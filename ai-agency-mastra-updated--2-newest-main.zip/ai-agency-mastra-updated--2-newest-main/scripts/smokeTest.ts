import { createWorkspace } from '../src/mastra/workspaces/index.js';
import { projectPlanSchema, socialOutputSchema } from '../src/mastra/agents/schemas.js';
import { evaluateCondition } from '../src/mastra/workflows/safeCondition.js';

/**
 * Lightweight smoke test for the agent layer + safe condition evaluator.
 * Requires OPENAI_API_KEY + MONGODB_URI for the live agent calls.
 * Run: `npm run test:agents`.
 */
async function main() {
  // 1. Safe condition evaluator (security fix) — no network needed.
  const ctx = { priority: 'high', score: 0.8, approved: true };
  console.assert(evaluateCondition("priority == 'high' && score >= 0.5", ctx) === true, 'cond1');
  console.assert(evaluateCondition("priority == 'low' || approved == true", ctx) === true, 'cond2');
  console.assert(evaluateCondition('score < 0.5', ctx) === false, 'cond3');
  console.log('✅ safe condition evaluator passes');

  if (!process.env.OPENAI_API_KEY) {
    console.log('ℹ️  OPENAI_API_KEY not set — skipping live agent calls.');
    return;
  }

  const ws = createWorkspace('demo-tenant', 'demo-user');

  console.log('▶ Running Project Manager agent…');
  const pm = await ws.runAgent(
    'project-manager',
    'Plan a 4-week landing page project for a SaaS startup.',
    projectPlanSchema,
  );
  console.log(`✅ PM plan: ${pm.object.phases.length} phases, ${pm.object.risks.length} risks`);

  console.log('▶ Running Social Media agent…');
  const social = await ws.runAgent(
    'social-media',
    'Create a 3-post launch campaign for the SaaS landing page.',
    socialOutputSchema,
  );
  console.log(`✅ Social: ${social.object.posts.length} posts generated`);
}

main()
  .then(() => process.exit(0))
  .catch((e) => {
    console.error('❌ Smoke test failed:', e);
    process.exit(1);
  });
