import { connectToDatabase } from '../src/lib/mongoose.js';
import { KnowledgeDoc } from '../src/models/index.js';
import { ingestDocument } from '../src/mastra/rag/vectorStore.js';

/**
 * Seeds the tenant RAG knowledge base with a couple of sample agency documents
 * (a brand guideline + a client brief). Run: `npm run rag:seed`.
 */
const TENANT = process.env.SEED_TENANT ?? 'demo-tenant';

const docs = [
  {
    title: 'Acme Brand Guidelines',
    source: 'brand',
    tags: ['brand', 'design'],
    content: `Acme Corp brand guidelines.
Voice: confident, friendly, concise. Avoid jargon.
Primary color: #2563EB (Acme Blue). Secondary: #0F172A (Slate). Accent: #F59E0B (Amber).
Typography: Headings use "Inter" bold; body uses "Inter" regular at 16px base.
Logo clear space: 1x the height of the mark on all sides.`,
  },
  {
    title: 'Client Brief: Acme Storefront Revamp',
    source: 'brief',
    tags: ['brief', 'ecommerce'],
    content: `Acme wants to revamp its e-commerce storefront.
Goals: increase conversion by 15%, reduce checkout abandonment, support mobile-first shoppers.
Must integrate with existing Stripe payments and a headless CMS.
Target audience: 25-45 urban professionals. Launch in 8 weeks.`,
  },
];

async function main() {
  await connectToDatabase();
  for (const d of docs) {
    const { chunks } = await ingestDocument(d.content, {
      tenantId: TENANT,
      title: d.title,
      source: d.source,
      tags: d.tags,
    });
    await KnowledgeDoc.create({ tenantId: TENANT, ...d, chunkCount: chunks });
    console.log(`✅ Ingested "${d.title}" (${chunks} chunks) for tenant ${TENANT}`);
  }
  console.log('Done.');
  process.exit(0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
