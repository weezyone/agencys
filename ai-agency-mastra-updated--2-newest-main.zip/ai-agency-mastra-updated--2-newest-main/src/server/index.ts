import express, { type Request, type Response, type NextFunction } from 'express';
import { existsSync } from 'fs';
import { join, dirname, resolve } from 'path';
import { fileURLToPath, pathToFileURL } from 'url';
import { z } from 'zod';
import { env } from '../lib/env.js';
import { connectToDatabase } from '../lib/mongoose.js';
import { resolveAuth, AuthError, type AuthContext } from '../lib/security.js';
import { writeAudit, KnowledgeDoc, AgentRun } from '../models/index.js';
import { mastra } from '../mastra/index.js';
import { agents, type AgentKey } from '../mastra/agents/index.js';
import { createWorkspace } from '../mastra/workspaces/index.js';
import { ingestDocument } from '../mastra/rag/vectorStore.js';
import {
  projectPlanSchema,
  researchOutputSchema,
  designOutputSchema,
  frontendOutputSchema,
  backendOutputSchema,
  qaOutputSchema,
  socialOutputSchema,
} from '../mastra/agents/schemas.js';

/**
 * HTTP API — exposes the Mastra agency over REST.
 *
 * Auth is enforced via `resolveAuth` (no `mock-user-id` bypass). Each request
 * is scoped to a tenant workspace. All actions are audit-logged.
 */
const app = express();
const __dirname = dirname(fileURLToPath(import.meta.url));
const webDist = join(__dirname, '../../web/dist');

app.use((req, res, next) => {
  const origin = req.header('Origin');
  if (origin?.startsWith('http://localhost:') || origin?.startsWith('http://127.0.0.1:')) {
    res.header('Access-Control-Allow-Origin', origin);
    res.header('Vary', 'Origin');
  }
  res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

app.use(express.json({ limit: '4mb' }));

// --- auth middleware (no dev bypass when ENFORCE_AUTH=true) ---
declare global {
  // eslint-disable-next-line no-var
  var __noop: undefined;
}
interface AuthedRequest extends Request {
  auth?: AuthContext;
}
function authenticate(req: AuthedRequest, res: Response, next: NextFunction) {
  try {
    req.auth = resolveAuth(req.header('authorization'));
    next();
  } catch (e) {
    const status = e instanceof AuthError ? e.status : 500;
    res.status(status).json({ error: e instanceof Error ? e.message : 'Auth failed' });
  }
}

const schemaByAgent: Record<AgentKey, z.ZodTypeAny> = {
  'project-manager': projectPlanSchema,
  'research-analyst': researchOutputSchema,
  designer: designOutputSchema,
  'frontend-developer': frontendOutputSchema,
  'backend-developer': backendOutputSchema,
  'qa-engineer': qaOutputSchema,
  'social-media': socialOutputSchema,
};

app.get('/health', (_req, res) =>
  res.json({
    ok: true,
    modelProvider: env.modelProvider,
    model: env.model,
    vertex: env.modelProvider === 'vertex'
      ? {
          project: env.googleCloudProject,
          location: env.googleCloudLocation,
          opus: env.vertexOpusModel,
          fable: env.vertexFableModel,
        }
      : undefined,
  }),
);

app.get('/agents', authenticate, (_req, res) => {
  res.json({
    agents: Object.values(agents).map((a) => ({ id: a.id, name: a.name, description: a.getDescription() })),
  });
});

// Run a single agent with structured output.
app.post('/agents/:agentKey/run', authenticate, async (req: AuthedRequest, res: Response) => {
  const agentKey = req.params.agentKey as AgentKey;
  if (!agents[agentKey]) return res.status(404).json({ error: `Unknown agent: ${agentKey}` });
  const body = z.object({ prompt: z.string(), projectId: z.string().optional() }).safeParse(req.body);
  if (!body.success) return res.status(400).json({ error: body.error.message });

  const { tenantId, userId } = req.auth!;
  const ws = createWorkspace(tenantId, userId);
  const startedAt = Date.now();
  try {
    const { object, text } = await ws.runAgent(
      agentKey,
      body.data.prompt,
      schemaByAgent[agentKey],
      { threadSuffix: body.data.projectId ?? agentKey },
    );
    await AgentRun.create({
      tenantId,
      projectId: body.data.projectId,
      agentType: agentKey,
      status: 'idle',
      input: body.data.prompt,
      output: object,
      rawText: text,
      durationMs: Date.now() - startedAt,
    });
    await writeAudit({ tenantId, userId, action: 'agent.run', resource: agentKey });
    res.json({ ok: true, output: object });
  } catch (e) {
    res.status(500).json({ ok: false, error: e instanceof Error ? e.message : 'Agent run failed' });
  }
});

// Kick off the full project-delivery workflow.
app.post('/workflows/project-delivery', authenticate, async (req: AuthedRequest, res: Response) => {
  const body = z.object({ projectName: z.string(), brief: z.string() }).safeParse(req.body);
  if (!body.success) return res.status(400).json({ error: body.error.message });

  const { tenantId, userId } = req.auth!;
  try {
    const run = await mastra.getWorkflow('project-delivery').createRun();
    const result = await run.start({
      inputData: { tenantId, userId, projectName: body.data.projectName, brief: body.data.brief },
    });
    await writeAudit({ tenantId, userId, action: 'workflow.run', resource: 'project-delivery' });
    res.json({ ok: true, status: result.status, result });
  } catch (e) {
    res.status(500).json({ ok: false, error: e instanceof Error ? e.message : 'Workflow failed' });
  }
});

// Ingest a document into the tenant RAG knowledge base.
app.post('/knowledge', authenticate, async (req: AuthedRequest, res: Response) => {
  const body = z
    .object({ title: z.string(), content: z.string(), source: z.string().optional(), tags: z.array(z.string()).optional() })
    .safeParse(req.body);
  if (!body.success) return res.status(400).json({ error: body.error.message });

  const { tenantId, userId } = req.auth!;
  try {
    const { chunks } = await ingestDocument(body.data.content, {
      tenantId,
      title: body.data.title,
      source: body.data.source,
      tags: body.data.tags,
    });
    const doc = await KnowledgeDoc.create({
      tenantId,
      title: body.data.title,
      source: body.data.source ?? 'manual',
      content: body.data.content,
      tags: body.data.tags ?? [],
      chunkCount: chunks,
    });
    await writeAudit({ tenantId, userId, action: 'knowledge.ingest', resource: String(doc._id) });
    res.json({ ok: true, id: doc._id, chunks });
  } catch (e) {
    res.status(500).json({ ok: false, error: e instanceof Error ? e.message : 'Ingest failed' });
  }
});

if (existsSync(webDist)) {
  app.use(express.static(webDist));
  app.get('*', (req, res, next) => {
    if (req.method !== 'GET' || req.path.startsWith('/agents') || req.path.startsWith('/workflows') || req.path.startsWith('/knowledge') || req.path === '/health') {
      return next();
    }
    res.sendFile(join(webDist, 'index.html'));
  });
}

export async function start() {
  await connectToDatabase();
  app.listen(env.port, () => {
    console.log(`🚀 AI Agency (Mastra) API listening on http://localhost:${env.port}`);
    console.log(`   Auth enforced: ${env.enforceAuth}`);
    if (existsSync(webDist)) {
      console.log(`   Agency dashboard: http://localhost:${env.port}`);
    }
  });
}

export { app };

// Run directly (node/tsx src/server/index.ts)
const entry = process.argv[1];
const isMain =
  entry != null &&
  import.meta.url === pathToFileURL(resolve(entry)).href;

if (isMain) {
  start().catch((e) => {
    console.error('Fatal startup error:', e);
    process.exit(1);
  });
}
