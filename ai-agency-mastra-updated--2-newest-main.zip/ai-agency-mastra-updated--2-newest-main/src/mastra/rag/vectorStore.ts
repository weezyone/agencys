import { MongoDBVector } from '@mastra/mongodb';
import { MDocument } from '@mastra/rag';
import { env } from '../../lib/env.js';
import { embedTexts, embedText, embeddingDimension } from './embeddings.js';

/**
 * RAG layer — NEW capability (the legacy codebase had no RAG).
 *
 * Uses Mastra's `MongoDBVector` (Atlas Vector Search) on the same cluster.
 * Knowledge is stored per-tenant via a metadata `tenantId` filter so retrieval
 * never crosses workspace boundaries (multi-tenant isolation preserved).
 */
export const RAG_INDEX = 'agency_knowledge';

let vectorStore: MongoDBVector | null = null;

export function getVectorStore(): MongoDBVector {
  if (!vectorStore) {
    vectorStore = new MongoDBVector({
      id: 'agency-vector',
      uri: env.mongoUri,
      dbName: env.mongoVectorDbName,
    });
  }
  return vectorStore;
}

let indexEnsured = false;
export async function ensureIndex(): Promise<void> {
  if (indexEnsured) return;
  const store = getVectorStore();
  try {
    await store.createIndex({ indexName: RAG_INDEX, dimension: embeddingDimension(), metric: 'cosine' });
  } catch (e) {
    // Index may already exist — that is fine.
    if (!/exist/i.test(String(e))) throw e;
  }
  indexEnsured = true;
}

export interface IngestOptions {
  tenantId: string;
  title: string;
  source?: string;
  tags?: string[];
}

/** Chunk → embed → upsert a document into the tenant-scoped knowledge base. */
export async function ingestDocument(content: string, opts: IngestOptions): Promise<{ chunks: number }> {
  await ensureIndex();
  const doc = MDocument.fromText(content, { title: opts.title });
  const chunks = await doc.chunk({ strategy: 'recursive', size: 800, overlap: 100 });

  const texts = chunks.map((c) => c.text);
  const vectors = await embedTexts(texts);

  const metadata = chunks.map((c) => ({
    tenantId: opts.tenantId,
    title: opts.title,
    source: opts.source ?? 'manual',
    tags: opts.tags ?? [],
    text: c.text,
  }));

  await getVectorStore().upsert({
    indexName: RAG_INDEX,
    vectors,
    metadata,
    documents: texts,
  });

  return { chunks: chunks.length };
}

export interface RetrievedChunk {
  text: string;
  score: number;
  title?: string;
  source?: string;
}

/** Semantic search scoped to a single tenant. */
export async function retrieve(
  query: string,
  tenantId: string,
  topK = 5,
): Promise<RetrievedChunk[]> {
  await ensureIndex();
  const queryVector = await embedText(query);
  const results = await getVectorStore().query({
    indexName: RAG_INDEX,
    queryVector,
    topK,
    filter: { tenantId },
  });
  return results.map((r) => ({
    text: (r.metadata?.text as string) ?? '',
    score: r.score ?? 0,
    title: r.metadata?.title as string | undefined,
    source: r.metadata?.source as string | undefined,
  }));
}
