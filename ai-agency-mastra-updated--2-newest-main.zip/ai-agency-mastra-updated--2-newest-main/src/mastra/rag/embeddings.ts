import { env } from '../../lib/env.js';

/**
 * Embedding helper — calls the OpenAI embeddings API directly with a real
 * HTTP request (no mock). Used by the RAG ingestion pipeline and the vector
 * query tool. The model name is taken from `AGENCY_EMBEDDING_MODEL`
 * (the "openai/" router prefix is stripped for the raw REST call).
 */
const EMBEDDING_DIMENSIONS: Record<string, number> = {
  'text-embedding-3-small': 1536,
  'text-embedding-3-large': 3072,
  'text-embedding-ada-002': 1536,
};

export function embeddingModelName(): string {
  return env.embeddingModel.replace(/^openai\//, '');
}

export function embeddingDimension(): number {
  return EMBEDDING_DIMENSIONS[embeddingModelName()] ?? 1536;
}

export async function embedTexts(texts: string[]): Promise<number[][]> {
  if (!env.openaiApiKey) {
    throw new Error('OPENAI_API_KEY is required to generate embeddings for RAG.');
  }
  if (texts.length === 0) return [];

  const res = await fetch('https://api.openai.com/v1/embeddings', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${env.openaiApiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ model: embeddingModelName(), input: texts }),
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Embedding request failed (${res.status}): ${err}`);
  }

  const data = (await res.json()) as { data: { embedding: number[] }[] };
  return data.data.map((d) => d.embedding);
}

export async function embedText(text: string): Promise<number[]> {
  const [vec] = await embedTexts([text]);
  return vec;
}
