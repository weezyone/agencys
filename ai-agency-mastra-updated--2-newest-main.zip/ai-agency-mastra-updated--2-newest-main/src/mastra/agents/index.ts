import { Agent } from '@mastra/core/agent';
import { agentModels } from '../../lib/models.js';
import { getMemory } from '../storage.js';
import { knowledgeSearchTool } from '../tools/knowledgeTool.js';
import { integrationTools } from '../tools/integrationTools.js';

/**
 * Mastra Agents — REPLACES the legacy `BaseAgent` + `callOpenAI()` plumbing and
 * all the specialized `*Agent` classes whose `parse*()` methods returned
 * hardcoded data.
 *
 * Every agent:
 *  - uses Opus 4.8 (reasoning) or Fable 5 (coding/creative) on Vertex, or
 *    the Mastra model router (`AGENCY_MODEL`) when `AGENCY_MODEL_PROVIDER=router`,
 *  - has persistent memory (MongoDB-backed) for conversation + working memory,
 *  - has real tools (RAG knowledge search + relevant integrations),
 *  - returns schema-validated structured output (see `schemas.ts`) at call time
 *    via `agent.generate(prompt, { structuredOutput: { schema } })`.
 */

const baseTools = { knowledge_search: knowledgeSearchTool };

export const projectManagerAgent = new Agent({
  id: 'project-manager',
  name: 'Project Manager Agent',
  description: 'Plans projects, breaks down work, allocates resources and assesses risk.',
  instructions: `You are an expert software delivery Project Manager for a digital agency.
Responsibilities: break complex projects into phases and tasks, create realistic timelines,
allocate the right specialist agents (frontend, backend, designer, qa, research, social),
and proactively identify risks with mitigations.
Always call knowledge_search first to ground plans in any client briefs or past deliverables.
Be specific, realistic and dependency-aware. When asked to create tickets, use the Jira/Asana/GitHub tools.`,
  model: agentModels.opus(),
  memory: getMemory(),
  tools: {
    ...baseTools,
    jira_create_issue: integrationTools.jira_create_issue,
    asana_create_task: integrationTools.asana_create_task,
    github_create_issue: integrationTools.github_create_issue,
    slack_post_message: integrationTools.slack_post_message,
  },
});

export const frontendAgent = new Agent({
  id: 'frontend-developer',
  name: 'Frontend Developer Agent',
  description: 'Implements React/TypeScript UIs, components and routing.',
  instructions: `You are a senior Frontend Developer specializing in React + TypeScript.
Produce production-quality, accessible, well-typed components. Prefer functional components,
hooks, and clear prop interfaces. Include real, compilable code in your structured output —
never placeholders. Ground design decisions using knowledge_search (brand guidelines, design system).`,
  model: agentModels.fable(),
  memory: getMemory(),
  tools: { ...baseTools, github_create_issue: integrationTools.github_create_issue },
});

export const backendAgent = new Agent({
  id: 'backend-developer',
  name: 'Backend Developer Agent',
  description: 'Designs APIs, data models, auth and backend services.',
  instructions: `You are a senior Backend Developer. Design clean REST/GraphQL APIs, robust data models,
secure auth, and provide real handler code (Node/TypeScript by default unless told otherwise).
Consider validation, error handling, pagination, and security. Never return placeholder code.`,
  model: agentModels.opus(),
  memory: getMemory(),
  tools: { ...baseTools, github_create_issue: integrationTools.github_create_issue },
});

export const qaAgent = new Agent({
  id: 'qa-engineer',
  name: 'QA Engineer Agent',
  description: 'Reviews code, finds issues and writes real test cases.',
  instructions: `You are a meticulous QA Engineer. Review code for correctness, security, performance and
maintainability. Report concrete, actionable issues with severity and location. Write real,
runnable test cases (unit/integration/e2e) — not stubs. Estimate realistic coverage.`,
  model: agentModels.fable(),
  memory: getMemory(),
  tools: { ...baseTools, github_create_issue: integrationTools.github_create_issue },
});

export const designAgent = new Agent({
  id: 'designer',
  name: 'Design Agent',
  description: 'Creates design systems, wireframes and UI assets.',
  instructions: `You are a product Designer. Produce coherent design systems (color, typography, spacing),
clear wireframes for each screen, and asset specifications. When you generate icons/illustrations,
provide valid inline SVG. Align everything to brand guidelines retrieved via knowledge_search.`,
  model: agentModels.fable(),
  memory: getMemory(),
  tools: { ...baseTools, figma_get_file: integrationTools.figma_get_file },
});

export const researchAgent = new Agent({
  id: 'research-analyst',
  name: 'Research Agent',
  description: 'Conducts market, competitor and trend research.',
  instructions: `You are a Market Research Analyst. Provide rigorous, structured market overviews,
competitor analysis (strengths/weaknesses/positioning), trend analysis with time horizons, and
clear opportunities and recommendations. Ground findings in knowledge_search results when available
and be explicit about assumptions.`,
  model: agentModels.opus(),
  memory: getMemory(),
  tools: { ...baseTools },
});

export const socialMediaAgent = new Agent({
  id: 'social-media',
  name: 'Social Media Agent',
  description: 'Creates social content, calendars and publishes posts.',
  instructions: `You are a Social Media Manager. Create platform-appropriate content with strong hooks,
relevant hashtags, optimal posting times, and a coherent content-calendar narrative. When asked to
publish, use the meta_publish_post tool. Define measurable KPIs. Match brand voice from knowledge_search.`,
  model: agentModels.fable(),
  memory: getMemory(),
  tools: {
    ...baseTools,
    meta_publish_post: integrationTools.meta_publish_post,
    slack_post_message: integrationTools.slack_post_message,
  },
});

export const agents = {
  'project-manager': projectManagerAgent,
  'frontend-developer': frontendAgent,
  'backend-developer': backendAgent,
  'qa-engineer': qaAgent,
  designer: designAgent,
  'research-analyst': researchAgent,
  'social-media': socialMediaAgent,
};

export type AgentKey = keyof typeof agents;
