import { z } from 'zod';

/**
 * Zod structured-output schemas for every agent.
 *
 * These REPLACE the legacy `parse*()` stub methods (e.g.
 * `parseProjectPhases`, `parseUIImplementation`, `parseAPIDesign`) that
 * returned hardcoded placeholder data. Each agent now produces schema-validated
 * structured output directly from the LLM via Mastra's `structuredOutput`,
 * so there are no mocks anywhere in the agent layer.
 */

export const priority = z.enum(['low', 'medium', 'high', 'critical']);

/* -------------------------- Project Manager -------------------------- */
export const projectPlanSchema = z.object({
  name: z.string(),
  summary: z.string(),
  phases: z.array(
    z.object({
      name: z.string(),
      tasks: z.array(z.string()),
      dependencies: z.array(z.string()),
      estimatedDays: z.number(),
    }),
  ),
  resources: z.array(z.object({ agentType: z.string(), allocationPct: z.number() })),
  risks: z.array(
    z.object({
      category: z.enum(['technical', 'timeline', 'resource', 'scope']),
      description: z.string(),
      severity: z.enum(['low', 'medium', 'high']),
      probability: z.number().min(0).max(1),
      mitigation: z.string(),
    }),
  ),
  estimatedDurationDays: z.number(),
});
export type ProjectPlan = z.infer<typeof projectPlanSchema>;

export const taskBreakdownSchema = z.object({
  parentTask: z.string(),
  subtasks: z.array(
    z.object({
      title: z.string(),
      description: z.string(),
      estimatedHours: z.number(),
      skillsRequired: z.array(z.string()),
      assignedAgent: z.string(),
      priority,
    }),
  ),
});
export type TaskBreakdown = z.infer<typeof taskBreakdownSchema>;

/* ----------------------------- Frontend ----------------------------- */
export const frontendOutputSchema = z.object({
  summary: z.string(),
  components: z.array(
    z.object({
      name: z.string(),
      path: z.string(),
      description: z.string(),
      code: z.string(),
      dependencies: z.array(z.string()),
    }),
  ),
  routes: z.array(z.object({ path: z.string(), component: z.string() })).default([]),
  notes: z.array(z.string()).default([]),
});
export type FrontendOutput = z.infer<typeof frontendOutputSchema>;

/* ----------------------------- Backend ------------------------------ */
export const backendOutputSchema = z.object({
  summary: z.string(),
  endpoints: z.array(
    z.object({
      method: z.enum(['GET', 'POST', 'PUT', 'PATCH', 'DELETE']),
      path: z.string(),
      description: z.string(),
      requestSchema: z.string().optional(),
      responseSchema: z.string().optional(),
      handlerCode: z.string(),
    }),
  ),
  dataModels: z.array(z.object({ name: z.string(), fields: z.string(), code: z.string() })).default([]),
  notes: z.array(z.string()).default([]),
});
export type BackendOutput = z.infer<typeof backendOutputSchema>;

/* ------------------------------- QA --------------------------------- */
export const qaOutputSchema = z.object({
  summary: z.string(),
  overallQuality: z.enum(['poor', 'fair', 'good', 'excellent']),
  issues: z.array(
    z.object({
      severity: z.enum(['info', 'minor', 'major', 'critical']),
      type: z.string(),
      location: z.string(),
      description: z.string(),
      recommendation: z.string(),
    }),
  ),
  testCases: z.array(
    z.object({
      name: z.string(),
      description: z.string(),
      type: z.enum(['unit', 'integration', 'e2e']),
      code: z.string(),
    }),
  ),
  coverageEstimatePct: z.number().min(0).max(100),
});
export type QAOutput = z.infer<typeof qaOutputSchema>;

/* ----------------------------- Design ------------------------------- */
export const designOutputSchema = z.object({
  summary: z.string(),
  designSystem: z.object({
    colors: z.array(z.object({ name: z.string(), hex: z.string() })),
    typography: z.array(z.object({ role: z.string(), font: z.string(), size: z.string() })),
    spacingScale: z.array(z.string()),
  }),
  wireframes: z.array(
    z.object({ screen: z.string(), description: z.string(), layout: z.string() }),
  ),
  assets: z.array(z.object({ name: z.string(), type: z.string(), svg: z.string().optional() })).default([]),
});
export type DesignOutput = z.infer<typeof designOutputSchema>;

/* ---------------------------- Research ------------------------------ */
export const researchOutputSchema = z.object({
  summary: z.string(),
  marketOverview: z.string(),
  competitors: z.array(
    z.object({
      name: z.string(),
      strengths: z.array(z.string()),
      weaknesses: z.array(z.string()),
      positioning: z.string(),
    }),
  ),
  trends: z.array(z.object({ trend: z.string(), impact: z.string(), horizon: z.string() })),
  opportunities: z.array(z.string()),
  recommendations: z.array(z.string()),
});
export type ResearchOutput = z.infer<typeof researchOutputSchema>;

/* --------------------------- Social Media --------------------------- */
export const socialOutputSchema = z.object({
  summary: z.string(),
  posts: z.array(
    z.object({
      platform: z.enum(['facebook', 'instagram', 'x', 'linkedin', 'tiktok']),
      content: z.string(),
      hashtags: z.array(z.string()),
      suggestedTime: z.string(),
      mediaIdea: z.string().optional(),
    }),
  ),
  contentCalendarSummary: z.string(),
  kpis: z.array(z.string()),
});
export type SocialOutput = z.infer<typeof socialOutputSchema>;
