import { Mastra } from '@mastra/core/mastra';
import { PinoLogger } from '@mastra/loggers';
import { getStore } from './storage.js';
import { getVectorStore } from './rag/vectorStore.js';
import { agents } from './agents/index.js';
import { projectDeliveryWorkflow } from './workflows/projectDelivery.js';
import { brandIdentityWorkflow } from './workflows/brandIdentity.js';
import { socialCampaignWorkflow } from './workflows/socialCampaign.js';
import { landingPageWorkflow } from './workflows/landingPage.js';
import { marketResearchWorkflow } from './workflows/marketResearch.js';

/**
 * Central Mastra instance — wires agents, workflows, MongoDB storage, the
 * MongoDB vector store (RAG) and structured logging. This is the single entry
 * point that replaces the legacy singletons (`AgentFactory`,
 * `AgentCommunicationSystem`, `AgentCoordinationManager`,
 * `MultiAgentWorkflowOrchestrator`).
 */
export const mastra = new Mastra({
  agents,
  workflows: {
    'project-delivery': projectDeliveryWorkflow,
    'brand-identity': brandIdentityWorkflow,
    'social-campaign': socialCampaignWorkflow,
    'landing-page': landingPageWorkflow,
    'market-research': marketResearchWorkflow,
  },
  storage: getStore(),
  vectors: { agency: getVectorStore() },
  logger: new PinoLogger({ name: 'ai-agency', level: 'info' }),
});

export { agents } from './agents/index.js';
export { projectDeliveryWorkflow } from './workflows/projectDelivery.js';
export { brandIdentityWorkflow } from './workflows/brandIdentity.js';
export { socialCampaignWorkflow } from './workflows/socialCampaign.js';
export { landingPageWorkflow } from './workflows/landingPage.js';
export { marketResearchWorkflow } from './workflows/marketResearch.js';
export { createWorkspace } from './workspaces/index.js';
