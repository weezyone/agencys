import { createTool } from '@mastra/core/tools';
import { z } from 'zod';
import { retrieve } from '../rag/vectorStore.js';

/**
 * RAG retrieval tool — lets any agent pull relevant knowledge (client briefs,
 * brand guidelines, past deliverables) from the tenant-scoped vector store.
 *
 * The `tenantId` is read from the request context so retrieval is always
 * isolated to the caller's workspace.
 */
export const knowledgeSearchTool = createTool({
  id: 'knowledge_search',
  description:
    'Search the agency knowledge base (briefs, brand guidelines, prior deliverables) for context relevant to the query. Always use this before answering questions that may depend on client-specific or project-specific knowledge.',
  inputSchema: z.object({
    query: z.string().describe('What to look up in the knowledge base'),
    topK: z.number().min(1).max(10).default(5),
  }),
  outputSchema: z.object({
    results: z.array(
      z.object({
        text: z.string(),
        score: z.number(),
        title: z.string().optional(),
        source: z.string().optional(),
      }),
    ),
  }),
  execute: async ({ query, topK }, context) => {
    const tenantId =
      (context?.requestContext?.get('tenantId') as string | undefined) ?? 'default';
    const results = await retrieve(query, tenantId, topK);
    return { results };
  },
});
