import { createTool } from '@mastra/core/tools';
import { z } from 'zod';
import { getIntegrations } from '../../lib/env.js';

/**
 * Integration tools — PORTED from the legacy `lib/integrations/providers/*`.
 *
 * The legacy providers made REAL `fetch()` calls with real auth (Slack, GitHub,
 * Jira, Asana, Vercel, Netlify, Figma, Meta). That logic is preserved here as
 * Mastra tools so any agent can call them. Each tool:
 *   - reads credentials from validated env config (no hardcoded secrets),
 *   - returns a typed result instead of throwing on "not configured",
 *   - performs the same real HTTP request the provider class did.
 */

function notConfigured(service: string, missing: string) {
  return {
    ok: false as const,
    error: `${service} is not configured. Set ${missing} in your environment.`,
  };
}

async function safeJson(res: Response): Promise<unknown> {
  const text = await res.text();
  try {
    return JSON.parse(text);
  } catch {
    return { raw: text };
  }
}

/* ------------------------------ Slack ------------------------------ */
export const slackPostMessageTool = createTool({
  id: 'slack_post_message',
  description: 'Post a message to a Slack channel via chat.postMessage.',
  inputSchema: z.object({
    channel: z.string().describe('Channel ID or name, e.g. #general'),
    text: z.string(),
    blocks: z.array(z.any()).optional(),
  }),
  outputSchema: z.object({ ok: z.boolean(), ts: z.string().optional(), error: z.string().optional() }),
  execute: async ({ channel, text, blocks }) => {
    const { slackBotToken } = getIntegrations();
    if (!slackBotToken) return { ...notConfigured('Slack', 'SLACK_BOT_TOKEN') };
    const res = await fetch('https://slack.com/api/chat.postMessage', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${slackBotToken}`,
        'Content-Type': 'application/json; charset=utf-8',
      },
      body: JSON.stringify({ channel, text, blocks }),
    });
    const data = (await safeJson(res)) as { ok?: boolean; ts?: string; error?: string };
    return { ok: Boolean(data.ok), ts: data.ts, error: data.error };
  },
});

/* ------------------------------ GitHub ----------------------------- */
export const githubCreateIssueTool = createTool({
  id: 'github_create_issue',
  description: 'Create a GitHub issue in owner/repo.',
  inputSchema: z.object({
    owner: z.string(),
    repo: z.string(),
    title: z.string(),
    body: z.string().optional(),
    labels: z.array(z.string()).optional(),
  }),
  outputSchema: z.object({
    ok: z.boolean(),
    number: z.number().optional(),
    url: z.string().optional(),
    error: z.string().optional(),
  }),
  execute: async ({ owner, repo, title, body, labels }) => {
    const { githubToken } = getIntegrations();
    if (!githubToken) return { ...notConfigured('GitHub', 'GITHUB_TOKEN') };
    const res = await fetch(`https://api.github.com/repos/${owner}/${repo}/issues`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${githubToken}`,
        Accept: 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
      },
      body: JSON.stringify({ title, body, labels }),
    });
    const data = (await safeJson(res)) as { number?: number; html_url?: string; message?: string };
    return {
      ok: res.ok,
      number: data.number,
      url: data.html_url,
      error: res.ok ? undefined : data.message,
    };
  },
});

/* ------------------------------- Jira ------------------------------ */
export const jiraCreateIssueTool = createTool({
  id: 'jira_create_issue',
  description: 'Create a Jira issue in a project.',
  inputSchema: z.object({
    projectKey: z.string(),
    summary: z.string(),
    description: z.string().optional(),
    issueType: z.string().default('Task'),
  }),
  outputSchema: z.object({
    ok: z.boolean(),
    key: z.string().optional(),
    error: z.string().optional(),
  }),
  execute: async ({ projectKey, summary, description, issueType }) => {
    const { jiraBaseUrl, jiraEmail, jiraApiToken } = getIntegrations();
    if (!jiraBaseUrl || !jiraEmail || !jiraApiToken) {
      return { ...notConfigured('Jira', 'JIRA_BASE_URL/JIRA_EMAIL/JIRA_API_TOKEN') };
    }
    const auth = Buffer.from(`${jiraEmail}:${jiraApiToken}`).toString('base64');
    const res = await fetch(`${jiraBaseUrl}/rest/api/3/issue`, {
      method: 'POST',
      headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        fields: {
          project: { key: projectKey },
          summary,
          issuetype: { name: issueType },
          description: description
            ? {
                type: 'doc',
                version: 1,
                content: [{ type: 'paragraph', content: [{ type: 'text', text: description }] }],
              }
            : undefined,
        },
      }),
    });
    const data = (await safeJson(res)) as { key?: string; errorMessages?: string[] };
    return { ok: res.ok, key: data.key, error: res.ok ? undefined : (data.errorMessages || []).join('; ') };
  },
});

/* ------------------------------ Asana ------------------------------ */
export const asanaCreateTaskTool = createTool({
  id: 'asana_create_task',
  description: 'Create a task in Asana.',
  inputSchema: z.object({
    projectId: z.string(),
    name: z.string(),
    notes: z.string().optional(),
  }),
  outputSchema: z.object({ ok: z.boolean(), gid: z.string().optional(), error: z.string().optional() }),
  execute: async ({ projectId, name, notes }) => {
    const { asanaAccessToken } = getIntegrations();
    if (!asanaAccessToken) return { ...notConfigured('Asana', 'ASANA_ACCESS_TOKEN') };
    const res = await fetch('https://app.asana.com/api/1.0/tasks', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${asanaAccessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ data: { name, notes, projects: [projectId] } }),
    });
    const data = (await safeJson(res)) as { data?: { gid?: string }; errors?: { message: string }[] };
    return {
      ok: res.ok,
      gid: data.data?.gid,
      error: res.ok ? undefined : (data.errors || []).map((e) => e.message).join('; '),
    };
  },
});

/* ------------------------------ Vercel ----------------------------- */
export const vercelListDeploymentsTool = createTool({
  id: 'vercel_list_deployments',
  description: 'List recent Vercel deployments for the account/team.',
  inputSchema: z.object({ limit: z.number().min(1).max(100).default(10) }),
  outputSchema: z.object({
    ok: z.boolean(),
    deployments: z.array(z.object({ uid: z.string(), url: z.string(), state: z.string().optional() })).optional(),
    error: z.string().optional(),
  }),
  execute: async ({ limit }) => {
    const { vercelToken } = getIntegrations();
    if (!vercelToken) return { ...notConfigured('Vercel', 'VERCEL_TOKEN') };
    const res = await fetch(`https://api.vercel.com/v6/deployments?limit=${limit}`, {
      headers: { Authorization: `Bearer ${vercelToken}` },
    });
    const data = (await safeJson(res)) as { deployments?: { uid: string; url: string; state?: string }[]; error?: { message: string } };
    return {
      ok: res.ok,
      deployments: data.deployments,
      error: res.ok ? undefined : data.error?.message,
    };
  },
});

/* ------------------------------ Netlify ---------------------------- */
export const netlifyListSitesTool = createTool({
  id: 'netlify_list_sites',
  description: 'List Netlify sites for the authenticated account.',
  inputSchema: z.object({}),
  outputSchema: z.object({
    ok: z.boolean(),
    sites: z.array(z.object({ id: z.string(), name: z.string(), url: z.string().optional() })).optional(),
    error: z.string().optional(),
  }),
  execute: async () => {
    const { netlifyToken } = getIntegrations();
    if (!netlifyToken) return { ...notConfigured('Netlify', 'NETLIFY_TOKEN') };
    const res = await fetch('https://api.netlify.com/api/v1/sites', {
      headers: { Authorization: `Bearer ${netlifyToken}` },
    });
    if (!res.ok) return { ok: false, error: `Netlify API error ${res.status}` };
    const sites = (await safeJson(res)) as { id: string; name: string; url?: string }[];
    return { ok: true, sites: sites.map((s) => ({ id: s.id, name: s.name, url: s.url })) };
  },
});

/* ------------------------------ Figma ------------------------------ */
export const figmaGetFileTool = createTool({
  id: 'figma_get_file',
  description: 'Fetch a Figma file metadata + document tree by file key.',
  inputSchema: z.object({ fileKey: z.string() }),
  outputSchema: z.object({
    ok: z.boolean(),
    name: z.string().optional(),
    lastModified: z.string().optional(),
    error: z.string().optional(),
  }),
  execute: async ({ fileKey }) => {
    const { figmaAccessToken } = getIntegrations();
    if (!figmaAccessToken) return { ...notConfigured('Figma', 'FIGMA_ACCESS_TOKEN') };
    const res = await fetch(`https://api.figma.com/v1/files/${fileKey}`, {
      headers: { 'X-Figma-Token': figmaAccessToken },
    });
    const data = (await safeJson(res)) as { name?: string; lastModified?: string; err?: string };
    return { ok: res.ok, name: data.name, lastModified: data.lastModified, error: res.ok ? undefined : data.err };
  },
});

/* ------------------------------- Meta ------------------------------ */
export const metaPublishPostTool = createTool({
  id: 'meta_publish_post',
  description: 'Publish a post to a Facebook Page feed via the Meta Graph API.',
  inputSchema: z.object({ pageId: z.string(), message: z.string(), link: z.string().optional() }),
  outputSchema: z.object({ ok: z.boolean(), id: z.string().optional(), error: z.string().optional() }),
  execute: async ({ pageId, message, link }) => {
    const { metaAccessToken } = getIntegrations();
    if (!metaAccessToken) return { ...notConfigured('Meta', 'META_ACCESS_TOKEN') };
    const params = new URLSearchParams({ message, access_token: metaAccessToken });
    if (link) params.set('link', link);
    const res = await fetch(`https://graph.facebook.com/v19.0/${pageId}/feed`, {
      method: 'POST',
      body: params,
    });
    const data = (await safeJson(res)) as { id?: string; error?: { message: string } };
    return { ok: res.ok, id: data.id, error: res.ok ? undefined : data.error?.message };
  },
});

export const integrationTools = {
  slack_post_message: slackPostMessageTool,
  github_create_issue: githubCreateIssueTool,
  jira_create_issue: jiraCreateIssueTool,
  asana_create_task: asanaCreateTaskTool,
  vercel_list_deployments: vercelListDeploymentsTool,
  netlify_list_sites: netlifyListSitesTool,
  figma_get_file: figmaGetFileTool,
  meta_publish_post: metaPublishPostTool,
};
