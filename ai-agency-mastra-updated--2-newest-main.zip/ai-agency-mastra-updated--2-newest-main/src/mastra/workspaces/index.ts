import { RequestContext } from '@mastra/core/request-context';
import type { AgentKey } from '../agents/index.js';
import { agents } from '../agents/index.js';
import { getMemory } from '../storage.js';

/**
 * Workspaces — multi-tenant isolation for Mastra.
 *
 * Each tenant is a workspace. A workspace produces:
 *  - a `RequestContext` carrying `tenantId` (read by tools like knowledge_search
 *    so RAG retrieval is always scoped to the tenant), and
 *  - deterministic memory identifiers (`resourceId` / `threadId`) so an agent's
 *    conversation history and working memory never leak across tenants.
 *
 * This preserves the row-level-security / tenant-isolation guarantees of the
 * legacy `lib/database/*` + `lib/middleware/tenantIsolation` layers, expressed
 * through Mastra primitives.
 */
export interface Workspace {
  tenantId: string;
  userId?: string;
  requestContext: RequestContext;
  /** Stable per-tenant resource id for memory scoping. */
  resourceId: string;
  /** Build a thread id namespaced to this tenant. */
  threadId(suffix: string): string;
  /** Run an agent with structured output, fully scoped to this workspace. */
  runAgent<T>(
    agentKey: AgentKey,
    prompt: string,
    schema: import('zod').ZodType<T>,
    opts?: { threadSuffix?: string },
  ): Promise<{ object: T; text: string }>;
}

export function createWorkspace(tenantId: string, userId?: string): Workspace {
  const requestContext = new RequestContext();
  requestContext.set('tenantId', tenantId);
  if (userId) requestContext.set('userId', userId);

  const resourceId = `tenant:${tenantId}`;

  return {
    tenantId,
    userId,
    requestContext,
    resourceId,
    threadId(suffix: string) {
      return `tenant:${tenantId}:${suffix}`;
    },
    async runAgent<T>(
      agentKey: AgentKey,
      prompt: string,
      schema: import('zod').ZodType<T>,
      opts?: { threadSuffix?: string },
    ) {
      const agent = agents[agentKey];
      const threadId = `tenant:${tenantId}:${opts?.threadSuffix ?? agentKey}`;
      const result = await agent.generate(prompt, {
        structuredOutput: { schema },
        requestContext,
        memory: { resource: resourceId, thread: threadId },
      });
      return { object: result.object as T, text: result.text };
    },
  };
}

export { getMemory };
