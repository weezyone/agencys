import { MongoDBStore } from '@mastra/mongodb';
import { Memory } from '@mastra/memory';
import { env } from '../lib/env.js';
import { patchObservabilityStorage } from './patchObservabilityStorage.js';
import { getVectorStore } from './rag/vectorStore.js';

/**
 * Mastra persistence — replaces the legacy in-memory `AgentState` /
 * `Conversation` handling and the in-memory `AgentCommunication` queues.
 *
 * `MongoDBStore` persists threads, messages and workflow state on the same
 * Atlas cluster as the business data. `Memory` adds working memory +
 * conversation history + semantic recall (RAG over past messages).
 */
let store: MongoDBStore | null = null;
export function getStore(): MongoDBStore {
  if (!store) {
    store = new MongoDBStore({
      id: 'agency-store',
      uri: env.mongoUri,
      dbName: env.mongoDbName,
    });

    if (store.stores?.observability) {
      patchObservabilityStorage(store.stores.observability);
    }
  }
  return store;
}

let sharedMemory: Memory | null = null;
export function getMemory(): Memory {
  if (!sharedMemory) {
    sharedMemory = new Memory({
      storage: getStore(),
      vector: getVectorStore(),
      embedder: env.embeddingModel,
      options: {
        lastMessages: 10,
        semanticRecall: { topK: 3, messageRange: 2 },
        workingMemory: { enabled: true },
        generateTitle: true,
      },
    });
  }
  return sharedMemory;
}
