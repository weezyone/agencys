import { createWorkflow, createStep } from '@mastra/core/workflows';
import { z } from 'zod';
import { createWorkspace } from '../workspaces/index.js';
import {
  designOutputSchema,
  frontendOutputSchema,
  qaOutputSchema,
} from '../agents/schemas.js';

/**
 * Landing Page Sprint workflow.
 *
 * Graph:
 *   design ─▶ frontend ─▶ qa ─▶ report
 *
 * Fast, conversion-focused single-page build: the designer defines the visual
 * system and hero/section layout, the frontend developer implements it, and QA
 * reviews and writes tests. No backend branch — optimized for marketing pages.
 */

const inputSchema = z.object({
  tenantId: z.string(),
  userId: z.string().optional(),
  projectName: z.string(),
  brief: z.string(),
});

const designStep = createStep({
  id: 'design',
  description: 'Designer defines the landing page visual system and layout.',
  inputSchema,
  outputSchema: z.object({
    tenantId: z.string(),
    userId: z.string().optional(),
    projectName: z.string(),
    brief: z.string(),
    design: designOutputSchema,
  }),
  execute: async ({ inputData }) => {
    const ws = createWorkspace(inputData.tenantId, inputData.userId);
    const { object: design } = await ws.runAgent(
      'designer',
      `Design a high-conversion landing page for "${inputData.projectName}": hero, sections, CTA, color palette, typography and responsive layout.\n\nBrief:\n${inputData.brief}`,
      designOutputSchema,
      { threadSuffix: `landing:${inputData.projectName}` },
    );
    return { ...inputData, design };
  },
});

const frontendStep = createStep({
  id: 'frontend',
  description: 'Frontend developer implements the landing page.',
  inputSchema: designStep.outputSchema,
  outputSchema: z.object({ frontend: frontendOutputSchema }),
  execute: async ({ inputData }) => {
    const ws = createWorkspace(inputData.tenantId, inputData.userId);
    const { object: frontend } = await ws.runAgent(
      'frontend-developer',
      `Implement the responsive landing page for "${inputData.projectName}".\n\nBrief:\n${inputData.brief}\n\nDesign system summary:\n${inputData.design.summary}`,
      frontendOutputSchema,
      { threadSuffix: `landing:${inputData.projectName}` },
    );
    return { frontend };
  },
});

const qaStep = createStep({
  id: 'qa',
  description: 'QA reviews the landing page implementation and writes tests.',
  inputSchema: z.object({ frontend: frontendOutputSchema }),
  outputSchema: z.object({ qa: qaOutputSchema }),
  execute: async ({ inputData, getInitData }) => {
    const init = getInitData() as z.infer<typeof inputSchema>;
    const ws = createWorkspace(init.tenantId, init.userId);
    const fePreview = inputData.frontend.components
      .map((c) => `// ${c.path}\n${c.code}`)
      .join('\n\n')
      .slice(0, 8000);
    const { object: qa } = await ws.runAgent(
      'qa-engineer',
      `Review the landing page for "${init.projectName}" (accessibility, responsiveness, performance, conversion) and write tests.\n\nFrontend:\n${fePreview}`,
      qaOutputSchema,
      { threadSuffix: `landing:${init.projectName}` },
    );
    return { qa };
  },
});

const outputSchema = z.object({
  projectName: z.string(),
  design: designOutputSchema,
  frontend: frontendOutputSchema,
  qa: qaOutputSchema,
});

const reportStep = createStep({
  id: 'report',
  description: 'Aggregate the landing page deliverables.',
  inputSchema: z.object({ qa: qaOutputSchema }),
  outputSchema,
  execute: async ({ inputData, getInitData, getStepResult }) => {
    const init = getInitData() as z.infer<typeof inputSchema>;
    return {
      projectName: init.projectName,
      design: getStepResult(designStep).design,
      frontend: getStepResult(frontendStep).frontend,
      qa: inputData.qa,
    };
  },
});

export const landingPageWorkflow = createWorkflow({
  id: 'landing-page',
  description:
    'Landing page sprint: design → frontend build → QA review → report.',
  inputSchema,
  outputSchema,
})
  .then(designStep)
  .then(frontendStep)
  .then(qaStep)
  .then(reportStep)
  .commit();
