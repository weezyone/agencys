import { createWorkflow, createStep } from '@mastra/core/workflows';
import { z } from 'zod';
import { createWorkspace } from '../workspaces/index.js';
import {
  projectPlanSchema,
  researchOutputSchema,
  designOutputSchema,
  frontendOutputSchema,
  backendOutputSchema,
  qaOutputSchema,
} from '../agents/schemas.js';

/**
 * Project delivery workflow — REPLACES the hand-rolled `WorkflowEngine` /
 * `WorkflowOrchestrator` / `AgentCommunication` / `AgentCoordination` stack.
 *
 * Graph-based, deterministic orchestration:
 *   plan ─▶ [research ‖ design] ─▶ [frontend ‖ backend] ─▶ qa ─▶ report
 *
 * Each step runs a real Mastra agent with structured output, fully scoped to
 * the tenant workspace. Parallel branches use `.parallel(...)`. No in-memory
 * EventEmitter messaging, no `Function` constructor, no mocks.
 */

const inputSchema = z.object({
  tenantId: z.string(),
  userId: z.string().optional(),
  projectName: z.string(),
  brief: z.string(),
});

const planStep = createStep({
  id: 'plan',
  description: 'Project Manager produces a structured delivery plan.',
  inputSchema,
  outputSchema: z.object({
    tenantId: z.string(),
    userId: z.string().optional(),
    projectName: z.string(),
    brief: z.string(),
    plan: projectPlanSchema,
  }),
  execute: async ({ inputData }) => {
    const ws = createWorkspace(inputData.tenantId, inputData.userId);
    const { object: plan } = await ws.runAgent(
      'project-manager',
      `Create a delivery plan for project "${inputData.projectName}".\n\nBrief:\n${inputData.brief}`,
      projectPlanSchema,
      { threadSuffix: `project:${inputData.projectName}` },
    );
    return { ...inputData, plan };
  },
});

const researchStep = createStep({
  id: 'research',
  description: 'Research agent analyzes market, competitors and trends.',
  inputSchema: planStep.outputSchema,
  outputSchema: z.object({ research: researchOutputSchema }),
  execute: async ({ inputData }) => {
    const ws = createWorkspace(inputData.tenantId, inputData.userId);
    const { object: research } = await ws.runAgent(
      'research-analyst',
      `Research the market and competitors for "${inputData.projectName}".\n\nBrief:\n${inputData.brief}`,
      researchOutputSchema,
      { threadSuffix: `project:${inputData.projectName}` },
    );
    return { research };
  },
});

const designStep = createStep({
  id: 'design',
  description: 'Design agent produces a design system and wireframes.',
  inputSchema: planStep.outputSchema,
  outputSchema: z.object({ design: designOutputSchema }),
  execute: async ({ inputData }) => {
    const ws = createWorkspace(inputData.tenantId, inputData.userId);
    const { object: design } = await ws.runAgent(
      'designer',
      `Design the UI/UX for "${inputData.projectName}".\n\nBrief:\n${inputData.brief}\n\nPhases:\n${inputData.plan.phases
        .map((p) => p.name)
        .join(', ')}`,
      designOutputSchema,
      { threadSuffix: `project:${inputData.projectName}` },
    );
    return { design };
  },
});

// Output shape produced by `.parallel([researchStep, designStep])`:
// keyed by each step's id.
const discoverySchema = z.object({
  research: z.object({ research: researchOutputSchema }),
  design: z.object({ design: designOutputSchema }),
});

const frontendStep = createStep({
  id: 'frontend',
  description: 'Frontend agent implements UI components.',
  inputSchema: discoverySchema,
  outputSchema: z.object({ frontend: frontendOutputSchema }),
  execute: async ({ getInitData, getStepResult }) => {
    const init = getInitData() as z.infer<typeof inputSchema>;
    const ws = createWorkspace(init.tenantId, init.userId);
    const design = getStepResult(designStep).design;
    const { object: frontend } = await ws.runAgent(
      'frontend-developer',
      `Implement the frontend for "${init.projectName}".\n\nBrief:\n${init.brief}\n\nDesign system summary:\n${design.summary}`,
      frontendOutputSchema,
      { threadSuffix: `project:${init.projectName}` },
    );
    return { frontend };
  },
});

const backendStep = createStep({
  id: 'backend',
  description: 'Backend agent designs APIs and data models.',
  inputSchema: discoverySchema,
  outputSchema: z.object({ backend: backendOutputSchema }),
  execute: async ({ getInitData }) => {
    const init = getInitData() as z.infer<typeof inputSchema>;
    const ws = createWorkspace(init.tenantId, init.userId);
    const { object: backend } = await ws.runAgent(
      'backend-developer',
      `Design the backend (APIs, data models, auth) for "${init.projectName}".\n\nBrief:\n${init.brief}`,
      backendOutputSchema,
      { threadSuffix: `project:${init.projectName}` },
    );
    return { backend };
  },
});

// Output shape produced by `.parallel([frontendStep, backendStep])`.
const implementationSchema = z.object({
  frontend: z.object({ frontend: frontendOutputSchema }),
  backend: z.object({ backend: backendOutputSchema }),
});

const qaStep = createStep({
  id: 'qa',
  description: 'QA agent reviews the produced implementation and writes tests.',
  inputSchema: implementationSchema,
  outputSchema: z.object({ qa: qaOutputSchema }),
  execute: async ({ getInitData, getStepResult }) => {
    const init = getInitData() as z.infer<typeof inputSchema>;
    const ws = createWorkspace(init.tenantId, init.userId);
    const frontend = getStepResult(frontendStep).frontend;
    const backend = getStepResult(backendStep).backend;
    const fePreview = frontend.components
      .map((c) => `// ${c.path}\n${c.code}`)
      .join('\n\n')
      .slice(0, 6000);
    const bePreview = backend.endpoints
      .map((e) => `${e.method} ${e.path}\n${e.handlerCode}`)
      .join('\n\n')
      .slice(0, 6000);
    const { object: qa } = await ws.runAgent(
      'qa-engineer',
      `Review the implementation for "${init.projectName}" and write tests.\n\nFrontend:\n${fePreview}\n\nBackend:\n${bePreview}`,
      qaOutputSchema,
      { threadSuffix: `project:${init.projectName}` },
    );
    return { qa };
  },
});

const outputSchema = z.object({
  projectName: z.string(),
  plan: projectPlanSchema,
  research: researchOutputSchema,
  design: designOutputSchema,
  frontend: frontendOutputSchema,
  backend: backendOutputSchema,
  qa: qaOutputSchema,
});

const reportStep = createStep({
  id: 'report',
  description: 'Aggregate every artifact into the final delivery report.',
  inputSchema: z.object({ qa: qaOutputSchema }),
  outputSchema,
  execute: async ({ inputData, getInitData, getStepResult }) => {
    const init = getInitData() as z.infer<typeof inputSchema>;
    return {
      projectName: init.projectName,
      plan: getStepResult(planStep).plan,
      research: getStepResult(researchStep).research,
      design: getStepResult(designStep).design,
      frontend: getStepResult(frontendStep).frontend,
      backend: getStepResult(backendStep).backend,
      qa: inputData.qa,
    };
  },
});

export const projectDeliveryWorkflow = createWorkflow({
  id: 'project-delivery',
  description:
    'End-to-end agency delivery: plan → (research ‖ design) → (frontend ‖ backend) → QA → report.',
  inputSchema,
  outputSchema,
})
  .then(planStep)
  .parallel([researchStep, designStep])
  .parallel([frontendStep, backendStep])
  .then(qaStep)
  .then(reportStep)
  .commit();
