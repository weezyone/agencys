/**
 * Safe condition evaluator — SECURITY FIX.
 *
 * The legacy `WorkflowOrchestrator.evaluateCondition()` used
 * `new Function('context', 'return ' + condition)` to evaluate
 * workflow/collaboration rules. That is effectively `eval` and allowed
 * arbitrary code execution from rule strings.
 *
 * This replacement parses a small, safe boolean expression grammar:
 *   <path> <op> <value>   combined with `&&` / `||`
 *   op ∈ ==, !=, >, >=, <, <=
 *   value ∈ number | quoted string | true | false | null
 * `<path>` is a dotted property lookup into the context object only.
 * No function calls, no member assignment, no arbitrary JS.
 */
type Json = unknown;

function getPath(context: Record<string, Json>, path: string): Json {
  return path.split('.').reduce<Json>((acc, key) => {
    if (acc && typeof acc === 'object' && key in (acc as Record<string, Json>)) {
      return (acc as Record<string, Json>)[key];
    }
    return undefined;
  }, context);
}

function parseLiteral(token: string): Json {
  const t = token.trim();
  if (t === 'true') return true;
  if (t === 'false') return false;
  if (t === 'null') return null;
  if (/^-?\d+(\.\d+)?$/.test(t)) return Number(t);
  if (/^"[^"]*"$/.test(t) || /^'[^']*'$/.test(t)) return t.slice(1, -1);
  return undefined;
}

function compare(left: Json, op: string, right: Json): boolean {
  switch (op) {
    case '==':
      return left === right;
    case '!=':
      return left !== right;
    case '>':
      return Number(left) > Number(right);
    case '>=':
      return Number(left) >= Number(right);
    case '<':
      return Number(left) < Number(right);
    case '<=':
      return Number(left) <= Number(right);
    default:
      throw new Error(`Unsupported operator: ${op}`);
  }
}

function evalComparison(expr: string, context: Record<string, Json>): boolean {
  const m = expr.trim().match(/^(.+?)\s*(==|!=|>=|<=|>|<)\s*(.+)$/);
  if (!m) {
    // Bare path => truthiness check.
    return Boolean(getPath(context, expr.trim()));
  }
  const [, pathPart, op, valuePart] = m;
  const left = getPath(context, pathPart.trim());
  const right = parseLiteral(valuePart);
  return compare(left, op, right);
}

export function evaluateCondition(condition: string, context: Record<string, Json>): boolean {
  if (!condition || !condition.trim()) return true;

  // OR has lower precedence than AND.
  return condition.split('||').some((orPart) =>
    orPart.split('&&').every((andPart) => evalComparison(andPart, context)),
  );
}
