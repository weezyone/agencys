import { createWorkflow, createStep } from '@mastra/core/workflows';
import { z } from 'zod';
import { createWorkspace } from '../workspaces/index.js';
import {
  projectPlanSchema,
  researchOutputSchema,
  designOutputSchema,
} from '../agents/schemas.js';

/**
 * Brand Identity Sprint workflow.
 *
 * Graph:
 *   plan ─▶ [research ‖ design] ─▶ report
 *
 * Produces a market-aware brand foundation: a project manager plan, a
 * research-analyst competitive/market read, and a designer-authored design
 * system (palette, typography, wireframes). Ideal for new brands or rebrands.
 */

const inputSchema = z.object({
  tenantId: z.string(),
  userId: z.string().optional(),
  projectName: z.string(),
  brief: z.string(),
});

const planStep = createStep({
  id: 'plan',
  description: 'Project Manager scopes the brand identity engagement.',
  inputSchema,
  outputSchema: z.object({
    tenantId: z.string(),
    userId: z.string().optional(),
    projectName: z.string(),
    brief: z.string(),
    plan: projectPlanSchema,
  }),
  execute: async ({ inputData }) => {
    const ws = createWorkspace(inputData.tenantId, inputData.userId);
    const { object: plan } = await ws.runAgent(
      'project-manager',
      `Scope a brand identity sprint for "${inputData.projectName}".\n\nBrief:\n${inputData.brief}`,
      projectPlanSchema,
      { threadSuffix: `brand:${inputData.projectName}` },
    );
    return { ...inputData, plan };
  },
});

const researchStep = createStep({
  id: 'research',
  description: 'Research analyst studies the market and competitor branding.',
  inputSchema: planStep.outputSchema,
  outputSchema: z.object({ research: researchOutputSchema }),
  execute: async ({ inputData }) => {
    const ws = createWorkspace(inputData.tenantId, inputData.userId);
    const { object: research } = await ws.runAgent(
      'research-analyst',
      `Analyze market positioning, competitor branding and visual trends for "${inputData.projectName}".\n\nBrief:\n${inputData.brief}`,
      researchOutputSchema,
      { threadSuffix: `brand:${inputData.projectName}` },
    );
    return { research };
  },
});

const designStep = createStep({
  id: 'design',
  description: 'Designer produces the brand design system and wireframes.',
  inputSchema: planStep.outputSchema,
  outputSchema: z.object({ design: designOutputSchema }),
  execute: async ({ inputData }) => {
    const ws = createWorkspace(inputData.tenantId, inputData.userId);
    const { object: design } = await ws.runAgent(
      'designer',
      `Create a complete brand design system (logo direction, color palette, typography, spacing, key screens) for "${inputData.projectName}".\n\nBrief:\n${inputData.brief}`,
      designOutputSchema,
      { threadSuffix: `brand:${inputData.projectName}` },
    );
    return { design };
  },
});

const discoverySchema = z.object({
  research: z.object({ research: researchOutputSchema }),
  design: z.object({ design: designOutputSchema }),
});

const outputSchema = z.object({
  projectName: z.string(),
  plan: projectPlanSchema,
  research: researchOutputSchema,
  design: designOutputSchema,
});

const reportStep = createStep({
  id: 'report',
  description: 'Aggregate the brand foundation into a final deliverable.',
  inputSchema: discoverySchema,
  outputSchema,
  execute: async ({ getInitData, getStepResult }) => {
    const init = getInitData() as z.infer<typeof inputSchema>;
    return {
      projectName: init.projectName,
      plan: getStepResult(planStep).plan,
      research: getStepResult(researchStep).research,
      design: getStepResult(designStep).design,
    };
  },
});

export const brandIdentityWorkflow = createWorkflow({
  id: 'brand-identity',
  description:
    'Brand identity sprint: plan → (market research ‖ design system) → brand foundation report.',
  inputSchema,
  outputSchema,
})
  .then(planStep)
  .parallel([researchStep, designStep])
  .then(reportStep)
  .commit();
