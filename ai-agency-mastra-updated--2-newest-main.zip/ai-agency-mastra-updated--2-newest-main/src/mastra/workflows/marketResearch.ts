import { createWorkflow, createStep } from '@mastra/core/workflows';
import { z } from 'zod';
import { createWorkspace } from '../workspaces/index.js';
import { projectPlanSchema, researchOutputSchema } from '../agents/schemas.js';

/**
 * Market Research Report workflow.
 *
 * Graph:
 *   plan ─▶ research ─▶ report
 *
 * A focused intelligence deliverable: the project manager frames the research
 * questions and the research analyst produces a structured market + competitor
 * report with trends, opportunities and recommendations.
 */

const inputSchema = z.object({
  tenantId: z.string(),
  userId: z.string().optional(),
  projectName: z.string(),
  brief: z.string(),
});

const planStep = createStep({
  id: 'plan',
  description: 'Project Manager frames the research questions and scope.',
  inputSchema,
  outputSchema: z.object({
    tenantId: z.string(),
    userId: z.string().optional(),
    projectName: z.string(),
    brief: z.string(),
    plan: projectPlanSchema,
  }),
  execute: async ({ inputData }) => {
    const ws = createWorkspace(inputData.tenantId, inputData.userId);
    const { object: plan } = await ws.runAgent(
      'project-manager',
      `Frame the research scope and key questions for "${inputData.projectName}".\n\nBrief:\n${inputData.brief}`,
      projectPlanSchema,
      { threadSuffix: `research:${inputData.projectName}` },
    );
    return { ...inputData, plan };
  },
});

const researchStep = createStep({
  id: 'research',
  description: 'Research analyst produces the structured market report.',
  inputSchema: planStep.outputSchema,
  outputSchema: z.object({ research: researchOutputSchema }),
  execute: async ({ inputData }) => {
    const ws = createWorkspace(inputData.tenantId, inputData.userId);
    const { object: research } = await ws.runAgent(
      'research-analyst',
      `Produce a comprehensive market and competitor research report for "${inputData.projectName}". Cover market overview, competitors, trends, opportunities and concrete recommendations.\n\nBrief:\n${inputData.brief}\n\nResearch focus:\n${inputData.plan.summary}`,
      researchOutputSchema,
      { threadSuffix: `research:${inputData.projectName}` },
    );
    return { research };
  },
});

const outputSchema = z.object({
  projectName: z.string(),
  plan: projectPlanSchema,
  research: researchOutputSchema,
});

const reportStep = createStep({
  id: 'report',
  description: 'Aggregate the research scope and findings.',
  inputSchema: z.object({ research: researchOutputSchema }),
  outputSchema,
  execute: async ({ inputData, getInitData, getStepResult }) => {
    const init = getInitData() as z.infer<typeof inputSchema>;
    return {
      projectName: init.projectName,
      plan: getStepResult(planStep).plan,
      research: inputData.research,
    };
  },
});

export const marketResearchWorkflow = createWorkflow({
  id: 'market-research',
  description: 'Market research report: plan → research → structured report.',
  inputSchema,
  outputSchema,
})
  .then(planStep)
  .then(researchStep)
  .then(reportStep)
  .commit();
