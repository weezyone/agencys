import { createWorkflow, createStep } from '@mastra/core/workflows';
import { z } from 'zod';
import { createWorkspace } from '../workspaces/index.js';
import {
  projectPlanSchema,
  researchOutputSchema,
  socialOutputSchema,
} from '../agents/schemas.js';

/**
 * Social Campaign workflow.
 *
 * Graph:
 *   plan ─▶ research ─▶ social ─▶ report
 *
 * Research-informed social media campaign: the project manager frames the
 * campaign, the research analyst surfaces audience/trend insight, and the
 * social-media agent produces a multi-platform content calendar with KPIs.
 */

const inputSchema = z.object({
  tenantId: z.string(),
  userId: z.string().optional(),
  projectName: z.string(),
  brief: z.string(),
});

const planStep = createStep({
  id: 'plan',
  description: 'Project Manager frames the campaign objectives and scope.',
  inputSchema,
  outputSchema: z.object({
    tenantId: z.string(),
    userId: z.string().optional(),
    projectName: z.string(),
    brief: z.string(),
    plan: projectPlanSchema,
  }),
  execute: async ({ inputData }) => {
    const ws = createWorkspace(inputData.tenantId, inputData.userId);
    const { object: plan } = await ws.runAgent(
      'project-manager',
      `Frame a social media campaign for "${inputData.projectName}".\n\nBrief:\n${inputData.brief}`,
      projectPlanSchema,
      { threadSuffix: `social:${inputData.projectName}` },
    );
    return { ...inputData, plan };
  },
});

const researchStep = createStep({
  id: 'research',
  description: 'Research analyst surfaces audience, trend and channel insight.',
  inputSchema: planStep.outputSchema,
  outputSchema: z.object({
    tenantId: z.string(),
    userId: z.string().optional(),
    projectName: z.string(),
    brief: z.string(),
    research: researchOutputSchema,
  }),
  execute: async ({ inputData }) => {
    const ws = createWorkspace(inputData.tenantId, inputData.userId);
    const { object: research } = await ws.runAgent(
      'research-analyst',
      `Identify target audiences, content trends and best-fit channels for the "${inputData.projectName}" campaign.\n\nBrief:\n${inputData.brief}`,
      researchOutputSchema,
      { threadSuffix: `social:${inputData.projectName}` },
    );
    return {
      tenantId: inputData.tenantId,
      userId: inputData.userId,
      projectName: inputData.projectName,
      brief: inputData.brief,
      research,
    };
  },
});

const socialStep = createStep({
  id: 'social',
  description: 'Social media agent builds a multi-platform content calendar.',
  inputSchema: researchStep.outputSchema,
  outputSchema: z.object({ social: socialOutputSchema }),
  execute: async ({ inputData }) => {
    const ws = createWorkspace(inputData.tenantId, inputData.userId);
    const { object: social } = await ws.runAgent(
      'social-media',
      `Create a multi-platform social content calendar for "${inputData.projectName}".\n\nBrief:\n${inputData.brief}\n\nAudience & trend insight:\n${inputData.research.summary}\n\nOpportunities:\n${inputData.research.opportunities.join('\n')}`,
      socialOutputSchema,
      { threadSuffix: `social:${inputData.projectName}` },
    );
    return { social };
  },
});

const outputSchema = z.object({
  projectName: z.string(),
  plan: projectPlanSchema,
  research: researchOutputSchema,
  social: socialOutputSchema,
});

const reportStep = createStep({
  id: 'report',
  description: 'Aggregate the campaign plan, insight and calendar.',
  inputSchema: z.object({ social: socialOutputSchema }),
  outputSchema,
  execute: async ({ inputData, getInitData, getStepResult }) => {
    const init = getInitData() as z.infer<typeof inputSchema>;
    return {
      projectName: init.projectName,
      plan: getStepResult(planStep).plan,
      research: getStepResult(researchStep).research,
      social: inputData.social,
    };
  },
});

export const socialCampaignWorkflow = createWorkflow({
  id: 'social-campaign',
  description:
    'Social campaign: plan → audience research → multi-platform content calendar → report.',
  inputSchema,
  outputSchema,
})
  .then(planStep)
  .then(researchStep)
  .then(socialStep)
  .then(reportStep)
  .commit();
