import { EntityType } from '@mastra/core/storage';
import type {
  GetEntityNamesArgs,
  GetTagsArgs,
  ObservabilityStorage,
} from '@mastra/core/storage';

const EMPTY_PAGINATION = {
  total: 0,
  page: 0,
  perPage: 10 as const,
  hasMore: false,
};

/**
 * `@mastra/mongodb` ObservabilityMongoDB persists traces/spans but does not yet
 * implement the newer Studio observability APIs (metrics OLAP, logs, scores,
 * discovery helpers). Those inherited base-class methods throw, which floods the
 * dev server log when Studio opens the observability dashboard.
 *
 * This patch adds no-op / empty responses for the missing APIs while keeping
 * trace persistence on MongoDB. Discovery helpers derive values from stored spans.
 */
export function patchObservabilityStorage(observability: ObservabilityStorage): void {
  const listTraces = observability.listTraces.bind(observability);

  const loadSpanContext = async () => {
    const { spans } = await listTraces({ pagination: { page: 0, perPage: false } });
    return spans;
  };

  Object.assign(observability, {
    batchCreateLogs: async () => undefined,
    listLogs: async () => ({ logs: [], pagination: EMPTY_PAGINATION }),

    batchCreateMetrics: async () => undefined,
    listMetrics: async () => ({ metrics: [], pagination: EMPTY_PAGINATION }),
    getMetricAggregate: async () => ({ value: null }),
    getMetricBreakdown: async () => ({ groups: [] }),
    getMetricTimeSeries: async () => ({ series: [] }),
    getMetricPercentiles: async () => ({ percentiles: [] }),

    getMetricNames: async () => ({ names: [] }),
    getMetricLabelKeys: async () => ({ keys: [] }),
    getMetricLabelValues: async () => ({ values: [] }),

    getEntityTypes: async () => {
      const validTypes = new Set(Object.values(EntityType));
      const entityTypes = new Set<string>();
      for (const span of await loadSpanContext()) {
        if (span.entityType && validTypes.has(span.entityType)) {
          entityTypes.add(span.entityType);
        }
      }
      return { entityTypes: Array.from(entityTypes).sort() };
    },

    getEntityNames: async (args: GetEntityNamesArgs) => {
      const names = new Set<string>();
      for (const span of await loadSpanContext()) {
        if (!span.entityName) continue;
        if (args.entityType && span.entityType !== args.entityType) continue;
        names.add(span.entityName);
      }
      return { names: Array.from(names).sort() };
    },

    getServiceNames: async () => {
      const serviceNames = new Set<string>();
      for (const span of await loadSpanContext()) {
        if (span.serviceName) serviceNames.add(span.serviceName);
      }
      return { serviceNames: Array.from(serviceNames).sort() };
    },

    getEnvironments: async () => {
      const environments = new Set<string>();
      for (const span of await loadSpanContext()) {
        if (span.environment) environments.add(span.environment);
      }
      return { environments: Array.from(environments).sort() };
    },

    getTags: async (args: GetTagsArgs) => {
      const tags = new Set<string>();
      for (const span of await loadSpanContext()) {
        if (!span.tags?.length) continue;
        if (args.entityType && span.entityType !== args.entityType) continue;
        for (const tag of span.tags) tags.add(tag);
      }
      return { tags: Array.from(tags).sort() };
    },

    createScore: async () => undefined,
    batchCreateScores: async () => undefined,
    listScores: async () => ({ scores: [], pagination: EMPTY_PAGINATION }),
    getScoreById: async () => null,
    getScoreAggregate: async () => ({ value: null }),
    getScoreBreakdown: async () => ({ groups: [] }),
    getScoreTimeSeries: async () => ({ series: [] }),
    getScorePercentiles: async () => ({ percentiles: [] }),

    createFeedback: async () => undefined,
    batchCreateFeedback: async () => undefined,
    listFeedback: async () => ({ feedback: [], pagination: EMPTY_PAGINATION }),
    getFeedbackAggregate: async () => ({ value: null }),
    getFeedbackBreakdown: async () => ({ groups: [] }),
    getFeedbackTimeSeries: async () => ({ series: [] }),
    getFeedbackPercentiles: async () => ({ percentiles: [] }),
  });
}
