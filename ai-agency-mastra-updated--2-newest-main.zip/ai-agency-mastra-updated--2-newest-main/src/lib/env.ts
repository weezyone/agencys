import { config as loadDotenv } from 'dotenv';
import { existsSync } from 'fs';
import { resolve } from 'path';

/**
 * Centralized, validated environment configuration.
 *
 * Replaces the per-agent hardcoded `gpt-4o-mini` model strings and the
 * scattered `process.env` reads in the legacy codebase. Fail fast on the
 * few values that are strictly required so we never silently fall back to
 * mock behaviour (one of the security issues flagged in the review).
 */

function loadProjectEnv(): void {
  // Mastra dev runs the bundled server from `.mastra/output`, so walk up to
  // find the project-root `.env` instead of relying on cwd alone.
  const candidates = [
    resolve(process.cwd(), '.env'),
    resolve(process.cwd(), '../.env'),
    resolve(process.cwd(), '../../.env'),
    resolve(process.cwd(), '../../../.env'),
  ];

  for (const path of candidates) {
    if (existsSync(path)) {
      loadDotenv({ path });
      return;
    }
  }

  loadDotenv();
}

loadProjectEnv();

function required(name: string, fallback?: string): string {
  const value = envVar(name, fallback);
  if (value === undefined || value === '') {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
}

/** Read env at call time so Mastra dev child processes see injected vars. */
export function envVar(name: string, fallback = ''): string {
  const value = process.env[name] ?? fallback;
  return typeof value === 'string' ? value.trim() : fallback;
}

function optional(name: string, fallback = ''): string {
  return envVar(name, fallback);
}

type ModelProvider = 'router' | 'vertex';

function modelProvider(): ModelProvider {
  const value = optional('AGENCY_MODEL_PROVIDER', 'router').toLowerCase();
  if (value === 'vertex') return 'vertex';
  return 'router';
}

export const env = {
  // LLM / model router
  openaiApiKey: optional('OPENAI_API_KEY'),
  modelProvider: modelProvider(),
  model: optional('AGENCY_MODEL', 'openai/gpt-5.5'),
  embeddingModel: optional('AGENCY_EMBEDDING_MODEL', 'openai/text-embedding-3-small'),

  // Vertex AI Anthropic (when AGENCY_MODEL_PROVIDER=vertex)
  googleCloudProject: optional(
    'GOOGLE_CLOUD_PROJECT',
    optional('GCP_PROJECT', 'strange-cycle-497112-s7'),
  ),
  googleCloudLocation: optional('GOOGLE_CLOUD_LOCATION', 'global'),
  vertexOpusModel: optional('AGENCY_VERTEX_OPUS_MODEL', 'claude-opus-4-8'),
  vertexFableModel: optional('AGENCY_VERTEX_FABLE_MODEL', 'claude-fable-5'),

  // MongoDB (shared between Mastra storage/vector and Mongoose business data)
  mongoUri: required('MONGODB_URI', 'mongodb+srv://weezy:weezy@cluster0.4so3vbh.mongodb.net/'),
  mongoDbName: optional('MONGODB_DB_NAME', 'ai_agency'),
  mongoVectorDbName: optional('MONGODB_VECTOR_DB_NAME', 'ai_agency_vectors'),

  // HTTP server
  port: parseInt(optional('PORT', '3000'), 10),

  // Security
  encryptionKey: optional('ENCRYPTION_KEY', ''),
  // When true (default) the API requires a valid bearer token / session.
  // This removes the legacy `mock-user-id` auth bypass.
  enforceAuth: optional('ENFORCE_AUTH', 'true') !== 'false',

} as const;

/** Integration credentials — resolved at call time, not module load. */
export function getIntegrations() {
  return {
    jiraBaseUrl: optional('JIRA_BASE_URL'),
    jiraEmail: optional('JIRA_EMAIL'),
    jiraApiToken: optional('JIRA_API_TOKEN'),
    asanaAccessToken: optional('ASANA_ACCESS_TOKEN'),
    slackBotToken: optional('SLACK_BOT_TOKEN'),
    githubToken: optional('GITHUB_TOKEN'),
    vercelToken: optional('VERCEL_TOKEN'),
    netlifyToken: optional('NETLIFY_TOKEN'),
    awsAccessKeyId: optional('AWS_ACCESS_KEY_ID'),
    awsSecretAccessKey: optional('AWS_SECRET_ACCESS_KEY'),
    awsRegion: optional('AWS_REGION', 'us-east-1'),
    azureTenantId: optional('AZURE_TENANT_ID'),
    azureClientId: optional('AZURE_CLIENT_ID'),
    azureClientSecret: optional('AZURE_CLIENT_SECRET'),
    figmaAccessToken: optional('FIGMA_ACCESS_TOKEN'),
    metaAccessToken: optional('META_ACCESS_TOKEN'),
  };
}

export type IntegrationKey = keyof ReturnType<typeof getIntegrations>;
