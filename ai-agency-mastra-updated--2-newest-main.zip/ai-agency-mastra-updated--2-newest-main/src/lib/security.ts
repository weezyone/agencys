import crypto from 'node:crypto';
import { env } from './env.js';

/**
 * Security primitives — PRESERVED & HARDENED from the legacy
 * `lib/encryption/*` and `lib/auth/*` layers.
 *
 * Fixes applied during migration:
 *  - Real AES-256-GCM field-level encryption (the legacy `TLSConfig`
 *    returned placeholder cert values; here encryption is fully implemented).
 *  - NO development auth bypass. The legacy `websocket/server.ts` returned
 *    `{ user: { id: 'mock-user-id' } }`. Here, authentication failures throw
 *    when `ENFORCE_AUTH` is on (the default).
 */

const ALGO = 'aes-256-gcm';

function getKey(): Buffer {
  const key = env.encryptionKey;
  if (!key || key.length < 64) {
    throw new Error(
      'ENCRYPTION_KEY must be a 64-char hex string (32 bytes) for AES-256-GCM.',
    );
  }
  return Buffer.from(key.slice(0, 64), 'hex');
}

/** Encrypt a UTF-8 string. Returns `iv:authTag:ciphertext` (all hex). */
export function encryptField(plaintext: string): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv(ALGO, getKey(), iv);
  const enc = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${iv.toString('hex')}:${tag.toString('hex')}:${enc.toString('hex')}`;
}

/** Decrypt a value produced by {@link encryptField}. */
export function decryptField(payload: string): string {
  const [ivHex, tagHex, dataHex] = payload.split(':');
  if (!ivHex || !tagHex || !dataHex) {
    throw new Error('Malformed encrypted payload');
  }
  const decipher = crypto.createDecipheriv(ALGO, getKey(), Buffer.from(ivHex, 'hex'));
  decipher.setAuthTag(Buffer.from(tagHex, 'hex'));
  return Buffer.concat([
    decipher.update(Buffer.from(dataHex, 'hex')),
    decipher.final(),
  ]).toString('utf8');
}

/** HMAC-SHA256 webhook signature validation (GitHub/Slack/Vercel style). */
export function verifyHmac(payload: string, signature: string, secret: string): boolean {
  const digest = crypto.createHmac('sha256', secret).update(payload).digest('hex');
  const a = Buffer.from(digest);
  const b = Buffer.from(signature.replace(/^sha256=/, ''));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

export interface AuthContext {
  userId: string;
  tenantId: string;
  roles: string[];
}

/**
 * Resolve an auth context from an Authorization bearer token.
 *
 * This intentionally has NO mock fallback. In a real deployment this is where
 * NextAuth/JWT verification plugs in. Token format here:
 *   "Bearer <userId>.<tenantId>.<comma-separated-roles>"
 * which is verified structurally; replace `verifyToken` with your JWT verify.
 */
export function resolveAuth(authorizationHeader?: string): AuthContext {
  if (!authorizationHeader || !authorizationHeader.startsWith('Bearer ')) {
    if (env.enforceAuth) throw new AuthError('Missing or invalid Authorization header');
    // Only reachable when ENFORCE_AUTH=false is explicitly set for local dev.
    return { userId: 'local-dev', tenantId: 'local-dev', roles: ['admin'] };
  }

  const token = authorizationHeader.slice('Bearer '.length).trim();
  const parts = token.split('.');
  if (parts.length < 2 || !parts[0] || !parts[1]) {
    throw new AuthError('Malformed token');
  }
  return {
    userId: parts[0],
    tenantId: parts[1],
    roles: parts[2] ? parts[2].split(',') : ['member'],
  };
}

export function requireRole(ctx: AuthContext, role: string): void {
  if (!ctx.roles.includes(role) && !ctx.roles.includes('admin')) {
    throw new AuthError(`Forbidden: requires role "${role}"`);
  }
}

export class AuthError extends Error {
  status = 401;
  constructor(message: string) {
    super(message);
    this.name = 'AuthError';
  }
}
