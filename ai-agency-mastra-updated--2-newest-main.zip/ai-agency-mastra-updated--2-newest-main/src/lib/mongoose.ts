import mongoose from 'mongoose';
import { env } from './env.js';

/**
 * Mongoose connection — PRESERVED from the legacy `lib/mongodb.ts`.
 *
 * This keeps the existing business-data layer (Tenant, User, Project, Task,
 * audit logs, etc.) working exactly as before. Mastra uses the same MongoDB
 * cluster through its own `MongoDBStore`/`MongoDBVector` adapters, but the
 * Mongoose models remain the source of truth for business records.
 *
 * The cached/global pattern avoids creating a new connection on every
 * serverless invocation / hot reload.
 */
interface ConnectionCache {
  conn: typeof mongoose | null;
  promise: Promise<typeof mongoose> | null;
}

declare global {
  // eslint-disable-next-line no-var
  var __agencyMongoose: ConnectionCache | undefined;
}

const cached: ConnectionCache = global.__agencyMongoose ?? { conn: null, promise: null };
global.__agencyMongoose = cached;

export async function connectToDatabase(): Promise<typeof mongoose> {
  if (cached.conn) return cached.conn;

  if (!cached.promise) {
    cached.promise = mongoose
      .connect(env.mongoUri, {
        dbName: env.mongoDbName,
        bufferCommands: false,
        maxPoolSize: 10,
        serverSelectionTimeoutMS: 8000,
        socketTimeoutMS: 45000,
        family: 4,
      })
      .then((m) => {
        console.log('✅ Mongoose connected to', env.mongoDbName);
        return m;
      });

    cached.promise.catch(() => {
      /* swallowed here; rethrown to awaiter below */
    });
  }

  try {
    cached.conn = await cached.promise;
  } catch (e) {
    cached.promise = null;
    throw e;
  }

  return cached.conn;
}

export default connectToDatabase;
