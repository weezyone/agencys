import { createVertexAnthropic } from '@ai-sdk/google-vertex/anthropic';
import type { MastraModelConfig } from '@mastra/core';
import { env } from './env.js';

/**
 * Resolves the LLM used by each agent.
 *
 * - `router` (default): Mastra model-router strings like `openai/gpt-5.5`.
 * - `vertex`: Google Vertex AI Anthropic publisher models via ADC.
 */
function createVertexProvider() {
  if (!env.googleCloudProject) {
    throw new Error(
      'GOOGLE_CLOUD_PROJECT is required when AGENCY_MODEL_PROVIDER=vertex',
    );
  }

  return createVertexAnthropic({
    project: env.googleCloudProject,
    location: env.googleCloudLocation,
  });
}

let vertexProvider: ReturnType<typeof createVertexAnthropic> | null = null;

function getVertexProvider() {
  vertexProvider ??= createVertexProvider();
  return vertexProvider;
}

export function resolveAgentModel(
  tier: 'opus' | 'fable' | 'default' = 'default',
): MastraModelConfig {
  if (env.modelProvider !== 'vertex') {
    return env.model;
  }

  const vertex = getVertexProvider();
  const modelId =
    tier === 'opus'
      ? env.vertexOpusModel
      : tier === 'fable'
        ? env.vertexFableModel
        : env.vertexFableModel;

  return vertex(modelId);
}

export const agentModels = {
  opus: () => resolveAgentModel('opus'),
  fable: () => resolveAgentModel('fable'),
  default: () => resolveAgentModel('default'),
} as const;
