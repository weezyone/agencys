import mongoose, { Schema, Document, Model } from 'mongoose';
import type {
  AgentType,
  AgentStatus,
  TaskPriority,
  TaskStatus,
  ProjectStatus,
} from '../types/index.js';

/**
 * Mongoose business-data models — PRESERVED from the legacy `lib/models/*`.
 *
 * These keep the multi-tenant design (every document is scoped by `tenantId`
 * with compound indexes) so the existing row-level-security / tenant-isolation
 * approach continues to work. Mastra's own collections (memory threads,
 * workflow state, vectors) live alongside these in the same database but are
 * managed by the Mastra adapters.
 *
 * The `defineModel` helper avoids "OverwriteModelError" on hot reload.
 */
function defineModel<T extends Document>(name: string, schema: Schema): Model<T> {
  return (mongoose.models[name] as Model<T>) || mongoose.model<T>(name, schema);
}

/* ----------------------------- Tenant ----------------------------- */
export interface ITenant extends Document {
  tenantId: string;
  name: string;
  plan: 'free' | 'pro' | 'enterprise';
  limits: { maxProjects: number; maxAgents: number; maxMonthlyRuns: number };
  status: 'active' | 'suspended';
  createdAt: Date;
  updatedAt: Date;
}
const TenantSchema = new Schema<ITenant>(
  {
    tenantId: { type: String, required: true, unique: true, index: true },
    name: { type: String, required: true },
    plan: { type: String, enum: ['free', 'pro', 'enterprise'], default: 'free' },
    limits: {
      maxProjects: { type: Number, default: 10 },
      maxAgents: { type: Number, default: 20 },
      maxMonthlyRuns: { type: Number, default: 1000 },
    },
    status: { type: String, enum: ['active', 'suspended'], default: 'active' },
  },
  { timestamps: true },
);
export const Tenant = defineModel<ITenant>('Tenant', TenantSchema);

/* ------------------------------ User ------------------------------ */
export interface IUser extends Document {
  tenantId: string;
  email: string;
  name: string;
  passwordHash?: string;
  roles: string[];
  mfaEnabled: boolean;
  mfaSecret?: string;
  createdAt: Date;
  updatedAt: Date;
}
const UserSchema = new Schema<IUser>(
  {
    tenantId: { type: String, required: true, index: true },
    email: { type: String, required: true },
    name: { type: String, required: true },
    passwordHash: String,
    roles: { type: [String], default: ['member'] },
    mfaEnabled: { type: Boolean, default: false },
    mfaSecret: String,
  },
  { timestamps: true },
);
UserSchema.index({ tenantId: 1, email: 1 }, { unique: true });
export const User = defineModel<IUser>('User', UserSchema);

/* ----------------------------- Project ---------------------------- */
export interface IProject extends Document {
  tenantId: string;
  name: string;
  description: string;
  status: ProjectStatus;
  ownerId?: string;
  plan?: unknown;
  createdAt: Date;
  updatedAt: Date;
}
const ProjectSchema = new Schema<IProject>(
  {
    tenantId: { type: String, required: true, index: true },
    name: { type: String, required: true },
    description: { type: String, default: '' },
    status: {
      type: String,
      enum: ['planning', 'active', 'on_hold', 'completed', 'archived'],
      default: 'planning',
    },
    ownerId: String,
    plan: Schema.Types.Mixed,
  },
  { timestamps: true },
);
ProjectSchema.index({ tenantId: 1, status: 1 });
export const Project = defineModel<IProject>('Project', ProjectSchema);

/* ------------------------------ Task ------------------------------ */
export interface ITask extends Document {
  tenantId: string;
  projectId: string;
  title: string;
  description: string;
  priority: TaskPriority;
  status: TaskStatus;
  assignedAgent?: AgentType;
  dependencies: string[];
  result?: unknown;
  error?: string;
  createdAt: Date;
  updatedAt: Date;
}
const TaskSchema = new Schema<ITask>(
  {
    tenantId: { type: String, required: true, index: true },
    projectId: { type: String, required: true, index: true },
    title: { type: String, required: true },
    description: { type: String, default: '' },
    priority: {
      type: String,
      enum: ['low', 'medium', 'high', 'critical'],
      default: 'medium',
    },
    status: {
      type: String,
      enum: ['pending', 'in_progress', 'completed', 'failed', 'blocked'],
      default: 'pending',
    },
    assignedAgent: String,
    dependencies: { type: [String], default: [] },
    result: Schema.Types.Mixed,
    error: String,
  },
  { timestamps: true },
);
TaskSchema.index({ tenantId: 1, projectId: 1, status: 1 });
export const Task = defineModel<ITask>('Task', TaskSchema);

/* ---------------------------- AgentRun ---------------------------- */
export interface IAgentRun extends Document {
  tenantId: string;
  projectId?: string;
  agentType: AgentType;
  status: AgentStatus;
  input: string;
  output?: unknown;
  rawText?: string;
  error?: string;
  tokensUsed?: number;
  durationMs?: number;
  createdAt: Date;
  updatedAt: Date;
}
const AgentRunSchema = new Schema<IAgentRun>(
  {
    tenantId: { type: String, required: true, index: true },
    projectId: { type: String, index: true },
    agentType: { type: String, required: true },
    status: { type: String, default: 'idle' },
    input: { type: String, required: true },
    output: Schema.Types.Mixed,
    rawText: String,
    error: String,
    tokensUsed: Number,
    durationMs: Number,
  },
  { timestamps: true },
);
AgentRunSchema.index({ tenantId: 1, agentType: 1, createdAt: -1 });
export const AgentRun = defineModel<IAgentRun>('AgentRun', AgentRunSchema);

/* -------------------------- KnowledgeDoc -------------------------- */
export interface IKnowledgeDoc extends Document {
  tenantId: string;
  title: string;
  source: string;
  content: string;
  tags: string[];
  chunkCount?: number;
  createdAt: Date;
  updatedAt: Date;
}
const KnowledgeDocSchema = new Schema<IKnowledgeDoc>(
  {
    tenantId: { type: String, required: true, index: true },
    title: { type: String, required: true },
    source: { type: String, default: 'manual' },
    content: { type: String, required: true },
    tags: { type: [String], default: [] },
    chunkCount: Number,
  },
  { timestamps: true },
);
export const KnowledgeDoc = defineModel<IKnowledgeDoc>('KnowledgeDoc', KnowledgeDocSchema);

/* ----------------------------- AuditLog --------------------------- */
export interface IAuditLog extends Document {
  tenantId: string;
  userId?: string;
  action: string;
  resource: string;
  metadata?: Record<string, unknown>;
  createdAt: Date;
}
const AuditLogSchema = new Schema<IAuditLog>(
  {
    tenantId: { type: String, required: true, index: true },
    userId: String,
    action: { type: String, required: true },
    resource: { type: String, required: true },
    metadata: Schema.Types.Mixed,
  },
  { timestamps: { createdAt: true, updatedAt: false } },
);
AuditLogSchema.index({ tenantId: 1, createdAt: -1 });
export const AuditLog = defineModel<IAuditLog>('AuditLog', AuditLogSchema);

export async function writeAudit(entry: {
  tenantId: string;
  userId?: string;
  action: string;
  resource: string;
  metadata?: Record<string, unknown>;
}): Promise<void> {
  try {
    await AuditLog.create(entry);
  } catch {
    /* never let audit failure break the request */
  }
}
