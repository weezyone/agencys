/**
 * Shared domain types — reconstructs the missing `@/types/agent`,
 * `@/types/tenant`, and `@/types/agencyos` modules that were referenced by the
 * legacy code but never included in the uploads.
 */

export type AgentType =
  | 'project-manager'
  | 'frontend'
  | 'backend'
  | 'qa'
  | 'designer'
  | 'research'
  | 'social'
  | 'coordinator';

export type AgentStatus =
  | 'idle'
  | 'active'
  | 'processing'
  | 'error'
  | 'offline'
  | 'ready'
  | 'working'
  | 'initializing';

export type TaskPriority = 'low' | 'medium' | 'high' | 'critical';
export type TaskStatus = 'pending' | 'in_progress' | 'completed' | 'failed' | 'blocked';

export type ProjectStatus = 'planning' | 'active' | 'on_hold' | 'completed' | 'archived';

export interface TenantContext {
  tenantId: string;
  userId?: string;
  roles?: string[];
  projectId?: string;
}

export interface AgentRunResult<T = unknown> {
  agent: AgentType;
  ok: boolean;
  output?: T;
  rawText?: string;
  tokensUsed?: number;
  error?: string;
  startedAt: string;
  finishedAt: string;
}
