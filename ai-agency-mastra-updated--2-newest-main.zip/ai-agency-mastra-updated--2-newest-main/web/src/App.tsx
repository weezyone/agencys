import { useCallback, useEffect, useMemo, useState, type CSSProperties } from 'react';
import {
  buildToken,
  fetchAgents,
  fetchHealth,
  ingestKnowledge,
  runAgent,
  runProjectDelivery,
  type AgentInfo,
  type AuthConfig,
} from './api';
import { AGENT_ACCENTS, AGENT_SHORT, PROMPT_SUGGESTIONS } from './agentMeta';
import { OutputPanel } from './components/OutputPanel';

type Tab = 'agents' | 'workflow' | 'knowledge' | 'settings';

const AUTH_KEY = 'agency-auth';

function loadAuth(): AuthConfig {
  try {
    const raw = localStorage.getItem(AUTH_KEY);
    if (raw) return JSON.parse(raw) as AuthConfig;
  } catch {
    /* ignore */
  }
  return { userId: 'agency-user', tenantId: 'demo-agency', roles: 'admin' };
}

export default function App() {
  const [tab, setTab] = useState<Tab>('agents');
  const [auth, setAuth] = useState<AuthConfig>(loadAuth);
  const [agents, setAgents] = useState<AgentInfo[]>([]);
  const [selectedAgent, setSelectedAgent] = useState<string>('project-manager');
  const [prompt, setPrompt] = useState('');
  const [projectId, setProjectId] = useState('');
  const [output, setOutput] = useState<unknown>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [health, setHealth] = useState('');
  const [apiOnline, setApiOnline] = useState(false);

  const [wfName, setWfName] = useState('');
  const [wfBrief, setWfBrief] = useState('');
  const [wfResult, setWfResult] = useState<unknown>(null);

  const [kbTitle, setKbTitle] = useState('');
  const [kbContent, setKbContent] = useState('');
  const [kbTags, setKbTags] = useState('');
  const [kbResult, setKbResult] = useState('');

  const token = useMemo(() => buildToken(auth), [auth]);

  const refresh = useCallback(async () => {
    setError('');
    try {
      const h = await fetchHealth();
      setHealth(`${h.modelProvider} · ${h.model}`);
      setApiOnline(true);
      const { agents: list } = await fetchAgents(token);
      setAgents(list);
      if (!list.find((a) => a.id === selectedAgent) && list[0]) {
        setSelectedAgent(list[0].id);
      }
    } catch (e) {
      setApiOnline(false);
      setHealth('API offline');
      setError(e instanceof Error ? e.message : 'Failed to connect to API');
      setAgents([]);
    }
  }, [token, selectedAgent]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  async function handleRunAgent() {
    if (!prompt.trim()) return;
    setLoading(true);
    setError('');
    setOutput(null);
    try {
      const res = await runAgent(token, selectedAgent, prompt, projectId || undefined);
      setOutput(res.output);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Agent run failed');
    } finally {
      setLoading(false);
    }
  }

  async function handleWorkflow() {
    if (!wfName.trim() || !wfBrief.trim()) return;
    setLoading(true);
    setError('');
    setWfResult(null);
    try {
      const res = await runProjectDelivery(token, wfName, wfBrief);
      setWfResult(res);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Workflow failed');
    } finally {
      setLoading(false);
    }
  }

  async function handleKnowledge() {
    if (!kbTitle.trim() || !kbContent.trim()) return;
    setLoading(true);
    setError('');
    setKbResult('');
    try {
      const tags = kbTags
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean);
      const res = await ingestKnowledge(token, {
        title: kbTitle,
        content: kbContent,
        source: 'dashboard',
        tags,
      });
      setKbResult(`Ingested ${res.chunks} chunks (id: ${res.id})`);
      setKbTitle('');
      setKbContent('');
      setKbTags('');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Ingest failed');
    } finally {
      setLoading(false);
    }
  }

  function saveAuth(next: AuthConfig) {
    setAuth(next);
    localStorage.setItem(AUTH_KEY, JSON.stringify(next));
  }

  const currentAgent = agents.find((a) => a.id === selectedAgent);
  const suggestions = PROMPT_SUGGESTIONS[selectedAgent] ?? [];

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <span className="brand-mark">◆</span>
          <div>
            <h1>Agency Command</h1>
            <p>Multi-agent studio</p>
          </div>
        </div>

        <nav className="nav">
          {(
            [
              ['agents', 'Agents'],
              ['workflow', 'Full Delivery'],
              ['knowledge', 'Knowledge Base'],
              ['settings', 'Settings'],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              className={tab === id ? 'nav-btn active' : 'nav-btn'}
              onClick={() => setTab(id)}
            >
              {label}
            </button>
          ))}
        </nav>

        {tab === 'agents' && (
          <div className="agent-list">
            <p className="section-label">Specialists</p>
            {agents.map((agent) => (
              <button
                key={agent.id}
                type="button"
                className={selectedAgent === agent.id ? 'agent-chip active' : 'agent-chip'}
                style={{ '--accent': AGENT_ACCENTS[agent.id] ?? '#888' } as CSSProperties}
                onClick={() => {
                  setSelectedAgent(agent.id);
                  setOutput(null);
                  setError('');
                }}
              >
                <span className="agent-badge">{AGENT_SHORT[agent.id] ?? '?'}</span>
                <span>{agent.name.replace(' Agent', '')}</span>
              </button>
            ))}
          </div>
        )}

        <footer className="sidebar-foot">
          <span className={apiOnline ? 'status ok' : 'status'}>
            {apiOnline ? health : health || 'API offline — run npm run dev:api'}
          </span>
        </footer>
      </aside>

      <main className="main">
        {error && (
          <div className="banner error" role="alert">
            {error}
            <button type="button" onClick={() => void refresh()}>
              Retry
            </button>
          </div>
        )}

        {tab === 'agents' && (
          <section className="panel">
            <header className="panel-head">
              <div>
                <h2>{currentAgent?.name ?? 'Agent'}</h2>
                <p>{currentAgent?.description}</p>
              </div>
              <input
                className="project-input"
                placeholder="Project ID (optional)"
                value={projectId}
                onChange={(e) => setProjectId(e.target.value)}
              />
            </header>

            <div className="suggestions">
              {suggestions.map((s) => (
                <button key={s} type="button" className="suggestion" onClick={() => setPrompt(s)}>
                  {s}
                </button>
              ))}
            </div>

            <div className="composer">
              <textarea
                rows={5}
                placeholder="Describe the task for this specialist…"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
              />
              <button
                type="button"
                className="primary"
                disabled={loading || !prompt.trim()}
                onClick={() => void handleRunAgent()}
              >
                {loading ? 'Running…' : 'Run Agent'}
              </button>
            </div>

            {output != null && (
              <div className="result">
                <h3>Structured Output</h3>
                <OutputPanel agentId={selectedAgent} output={output} />
              </div>
            )}
          </section>
        )}

        {tab === 'workflow' && (
          <section className="panel">
            <header className="panel-head">
              <div>
                <h2>Project Delivery Workflow</h2>
                <p>
                  Orchestrates PM → design → dev → QA across your agency agents for a full client
                  engagement.
                </p>
              </div>
            </header>
            <div className="form-stack">
              <label>
                Project name
                <input value={wfName} onChange={(e) => setWfName(e.target.value)} placeholder="Acme Rebrand Q3" />
              </label>
              <label>
                Client brief
                <textarea
                  rows={8}
                  value={wfBrief}
                  onChange={(e) => setWfBrief(e.target.value)}
                  placeholder="Goals, audience, timeline, deliverables…"
                />
              </label>
              <button
                type="button"
                className="primary"
                disabled={loading || !wfName.trim() || !wfBrief.trim()}
                onClick={() => void handleWorkflow()}
              >
                {loading ? 'Orchestrating…' : 'Start Delivery Workflow'}
              </button>
            </div>
            {wfResult != null && (
              <pre className="json-fallback">{JSON.stringify(wfResult, null, 2)}</pre>
            )}
          </section>
        )}

        {tab === 'knowledge' && (
          <section className="panel">
            <header className="panel-head">
              <div>
                <h2>Knowledge Base</h2>
                <p>
                  Ingest client briefs, brand guidelines, and past deliverables. Agents search this
                  via RAG before responding.
                </p>
              </div>
            </header>
            <div className="form-stack">
              <label>
                Title
                <input value={kbTitle} onChange={(e) => setKbTitle(e.target.value)} placeholder="Brand guidelines — Acme" />
              </label>
              <label>
                Tags (comma-separated)
                <input value={kbTags} onChange={(e) => setKbTags(e.target.value)} placeholder="brand, acme, 2026" />
              </label>
              <label>
                Content
                <textarea
                  rows={12}
                  value={kbContent}
                  onChange={(e) => setKbContent(e.target.value)}
                  placeholder="Paste brief, SOW, or reference doc…"
                />
              </label>
              <button
                type="button"
                className="primary"
                disabled={loading || !kbTitle.trim() || !kbContent.trim()}
                onClick={() => void handleKnowledge()}
              >
                {loading ? 'Ingesting…' : 'Add to Knowledge Base'}
              </button>
              {kbResult && <p className="success-msg">{kbResult}</p>}
            </div>
          </section>
        )}

        {tab === 'settings' && (
          <section className="panel">
            <header className="panel-head">
              <div>
                <h2>Workspace Settings</h2>
                <p>
                  API auth uses bearer tokens: <code>userId.tenantId.roles</code>. Scoped per tenant
                  for isolation.
                </p>
              </div>
            </header>
            <div className="form-stack">
              <label>
                User ID
                <input
                  value={auth.userId}
                  onChange={(e) => saveAuth({ ...auth, userId: e.target.value })}
                />
              </label>
              <label>
                Tenant ID
                <input
                  value={auth.tenantId}
                  onChange={(e) => saveAuth({ ...auth, tenantId: e.target.value })}
                />
              </label>
              <label>
                Roles (comma-separated)
                <input
                  value={auth.roles}
                  onChange={(e) => saveAuth({ ...auth, roles: e.target.value })}
                />
              </label>
              <p className="hint">
                Token preview: <code>{token.slice(0, 24)}…</code>
              </p>
              <button type="button" className="secondary" onClick={() => void refresh()}>
                Reconnect to API
              </button>
            </div>
          </section>
        )}
      </main>
    </div>
  );
}
