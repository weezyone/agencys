const API_BASE = import.meta.env.VITE_API_URL ?? '';

export type AgentInfo = {
  id: string;
  name: string;
  description: string;
};

export type AuthConfig = {
  userId: string;
  tenantId: string;
  roles: string;
};

export function buildToken(auth: AuthConfig): string {
  const roles = auth.roles.trim() || 'admin';
  return `${auth.userId.trim()}.${auth.tenantId.trim()}.${roles}`;
}

function headers(token: string): HeadersInit {
  return {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${token}`,
  };
}

async function parseJson<T>(res: Response): Promise<T> {
  const text = await res.text();
  const contentType = res.headers.get('content-type') ?? '';

  if (
    text.trimStart().startsWith('<') ||
    (!contentType.includes('json') && text.trimStart().startsWith('<!'))
  ) {
    throw new Error(
      `API returned HTML instead of JSON (status ${res.status}). ` +
        'Start the Agency API with `npm run dev:api` — it must not share port 3000 with Mastra Studio.',
    );
  }

  let data: unknown;
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    throw new Error(`Invalid JSON from API (status ${res.status}): ${text.slice(0, 120)}`);
  }

  if (!res.ok) {
    throw new Error((data as { error?: string }).error ?? `Request failed (${res.status})`);
  }
  return data as T;
}

export async function fetchHealth() {
  return parseJson<{ ok: boolean; model: string; modelProvider: string }>(
    await fetch(`${API_BASE}/health`),
  );
}

export async function fetchAgents(token: string) {
  return parseJson<{ agents: AgentInfo[] }>(
    await fetch(`${API_BASE}/agents`, { headers: headers(token) }),
  );
}

export async function runAgent(
  token: string,
  agentKey: string,
  prompt: string,
  projectId?: string,
) {
  return parseJson<{ ok: boolean; output: unknown }>(
    await fetch(`${API_BASE}/agents/${agentKey}/run`, {
      method: 'POST',
      headers: headers(token),
      body: JSON.stringify({ prompt, projectId }),
    }),
  );
}

export async function runProjectDelivery(
  token: string,
  projectName: string,
  brief: string,
) {
  return parseJson<{ ok: boolean; status: string; result: unknown }>(
    await fetch(`${API_BASE}/workflows/project-delivery`, {
      method: 'POST',
      headers: headers(token),
      body: JSON.stringify({ projectName, brief }),
    }),
  );
}

export async function ingestKnowledge(
  token: string,
  payload: { title: string; content: string; source?: string; tags?: string[] },
) {
  return parseJson<{ ok: boolean; id: string; chunks: number }>(
    await fetch(`${API_BASE}/knowledge`, {
      method: 'POST',
      headers: headers(token),
      body: JSON.stringify(payload),
    }),
  );
}
