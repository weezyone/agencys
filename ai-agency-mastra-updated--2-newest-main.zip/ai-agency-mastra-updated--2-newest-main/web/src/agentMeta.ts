export const AGENT_ACCENTS: Record<string, string> = {
  'project-manager': '#e8a838',
  'frontend-developer': '#3dd6c3',
  'backend-developer': '#6b8cff',
  'qa-engineer': '#f07178',
  designer: '#c792ea',
  'research-analyst': '#82aaff',
  'social-media': '#ff9e64',
};

export const AGENT_SHORT: Record<string, string> = {
  'project-manager': 'PM',
  'frontend-developer': 'FE',
  'backend-developer': 'BE',
  'qa-engineer': 'QA',
  designer: 'UX',
  'research-analyst': 'RS',
  'social-media': 'SM',
};

export const PROMPT_SUGGESTIONS: Record<string, string[]> = {
  'project-manager': [
    'Plan a 6-week SaaS landing page project with phased delivery.',
    'Break down a client rebrand into tasks and assign specialist agents.',
  ],
  'frontend-developer': [
    'Build a responsive pricing section in React + TypeScript.',
    'Create an accessible dashboard shell with sidebar navigation.',
  ],
  'backend-developer': [
    'Design REST APIs for a multi-tenant project management app.',
    'Propose auth, pagination, and error handling for a Node API.',
  ],
  'qa-engineer': [
    'Review this component for accessibility and edge cases.',
    'Write integration tests for the signup flow.',
  ],
  designer: [
    'Create a design system for a fintech startup — colors, type, spacing.',
    'Wireframe a 3-screen onboarding flow for a mobile app.',
  ],
  'research-analyst': [
    'Analyze competitors in the AI agency tools market.',
    'Summarize trends in B2B SaaS pricing for 2026.',
  ],
  'social-media': [
    'Create a 5-post LinkedIn launch campaign for a new product.',
    'Draft a 2-week content calendar for a design agency.',
  ],
};
