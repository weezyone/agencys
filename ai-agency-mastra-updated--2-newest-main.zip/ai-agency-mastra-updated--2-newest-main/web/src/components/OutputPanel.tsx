type OutputPanelProps = {
  agentId: string;
  output: unknown;
};

function ProjectPlanView({ output }: { output: Record<string, unknown> }) {
  const phases = (output.phases as { name: string; tasks: string[]; estimatedDays: number }[]) ?? [];
  const risks = (output.risks as { description: string; severity: string; mitigation: string }[]) ?? [];

  return (
    <div className="structured-output">
      <header className="output-hero">
        <h3>{String(output.name ?? 'Project Plan')}</h3>
        <p>{String(output.summary ?? '')}</p>
        {output.estimatedDurationDays != null && (
          <span className="pill">{String(output.estimatedDurationDays)} days estimated</span>
        )}
      </header>
      <section>
        <h4>Phases</h4>
        <div className="phase-grid">
          {phases.map((phase) => (
            <article key={phase.name} className="phase-card">
              <div className="phase-head">
                <strong>{phase.name}</strong>
                <span>{phase.estimatedDays}d</span>
              </div>
              <ul>
                {phase.tasks.map((task) => (
                  <li key={task}>{task}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </section>
      {risks.length > 0 && (
        <section>
          <h4>Risks</h4>
          <div className="risk-list">
            {risks.map((risk) => (
              <div key={risk.description} className={`risk-card severity-${risk.severity}`}>
                <strong>{risk.severity}</strong>
                <p>{risk.description}</p>
                <small>Mitigation: {risk.mitigation}</small>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

function CodeOutputView({ output }: { output: Record<string, unknown> }) {
  const components = (output.components as { name: string; path: string; code: string }[]) ?? [];
  const endpoints = (output.endpoints as { method: string; path: string; description: string }[]) ?? [];
  const posts = (output.posts as { platform: string; content: string }[]) ?? [];

  if (components.length > 0) {
    return (
      <div className="structured-output">
        <p className="output-summary">{String(output.summary ?? '')}</p>
        {components.map((c) => (
          <details key={c.path} className="code-block" open>
            <summary>
              {c.name} — <code>{c.path}</code>
            </summary>
            <pre>{c.code}</pre>
          </details>
        ))}
      </div>
    );
  }

  if (endpoints.length > 0) {
    return (
      <div className="structured-output">
        <p className="output-summary">{String(output.summary ?? '')}</p>
        {endpoints.map((ep) => (
          <div key={`${ep.method}-${ep.path}`} className="endpoint-row">
            <span className="method">{ep.method}</span>
            <code>{ep.path}</code>
            <span>{ep.description}</span>
          </div>
        ))}
      </div>
    );
  }

  if (posts.length > 0) {
    return (
      <div className="structured-output">
        {posts.map((post, i) => (
          <article key={i} className="post-card">
            <span className="pill">{post.platform}</span>
            <p>{post.content}</p>
          </article>
        ))}
      </div>
    );
  }

  return <pre className="json-fallback">{JSON.stringify(output, null, 2)}</pre>;
}

export function OutputPanel({ agentId, output }: OutputPanelProps) {
  if (!output || typeof output !== 'object') {
    return <pre className="json-fallback">{JSON.stringify(output, null, 2)}</pre>;
  }

  const data = output as Record<string, unknown>;

  if (agentId === 'project-manager' && Array.isArray(data.phases)) {
    return <ProjectPlanView output={data} />;
  }

  if (
    Array.isArray(data.components) ||
    Array.isArray(data.endpoints) ||
    Array.isArray(data.posts)
  ) {
    return <CodeOutputView output={data} />;
  }

  return <pre className="json-fallback">{JSON.stringify(output, null, 2)}</pre>;
}
