import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import { resolve } from 'path';

export default defineConfig(({ mode }) => {
  const rootEnv = loadEnv(mode, resolve(__dirname, '..'), '');
  const apiPort = rootEnv.PORT || '3001';
  const target = `http://localhost:${apiPort}`;

  return {
    plugins: [react()],
    server: {
      port: 5173,
      proxy: {
        '/health': target,
        '/agents': target,
        '/workflows': target,
        '/knowledge': target,
      },
    },
  };
});
