import assert from "node:assert/strict";
import test from "node:test";
import {
  SESSION_TTL_MS,
  signSessionToken,
  verifySessionToken,
} from "../src/lib/auth/session";

const SECRET = "correct-horse-battery-staple";

test("a signed token round-trips back to its payload", async () => {
  const token = await signSessionToken({ sub: "paul" }, SECRET);
  const payload = await verifySessionToken(token, SECRET);

  assert.equal(payload?.sub, "paul");
});

test("a token signed with a different secret is rejected", async () => {
  const token = await signSessionToken({ sub: "paul" }, SECRET);

  assert.equal(await verifySessionToken(token, "some-other-secret"), null);
});

test("a tampered payload is rejected", async () => {
  const token = await signSessionToken({ sub: "paul" }, SECRET);
  const [, signature] = token.split(".");
  const forged = Buffer.from(
    JSON.stringify({ sub: "attacker", exp: Date.now() + SESSION_TTL_MS }),
  ).toString("base64url");

  assert.equal(await verifySessionToken(`${forged}.${signature}`, SECRET), null);
});

test("an expired token is rejected", async () => {
  const token = await signSessionToken({ sub: "paul" }, SECRET);
  const wellPastExpiry = Date.now() + SESSION_TTL_MS + 1_000;

  assert.equal(await verifySessionToken(token, SECRET, wellPastExpiry), null);
});

test("malformed tokens are rejected without throwing", async () => {
  for (const candidate of ["", ".", "not-a-token", "a.b.c", "%%%.%%%"]) {
    assert.equal(await verifySessionToken(candidate, SECRET), null);
  }
});

test("an empty secret never verifies, so a misconfigured deploy fails closed", async () => {
  const token = await signSessionToken({ sub: "paul" }, SECRET);

  assert.equal(await verifySessionToken(token, ""), null);
});
