import assert from "node:assert/strict";
import test from "node:test";
import { hasValidMilestoneAssignments } from "../src/lib/workflows/project-plan";

test("tasks pointing at real milestones are accepted", () => {
  assert.equal(hasValidMilestoneAssignments(2, [0, 1, 0]), true);
});

test("a task pointing past the end of the milestone list is rejected", () => {
  assert.equal(hasValidMilestoneAssignments(2, [0, 2]), false);
});

test("a negative milestone index is rejected", () => {
  assert.equal(hasValidMilestoneAssignments(2, [-1, 0]), false);
});

test("a fractional milestone index is rejected", () => {
  assert.equal(hasValidMilestoneAssignments(2, [0.5]), false);
});

test("a plan with no milestones is rejected even when no task references one", () => {
  assert.equal(hasValidMilestoneAssignments(0, []), false);
});
