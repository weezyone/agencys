import assert from "node:assert/strict";
import test from "node:test";
import { isMutatingMethod, isCrossSiteRequest } from "../src/lib/auth/origin";

function request(
  method: string,
  headers: Record<string, string> = {},
): Request {
  return new Request("http://agency.example.com/api/approvals/abc", {
    method,
    headers,
    ...(method === "GET" || method === "HEAD" ? {} : { body: "{}" }),
  });
}

test("read-only methods are not treated as mutating", () => {
  assert.equal(isMutatingMethod("GET"), false);
  assert.equal(isMutatingMethod("HEAD"), false);
  assert.equal(isMutatingMethod("OPTIONS"), false);
});

test("state-changing methods are treated as mutating", () => {
  assert.equal(isMutatingMethod("POST"), true);
  assert.equal(isMutatingMethod("PATCH"), true);
  assert.equal(isMutatingMethod("put"), true);
  assert.equal(isMutatingMethod("DELETE"), true);
});

test("a same-origin post is allowed", () => {
  const req = request("POST", {
    origin: "http://agency.example.com",
    host: "agency.example.com",
  });

  assert.equal(isCrossSiteRequest(req), false);
});

test("a post from another site is rejected", () => {
  const req = request("POST", {
    origin: "https://evil.example.com",
    host: "agency.example.com",
  });

  assert.equal(isCrossSiteRequest(req), true);
});

test("a matching host on a different scheme is still same-site", () => {
  const req = request("POST", {
    origin: "https://agency.example.com",
    host: "agency.example.com",
  });

  assert.equal(isCrossSiteRequest(req), false);
});

test("a request with no origin header is not treated as cross-site", () => {
  const req = request("POST", { host: "agency.example.com" });

  assert.equal(isCrossSiteRequest(req), false);
});

test("a malformed origin header is treated as cross-site", () => {
  const req = request("POST", {
    origin: "not a url",
    host: "agency.example.com",
  });

  assert.equal(isCrossSiteRequest(req), true);
});

test("the forwarded host is preferred when a proxy sets it", () => {
  const req = request("POST", {
    origin: "https://agency.example.com",
    host: "internal-lb:3000",
    "x-forwarded-host": "agency.example.com",
  });

  assert.equal(isCrossSiteRequest(req), false);
});
