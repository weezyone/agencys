import assert from "node:assert/strict";
import test from "node:test";
import { createElement } from "react";
import {
  ProjectDeliveryPlan,
  type ProjectDeliveryPlanProps,
  type TaskViewModel,
} from "../src/components/project-delivery-plan";
import { renderWithRouter } from "./helpers/render";

function render(props: ProjectDeliveryPlanProps): string {
  return renderWithRouter(createElement(ProjectDeliveryPlan, props));
}

const FOUNDATION: ProjectDeliveryPlanProps["milestones"][number] = {
  id: "foundation",
  title: "Foundation",
  order: 0,
  status: "in_progress",
};

const LAUNCH: ProjectDeliveryPlanProps["milestones"][number] = {
  id: "launch",
  title: "Launch",
  order: 1,
  status: "todo",
};

const CONFIRM_REQUIREMENTS: TaskViewModel = {
  id: "task-1",
  milestoneId: "foundation",
  title: "Confirm requirements",
  ownerAgentId: "strategist-agent",
  priority: "high",
  status: "in_progress",
  acceptanceCriteria: ["Requirements are approved"],
  executionStatus: "idle",
  canRun: true,
};

test("milestones render in order regardless of input order", () => {
  const html = render({ milestones: [LAUNCH, FOUNDATION], tasks: [] });

  assert.ok(html.indexOf("Foundation") < html.indexOf("Launch"));
});

test("a task renders under its milestone with an editable status control", () => {
  const html = render({
    milestones: [FOUNDATION],
    tasks: [CONFIRM_REQUIREMENTS],
  });

  assert.match(html, /Confirm requirements/);
  assert.match(html, /<select/);
  assert.match(html, /Requirements are approved/);
  assert.match(html, /strategist-agent/);
});

test("a runnable task shows a run control", () => {
  const html = render({
    milestones: [FOUNDATION],
    tasks: [CONFIRM_REQUIREMENTS],
  });

  assert.match(html, /Run with strategist-agent/);
});

test("a succeeded task renders its artifact inline and offers a retry", () => {
  const html = render({
    milestones: [FOUNDATION],
    tasks: [
      {
        ...CONFIRM_REQUIREMENTS,
        executionStatus: "succeeded",
        canRun: true,
        artifact: {
          id: "art-1",
          title: "Requirements brief",
          kind: "document",
          content: "Signed-off requirements.",
          summary: "Discovery notes",
        },
      },
    ],
  });

  assert.match(html, /Artifact: Requirements brief/);
  assert.match(html, /Signed-off requirements/);
  assert.match(html, /Discovery notes/);
  assert.match(html, /Retry with strategist-agent/);
});

test("a failed task shows the error and a retry control", () => {
  const html = render({
    milestones: [FOUNDATION],
    tasks: [
      {
        ...CONFIRM_REQUIREMENTS,
        executionStatus: "failed",
        executionError: "upstream API refused the connection",
        canRun: true,
      },
    ],
  });

  assert.match(html, /upstream API refused the connection/);
  assert.match(html, /Retry with strategist-agent/);
});

test("a queued task tells the operator the worker will pick it up", () => {
  const html = render({
    milestones: [FOUNDATION],
    tasks: [
      {
        ...CONFIRM_REQUIREMENTS,
        executionStatus: "queued",
        canRun: false,
      },
    ],
  });

  assert.match(html, /Queued for the worker/);
});

test("a task whose milestone is missing is surfaced as unscheduled rather than dropped", () => {
  const html = render({
    milestones: [FOUNDATION],
    tasks: [{ ...CONFIRM_REQUIREMENTS, id: "orphan", milestoneId: "deleted-milestone" }],
  });

  assert.match(html, /Unscheduled tasks/);
});

test("a task with no milestone at all is surfaced as unscheduled", () => {
  const html = render({
    milestones: [FOUNDATION],
    tasks: [{ ...CONFIRM_REQUIREMENTS, id: "orphan", milestoneId: undefined }],
  });

  assert.match(html, /Unscheduled tasks/);
});

test("a milestone with no tasks says so instead of rendering an empty block", () => {
  const html = render({ milestones: [FOUNDATION], tasks: [] });

  assert.match(html, /No tasks assigned to this milestone/);
});

test("a project with no milestones shows an empty state", () => {
  const html = render({ milestones: [], tasks: [] });

  assert.match(html, /No milestones have been generated yet/);
});

test("duplicate acceptance criteria do not collide into one entry", () => {
  const html = render({
    milestones: [FOUNDATION],
    tasks: [
      {
        ...CONFIRM_REQUIREMENTS,
        acceptanceCriteria: ["Signed off", "Signed off"],
      },
    ],
  });

  assert.equal(html.split("Signed off").length - 1, 2);
});
