import assert from "node:assert/strict";
import test from "node:test";
import {
  APPROVAL_DECISIONS,
  canTransition,
  sourceStatusesFor,
} from "../src/lib/approvals/status";

test("a pending approval can be approved or rejected", () => {
  assert.equal(canTransition("pending", "approved"), true);
  assert.equal(canTransition("pending", "rejected"), true);
});

test("an approved approval can still be revoked before it executes", () => {
  assert.equal(canTransition("approved", "rejected"), true);
});

test("re-approving an already approved approval is a no-op, not a transition", () => {
  assert.equal(canTransition("approved", "approved"), false);
});

test("a failed approval can be retried by approving it again", () => {
  assert.equal(canTransition("failed", "approved"), true);
  assert.equal(canTransition("failed", "rejected"), true);
});

test("an in-flight execution cannot be approved or rejected underneath itself", () => {
  assert.equal(canTransition("executing", "approved"), false);
  assert.equal(canTransition("executing", "rejected"), false);
});

test("terminal states cannot be changed", () => {
  assert.equal(canTransition("executed", "approved"), false);
  assert.equal(canTransition("executed", "rejected"), false);
  assert.equal(canTransition("rejected", "approved"), false);
  assert.equal(canTransition("rejected", "rejected"), false);
});

test("source statuses drive a conditional update that matches canTransition", () => {
  for (const decision of APPROVAL_DECISIONS) {
    const sources = sourceStatusesFor(decision);
    for (const source of sources) {
      assert.equal(
        canTransition(source, decision),
        true,
        `${source} -> ${decision} should be allowed`,
      );
    }
  }
});
