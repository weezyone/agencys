import assert from "node:assert/strict";
import test from "node:test";
import {
  createApprovalExecutor,
  type AgentRunEntry,
  type ApprovalClaim,
  type ApprovalExecutionStore,
  type ApprovalRecord,
} from "../src/lib/approvals/execute";

const APPROVAL_ID = "507f1f77bcf86cd799439011";

function approvalRecord(overrides: Partial<ApprovalRecord> = {}): ApprovalRecord {
  return {
    id: APPROVAL_ID,
    status: "approved",
    title: "Send the kickoff email",
    description: "Email the client to confirm the kickoff call.",
    externalToolkit: "gmail",
    externalAction: "GMAIL_SEND_EMAIL",
    payload: { to: "client@example.com" },
    ...overrides,
  };
}

/**
 * Mimics the atomic compare-and-swap that MongoDB's findOneAndUpdate provides:
 * the status transition happens synchronously, before any await can interleave.
 */
function createFakeStore(initial: ApprovalRecord | null) {
  let current = initial;
  const agentRuns: AgentRunEntry[] = [];

  const store: ApprovalExecutionStore = {
    claimForExecution: async (): Promise<ApprovalClaim> => {
      if (!current) return { outcome: "not_found" };
      if (current.status === "approved") {
        current = { ...current, status: "executing" };
        return { outcome: "claimed", approval: current };
      }
      if (current.status === "executed") {
        return { outcome: "already_executed", approval: current };
      }
      if (current.status === "executing") return { outcome: "in_flight" };
      if (current.status === "rejected") return { outcome: "rejected" };
      return { outcome: "not_approved", status: current.status };
    },
    recordSuccess: async (_id, result) => {
      if (!current) return null;
      current = { ...current, status: "executed", result };
      return current;
    },
    recordFailure: async (_id, error) => {
      if (!current) return null;
      current = { ...current, status: "failed", result: { ok: false, error } };
      return current;
    },
    logAgentRun: async (entry) => {
      agentRuns.push(entry);
    },
  };

  return { store, agentRuns, read: () => current };
}

test("execution rejects an id that is not a valid ObjectId", async () => {
  const { store } = createFakeStore(approvalRecord());
  let ranExternalAction = false;
  const execute = createApprovalExecutor({
    store,
    createRunner: async () => async () => {
      ranExternalAction = true;
      return {};
    },
  });

  const result = await execute("not-an-object-id");

  assert.equal(result.ok, false);
  assert.equal(result.status, 400);
  assert.equal(ranExternalAction, false);
});

test("execution returns 404 when the approval does not exist", async () => {
  const { store } = createFakeStore(null);
  const execute = createApprovalExecutor({
    store,
    createRunner: async () => async () => ({}),
  });

  const result = await execute(APPROVAL_ID);

  assert.equal(result.ok, false);
  assert.equal(result.status, 404);
});

test("concurrent executions only run the external action once", async () => {
  const { store, read } = createFakeStore(approvalRecord());
  let externalCalls = 0;
  const execute = createApprovalExecutor({
    store,
    createRunner: async () => async () => {
      externalCalls += 1;
      await new Promise((resolve) => setTimeout(resolve, 5));
      return { delivered: true };
    },
  });

  const [first, second] = await Promise.all([
    execute(APPROVAL_ID),
    execute(APPROVAL_ID),
  ]);

  assert.equal(externalCalls, 1);
  assert.equal(read()?.status, "executed");

  const statuses = [first.status, second.status].sort();
  assert.deepEqual(statuses, [200, 409]);
});

test("a successful execution records the result and logs an agent run", async () => {
  const { store, agentRuns, read } = createFakeStore(
    approvalRecord({ projectId: "507f1f77bcf86cd799439012" }),
  );
  const execute = createApprovalExecutor({
    store,
    createRunner: async () => async () => ({ messageId: "abc" }),
  });

  const result = await execute(APPROVAL_ID);

  assert.equal(result.ok, true);
  assert.equal(result.status, 200);
  assert.equal(read()?.status, "executed");
  assert.deepEqual(result.approval?.result?.response, { messageId: "abc" });
  assert.equal(agentRuns.length, 1);
  assert.equal(agentRuns[0]?.status, "completed");
});

test("an approval that already executed is reported without re-running the action", async () => {
  const { store } = createFakeStore(approvalRecord({ status: "executed" }));
  let externalCalls = 0;
  const execute = createApprovalExecutor({
    store,
    createRunner: async () => async () => {
      externalCalls += 1;
      return {};
    },
  });

  const result = await execute(APPROVAL_ID);

  assert.equal(result.ok, true);
  assert.equal(result.alreadyExecuted, true);
  assert.equal(externalCalls, 0);
});

test("a rejected approval cannot be executed", async () => {
  const { store } = createFakeStore(approvalRecord({ status: "rejected" }));
  let externalCalls = 0;
  const execute = createApprovalExecutor({
    store,
    createRunner: async () => async () => {
      externalCalls += 1;
      return {};
    },
  });

  const result = await execute(APPROVAL_ID);

  assert.equal(result.ok, false);
  assert.equal(result.status, 409);
  assert.equal(externalCalls, 0);
});

test("a pending approval cannot be executed before a human approves it", async () => {
  const { store } = createFakeStore(approvalRecord({ status: "pending" }));
  let externalCalls = 0;
  const execute = createApprovalExecutor({
    store,
    createRunner: async () => async () => {
      externalCalls += 1;
      return {};
    },
  });

  const result = await execute(APPROVAL_ID);

  assert.equal(result.ok, false);
  assert.equal(result.status, 409);
  assert.equal(externalCalls, 0);
});

test("a failed external action marks the approval failed and logs the run", async () => {
  const { store, agentRuns, read } = createFakeStore(
    approvalRecord({ projectId: "507f1f77bcf86cd799439012" }),
  );
  const execute = createApprovalExecutor({
    store,
    createRunner: async () => async () => {
      throw new Error("Composio rejected the request");
    },
  });

  const result = await execute(APPROVAL_ID);

  assert.equal(result.ok, false);
  assert.equal(result.status, 502);
  assert.equal(read()?.status, "failed");
  assert.equal(agentRuns.length, 1);
  assert.equal(agentRuns[0]?.status, "failed");
});

test("a failed session handshake still releases the approval from executing", async () => {
  const { store, read } = createFakeStore(approvalRecord());
  const execute = createApprovalExecutor({
    store,
    createRunner: async () => {
      throw new Error("No Composio connection for this user");
    },
  });

  const result = await execute(APPROVAL_ID);

  assert.equal(result.ok, false);
  assert.equal(result.status, 502);
  assert.equal(read()?.status, "failed");
});
