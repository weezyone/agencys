import assert from "node:assert/strict";
import test from "node:test";
import { isPublicPath, resolveAuthPolicy, safeNextPath } from "../src/lib/auth/policy";

test("a configured password enforces authentication in any environment", () => {
  const policy = resolveAuthPolicy({
    nodeEnv: "development",
    password: "hunter2",
    secret: undefined,
  });

  assert.equal(policy.mode, "enforced");
});

test("the session secret falls back to the password when unset", () => {
  const policy = resolveAuthPolicy({
    nodeEnv: "production",
    password: "hunter2",
    secret: undefined,
  });

  assert.equal(policy.mode, "enforced");
  assert.equal(policy.mode === "enforced" && policy.secret, "hunter2");
});

test("an explicit session secret is preferred over the password", () => {
  const policy = resolveAuthPolicy({
    nodeEnv: "production",
    password: "hunter2",
    secret: "a-dedicated-signing-secret",
  });

  assert.equal(policy.mode === "enforced" && policy.secret, "a-dedicated-signing-secret");
});

test("local development without a password stays open so setup is zero-config", () => {
  const policy = resolveAuthPolicy({
    nodeEnv: "development",
    password: undefined,
    secret: undefined,
  });

  assert.equal(policy.mode, "open");
});

test("production without a password fails closed rather than open", () => {
  const policy = resolveAuthPolicy({
    nodeEnv: "production",
    password: undefined,
    secret: undefined,
  });

  assert.equal(policy.mode, "locked");
});

test("a blank or whitespace password counts as unset", () => {
  assert.equal(
    resolveAuthPolicy({ nodeEnv: "production", password: "   ", secret: undefined }).mode,
    "locked",
  );
});

test("only the login and health paths are public", () => {
  assert.equal(isPublicPath("/login"), true);
  assert.equal(isPublicPath("/api/auth/login"), true);

  assert.equal(isPublicPath("/"), false);
  assert.equal(isPublicPath("/approvals"), false);
  assert.equal(isPublicPath("/api/approvals/507f1f77bcf86cd799439011"), false);
  assert.equal(isPublicPath("/api/workflows/lead-to-project"), false);
  assert.equal(isPublicPath("/integrations/callback"), false);
});

test("a path that merely starts with a public prefix is not public", () => {
  assert.equal(isPublicPath("/login-as-admin"), false);
  assert.equal(isPublicPath("/api/auth/login/../../approvals"), false);
});

test("a post-login redirect keeps relative in-app paths", () => {
  assert.equal(safeNextPath("/approvals"), "/approvals");
  assert.equal(safeNextPath("/projects/507f1f77bcf86cd799439011"), "/projects/507f1f77bcf86cd799439011");
});

test("a post-login redirect refuses to leave the site", () => {
  assert.equal(safeNextPath("https://evil.example.com"), "/");
  assert.equal(safeNextPath("//evil.example.com"), "/");
  assert.equal(safeNextPath("/\\evil.example.com"), "/");
  assert.equal(safeNextPath("javascript:alert(1)"), "/");
});

test("a post-login redirect never bounces back to the login page", () => {
  assert.equal(safeNextPath("/login"), "/");
});

test("a missing post-login redirect lands on the dashboard", () => {
  assert.equal(safeNextPath(null), "/");
  assert.equal(safeNextPath(undefined), "/");
  assert.equal(safeNextPath(""), "/");
});
