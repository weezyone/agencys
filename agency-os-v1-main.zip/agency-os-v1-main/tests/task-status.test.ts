import assert from "node:assert/strict";
import test from "node:test";
import { TASK_STATUSES, deriveMilestoneStatus } from "../src/lib/tasks/status";

test("the shared task status list covers every supported status", () => {
  assert.deepEqual(TASK_STATUSES, [
    "todo",
    "in_progress",
    "blocked",
    "review",
    "done",
  ]);
});

test("a milestone with no tasks has not started", () => {
  assert.equal(deriveMilestoneStatus([]), "todo");
});

test("a milestone whose tasks are all untouched has not started", () => {
  assert.equal(deriveMilestoneStatus(["todo", "todo"]), "todo");
});

test("a milestone with any finished work is in progress", () => {
  assert.equal(deriveMilestoneStatus(["todo", "done"]), "in_progress");
  assert.equal(deriveMilestoneStatus(["todo", "in_progress"]), "in_progress");
});

test("a milestone is in review when work awaits review and nothing is blocked", () => {
  assert.equal(deriveMilestoneStatus(["review", "done"]), "review");
});

test("a blocked task outranks review when reporting milestone status", () => {
  assert.equal(deriveMilestoneStatus(["blocked", "review"]), "blocked");
});

test("a milestone is only done when every task is done", () => {
  assert.equal(deriveMilestoneStatus(["done", "done"]), "done");
  assert.equal(deriveMilestoneStatus(["done", "review"]), "review");
});
