import assert from "node:assert/strict";
import test from "node:test";
import { createInMemoryExecutionStore } from "../src/lib/tasks/execution-store.memory";
import { createWorkerLoop } from "../src/lib/tasks/worker-loop";

test("the worker claims a queued task, runs the agent, and stops on abort", async () => {
  const store = createInMemoryExecutionStore([
    {
      id: "task-1",
      projectId: "project-1",
      title: "Write the FAQ",
      ownerAgentId: "content-agent",
      acceptanceCriteria: ["Answers pricing"],
      execution: { status: "queued", attempts: 0 },
    },
  ]);

  const results: Array<{ ok: boolean; taskId: string }> = [];
  const controller = new AbortController();

  const run = createWorkerLoop({
    store,
    runAgent: async () => ({
      title: "FAQ",
      kind: "document",
      content: "Pricing starts at $99/mo.",
      summary: "FAQ draft",
    }),
    projectId: "project-1",
    pollIntervalMs: 10,
    sleep: async () => {
      controller.abort();
    },
    onResult: (result) => results.push(result),
  });

  await run(controller.signal);

  assert.equal(results.length, 1);
  assert.equal(results[0]?.ok, true);
  assert.equal(store.tasks.get("task-1")?.execution.status, "succeeded");
  assert.equal(store.artifacts.length, 1);
});

test("the worker idles when the queue is empty until aborted", async () => {
  const store = createInMemoryExecutionStore([]);
  const controller = new AbortController();
  let sleeps = 0;

  const run = createWorkerLoop({
    store,
    runAgent: async () => {
      throw new Error("should not run");
    },
    pollIntervalMs: 1,
    sleep: async () => {
      sleeps += 1;
      if (sleeps >= 2) controller.abort();
    },
  });

  await run(controller.signal);
  assert.ok(sleeps >= 2);
});
