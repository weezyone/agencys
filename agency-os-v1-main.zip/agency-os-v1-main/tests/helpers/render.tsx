import { createElement, type ReactElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { AppRouterContext } from "next/dist/shared/lib/app-router-context.shared-runtime";
import type { AppRouterInstance } from "next/dist/shared/lib/app-router-context.shared-runtime";

/**
 * Client components that call `useRouter` need App Router context, which Next
 * supplies during a real server render but `renderToStaticMarkup` does not.
 * The internal import is confined to this helper so a Next upgrade touches one file.
 */
const noopRouter: AppRouterInstance = {
  back: () => {},
  forward: () => {},
  refresh: () => {},
  push: () => {},
  replace: () => {},
  prefetch: () => {},
};

export function renderWithRouter(element: ReactElement): string {
  return renderToStaticMarkup(
    createElement(AppRouterContext.Provider, { value: noopRouter }, element),
  );
}
