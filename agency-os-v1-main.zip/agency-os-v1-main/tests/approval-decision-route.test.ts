import assert from "node:assert/strict";
import test from "node:test";
import {
  createApprovalDecisionHandler,
  type ApplyApprovalDecision,
} from "../src/lib/approvals/decision-handler";

const APPROVAL_ID = "507f1f77bcf86cd799439011";

function patch(body: unknown, id = APPROVAL_ID) {
  return [
    new Request(`http://localhost/api/approvals/${id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: typeof body === "string" ? body : JSON.stringify(body),
    }),
    { params: Promise.resolve({ id }) },
  ] as const;
}

const applied: ApplyApprovalDecision = async (id, decision) => ({
  outcome: "updated",
  approval: {
    id,
    status: decision,
    title: "Send the kickoff email",
    description: "Email the client.",
    externalToolkit: "gmail",
    externalAction: "GMAIL_SEND_EMAIL",
    payload: {},
  },
});

test("an invalid approval id is rejected before any write", async () => {
  let applyCalled = false;
  const handler = createApprovalDecisionHandler(async (...args) => {
    applyCalled = true;
    return applied(...args);
  });

  const response = await handler(...patch({ status: "approved" }, "not-an-id"));

  assert.equal(response.status, 400);
  assert.equal(applyCalled, false);
});

test("malformed JSON returns a 400 instead of throwing", async () => {
  const handler = createApprovalDecisionHandler(applied);

  const response = await handler(...patch("{not-json"));

  assert.equal(response.status, 400);
  assert.deepEqual(await response.json(), {
    error: "Request body must be valid JSON.",
  });
});

test("an unsupported decision returns a 400 instead of throwing", async () => {
  let applyCalled = false;
  const handler = createApprovalDecisionHandler(async (...args) => {
    applyCalled = true;
    return applied(...args);
  });

  const response = await handler(...patch({ status: "executed" }));

  assert.equal(response.status, 400);
  assert.equal(applyCalled, false);
});

test("approving a pending approval returns the updated record", async () => {
  const handler = createApprovalDecisionHandler(applied);

  const response = await handler(...patch({ status: "approved" }));
  const body = (await response.json()) as { approval?: { status?: string } };

  assert.equal(response.status, 200);
  assert.equal(body.approval?.status, "approved");
});

test("a missing approval returns 404", async () => {
  const handler = createApprovalDecisionHandler(async () => ({
    outcome: "not_found",
  }));

  const response = await handler(...patch({ status: "approved" }));

  assert.equal(response.status, 404);
});

test("an illegal transition returns 409 rather than silently succeeding", async () => {
  const handler = createApprovalDecisionHandler(async () => ({
    outcome: "conflict",
    status: "executed",
  }));

  const response = await handler(...patch({ status: "approved" }));
  const body = (await response.json()) as { error?: string };

  assert.equal(response.status, 409);
  assert.match(body.error ?? "", /executed/i);
});
