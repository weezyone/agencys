import assert from "node:assert/strict";
import test from "node:test";
import {
  DELIVERY_AGENT_IDS,
  agentsById,
  getDeliveryAgent,
  isDeliveryAgentId,
} from "../src/mastra/agents/registry";

test("every delivery agent id resolves to a registered agent", () => {
  for (const id of DELIVERY_AGENT_IDS) {
    const agent = getDeliveryAgent(id);
    assert.ok(agent, `expected agent for ${id}`);
    assert.equal(agent.id, id);
  }
});

test("the dispatch map covers every delivery agent id and nothing else", () => {
  assert.deepEqual(Object.keys(agentsById).sort(), [...DELIVERY_AGENT_IDS].sort());
});

test("isDeliveryAgentId accepts only known delivery agents", () => {
  assert.equal(isDeliveryAgentId("engineer-agent"), true);
  assert.equal(isDeliveryAgentId("sales-agent"), false);
  assert.equal(isDeliveryAgentId("not-an-agent"), false);
});

test("getDeliveryAgent returns undefined for unknown ids", () => {
  assert.equal(getDeliveryAgent("sales-agent"), undefined);
});
