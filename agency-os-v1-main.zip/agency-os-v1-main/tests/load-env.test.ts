import assert from "node:assert/strict";
import { mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";

import { loadEnv } from "../scripts/load-env";
import { env } from "../src/lib/env";

test("loadEnv parses quoted values and ignores comments", () => {
  const dir = mkdtempSync(join(tmpdir(), "agencyos-env-"));
  const path = join(dir, ".env");
  writeFileSync(
    path,
    [
      "# comment",
      "FOO=bare",
      'BAR="quoted value"',
      "BAZ='single'",
      "EXISTING=from-file",
      "",
    ].join("\n"),
  );

  process.env.EXISTING = "already-set";
  delete process.env.FOO;
  delete process.env.BAR;
  delete process.env.BAZ;

  loadEnv(path);

  assert.equal(process.env.FOO, "bare");
  assert.equal(process.env.BAR, "quoted value");
  assert.equal(process.env.BAZ, "single");
  assert.equal(process.env.EXISTING, "already-set");
});

test("env.mongodbUri reads process.env lazily after loadEnv", () => {
  const previous = process.env.MONGODB_URI;
  delete process.env.MONGODB_URI;

  assert.equal(env.mongodbUri, "mongodb://localhost:27017");

  process.env.MONGODB_URI = "mongodb+srv://example.mongodb.net/";
  assert.equal(env.mongodbUri, "mongodb+srv://example.mongodb.net/");

  if (previous === undefined) {
    delete process.env.MONGODB_URI;
  } else {
    process.env.MONGODB_URI = previous;
  }
});
