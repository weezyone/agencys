import assert from "node:assert/strict";
import test from "node:test";
import { LEASE_MS, MAX_ATTEMPTS } from "../src/lib/tasks/claim";
import type { RunAgent } from "../src/lib/tasks/execution";
import { createInMemoryExecutionStore } from "../src/lib/tasks/execution-store.memory";
import type { TaskExecutionStore } from "../src/lib/tasks/execution-types";
import { createWorkerLoop } from "../src/lib/tasks/worker-loop";

type WorkerResult = { ok: boolean; taskId: string; error?: string };

/**
 * Runs a worker until its first empty poll, which is the point at which every
 * claimable task in scope has been executed.
 */
async function drainQueue(
  store: TaskExecutionStore,
  runAgent: RunAgent,
  projectId?: string,
): Promise<WorkerResult[]> {
  const results: WorkerResult[] = [];
  const controller = new AbortController();

  const run = createWorkerLoop({
    store,
    runAgent,
    projectId,
    sleep: async () => {
      controller.abort();
    },
    onResult: (result) => results.push(result),
  });

  await run(controller.signal);
  return results;
}

const deliverable = (title: string): Awaited<ReturnType<RunAgent>> => ({
  title,
  kind: "document",
  content: `Deliverable body for ${title}.`,
  summary: `Summary of ${title}.`,
});

test("scenario 1: a worker drains a project queue highest priority first", async () => {
  const store = createInMemoryExecutionStore([
    {
      id: "task-low",
      projectId: "project-1",
      title: "Archive the old assets",
      ownerAgentId: "ops-agent",
      priority: "low",
      createdAt: new Date("2026-01-01T09:00:00Z"),
      execution: { status: "queued", attempts: 0 },
    },
    {
      id: "task-high",
      projectId: "project-1",
      title: "Draft the launch brief",
      ownerAgentId: "strategist-agent",
      priority: "high",
      createdAt: new Date("2026-01-01T11:00:00Z"),
      execution: { status: "queued", attempts: 0 },
    },
    {
      id: "task-medium",
      projectId: "project-1",
      title: "Write the QA plan",
      ownerAgentId: "qa-agent",
      priority: "medium",
      createdAt: new Date("2026-01-01T10:00:00Z"),
      execution: { status: "queued", attempts: 0 },
    },
  ]);

  const dispatched: string[] = [];
  const results = await drainQueue(
    store,
    async (agentId, prompt) => {
      dispatched.push(agentId);
      assert.match(prompt, /AgencyOS/);
      return deliverable(`Output from ${agentId}`);
    },
    "project-1",
  );

  assert.deepEqual(
    dispatched,
    ["strategist-agent", "qa-agent", "ops-agent"],
    "priority outranks age when choosing the next task",
  );
  assert.equal(results.length, 3);
  assert.ok(results.every((result) => result.ok));

  for (const id of ["task-high", "task-medium", "task-low"]) {
    const task = store.tasks.get(id);
    assert.equal(task?.status, "review", `${id} moves to review`);
    assert.equal(task?.execution.status, "succeeded");
    assert.equal(task?.execution.attempts, 1);
  }

  assert.equal(store.artifacts.length, 3);
  assert.deepEqual(
    [...store.artifacts].map((artifact) => artifact.taskId).sort(),
    ["task-high", "task-low", "task-medium"],
    "each artifact is keyed to the task that produced it",
  );
});

test("scenario 2: an orphaned run is reclaimed once its lease expires, a live lease is left alone", async () => {
  const now = Date.now();
  const store = createInMemoryExecutionStore([
    {
      id: "task-orphaned",
      projectId: "project-1",
      title: "Rebuild the pricing page",
      ownerAgentId: "engineer-agent",
      execution: {
        status: "running",
        attempts: 1,
        startedAt: new Date(now - LEASE_MS * 2),
        leaseExpiresAt: new Date(now - 1_000),
      },
    },
    {
      id: "task-held",
      projectId: "project-1",
      title: "Held by a healthy worker",
      ownerAgentId: "designer-agent",
      execution: {
        status: "running",
        attempts: 1,
        startedAt: new Date(now),
        leaseExpiresAt: new Date(now + LEASE_MS),
      },
    },
  ]);

  const results = await drainQueue(
    store,
    async () => deliverable("Pricing page rebuild"),
    "project-1",
  );

  assert.deepEqual(
    results.map((result) => result.taskId),
    ["task-orphaned"],
    "only the expired lease is reclaimed",
  );

  const reclaimed = store.tasks.get("task-orphaned");
  assert.equal(reclaimed?.execution.status, "succeeded");
  assert.equal(reclaimed?.execution.attempts, 2, "the retry counts against the cap");

  const held = store.tasks.get("task-held");
  assert.equal(held?.execution.status, "running", "a live lease is never stolen");
  assert.equal(held?.execution.attempts, 1);
  assert.equal(store.artifacts.length, 1);
});

test("scenario 3: expired-lease reclaims stop at MAX_ATTEMPTS; a human re-queue resets the counter", async () => {
  const store = createInMemoryExecutionStore([
    {
      id: "task-poison",
      projectId: "project-1",
      title: "Integrate the unreachable API",
      ownerAgentId: "engineer-agent",
      execution: { status: "queued", attempts: 0 },
    },
  ]);

  let calls = 0;
  const alwaysThrows: RunAgent = async () => {
    calls += 1;
    throw new Error("upstream API refused the connection");
  };

  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt += 1) {
    if (attempt > 1) {
      // Simulate a worker that died mid-run: still "running", lease expired.
      // This is the only automatic path that accumulates attempts.
      const task = store.tasks.get("task-poison");
      assert.ok(task);
      task.execution = {
        status: "running",
        attempts: attempt - 1,
        startedAt: new Date(Date.now() - LEASE_MS * 2),
        leaseExpiresAt: new Date(Date.now() - 1_000),
      };
    }

    const results = await drainQueue(store, alwaysThrows, "project-1");
    assert.equal(results.length, 1, `attempt ${attempt} runs once`);
    assert.equal(results[0]?.ok, false);
    assert.equal(store.tasks.get("task-poison")?.execution.attempts, attempt);
  }

  const failed = store.tasks.get("task-poison");
  assert.equal(failed?.execution.status, "failed");
  assert.equal(failed?.execution.error, "upstream API refused the connection");
  assert.equal(calls, MAX_ATTEMPTS);

  // Even an expired lease at the cap is not reclaimed.
  assert.ok(failed);
  failed.execution = {
    status: "running",
    attempts: MAX_ATTEMPTS,
    startedAt: new Date(Date.now() - LEASE_MS * 2),
    leaseExpiresAt: new Date(Date.now() - 1_000),
  };
  assert.equal(await store.claimNext("project-1"), null);
  assert.equal(calls, MAX_ATTEMPTS, "no further agent calls after the cap");

  // Operator sees a failed task (not a zombie running lease) and presses Run.
  failed.execution = {
    status: "failed",
    attempts: MAX_ATTEMPTS,
    finishedAt: new Date(),
    error: "upstream API refused the connection",
  };

  // A human pressing Run resets attempts so the task can be retried.
  await store.queueTask("task-poison");
  const requeued = store.tasks.get("task-poison");
  assert.equal(requeued?.execution.status, "queued");
  assert.equal(
    requeued?.execution.attempts,
    0,
    "manual re-queue clears the attempt counter",
  );

  const retryResults = await drainQueue(store, alwaysThrows, "project-1");
  assert.equal(retryResults.length, 1);
  assert.equal(retryResults[0]?.ok, false);
  assert.equal(calls, MAX_ATTEMPTS + 1, "one more agent call after a human retry");
  assert.equal(store.tasks.get("task-poison")?.execution.attempts, 1);
});

test("scenario 4: two workers share a queue and each task executes exactly once", async () => {
  const store = createInMemoryExecutionStore(
    ["task-1", "task-2", "task-3", "task-4"].map((id, index) => ({
      id,
      projectId: "project-1",
      title: `Deliverable ${index + 1}`,
      ownerAgentId: "content-agent",
      createdAt: new Date(2026, 0, index + 1),
      execution: { status: "queued" as const, attempts: 0 },
    })),
  );

  const dispatched: string[] = [];
  const runAgent: RunAgent = async (_agentId, prompt) => {
    dispatched.push(prompt);
    // Yield so the two loops genuinely interleave on the event loop.
    await new Promise((resolve) => setTimeout(resolve, 1));
    return deliverable("Shared queue output");
  };

  const [first, second] = await Promise.all([
    drainQueue(store, runAgent, "project-1"),
    drainQueue(store, runAgent, "project-1"),
  ]);

  const handled = [...first, ...second].map((result) => result.taskId).sort();
  assert.deepEqual(handled, ["task-1", "task-2", "task-3", "task-4"]);
  assert.equal(new Set(handled).size, 4, "no task is claimed by both workers");
  assert.equal(dispatched.length, 4, "the agent runs once per task");
  assert.equal(store.artifacts.length, 4, "no duplicate artifacts");

  for (const task of store.tasks.values()) {
    assert.equal(task.execution.status, "succeeded");
    assert.equal(task.execution.attempts, 1);
  }
});

test("scenario 5: undispatchable tasks fail without an agent call and do not block the queue", async () => {
  const store = createInMemoryExecutionStore([
    {
      id: "task-unowned",
      projectId: "project-1",
      title: "Nobody owns this",
      priority: "high",
      createdAt: new Date("2026-01-01T09:00:00Z"),
      execution: { status: "queued", attempts: 0 },
    },
    {
      id: "task-non-delivery",
      projectId: "project-1",
      title: "Owned by an agent that cannot deliver",
      ownerAgentId: "sales-agent",
      priority: "high",
      createdAt: new Date("2026-01-01T10:00:00Z"),
      execution: { status: "queued", attempts: 0 },
    },
    {
      id: "task-valid",
      projectId: "project-1",
      title: "Write the release notes",
      ownerAgentId: "content-agent",
      priority: "medium",
      createdAt: new Date("2026-01-01T11:00:00Z"),
      execution: { status: "queued", attempts: 0 },
    },
    {
      id: "task-other-project",
      projectId: "project-2",
      title: "Belongs to another project",
      ownerAgentId: "content-agent",
      priority: "high",
      createdAt: new Date("2026-01-01T08:00:00Z"),
      execution: { status: "queued", attempts: 0 },
    },
  ]);

  let calls = 0;
  const results = await drainQueue(
    store,
    async () => {
      calls += 1;
      return deliverable("Release notes");
    },
    "project-1",
  );

  assert.equal(calls, 1, "only the dispatchable task reaches an agent");
  assert.equal(results.filter((result) => result.ok).length, 1);
  assert.equal(results.filter((result) => !result.ok).length, 2);

  assert.match(
    store.tasks.get("task-unowned")?.execution.error ?? "",
    /no owner agent/i,
  );
  assert.match(
    store.tasks.get("task-non-delivery")?.execution.error ?? "",
    /not a delivery agent/i,
  );

  const valid = store.tasks.get("task-valid");
  assert.equal(valid?.execution.status, "succeeded");
  assert.equal(valid?.status, "review");

  const otherProject = store.tasks.get("task-other-project");
  assert.equal(
    otherProject?.execution.status,
    "queued",
    "a project-scoped worker leaves other projects untouched",
  );
  assert.equal(store.artifacts.length, 1);
});
