import assert from "node:assert/strict";
import test from "node:test";
import { isTransactionUnsupported } from "../src/lib/mongodb/transaction";

test("a standalone mongod rejecting transaction numbers is treated as unsupported", () => {
  const error = Object.assign(
    new Error(
      "Transaction numbers are only allowed on a replica set member or mongos",
    ),
    { code: 20, codeName: "IllegalOperation" },
  );

  assert.equal(isTransactionUnsupported(error), true);
});

test("a deployment that does not support sessions is treated as unsupported", () => {
  const error = new Error("Current topology does not support sessions");

  assert.equal(isTransactionUnsupported(error), true);
});

test("a genuine write failure is not mistaken for missing transaction support", () => {
  const error = Object.assign(new Error("E11000 duplicate key error"), {
    code: 11000,
  });

  assert.equal(isTransactionUnsupported(error), false);
});

test("an unrelated error is not treated as unsupported", () => {
  assert.equal(isTransactionUnsupported(new Error("connection reset")), false);
  assert.equal(isTransactionUnsupported("not an error"), false);
  assert.equal(isTransactionUnsupported(null), false);
});
