import assert from "node:assert/strict";
import test from "node:test";
import {
  leadIntakeSchema,
  workflowIntakeSchema,
} from "../src/lib/leads/intake";
import { createLeadIntakeHandler } from "../src/lib/leads/intake-handler";

const VALID = {
  name: "Avery",
  problem: "Launch a new client portal.",
};

test("a blank name is rejected", () => {
  const result = leadIntakeSchema.safeParse({ ...VALID, name: "   " });

  assert.equal(result.success, false);
});

test("a blank problem is rejected", () => {
  const result = leadIntakeSchema.safeParse({ ...VALID, problem: "  \n " });

  assert.equal(result.success, false);
});

test("surrounding whitespace is trimmed off required fields", () => {
  const result = leadIntakeSchema.safeParse({
    name: "  Avery  ",
    problem: "  Launch a portal.  ",
  });

  assert.equal(result.success, true);
  assert.equal(result.data?.name, "Avery");
  assert.equal(result.data?.problem, "Launch a portal.");
});

test("empty optional fields become undefined rather than empty strings", () => {
  const result = leadIntakeSchema.safeParse({
    ...VALID,
    company: "",
    email: "",
    budget: "   ",
  });

  assert.equal(result.success, true);
  assert.equal(result.data?.company, undefined);
  assert.equal(result.data?.email, undefined);
  assert.equal(result.data?.budget, undefined);
});

test("a malformed email is rejected", () => {
  const result = leadIntakeSchema.safeParse({ ...VALID, email: "not-an-email" });

  assert.equal(result.success, false);
});

test("the workflow schema accepts everything the HTTP schema produces", () => {
  const parsed = leadIntakeSchema.parse({
    name: "Avery",
    company: "Northwind",
    email: "avery@example.com",
    source: "dashboard",
    problem: "Launch a new client portal.",
    budget: "$20k",
    timeline: "six weeks",
  });

  assert.equal(workflowIntakeSchema.safeParse(parsed).success, true);
});

test("POST /api/leads returns 400 for a malformed body instead of throwing", async () => {
  let created = false;
  const handler = createLeadIntakeHandler(async () => {
    created = true;
    return "507f1f77bcf86cd799439011";
  });

  const response = await handler(
    new Request("http://localhost/api/leads", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{not-json",
    }),
  );

  assert.equal(response.status, 400);
  assert.equal(created, false);
});

test("POST /api/leads returns 400 for a blank lead instead of writing it", async () => {
  let created = false;
  const handler = createLeadIntakeHandler(async () => {
    created = true;
    return "507f1f77bcf86cd799439011";
  });

  const response = await handler(
    new Request("http://localhost/api/leads", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ name: "   ", problem: "   " }),
    }),
  );

  assert.equal(response.status, 400);
  assert.equal(created, false);
});

test("POST /api/leads returns 400 with a readable message for a bad email", async () => {
  const handler = createLeadIntakeHandler(async () => "507f1f77bcf86cd799439011");

  const response = await handler(
    new Request("http://localhost/api/leads", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ ...VALID, email: "nope" }),
    }),
  );
  const body = (await response.json()) as { error?: string };

  assert.equal(response.status, 400);
  assert.match(body.error ?? "", /email/i);
});

test("POST /api/leads creates a lead and returns 201 with its id", async () => {
  const handler = createLeadIntakeHandler(async () => "507f1f77bcf86cd799439011");

  const response = await handler(
    new Request("http://localhost/api/leads", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(VALID),
    }),
  );

  assert.equal(response.status, 201);
  assert.deepEqual(await response.json(), {
    leadId: "507f1f77bcf86cd799439011",
    nextWorkflow: "lead-to-project",
  });
});

test("POST /api/leads reports a storage failure as 502 without leaking internals", async () => {
  const handler = createLeadIntakeHandler(async () => {
    throw new Error("mongodb://user:password@cluster refused the connection");
  });

  const response = await handler(
    new Request("http://localhost/api/leads", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(VALID),
    }),
  );
  const body = (await response.json()) as { error?: string };

  assert.equal(response.status, 502);
  assert.doesNotMatch(JSON.stringify(body), /password/i);
});
