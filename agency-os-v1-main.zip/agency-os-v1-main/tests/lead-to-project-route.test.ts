import assert from "node:assert/strict";
import test from "node:test";
import * as leadToProjectRoute from "../src/app/api/workflows/lead-to-project/route";
import { createLeadToProjectHandler } from "../src/lib/workflows/lead-to-project-handler";

const { POST } = leadToProjectRoute;

test("lead-to-project returns a validation response for invalid intake", async () => {
  const response = await POST(
    new Request("http://localhost/api/workflows/lead-to-project", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        name: "Avery",
        email: "not-an-email",
        problem: "Launch a new client portal.",
      }),
    }),
  );

  assert.equal(response.status, 400);
  const body = (await response.json()) as { error?: string };
  assert.match(body.error ?? "", /valid email/i);
});

test("lead-to-project returns a navigable payload after a successful run", async () => {
  const handler = createLeadToProjectHandler(async () => ({
    runId: "run-123",
    outcome: {
      status: "success",
      result: {
        leadId: "lead-123",
        briefId: "brief-123",
        projectId: "project-123",
        milestoneIds: ["milestone-123"],
        taskIds: ["task-123"],
      },
    },
  }));

  const response = await handler(
    new Request("http://localhost/api/workflows/lead-to-project", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        name: "Avery",
        email: "avery@example.com",
        problem: "Launch a new client portal.",
      }),
    }),
  );

  assert.equal(response.status, 201);
  assert.deepEqual(await response.json(), {
    workflow: "lead-to-project",
    runId: "run-123",
    leadId: "lead-123",
    briefId: "brief-123",
    projectId: "project-123",
    milestoneIds: ["milestone-123"],
    taskIds: ["task-123"],
  });
});

test("lead-to-project rejects blank required fields before starting a run", async () => {
  let workflowStarted = false;
  const handler = createLeadToProjectHandler(async () => {
    workflowStarted = true;
    return {
      runId: "run-blank",
      outcome: {
        status: "success",
        result: {
          leadId: "lead-blank",
          briefId: "brief-blank",
          projectId: "project-blank",
          milestoneIds: [],
          taskIds: [],
        },
      },
    };
  });

  const response = await handler(
    new Request("http://localhost/api/workflows/lead-to-project", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ name: "   ", problem: "   " }),
    }),
  );

  assert.equal(response.status, 400);
  assert.equal(workflowStarted, false);
});

test("lead-to-project returns a safe error when execution throws", async () => {
  const handler = createLeadToProjectHandler(async () => {
    throw new Error("provider secret should not be exposed");
  });

  const response = await handler(
    new Request("http://localhost/api/workflows/lead-to-project", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        name: "Avery",
        email: "avery@example.com",
        problem: "Launch a new client portal.",
      }),
    }),
  );

  assert.equal(response.status, 502);
  const body = (await response.json()) as { error?: string };
  assert.equal(body.error, "Unable to complete the lead-to-project workflow.");
  assert.doesNotMatch(JSON.stringify(body), /provider secret/i);
});

test("lead-to-project rejects malformed JSON", async () => {
  const response = await POST(
    new Request("http://localhost/api/workflows/lead-to-project", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{not-json",
    }),
  );

  assert.equal(response.status, 400);
  assert.deepEqual(await response.json(), { error: "Request body must be valid JSON." });
});
