import assert from "node:assert/strict";
import test from "node:test";
import { createTaskStatusUpdater } from "../src/lib/tasks/update-status";
import type { TaskStatus } from "../src/lib/mongodb/types";

const TASK_ID = "507f1f77bcf86cd799439011";
const MILESTONE_ID = "507f1f77bcf86cd799439012";

function createStore({
  task,
  siblingStatuses = [],
}: {
  task: { milestoneId?: string } | null;
  siblingStatuses?: TaskStatus[];
}) {
  const milestoneWrites: Array<{ milestoneId: string; status: TaskStatus }> = [];

  return {
    milestoneWrites,
    store: {
      setTaskStatus: async () => task,
      listMilestoneTaskStatuses: async () => siblingStatuses,
      setMilestoneStatus: async (milestoneId: string, status: TaskStatus) => {
        milestoneWrites.push({ milestoneId, status });
      },
    },
  };
}

test("a missing task yields no result and no milestone write", async () => {
  const { store, milestoneWrites } = createStore({ task: null });
  const update = createTaskStatusUpdater(store);

  assert.equal(await update(TASK_ID, "done"), null);
  assert.equal(milestoneWrites.length, 0);
});

test("a task with no milestone returns its own status only", async () => {
  const { store, milestoneWrites } = createStore({ task: {} });
  const update = createTaskStatusUpdater(store);

  const result = await update(TASK_ID, "in_progress");

  assert.deepEqual(result, { taskId: TASK_ID, status: "in_progress" });
  assert.equal(milestoneWrites.length, 0);
});

test("finishing the last open task rolls the milestone up to done", async () => {
  const { store, milestoneWrites } = createStore({
    task: { milestoneId: MILESTONE_ID },
    siblingStatuses: ["done", "done"],
  });
  const update = createTaskStatusUpdater(store);

  const result = await update(TASK_ID, "done");

  assert.equal(result?.milestoneStatus, "done");
  assert.deepEqual(milestoneWrites, [
    { milestoneId: MILESTONE_ID, status: "done" },
  ]);
});

test("blocking one task blocks the whole milestone", async () => {
  const { store, milestoneWrites } = createStore({
    task: { milestoneId: MILESTONE_ID },
    siblingStatuses: ["blocked", "done"],
  });
  const update = createTaskStatusUpdater(store);

  const result = await update(TASK_ID, "blocked");

  assert.equal(result?.milestoneStatus, "blocked");
  assert.equal(milestoneWrites[0]?.status, "blocked");
});

test("the returned milestone id is a string the client can round-trip", async () => {
  const { store } = createStore({
    task: { milestoneId: MILESTONE_ID },
    siblingStatuses: ["in_progress"],
  });
  const update = createTaskStatusUpdater(store);

  const result = await update(TASK_ID, "in_progress");

  assert.equal(result?.milestoneId, MILESTONE_ID);
  assert.equal(typeof result?.milestoneId, "string");
});
