import assert from "node:assert/strict";
import test from "node:test";
import { PATCH } from "../src/app/api/tasks/[id]/route";
import {
  createTaskStatusHandler,
  type UpdateTaskStatus,
} from "../src/lib/tasks/task-status-handler";

const TASK_ID = "507f1f77bcf86cd799439011";
const MILESTONE_ID = "507f1f77bcf86cd799439012";

function patch(body: unknown, id = TASK_ID) {
  return [
    new Request(`http://localhost/api/tasks/${id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: typeof body === "string" ? body : JSON.stringify(body),
    }),
    { params: Promise.resolve({ id }) },
  ] as const;
}

function spyUpdate(result: Awaited<ReturnType<UpdateTaskStatus>>) {
  const calls: Array<{ id: string; status: string }> = [];
  const update: UpdateTaskStatus = async (id, status) => {
    calls.push({ id, status });
    return result;
  };

  return { calls, update };
}

test("an invalid task id is rejected before any write", async () => {
  const { calls, update } = spyUpdate(null);
  const response = await createTaskStatusHandler(update)(
    ...patch({ status: "done" }, "not-an-id"),
  );

  assert.equal(response.status, 400);
  assert.deepEqual(await response.json(), { error: "Invalid task id." });
  assert.equal(calls.length, 0);
});

test("malformed JSON is rejected before any write", async () => {
  const { calls, update } = spyUpdate(null);
  const response = await createTaskStatusHandler(update)(...patch("{not-json"));

  assert.equal(response.status, 400);
  assert.equal(calls.length, 0);
});

test("an unsupported status is rejected before any write", async () => {
  const { calls, update } = spyUpdate(null);
  const response = await createTaskStatusHandler(update)(
    ...patch({ status: "deleted" }),
  );

  assert.equal(response.status, 400);
  assert.deepEqual(await response.json(), { error: "Invalid task status." });
  assert.equal(calls.length, 0);
});

test("a successful update returns the task and its milestone rollup", async () => {
  const { calls, update } = spyUpdate({
    taskId: TASK_ID,
    status: "in_progress",
    milestoneId: MILESTONE_ID,
    milestoneStatus: "in_progress",
  });
  const response = await createTaskStatusHandler(update)(
    ...patch({ status: "in_progress" }),
  );

  assert.equal(response.status, 200);
  assert.deepEqual(await response.json(), {
    taskId: TASK_ID,
    status: "in_progress",
    milestoneId: MILESTONE_ID,
    milestoneStatus: "in_progress",
  });
  assert.deepEqual(calls, [{ id: TASK_ID, status: "in_progress" }]);
});

test("a missing task returns 404", async () => {
  const { update } = spyUpdate(null);
  const response = await createTaskStatusHandler(update)(...patch({ status: "done" }));

  assert.equal(response.status, 404);
  assert.deepEqual(await response.json(), { error: "Task not found." });
});

test("the route exports a PATCH handler wired to the production store", () => {
  assert.equal(typeof PATCH, "function");
});
