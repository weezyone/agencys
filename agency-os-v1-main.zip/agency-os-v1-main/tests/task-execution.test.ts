import assert from "node:assert/strict";
import test from "node:test";
import {
  artifactOutputSchema,
  buildTaskPrompt,
  createTaskExecutor,
  type RunAgent,
} from "../src/lib/tasks/execution";
import { createInMemoryExecutionStore } from "../src/lib/tasks/execution-store.memory";
import type { ClaimedTask } from "../src/lib/tasks/execution-types";

function claimed(overrides: Partial<ClaimedTask> = {}): ClaimedTask {
  return {
    id: "task-1",
    projectId: "project-1",
    title: "Draft the landing hero",
    description: "Write a conversion-focused hero section.",
    ownerAgentId: "content-agent",
    priority: "high",
    acceptanceCriteria: ["Mentions the product name", "Under 80 words"],
    status: "in_progress",
    execution: {
      status: "running",
      attempts: 1,
      leaseExpiresAt: new Date(Date.now() + 60_000),
    },
    ...overrides,
  };
}

test("buildTaskPrompt includes title, description, and acceptance criteria", () => {
  const prompt = buildTaskPrompt(claimed());

  assert.match(prompt, /Draft the landing hero/);
  assert.match(prompt, /conversion-focused hero/);
  assert.match(prompt, /Mentions the product name/);
  assert.match(prompt, /Under 80 words/);
  assert.match(prompt, /content-agent/);
});

test("artifactOutputSchema requires a supported kind and non-empty content", () => {
  assert.equal(
    artifactOutputSchema.safeParse({
      title: "Hero copy",
      kind: "document",
      content: "Welcome to Acme.",
      summary: "Hero draft",
    }).success,
    true,
  );
  assert.equal(
    artifactOutputSchema.safeParse({
      title: "Hero copy",
      kind: "tweet",
      content: "x",
      summary: "x",
    }).success,
    false,
  );
  assert.equal(
    artifactOutputSchema.safeParse({
      title: "Hero copy",
      kind: "document",
      content: "",
      summary: "x",
    }).success,
    false,
  );
});

test("a successful run saves an artifact, marks the task succeeded, and logs the run", async () => {
  const store = createInMemoryExecutionStore([
    {
      id: "task-1",
      projectId: "project-1",
      title: "Draft the landing hero",
      ownerAgentId: "content-agent",
      acceptanceCriteria: ["Mentions the product name"],
      execution: { status: "queued", attempts: 0 },
    },
  ]);

  const runAgent: RunAgent = async () => ({
    title: "Hero copy",
    kind: "document",
    content: "Welcome to Acme — ship faster.",
    summary: "Conversion-focused hero",
  });

  const execute = createTaskExecutor({ store, runAgent });
  const claimedTask = await store.claimNext("project-1");
  assert.ok(claimedTask);

  const result = await execute(claimedTask);

  assert.equal(result.ok, true);
  assert.equal(store.artifacts.length, 1);
  assert.equal(store.artifacts[0]?.kind, "document");
  assert.equal(store.tasks.get("task-1")?.status, "review");
  assert.equal(store.tasks.get("task-1")?.execution.status, "succeeded");
});

test("a missing owner agent fails the task without calling the runner", async () => {
  const store = createInMemoryExecutionStore([
    {
      id: "task-1",
      projectId: "project-1",
      title: "Orphan task",
      acceptanceCriteria: [],
      execution: { status: "queued", attempts: 0 },
    },
  ]);
  let ran = false;
  const execute = createTaskExecutor({
    store,
    runAgent: async () => {
      ran = true;
      return {
        title: "x",
        kind: "document",
        content: "x",
        summary: "x",
      };
    },
  });

  const claimedTask = await store.claimNext("project-1");
  assert.ok(claimedTask);
  // Strip the owner after claim to simulate a bad document.
  claimedTask.ownerAgentId = undefined;

  const result = await execute(claimedTask);

  assert.equal(result.ok, false);
  assert.equal(ran, false);
  assert.equal(store.tasks.get("task-1")?.execution.status, "failed");
  assert.match(result.error ?? "", /owner/i);
});

test("an unknown owner agent fails the task", async () => {
  const store = createInMemoryExecutionStore([
    {
      id: "task-1",
      projectId: "project-1",
      title: "Bad owner",
      ownerAgentId: "sales-agent",
      acceptanceCriteria: [],
      execution: { status: "queued", attempts: 0 },
    },
  ]);
  const execute = createTaskExecutor({
    store,
    runAgent: async () => ({
      title: "x",
      kind: "document",
      content: "x",
      summary: "x",
    }),
  });

  const claimedTask = await store.claimNext("project-1");
  assert.ok(claimedTask);
  const result = await execute(claimedTask);

  assert.equal(result.ok, false);
  assert.match(result.error ?? "", /sales-agent|delivery agent/i);
  assert.equal(store.tasks.get("task-1")?.execution.status, "failed");
});

test("a thrown agent error marks the task failed and records the message", async () => {
  const store = createInMemoryExecutionStore([
    {
      id: "task-1",
      projectId: "project-1",
      title: "Failing task",
      ownerAgentId: "engineer-agent",
      acceptanceCriteria: ["Compiles"],
      execution: { status: "queued", attempts: 0 },
    },
  ]);
  const execute = createTaskExecutor({
    store,
    runAgent: async () => {
      throw new Error("model timed out");
    },
  });

  const claimedTask = await store.claimNext("project-1");
  assert.ok(claimedTask);
  const result = await execute(claimedTask);

  assert.equal(result.ok, false);
  assert.equal(result.error, "model timed out");
  assert.equal(store.tasks.get("task-1")?.execution.status, "failed");
  assert.equal(store.tasks.get("task-1")?.execution.error, "model timed out");
  assert.equal(store.artifacts.length, 0);
});

test("the agent runner receives the built prompt and owner id", async () => {
  const store = createInMemoryExecutionStore([
    {
      id: "task-1",
      projectId: "project-1",
      title: "Design the nav",
      description: "Top navigation for the marketing site.",
      ownerAgentId: "designer-agent",
      acceptanceCriteria: ["Mobile friendly"],
      execution: { status: "queued", attempts: 0 },
    },
  ]);
  let seen: { agentId: string; prompt: string } | undefined;
  const execute = createTaskExecutor({
    store,
    runAgent: async (agentId, prompt) => {
      seen = { agentId, prompt };
      return {
        title: "Nav design notes",
        kind: "design",
        content: "Sticky top bar with logo left, CTA right.",
        summary: "Nav layout",
      };
    },
  });

  const claimedTask = await store.claimNext("project-1");
  assert.ok(claimedTask);
  await execute(claimedTask);

  assert.equal(seen?.agentId, "designer-agent");
  assert.match(seen?.prompt ?? "", /Design the nav/);
  assert.match(seen?.prompt ?? "", /Mobile friendly/);
});
