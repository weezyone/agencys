import assert from "node:assert/strict";
import test from "node:test";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import HomePage from "../src/app/page";

test("home page renders the lead intake form", () => {
  const html = renderToStaticMarkup(createElement(HomePage));

  assert.match(html, /<form/);
  assert.match(html, /name="name"/);
  assert.match(html, /name="email"/);
  assert.match(html, /name="problem"/);
  assert.match(html, />Start planning</);
});
