import assert from "node:assert/strict";
import test from "node:test";
import {
  LEASE_MS,
  MAX_ATTEMPTS,
  PRIORITY_RANK,
  isClaimable,
  type ClaimableTask,
} from "../src/lib/tasks/claim";
import { createInMemoryExecutionStore } from "../src/lib/tasks/execution-store.memory";

function task(overrides: Partial<ClaimableTask> = {}): ClaimableTask {
  return {
    id: "task-1",
    projectId: "project-1",
    priority: "medium",
    createdAt: new Date("2026-01-01T00:00:00Z"),
    execution: { status: "queued", attempts: 0 },
    ...overrides,
  };
}

test("a queued task with attempts remaining is claimable", () => {
  assert.equal(isClaimable(task(), new Date()), true);
});

test("a running task with an expired lease is claimable", () => {
  const now = new Date("2026-01-01T12:00:00Z");
  assert.equal(
    isClaimable(
      task({
        execution: {
          status: "running",
          attempts: 1,
          leaseExpiresAt: new Date("2026-01-01T11:59:00Z"),
        },
      }),
      now,
    ),
    true,
  );
});

test("a running task whose lease is still live is not claimable", () => {
  const now = new Date("2026-01-01T12:00:00Z");
  assert.equal(
    isClaimable(
      task({
        execution: {
          status: "running",
          attempts: 1,
          leaseExpiresAt: new Date("2026-01-01T12:05:00Z"),
        },
      }),
      now,
    ),
    false,
  );
});

test("a task that has exhausted its attempts is not claimable", () => {
  assert.equal(
    isClaimable(
      task({ execution: { status: "queued", attempts: MAX_ATTEMPTS } }),
      new Date(),
    ),
    false,
  );
});

test("succeeded and failed tasks are not claimable", () => {
  assert.equal(
    isClaimable(task({ execution: { status: "succeeded", attempts: 1 } }), new Date()),
    false,
  );
  assert.equal(
    isClaimable(task({ execution: { status: "failed", attempts: 1 } }), new Date()),
    false,
  );
});

test("idle tasks are not claimable until queued", () => {
  assert.equal(
    isClaimable(task({ execution: { status: "idle", attempts: 0 } }), new Date()),
    false,
  );
});

test("priority ranking puts high ahead of medium ahead of low", () => {
  assert.ok(PRIORITY_RANK.high > PRIORITY_RANK.medium);
  assert.ok(PRIORITY_RANK.medium > PRIORITY_RANK.low);
});

test("lease duration is positive", () => {
  assert.ok(LEASE_MS > 0);
});

test("the in-memory store claims a queued task and bumps attempts", async () => {
  const store = createInMemoryExecutionStore([
    task({ id: "a", execution: { status: "queued", attempts: 0 } }),
  ]);

  const claimed = await store.claimNext("project-1");

  assert.ok(claimed);
  assert.equal(claimed.id, "a");
  assert.equal(claimed.execution.status, "running");
  assert.equal(claimed.execution.attempts, 1);
  assert.ok(claimed.execution.leaseExpiresAt);
});

test("concurrent claims only hand a task to one worker", async () => {
  const store = createInMemoryExecutionStore([
    task({ id: "only", execution: { status: "queued", attempts: 0 } }),
  ]);

  const [first, second] = await Promise.all([
    store.claimNext("project-1"),
    store.claimNext("project-1"),
  ]);

  const claimed = [first, second].filter(Boolean);
  assert.equal(claimed.length, 1);
  assert.equal(claimed[0]?.id, "only");
});

test("an expired lease can be reclaimed by another worker", async () => {
  const past = new Date(Date.now() - LEASE_MS - 1_000);
  const store = createInMemoryExecutionStore([
    task({
      id: "orphan",
      execution: { status: "running", attempts: 1, leaseExpiresAt: past },
    }),
  ]);

  const claimed = await store.claimNext("project-1");

  assert.ok(claimed);
  assert.equal(claimed.id, "orphan");
  assert.equal(claimed.execution.attempts, 2);
});

test("a live lease cannot be reclaimed", async () => {
  const future = new Date(Date.now() + LEASE_MS);
  const store = createInMemoryExecutionStore([
    task({
      id: "busy",
      execution: { status: "running", attempts: 1, leaseExpiresAt: future },
    }),
  ]);

  assert.equal(await store.claimNext("project-1"), null);
});

test("a task at the attempts cap is never claimed again", async () => {
  const store = createInMemoryExecutionStore([
    task({
      id: "poison",
      execution: { status: "queued", attempts: MAX_ATTEMPTS },
    }),
  ]);

  assert.equal(await store.claimNext("project-1"), null);
});

test("higher priority tasks are claimed before older lower-priority ones", async () => {
  const store = createInMemoryExecutionStore([
    task({
      id: "old-low",
      priority: "low",
      createdAt: new Date("2026-01-01T00:00:00Z"),
      execution: { status: "queued", attempts: 0 },
    }),
    task({
      id: "new-high",
      priority: "high",
      createdAt: new Date("2026-01-02T00:00:00Z"),
      execution: { status: "queued", attempts: 0 },
    }),
  ]);

  const claimed = await store.claimNext("project-1");
  assert.equal(claimed?.id, "new-high");
});

test("claimNext scopes to the requested project", async () => {
  const store = createInMemoryExecutionStore([
    task({
      id: "other",
      projectId: "project-2",
      execution: { status: "queued", attempts: 0 },
    }),
  ]);

  assert.equal(await store.claimNext("project-1"), null);
});

test("heartbeat extends the lease of a running task", async () => {
  const store = createInMemoryExecutionStore([
    task({ id: "a", execution: { status: "queued", attempts: 0 } }),
  ]);
  const claimed = await store.claimNext("project-1");
  assert.ok(claimed);

  const before = claimed.execution.leaseExpiresAt!.getTime();
  await new Promise((resolve) => setTimeout(resolve, 5));
  const extended = await store.heartbeat(claimed.id);
  assert.ok(extended);
  assert.ok(extended.leaseExpiresAt!.getTime() > before);
});
