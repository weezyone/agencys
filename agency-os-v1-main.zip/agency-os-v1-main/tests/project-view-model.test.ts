import assert from "node:assert/strict";
import test from "node:test";
import { ObjectId } from "mongodb";
import { toDeliveryPlanViewModel } from "../src/lib/projects/view-model";
import type { ArtifactDoc, MilestoneDoc, TaskDoc } from "../src/lib/mongodb/types";

const PROJECT_ID = new ObjectId();
const FOUNDATION_ID = new ObjectId();
const LAUNCH_ID = new ObjectId();
const TASK_ID = new ObjectId();
const ARTIFACT_ID = new ObjectId();

function milestone(overrides: Partial<MilestoneDoc> = {}): MilestoneDoc {
  return {
    _id: FOUNDATION_ID,
    projectId: PROJECT_ID,
    title: "Foundation",
    order: 0,
    status: "todo",
    createdAt: new Date(),
    updatedAt: new Date(),
    ...overrides,
  };
}

function task(overrides: Partial<TaskDoc> = {}): TaskDoc {
  return {
    _id: TASK_ID,
    projectId: PROJECT_ID,
    milestoneId: FOUNDATION_ID,
    title: "Confirm requirements",
    status: "todo",
    priority: "medium",
    acceptanceCriteria: [],
    createdAt: new Date(),
    updatedAt: new Date(),
    ...overrides,
  };
}

function artifact(overrides: Partial<ArtifactDoc> = {}): ArtifactDoc {
  return {
    _id: ARTIFACT_ID,
    projectId: PROJECT_ID,
    taskId: TASK_ID,
    kind: "document",
    title: "Requirements brief",
    content: "Signed-off requirements.",
    metadata: { summary: "Discovery notes" },
    createdAt: new Date(),
    updatedAt: new Date(),
    ...overrides,
  };
}

test("object ids are converted to strings the client can use", () => {
  const view = toDeliveryPlanViewModel([milestone()], [task()]);

  assert.equal(view.milestones[0]?.id, FOUNDATION_ID.toString());
  assert.equal(view.tasks[0]?.milestoneId, FOUNDATION_ID.toString());
});

test("milestones come back ordered even when the source is not", () => {
  const view = toDeliveryPlanViewModel(
    [
      milestone({ _id: LAUNCH_ID, title: "Launch", order: 1 }),
      milestone({ _id: FOUNDATION_ID, title: "Foundation", order: 0 }),
    ],
    [],
  );

  assert.deepEqual(
    view.milestones.map((entry) => entry.title),
    ["Foundation", "Launch"],
  );
});

test("a task with no milestone survives the mapping as unscheduled", () => {
  const view = toDeliveryPlanViewModel([milestone()], [
    task({ milestoneId: undefined, title: "Orphan" }),
  ]);

  assert.equal(view.tasks[0]?.milestoneId, undefined);
});

test("optional task fields are preserved rather than defaulted away", () => {
  const view = toDeliveryPlanViewModel(
    [milestone()],
    [
      task({
        description: "Run the discovery call",
        ownerAgentId: "strategist-agent",
        priority: "high",
        acceptanceCriteria: ["Client signs off"],
      }),
    ],
  );

  assert.equal(view.tasks[0]?.description, "Run the discovery call");
  assert.equal(view.tasks[0]?.ownerAgentId, "strategist-agent");
  assert.equal(view.tasks[0]?.priority, "high");
  assert.deepEqual(view.tasks[0]?.acceptanceCriteria, ["Client signs off"]);
});

test("an empty project maps to an empty plan rather than throwing", () => {
  const view = toDeliveryPlanViewModel([], []);

  assert.deepEqual(view, { milestones: [], tasks: [] });
});

test("execution defaults to idle and canRun when an owner is present", () => {
  const view = toDeliveryPlanViewModel(
    [milestone()],
    [task({ ownerAgentId: "content-agent" })],
  );

  assert.equal(view.tasks[0]?.executionStatus, "idle");
  assert.equal(view.tasks[0]?.canRun, true);
});

test("queued and running tasks cannot be re-queued", () => {
  const queued = toDeliveryPlanViewModel(
    [milestone()],
    [
      task({
        ownerAgentId: "content-agent",
        execution: { status: "queued", attempts: 0 },
      }),
    ],
  );
  const running = toDeliveryPlanViewModel(
    [milestone()],
    [
      task({
        ownerAgentId: "content-agent",
        execution: { status: "running", attempts: 1 },
      }),
    ],
  );

  assert.equal(queued.tasks[0]?.canRun, false);
  assert.equal(running.tasks[0]?.canRun, false);
});

test("artifacts are attached to their task by id", () => {
  const view = toDeliveryPlanViewModel(
    [milestone()],
    [task({ ownerAgentId: "content-agent" })],
    [artifact()],
  );

  assert.equal(view.tasks[0]?.artifact?.id, ARTIFACT_ID.toString());
  assert.equal(view.tasks[0]?.artifact?.title, "Requirements brief");
  assert.equal(view.tasks[0]?.artifact?.summary, "Discovery notes");
});
