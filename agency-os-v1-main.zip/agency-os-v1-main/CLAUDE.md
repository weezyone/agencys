# CLAUDE.md

Guidance for Claude Code when working in this repository.

The instructions are maintained in a single place so they cannot drift:

@AGENTS.md
