import { ObjectId } from "mongodb";
import { collections } from "@/lib/mongodb/collections";
import { toDeliveryPlanViewModel } from "@/lib/projects/view-model";
import { ProjectDeliveryPlan } from "@/components/project-delivery-plan";

export const dynamic = "force-dynamic";

function asObjectId(value: string) {
  return ObjectId.isValid(value) ? new ObjectId(value) : undefined;
}

export default async function ProjectDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const projectId = asObjectId(id);

  if (!projectId) {
    return <div className="card">Invalid project id.</div>;
  }

  const c = await collections();
  const [project, milestones, tasks, approvals, agentRuns, artifacts] = await Promise.all([
    c.projects.findOne({ _id: projectId }),
    c.milestones.find({ projectId }).sort({ order: 1 }).toArray(),
    c.tasks.find({ projectId }).sort({ createdAt: 1 }).toArray(),
    c.approvals.find({ projectId }).sort({ createdAt: -1 }).toArray(),
    c.agentRuns.find({ projectId }).sort({ createdAt: -1 }).limit(25).toArray(),
    c.artifacts.find({ projectId }).sort({ createdAt: -1 }).limit(25).toArray(),
  ]);

  if (!project) {
    return <div className="card">Project not found.</div>;
  }

  return (
    <div>
      <span className="eyebrow">Project</span>
      <h1>{project.name}</h1>
      <p>Status: <span className="code">{project.status}</span></p>

      <section className="grid" style={{ marginTop: 24 }}>
        <article className="card">
          <h2>Goals</h2>
          <ul>{project.goals.map((goal, index) => <li key={`goal-${index}`}>{goal}</li>)}</ul>
        </article>
        <article className="card">
          <h2>Assigned agents</h2>
          <ul>{project.assignedAgentIds.map((agent, index) => <li key={`agent-${index}`}>{agent}</li>)}</ul>
        </article>
      </section>

      <section className="card" style={{ marginTop: 24 }}>
        <ProjectDeliveryPlan
          {...toDeliveryPlanViewModel(milestones, tasks, artifacts)}
        />
      </section>

      <section className="grid" style={{ marginTop: 24 }}>
        <article className="card">
          <h2>Approvals</h2>
          <ul>{approvals.map((approval) => <li key={approval._id.toString()}>{approval.title} — {approval.status}</li>)}</ul>
          {approvals.length === 0 ? <p>No approvals queued.</p> : null}
        </article>
        <article className="card">
          <h2>Agent runs</h2>
          <ul>{agentRuns.map((run) => <li key={run._id.toString()}>{run.agentId} — {run.status}</li>)}</ul>
          {agentRuns.length === 0 ? <p>No agent runs logged yet.</p> : null}
        </article>
        <article className="card">
          <h2>Artifacts</h2>
          <ul>{artifacts.map((artifact) => <li key={artifact._id.toString()}>{artifact.title} — {artifact.kind}</li>)}</ul>
          {artifacts.length === 0 ? <p>No artifacts yet.</p> : null}
        </article>
      </section>
    </div>
  );
}
