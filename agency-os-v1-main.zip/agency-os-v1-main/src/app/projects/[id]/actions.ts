"use server";

import { revalidatePath } from "next/cache";
import { ObjectId } from "mongodb";
import { mongoTaskExecutionStore } from "@/lib/tasks/execution-store";
import { isDeliveryAgentId } from "@/mastra/agents/registry";
import { collections } from "@/lib/mongodb/collections";

export type QueueTaskResult =
  | { ok: true; taskId: string }
  | { ok: false; error: string };

export async function queueTaskForExecution(formData: FormData): Promise<QueueTaskResult> {
  const taskId = String(formData.get("taskId") ?? "");
  if (!ObjectId.isValid(taskId)) {
    return { ok: false, error: "Invalid task id." };
  }

  const c = await collections();
  const task = await c.tasks.findOne({ _id: new ObjectId(taskId) });
  if (!task) {
    return { ok: false, error: "Task not found." };
  }

  if (!task.ownerAgentId || !isDeliveryAgentId(task.ownerAgentId)) {
    return {
      ok: false,
      error: "Task needs a delivery agent owner before it can be run.",
    };
  }

  const queued = await mongoTaskExecutionStore.queueTask(taskId);
  if (!queued) {
    return { ok: false, error: "Unable to queue the task." };
  }

  revalidatePath(`/projects/${task.projectId.toString()}`);
  return { ok: true, taskId };
}
