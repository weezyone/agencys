import { safeNextPath } from "@/lib/auth/policy";

export const dynamic = "force-dynamic";

function one(value: string | string[] | undefined): string | undefined {
  return Array.isArray(value) ? value[0] : value;
}

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const params = await searchParams;
  const next = safeNextPath(one(params.next));
  const hasError = one(params.error) === "1";

  return (
    <div className="card intake-panel">
      <div className="section-heading">
        <span className="eyebrow">AgencyOS</span>
        <h1>Sign in</h1>
        <p>This dashboard can approve and execute real actions in connected systems.</p>
      </div>

      <form className="intake-form" method="post" action="/api/auth/login">
        <input type="hidden" name="next" value={next} />
        <div className="form-grid">
          <div className="form-field form-field-wide">
            <label htmlFor="dashboard-password">Password</label>
            <input
              id="dashboard-password"
              name="password"
              type="password"
              autoComplete="current-password"
              required
              autoFocus
              aria-describedby={hasError ? "login-error" : undefined}
            />
          </div>
        </div>

        <div className="form-actions">
          <button className="button" type="submit">
            Sign in
          </button>
          {hasError ? (
            <p className="form-message form-error" id="login-error" role="alert">
              That password was not correct.
            </p>
          ) : null}
        </div>
      </form>
    </div>
  );
}
