import { collections } from "@/lib/mongodb/collections";
import { canTransition } from "@/lib/approvals/status";
import type { ApprovalStatus } from "@/lib/mongodb/types";
import { decideApproval, executeApprovalAction } from "./actions";

export const dynamic = "force-dynamic";

function ActionButtons({ id, status }: { id: string; status: ApprovalStatus }) {
  const canApprove = canTransition(status, "approved");
  const canReject = canTransition(status, "rejected");
  const canExecute = status === "approved";

  if (!canApprove && !canReject && !canExecute) {
    return status === "executing" ? (
      <p className="muted-small">Execution in progress…</p>
    ) : null;
  }

  return (
    <div className="actions-row">
      {canApprove ? (
        <form action={decideApproval}>
          <input type="hidden" name="approvalId" value={id} />
          <input type="hidden" name="decision" value="approved" />
          <button className="button" type="submit">
            {status === "failed" ? "Retry (approve again)" : "Approve"}
          </button>
        </form>
      ) : null}
      {canExecute ? (
        <form action={executeApprovalAction}>
          <input type="hidden" name="approvalId" value={id} />
          <button className="button" type="submit">Execute with Composio</button>
        </form>
      ) : null}
      {canReject ? (
        <form action={decideApproval}>
          <input type="hidden" name="approvalId" value={id} />
          <input type="hidden" name="decision" value="rejected" />
          <button className="button button-secondary" type="submit">Reject</button>
        </form>
      ) : null}
    </div>
  );
}

export default async function ApprovalsPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const params = await searchParams;
  const error = Array.isArray(params.error) ? params.error[0] : params.error;
  const c = await collections();
  const approvals = await c.approvals.find({}).sort({ createdAt: -1 }).limit(100).toArray();

  return (
    <div>
      <span className="eyebrow">Human-in-the-loop</span>
      <h1>Approval queue</h1>
      <p>External actions should land here before AgencyOS executes them through Composio.</p>
      {error ? <div className="notice" role="alert">Execution error: {error}</div> : null}

      <section className="stack" style={{ marginTop: 24 }}>
        {approvals.length === 0 ? (
          <article className="card"><h2>No approvals pending</h2><p>Queued external actions will appear here.</p></article>
        ) : approvals.map((approval) => {
          const id = approval._id.toString();
          return (
            <article className="card" key={id}>
              <div className="card-header">
                <h2>{approval.title}</h2>
                <span className={`status status-${approval.status}`}>{approval.status}</span>
              </div>
              <p>{approval.description}</p>
              <p className="muted-small">{approval.externalToolkit} → {approval.externalAction}</p>
              <ActionButtons id={id} status={approval.status} />
              <h3>Payload</h3>
              <pre>{JSON.stringify(approval.payload, null, 2)}</pre>
              {approval.result ? (
                <>
                  <h3>Execution result</h3>
                  <pre>{JSON.stringify(approval.result, null, 2)}</pre>
                </>
              ) : null}
            </article>
          );
        })}
      </section>
    </div>
  );
}
