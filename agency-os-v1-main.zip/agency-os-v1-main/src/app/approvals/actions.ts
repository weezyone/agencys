"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { executeApproval } from "@/lib/approvals";
import { applyApprovalDecision } from "@/lib/approvals/store";
import { isApprovalDecision } from "@/lib/approvals/status";

const APPROVALS_PATH = "/approvals";

function backToQueue(error?: string): never {
  revalidatePath(APPROVALS_PATH);
  redirect(error ? `${APPROVALS_PATH}?error=${encodeURIComponent(error)}` : APPROVALS_PATH);
}

export async function decideApproval(formData: FormData) {
  const id = String(formData.get("approvalId") ?? "");
  const decision = String(formData.get("decision") ?? "");

  if (!isApprovalDecision(decision)) {
    backToQueue("Unsupported approval action.");
  }

  const result = await applyApprovalDecision(id, decision);

  if (result.outcome === "not_found") backToQueue("Approval not found.");
  if (result.outcome === "conflict") {
    backToQueue(`An approval that is already ${result.status} cannot be ${decision}.`);
  }

  backToQueue();
}

export async function executeApprovalAction(formData: FormData) {
  const id = String(formData.get("approvalId") ?? "");
  const result = await executeApproval(id);

  backToQueue(result.ok ? undefined : result.error);
}
