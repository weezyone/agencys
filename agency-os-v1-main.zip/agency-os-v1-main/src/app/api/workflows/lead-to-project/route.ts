import {
  createLeadToProjectHandler,
  type RunLeadToProject,
} from "@/lib/workflows/lead-to-project-handler";

const runLeadToProject: RunLeadToProject = async (input) => {
  const { mastra } = await import("@/mastra");
  const workflow = mastra.getWorkflow("leadToProjectWorkflow");
  const run = await workflow.createRun();
  const outcome = await run.start({ inputData: input });

  return { runId: run.runId, outcome };
};

export const POST = createLeadToProjectHandler(runLeadToProject);
