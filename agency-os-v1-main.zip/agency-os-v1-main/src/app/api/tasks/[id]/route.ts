import { createTaskStatusHandler } from "@/lib/tasks/task-status-handler";
import { mongoTaskStatusStore } from "@/lib/tasks/mongo-status-store";
import { createTaskStatusUpdater } from "@/lib/tasks/update-status";

export const PATCH = createTaskStatusHandler(
  createTaskStatusUpdater(mongoTaskStatusStore),
);
