import { createApprovalDecisionHandler } from "@/lib/approvals/decision-handler";
import { applyApprovalDecision } from "@/lib/approvals/store";

export const PATCH = createApprovalDecisionHandler(applyApprovalDecision);
