import { cookies } from "next/headers";
import { env } from "@/lib/env";
import { currentAuthPolicy, safeNextPath } from "@/lib/auth/policy";
import {
  SESSION_COOKIE_NAME,
  SESSION_TTL_MS,
  constantTimeEquals,
  signSessionToken,
} from "@/lib/auth/session";

function redirectTo(request: Request, path: string): Response {
  return new Response(null, {
    status: 303,
    headers: { location: new URL(path, request.url).toString() },
  });
}

export async function POST(request: Request) {
  const policy = currentAuthPolicy();

  if (policy.mode === "locked") {
    return Response.json({ error: policy.reason }, { status: 503 });
  }

  if (policy.mode === "open") {
    return redirectTo(request, "/");
  }

  let form: FormData;
  try {
    form = await request.formData();
  } catch {
    return Response.json({ error: "Expected a form submission." }, { status: 400 });
  }

  const password = String(form.get("password") ?? "");
  const next = safeNextPath(
    typeof form.get("next") === "string" ? String(form.get("next")) : null,
  );

  if (!(await constantTimeEquals(password, policy.password))) {
    const retry = new URL("/login", request.url);
    retry.searchParams.set("error", "1");
    if (next !== "/") retry.searchParams.set("next", next);
    return new Response(null, {
      status: 303,
      headers: { location: retry.toString() },
    });
  }

  const token = await signSessionToken({ sub: env.agencyUserId }, policy.secret);

  // `Set-Cookie` is a forbidden response header name, so appending it to a
  // Response's Headers is silently dropped. Next's cookie store is the way in.
  const cookieStore = await cookies();
  cookieStore.set(SESSION_COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: Math.floor(SESSION_TTL_MS / 1000),
    secure: request.url.startsWith("https://"),
  });

  return redirectTo(request, next);
}
