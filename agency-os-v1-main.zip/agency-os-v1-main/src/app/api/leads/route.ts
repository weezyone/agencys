import { createLeadIntakeHandler, type CreateLead } from "@/lib/leads/intake-handler";
import { collections, nowTimestamps } from "@/lib/mongodb/collections";

const createLead: CreateLead = async (intake) => {
  const c = await collections();
  const result = await c.leads.insertOne({
    ...intake,
    status: "new",
    rawIntake: intake,
    ...nowTimestamps(),
  });

  return result.insertedId.toString();
};

export const POST = createLeadIntakeHandler(createLead);
