import { NextResponse, type NextRequest } from "next/server";
import { isCrossSiteRequest, isMutatingMethod } from "@/lib/auth/origin";
import { currentAuthPolicy, isPublicPath } from "@/lib/auth/policy";
import { SESSION_COOKIE_NAME, verifySessionToken } from "@/lib/auth/session";

function isApiPath(pathname: string): boolean {
  return pathname.startsWith("/api/");
}

export async function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;

  if (isMutatingMethod(request.method) && isCrossSiteRequest(request)) {
    return NextResponse.json(
      { error: "Cross-site request blocked." },
      { status: 403 },
    );
  }

  const policy = currentAuthPolicy();

  if (policy.mode === "open") {
    return NextResponse.next();
  }

  if (policy.mode === "locked") {
    return NextResponse.json({ error: policy.reason }, { status: 503 });
  }

  if (isPublicPath(pathname)) {
    return NextResponse.next();
  }

  const token = request.cookies.get(SESSION_COOKIE_NAME)?.value ?? "";
  const session = await verifySessionToken(token, policy.secret);

  if (session) {
    return NextResponse.next();
  }

  if (isApiPath(pathname)) {
    return NextResponse.json({ error: "Authentication required." }, { status: 401 });
  }

  const loginUrl = new URL("/login", request.url);
  loginUrl.searchParams.set("next", `${pathname}${request.nextUrl.search}`);
  return NextResponse.redirect(loginUrl);
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
