import type { Agent } from "@mastra/core/agent";
import { contentAgent } from "./content-agent";
import { designerAgent } from "./designer-agent";
import { engineerAgent } from "./engineer-agent";
import { opsAgent } from "./ops-agent";
import { pmAgent } from "./pm-agent";
import { qaAgent } from "./qa-agent";
import { strategistAgent } from "./strategist-agent";

/**
 * Agents that can own delivery tasks. Shared by the lead-to-project plan schema
 * and the task execution dispatcher so the two cannot drift.
 */
export const DELIVERY_AGENT_IDS = [
  "strategist-agent",
  "pm-agent",
  "designer-agent",
  "engineer-agent",
  "qa-agent",
  "content-agent",
  "ops-agent",
] as const;

export type DeliveryAgentId = (typeof DELIVERY_AGENT_IDS)[number];

export const agentsById: Record<DeliveryAgentId, Agent> = {
  "strategist-agent": strategistAgent,
  "pm-agent": pmAgent,
  "designer-agent": designerAgent,
  "engineer-agent": engineerAgent,
  "qa-agent": qaAgent,
  "content-agent": contentAgent,
  "ops-agent": opsAgent,
};

export function isDeliveryAgentId(value: string): value is DeliveryAgentId {
  return (DELIVERY_AGENT_IDS as readonly string[]).includes(value);
}

export function getDeliveryAgent(id: string): Agent | undefined {
  if (!isDeliveryAgentId(id)) return undefined;
  return agentsById[id];
}
