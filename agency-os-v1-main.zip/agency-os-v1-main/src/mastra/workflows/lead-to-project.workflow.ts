import { createStep, createWorkflow } from "@mastra/core/workflows";
import { z } from "zod";
import { ObjectId } from "mongodb";
import { collections, nowTimestamps } from "@/lib/mongodb/collections";
import { env } from "@/lib/env";
import { workflowIntakeSchema } from "@/lib/leads/intake";
import { withTransaction } from "@/lib/mongodb/transaction";
import { hasValidMilestoneAssignments } from "@/lib/workflows/project-plan";
import { strategistAgent, pmAgent } from "../agents";
import { DELIVERY_AGENT_IDS } from "../agents/registry";

const intakeSchema = workflowIntakeSchema;

const briefObjectSchema = z.object({
  title: z.string(),
  summary: z.string(),
  targetAudience: z.string(),
  goals: z.array(z.string()),
  recommendedOffer: z.string(),
  scope: z.array(z.string()),
  risks: z.array(z.string()),
});

const planObjectSchema = z.object({
  project: z.object({
    name: z.string(),
    type: z.enum(["landing_page", "web_app", "automation", "ai_agent", "other"]),
    assignedAgentIds: z.array(z.enum(DELIVERY_AGENT_IDS)),
  }),
  milestones: z
    .array(z.object({ title: z.string(), description: z.string() }))
    .min(2)
    .max(6),
  tasks: z
    .array(
      z.object({
        title: z.string(),
        description: z.string(),
        ownerAgentId: z.enum(DELIVERY_AGENT_IDS),
        priority: z.enum(["low", "medium", "high"]),
        acceptanceCriteria: z.array(z.string()),
        milestoneIndex: z.number().int().min(0).describe("Index into the milestones array this task belongs to"),
      }),
    )
    .min(3),
});

const leadCreatedSchema = intakeSchema.extend({ leadId: z.string() });
const briefSchema = leadCreatedSchema.extend({ briefId: z.string(), brief: briefObjectSchema });
const projectPlanSchema = briefSchema.extend(planObjectSchema.shape);

type AgentRunLog = {
  agentId: string;
  leadId: string;
  input: Record<string, unknown>;
  output?: Record<string, unknown>;
  error?: string;
};

async function logAgentRun({ agentId, leadId, input, output, error }: AgentRunLog) {
  const c = await collections();
  const now = new Date();
  await c.agentRuns.insertOne({
    agentId,
    workflowId: "lead-to-project",
    leadId: new ObjectId(leadId),
    status: error ? "failed" : "completed",
    input,
    output,
    error,
    model: env.openaiModel,
    completedAt: now,
    createdAt: now,
    updatedAt: now,
  });
}

const createLeadStep = createStep({
  id: "create-lead",
  inputSchema: intakeSchema,
  outputSchema: leadCreatedSchema,
  execute: async ({ inputData }) => {
    const c = await collections();
    const result = await c.leads.insertOne({
      ...inputData,
      status: "new",
      rawIntake: inputData,
      ...nowTimestamps(),
    });
    return { ...inputData, leadId: result.insertedId.toString() };
  },
});

const draftBriefStep = createStep({
  id: "draft-brief",
  inputSchema: leadCreatedSchema,
  outputSchema: briefSchema,
  execute: async ({ inputData }) => {
    const intake = {
      name: inputData.name,
      company: inputData.company,
      email: inputData.email,
      source: inputData.source,
      problem: inputData.problem,
      budget: inputData.budget,
      timeline: inputData.timeline,
    };

    const prompt = `New lead intake:
${JSON.stringify(intake, null, 2)}

Write a client-ready strategy brief for this lead. Ground every field in the intake — do not invent budget, timeline, or company facts that are not present. Goals should be measurable business outcomes, scope should list concrete workstreams, and risks should be specific to this engagement.`;

    try {
      const result = await strategistAgent.generate(prompt, {
        structuredOutput: { schema: briefObjectSchema },
      });
      const brief = result.object;
      if (!brief) {
        throw new Error("Strategist agent returned no structured brief.");
      }

      const c = await collections();
      const briefResult = await c.briefs.insertOne({
        leadId: new ObjectId(inputData.leadId),
        ...brief,
        ...nowTimestamps(),
      });

      await logAgentRun({ agentId: "strategist-agent", leadId: inputData.leadId, input: intake, output: brief });
      return { ...inputData, briefId: briefResult.insertedId.toString(), brief };
    } catch (error) {
      const message = error instanceof Error ? error.message : "Unknown strategist agent error.";
      await logAgentRun({ agentId: "strategist-agent", leadId: inputData.leadId, input: intake, error: message });
      throw error;
    }
  },
});

const createProjectPlanStep = createStep({
  id: "create-project-plan",
  inputSchema: briefSchema,
  outputSchema: projectPlanSchema,
  execute: async ({ inputData }) => {
    const prompt = `Strategy brief for a new engagement:
${JSON.stringify(inputData.brief, null, 2)}

Client timeline: ${inputData.timeline ?? "not specified"}. Client budget: ${inputData.budget ?? "not specified"}.

Create a project plan:
- Pick the project type that best matches the brief.
- Assign only the agents this project actually needs (available: ${DELIVERY_AGENT_IDS.join(", ")}).
- Break the work into 2-6 ordered milestones, each a client-visible outcome.
- Create tasks that roll up to milestones via milestoneIndex. Every task needs a clear owner agent and verifiable acceptance criteria.`;

    try {
      const result = await pmAgent.generate(prompt, {
        structuredOutput: { schema: planObjectSchema },
      });
      const plan = result.object;
      if (!plan) {
        throw new Error("PM agent returned no structured project plan.");
      }
      if (
        !hasValidMilestoneAssignments(
          plan.milestones.length,
          plan.tasks.map((task) => task.milestoneIndex),
        )
      ) {
        throw new Error("PM agent returned tasks with invalid milestone assignments.");
      }

      await logAgentRun({
        agentId: "pm-agent",
        leadId: inputData.leadId,
        input: { briefId: inputData.briefId, brief: inputData.brief },
        output: plan,
      });
      return { ...inputData, ...plan };
    } catch (error) {
      const message = error instanceof Error ? error.message : "Unknown PM agent error.";
      await logAgentRun({
        agentId: "pm-agent",
        leadId: inputData.leadId,
        input: { briefId: inputData.briefId, brief: inputData.brief },
        error: message,
      });
      throw error;
    }
  },
});

const persistProjectStep = createStep({
  id: "persist-project",
  inputSchema: projectPlanSchema,
  outputSchema: z.object({
    leadId: z.string(),
    briefId: z.string(),
    projectId: z.string(),
    milestoneIds: z.array(z.string()),
    taskIds: z.array(z.string()),
  }),
  execute: async ({ inputData }) => {
    const c = await collections();
    const briefId = new ObjectId(inputData.briefId);

    // A half-written plan is worse than no plan, so the project, its milestones,
    // its tasks, and the brief backlink either all land or none of them do.
    return withTransaction(async (session) => {
      const projectResult = await c.projects.insertOne(
        {
          leadId: new ObjectId(inputData.leadId),
          briefId,
          name: inputData.project.name,
          type: inputData.project.type,
          status: "planning",
          goals: inputData.brief.goals,
          assignedAgentIds: [...inputData.project.assignedAgentIds],
          ...nowTimestamps(),
        },
        { session },
      );
      const projectId = projectResult.insertedId;

      const milestoneResults = await c.milestones.insertMany(
        inputData.milestones.map((milestone, index) => ({
          projectId,
          title: milestone.title,
          description: milestone.description,
          order: index,
          status: "todo" as const,
          ...nowTimestamps(),
        })),
        { session },
      );
      const milestoneIds = Object.values(milestoneResults.insertedIds);

      const taskResults = await c.tasks.insertMany(
        inputData.tasks.map((task) => {
          const milestoneId = milestoneIds[task.milestoneIndex];
          if (!milestoneId) {
            throw new Error(
              `Task "${task.title}" references milestone ${task.milestoneIndex}, which does not exist.`,
            );
          }

          return {
            projectId,
            milestoneId,
            title: task.title,
            description: task.description,
            ownerAgentId: task.ownerAgentId,
            priority: task.priority,
            acceptanceCriteria: task.acceptanceCriteria,
            status: "todo" as const,
            ...nowTimestamps(),
          };
        }),
        { session },
      );

      await c.briefs.updateOne(
        { _id: briefId },
        { $set: { projectId, updatedAt: new Date() } },
        { session },
      );

      return {
        leadId: inputData.leadId,
        briefId: inputData.briefId,
        projectId: projectId.toString(),
        milestoneIds: milestoneIds.map((id) => id.toString()),
        taskIds: Object.values(taskResults.insertedIds).map((id) => id.toString()),
      };
    });
  },
});

export const leadToProjectWorkflow = createWorkflow({
  id: "lead-to-project",
  inputSchema: intakeSchema,
  outputSchema: z.object({
    leadId: z.string(),
    briefId: z.string(),
    projectId: z.string(),
    milestoneIds: z.array(z.string()),
    taskIds: z.array(z.string()),
  }),
})
  .then(createLeadStep)
  .then(draftBriefStep)
  .then(createProjectPlanStep)
  .then(persistProjectStep)
  .commit();
