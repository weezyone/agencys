import { ObjectId } from "mongodb";
import type { ApprovalStatus } from "@/lib/mongodb/types";

export type ApprovalRecord = {
  id: string;
  status: ApprovalStatus;
  title: string;
  description: string;
  externalToolkit: string;
  externalAction: string;
  payload: Record<string, unknown>;
  projectId?: string;
  result?: Record<string, unknown>;
};

/**
 * The outcome of trying to take ownership of an approval for execution.
 * Only "claimed" grants the right to touch the outside world, and the store
 * must guarantee that at most one caller ever receives it for a given approval.
 */
export type ApprovalClaim =
  | { outcome: "claimed"; approval: ApprovalRecord }
  | { outcome: "already_executed"; approval: ApprovalRecord }
  | { outcome: "in_flight" }
  | { outcome: "rejected" }
  | { outcome: "not_approved"; status: ApprovalStatus }
  | { outcome: "not_found" };

export type AgentRunEntry = {
  status: "completed" | "failed";
  approvalId: string;
  projectId: string;
  toolkit: string;
  action: string;
  payload: Record<string, unknown>;
  output?: Record<string, unknown>;
  error?: string;
};

export type ApprovalExecutionStore = {
  claimForExecution: (approvalId: string) => Promise<ApprovalClaim>;
  recordSuccess: (
    approvalId: string,
    result: Record<string, unknown>,
  ) => Promise<ApprovalRecord | null>;
  recordFailure: (
    approvalId: string,
    error: string,
  ) => Promise<ApprovalRecord | null>;
  logAgentRun: (entry: AgentRunEntry) => Promise<void>;
};

export type ExternalActionRunner = (
  action: string,
  payload: Record<string, unknown>,
) => Promise<unknown>;

export type ApprovalExecutorDeps = {
  store: ApprovalExecutionStore;
  createRunner: (userId?: string) => Promise<ExternalActionRunner>;
};

export type ApprovalExecutionResult =
  | {
      ok: true;
      status: 200;
      approval: ApprovalRecord | null;
      alreadyExecuted: boolean;
    }
  | {
      ok: false;
      status: 400 | 404 | 409 | 502;
      error: string;
      approval?: ApprovalRecord | null;
    };

function toRecord(value: unknown): Record<string, unknown> {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    return value as Record<string, unknown>;
  }

  return { value };
}

function describeClaimRefusal(
  claim: Exclude<ApprovalClaim, { outcome: "claimed" | "already_executed" }>,
): ApprovalExecutionResult {
  switch (claim.outcome) {
    case "not_found":
      return { ok: false, status: 404, error: "Approval not found." };
    case "rejected":
      return {
        ok: false,
        status: 409,
        error: "Rejected approvals cannot be executed.",
      };
    case "in_flight":
      return {
        ok: false,
        status: 409,
        error: "This approval is already being executed.",
      };
    case "not_approved":
      return {
        ok: false,
        status: 409,
        error: "Approval must be approved before execution.",
      };
    default: {
      const exhaustive: never = claim;
      return exhaustive;
    }
  }
}

export function createApprovalExecutor({ store, createRunner }: ApprovalExecutorDeps) {
  return async function executeApproval(
    approvalId: string,
    userId?: string,
  ): Promise<ApprovalExecutionResult> {
    if (!ObjectId.isValid(approvalId)) {
      return { ok: false, status: 400, error: "Invalid approval id." };
    }

    const claim = await store.claimForExecution(approvalId);

    if (claim.outcome === "already_executed") {
      return {
        ok: true,
        status: 200,
        approval: claim.approval,
        alreadyExecuted: true,
      };
    }

    if (claim.outcome !== "claimed") {
      return describeClaimRefusal(claim);
    }

    const { approval } = claim;

    try {
      const runner = await createRunner(userId);
      const response = toRecord(
        await runner(approval.externalAction, approval.payload),
      );
      const updated = await store.recordSuccess(approvalId, {
        ok: true,
        toolkit: approval.externalToolkit,
        action: approval.externalAction,
        response,
        executedAt: new Date().toISOString(),
      });

      if (approval.projectId) {
        await store.logAgentRun({
          status: "completed",
          approvalId,
          projectId: approval.projectId,
          toolkit: approval.externalToolkit,
          action: approval.externalAction,
          payload: approval.payload,
          output: response,
        });
      }

      return { ok: true, status: 200, approval: updated, alreadyExecuted: false };
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Unknown Composio execution error.";
      const updated = await store.recordFailure(approvalId, message);

      if (approval.projectId) {
        await store.logAgentRun({
          status: "failed",
          approvalId,
          projectId: approval.projectId,
          toolkit: approval.externalToolkit,
          action: approval.externalAction,
          payload: approval.payload,
          error: message,
        });
      }

      return { ok: false, status: 502, error: message, approval: updated };
    }
  };
}
