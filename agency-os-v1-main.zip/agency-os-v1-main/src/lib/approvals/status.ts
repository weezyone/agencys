import type { ApprovalStatus } from "@/lib/mongodb/types";

/** The two outcomes a human can choose in the approval queue. */
export const APPROVAL_DECISIONS = ["approved", "rejected"] as const;

export type ApprovalDecision = (typeof APPROVAL_DECISIONS)[number];

const ALLOWED_SOURCES: Record<ApprovalDecision, readonly ApprovalStatus[]> = {
  // "failed" is included so a human can retry an action that errored downstream.
  approved: ["pending", "failed"],
  rejected: ["pending", "approved", "failed"],
};

export function sourceStatusesFor(
  decision: ApprovalDecision,
): readonly ApprovalStatus[] {
  return ALLOWED_SOURCES[decision];
}

export function canTransition(
  from: ApprovalStatus,
  to: ApprovalDecision,
): boolean {
  return ALLOWED_SOURCES[to].includes(from);
}

export function isApprovalDecision(value: unknown): value is ApprovalDecision {
  return (
    typeof value === "string" &&
    (APPROVAL_DECISIONS as readonly string[]).includes(value)
  );
}
