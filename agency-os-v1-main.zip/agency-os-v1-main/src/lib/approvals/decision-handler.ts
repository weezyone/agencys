import { ObjectId } from "mongodb";
import { z } from "zod";
import type { ApprovalStatus } from "@/lib/mongodb/types";
import type { ApprovalRecord } from "./execute";
import { APPROVAL_DECISIONS, type ApprovalDecision } from "./status";

export type ApprovalDecisionOutcome =
  | { outcome: "updated"; approval: ApprovalRecord }
  | { outcome: "not_found" }
  | { outcome: "conflict"; status: ApprovalStatus };

export type ApplyApprovalDecision = (
  id: string,
  decision: ApprovalDecision,
) => Promise<ApprovalDecisionOutcome>;

const decisionSchema = z.object({ status: z.enum(APPROVAL_DECISIONS) });

export function createApprovalDecisionHandler(applyDecision: ApplyApprovalDecision) {
  return async function approvalDecisionPatch(
    request: Request,
    { params }: { params: Promise<{ id: string }> },
  ) {
    const { id } = await params;
    if (!ObjectId.isValid(id)) {
      return Response.json({ error: "Invalid approval id." }, { status: 400 });
    }

    let input: unknown;
    try {
      input = await request.json();
    } catch {
      return Response.json(
        { error: "Request body must be valid JSON." },
        { status: 400 },
      );
    }

    const parsed = decisionSchema.safeParse(input);
    if (!parsed.success) {
      return Response.json(
        { error: `Status must be one of: ${APPROVAL_DECISIONS.join(", ")}.` },
        { status: 400 },
      );
    }

    const result = await applyDecision(id, parsed.data.status);

    switch (result.outcome) {
      case "updated":
        return Response.json({ approval: result.approval });
      case "not_found":
        return Response.json({ error: "Approval not found." }, { status: 404 });
      case "conflict":
        return Response.json(
          {
            error: `An approval that is already ${result.status} cannot be ${parsed.data.status}.`,
          },
          { status: 409 },
        );
      default: {
        const exhaustive: never = result;
        return exhaustive;
      }
    }
  };
}
