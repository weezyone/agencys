import { ObjectId } from "mongodb";
import { collections } from "@/lib/mongodb/collections";
import type { ApprovalDoc } from "@/lib/mongodb/types";
import type {
  AgentRunEntry,
  ApprovalClaim,
  ApprovalExecutionStore,
  ApprovalRecord,
} from "./execute";
import type { ApprovalDecisionOutcome } from "./decision-handler";
import { sourceStatusesFor, type ApprovalDecision } from "./status";

function toApprovalRecord(doc: ApprovalDoc): ApprovalRecord {
  return {
    id: doc._id?.toString() ?? "",
    status: doc.status,
    title: doc.title,
    description: doc.description,
    externalToolkit: doc.externalToolkit,
    externalAction: doc.externalAction,
    payload: doc.payload,
    projectId: doc.projectId?.toString(),
    result: doc.result,
  };
}

async function claimForExecution(approvalId: string): Promise<ApprovalClaim> {
  const c = await collections();
  const _id = new ObjectId(approvalId);

  // The compare-and-swap on `status` is what makes execution single-shot:
  // only the caller that flips approved -> executing may touch the outside world.
  const claimed = await c.approvals.findOneAndUpdate(
    { _id, status: "approved" },
    { $set: { status: "executing", updatedAt: new Date() } },
    { returnDocument: "after" },
  );

  if (claimed) {
    return { outcome: "claimed", approval: toApprovalRecord(claimed) };
  }

  const existing = await c.approvals.findOne({ _id });
  if (!existing) return { outcome: "not_found" };

  switch (existing.status) {
    case "executed":
      return { outcome: "already_executed", approval: toApprovalRecord(existing) };
    case "executing":
      return { outcome: "in_flight" };
    case "rejected":
      return { outcome: "rejected" };
    case "pending":
    case "failed":
    case "approved":
      return { outcome: "not_approved", status: existing.status };
    default: {
      const exhaustive: never = existing.status;
      return { outcome: "not_approved", status: exhaustive };
    }
  }
}

export async function applyApprovalDecision(
  approvalId: string,
  decision: ApprovalDecision,
): Promise<ApprovalDecisionOutcome> {
  const c = await collections();
  const _id = new ObjectId(approvalId);

  const updated = await c.approvals.findOneAndUpdate(
    { _id, status: { $in: [...sourceStatusesFor(decision)] } },
    { $set: { status: decision, updatedAt: new Date() } },
    { returnDocument: "after" },
  );

  if (updated) return { outcome: "updated", approval: toApprovalRecord(updated) };

  const existing = await c.approvals.findOne({ _id });
  if (!existing) return { outcome: "not_found" };

  return { outcome: "conflict", status: existing.status };
}

async function setOutcome(
  approvalId: string,
  status: "executed" | "failed",
  result: Record<string, unknown>,
): Promise<ApprovalRecord | null> {
  const c = await collections();
  const updated = await c.approvals.findOneAndUpdate(
    { _id: new ObjectId(approvalId) },
    { $set: { status, result, updatedAt: new Date() } },
    { returnDocument: "after" },
  );

  return updated ? toApprovalRecord(updated) : null;
}

async function logAgentRun(entry: AgentRunEntry): Promise<void> {
  const c = await collections();
  const now = new Date();

  await c.agentRuns.insertOne({
    agentId: "ops-agent",
    workflowId: "approval-execution",
    projectId: new ObjectId(entry.projectId),
    status: entry.status,
    input: {
      approvalId: entry.approvalId,
      toolkit: entry.toolkit,
      action: entry.action,
      payload: entry.payload,
    },
    ...(entry.output ? { output: entry.output } : {}),
    ...(entry.error ? { error: entry.error } : {}),
    toolCalls: [
      { provider: "composio", toolkit: entry.toolkit, action: entry.action },
    ],
    completedAt: now,
    createdAt: now,
    updatedAt: now,
  });
}

export const mongoApprovalStore: ApprovalExecutionStore = {
  claimForExecution,
  recordSuccess: (approvalId, result) => setOutcome(approvalId, "executed", result),
  recordFailure: (approvalId, error) =>
    setOutcome(approvalId, "failed", {
      ok: false,
      error,
      failedAt: new Date().toISOString(),
    }),
  logAgentRun,
};
