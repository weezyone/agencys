import { getComposioSession } from "@/lib/composio/session";
import { createApprovalExecutor, type ExternalActionRunner } from "./execute";
import { mongoApprovalStore } from "./store";

async function createComposioRunner(userId?: string): Promise<ExternalActionRunner> {
  const session = await getComposioSession(userId);
  return (action, payload) => session.execute(action, payload);
}

export const executeApproval = createApprovalExecutor({
  store: mongoApprovalStore,
  createRunner: createComposioRunner,
});

export type { ApprovalExecutionResult, ApprovalRecord } from "./execute";
