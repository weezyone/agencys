import { z } from "zod";
import {
  firstIssueMessage,
  leadIntakeSchema,
  type LeadIntake,
} from "@/lib/leads/intake";

const leadToProjectOutputSchema = z.object({
  leadId: z.string(),
  briefId: z.string(),
  projectId: z.string(),
  milestoneIds: z.array(z.string()),
  taskIds: z.array(z.string()),
});

type LeadToProjectOutput = z.infer<typeof leadToProjectOutputSchema>;

type WorkflowOutcome =
  | { status: "success"; result: LeadToProjectOutput }
  | {
      status: "failed" | "tripwire" | "suspended" | "paused";
      error?: unknown;
    };

export type RunLeadToProject = (
  input: LeadIntake,
) => Promise<{ runId: string; outcome: WorkflowOutcome }>;

export function createLeadToProjectHandler(runWorkflow: RunLeadToProject) {
  return async function leadToProjectPost(request: Request) {
    let input: unknown;
    try {
      input = await request.json();
    } catch {
      return Response.json(
        { error: "Request body must be valid JSON." },
        { status: 400 },
      );
    }

    const parsed = leadIntakeSchema.safeParse(input);
    if (!parsed.success) {
      return Response.json(
        { error: firstIssueMessage(parsed.error, "Invalid lead intake.") },
        { status: 400 },
      );
    }

    let execution: Awaited<ReturnType<RunLeadToProject>>;
    try {
      execution = await runWorkflow(parsed.data);
    } catch {
      return Response.json(
        { error: "Unable to complete the lead-to-project workflow." },
        { status: 502 },
      );
    }

    const { runId, outcome } = execution;
    if (outcome.status !== "success") {
      return Response.json(
        { error: "Lead-to-project workflow failed.", runId },
        { status: 502 },
      );
    }

    const output = leadToProjectOutputSchema.parse(outcome.result);
    return Response.json(
      {
        workflow: "lead-to-project",
        runId,
        ...output,
      },
      { status: 201 },
    );
  };
}
