export function hasValidMilestoneAssignments(
  milestoneCount: number,
  milestoneIndexes: number[],
) {
  return (
    milestoneCount > 0 &&
    milestoneIndexes.every(
      (index) => Number.isInteger(index) && index >= 0 && index < milestoneCount,
    )
  );
}
