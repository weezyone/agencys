import type {
  ArtifactDoc,
  MilestoneDoc,
  TaskDoc,
  TaskExecutionStatus,
} from "@/lib/mongodb/types";
import type {
  ArtifactViewModel,
  MilestoneViewModel,
  TaskViewModel,
} from "@/components/project-delivery-plan";

export type DeliveryPlanViewModel = {
  milestones: MilestoneViewModel[];
  tasks: TaskViewModel[];
};

export function toDeliveryPlanViewModel(
  milestones: MilestoneDoc[],
  tasks: TaskDoc[],
  artifacts: ArtifactDoc[] = [],
): DeliveryPlanViewModel {
  const artifactsByTaskId = new Map<string, ArtifactViewModel>();

  for (const artifact of artifacts) {
    const taskId = artifact.taskId?.toString();
    if (!taskId || artifactsByTaskId.has(taskId)) continue;
    artifactsByTaskId.set(taskId, {
      id: artifact._id?.toString() ?? "",
      title: artifact.title,
      kind: artifact.kind,
      content: artifact.content,
      summary:
        typeof artifact.metadata?.summary === "string"
          ? artifact.metadata.summary
          : undefined,
    });
  }

  return {
    milestones: milestones
      .map((milestone) => ({
        id: milestone._id?.toString() ?? "",
        title: milestone.title,
        description: milestone.description,
        order: milestone.order,
        status: milestone.status,
      }))
      .sort((a, b) => a.order - b.order),
    tasks: tasks.map((task) => {
      const taskId = task._id?.toString() ?? "";
      const executionStatus: TaskExecutionStatus =
        task.execution?.status ?? "idle";

      return {
        id: taskId,
        milestoneId: task.milestoneId?.toString(),
        title: task.title,
        description: task.description,
        ownerAgentId: task.ownerAgentId,
        priority: task.priority,
        status: task.status,
        acceptanceCriteria: task.acceptanceCriteria,
        executionStatus,
        executionError: task.execution?.error,
        canRun:
          Boolean(task.ownerAgentId) &&
          executionStatus !== "queued" &&
          executionStatus !== "running",
        artifact: artifactsByTaskId.get(taskId),
      };
    }),
  };
}
