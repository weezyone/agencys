export function requireEnv(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
}

/**
 * Reads process.env on each access so standalone scripts can call loadEnv()
 * (or import the side-effect preload) before Mongo/agent code runs.
 */
export const env = {
  get appUrl() {
    return process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";
  },
  get agencyUserId() {
    return process.env.AGENCYOS_USER_ID ?? "paul";
  },
  get openaiModel() {
    return process.env.OPENAI_MODEL ?? "gpt-4.1";
  },
  get mongodbUri() {
    return process.env.MONGODB_URI ?? "mongodb://localhost:27017";
  },
  get mongodbDbName() {
    return process.env.MONGODB_DB_NAME ?? "agency_os_v1";
  },
  get composioCallbackUrl() {
    return (
      process.env.COMPOSIO_CALLBACK_URL ??
      `${process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000"}/integrations/callback`
    );
  },
};
