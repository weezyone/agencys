import { firstIssueMessage, leadIntakeSchema, type LeadIntake } from "./intake";

export type CreateLead = (intake: LeadIntake) => Promise<string>;

export function createLeadIntakeHandler(createLead: CreateLead) {
  return async function leadIntakePost(request: Request) {
    let input: unknown;
    try {
      input = await request.json();
    } catch {
      return Response.json(
        { error: "Request body must be valid JSON." },
        { status: 400 },
      );
    }

    const parsed = leadIntakeSchema.safeParse(input);
    if (!parsed.success) {
      return Response.json(
        { error: firstIssueMessage(parsed.error, "Invalid lead intake.") },
        { status: 400 },
      );
    }

    let leadId: string;
    try {
      leadId = await createLead(parsed.data);
    } catch {
      return Response.json({ error: "Unable to save the lead." }, { status: 502 });
    }

    return Response.json(
      { leadId, nextWorkflow: "lead-to-project" },
      { status: 201 },
    );
  };
}
