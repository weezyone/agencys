import { z } from "zod";

const blankToUndefined = (value: unknown) =>
  typeof value === "string" && value.trim() === "" ? undefined : value;

const optionalTrimmedString = z.preprocess(
  blankToUndefined,
  z.string().trim().optional(),
);

const optionalEmail = z.preprocess(
  blankToUndefined,
  z.string().trim().email("Email must be a valid email address.").optional(),
);

/**
 * Validation for lead intake arriving over HTTP. Browsers submit empty strings
 * for untouched optional inputs, so those are normalised away before storage.
 */
export const leadIntakeSchema = z.object({
  name: z.string().trim().min(1, "Name is required."),
  company: optionalTrimmedString,
  email: optionalEmail,
  source: optionalTrimmedString,
  problem: z.string().trim().min(1, "Problem is required."),
  budget: optionalTrimmedString,
  timeline: optionalTrimmedString,
});

/**
 * The same fields without preprocessing, for the Mastra workflow input where the
 * data has already passed `leadIntakeSchema` and the schema is exposed as JSON Schema.
 */
export const workflowIntakeSchema = z.object({
  name: z.string(),
  company: z.string().optional(),
  email: z.string().email().optional(),
  source: z.string().optional(),
  problem: z.string(),
  budget: z.string().optional(),
  timeline: z.string().optional(),
});

export type LeadIntake = z.infer<typeof leadIntakeSchema>;

export function firstIssueMessage(error: z.ZodError, fallback: string): string {
  return error.issues[0]?.message ?? fallback;
}
