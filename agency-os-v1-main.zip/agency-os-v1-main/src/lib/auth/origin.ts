const MUTATING_METHODS = new Set(["POST", "PUT", "PATCH", "DELETE"]);

export function isMutatingMethod(method: string): boolean {
  return MUTATING_METHODS.has(method.toUpperCase());
}

/**
 * Browsers always send `Origin` on cross-origin state-changing requests, so a
 * present-but-mismatched origin is the CSRF signal. A missing origin means the
 * caller is not a browser (curl, a server job), which the session cookie guards.
 * Scheme is ignored because TLS termination upstream can rewrite it.
 */
export function isCrossSiteRequest(request: Request): boolean {
  const origin = request.headers.get("origin");
  if (!origin) return false;

  const host =
    request.headers.get("x-forwarded-host") ?? request.headers.get("host");
  if (!host) return true;

  try {
    return new URL(origin).host !== host;
  } catch {
    return true;
  }
}
