export const SESSION_COOKIE_NAME = "agencyos_session";
export const SESSION_TTL_MS = 12 * 60 * 60 * 1000;

export type SessionPayload = {
  sub: string;
  exp: number;
};

const encoder = new TextEncoder();

function toBase64Url(bytes: Uint8Array): string {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
}

function fromBase64Url(value: string): Uint8Array | null {
  try {
    const padded = value.replaceAll("-", "+").replaceAll("_", "/");
    const binary = atob(padded.padEnd(Math.ceil(padded.length / 4) * 4, "="));
    return Uint8Array.from(binary, (character) => character.charCodeAt(0));
  } catch {
    return null;
  }
}

async function importKey(secret: string): Promise<CryptoKey> {
  return crypto.subtle.importKey(
    "raw",
    encoder.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign", "verify"],
  );
}

/**
 * Double-HMAC comparison: hashing both sides under a single-use random key
 * makes the comparison time independent of how many leading characters match.
 */
export async function constantTimeEquals(a: string, b: string): Promise<boolean> {
  const key = await crypto.subtle.importKey(
    "raw",
    crypto.getRandomValues(new Uint8Array(32)),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );

  const [hashedA, hashedB] = await Promise.all([
    crypto.subtle.sign("HMAC", key, encoder.encode(a)),
    crypto.subtle.sign("HMAC", key, encoder.encode(b)),
  ]);

  return toBase64Url(new Uint8Array(hashedA)) === toBase64Url(new Uint8Array(hashedB));
}

export async function signSessionToken(
  payload: { sub: string },
  secret: string,
  now = Date.now(),
): Promise<string> {
  const body: SessionPayload = { sub: payload.sub, exp: now + SESSION_TTL_MS };
  const encodedBody = toBase64Url(encoder.encode(JSON.stringify(body)));
  const key = await importKey(secret);
  const signature = await crypto.subtle.sign(
    "HMAC",
    key,
    encoder.encode(encodedBody),
  );

  return `${encodedBody}.${toBase64Url(new Uint8Array(signature))}`;
}

export async function verifySessionToken(
  token: string,
  secret: string,
  now = Date.now(),
): Promise<SessionPayload | null> {
  if (!secret) return null;

  const parts = token.split(".");
  if (parts.length !== 2) return null;

  const [encodedBody, encodedSignature] = parts;
  if (!encodedBody || !encodedSignature) return null;

  const signature = fromBase64Url(encodedSignature);
  if (!signature) return null;

  const key = await importKey(secret);
  const isValid = await crypto.subtle.verify(
    "HMAC",
    key,
    signature as unknown as ArrayBuffer,
    encoder.encode(encodedBody),
  );
  if (!isValid) return null;

  const body = fromBase64Url(encodedBody);
  if (!body) return null;

  try {
    const parsed: unknown = JSON.parse(new TextDecoder().decode(body));
    if (
      !parsed ||
      typeof parsed !== "object" ||
      typeof (parsed as SessionPayload).sub !== "string" ||
      typeof (parsed as SessionPayload).exp !== "number"
    ) {
      return null;
    }

    const payload = parsed as SessionPayload;
    return payload.exp > now ? payload : null;
  } catch {
    return null;
  }
}
