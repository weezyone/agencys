export type AuthPolicy =
  | { mode: "enforced"; password: string; secret: string }
  | { mode: "open" }
  | { mode: "locked"; reason: string };

export type AuthEnvironment = {
  nodeEnv: string | undefined;
  password: string | undefined;
  secret: string | undefined;
};

const PUBLIC_PATHS = new Set(["/login", "/api/auth/login"]);

export function isPublicPath(pathname: string): boolean {
  return PUBLIC_PATHS.has(pathname);
}

/**
 * Constrains a post-login redirect to a path on this site, so a crafted
 * `?next=` cannot bounce an authenticated operator to an attacker's page.
 */
export function safeNextPath(value: string | null | undefined): string {
  if (!value || !value.startsWith("/")) return "/";
  if (value.startsWith("//") || value.includes("\\")) return "/";
  if (isPublicPath(value)) return "/";
  return value;
}

export function resolveAuthPolicy({
  nodeEnv,
  password,
  secret,
}: AuthEnvironment): AuthPolicy {
  const trimmedPassword = password?.trim();
  const trimmedSecret = secret?.trim();

  if (trimmedPassword) {
    return {
      mode: "enforced",
      password: trimmedPassword,
      secret: trimmedSecret || trimmedPassword,
    };
  }

  if (nodeEnv === "production") {
    return {
      mode: "locked",
      reason:
        "AGENCYOS_DASHBOARD_PASSWORD is not set. Refusing to serve an unauthenticated dashboard in production.",
    };
  }

  return { mode: "open" };
}

export function currentAuthPolicy(): AuthPolicy {
  return resolveAuthPolicy({
    nodeEnv: process.env.NODE_ENV,
    password: process.env.AGENCYOS_DASHBOARD_PASSWORD,
    secret: process.env.AGENCYOS_SESSION_SECRET,
  });
}
