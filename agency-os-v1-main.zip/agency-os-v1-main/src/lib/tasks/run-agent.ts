import { getDeliveryAgent } from "@/mastra/agents/registry";
import {
  artifactOutputSchema,
  type ArtifactOutput,
  type RunAgent,
} from "./execution";

/**
 * Production agent runner: dispatches to the Mastra agent named by ownerAgentId
 * and validates the structured deliverable before the executor persists it.
 */
export const runDeliveryAgent: RunAgent = async (agentId, prompt) => {
  const agent = getDeliveryAgent(agentId);
  if (!agent) {
    throw new Error(`No delivery agent registered for "${agentId}".`);
  }

  const result = await agent.generate(prompt, {
    structuredOutput: { schema: artifactOutputSchema },
  });

  const output = result.object as ArtifactOutput | null | undefined;
  if (!output) {
    throw new Error(`${agentId} returned no structured artifact.`);
  }

  return artifactOutputSchema.parse(output);
};
