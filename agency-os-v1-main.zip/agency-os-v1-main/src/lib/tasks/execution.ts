import { z } from "zod";
import { isDeliveryAgentId } from "@/mastra/agents/registry";
import type { ClaimedTask, TaskExecutionStore } from "./execution-types";

export const ARTIFACT_KINDS = [
  "brief",
  "proposal",
  "status_report",
  "design",
  "code",
  "document",
  "other",
] as const;

export const artifactOutputSchema = z.object({
  title: z.string().trim().min(1),
  kind: z.enum(ARTIFACT_KINDS),
  content: z.string().trim().min(1),
  summary: z.string().trim().min(1),
});

export type ArtifactOutput = z.infer<typeof artifactOutputSchema>;

export type RunAgent = (
  agentId: string,
  prompt: string,
) => Promise<ArtifactOutput>;

export type TaskExecutorDeps = {
  store: TaskExecutionStore;
  runAgent: RunAgent;
};

export type TaskExecutionResult =
  | { ok: true; artifactId: string; taskId: string }
  | { ok: false; taskId: string; error: string };

export function buildTaskPrompt(task: ClaimedTask): string {
  const criteria =
    task.acceptanceCriteria.length > 0
      ? task.acceptanceCriteria.map((item) => `- ${item}`).join("\n")
      : "- (none provided)";

  return `You are completing a delivery task for AgencyOS.

Owner agent: ${task.ownerAgentId ?? "unassigned"}
Task: ${task.title}
${task.description ? `Description: ${task.description}\n` : ""}
Acceptance criteria:
${criteria}

Produce a single deliverable that satisfies the acceptance criteria.
Ground the work in the task description — do not invent client facts that are not present.
Return structured output with title, kind, content, and a short summary.`;
}

export function createTaskExecutor({ store, runAgent }: TaskExecutorDeps) {
  return async function executeTask(task: ClaimedTask): Promise<TaskExecutionResult> {
    const ownerId = task.ownerAgentId;

    if (!ownerId) {
      const error = "Task has no owner agent; cannot dispatch execution.";
      await store.markFailed(task.id, error);
      await store.logAgentRun({
        agentId: "unknown",
        projectId: task.projectId,
        taskId: task.id,
        status: "failed",
        input: { title: task.title },
        error,
      });
      return { ok: false, taskId: task.id, error };
    }

    if (!isDeliveryAgentId(ownerId)) {
      const error = `"${ownerId}" is not a delivery agent and cannot execute tasks.`;
      await store.markFailed(task.id, error);
      await store.logAgentRun({
        agentId: ownerId,
        projectId: task.projectId,
        taskId: task.id,
        status: "failed",
        input: { title: task.title },
        error,
      });
      return { ok: false, taskId: task.id, error };
    }

    const prompt = buildTaskPrompt(task);

    try {
      const output = artifactOutputSchema.parse(await runAgent(ownerId, prompt));
      const { artifactId } = await store.saveArtifact({
        projectId: task.projectId,
        taskId: task.id,
        kind: output.kind,
        title: output.title,
        content: output.content,
        metadata: { summary: output.summary, agentId: ownerId },
      });

      await store.markSucceeded(task.id, artifactId);
      await store.logAgentRun({
        agentId: ownerId,
        projectId: task.projectId,
        taskId: task.id,
        status: "completed",
        input: { title: task.title, prompt },
        output: { ...output, artifactId },
      });

      return { ok: true, artifactId, taskId: task.id };
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Unknown task execution error.";
      await store.markFailed(task.id, message);
      await store.logAgentRun({
        agentId: ownerId,
        projectId: task.projectId,
        taskId: task.id,
        status: "failed",
        input: { title: task.title, prompt },
        error: message,
      });
      return { ok: false, taskId: task.id, error: message };
    }
  };
}
