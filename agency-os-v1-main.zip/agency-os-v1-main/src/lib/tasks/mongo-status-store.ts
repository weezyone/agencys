import { ObjectId } from "mongodb";
import { collections } from "@/lib/mongodb/collections";
import type { TaskStatusStore } from "./update-status";

export const mongoTaskStatusStore: TaskStatusStore = {
  setTaskStatus: async (id, status) => {
    const c = await collections();
    const task = await c.tasks.findOneAndUpdate(
      { _id: new ObjectId(id) },
      { $set: { status, updatedAt: new Date() } },
      { returnDocument: "after" },
    );

    if (!task) return null;
    return { milestoneId: task.milestoneId?.toString() };
  },

  listMilestoneTaskStatuses: async (milestoneId) => {
    const c = await collections();
    const tasks = await c.tasks
      .find({ milestoneId: new ObjectId(milestoneId) }, { projection: { status: 1 } })
      .toArray();

    return tasks.map((task) => task.status);
  },

  setMilestoneStatus: async (milestoneId, status) => {
    const c = await collections();
    await c.milestones.updateOne(
      { _id: new ObjectId(milestoneId) },
      { $set: { status, updatedAt: new Date() } },
    );
  },
};
