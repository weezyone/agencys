import { ObjectId } from "mongodb";
import { z } from "zod";
import type { TaskStatus } from "@/lib/mongodb/types";
import { TASK_STATUSES } from "@/lib/tasks/status";

export type TaskStatusUpdateResult = {
  taskId: string;
  status: TaskStatus;
  milestoneId?: string;
  milestoneStatus?: TaskStatus;
};

export type UpdateTaskStatus = (
  id: string,
  status: TaskStatus,
) => Promise<TaskStatusUpdateResult | null>;

export function createTaskStatusHandler(updateTask: UpdateTaskStatus) {
  return async function taskStatusPatch(
    request: Request,
    { params }: { params: Promise<{ id: string }> },
  ) {
    const { id } = await params;
    if (!ObjectId.isValid(id)) {
      return Response.json({ error: "Invalid task id." }, { status: 400 });
    }

    let input: unknown;
    try {
      input = await request.json();
    } catch {
      return Response.json(
        { error: "Request body must be valid JSON." },
        { status: 400 },
      );
    }

    const parsed = z.object({ status: z.enum(TASK_STATUSES) }).safeParse(input);
    if (!parsed.success) {
      return Response.json({ error: "Invalid task status." }, { status: 400 });
    }

    const result = await updateTask(id, parsed.data.status);
    if (!result) {
      return Response.json({ error: "Task not found." }, { status: 404 });
    }

    return Response.json(result);
  };
}
