import type { TaskStatus } from "@/lib/mongodb/types";

export const TASK_STATUSES = [
  "todo",
  "in_progress",
  "blocked",
  "review",
  "done",
] as const satisfies readonly TaskStatus[];

export function deriveMilestoneStatus(statuses: TaskStatus[]): TaskStatus {
  if (statuses.length === 0 || statuses.every((status) => status === "todo")) {
    return "todo";
  }

  if (statuses.every((status) => status === "done")) {
    return "done";
  }

  if (statuses.includes("blocked")) {
    return "blocked";
  }

  if (statuses.includes("review")) {
    return "review";
  }

  return "in_progress";
}
