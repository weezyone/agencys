import type { ArtifactDoc, TaskExecution, TaskStatus } from "@/lib/mongodb/types";

export type ClaimedTask = {
  id: string;
  projectId: string;
  milestoneId?: string;
  title: string;
  description?: string;
  ownerAgentId?: string;
  priority: "low" | "medium" | "high";
  acceptanceCriteria: string[];
  status: TaskStatus;
  execution: TaskExecution;
};

export type ArtifactDraft = {
  projectId: string;
  taskId: string;
  kind: ArtifactDoc["kind"];
  title: string;
  content: string;
  metadata?: Record<string, unknown>;
};

export type TaskExecutionStore = {
  claimNext: (projectId?: string) => Promise<ClaimedTask | null>;
  heartbeat: (taskId: string) => Promise<TaskExecution | null>;
  queueTask: (taskId: string) => Promise<ClaimedTask | null>;
  saveArtifact: (draft: ArtifactDraft) => Promise<{ artifactId: string }>;
  markSucceeded: (
    taskId: string,
    artifactId: string,
  ) => Promise<ClaimedTask | null>;
  markFailed: (taskId: string, error: string) => Promise<ClaimedTask | null>;
  logAgentRun: (entry: {
    agentId: string;
    projectId: string;
    taskId: string;
    status: "completed" | "failed";
    input: Record<string, unknown>;
    output?: Record<string, unknown>;
    error?: string;
  }) => Promise<void>;
};
