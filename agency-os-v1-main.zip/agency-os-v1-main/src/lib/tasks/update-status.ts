import type { TaskStatus } from "@/lib/mongodb/types";
import { deriveMilestoneStatus } from "./status";
import type { TaskStatusUpdateResult, UpdateTaskStatus } from "./task-status-handler";

export type TaskStatusStore = {
  setTaskStatus: (
    id: string,
    status: TaskStatus,
  ) => Promise<{ milestoneId?: string } | null>;
  listMilestoneTaskStatuses: (milestoneId: string) => Promise<TaskStatus[]>;
  setMilestoneStatus: (milestoneId: string, status: TaskStatus) => Promise<void>;
};

export function createTaskStatusUpdater(store: TaskStatusStore): UpdateTaskStatus {
  return async function updateTaskStatus(id, status) {
    const task = await store.setTaskStatus(id, status);
    if (!task) return null;

    const result: TaskStatusUpdateResult = { taskId: id, status };
    if (!task.milestoneId) return result;

    const milestoneStatus = deriveMilestoneStatus(
      await store.listMilestoneTaskStatuses(task.milestoneId),
    );
    await store.setMilestoneStatus(task.milestoneId, milestoneStatus);

    return { ...result, milestoneId: task.milestoneId, milestoneStatus };
  };
}
