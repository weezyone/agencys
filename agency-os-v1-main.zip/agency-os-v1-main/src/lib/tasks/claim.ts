import type { TaskExecution, TaskExecutionStatus } from "@/lib/mongodb/types";

/** How long a worker may hold a task before another worker can reclaim it. */
export const LEASE_MS = 60_000;

/** After this many claims a poisonous task stops being offered. */
export const MAX_ATTEMPTS = 3;

export const PRIORITY_RANK = {
  high: 3,
  medium: 2,
  low: 1,
} as const;

export type ClaimableTask = {
  id: string;
  projectId: string;
  priority: keyof typeof PRIORITY_RANK;
  createdAt: Date;
  execution?: Pick<TaskExecution, "status" | "attempts" | "leaseExpiresAt">;
};

const CLAIMABLE_STATUSES: readonly TaskExecutionStatus[] = ["queued", "running"];

export function isClaimable(task: ClaimableTask, now: Date): boolean {
  const execution = task.execution;
  if (!execution) return false;
  if (!CLAIMABLE_STATUSES.includes(execution.status)) return false;
  if (execution.attempts >= MAX_ATTEMPTS) return false;

  if (execution.status === "queued") return true;

  if (execution.status === "running") {
    return Boolean(
      execution.leaseExpiresAt && execution.leaseExpiresAt.getTime() < now.getTime(),
    );
  }

  return false;
}

export function compareClaimPriority(a: ClaimableTask, b: ClaimableTask): number {
  const priorityDelta = PRIORITY_RANK[b.priority] - PRIORITY_RANK[a.priority];
  if (priorityDelta !== 0) return priorityDelta;
  return a.createdAt.getTime() - b.createdAt.getTime();
}
