import type { TaskExecution } from "@/lib/mongodb/types";
import {
  LEASE_MS,
  compareClaimPriority,
  isClaimable,
  type ClaimableTask,
} from "./claim";
import type {
  ArtifactDraft,
  ClaimedTask,
  TaskExecutionStore,
} from "./execution-types";

type MemoryTask = ClaimableTask & {
  title: string;
  description?: string;
  ownerAgentId?: string;
  acceptanceCriteria: string[];
  status: ClaimedTask["status"];
  milestoneId?: string;
  execution: TaskExecution;
};

/**
 * In-memory store that mirrors the MongoDB compare-and-swap claim semantics.
 * Used by unit tests; production uses the Mongo adapter.
 */
export function createInMemoryExecutionStore(
  seed: Array<Partial<MemoryTask> & Pick<MemoryTask, "id" | "projectId">>,
): TaskExecutionStore & { tasks: Map<string, MemoryTask>; artifacts: ArtifactDraft[] } {
  const tasks = new Map<string, MemoryTask>();
  const artifacts: ArtifactDraft[] = [];
  let artifactSeq = 0;

  for (const entry of seed) {
    tasks.set(entry.id, {
      title: entry.title ?? entry.id,
      description: entry.description,
      ownerAgentId: entry.ownerAgentId,
      acceptanceCriteria: entry.acceptanceCriteria ?? [],
      status: entry.status ?? "todo",
      milestoneId: entry.milestoneId,
      priority: entry.priority ?? "medium",
      createdAt: entry.createdAt ?? new Date(),
      execution: entry.execution ?? { status: "idle", attempts: 0 },
      id: entry.id,
      projectId: entry.projectId,
    });
  }

  function toClaimed(task: MemoryTask): ClaimedTask {
    return {
      id: task.id,
      projectId: task.projectId,
      milestoneId: task.milestoneId,
      title: task.title,
      description: task.description,
      ownerAgentId: task.ownerAgentId,
      priority: task.priority,
      acceptanceCriteria: task.acceptanceCriteria,
      status: task.status,
      execution: { ...task.execution },
    };
  }

  const store: TaskExecutionStore & {
    tasks: Map<string, MemoryTask>;
    artifacts: ArtifactDraft[];
  } = {
    tasks,
    artifacts,

    claimNext: async (projectId) => {
      const now = new Date();
      const candidates = [...tasks.values()]
        .filter((task) => (projectId ? task.projectId === projectId : true))
        .filter((task) => isClaimable(task, now))
        .sort(compareClaimPriority);

      const next = candidates[0];
      if (!next) return null;

      // Synchronous mutation is the in-memory equivalent of findOneAndUpdate CAS:
      // two concurrent awaiters that both saw the task as claimable still race here
      // on a single-threaded event loop, and only the first mutator wins.
      if (!isClaimable(next, now)) return null;

      next.execution = {
        ...next.execution,
        status: "running",
        attempts: next.execution.attempts + 1,
        startedAt: next.execution.startedAt ?? now,
        leaseExpiresAt: new Date(now.getTime() + LEASE_MS),
        error: undefined,
      };
      next.status = "in_progress";
      return toClaimed(next);
    },

    heartbeat: async (taskId) => {
      const task = tasks.get(taskId);
      if (!task || task.execution.status !== "running") return null;
      task.execution = {
        ...task.execution,
        leaseExpiresAt: new Date(Date.now() + LEASE_MS),
      };
      return { ...task.execution };
    },

    queueTask: async (taskId) => {
      const task = tasks.get(taskId);
      if (!task) return null;
      if (
        task.execution.status === "running" ||
        task.execution.status === "queued"
      ) {
        return toClaimed(task);
      }
      // Human re-queue is an intentional retry: clear the attempt counter so a
      // task that hit MAX_ATTEMPTS is claimable again.
      task.execution = {
        status: "queued",
        attempts: 0,
      };
      return toClaimed(task);
    },

    saveArtifact: async (draft) => {
      artifacts.push(draft);
      artifactSeq += 1;
      return { artifactId: `artifact-${artifactSeq}` };
    },

    markSucceeded: async (taskId, _artifactId) => {
      const task = tasks.get(taskId);
      if (!task) return null;
      task.execution = {
        ...task.execution,
        status: "succeeded",
        finishedAt: new Date(),
        leaseExpiresAt: undefined,
        error: undefined,
      };
      task.status = "review";
      return toClaimed(task);
    },

    markFailed: async (taskId, error) => {
      const task = tasks.get(taskId);
      if (!task) return null;
      task.execution = {
        ...task.execution,
        status: "failed",
        finishedAt: new Date(),
        leaseExpiresAt: undefined,
        error,
      };
      return toClaimed(task);
    },

    logAgentRun: async () => {},
  };

  return store;
}
