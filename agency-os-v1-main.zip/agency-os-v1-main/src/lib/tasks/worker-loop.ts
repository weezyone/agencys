import { LEASE_MS } from "./claim";
import { createTaskExecutor } from "./execution";
import type { RunAgent } from "./execution";
import type { TaskExecutionStore } from "./execution-types";

export type WorkerLoopOptions = {
  store: TaskExecutionStore;
  runAgent: RunAgent;
  /** Optional project scope; omit to claim across all projects. */
  projectId?: string;
  pollIntervalMs?: number;
  /** Injected for tests; defaults to setTimeout. */
  sleep?: (ms: number) => Promise<void>;
  /** Called once per completed (ok or failed) execution. */
  onResult?: (result: { ok: boolean; taskId: string; error?: string }) => void;
};

const defaultSleep = (ms: number) =>
  new Promise<void>((resolve) => {
    setTimeout(resolve, ms);
  });

/**
 * Polls for claimable tasks, heartbeats the lease while the agent runs, and
 * stops when `signal` is aborted. Pure enough to unit-test with fakes.
 */
export function createWorkerLoop(options: WorkerLoopOptions) {
  const {
    store,
    runAgent,
    projectId,
    pollIntervalMs = 2_000,
    sleep = defaultSleep,
    onResult,
  } = options;

  const execute = createTaskExecutor({ store, runAgent });

  return async function runWorkerLoop(signal: AbortSignal): Promise<void> {
    while (!signal.aborted) {
      const claimed = await store.claimNext(projectId);

      if (!claimed) {
        await sleep(pollIntervalMs);
        continue;
      }

      const heartbeatTimer = setInterval(() => {
        void store.heartbeat(claimed.id);
      }, Math.max(1_000, Math.floor(LEASE_MS / 3)));

      try {
        const result = await execute(claimed);
        onResult?.(
          result.ok
            ? { ok: true, taskId: result.taskId }
            : { ok: false, taskId: result.taskId, error: result.error },
        );
      } finally {
        clearInterval(heartbeatTimer);
      }
    }
  };
}
