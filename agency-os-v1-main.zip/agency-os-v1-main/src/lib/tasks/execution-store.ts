import { ObjectId } from "mongodb";
import { collections, nowTimestamps } from "@/lib/mongodb/collections";
import { env } from "@/lib/env";
import type { TaskDoc } from "@/lib/mongodb/types";
import { LEASE_MS, MAX_ATTEMPTS, compareClaimPriority } from "./claim";
import type {
  ArtifactDraft,
  ClaimedTask,
  TaskExecutionStore,
} from "./execution-types";
import { mongoTaskStatusStore } from "./mongo-status-store";
import { createTaskStatusUpdater } from "./update-status";

const updateTaskStatus = createTaskStatusUpdater(mongoTaskStatusStore);

function toClaimed(task: TaskDoc): ClaimedTask | null {
  if (!task._id || !task.execution) return null;
  return {
    id: task._id.toString(),
    projectId: task.projectId.toString(),
    milestoneId: task.milestoneId?.toString(),
    title: task.title,
    description: task.description,
    ownerAgentId: task.ownerAgentId,
    priority: task.priority,
    acceptanceCriteria: task.acceptanceCriteria,
    status: task.status,
    execution: task.execution,
  };
}

function claimFilter(projectId: string | undefined, now: Date) {
  return {
    ...(projectId ? { projectId: new ObjectId(projectId) } : {}),
    "execution.attempts": { $lt: MAX_ATTEMPTS },
    $or: [
      { "execution.status": "queued" },
      {
        "execution.status": "running",
        "execution.leaseExpiresAt": { $lt: now },
      },
    ],
  };
}

async function claimNext(projectId?: string): Promise<ClaimedTask | null> {
  const c = await collections();
  const now = new Date();

  // Priority is a string enum, so we fetch a small batch and rank in process,
  // then CAS-claim the winner by id so two workers cannot both take it.
  const candidates = await c.tasks.find(claimFilter(projectId, now)).limit(25).toArray();
  if (candidates.length === 0) return null;

  const ranked = [...candidates].sort((a, b) =>
    compareClaimPriority(
      {
        id: a._id?.toString() ?? "",
        projectId: a.projectId.toString(),
        priority: a.priority,
        createdAt: a.createdAt,
        execution: a.execution,
      },
      {
        id: b._id?.toString() ?? "",
        projectId: b.projectId.toString(),
        priority: b.priority,
        createdAt: b.createdAt,
        execution: b.execution,
      },
    ),
  );

  for (const candidate of ranked) {
    if (!candidate._id) continue;

    const claimed = await c.tasks.findOneAndUpdate(
      {
        _id: candidate._id,
        ...claimFilter(projectId, now),
      },
      {
        $set: {
          status: "in_progress",
          "execution.status": "running",
          "execution.leaseExpiresAt": new Date(now.getTime() + LEASE_MS),
          "execution.startedAt": candidate.execution?.startedAt ?? now,
          updatedAt: now,
        },
        $inc: { "execution.attempts": 1 },
        $unset: { "execution.error": "" },
      },
      { returnDocument: "after" },
    );

    if (claimed) return toClaimed(claimed);
  }

  return null;
}

async function heartbeat(taskId: string) {
  const c = await collections();
  const now = new Date();
  const updated = await c.tasks.findOneAndUpdate(
    { _id: new ObjectId(taskId), "execution.status": "running" },
    {
      $set: {
        "execution.leaseExpiresAt": new Date(now.getTime() + LEASE_MS),
        updatedAt: now,
      },
    },
    { returnDocument: "after" },
  );

  return updated?.execution ?? null;
}

async function queueTask(taskId: string): Promise<ClaimedTask | null> {
  if (!ObjectId.isValid(taskId)) return null;

  const c = await collections();
  const now = new Date();
  const _id = new ObjectId(taskId);
  const existing = await c.tasks.findOne({ _id });
  if (!existing) return null;

  if (
    existing.execution?.status === "queued" ||
    existing.execution?.status === "running"
  ) {
    return toClaimed(existing);
  }

  const updated = await c.tasks.findOneAndUpdate(
    {
      _id,
      $or: [
        { execution: { $exists: false } },
        { "execution.status": { $nin: ["queued", "running"] } },
      ],
    },
    {
      $set: {
        // Human re-queue is an intentional retry: clear the attempt counter so
        // a task that hit MAX_ATTEMPTS is claimable again.
        execution: {
          status: "queued",
          attempts: 0,
        },
        updatedAt: now,
      },
    },
    { returnDocument: "after" },
  );

  return updated ? toClaimed(updated) : toClaimed(existing);
}

async function saveArtifact(draft: ArtifactDraft) {
  const c = await collections();
  const result = await c.artifacts.insertOne({
    projectId: new ObjectId(draft.projectId),
    taskId: new ObjectId(draft.taskId),
    kind: draft.kind,
    title: draft.title,
    content: draft.content,
    metadata: draft.metadata,
    ...nowTimestamps(),
  });

  return { artifactId: result.insertedId.toString() };
}

async function markSucceeded(taskId: string, artifactId: string) {
  const c = await collections();
  const now = new Date();

  const updated = await c.tasks.findOneAndUpdate(
    { _id: new ObjectId(taskId) },
    {
      $set: {
        status: "review",
        "execution.status": "succeeded",
        "execution.finishedAt": now,
        "execution.artifactId": new ObjectId(artifactId),
        updatedAt: now,
      },
      $unset: { "execution.leaseExpiresAt": "", "execution.error": "" },
    },
    { returnDocument: "after" },
  );

  if (!updated) return null;

  // Roll the milestone up through the shared status updater (status is already
  // "review"; the updater still recomputes the parent milestone).
  await updateTaskStatus(taskId, "review");
  const refreshed = await c.tasks.findOne({ _id: new ObjectId(taskId) });
  return refreshed ? toClaimed(refreshed) : toClaimed(updated);
}

async function markFailed(taskId: string, error: string) {
  const c = await collections();
  const now = new Date();
  const updated = await c.tasks.findOneAndUpdate(
    { _id: new ObjectId(taskId) },
    {
      $set: {
        "execution.status": "failed",
        "execution.finishedAt": now,
        "execution.error": error,
        updatedAt: now,
      },
      $unset: { "execution.leaseExpiresAt": "" },
    },
    { returnDocument: "after" },
  );

  return updated ? toClaimed(updated) : null;
}

async function logAgentRun(entry: {
  agentId: string;
  projectId: string;
  taskId: string;
  status: "completed" | "failed";
  input: Record<string, unknown>;
  output?: Record<string, unknown>;
  error?: string;
}) {
  const c = await collections();
  const now = new Date();

  await c.agentRuns.insertOne({
    agentId: entry.agentId,
    workflowId: "task-execution",
    projectId: new ObjectId(entry.projectId),
    status: entry.status,
    input: { ...entry.input, taskId: entry.taskId },
    ...(entry.output ? { output: entry.output } : {}),
    ...(entry.error ? { error: entry.error } : {}),
    model: env.openaiModel,
    completedAt: now,
    createdAt: now,
    updatedAt: now,
  });
}

export const mongoTaskExecutionStore: TaskExecutionStore = {
  claimNext,
  heartbeat,
  queueTask,
  saveArtifact,
  markSucceeded,
  markFailed,
  logAgentRun,
};
