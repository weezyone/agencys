import type { ClientSession } from "mongodb";
import { getMongoClient } from "./client";

const UNSUPPORTED_MESSAGE =
  /replica set member or mongos|does not support (transactions|sessions|retryable writes)/i;

/**
 * A standalone mongod (the common local-dev setup) rejects transactions outright.
 * Atlas and any replica set accept them, so we detect the standalone case and
 * degrade instead of making a replica set a hard requirement for `npm run dev`.
 */
export function isTransactionUnsupported(error: unknown): boolean {
  if (!(error instanceof Error)) return false;

  const code = (error as { code?: unknown }).code;
  if (code === 20) return true;

  return UNSUPPORTED_MESSAGE.test(error.message);
}

/**
 * Runs `work` inside a transaction where the deployment supports one, and falls
 * back to unsynchronised writes where it does not. Callers must pass the session
 * through to every write so the transactional path is genuinely atomic.
 */
export async function withTransaction<T>(
  work: (session?: ClientSession) => Promise<T>,
): Promise<T> {
  const client = await getMongoClient();
  const session = client.startSession();

  try {
    let result: T | undefined;
    await session.withTransaction(async () => {
      result = await work(session);
    });
    return result as T;
  } catch (error) {
    if (!isTransactionUnsupported(error)) throw error;
    return work(undefined);
  } finally {
    await session.endSession();
  }
}
