import type { TaskExecutionStatus, TaskStatus } from "@/lib/mongodb/types";
import { TaskStatusControl } from "@/components/task-status-control";
import { TaskRunControl } from "@/components/task-run-control";

export type MilestoneViewModel = {
  id: string;
  title: string;
  description?: string;
  order: number;
  status: TaskStatus;
};

export type ArtifactViewModel = {
  id: string;
  title: string;
  kind: string;
  content?: string;
  summary?: string;
};

export type TaskViewModel = {
  id: string;
  milestoneId?: string;
  title: string;
  description?: string;
  ownerAgentId?: string;
  priority: "low" | "medium" | "high";
  status: TaskStatus;
  acceptanceCriteria: string[];
  executionStatus: TaskExecutionStatus;
  executionError?: string;
  canRun: boolean;
  artifact?: ArtifactViewModel;
};

export type ProjectDeliveryPlanProps = {
  milestones: MilestoneViewModel[];
  tasks: TaskViewModel[];
};

const EXECUTION_LABELS: Record<TaskExecutionStatus, string> = {
  idle: "idle",
  queued: "queued",
  running: "running",
  succeeded: "succeeded",
  failed: "failed",
};

function TaskRow({ task }: { task: TaskViewModel }) {
  return (
    <div className="delivery-task">
      <div className="delivery-task-copy">
        <strong>{task.title}</strong>
        {task.description ? <p>{task.description}</p> : null}
        <p className="muted-small">
          Owner: {task.ownerAgentId ?? "unassigned"} • Priority: {task.priority}
        </p>
        <p className="muted-small">
          Execution:{" "}
          <span className={`status status-${task.executionStatus}`}>
            {EXECUTION_LABELS[task.executionStatus]}
          </span>
        </p>
        {task.executionError ? (
          <p className="task-status-error" role="alert">
            {task.executionError}
          </p>
        ) : null}
        {task.acceptanceCriteria.length > 0 ? (
          <details>
            <summary>Acceptance criteria</summary>
            <ul>
              {task.acceptanceCriteria.map((criterion, index) => (
                <li key={`${task.id}-criterion-${index}`}>{criterion}</li>
              ))}
            </ul>
          </details>
        ) : null}
        {task.artifact ? (
          <details open={task.executionStatus === "succeeded"}>
            <summary>
              Artifact: {task.artifact.title} ({task.artifact.kind})
            </summary>
            {task.artifact.summary ? (
              <p className="muted-small">{task.artifact.summary}</p>
            ) : null}
            {task.artifact.content ? (
              <pre className="artifact-content">{task.artifact.content}</pre>
            ) : null}
          </details>
        ) : null}
      </div>
      <div className="delivery-task-controls">
        <TaskStatusControl
          taskId={task.id}
          taskTitle={task.title}
          initialStatus={task.status}
        />
        <TaskRunControl
          taskId={task.id}
          ownerAgentId={task.ownerAgentId}
          canRun={task.canRun}
          executionStatus={task.executionStatus}
        />
      </div>
    </div>
  );
}

function groupTasksByMilestone(
  tasks: TaskViewModel[],
  milestoneIds: ReadonlySet<string>,
): { grouped: Map<string, TaskViewModel[]>; unscheduled: TaskViewModel[] } {
  const grouped = new Map<string, TaskViewModel[]>();
  const unscheduled: TaskViewModel[] = [];

  for (const task of tasks) {
    if (!task.milestoneId || !milestoneIds.has(task.milestoneId)) {
      unscheduled.push(task);
      continue;
    }

    const existing = grouped.get(task.milestoneId);
    if (existing) existing.push(task);
    else grouped.set(task.milestoneId, [task]);
  }

  return { grouped, unscheduled };
}

export function ProjectDeliveryPlan({
  milestones,
  tasks,
}: ProjectDeliveryPlanProps) {
  const orderedMilestones = [...milestones].sort((a, b) => a.order - b.order);
  const milestoneIds = new Set(orderedMilestones.map((milestone) => milestone.id));
  const { grouped, unscheduled: unscheduledTasks } = groupTasksByMilestone(
    tasks,
    milestoneIds,
  );

  return (
    <section className="delivery-plan" aria-labelledby="delivery-plan-heading">
      <div className="card-header">
        <div>
          <span className="eyebrow">Execution</span>
          <h2 id="delivery-plan-heading">Milestones and tasks</h2>
        </div>
        <span className="badge">
          {milestones.length} milestone{milestones.length === 1 ? "" : "s"}
        </span>
      </div>

      <div className="milestone-list">
        {orderedMilestones.map((milestone) => {
          const milestoneTasks = grouped.get(milestone.id) ?? [];

          return (
            <article className="milestone-card" key={milestone.id}>
              <header className="card-header">
                <div>
                  <span className="milestone-index">
                    Milestone {milestone.order + 1}
                  </span>
                  <h3>{milestone.title}</h3>
                  {milestone.description ? <p>{milestone.description}</p> : null}
                </div>
                <span className={`status status-${milestone.status}`}>
                  {milestone.status}
                </span>
              </header>

              <div className="milestone-tasks">
                {milestoneTasks.map((task) => (
                  <TaskRow key={task.id} task={task} />
                ))}
                {milestoneTasks.length === 0 ? (
                  <p className="muted-small">No tasks assigned to this milestone.</p>
                ) : null}
              </div>
            </article>
          );
        })}

        {orderedMilestones.length === 0 ? (
          <div className="notice">No milestones have been generated yet.</div>
        ) : null}

        {unscheduledTasks.length > 0 ? (
          <article className="milestone-card">
            <header>
              <span className="milestone-index">Needs planning</span>
              <h3>Unscheduled tasks</h3>
            </header>
            <div className="milestone-tasks">
              {unscheduledTasks.map((task) => (
                <TaskRow key={task.id} task={task} />
              ))}
            </div>
          </article>
        ) : null}
      </div>
    </section>
  );
}
