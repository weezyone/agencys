"use client";

import { useState, type FormEvent } from "react";

type LeadToProjectResponse = {
  projectId?: string;
  error?: string;
};

export function LeadIntakeForm() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState("");
  const [hasError, setHasError] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsSubmitting(true);
    setHasError(false);
    setMessage("The Strategist and PM agents are preparing the project.");

    const form = new FormData(event.currentTarget);
    const payload = {
      name: String(form.get("name") ?? ""),
      company: String(form.get("company") ?? ""),
      email: String(form.get("email") ?? ""),
      source: "dashboard",
      problem: String(form.get("problem") ?? ""),
      budget: String(form.get("budget") ?? ""),
      timeline: String(form.get("timeline") ?? ""),
    };

    try {
      const response = await fetch("/api/workflows/lead-to-project", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload),
      });
      const result = (await response.json()) as LeadToProjectResponse;

      if (!response.ok || !result.projectId) {
        throw new Error(result.error ?? "Unable to create the project.");
      }

      setMessage("Project created. Opening the delivery workspace.");
      window.location.assign(`/projects/${encodeURIComponent(result.projectId)}`);
    } catch (error) {
      setHasError(true);
      setMessage(
        error instanceof Error ? error.message : "Unable to create the project.",
      );
      setIsSubmitting(false);
    }
  }

  return (
    <form className="intake-form" onSubmit={handleSubmit} aria-busy={isSubmitting}>
      <div className="form-grid">
        <div className="form-field">
          <label htmlFor="lead-name">Your name</label>
          <input id="lead-name" name="name" autoComplete="name" required />
        </div>

        <div className="form-field">
          <label htmlFor="lead-company">Company</label>
          <input id="lead-company" name="company" autoComplete="organization" />
        </div>

        <div className="form-field">
          <label htmlFor="lead-email">Email</label>
          <input id="lead-email" name="email" type="email" autoComplete="email" />
        </div>

        <div className="form-field">
          <label htmlFor="lead-budget">Budget or range</label>
          <input id="lead-budget" name="budget" placeholder="e.g. $15k–$25k" />
        </div>

        <div className="form-field form-field-wide">
          <label htmlFor="lead-problem">What should we solve?</label>
          <textarea
            id="lead-problem"
            name="problem"
            rows={5}
            required
            placeholder="Describe the business problem, audience, and desired outcome."
          />
        </div>

        <div className="form-field form-field-wide">
          <label htmlFor="lead-timeline">Timeline</label>
          <input
            id="lead-timeline"
            name="timeline"
            placeholder="e.g. MVP in six weeks"
          />
        </div>
      </div>

      <div className="form-actions">
        <button className="button" type="submit" disabled={isSubmitting}>
          {isSubmitting ? "Planning project…" : "Start planning"}
        </button>
        <p
          className={hasError ? "form-message form-error" : "form-message"}
          role="status"
          aria-live={hasError ? "assertive" : "polite"}
        >
          {message || "Required fields are marked by the browser."}
        </p>
      </div>
    </form>
  );
}
