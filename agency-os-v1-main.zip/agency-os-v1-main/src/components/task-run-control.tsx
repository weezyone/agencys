"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { queueTaskForExecution } from "@/app/projects/[id]/actions";

export type TaskRunControlProps = {
  taskId: string;
  ownerAgentId?: string;
  canRun: boolean;
  executionStatus: string;
};

export function TaskRunControl({
  taskId,
  ownerAgentId,
  canRun,
  executionStatus,
}: TaskRunControlProps) {
  const router = useRouter();
  const [error, setError] = useState("");
  const [isPending, startTransition] = useTransition();

  if (executionStatus === "queued" || executionStatus === "running") {
    return (
      <p className="muted-small" aria-live="polite">
        {executionStatus === "queued"
          ? "Queued for the worker…"
          : "Agent is working…"}
      </p>
    );
  }

  if (!canRun) {
    return (
      <p className="muted-small">
        {ownerAgentId ? "Already ran." : "Assign an owner agent to run."}
      </p>
    );
  }

  const isRetry = executionStatus === "failed" || executionStatus === "succeeded";
  const label = isPending
    ? "Queuing…"
    : isRetry
      ? `Retry with ${ownerAgentId ?? "agent"}`
      : `Run with ${ownerAgentId ?? "agent"}`;

  return (
    <form
      action={(formData) => {
        setError("");
        startTransition(async () => {
          const result = await queueTaskForExecution(formData);
          if (!result.ok) {
            setError(result.error);
            return;
          }
          router.refresh();
        });
      }}
    >
      <input type="hidden" name="taskId" value={taskId} />
      <button className="button button-secondary button-small" type="submit" disabled={isPending}>
        {label}
      </button>
      {error ? (
        <span className="task-status-error" role="alert">
          {error}
        </span>
      ) : null}
    </form>
  );
}
