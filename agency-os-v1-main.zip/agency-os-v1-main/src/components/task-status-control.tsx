"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition, type ChangeEvent } from "react";
import type { TaskStatus } from "@/lib/mongodb/types";
import { TASK_STATUSES } from "@/lib/tasks/status";

const STATUS_LABELS: Record<TaskStatus, string> = {
  todo: "To do",
  in_progress: "In progress",
  blocked: "Blocked",
  review: "In review",
  done: "Done",
};

export type TaskStatusControlProps = {
  taskId: string;
  taskTitle: string;
  initialStatus: TaskStatus;
};

export function TaskStatusControl({
  taskId,
  taskTitle,
  initialStatus,
}: TaskStatusControlProps) {
  const router = useRouter();
  const [status, setStatus] = useState(initialStatus);
  const [isSaving, setIsSaving] = useState(false);
  const [isRefreshing, startRefresh] = useTransition();
  const [error, setError] = useState("");

  async function handleChange(event: ChangeEvent<HTMLSelectElement>) {
    const nextStatus = event.target.value as TaskStatus;
    const previousStatus = status;
    setStatus(nextStatus);
    setIsSaving(true);
    setError("");

    try {
      const response = await fetch(`/api/tasks/${encodeURIComponent(taskId)}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ status: nextStatus }),
      });
      const result = (await response.json()) as { error?: string };

      if (!response.ok) {
        throw new Error(result.error ?? "Unable to update the task.");
      }

      // Re-render the server component so the milestone rollup reflects this change,
      // without discarding the page the way a full reload would.
      startRefresh(() => router.refresh());
    } catch (saveError) {
      setStatus(previousStatus);
      setError(
        saveError instanceof Error ? saveError.message : "Unable to update the task.",
      );
    } finally {
      setIsSaving(false);
    }
  }

  return (
    <label className="task-status-control">
      <span className="sr-only">Status for {taskTitle}</span>
      <select
        className="task-status-select"
        value={status}
        onChange={handleChange}
        disabled={isSaving || isRefreshing}
        aria-describedby={error ? `task-${taskId}-error` : undefined}
      >
        {TASK_STATUSES.map((option) => (
          <option key={option} value={option}>
            {STATUS_LABELS[option]}
          </option>
        ))}
      </select>
      {error ? (
        <span className="task-status-error" id={`task-${taskId}-error`} role="alert">
          {error}
        </span>
      ) : null}
    </label>
  );
}
