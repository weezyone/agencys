# AGENTS.md

This file provides guidance to Codex (Codex.ai/code) when working with code in this repository.

## Commands

This project installs with **pnpm**. Do not add a `package-lock.json`.

```bash
pnpm dev              # Next.js dev server (port 3000)
pnpm dev:mastra       # Mastra Studio — local agent development UI
pnpm build            # Production build
pnpm test             # node:test via tsx
pnpm typecheck        # tsc --noEmit (no separate lint command)
pnpm db:indexes       # Create/update all MongoDB indexes (run after schema changes)
pnpm worker           # Durable task execution worker (polls MongoDB, runs owner agents)
```

Tests live in `tests/**/*.test.ts`. TypeScript strict mode (including `noUncheckedIndexedAccess`) and Zod runtime validation are the other correctness mechanisms.

## Architecture Overview

Agency OS is a **human-in-the-loop AI agency platform**. A team of 8 specialized Mastra agents (Sales, Strategist, PM, Designer, Engineer, QA, Content, Ops) processes client work but cannot directly mutate external systems — they must queue an `ApprovalDoc` first, which a human approves through the dashboard before Composio executes it.

### Layers

| Layer | Location | Role |
|---|---|---|
| Dashboard UI | `src/app/` | Next.js App Router pages — overview, projects, approvals, integrations |
| API routes | `src/app/api/` | Lead intake, workflow triggers, approval lifecycle (approve/reject/execute) |
| Agents | `src/mastra/agents/` | 8 role-specific agents sharing `agencyOperatingRules` from `instructions.ts` |
| Tools | `src/mastra/tools/agency-tools.ts` | 4 typed Zod tools agents call: `createLeadTool`, `createProjectTool`, `createTaskTool`, `queueExternalApprovalTool` |
| Workflows | `src/mastra/workflows/` | Mastra workflow orchestration (currently: `lead-to-project`) |
| Persistence | `src/lib/mongodb/` | MongoDB Atlas — sole source of truth for all domain state |
| Integrations | `src/lib/composio/` | Per-user Composio OAuth sessions; execution only happens post-approval |

### Core Data Flow

```
POST /api/workflows/lead-to-project
  → [Step 1] createLead → LeadDoc (status="new")
  → [Step 2] strategist-agent drafts → BriefDoc
  → [Step 3] pm-agent plans → ProjectDoc + MilestoneDocs + TaskDocs
  → [Step 4] persist all to MongoDB in one transaction

Agent queues action → ApprovalDoc (status="pending")
  → Dashboard /approvals → human approves (status="approved")
  → executeApproval() atomically claims it (status="executing")
  → Composio session → external action
  → ApprovalDoc (status="executed" | "failed") + AgentRunDoc logged
```

### MongoDB Collections & Types

All types are in `src/lib/mongodb/types.ts`. The 10 collections are:

- **leads** / **clients** — intake and converted clients
- **briefs** — strategy briefs produced by the Strategist agent
- **projects** / **milestones** / **tasks** — the project hierarchy; tasks carry an optional `execution` sub-document (idle/queued/running/succeeded/failed) used by the durable worker
- **artifacts** — deliverables produced by task execution (briefs, proposals, designs, code, docs), keyed by `taskId`
- **agentRuns** — execution logs per agent call
- **integrationConnections** — per-user OAuth state (Composio)
- **approvals** — external action queue (pending/approved/executing/executed/failed/rejected)

Access collections through the typed accessors in `src/lib/mongodb/collections.ts`, not the raw client.

### Mastra Setup

`src/mastra/index.ts` exports the singleton `Mastra` instance. It registers all agents and workflows, and uses `MongoDBStore` + `MongoDBVector` for runtime memory.

Agents are defined in `src/mastra/agents/` — each imports shared `agencyOperatingRules` and a role-specific instruction from `instructions.ts`. All agents use OpenAI (model configurable via `OPENAI_MODEL` env var, defaults to `gpt-4.1`).

### Approval Execution

`src/lib/approvals/` is split so the risky part is testable without a database:

- `execute.ts` — `createApprovalExecutor()`, the pure execution logic
- `store.ts` — the MongoDB adapter, including the atomic `approved → executing` claim
- `status.ts` — which status transitions a human is allowed to make
- `index.ts` — production wiring (`executeApproval`)

Execution must stay single-shot. Only the caller that wins the compare-and-swap
in `claimForExecution` may touch an external system.

### Task Execution

`src/lib/tasks/execution.ts` and `src/lib/tasks/execution-store.ts` implement the
durable task loop. A task is claimed with a compare-and-swap + lease on its
`execution` sub-document; `scripts/worker.ts` (`pnpm worker`) polls, dispatches
to the agent named in `ownerAgentId` via `src/mastra/agents/registry.ts`, and
writes an `ArtifactDoc`. History still goes to `agentRuns`.

### Authentication

`src/proxy.ts` (the Next 16 replacement for `middleware.ts`) gates every route.
`src/lib/auth/` holds the session token, policy, and origin checks. Without
`AGENCYOS_DASHBOARD_PASSWORD` the app is open in development and refuses to
serve in production.

## Environment Variables

See `.env.example`. Required at runtime:

```
OPENAI_API_KEY
COMPOSIO_API_KEY
MONGODB_URI
MONGODB_DB_NAME=agency_os_v1
AGENCYOS_USER_ID=paul
AGENCYOS_DASHBOARD_PASSWORD   # required in production
AGENCYOS_SESSION_SECRET       # optional, defaults to the password
```

## Key Conventions

- **Agents must not call external APIs directly** — use `queueExternalApprovalTool` so the action goes through human review.
- **All MongoDB writes go through typed collection accessors** in `src/lib/mongodb/collections.ts`.
- **API route validation uses Zod, and validation failure is handled** — use `safeParse` and return a 400. A bare `.parse()` in a route throws and surfaces as a 500.
- **Route handlers are factories that take their I/O as an argument** (`createLeadIntakeHandler`, `createTaskStatusHandler`, `createApprovalExecutor`, ...). The route file supplies the MongoDB/Composio implementation; tests supply a fake. Keep new handlers in this shape.
- **Write the test first.** Every fix and feature lands as a failing test, then the code to pass it.
- When adding a new agent tool, register it in `src/mastra/tools/agency-tools.ts` and add it to the relevant agent's `tools` array.
- When adding a new MongoDB collection, add the type to `types.ts`, the accessor to `collections.ts`, and the indexes to `indexes.ts` (then run `pnpm db:indexes`).
