# Manual smoke test for the auth gate against a running production server.
# The unit suite covers the policy, origin, and session logic in isolation;
# this checks the pieces only a real server exercises, such as cookies actually
# being set on the response.
#
#   pnpm build
#   $env:AGENCYOS_DASHBOARD_PASSWORD="test-password-123"
#   $env:AGENCYOS_SESSION_SECRET="test-signing-secret"
#   npx next start -p 3100
#   pwsh scripts/verify-auth.ps1

Add-Type -AssemblyName System.Net.Http

$base = "http://localhost:3100"
$script:pass = 0
$script:fail = 0

function Check($name, $expected, $actual) {
    if ("$expected" -eq "$actual") {
        Write-Host "  PASS  $name (got $actual)" -ForegroundColor Green
        $script:pass++
    } else {
        Write-Host "  FAIL  $name (expected $expected, got $actual)" -ForegroundColor Red
        $script:fail++
    }
}

$cookies = New-Object System.Net.CookieContainer
$handler = New-Object System.Net.Http.HttpClientHandler
$handler.AllowAutoRedirect = $false
$handler.CookieContainer = $cookies
$client = New-Object System.Net.Http.HttpClient($handler)

function Send($method, $path, $body, $contentType, $headers) {
    $req = New-Object System.Net.Http.HttpRequestMessage([System.Net.Http.HttpMethod]::new($method), "$base$path")
    if ($body) {
        $req.Content = New-Object System.Net.Http.StringContent($body, [System.Text.Encoding]::UTF8, $contentType)
    }
    if ($headers) {
        foreach ($k in $headers.Keys) { $req.Headers.TryAddWithoutValidation($k, $headers[$k]) | Out-Null }
    }
    return $client.SendAsync($req).GetAwaiter().GetResult()
}

function Json($method, $path, $body, $headers) { Send $method $path $body "application/json" $headers }
function Form($method, $path, $body, $headers) { Send $method $path $body "application/x-www-form-urlencoded" $headers }

Write-Host "`n--- Unauthenticated access ---"
Check "GET /approvals redirects to login" 307 ([int](Send "GET" "/approvals" $null $null $null).StatusCode)
Check "POST /api/approvals/:id/execute is refused" 401 ([int](Json "POST" "/api/approvals/507f1f77bcf86cd799439011/execute" "{}" $null).StatusCode)
Check "PATCH /api/approvals/:id is refused" 401 ([int](Json "PATCH" "/api/approvals/507f1f77bcf86cd799439011" '{"status":"approved"}' $null).StatusCode)
Check "POST /api/leads is refused" 401 ([int](Json "POST" "/api/leads" '{"name":"x","problem":"y"}' $null).StatusCode)
Check "POST /api/workflows/lead-to-project is refused" 401 ([int](Json "POST" "/api/workflows/lead-to-project" '{"name":"x","problem":"y"}' $null).StatusCode)
Check "GET /login is reachable" 200 ([int](Send "GET" "/login" $null $null $null).StatusCode)

Write-Host "`n--- Cross-site requests ---"
Check "cross-site execute POST is blocked" 403 ([int](Json "POST" "/api/approvals/507f1f77bcf86cd799439011/execute" "{}" @{ Origin = "https://evil.example.com" }).StatusCode)
Check "cross-site login POST is blocked" 403 ([int](Form "POST" "/api/auth/login" "password=test-password-123" @{ Origin = "https://evil.example.com" }).StatusCode)
Check "same-origin POST is not blocked as cross-site" 401 ([int](Json "POST" "/api/leads" '{"name":"x","problem":"y"}' @{ Origin = $base }).StatusCode)

Write-Host "`n--- Login ---"
$bad = Form "POST" "/api/auth/login" "password=wrong-password" $null
Check "wrong password bounces back with an error" $true ("$($bad.Headers.Location)" -match "error=1")
Check "wrong password sets no session cookie" 0 ($cookies.GetCookies($base) | Where-Object { $_.Name -eq "agencyos_session" }).Count

$good = Form "POST" "/api/auth/login" "password=test-password-123&next=%2Fapprovals" $null
Check "correct password redirects to the requested page" $true ("$($good.Headers.Location)" -match "/approvals")
$cookie = @($cookies.GetCookies($base) | Where-Object { $_.Name -eq "agencyos_session" })
Check "correct password sets a session cookie" 1 $cookie.Count
Check "session cookie is HttpOnly" $true $cookie[0].HttpOnly

Write-Host "`n--- Open redirect ---"
$openRedirect = Form "POST" "/api/auth/login" "password=test-password-123&next=https%3A%2F%2Fevil.example.com" $null
Check "next= cannot redirect off-site" $false ("$($openRedirect.Headers.Location)" -match "evil.example.com")

Write-Host "`n--- Authenticated access ---"
$leadStatus = [int](Json "POST" "/api/leads" '{"name":"Avery","problem":"Launch a portal."}' $null).StatusCode
Check "a valid lead reaches the handler (201 created, or 502 with no mongo)" $true ($leadStatus -in @(201, 502))
Check "a blank lead is rejected with 400, not 500" 400 ([int](Json "POST" "/api/leads" '{"name":"   ","problem":"  "}' $null).StatusCode)
Check "malformed JSON is rejected with 400, not 500" 400 ([int](Json "POST" "/api/leads" '{not-json' $null).StatusCode)
Check "a bad email is rejected with 400, not 500" 400 ([int](Json "POST" "/api/leads" '{"name":"A","problem":"B","email":"nope"}' $null).StatusCode)
Check "an unsupported approval status is rejected with 400, not 500" 400 ([int](Json "PATCH" "/api/approvals/507f1f77bcf86cd799439011" '{"status":"executed"}' $null).StatusCode)
Check "an invalid task id is rejected with 400" 400 ([int](Json "PATCH" "/api/tasks/not-an-id" '{"status":"done"}' $null).StatusCode)

Write-Host "`n--- Forged session ---"
$forgedCookies = New-Object System.Net.CookieContainer
$forgedHandler = New-Object System.Net.Http.HttpClientHandler
$forgedHandler.AllowAutoRedirect = $false
$forgedHandler.CookieContainer = $forgedCookies
$forgedCookies.Add((New-Object System.Net.Cookie("agencyos_session", "eyJzdWIiOiJhdHRhY2tlciIsImV4cCI6OTk5OTk5OTk5OTk5OX0.ZmFrZXNpZ25hdHVyZQ", "/", "localhost")))
$forgedClient = New-Object System.Net.Http.HttpClient($forgedHandler)
$forgedReq = New-Object System.Net.Http.HttpRequestMessage([System.Net.Http.HttpMethod]::new("POST"), "$base/api/leads")
$forgedReq.Content = New-Object System.Net.Http.StringContent('{"name":"x","problem":"y"}', [System.Text.Encoding]::UTF8, "application/json")
Check "a forged session cookie is rejected" 401 ([int]$forgedClient.SendAsync($forgedReq).GetAwaiter().GetResult().StatusCode)

Write-Host "`n=== $($script:pass) passed, $($script:fail) failed ===`n"
if ($script:fail -gt 0) { exit 1 }
