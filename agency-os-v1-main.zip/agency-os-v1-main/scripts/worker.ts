import "./load-env";

import { createTaskExecutor } from "../src/lib/tasks/execution";
import { mongoTaskExecutionStore } from "../src/lib/tasks/execution-store";
import { runDeliveryAgent } from "../src/lib/tasks/run-agent";
import { createWorkerLoop } from "../src/lib/tasks/worker-loop";

const projectId = process.env.AGENCYOS_WORKER_PROJECT_ID;

const run = createWorkerLoop({
  store: mongoTaskExecutionStore,
  runAgent: runDeliveryAgent,
  projectId: projectId || undefined,
  pollIntervalMs: Number(process.env.AGENCYOS_WORKER_POLL_MS ?? 2_000),
  onResult: (result) => {
    if (result.ok) {
      console.log(`[worker] succeeded task=${result.taskId}`);
    } else {
      console.error(`[worker] failed task=${result.taskId}: ${result.error}`);
    }
  },
});

const controller = new AbortController();

function shutdown(signal: string) {
  console.log(`[worker] received ${signal}, shutting down…`);
  controller.abort();
}

process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));

console.log(
  `[worker] starting${projectId ? ` (project=${projectId})` : " (all projects)"}`,
);

// Warm the executor wiring so a bad import fails fast.
createTaskExecutor({
  store: mongoTaskExecutionStore,
  runAgent: runDeliveryAgent,
});

await run(controller.signal);
console.log("[worker] stopped");
process.exit(0);
