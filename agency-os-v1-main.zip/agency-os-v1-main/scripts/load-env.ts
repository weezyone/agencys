import { readFileSync } from "node:fs";
import { resolve } from "node:path";

/**
 * Load `.env` into `process.env` for standalone scripts (worker, setup).
 * Next.js already loads env for the app; this is only for `tsx scripts/*`.
 * Existing process env wins over file values.
 *
 * Importing this module as a side effect (`import "./load-env"`) runs load
 * immediately — required because ESM evaluates all static imports before the
 * importer's body, and agent/Mongo modules read env during that phase.
 */
export function loadEnv(filePath = resolve(process.cwd(), ".env")): void {
  let raw: string;
  try {
    raw = readFileSync(filePath, "utf8");
  } catch {
    return;
  }

  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;

    const eq = trimmed.indexOf("=");
    if (eq < 1) continue;

    const key = trimmed.slice(0, eq).trim();
    if (!key || process.env[key] !== undefined) continue;

    let value = trimmed.slice(eq + 1).trim();
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }

    process.env[key] = value;
  }
}

loadEnv();
