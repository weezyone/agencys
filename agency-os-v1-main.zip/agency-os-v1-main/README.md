# AgencyOS v1

AI-native agency operating system built with **Mastra.ai + MongoDB + Composio**.

## Product goal

AgencyOS v1 turns a new lead into a client-ready operating plan:

```txt
Lead intake
→ strategy brief
→ proposal draft
→ project plan
→ tasks/milestones
→ agent assignments
→ approved external actions
```

## Stack

- **Mastra.ai** — agents, typed tools, workflows, runtime memory/state
- **MongoDB / Atlas** — source of truth for clients, leads, projects, tasks, artifacts, agent runs, approvals
- **Composio** — outside-world integrations and per-user auth for GitHub, Linear, Slack, Google Drive/Docs, Gmail, etc.
- **Next.js** — AgencyOS dashboard and API surface

## Current scope

This repo now has the foundation plus the first operational loop:

- MongoDB typed collections and indexes
- Composio session/auth helper and callback status sync
- Mastra agent definitions for the 8-agent agency
- Mastra internal tools for leads/projects/tasks/approvals
- First controlled workflow: `leadToProjectWorkflow`
- Dashboard pages for overview, integrations, projects, project detail, and approvals
- API routes for lead creation, integration connection links, approval status updates, and `POST /api/workflows/lead-to-project`

## Quick start

```bash
cp .env.example .env.local
pnpm install
pnpm dev
```

Mastra Studio/runtime:

```bash
pnpm dev:mastra
```

Create MongoDB indexes:

```bash
pnpm db:indexes
```

Typecheck and test:

```bash
pnpm typecheck
pnpm test
```

## Environment variables

See `.env.example`.

Required for local agent execution:

- `OPENAI_API_KEY`
- `COMPOSIO_API_KEY`
- `MONGODB_URI`
- `MONGODB_DB_NAME`

## Dashboard authentication

The dashboard can approve and execute real actions in connected systems, so it
sits behind a password.

- Set `AGENCYOS_DASHBOARD_PASSWORD` to require sign-in at `/login`.
- Set `AGENCYOS_SESSION_SECRET` to sign session cookies independently of the
  password, so rotating the password does not invalidate live sessions.
- With no password set, local development stays open for zero-config setup.
  **In production the app fails closed** and returns `503` on every route rather
  than serving an unauthenticated approval queue.

The proxy also rejects state-changing requests whose `Origin` does not match the
host, and session cookies are `HttpOnly` + `SameSite=Lax`.

## Architecture rule

Do **not** let agents directly mutate outside systems without an approval path.

Pattern:

```txt
Agent drafts action
→ AgencyOS queues approval
→ human approves
→ Composio executes
→ MongoDB logs result
```

Approval execution endpoints:

- `PATCH /api/approvals/:id` with `{ "status": "approved" | "rejected" }`
- `POST /api/approvals/:id/execute` to run an approved action through Composio

The dashboard itself uses server actions rather than posting to these routes, so
form submissions get Next.js's built-in origin checks.

Execution is single-shot: it is granted by an atomic `approved → executing`
compare-and-swap, so concurrent requests cannot fire the same external action
twice. A failed execution lands in `failed`, which a human can approve again to retry.

`externalAction` should be a Composio tool slug/action name and `payload` should match that tool's expected arguments.

## Directory map

```txt
src/
  app/                 Next.js dashboard + API routes
  proxy.ts             auth gate + cross-site request rejection
  lib/
    approvals/         approval state machine, execution, Mongo store
    auth/              session tokens, auth policy, origin checks
    composio/          Composio client/session/auth helpers
    leads/             shared lead intake validation
    mongodb/           MongoDB client, types, collections, indexes
    projects/          view-model mapping for the dashboard
    tasks/             task status rules and updates
  mastra/
    agents/            8-agent agency definitions
    tools/             typed Mastra tools
    workflows/         controlled workflows
    index.ts           Mastra runtime registration
scripts/
  setup.ts             MongoDB index creation
  verify-auth.ps1      manual auth smoke test against a running server
tests/                 node:test suites (pnpm test)
```

## Testing

Route handlers and stores are built as factories that take their I/O as
dependencies (`createApprovalExecutor`, `createLeadIntakeHandler`,
`createTaskStatusUpdater`, ...), so the suite runs against in-memory fakes with
no MongoDB, Composio, or OpenAI connection required.

```bash
pnpm test
```

`scripts/verify-auth.ps1` is a manual smoke test for the auth gate against a
running production server, covering the parts only a real server exercises
(cookie issuance, redirects, cross-site rejection, fail-closed behavior).
