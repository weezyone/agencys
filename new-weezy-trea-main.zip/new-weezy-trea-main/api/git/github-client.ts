/**
 * GitHub REST + Git Data API client used by the per-sandbox git-service.
 *
 * Pure functional module — no persistence, no state. Uses `globalThis.fetch`
 * so no extra deps. Every call sends the same fixed set of headers.
 *
 * All non-2xx responses throw a {@link GitHubApiError} carrying the status
 * code and parsed body for the caller to inspect.
 */
import { Buffer } from 'node:buffer';

const API_BASE = 'https://api.github.com';
const ACCEPT = 'application/vnd.github+json';
const API_VERSION = '2022-11-28';
const USER_AGENT = 'weezy-agent-console';

export class GitHubApiError extends Error {
  readonly status: number;
  readonly body: unknown;
  constructor(status: number, body: unknown, message?: string) {
    super(message ?? `GitHub API error ${status}`);
    this.name = 'GitHubApiError';
    this.status = status;
    this.body = body;
  }
}

function headers(token: string): Record<string, string> {
  return {
    Accept: ACCEPT,
    Authorization: `Bearer ${token}`,
    'X-GitHub-Api-Version': API_VERSION,
    'User-Agent': USER_AGENT,
  };
}

async function request<T>(
  method: 'GET' | 'POST' | 'PATCH',
  url: string,
  token: string,
  body?: unknown,
): Promise<{ status: number; body: T }> {
  const init: RequestInit = {
    method,
    headers:
      body === undefined
        ? headers(token)
        : { ...headers(token), 'Content-Type': 'application/json' },
  };
  if (body !== undefined) {
    init.body = JSON.stringify(body);
  }
  const res = await globalThis.fetch(url, init);
  const text = await res.text();
  let parsed: unknown = undefined;
  if (text.length > 0) {
    try {
      parsed = JSON.parse(text);
    } catch {
      parsed = text;
    }
  }
  if (res.status < 200 || res.status >= 300) {
    throw new GitHubApiError(
      res.status,
      parsed,
      `GitHub API ${method} ${url} → ${res.status}`,
    );
  }
  return { status: res.status, body: parsed as T };
}

/**
 * Accepts:
 *   - `https://github.com/owner/repo` (with optional `.git` suffix, trailing `/`)
 *   - `git@github.com:owner/repo(.git)?`
 *   - bare `owner/repo` shortcut
 * Returns null when the string is not a recognisable GitHub repo URL.
 */
export function parseRepoUrl(
  repoUrl: string,
): { owner: string; repo: string } | null {
  if (!repoUrl) return null;
  const raw = repoUrl.trim();
  if (!raw) return null;

  const stripSuffix = (repo: string): string =>
    repo.replace(/\.git$/i, '').replace(/\/$/, '');

  // https://github.com/owner/repo(.git)?(/.*)?
  const httpsMatch = raw.match(
    /^https?:\/\/github\.com\/([^/\s]+)\/([^/\s?#]+)(?:\.git)?\/?/i,
  );
  if (httpsMatch) {
    return { owner: httpsMatch[1], repo: stripSuffix(httpsMatch[2]) };
  }

  // git@github.com:owner/repo(.git)?
  const sshMatch = raw.match(/^git@github\.com:([^/\s]+)\/([^/\s]+?)(?:\.git)?$/i);
  if (sshMatch) {
    return { owner: sshMatch[1], repo: stripSuffix(sshMatch[2]) };
  }

  // bare owner/repo shortcut
  const shortMatch = raw.match(/^([A-Za-z0-9._-]+)\/([A-Za-z0-9._-]+?)(?:\.git)?$/);
  if (shortMatch) {
    return { owner: shortMatch[1], repo: stripSuffix(shortMatch[2]) };
  }

  return null;
}

interface RawBranchRef {
  name: string;
  commit: { sha: string };
}

interface RawRepo {
  default_branch: string;
}

export async function listBranches(
  token: string,
  owner: string,
  repo: string,
): Promise<Array<{ name: string; sha: string; isCurrent: boolean }>> {
  const branchesUrl = `${API_BASE}/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/branches?per_page=100`;
  const repoUrl = `${API_BASE}/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}`;
  const [branchesRes, repoRes] = await Promise.all([
    request<RawBranchRef[]>('GET', branchesUrl, token),
    request<RawRepo>('GET', repoUrl, token),
  ]);
  const defaultBranch = repoRes.body.default_branch;
  return branchesRes.body.map((b) => ({
    name: b.name,
    sha: b.commit.sha,
    isCurrent: b.name === defaultBranch,
  }));
}

export async function getBranch(
  token: string,
  owner: string,
  repo: string,
  name: string,
): Promise<{ name: string; sha: string } | null> {
  const url = `${API_BASE}/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/branches/${encodeURIComponent(name)}`;
  try {
    const res = await request<{ name: string; commit: { sha: string } }>(
      'GET',
      url,
      token,
    );
    return { name: res.body.name, sha: res.body.commit.sha };
  } catch (err) {
    if (err instanceof GitHubApiError && err.status === 404) return null;
    throw err;
  }
}

export async function createBranch(
  token: string,
  owner: string,
  repo: string,
  name: string,
  fromSha: string,
): Promise<{ name: string; sha: string }> {
  const url = `${API_BASE}/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/git/refs`;
  const res = await request<{ ref: string; object: { sha: string } }>(
    'POST',
    url,
    token,
    {
      ref: `refs/heads/${name}`,
      sha: fromSha,
    },
  );
  return { name, sha: res.body.object.sha };
}

interface RawCommitObject {
  sha: string;
  commit: {
    message: string;
    author: { name?: string; email?: string; date?: string } | null;
  };
  author: { login?: string } | null;
}

interface RawCommitDetail extends RawCommitObject {
  stats?: { additions: number; deletions: number; total: number };
  files?: Array<{ filename: string }>;
}

/**
 * Run `tasks` concurrently, but at most `size` at a time. Preserves order.
 */
async function pool<T, R>(
  size: number,
  items: T[],
  fn: (item: T, index: number) => Promise<R>,
): Promise<R[]> {
  const results: R[] = new Array(items.length);
  let cursor = 0;
  const workers: Promise<void>[] = [];
  const worker = async (): Promise<void> => {
    while (true) {
      const i = cursor++;
      if (i >= items.length) return;
      results[i] = await fn(items[i], i);
    }
  };
  const n = Math.min(size, items.length);
  for (let i = 0; i < n; i++) workers.push(worker());
  await Promise.all(workers);
  return results;
}

export async function listCommits(
  token: string,
  owner: string,
  repo: string,
  branch: string,
  limit = 20,
): Promise<
  Array<{
    sha: string;
    message: string;
    author: string;
    timestamp: string;
    additions: number;
    deletions: number;
    filesChanged: number;
  }>
> {
  const listUrl = `${API_BASE}/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/commits?sha=${encodeURIComponent(branch)}&per_page=${limit}`;
  const listRes = await request<RawCommitObject[]>('GET', listUrl, token);
  const items = listRes.body;
  const details = await pool(5, items, async (c) => {
    const detailUrl = `${API_BASE}/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/commits/${encodeURIComponent(c.sha)}`;
    const res = await request<RawCommitDetail>('GET', detailUrl, token);
    return res.body;
  });
  return details.map((d) => {
    const authorLogin = d.author?.login;
    const authorName = d.commit.author?.name;
    const authorEmail = d.commit.author?.email;
    const author = authorLogin ?? authorName ?? authorEmail ?? 'unknown';
    return {
      sha: d.sha,
      message: d.commit.message,
      author,
      timestamp: d.commit.author?.date ?? new Date().toISOString(),
      additions: d.stats?.additions ?? 0,
      deletions: d.stats?.deletions ?? 0,
      filesChanged: d.files?.length ?? 0,
    };
  });
}

/**
 * Create a commit on `branch` containing `files`, using the low-level Git
 * Data API (blob → tree → commit → update-ref). Content is treated as utf-8
 * and encoded as base64 for the blob POST.
 */
export async function createCommit(
  token: string,
  owner: string,
  repo: string,
  branch: string,
  message: string,
  files: Array<{ path: string; content: string }>,
): Promise<{ sha: string; message: string; timestamp: string }> {
  const encRepo = encodeURIComponent(repo);
  const encOwner = encodeURIComponent(owner);
  const base = `${API_BASE}/repos/${encOwner}/${encRepo}`;

  // 1. current branch head → commit sha
  const refRes = await request<{ object: { sha: string } }>(
    'GET',
    `${base}/git/refs/heads/${encodeURIComponent(branch)}`,
    token,
  );
  const parentSha = refRes.body.object.sha;

  // 2. that commit's tree sha
  const commitRes = await request<{ tree: { sha: string } }>(
    'GET',
    `${base}/git/commits/${encodeURIComponent(parentSha)}`,
    token,
  );
  const baseTreeSha = commitRes.body.tree.sha;

  // 3. blobs (parallel, pooled)
  const blobs = await pool(5, files, async (f) => {
    const res = await request<{ sha: string }>(
      'POST',
      `${base}/git/blobs`,
      token,
      {
        content: Buffer.from(f.content, 'utf-8').toString('base64'),
        encoding: 'base64',
      },
    );
    return { path: f.path, sha: res.body.sha };
  });

  // 4. new tree
  const treeRes = await request<{ sha: string }>(
    'POST',
    `${base}/git/trees`,
    token,
    {
      base_tree: baseTreeSha,
      tree: blobs.map((b) => ({
        path: b.path,
        mode: '100644',
        type: 'blob',
        sha: b.sha,
      })),
    },
  );

  // 5. new commit
  const newCommitRes = await request<{
    sha: string;
    message: string;
    author: { date: string };
  }>('POST', `${base}/git/commits`, token, {
    message,
    tree: treeRes.body.sha,
    parents: [parentSha],
  });

  // 6. move the ref
  await request<{ object: { sha: string } }>(
    'PATCH',
    `${base}/git/refs/heads/${encodeURIComponent(branch)}`,
    token,
    { sha: newCommitRes.body.sha, force: false },
  );

  return {
    sha: newCommitRes.body.sha,
    message: newCommitRes.body.message,
    timestamp: newCommitRes.body.author.date,
  };
}

export async function createPullRequest(
  token: string,
  owner: string,
  repo: string,
  title: string,
  sourceBranch: string,
  targetBranch: string,
  body?: string,
): Promise<{
  number: number;
  url: string;
  status: 'open' | 'merged' | 'closed';
  sourceBranch: string;
  targetBranch: string;
  title: string;
  author: string;
  createdAt: string;
}> {
  const url = `${API_BASE}/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/pulls`;
  const res = await request<{
    number: number;
    html_url: string;
    state: 'open' | 'closed';
    merged?: boolean;
    title: string;
    user: { login: string } | null;
    created_at: string;
    head: { ref: string };
    base: { ref: string };
  }>('POST', url, token, {
    title,
    head: sourceBranch,
    base: targetBranch,
    body: body ?? '',
  });
  const status: 'open' | 'merged' | 'closed' =
    res.body.state === 'closed'
      ? res.body.merged
        ? 'merged'
        : 'closed'
      : 'open';
  return {
    number: res.body.number,
    url: res.body.html_url,
    status,
    sourceBranch: res.body.head.ref,
    targetBranch: res.body.base.ref,
    title: res.body.title,
    author: res.body.user?.login ?? 'unknown',
    createdAt: res.body.created_at,
  };
}
