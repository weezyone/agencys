import { nanoid } from 'nanoid';
import { sandboxStore } from '../storage/stores.js';
import type {
  GitBranch,
  GitCommit,
  GitDiffFile,
  PullRequest,
  Sandbox,
  SandboxGitState,
} from '../../shared/sandbox-contracts.js';
import * as gh from '../git/github-client.js';

function shortSha() {
  return nanoid(7).toLowerCase();
}

function nowIso() {
  return new Date().toISOString();
}

export function createInitialGitState(defaultBranch?: string): SandboxGitState {
  const branch = (defaultBranch && defaultBranch.trim()) || 'main';
  const seedCommit: GitCommit = {
    sha: shortSha(),
    message: 'chore: initial scaffold',
    author: 'weezy@platform',
    timestamp: nowIso(),
    filesChanged: 3,
    additions: 42,
    deletions: 0,
  };
  return {
    branches: [{ name: branch, isCurrent: true, ahead: 0, behind: 0 }],
    currentBranch: branch,
    commits: [seedCommit],
    diff: seedDiff(),
    pulls: [],
    nextPrNumber: 1,
  };
}

function seedDiff(): GitDiffFile[] {
  return [
    {
      path: 'src/index.ts',
      status: 'modified',
      additions: 4,
      deletions: 1,
      hunks: [
        [
          '@@ -1,3 +1,6 @@',
          '-export const version = "0.0.1";',
          '+export const version = "0.0.2";',
          '+',
          '+export function greet(name: string) {',
          '+  return `hello, ${name}`;',
          '+}',
        ].join('\n'),
      ],
    },
    {
      path: 'README.md',
      status: 'modified',
      additions: 2,
      deletions: 0,
      hunks: [
        [
          '@@ -1,1 +1,3 @@',
          ' # project',
          '+',
          '+A sandbox scaffold produced by weezy.',
        ].join('\n'),
      ],
    },
  ];
}

function requireSandbox(id: string): Sandbox {
  const s = sandboxStore.get(id);
  if (!s) throw new Error('sandbox not found');
  return s;
}

/**
 * Resolve a live GitHub context for a sandbox. Returns null unless there is
 * both a token and the sandbox's `repoUrl` parses cleanly. Callers use the
 * null case to keep the simulated behaviour byte-identical for demos.
 */
export function githubContext(
  sandbox: Sandbox,
  token?: string,
): { token: string; owner: string; repo: string } | null {
  if (!token) return null;
  if (!sandbox.repoUrl) return null;
  const parsed = gh.parseRepoUrl(sandbox.repoUrl);
  if (!parsed) return null;
  return { token, owner: parsed.owner, repo: parsed.repo };
}

type Mode = 'live' | 'simulated';

export class GitService {
  async listBranches(
    sandboxId: string,
    token?: string,
  ): Promise<{ mode: Mode; branches: GitBranch[] }> {
    const s = requireSandbox(sandboxId);
    const ctx = githubContext(s, token);
    if (!ctx) {
      return { mode: 'simulated', branches: s.git.branches };
    }
    const live = await gh.listBranches(ctx.token, ctx.owner, ctx.repo);
    const currentName =
      live.find((b) => b.name === s.git.currentBranch)?.name ??
      live.find((b) => b.isCurrent)?.name ??
      live[0]?.name ??
      s.git.currentBranch;
    const branches: GitBranch[] = live.map((b) => ({
      name: b.name,
      isCurrent: b.name === currentName,
      ahead: 0,
      behind: 0,
    }));
    s.git.branches = branches;
    s.git.currentBranch = currentName;
    sandboxStore.save(s);
    return { mode: 'live', branches };
  }

  async createBranch(
    sandboxId: string,
    name: string,
    token?: string,
  ): Promise<{ mode: Mode; branch: GitBranch; branches: GitBranch[] }> {
    const s = requireSandbox(sandboxId);
    const trimmed = (name ?? '').trim();
    if (!trimmed) throw new Error('branch name is required');
    if (s.git.branches.some((b) => b.name === trimmed)) {
      throw new Error('branch already exists');
    }
    const ctx = githubContext(s, token);
    if (ctx) {
      const source = await gh.getBranch(
        ctx.token,
        ctx.owner,
        ctx.repo,
        s.git.currentBranch,
      );
      if (!source) {
        throw new Error(
          `source branch ${s.git.currentBranch} not found on remote`,
        );
      }
      await gh.createBranch(ctx.token, ctx.owner, ctx.repo, trimmed, source.sha);
      const branch: GitBranch = {
        name: trimmed,
        isCurrent: false,
        ahead: 0,
        behind: 0,
      };
      s.git.branches.push(branch);
      sandboxStore.save(s);
      return { mode: 'live', branch, branches: s.git.branches };
    }
    const branch: GitBranch = {
      name: trimmed,
      isCurrent: false,
      ahead: 0,
      behind: 0,
    };
    s.git.branches.push(branch);
    sandboxStore.save(s);
    return { mode: 'simulated', branch, branches: s.git.branches };
  }

  async switchBranch(
    sandboxId: string,
    name: string,
    token?: string,
  ): Promise<{ mode: Mode; branches: GitBranch[] }> {
    const s = requireSandbox(sandboxId);
    const ctx = githubContext(s, token);
    if (ctx) {
      const remote = await gh.getBranch(ctx.token, ctx.owner, ctx.repo, name);
      if (!remote) throw new Error('branch not found');
      if (!s.git.branches.some((b) => b.name === name)) {
        s.git.branches.push({ name, isCurrent: false, ahead: 0, behind: 0 });
      }
      for (const b of s.git.branches) b.isCurrent = b.name === name;
      s.git.currentBranch = name;
      sandboxStore.save(s);
      return { mode: 'live', branches: s.git.branches };
    }
    const target = s.git.branches.find((b) => b.name === name);
    if (!target) throw new Error('branch not found');
    for (const b of s.git.branches) {
      b.isCurrent = b.name === name;
    }
    s.git.currentBranch = name;
    sandboxStore.save(s);
    return { mode: 'simulated', branches: s.git.branches };
  }

  stageAll(sandboxId: string): GitDiffFile[] {
    // No-op for the mock: everything is already staged.
    return requireSandbox(sandboxId).git.diff;
  }

  async commit(
    sandboxId: string,
    message: string,
    author: string,
    token?: string,
  ): Promise<{ mode: Mode; commit: GitCommit; commits: GitCommit[] }> {
    const s = requireSandbox(sandboxId);
    const msg = (message ?? '').trim();
    if (!msg) throw new Error('commit message is required');
    const auth = (author ?? '').trim() || 'weezy@platform';
    const ctx = githubContext(s, token);
    if (ctx) {
      // No real working tree yet: record the commit against a marker file so
      // the low-level Git Data API has something concrete to write. The
      // sandbox's simulated diff stays the same for UI consistency.
      const marker = {
        path: '.weezy/commits.log',
        content:
          `${nowIso()} ${auth}\n${msg}\n` +
          s.git.diff.map((f) => `  ${f.status} ${f.path}`).join('\n') +
          '\n',
      };
      const live = await gh.createCommit(
        ctx.token,
        ctx.owner,
        ctx.repo,
        s.git.currentBranch,
        msg,
        [marker],
      );
      const diffFiles = s.git.diff;
      const additions = diffFiles.reduce((n, f) => n + f.additions, 0);
      const deletions = diffFiles.reduce((n, f) => n + f.deletions, 0);
      const commit: GitCommit = {
        sha: live.sha,
        message: live.message,
        author: auth,
        timestamp: live.timestamp,
        filesChanged: Math.max(1, diffFiles.length),
        additions,
        deletions,
      };
      s.git.commits.unshift(commit);
      s.git.diff = [];
      const current = s.git.branches.find((b) => b.name === s.git.currentBranch);
      if (current) current.ahead += 1;
      sandboxStore.save(s);
      return { mode: 'live', commit, commits: s.git.commits };
    }
    const diffFiles = s.git.diff;
    const additions = diffFiles.reduce((n, f) => n + f.additions, 0);
    const deletions = diffFiles.reduce((n, f) => n + f.deletions, 0);
    const commit: GitCommit = {
      sha: shortSha(),
      message: msg,
      author: auth,
      timestamp: nowIso(),
      filesChanged: diffFiles.length,
      additions,
      deletions,
    };
    s.git.commits.unshift(commit);
    // clear diff after commit; bump ahead count on current branch
    s.git.diff = [];
    const current = s.git.branches.find((b) => b.name === s.git.currentBranch);
    if (current) current.ahead += 1;
    sandboxStore.save(s);
    return { mode: 'simulated', commit, commits: s.git.commits };
  }

  diff(sandboxId: string, token?: string): { mode: Mode; diff: GitDiffFile[] } {
    const s = requireSandbox(sandboxId);
    const ctx = githubContext(s, token);
    return { mode: ctx ? 'live' : 'simulated', diff: s.git.diff };
  }

  async listCommits(
    sandboxId: string,
    token?: string,
  ): Promise<{ mode: Mode; commits: GitCommit[] }> {
    const s = requireSandbox(sandboxId);
    const ctx = githubContext(s, token);
    if (!ctx) {
      return { mode: 'simulated', commits: s.git.commits };
    }
    const live = await gh.listCommits(
      ctx.token,
      ctx.owner,
      ctx.repo,
      s.git.currentBranch,
      20,
    );
    const commits: GitCommit[] = live.map((c) => ({
      sha: c.sha,
      message: c.message,
      author: c.author,
      timestamp: c.timestamp,
      filesChanged: c.filesChanged,
      additions: c.additions,
      deletions: c.deletions,
    }));
    s.git.commits = commits;
    sandboxStore.save(s);
    return { mode: 'live', commits };
  }

  async createPullRequest(
    sandboxId: string,
    payload: { title: string; description: string; targetBranch: string },
    token?: string,
  ): Promise<{ mode: Mode; pull: PullRequest; pulls: PullRequest[] }> {
    const s = requireSandbox(sandboxId);
    const title = (payload.title ?? '').trim();
    if (!title) throw new Error('title is required');
    const target = (payload.targetBranch ?? '').trim() || 'main';
    const source = s.git.currentBranch;
    const ctx = githubContext(s, token);
    if (ctx) {
      const live = await gh.createPullRequest(
        ctx.token,
        ctx.owner,
        ctx.repo,
        title,
        source,
        target,
        payload.description ?? '',
      );
      const pr: PullRequest = {
        id: `pr_${nanoid(10)}`,
        number: live.number,
        title: live.title,
        description: (payload.description ?? '').trim(),
        sourceBranch: live.sourceBranch,
        targetBranch: live.targetBranch,
        url: live.url,
        status: live.status,
        createdAt: live.createdAt,
      };
      s.git.pulls.unshift(pr);
      s.git.nextPrNumber = Math.max(s.git.nextPrNumber, live.number + 1);
      sandboxStore.save(s);
      return { mode: 'live', pull: pr, pulls: s.git.pulls };
    }
    const number = s.git.nextPrNumber++;
    const pr: PullRequest = {
      id: `pr_${nanoid(10)}`,
      number,
      title,
      description: (payload.description ?? '').trim(),
      sourceBranch: source,
      targetBranch: target,
      url: `https://github.com/weezy/sandbox/pull/${number}`,
      status: 'open',
      createdAt: nowIso(),
    };
    s.git.pulls.unshift(pr);
    sandboxStore.save(s);
    return { mode: 'simulated', pull: pr, pulls: s.git.pulls };
  }

  listPullRequests(
    sandboxId: string,
    token?: string,
  ): { mode: Mode; pulls: PullRequest[] } {
    const s = requireSandbox(sandboxId);
    const ctx = githubContext(s, token);
    return { mode: ctx ? 'live' : 'simulated', pulls: s.git.pulls };
  }
}

export const gitService = new GitService();
