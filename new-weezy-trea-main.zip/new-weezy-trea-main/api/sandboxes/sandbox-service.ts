import { EventEmitter } from 'node:events';
import { nanoid } from 'nanoid';
import OpenAI from 'openai';
import { sandboxStore, settingsStore } from '../storage/stores.js';
import {
  DEFAULT_NVIDIA_MODEL,
  NVIDIA_NIM_BASE_URL,
} from '../../shared/settings-contracts.js';
import type {
  Sandbox,
  SandboxAgentKind,
  SandboxAgentRunResult,
  SandboxCreateInput,
  SandboxExecResult,
  SandboxLog,
  SandboxLogLevel,
  SandboxRuntime,
} from '../../shared/sandbox-contracts.js';
import { createInitialGitState } from './git-service.js';

const MIN_VCPUS = 1;
const MAX_VCPUS = 8;
const MIN_TIMEOUT = 5;
const MAX_TIMEOUT = 300;
const DEFAULT_VCPUS = 2;
const DEFAULT_TIMEOUT = 30;
const DEFAULT_RUNTIME: SandboxRuntime = 'node22';
const MEMORY_PER_VCPU_MB = 2048;

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

function nowIso() {
  return new Date().toISOString();
}

function makeLog(
  level: SandboxLogLevel,
  message: string,
  source = 'runtime',
): SandboxLog {
  return {
    id: `log_${nanoid(8)}`,
    timestamp: nowIso(),
    level,
    message,
    source,
  };
}

export class SandboxService {
  private timers = new Set<NodeJS.Timeout>();
  private emitter = new EventEmitter();

  constructor() {
    // Node's default max listeners (10) is too low when many browser tabs
    // subscribe to the same sandbox log stream. Bump generously.
    this.emitter.setMaxListeners(0);
  }

  /**
   * Subscribe to a live log stream for a sandbox. The callback is invoked for
   * every new log line plus a synthetic 'status' event when the sandbox
   * transitions state. Returns an unsubscribe fn.
   */
  subscribe(
    id: string,
    onEvent: (event:
      | { kind: 'log'; log: SandboxLog }
      | { kind: 'status'; status: Sandbox['status'] }
    ) => void,
  ): () => void {
    const channel = `sbx:${id}`;
    const handler = (
      event:
        | { kind: 'log'; log: SandboxLog }
        | { kind: 'status'; status: Sandbox['status'] },
    ) => onEvent(event);
    this.emitter.on(channel, handler);
    return () => this.emitter.off(channel, handler);
  }

  private emitLog(id: string, log: SandboxLog) {
    this.emitter.emit(`sbx:${id}`, { kind: 'log', log });
  }

  private emitStatus(id: string, status: Sandbox['status']) {
    this.emitter.emit(`sbx:${id}`, { kind: 'status', status });
  }

  create(input: SandboxCreateInput): Sandbox {
    if (!input.name || !input.name.trim()) {
      throw new Error('name is required');
    }
    // Fall back to platform defaults from settings, then to the built-in
    // constants if the settings file is empty / missing fields.
    const settingsDefaults = settingsStore.load().sandboxDefaults;
    const vcpus = clamp(
      input.vcpus ?? settingsDefaults.vcpus ?? DEFAULT_VCPUS,
      MIN_VCPUS,
      MAX_VCPUS,
    );
    const timeoutMinutes = clamp(
      input.timeoutMinutes ?? settingsDefaults.timeoutMinutes ?? DEFAULT_TIMEOUT,
      MIN_TIMEOUT,
      MAX_TIMEOUT,
    );
    const runtime: SandboxRuntime =
      input.runtime ?? settingsDefaults.runtime ?? DEFAULT_RUNTIME;
    const id = `sbx_${nanoid(10)}`;
    const createdAt = nowIso();
    // If a GitHub repo was picked, synthesise repoUrl + branch from it.
    const derivedRepoUrl = input.repo
      ? `https://github.com/${input.repo.owner}/${input.repo.name}.git`
      : undefined;
    const derivedBranch = input.repo?.branch;
    const repoUrl =
      derivedRepoUrl ?? (input.repoUrl?.trim() || undefined);
    const branch =
      derivedBranch ??
      (input.branch?.trim() || (input.repoUrl ? 'main' : undefined));
    const initialLogs: SandboxLog[] = [
      makeLog('info', `sandbox ${id} queued for provisioning`, 'orchestrator'),
    ];
    if (input.repo) {
      initialLogs.push(
        makeLog(
          'info',
          `cloned from ${input.repo.owner}/${input.repo.name}#${input.repo.branch}`,
          'git',
        ),
      );
    }
    const sandbox: Sandbox = {
      id,
      name: input.name.trim(),
      status: 'provisioning',
      repoUrl,
      branch,
      vcpus,
      memoryMb: vcpus * MEMORY_PER_VCPU_MB,
      timeoutMinutes,
      runtime,
      createdAt,
      domainUrl: `https://${id.replace('_', '-')}.sandbox.weezy.dev`,
      projectId: input.projectId,
      logs: initialLogs,
      git: createInitialGitState(branch),
    };
    sandboxStore.save(sandbox);
    this.scheduleProvisioning(id);
    return sandbox;
  }

  private scheduleProvisioning(id: string) {
    const steps: Array<{ delay: number; log: SandboxLog }> = [
      {
        delay: 250,
        log: makeLog('info', 'allocating vcpu + memory quota', 'orchestrator'),
      },
      { delay: 550, log: makeLog('info', 'cloning repo', 'git') },
      {
        delay: 900,
        log: makeLog('info', 'installing claude-code CLI', 'installer'),
      },
      {
        delay: 1250,
        log: makeLog('info', 'installing codex CLI', 'installer'),
      },
      { delay: 1600, log: makeLog('info', 'warming runtime', 'runtime') },
    ];
    for (const step of steps) {
      const t = setTimeout(() => {
        this.timers.delete(t);
        this.appendLog(id, step.log);
      }, step.delay);
      this.timers.add(t);
    }
    const finalT = setTimeout(() => {
      this.timers.delete(finalT);
      const sandbox = sandboxStore.get(id);
      if (!sandbox) return;
      if (sandbox.status !== 'provisioning') return;
      sandbox.status = 'running';
      const readyLog = makeLog('info', 'ready', 'runtime');
      sandbox.logs.push(readyLog);
      sandboxStore.save(sandbox);
      this.emitLog(id, readyLog);
      this.emitStatus(id, 'running');
    }, 2000);
    this.timers.add(finalT);
  }

  list(): Sandbox[] {
    return sandboxStore.list();
  }

  get(id: string): Sandbox | undefined {
    return sandboxStore.get(id);
  }

  pause(id: string): Sandbox | undefined {
    const s = sandboxStore.get(id);
    if (!s) return undefined;
    if (s.status !== 'running') return s;
    s.status = 'paused';
    const log = makeLog('info', 'sandbox paused', 'orchestrator');
    s.logs.push(log);
    const saved = sandboxStore.save(s);
    this.emitLog(id, log);
    this.emitStatus(id, 'paused');
    return saved;
  }

  resume(id: string): Sandbox | undefined {
    const s = sandboxStore.get(id);
    if (!s) return undefined;
    if (s.status !== 'paused') return s;
    s.status = 'running';
    const log = makeLog('info', 'sandbox resumed', 'orchestrator');
    s.logs.push(log);
    const saved = sandboxStore.save(s);
    this.emitLog(id, log);
    this.emitStatus(id, 'running');
    return saved;
  }

  terminate(id: string): Sandbox | undefined {
    const s = sandboxStore.get(id);
    if (!s) return undefined;
    if (s.status === 'terminated') return s;
    s.status = 'terminated';
    s.terminatedAt = nowIso();
    const log = makeLog('info', 'sandbox terminated', 'orchestrator');
    s.logs.push(log);
    const saved = sandboxStore.save(s);
    this.emitLog(id, log);
    this.emitStatus(id, 'terminated');
    return saved;
  }

  appendLog(id: string, log: SandboxLog): Sandbox | undefined {
    const s = sandboxStore.get(id);
    if (!s) return undefined;
    s.logs.push(log);
    const saved = sandboxStore.save(s);
    this.emitLog(id, log);
    return saved;
  }

  logsSince(id: string, since?: string): SandboxLog[] {
    const s = sandboxStore.get(id);
    if (!s) return [];
    if (!since) return s.logs;
    return s.logs.filter((l) => l.timestamp > since);
  }

  exec(id: string, command: string): SandboxExecResult | undefined {
    const s = sandboxStore.get(id);
    if (!s) return undefined;
    const trimmed = (command ?? '').trim();
    if (!trimmed) {
      throw new Error('command is required');
    }
    const stdout = simulateCommand(trimmed, s);
    const cmdLog = makeLog('info', `$ ${trimmed}`, 'shell');
    s.logs.push(cmdLog);
    this.emitLog(id, cmdLog);
    for (const line of stdout.split('\n')) {
      if (line.trim()) {
        const l = makeLog('info', line, 'shell');
        s.logs.push(l);
        this.emitLog(id, l);
      }
    }
    sandboxStore.save(s);
    return {
      command: trimmed,
      stdout,
      exitCode: 0,
      timestamp: nowIso(),
    };
  }

  async runAgent(
    id: string,
    agent: SandboxAgentKind,
    task: string,
  ): Promise<SandboxAgentRunResult | undefined> {
    const s = sandboxStore.get(id);
    if (!s) return undefined;
    const trimmed = (task ?? '').trim();
    if (!trimmed) {
      throw new Error('task is required');
    }
    const label = agent === 'claude_code' ? 'claude-code' : 'codex';

    // Real path: pick a provider based on which key is configured. NVIDIA NIM
    // is preferred over OpenAI when both are set (it's the explicit opt-in);
    // both use the OpenAI SDK since NIM exposes an OpenAI-compatible surface.
    // Any failure logs a warning and falls through to the simulated response
    // so demos never break.
    const providerCfg = pickLiveProvider(settingsStore.load());
    let realResult: SandboxAgentRunResult | undefined;
    if (providerCfg) {
      const startLog = makeLog(
        'info',
        `[${label}] starting task (live · ${providerCfg.name}${
          providerCfg.name === 'nvidia' ? ` · ${providerCfg.model}` : ''
        })`,
        label,
      );
      s.logs.push(startLog);
      this.emitLog(id, startLog);
      sandboxStore.save(s);
      try {
        realResult = await callLiveAgent(providerCfg, agent, trimmed, s);
        const doneLog = makeLog('info', `[${label}] complete`, label);
        s.logs.push(doneLog);
        this.emitLog(id, doneLog);
        sandboxStore.save(s);
      } catch (err) {
        const msg = (err as Error).message ?? String(err);
        const warnLog = makeLog(
          'warn',
          `[${label}] live call failed (${providerCfg.name}): ${truncate(msg, 160)} — falling back to simulation`,
          label,
        );
        s.logs.push(warnLog);
        this.emitLog(id, warnLog);
        sandboxStore.save(s);
      }
    }

    if (realResult) {
      return realResult;
    }

    // Simulated path (unchanged behaviour).
    const lines = [
      `[${label}] starting task`,
      `[${label}] planning: ${truncate(trimmed, 80)}`,
      `[${label}] editing files…`,
      `[${label}] running tests`,
      `[${label}] complete`,
    ];
    for (const message of lines) {
      const l = makeLog('info', message, label);
      s.logs.push(l);
      this.emitLog(id, l);
    }
    sandboxStore.save(s);

    const summary =
      agent === 'claude_code'
        ? `claude-code drafted a change for: ${truncate(trimmed, 120)}. Touched 2 files, added guarded happy-path tests.`
        : `codex proposed a minimal diff for: ${truncate(trimmed, 120)}. Preserved public surface, no new deps.`;
    const diff = synthesiseDiff(agent, trimmed);
    return {
      summary,
      diff,
      agent,
      task: trimmed,
      timestamp: nowIso(),
    };
  }
}

function truncate(s: string, n: number) {
  return s.length > n ? `${s.slice(0, n - 1)}…` : s;
}

function simulateCommand(cmd: string, s: Sandbox): string {
  const lower = cmd.toLowerCase();
  if (lower.startsWith('ls')) {
    return ['README.md', 'package.json', 'src/', 'tests/'].join('\n');
  }
  if (lower === 'pwd') {
    return `/workspace/${s.name.replace(/\s+/g, '-').toLowerCase()}`;
  }
  if (lower.startsWith('node') || lower.startsWith('npm')) {
    return `${cmd}\n> ok · runtime=${s.runtime}`;
  }
  if (lower.startsWith('python') || lower.startsWith('pip')) {
    return `${cmd}\n> ok · runtime=${s.runtime}`;
  }
  if (lower.startsWith('git')) {
    return `${cmd}\n> on branch ${s.git.currentBranch}`;
  }
  if (lower.startsWith('echo ')) {
    return cmd.slice(5);
  }
  return `${cmd}\n> executed in ${s.id}`;
}

function synthesiseDiff(agent: SandboxAgentKind, task: string): string {
  const filename = agent === 'claude_code' ? 'src/feature.ts' : 'src/index.ts';
  return [
    `diff --git a/${filename} b/${filename}`,
    `--- a/${filename}`,
    `+++ b/${filename}`,
    `@@ -1,4 +1,8 @@`,
    ` // ${task.slice(0, 60)}`,
    `-export function run() {`,
    `-  return 'todo'`,
    `+export function run() {`,
    `+  // agent: ${agent}`,
    `+  const result = perform();`,
    `+  return result;`,
    `+}`,
    `+function perform() { return 'ok'; }`,
    ` `,
  ].join('\n');
}

/**
 * Configuration for a live LLM call. We support two OpenAI-compatible
 * backends today: OpenAI's own endpoint, and NVIDIA NIM (which hosts a range
 * of open-weight models behind the same request/response shape). Both are
 * driven through the `openai` SDK by swapping the `baseURL`.
 */
type LiveProviderConfig =
  | { name: 'openai'; apiKey: string; model: string }
  | { name: 'nvidia'; apiKey: string; model: string; baseURL: string };

function pickLiveProvider(
  s: ReturnType<typeof settingsStore.load>,
): LiveProviderConfig | undefined {
  const nvidiaKey = s.aiProviders.nvidiaApiKey?.trim();
  if (nvidiaKey) {
    return {
      name: 'nvidia',
      apiKey: nvidiaKey,
      model: s.aiProviders.nvidiaModel?.trim() || DEFAULT_NVIDIA_MODEL,
      baseURL: NVIDIA_NIM_BASE_URL,
    };
  }
  const openaiKey = s.aiProviders.openaiApiKey?.trim();
  if (openaiKey) {
    return {
      name: 'openai',
      apiKey: openaiKey,
      // gpt-4o-mini is fast + cheap; can be lifted into settings later.
      model: 'gpt-4o-mini',
    };
  }
  return undefined;
}

/**
 * Real agent path. Sends a chat completion request to whichever
 * OpenAI-compatible endpoint the caller configured (OpenAI or NVIDIA NIM) and
 * expects strict JSON back: {summary, diff}. Returns a
 * SandboxAgentRunResult on success; the caller falls back to the simulated
 * response on any thrown error.
 */
async function callLiveAgent(
  cfg: LiveProviderConfig,
  agent: SandboxAgentKind,
  task: string,
  sandbox: Sandbox,
): Promise<SandboxAgentRunResult> {
  const client = new OpenAI({
    apiKey: cfg.apiKey,
    ...(cfg.name === 'nvidia' ? { baseURL: cfg.baseURL } : {}),
  });
  const persona =
    agent === 'claude_code'
      ? 'You are Claude Code, a careful pair programmer that prefers minimal, well-tested diffs.'
      : 'You are Codex, a terse code-writing assistant that prefers surgical patches with no new dependencies.';
  const repoHint = sandbox.repoUrl
    ? `Target repo: ${sandbox.repoUrl} (branch ${sandbox.git.currentBranch}).`
    : `No repo attached; assume a small ${sandbox.runtime} project.`;
  // NIM models don't universally support response_format=json_object, so we
  // ask very firmly for JSON in the prompt and use safeParseAgentJson to
  // recover from anything the model wraps around it.
  const system = [
    persona,
    'Return STRICT JSON with two keys: "summary" (2-3 short sentences describing what you changed) and "diff" (a valid unified diff patch, git-style, with --- / +++ / @@ headers; may touch 1-3 files).',
    'Do not include markdown fences. Do not include prose outside the JSON.',
    'The diff must apply cleanly to a hypothetical version of the target project. Prefer TypeScript for node runtimes and Python for python runtimes.',
  ].join(' ');
  const user = [
    `Task: ${task}`,
    repoHint,
    `Runtime: ${sandbox.runtime}. vCPUs: ${sandbox.vcpus}. Timeout: ${sandbox.timeoutMinutes}min.`,
  ].join('\n');

  const completion = await client.chat.completions.create({
    model: cfg.model,
    temperature: 0.2,
    // Only request structured output on OpenAI. NIM/OSS models return 400 on
    // unrecognized response_format; the safeParseAgentJson recovery handles
    // any code fences those models sometimes emit.
    ...(cfg.name === 'openai'
      ? { response_format: { type: 'json_object' as const } }
      : {}),
    messages: [
      { role: 'system', content: system },
      { role: 'user', content: user },
    ],
  });

  const raw = completion.choices[0]?.message?.content ?? '';
  const parsed = safeParseAgentJson(raw);
  if (!parsed) {
    throw new Error('model returned unparseable JSON');
  }
  const summary =
    typeof parsed.summary === 'string' && parsed.summary.trim()
      ? parsed.summary.trim()
      : `${agent} produced a change for: ${truncate(task, 100)}`;
  const diff =
    typeof parsed.diff === 'string' && parsed.diff.trim()
      ? parsed.diff.trim()
      : synthesiseDiff(agent, task);

  return {
    summary,
    diff,
    agent,
    task,
    timestamp: nowIso(),
  };
}

function safeParseAgentJson(raw: string): { summary?: unknown; diff?: unknown } | undefined {
  try {
    const obj = JSON.parse(raw);
    if (obj && typeof obj === 'object') return obj as Record<string, unknown>;
  } catch {
    // Some models still slip a code fence in despite response_format; try to
    // recover by extracting the first {...} block.
    const start = raw.indexOf('{');
    const end = raw.lastIndexOf('}');
    if (start >= 0 && end > start) {
      try {
        const obj = JSON.parse(raw.slice(start, end + 1));
        if (obj && typeof obj === 'object') return obj as Record<string, unknown>;
      } catch {
        return undefined;
      }
    }
  }
  return undefined;
}

export const sandboxService = new SandboxService();
