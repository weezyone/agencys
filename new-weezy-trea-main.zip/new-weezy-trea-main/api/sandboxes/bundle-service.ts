import { gzipSync } from 'node:zlib';
import { Buffer } from 'node:buffer';
import type { Sandbox } from '../../shared/sandbox-contracts.js';

/**
 * Minimal ustar tar writer + gzip. Enough to bundle a sandbox snapshot into a
 * standard `.tar.gz` that macOS Archive Utility, GNU tar, and 7-zip can all
 * read. No external dependency.
 */

const BLOCK_SIZE = 512;

function octal(value: number, width: number): string {
  return value.toString(8).padStart(width - 1, '0') + '\0';
}

function pad(buf: Buffer): Buffer {
  const rem = buf.length % BLOCK_SIZE;
  if (rem === 0) return buf;
  return Buffer.concat([buf, Buffer.alloc(BLOCK_SIZE - rem)]);
}

function tarHeader(name: string, size: number, mtimeSec: number): Buffer {
  if (Buffer.byteLength(name) > 100) {
    throw new Error(`path too long for ustar: ${name}`);
  }
  const header = Buffer.alloc(BLOCK_SIZE);
  header.write(name, 0, 100, 'utf-8');
  header.write(octal(0o644, 8), 100, 8, 'ascii'); // mode
  header.write(octal(0, 8), 108, 8, 'ascii'); // uid
  header.write(octal(0, 8), 116, 8, 'ascii'); // gid
  header.write(octal(size, 12), 124, 12, 'ascii'); // size
  header.write(octal(mtimeSec, 12), 136, 12, 'ascii'); // mtime
  header.write('        ', 148, 8, 'ascii'); // checksum placeholder
  header.write('0', 156, 1, 'ascii'); // typeflag: regular file
  header.write('ustar\0', 257, 6, 'ascii');
  header.write('00', 263, 2, 'ascii');
  // Compute checksum
  let sum = 0;
  for (let i = 0; i < BLOCK_SIZE; i++) sum += header[i];
  header.write(octal(sum, 8), 148, 8, 'ascii');
  return header;
}

function addFile(chunks: Buffer[], path: string, contents: string, mtime: Date) {
  const body = Buffer.from(contents, 'utf-8');
  const mtimeSec = Math.floor(mtime.getTime() / 1000);
  chunks.push(tarHeader(path, body.length, mtimeSec));
  chunks.push(pad(body));
}

function synthSrcIndex(sandbox: Sandbox): string {
  return [
    '// Synthesised from the weezy sandbox snapshot.',
    `// Sandbox: ${sandbox.name} (${sandbox.id})`,
    `// Branch:  ${sandbox.git.currentBranch}`,
    '',
    'export const version = "0.0.2";',
    '',
    'export function greet(name: string) {',
    '  return `hello, ${name}`;',
    '}',
    '',
  ].join('\n');
}

function synthReadme(sandbox: Sandbox): string {
  return [
    `# ${sandbox.name}`,
    '',
    'A sandbox scaffold produced by weezy.',
    '',
    `- **Runtime:** ${sandbox.runtime}`,
    `- **vCPUs:** ${sandbox.vcpus} · **Memory:** ${sandbox.memoryMb} MB`,
    `- **Timeout:** ${sandbox.timeoutMinutes} min`,
    `- **Repo:** ${sandbox.repoUrl ?? 'scratch (no repo)'}`,
    `- **Current branch:** ${sandbox.git.currentBranch}`,
    '',
    '## Git history',
    '',
    ...sandbox.git.commits.map(
      (c) => `- \`${c.sha}\` · ${c.message} — ${c.author}`,
    ),
    '',
  ].join('\n');
}

function synthPackageJson(sandbox: Sandbox): string {
  return `${JSON.stringify(
    {
      name: sandbox.name.replace(/\s+/g, '-').toLowerCase(),
      version: '0.0.2',
      private: true,
      type: 'module',
      runtime: sandbox.runtime,
    },
    null,
    2,
  )}\n`;
}

function synthGitInfo(sandbox: Sandbox): string {
  const branches = sandbox.git.branches
    .map((b) => `${b.isCurrent ? '*' : ' '} ${b.name}  (+${b.ahead}/-${b.behind})`)
    .join('\n');
  const commits = sandbox.git.commits
    .map(
      (c) =>
        `${c.sha}  ${c.timestamp}  ${c.author}\n    ${c.message}  [+${c.additions}/-${c.deletions}, ${c.filesChanged} files]`,
    )
    .join('\n');
  const pulls =
    sandbox.git.pulls
      .map(
        (p) =>
          `PR #${p.number} [${p.status}] ${p.sourceBranch} → ${p.targetBranch}\n    ${p.title}`,
      )
      .join('\n') || '(none)';
  return [
    `# git snapshot for ${sandbox.name}`,
    '',
    '## Branches',
    branches,
    '',
    '## Commits',
    commits,
    '',
    '## Pull requests',
    pulls,
    '',
  ].join('\n');
}

function synthManifest(sandbox: Sandbox): string {
  return `${JSON.stringify(
    {
      id: sandbox.id,
      name: sandbox.name,
      status: sandbox.status,
      runtime: sandbox.runtime,
      vcpus: sandbox.vcpus,
      memoryMb: sandbox.memoryMb,
      timeoutMinutes: sandbox.timeoutMinutes,
      repoUrl: sandbox.repoUrl,
      branch: sandbox.git.currentBranch,
      createdAt: sandbox.createdAt,
      snapshotAt: new Date().toISOString(),
      logLines: sandbox.logs.length,
      commitCount: sandbox.git.commits.length,
      pullCount: sandbox.git.pulls.length,
    },
    null,
    2,
  )}\n`;
}

function synthLogs(sandbox: Sandbox): string {
  return sandbox.logs
    .map(
      (l) =>
        `${l.timestamp}  [${l.level.toUpperCase()}] ${l.source.padEnd(12)} ${l.message}`,
    )
    .join('\n')
    .concat('\n');
}

export interface SandboxBundle {
  buffer: Buffer;
  filename: string;
  byteLength: number;
  fileCount: number;
}

export function buildSandboxBundle(sandbox: Sandbox): SandboxBundle {
  const mtime = new Date();
  const root = sandbox.name.replace(/[^a-z0-9-_]+/gi, '-').toLowerCase() || 'sandbox';
  const chunks: Buffer[] = [];

  const files: Array<[string, string]> = [
    [`${root}/manifest.json`, synthManifest(sandbox)],
    [`${root}/README.md`, synthReadme(sandbox)],
    [`${root}/package.json`, synthPackageJson(sandbox)],
    [`${root}/src/index.ts`, synthSrcIndex(sandbox)],
    [`${root}/.git-info.txt`, synthGitInfo(sandbox)],
    [`${root}/logs/console.log`, synthLogs(sandbox)],
  ];

  for (const [path, body] of files) {
    addFile(chunks, path, body, mtime);
  }

  // Two zero blocks terminate the archive.
  chunks.push(Buffer.alloc(BLOCK_SIZE * 2));

  const tar = Buffer.concat(chunks);
  const gz = gzipSync(tar, { level: 6 });

  return {
    buffer: gz,
    filename: `${root}-${sandbox.id}.tar.gz`,
    byteLength: gz.length,
    fileCount: files.length,
  };
}
