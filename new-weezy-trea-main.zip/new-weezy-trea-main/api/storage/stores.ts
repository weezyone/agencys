import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { nanoid } from 'nanoid';
import type {
  Artifact,
  Lead,
  Project,
  WorkflowRun,
} from '../../shared/agent-contracts.js';
import type { Sandbox } from '../../shared/sandbox-contracts.js';
import {
  DEFAULT_SETTINGS,
  type PlatformSettings,
} from '../../shared/settings-contracts.js';

/**
 * File-backed JSON persistence. The PRD allows in-memory or file-based storage
 * for V1; this implementation keeps a simple flat-file per collection so runs,
 * artifacts, projects and leads survive server restarts without native deps.
 */

const DATA_DIR =
  process.env.WEEZY_DATA_DIR ??
  join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'data');

if (!existsSync(DATA_DIR)) {
  mkdirSync(DATA_DIR, { recursive: true });
}

function loadJson<T>(file: string, fallback: T): T {
  const path = join(DATA_DIR, file);
  if (!existsSync(path)) return fallback;
  try {
    const raw = readFileSync(path, 'utf-8');
    if (!raw.trim()) return fallback;
    return JSON.parse(raw) as T;
  } catch (err) {
    console.warn(`[storage] failed to read ${file}, using fallback:`, (err as Error).message);
    return fallback;
  }
}

function writeJson(file: string, data: unknown): void {
  const path = join(DATA_DIR, file);
  writeFileSync(path, JSON.stringify(data, null, 2), 'utf-8');
}

class FileArtifactStore {
  private artifacts: Map<string, Artifact>;
  private readonly file = 'artifacts.json';

  constructor() {
    const rows = loadJson<Artifact[]>(this.file, []);
    this.artifacts = new Map(rows.map((a) => [a.id, a]));
  }

  private persist() {
    writeJson(this.file, Array.from(this.artifacts.values()));
  }

  save(artifact: Omit<Artifact, 'id' | 'createdAt'> & { id?: string }): Artifact {
    const id = artifact.id ?? `art_${nanoid(10)}`;
    const record: Artifact = {
      ...artifact,
      id,
      createdAt: new Date().toISOString(),
    };
    this.artifacts.set(id, record);
    this.persist();
    return record;
  }

  get(id: string): Artifact | undefined {
    return this.artifacts.get(id);
  }

  list(filter?: {
    workflowRunId?: string;
    projectId?: string;
    leadId?: string;
    agentType?: string;
  }): Artifact[] {
    return Array.from(this.artifacts.values())
      .filter((a) => {
        if (filter?.workflowRunId && a.workflowRunId !== filter.workflowRunId) return false;
        if (filter?.projectId && a.projectId !== filter.projectId) return false;
        if (filter?.leadId && a.leadId !== filter.leadId) return false;
        if (filter?.agentType && a.agentType !== filter.agentType) return false;
        return true;
      })
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }
}

class FileRunStore {
  private runs: Map<string, WorkflowRun>;
  private readonly file = 'runs.json';

  constructor() {
    const rows = loadJson<WorkflowRun[]>(this.file, []);
    this.runs = new Map(rows.map((r) => [r.id, r]));
  }

  private persist() {
    writeJson(this.file, Array.from(this.runs.values()));
  }

  save(run: WorkflowRun): WorkflowRun {
    this.runs.set(run.id, run);
    this.persist();
    return run;
  }
  get(id: string): WorkflowRun | undefined {
    return this.runs.get(id);
  }
  list(): WorkflowRun[] {
    return Array.from(this.runs.values()).sort((a, b) =>
      b.startedAt.localeCompare(a.startedAt),
    );
  }
}

class FileProjectStore {
  private projects: Map<string, Project>;
  private leads: Map<string, Lead>;
  private readonly projectsFile = 'projects.json';
  private readonly leadsFile = 'leads.json';

  constructor() {
    const projectRows = loadJson<Project[]>(this.projectsFile, []);
    this.projects = new Map(projectRows.map((p) => [p.id, p]));
    const leadRows = loadJson<Lead[]>(this.leadsFile, []);
    this.leads = new Map(leadRows.map((l) => [l.id, l]));
  }

  private persistProjects() {
    writeJson(this.projectsFile, Array.from(this.projects.values()));
  }
  private persistLeads() {
    writeJson(this.leadsFile, Array.from(this.leads.values()));
  }

  saveProject(p: Project): Project {
    this.projects.set(p.id, p);
    this.persistProjects();
    return p;
  }
  getProject(id: string) {
    return this.projects.get(id);
  }
  listProjects(): Project[] {
    return Array.from(this.projects.values()).sort((a, b) =>
      b.createdAt.localeCompare(a.createdAt),
    );
  }

  saveLead(l: Lead): Lead {
    this.leads.set(l.id, l);
    this.persistLeads();
    return l;
  }
  getLead(id: string) {
    return this.leads.get(id);
  }
  listLeads(): Lead[] {
    return Array.from(this.leads.values()).sort((a, b) =>
      b.createdAt.localeCompare(a.createdAt),
    );
  }
}

export const artifactStore = new FileArtifactStore();
export const runStore = new FileRunStore();
export const projectStore = new FileProjectStore();

class FileSandboxStore {
  private sandboxes: Map<string, Sandbox>;
  private readonly file = 'sandboxes.json';

  constructor() {
    const rows = loadJson<Sandbox[]>(this.file, []);
    this.sandboxes = new Map(rows.map((s) => [s.id, s]));
  }

  private persist() {
    writeJson(this.file, Array.from(this.sandboxes.values()));
  }

  save(sandbox: Sandbox): Sandbox {
    this.sandboxes.set(sandbox.id, sandbox);
    this.persist();
    return sandbox;
  }

  get(id: string): Sandbox | undefined {
    return this.sandboxes.get(id);
  }

  list(): Sandbox[] {
    return Array.from(this.sandboxes.values()).sort((a, b) =>
      b.createdAt.localeCompare(a.createdAt),
    );
  }
}

export const sandboxStore = new FileSandboxStore();

class FileSettingsStore {
  private settings: PlatformSettings | undefined;
  private readonly file = 'settings.json';

  load(): PlatformSettings {
    if (this.settings) return this.settings;
    const path = join(DATA_DIR, this.file);
    if (!existsSync(path)) {
      // Do not persist until the first save() so we don't create the file
      // eagerly just for a read.
      this.settings = DEFAULT_SETTINGS;
      return this.settings;
    }
    const loaded = loadJson<PlatformSettings>(this.file, DEFAULT_SETTINGS);
    // Merge with defaults so partial legacy files still satisfy the shape.
    this.settings = {
      ...DEFAULT_SETTINGS,
      ...loaded,
      aiProviders: { ...DEFAULT_SETTINGS.aiProviders, ...loaded.aiProviders },
      sandboxDefaults: {
        ...DEFAULT_SETTINGS.sandboxDefaults,
        ...loaded.sandboxDefaults,
      },
      git: { ...DEFAULT_SETTINGS.git, ...loaded.git },
    };
    return this.settings;
  }

  save(next: PlatformSettings): PlatformSettings {
    this.settings = next;
    writeJson(this.file, next);
    return next;
  }
}

export const settingsStore = new FileSettingsStore();
// Re-export id helper for services that want to mint related ids consistently.
export { nanoid };
