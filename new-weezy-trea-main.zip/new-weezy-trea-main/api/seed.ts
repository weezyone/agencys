import { nanoid } from 'nanoid';
import { projectStore, runStore } from './storage/stores.js';
import type { WorkflowRunner } from './workflows/workflow-runner.js';
import { WORKFLOW_DEFINITIONS } from './workflows/definitions.js';
import { sandboxService } from './sandboxes/sandbox-service.js';

export function seedInitialData(runner: WorkflowRunner) {
  if (sandboxService.list().length === 0) {
    sandboxService.create({
      name: 'Halcyon marketing site',
      repoUrl: 'https://github.com/halcyon/marketing-site',
      branch: 'main',
      vcpus: 2,
      timeoutMinutes: 60,
      runtime: 'node22',
    });
  }

  if (projectStore.listProjects().length > 0) return;

  const now = new Date();
  const iso = (offsetMinutes = 0) =>
    new Date(now.getTime() - offsetMinutes * 60_000).toISOString();

  projectStore.saveProject({
    id: `proj_${nanoid(8)}`,
    tenantId: 'tenant_default',
    name: 'Halcyon Type Foundry',
    status: 'active',
    context: {
      industry: 'Independent type foundry',
      goal: 'Launch a subscription tier for OEM licensing',
    },
    createdAt: iso(60 * 24 * 3),
  });
  projectStore.saveProject({
    id: `proj_${nanoid(8)}`,
    tenantId: 'tenant_default',
    name: 'Meridian Coffee Co-op',
    status: 'discovery',
    context: {
      industry: 'Specialty coffee',
      goal: 'Rebuild D2C storefront with editorial voice',
    },
    createdAt: iso(60 * 24 * 8),
  });

  projectStore.saveLead({
    id: `lead_${nanoid(8)}`,
    tenantId: 'tenant_default',
    company: 'Nord Loom Studio',
    contactName: 'Ada Reinholt',
    contactEmail: 'ada@nordloom.co',
    context: {
      industry: 'Weaving atelier',
      referral: 'Introduced by former client Halcyon',
    },
    createdAt: iso(60 * 6),
  });
  projectStore.saveLead({
    id: `lead_${nanoid(8)}`,
    tenantId: 'tenant_default',
    company: 'Argent & Salt',
    contactName: 'Milo Kestrel',
    contactEmail: 'milo@argentsalt.com',
    context: {
      industry: 'Small-batch preserves',
      referral: 'Cold inbound',
    },
    createdAt: iso(60 * 30),
  });

  const projects = projectStore.listProjects();
  const leads = projectStore.listLeads();

  // Kick off one seeded run per workflow for demo state.
  runner.createRun(
    WORKFLOW_DEFINITIONS.lead_to_outreach,
    {
      tenantId: 'tenant_default',
      leadId: leads[0]?.id,
    },
    leads[0]?.company,
  );
  runner.createRun(
    WORKFLOW_DEFINITIONS.intake_to_brief,
    {
      tenantId: 'tenant_default',
      projectId: projects[0]?.id,
    },
    projects[0]?.name,
  );
  runner.createRun(
    WORKFLOW_DEFINITIONS.brief_to_build_plan,
    {
      tenantId: 'tenant_default',
      projectId: projects[1]?.id,
    },
    projects[1]?.name,
  );

  // Force runs to progress to their first pause synchronously for demo readiness.
  const seededRuns = runStore.list();
  for (const run of seededRuns) {
    if (run.status === 'running') {
      // fire-and-forget; the runner already began
    }
  }
}
