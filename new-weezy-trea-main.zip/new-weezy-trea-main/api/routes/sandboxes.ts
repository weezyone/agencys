import { Router, type Request, type Response } from 'express';
import { z } from 'zod';
import { sandboxService } from '../sandboxes/sandbox-service.js';
import { buildSandboxBundle } from '../sandboxes/bundle-service.js';
import gitRouter from './git.js';

const router = Router();

const createSchema = z.object({
  name: z.string().min(1),
  repoUrl: z.string().optional(),
  branch: z.string().optional(),
  vcpus: z.number().int().min(1).max(8).optional(),
  timeoutMinutes: z.number().int().min(5).max(300).optional(),
  runtime: z.enum(['node22', 'python']).optional(),
  projectId: z.string().optional(),
  repo: z
    .object({
      owner: z.string().min(1),
      name: z.string().min(1),
      branch: z.string().min(1),
    })
    .optional(),
});

router.get('/', (_req: Request, res: Response) => {
  res.json({ sandboxes: sandboxService.list() });
});

router.post('/', (req: Request, res: Response): void => {
  const parsed = createSchema.safeParse(req.body ?? {});
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  try {
    const sandbox = sandboxService.create({
      name: parsed.data.name,
      repoUrl: parsed.data.repoUrl,
      branch: parsed.data.branch,
      vcpus: parsed.data.vcpus,
      timeoutMinutes: parsed.data.timeoutMinutes,
      runtime: parsed.data.runtime,
      projectId: parsed.data.projectId,
      repo: parsed.data.repo as
        | { owner: string; name: string; branch: string }
        | undefined,
    });
    res.status(201).json({ sandbox });
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

router.get('/:id', (req: Request, res: Response): void => {
  const sandbox = sandboxService.get(req.params.id);
  if (!sandbox) {
    res.status(404).json({ error: 'sandbox not found' });
    return;
  }
  res.json({ sandbox });
});

router.get('/:id/logs', (req: Request, res: Response): void => {
  const sandbox = sandboxService.get(req.params.id);
  if (!sandbox) {
    res.status(404).json({ error: 'sandbox not found' });
    return;
  }
  const since = typeof req.query.since === 'string' ? req.query.since : undefined;
  const logs = sandboxService.logsSince(req.params.id, since);
  res.json({ logs, status: sandbox.status });
});

// Server-Sent Events stream for real-time logs + status transitions.
// Clients: `new EventSource('/api/sandboxes/:id/logs/stream')`.
router.get('/:id/logs/stream', (req: Request, res: Response): void => {
  const sandbox = sandboxService.get(req.params.id);
  if (!sandbox) {
    res.status(404).json({ error: 'sandbox not found' });
    return;
  }

  res.status(200).set({
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  });
  res.flushHeaders?.();

  const send = (event: string, data: unknown) => {
    res.write(`event: ${event}\n`);
    res.write(`data: ${JSON.stringify(data)}\n\n`);
  };

  // Replay recent logs (last 200) + current status so late subscribers catch up.
  send('status', { status: sandbox.status });
  const tail = sandbox.logs.slice(-200);
  for (const log of tail) send('log', log);

  const unsubscribe = sandboxService.subscribe(req.params.id, (event) => {
    if (event.kind === 'log') send('log', event.log);
    else send('status', { status: event.status });
  });

  // Heartbeat every 15s to keep proxies from closing the connection.
  const heartbeat = setInterval(() => {
    res.write(': heartbeat\n\n');
  }, 15000);

  const close = () => {
    clearInterval(heartbeat);
    unsubscribe();
    res.end();
  };
  req.on('close', close);
  req.on('aborted', close);
});

router.post('/:id/pause', (req: Request, res: Response): void => {
  const sandbox = sandboxService.pause(req.params.id);
  if (!sandbox) {
    res.status(404).json({ error: 'sandbox not found' });
    return;
  }
  res.json({ sandbox });
});

router.post('/:id/resume', (req: Request, res: Response): void => {
  const sandbox = sandboxService.resume(req.params.id);
  if (!sandbox) {
    res.status(404).json({ error: 'sandbox not found' });
    return;
  }
  res.json({ sandbox });
});

router.post('/:id/terminate', (req: Request, res: Response): void => {
  const sandbox = sandboxService.terminate(req.params.id);
  if (!sandbox) {
    res.status(404).json({ error: 'sandbox not found' });
    return;
  }
  res.json({ sandbox });
});

const execSchema = z.object({ command: z.string().min(1) });
router.post('/:id/exec', (req: Request, res: Response): void => {
  const sandbox = sandboxService.get(req.params.id);
  if (!sandbox) {
    res.status(404).json({ error: 'sandbox not found' });
    return;
  }
  const parsed = execSchema.safeParse(req.body ?? {});
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  try {
    const result = sandboxService.exec(req.params.id, parsed.data.command);
    res.json({ result });
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

const agentSchema = z.object({
  agent: z.enum(['claude_code', 'codex_cli']),
  task: z.string().min(1),
});
router.post('/:id/agent', async (req: Request, res: Response): Promise<void> => {
  const sandbox = sandboxService.get(req.params.id);
  if (!sandbox) {
    res.status(404).json({ error: 'sandbox not found' });
    return;
  }
  const parsed = agentSchema.safeParse(req.body ?? {});
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  try {
    const result = await sandboxService.runAgent(
      req.params.id,
      parsed.data.agent,
      parsed.data.task,
    );
    res.json({ result });
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

// mount git routes under /:id/git — mergeParams so :id is available to child.
router.use('/:id/git', gitRouter);

// Snapshot the sandbox (files + git state + logs) as a .tar.gz.
router.get('/:id/download', (req: Request, res: Response): void => {
  const sandbox = sandboxService.get(req.params.id);
  if (!sandbox) {
    res.status(404).json({ error: 'sandbox not found' });
    return;
  }
  const bundle = buildSandboxBundle(sandbox);
  res.setHeader('Content-Type', 'application/gzip');
  res.setHeader(
    'Content-Disposition',
    `attachment; filename="${bundle.filename}"`,
  );
  res.setHeader('Content-Length', String(bundle.byteLength));
  res.setHeader('X-Bundle-Files', String(bundle.fileCount));
  res.status(200).end(bundle.buffer);
});

export default router;
