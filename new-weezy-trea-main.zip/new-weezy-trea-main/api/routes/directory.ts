import { Router, type Request, type Response } from 'express';
import { z } from 'zod';
import { nanoid } from 'nanoid';
import { projectStore } from '../storage/stores.js';

const router = Router();

router.get('/projects', (_req: Request, res: Response) => {
  res.json({ projects: projectStore.listProjects() });
});

const projectSchema = z.object({
  name: z.string().min(1),
  status: z.enum(['active', 'archived', 'discovery']).default('active'),
  context: z.record(z.string()).default({}),
});

router.post('/projects', (req: Request, res: Response): void => {
  const parsed = projectSchema.safeParse(req.body ?? {});
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const project = projectStore.saveProject({
    id: `proj_${nanoid(8)}`,
    tenantId: 'tenant_default',
    name: parsed.data.name,
    status: parsed.data.status,
    context: parsed.data.context,
    createdAt: new Date().toISOString(),
  });
  res.json({ project });
});

router.get('/leads', (_req: Request, res: Response) => {
  res.json({ leads: projectStore.listLeads() });
});

const leadSchema = z.object({
  company: z.string().min(1),
  contactName: z.string().optional(),
  contactEmail: z.string().optional(),
  context: z.record(z.string()).default({}),
});

router.post('/leads', (req: Request, res: Response): void => {
  const parsed = leadSchema.safeParse(req.body ?? {});
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const lead = projectStore.saveLead({
    id: `lead_${nanoid(8)}`,
    tenantId: 'tenant_default',
    company: parsed.data.company,
    contactName: parsed.data.contactName,
    contactEmail: parsed.data.contactEmail,
    context: parsed.data.context,
    createdAt: new Date().toISOString(),
  });
  res.json({ lead });
});

export default router;
