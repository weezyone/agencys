import { Router, type Request, type Response } from 'express';
import { z } from 'zod';
import { AGENT_DIRECTORY, AGENT_TYPES } from '../../shared/agent-types.js';
import { agentFactory } from '../runtime.js';

const router = Router();

router.get('/', (_req: Request, res: Response) => {
  res.json({ agents: Object.values(AGENT_DIRECTORY) });
});

const runSchema = z.object({
  context: z.object({
    tenantId: z.string().default('tenant_default'),
    projectId: z.string().optional(),
    leadId: z.string().optional(),
    workflowRunId: z.string().optional(),
  }),
  input: z.record(z.unknown()).default({}),
});

router.post('/:type/run', async (req: Request, res: Response): Promise<void> => {
  const { type } = req.params;
  if (!AGENT_TYPES.includes(type as (typeof AGENT_TYPES)[number])) {
    res.status(400).json({ error: `Unknown agent type: ${type}` });
    return;
  }
  const parsed = runSchema.safeParse(req.body ?? {});
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const agent = agentFactory.createAgent(
    type as (typeof AGENT_TYPES)[number],
  );
  const result = await agent.assignTask(parsed.data.input, {
    tenantId: parsed.data.context.tenantId,
    projectId: parsed.data.context.projectId,
    leadId: parsed.data.context.leadId,
    workflowRunId: parsed.data.context.workflowRunId,
  });
  res.json({ result });
});

export default router;
