import { Router, type Request, type Response } from 'express';
import { artifactStore } from '../storage/stores.js';

const router = Router();

router.get('/', (req: Request, res: Response) => {
  const { agentType, workflowRunId, projectId, leadId } = req.query as Record<
    string,
    string | undefined
  >;
  const artifacts = artifactStore.list({
    agentType,
    workflowRunId,
    projectId,
    leadId,
  });
  res.json({ artifacts });
});

router.get('/:id', (req: Request, res: Response): void => {
  const artifact = artifactStore.get(req.params.id);
  if (!artifact) {
    res.status(404).json({ error: 'Artifact not found' });
    return;
  }
  res.json({ artifact });
});

export default router;
