/**
 * GitHub device-flow authentication routes.
 *
 *   GET  /api/auth/me           → current AuthView
 *   POST /api/auth/login/start  → begin a device-flow attempt
 *   POST /api/auth/login/poll   → poll for the access token
 *   POST /api/auth/logout       → clear the current session
 */
import { Router, type Request, type Response } from 'express';
import { nanoid } from 'nanoid';
import type { AuthSession, AuthView } from '../../shared/auth-contracts.js';
import { githubClientId, sessionStore } from '../runtime.js';
import {
  fetchGitHubUser,
  pollAccessToken,
  startDeviceFlow,
} from '../auth/github-device-flow.js';
import * as pendingStore from '../auth/pending-store.js';

const router = Router();

const COOKIE_NAME = 'weezy.sid';
const COOKIE_MAX_AGE_SECONDS = 60 * 60 * 24 * 30; // 30 days

function buildCookie(sid: string): string {
  return `${COOKIE_NAME}=${encodeURIComponent(sid)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${COOKIE_MAX_AGE_SECONDS}`;
}

function clearCookie(): string {
  return `${COOKIE_NAME}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0`;
}

/**
 * Strip every server-only field (accessToken, githubToken) before sending a
 * session to the client. The raw GitHub tokens must never leave the server.
 */
function sanitizeSession(s: AuthSession): AuthSession {
  const { accessToken: _a, githubToken: _g, ...safe } = s;
  return safe;
}

router.get('/me', (req: Request, res: Response): void => {
  const configured = Boolean(githubClientId);
  const sid = req.cookies?.[COOKIE_NAME];
  const session = sid ? sessionStore.get(sid) : undefined;
  const view: AuthView = session
    ? { status: 'authenticated', session: sanitizeSession(session), configured }
    : { status: 'anonymous', configured };
  res.status(200).json(view);
});

router.post('/login/start', async (_req: Request, res: Response): Promise<void> => {
  if (!githubClientId) {
    res.status(501).json({
      error: 'GitHub OAuth not configured. Set GITHUB_CLIENT_ID.',
    });
    return;
  }
  try {
    pendingStore.pruneExpired();
    const dc = await startDeviceFlow(githubClientId);
    const pendingId = nanoid(16);
    const expiresAt = new Date(Date.now() + dc.expires_in * 1000).toISOString();
    pendingStore.put(pendingId, {
      deviceCode: dc.device_code,
      userCode: dc.user_code,
      verificationUri: dc.verification_uri,
      expiresAt,
      interval: dc.interval,
      clientId: githubClientId,
      cancelled: false,
    });
    res.status(200).json({
      pendingId,
      userCode: dc.user_code,
      verificationUri: dc.verification_uri,
      expiresAt,
      interval: dc.interval,
    });
  } catch (err) {
    res.status(502).json({
      error: `Failed to start device flow: ${(err as Error).message}`,
    });
  }
});

router.post('/login/poll', async (req: Request, res: Response): Promise<void> => {
  if (!githubClientId) {
    res.status(501).json({
      error: 'GitHub OAuth not configured. Set GITHUB_CLIENT_ID.',
    });
    return;
  }
  const body = req.body as { pendingId?: string } | undefined;
  const pendingId = body?.pendingId;
  if (!pendingId) {
    res.status(400).json({ error: 'pendingId is required' });
    return;
  }
  const entry = pendingStore.get(pendingId);
  if (!entry) {
    res.status(404).json({ error: 'pending flow not found' });
    return;
  }
  if (Date.parse(entry.expiresAt) <= Date.now()) {
    pendingStore.remove(pendingId);
    res.status(410).json({ status: 'expired' });
    return;
  }

  try {
    const result = await pollAccessToken(entry.clientId, entry.deviceCode);
    if (result.status === 'pending' || result.status === 'slow_down') {
      res.status(200).json({ status: 'pending' });
      return;
    }
    if (result.status === 'expired') {
      pendingStore.remove(pendingId);
      res.status(410).json({ status: 'expired' });
      return;
    }
    if (result.status === 'error' || !result.accessToken) {
      res.status(400).json({ status: 'error', error: result.error ?? 'error' });
      return;
    }

    // success — fetch the user and mint a session.
    const user = await fetchGitHubUser(result.accessToken);
    const session: AuthSession = {
      userId: String(user.id),
      login: user.login,
      name: user.name,
      avatarUrl: user.avatar_url,
      scopes: ['read:user'],
      connectedAt: new Date().toISOString(),
      accessToken: result.accessToken,
      githubToken: result.accessToken,
    };
    const sid = nanoid(24);
    sessionStore.create(sid, session);
    pendingStore.remove(pendingId);
    res.setHeader('Set-Cookie', buildCookie(sid));
    const view: AuthView = {
      status: 'authenticated',
      session: sanitizeSession(session),
      configured: true,
    };
    res.status(200).json(view);
  } catch (err) {
    res.status(400).json({ status: 'error', error: (err as Error).message });
  }
});

router.post('/logout', (req: Request, res: Response): void => {
  const sid = req.cookies?.[COOKIE_NAME];
  if (sid) sessionStore.delete(sid);
  res.setHeader('Set-Cookie', clearCookie());
  res.status(200).json({ status: 'ok' });
});

export default router;
