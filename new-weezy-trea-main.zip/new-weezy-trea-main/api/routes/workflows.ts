import { Router, type Request, type Response } from 'express';
import { z } from 'zod';
import { WORKFLOW_LIST, WORKFLOW_DEFINITIONS } from '../workflows/definitions.js';
import { runStore } from '../storage/stores.js';
import { workflowRunner } from '../runtime.js';

const router = Router();

router.get('/', (_req: Request, res: Response) => {
  res.json({ definitions: WORKFLOW_LIST });
});

const launchSchema = z.object({
  context: z
    .object({
      tenantId: z.string().default('tenant_default'),
      projectId: z.string().optional(),
      leadId: z.string().optional(),
    })
    .default({ tenantId: 'tenant_default' }),
  label: z.string().optional(),
});

router.post('/:id/runs', (req: Request, res: Response): void => {
  const def = WORKFLOW_DEFINITIONS[
    req.params.id as keyof typeof WORKFLOW_DEFINITIONS
  ];
  if (!def) {
    res.status(404).json({ error: 'Unknown workflow' });
    return;
  }
  const parsed = launchSchema.safeParse(req.body ?? {});
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const run = workflowRunner.createRun(
    def,
    {
      tenantId: parsed.data.context.tenantId,
      projectId: parsed.data.context.projectId,
      leadId: parsed.data.context.leadId,
    },
    parsed.data.label,
  );
  res.json({ run });
});

router.get('/runs', (_req: Request, res: Response) => {
  res.json({ runs: runStore.list() });
});

router.get('/runs/:runId', (req: Request, res: Response): void => {
  const run = runStore.get(req.params.runId);
  if (!run) {
    res.status(404).json({ error: 'Run not found' });
    return;
  }
  res.json({ run });
});

router.post(
  '/runs/:runId/steps/:stepId/approve',
  async (req: Request, res: Response): Promise<void> => {
    const run = await workflowRunner.approveStep(
      req.params.runId,
      req.params.stepId,
    );
    if (!run) {
      res.status(404).json({ error: 'Run not found' });
      return;
    }
    res.json({ run });
  },
);

router.post(
  '/runs/:runId/steps/:stepId/reject',
  async (req: Request, res: Response): Promise<void> => {
    const run = await workflowRunner.rejectStep(
      req.params.runId,
      req.params.stepId,
    );
    if (!run) {
      res.status(404).json({ error: 'Run not found' });
      return;
    }
    res.json({ run });
  },
);

router.post(
  '/runs/:runId/steps/:stepId/retry',
  async (req: Request, res: Response): Promise<void> => {
    const run = await workflowRunner.retryStep(
      req.params.runId,
      req.params.stepId,
    );
    if (!run) {
      res.status(404).json({ error: 'Run not found' });
      return;
    }
    res.json({ run });
  },
);

export default router;
