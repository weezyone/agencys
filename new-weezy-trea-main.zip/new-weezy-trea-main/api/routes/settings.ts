import { Router, type Request, type Response } from 'express';
import { z } from 'zod';
import { settingsStore } from '../storage/stores.js';
import {
  maskKey,
  type PlatformSettings,
} from '../../shared/settings-contracts.js';

const router = Router();

const UNCHANGED = '__unchanged__';

const providersSchema = z
  .object({
    anthropicApiKey: z.string().optional(),
    openaiApiKey: z.string().optional(),
    googleApiKey: z.string().optional(),
    nvidiaApiKey: z.string().optional(),
    nvidiaModel: z.string().optional(),
  })
  .optional();

const sandboxDefaultsSchema = z
  .object({
    vcpus: z.number().int().min(1).max(8).optional(),
    timeoutMinutes: z.number().int().min(5).max(300).optional(),
    runtime: z.enum(['node22', 'python']).optional(),
  })
  .optional();

const gitSchema = z
  .object({
    defaultAuthorName: z.string().optional(),
    defaultAuthorEmail: z.string().optional(),
    defaultTargetBranch: z.string().min(1).optional(),
  })
  .optional();

const updateSchema = z.object({
  aiProviders: providersSchema,
  sandboxDefaults: sandboxDefaultsSchema,
  git: gitSchema,
});

interface MaskedSettings {
  aiProviders: {
    anthropicApiKey?: string;
    openaiApiKey?: string;
    googleApiKey?: string;
    nvidiaApiKey?: string;
    nvidiaModel?: string;
  };
  sandboxDefaults: PlatformSettings['sandboxDefaults'];
  git: PlatformSettings['git'];
  updatedAt: string;
  hasAnthropicKey: boolean;
  hasOpenaiKey: boolean;
  hasGoogleKey: boolean;
  hasNvidiaKey: boolean;
}

/**
 * Build the outward-facing view of settings — the raw provider keys are
 * replaced with their masked form so they never leave the server.
 */
function maskedView(s: PlatformSettings): MaskedSettings {
  return {
    aiProviders: {
      anthropicApiKey: maskKey(s.aiProviders.anthropicApiKey),
      openaiApiKey: maskKey(s.aiProviders.openaiApiKey),
      googleApiKey: maskKey(s.aiProviders.googleApiKey),
      nvidiaApiKey: maskKey(s.aiProviders.nvidiaApiKey),
      // model id is not a secret — surface it as-is so the UI can echo it.
      nvidiaModel: s.aiProviders.nvidiaModel,
    },
    sandboxDefaults: s.sandboxDefaults,
    git: s.git,
    updatedAt: s.updatedAt,
    hasAnthropicKey: Boolean(s.aiProviders.anthropicApiKey),
    hasOpenaiKey: Boolean(s.aiProviders.openaiApiKey),
    hasGoogleKey: Boolean(s.aiProviders.googleApiKey),
    hasNvidiaKey: Boolean(s.aiProviders.nvidiaApiKey),
  };
}

/**
 * Reconcile an incoming provider-key patch with what we already store:
 *   - `undefined` or `'__unchanged__'` → keep existing value
 *   - empty string                     → clear
 *   - anything else                    → replace
 */
function reconcileKey(
  existing: string | undefined,
  next: string | undefined,
): string | undefined {
  if (next === undefined) return existing;
  if (next === UNCHANGED) return existing;
  const trimmed = next.trim();
  if (!trimmed) return undefined;
  return trimmed;
}

router.get('/', (_req: Request, res: Response) => {
  const settings = settingsStore.load();
  res.json({ settings: maskedView(settings) });
});

router.put('/', (req: Request, res: Response): void => {
  const parsed = updateSchema.safeParse(req.body ?? {});
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const current = settingsStore.load();
  const patch = parsed.data;

  const next: PlatformSettings = {
    aiProviders: {
      anthropicApiKey: reconcileKey(
        current.aiProviders.anthropicApiKey,
        patch.aiProviders?.anthropicApiKey,
      ),
      openaiApiKey: reconcileKey(
        current.aiProviders.openaiApiKey,
        patch.aiProviders?.openaiApiKey,
      ),
      googleApiKey: reconcileKey(
        current.aiProviders.googleApiKey,
        patch.aiProviders?.googleApiKey,
      ),
      nvidiaApiKey: reconcileKey(
        current.aiProviders.nvidiaApiKey,
        patch.aiProviders?.nvidiaApiKey,
      ),
      nvidiaModel:
        patch.aiProviders?.nvidiaModel !== undefined
          ? patch.aiProviders.nvidiaModel.trim() || undefined
          : current.aiProviders.nvidiaModel,
    },
    sandboxDefaults: {
      vcpus: patch.sandboxDefaults?.vcpus ?? current.sandboxDefaults.vcpus,
      timeoutMinutes:
        patch.sandboxDefaults?.timeoutMinutes ??
        current.sandboxDefaults.timeoutMinutes,
      runtime:
        patch.sandboxDefaults?.runtime ?? current.sandboxDefaults.runtime,
    },
    git: {
      defaultAuthorName:
        patch.git?.defaultAuthorName !== undefined
          ? patch.git.defaultAuthorName.trim() || undefined
          : current.git.defaultAuthorName,
      defaultAuthorEmail:
        patch.git?.defaultAuthorEmail !== undefined
          ? patch.git.defaultAuthorEmail.trim() || undefined
          : current.git.defaultAuthorEmail,
      defaultTargetBranch:
        patch.git?.defaultTargetBranch ?? current.git.defaultTargetBranch,
    },
    updatedAt: new Date().toISOString(),
  };

  settingsStore.save(next);
  res.json({ settings: maskedView(next) });
});

export default router;
