/**
 * GitHub proxy routes. All routes require an authenticated session AND that
 * OAuth is configured on the server. If OAuth is unconfigured we return 501
 * with a stable error shape so the client can render a graceful fallback.
 */
import { Router, type NextFunction, type Request, type Response } from 'express';
import { githubClientId } from '../runtime.js';
import { getSession, requireSession } from '../auth/require-session.js';
import {
  GitHubAuthError,
  GitHubRateLimitError,
  listBranches,
  listUserRepos,
} from '../github/github-client.js';
import type {
  BranchListResponse,
  RepoListResponse,
} from '../../shared/github-contracts.js';

const router = Router();

/**
 * Extra guard: even though `requireSession` no-ops when OAuth is unconfigured,
 * we cannot proxy to GitHub without a real token. Always 501 in that mode.
 */
function requireConfigured(
  _req: Request,
  res: Response,
  next: NextFunction,
): void {
  if (!githubClientId) {
    res.status(501).json({ error: 'GitHub OAuth not configured' });
    return;
  }
  next();
}

router.use(requireConfigured);
router.use(requireSession);

function handleGitHubError(err: unknown, res: Response): void {
  if (err instanceof GitHubAuthError) {
    res.status(401).json({ error: err.message });
    return;
  }
  if (err instanceof GitHubRateLimitError) {
    const retryAfterSeconds = Math.max(
      1,
      Math.ceil((err.resetAt.getTime() - Date.now()) / 1000),
    );
    res.setHeader('Retry-After', String(retryAfterSeconds));
    res
      .status(429)
      .json({ error: err.message, resetAt: err.resetAt.toISOString() });
    return;
  }
  res.status(502).json({ error: (err as Error).message });
}

router.get('/repos', async (req: Request, res: Response): Promise<void> => {
  const session = getSession(req);
  if (!session?.accessToken) {
    res.status(401).json({ error: 'authentication required' });
    return;
  }
  try {
    const repos = await listUserRepos(session.accessToken, { sort: 'updated' });
    const body: RepoListResponse = { repos, source: 'github' };
    res.status(200).json(body);
  } catch (err) {
    handleGitHubError(err, res);
  }
});

router.get(
  '/repos/:owner/:repo/branches',
  async (req: Request, res: Response): Promise<void> => {
    const session = getSession(req);
    if (!session?.accessToken) {
      res.status(401).json({ error: 'authentication required' });
      return;
    }
    const { owner, repo } = req.params;
    if (!owner || !repo) {
      res.status(400).json({ error: 'owner and repo are required' });
      return;
    }
    try {
      const branches = await listBranches(session.accessToken, owner, repo);
      const defaultBranch =
        branches.find((b) => b.name === 'main')?.name ??
        branches.find((b) => b.name === 'master')?.name ??
        branches[0]?.name ??
        'main';
      const body: BranchListResponse = { branches, defaultBranch };
      res.status(200).json(body);
    } catch (err) {
      handleGitHubError(err, res);
    }
  },
);

export default router;
