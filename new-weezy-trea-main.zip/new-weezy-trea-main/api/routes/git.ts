import { Router, type Request, type Response } from 'express';
import { z } from 'zod';
import { gitService } from '../sandboxes/git-service.js';
import { sandboxService } from '../sandboxes/sandbox-service.js';
import { getSession } from '../auth/require-session.js';

// mergeParams so the parent `:id` is visible.
const router = Router({ mergeParams: true });

function sandboxIdOr404(req: Request, res: Response): string | undefined {
  const id = (req.params as { id?: string }).id;
  if (!id || !sandboxService.get(id)) {
    res.status(404).json({ error: 'sandbox not found' });
    return undefined;
  }
  return id;
}

function tokenFrom(req: Request): string | undefined {
  return getSession(req)?.githubToken;
}

router.get('/branches', async (req: Request, res: Response): Promise<void> => {
  const id = sandboxIdOr404(req, res);
  if (!id) return;
  try {
    const result = await gitService.listBranches(id, tokenFrom(req));
    res.json({ branches: result.branches, mode: result.mode });
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

const branchSchema = z.object({ name: z.string().min(1) });
router.post('/branches', async (req: Request, res: Response): Promise<void> => {
  const id = sandboxIdOr404(req, res);
  if (!id) return;
  const parsed = branchSchema.safeParse(req.body ?? {});
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  try {
    const result = await gitService.createBranch(
      id,
      parsed.data.name,
      tokenFrom(req),
    );
    res.status(201).json({
      branch: result.branch,
      branches: result.branches,
      mode: result.mode,
    });
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

router.post(
  '/branches/:name/checkout',
  async (req: Request, res: Response): Promise<void> => {
    const id = sandboxIdOr404(req, res);
    if (!id) return;
    try {
      const result = await gitService.switchBranch(
        id,
        req.params.name,
        tokenFrom(req),
      );
      res.json({ branches: result.branches, mode: result.mode });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  },
);

router.get('/diff', (req: Request, res: Response): void => {
  const id = sandboxIdOr404(req, res);
  if (!id) return;
  const result = gitService.diff(id, tokenFrom(req));
  res.json({ diff: result.diff, mode: result.mode });
});

const commitSchema = z.object({
  message: z.string().min(1),
  author: z.string().optional(),
});
router.post('/commits', async (req: Request, res: Response): Promise<void> => {
  const id = sandboxIdOr404(req, res);
  if (!id) return;
  const parsed = commitSchema.safeParse(req.body ?? {});
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  try {
    const result = await gitService.commit(
      id,
      parsed.data.message,
      parsed.data.author ?? 'weezy@platform',
      tokenFrom(req),
    );
    res.status(201).json({
      commit: result.commit,
      commits: result.commits,
      mode: result.mode,
    });
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

router.get('/commits', async (req: Request, res: Response): Promise<void> => {
  const id = sandboxIdOr404(req, res);
  if (!id) return;
  try {
    const result = await gitService.listCommits(id, tokenFrom(req));
    res.json({ commits: result.commits, mode: result.mode });
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

router.get('/pulls', (req: Request, res: Response): void => {
  const id = sandboxIdOr404(req, res);
  if (!id) return;
  const result = gitService.listPullRequests(id, tokenFrom(req));
  res.json({ pulls: result.pulls, mode: result.mode });
});

const prSchema = z.object({
  title: z.string().min(1),
  description: z.string().optional().default(''),
  targetBranch: z.string().optional().default('main'),
});
router.post('/pulls', async (req: Request, res: Response): Promise<void> => {
  const id = sandboxIdOr404(req, res);
  if (!id) return;
  const parsed = prSchema.safeParse(req.body ?? {});
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  try {
    const result = await gitService.createPullRequest(
      id,
      {
        title: parsed.data.title,
        description: parsed.data.description ?? '',
        targetBranch: parsed.data.targetBranch ?? 'main',
      },
      tokenFrom(req),
    );
    res
      .status(201)
      .json({ pull: result.pull, pulls: result.pulls, mode: result.mode });
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

export default router;
