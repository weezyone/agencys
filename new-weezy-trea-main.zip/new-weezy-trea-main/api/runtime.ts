import { AgentFactory } from './agents/agent-factory.js';
import type { AgentDeps } from './agents/base-agent.js';
import {
  consoleLogger,
  createConfiguredAiClient,
  createInProcessBus,
} from './agents/services.js';
import { WorkflowRunner } from './workflows/workflow-runner.js';
import { seedInitialData } from './seed.js';
import { settingsStore } from './storage/stores.js';
import { FileSessionStore } from './auth/session-store.js';

const deps: AgentDeps = {
  ai: createConfiguredAiClient(consoleLogger),
  bus: createInProcessBus(),
  logger: consoleLogger,
  now: () => new Date(),
};

export const agentFactory = new AgentFactory(deps);
export const workflowRunner = new WorkflowRunner(agentFactory);
export { settingsStore };

export const sessionStore = new FileSessionStore();
export const githubClientId: string | undefined =
  process.env.GITHUB_CLIENT_ID?.trim() || undefined;

if (!githubClientId) {
  process.stderr.write(
    '[auth] GITHUB_CLIENT_ID not set — /workspace will remain unlocked in dev\n',
  );
}

seedInitialData(workflowRunner);

// Durable resume: replay any in-flight runs from disk once on boot.
let resumed = false;
if (!resumed) {
  resumed = true;
  workflowRunner.resumeAll();
}
