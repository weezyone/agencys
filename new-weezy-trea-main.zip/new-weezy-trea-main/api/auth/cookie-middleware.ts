import type { Request, Response, NextFunction } from 'express';

/**
 * Minimal cookie parser — avoids adding `cookie-parser` as a dependency.
 * Only splits on `;`, trims, and unescapes each key/value pair. Populates
 * the pre-existing `req.cookies` field declared by `@types/express`.
 */
export function cookieMiddleware(
  req: Request,
  _res: Response,
  next: NextFunction,
): void {
  const header = req.headers.cookie;
  const out: Record<string, string> = {};
  if (header) {
    for (const part of header.split(';')) {
      const eq = part.indexOf('=');
      if (eq < 0) continue;
      const k = part.slice(0, eq).trim();
      const v = part.slice(eq + 1).trim();
      if (!k) continue;
      try {
        out[k] = decodeURIComponent(v);
      } catch {
        out[k] = v;
      }
    }
  }
  req.cookies = out;
  next();
}
