import type { Request, Response, NextFunction } from 'express';
import { githubClientId, sessionStore } from '../runtime.js';
import type { AuthSession } from '../../shared/auth-contracts.js';

/**
 * Requests that have passed through {@link requireSession} carry the
 * resolved AuthSession. Callers should cast via {@link getSession}.
 */
export interface AuthedRequest extends Request {
  session: AuthSession;
}

export function getSession(req: Request): AuthSession | undefined {
  return (req as Request & { session?: AuthSession }).session;
}

/**
 * Guard middleware. If GitHub OAuth is not configured (no client id in
 * env), this is a no-op so the dev demo keeps working. Otherwise it
 * requires the `weezy.sid` cookie to map to a live session.
 */
export function requireSession(
  req: Request,
  res: Response,
  next: NextFunction,
): void {
  if (!githubClientId) {
    next();
    return;
  }
  const sid = req.cookies?.['weezy.sid'];
  const session = sid ? sessionStore.get(sid) : undefined;
  if (!session) {
    res.status(401).json({ error: 'authentication required' });
    return;
  }
  (req as Request & { session?: AuthSession }).session = session;
  next();
}
