/**
 * GitHub Device Flow (RFC 8628-style) helpers.
 *
 * Pure functional module — no persistence, no state. Callers wrap these
 * with their own book-keeping (see `pending-store.ts` and the auth router).
 */

const DEVICE_CODE_URL = 'https://github.com/login/device/code';
const ACCESS_TOKEN_URL = 'https://github.com/login/oauth/access_token';
const USER_URL = 'https://api.github.com/user';

export interface DeviceCodeResponse {
  device_code: string;
  user_code: string;
  verification_uri: string;
  expires_in: number;
  interval: number;
}

export interface PollResult {
  status: 'pending' | 'slow_down' | 'success' | 'expired' | 'error';
  accessToken?: string;
  error?: string;
}

export interface GitHubUser {
  id: number;
  login: string;
  name?: string;
  avatar_url?: string;
}

export async function startDeviceFlow(
  clientId: string,
): Promise<DeviceCodeResponse> {
  const res = await globalThis.fetch(DEVICE_CODE_URL, {
    method: 'POST',
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      client_id: clientId,
      scope: 'read:user',
    }).toString(),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`GitHub device code request failed: ${res.status} ${text}`);
  }
  const body = (await res.json()) as DeviceCodeResponse;
  return body;
}

export async function pollAccessToken(
  clientId: string,
  deviceCode: string,
): Promise<PollResult> {
  const res = await globalThis.fetch(ACCESS_TOKEN_URL, {
    method: 'POST',
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      client_id: clientId,
      device_code: deviceCode,
      grant_type: 'urn:ietf:params:oauth:grant-type:device_code',
    }).toString(),
  });
  if (!res.ok) {
    return { status: 'error', error: `HTTP ${res.status}` };
  }
  const body = (await res.json()) as {
    access_token?: string;
    token_type?: string;
    scope?: string;
    error?: string;
    error_description?: string;
  };
  if (body.access_token) {
    return { status: 'success', accessToken: body.access_token };
  }
  switch (body.error) {
    case 'authorization_pending':
      return { status: 'pending' };
    case 'slow_down':
      return { status: 'slow_down' };
    case 'expired_token':
      return { status: 'expired' };
    case 'access_denied':
      return { status: 'error', error: 'access_denied' };
    default:
      return {
        status: 'error',
        error: body.error ?? body.error_description ?? 'unknown_error',
      };
  }
}

export async function fetchGitHubUser(token: string): Promise<GitHubUser> {
  const res = await globalThis.fetch(USER_URL, {
    method: 'GET',
    headers: {
      Accept: 'application/json',
      Authorization: `Bearer ${token}`,
      'User-Agent': 'weezy-platform',
    },
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`GitHub user request failed: ${res.status} ${text}`);
  }
  const body = (await res.json()) as {
    id: number;
    login: string;
    name?: string | null;
    avatar_url?: string | null;
  };
  return {
    id: body.id,
    login: body.login,
    name: body.name ?? undefined,
    avatar_url: body.avatar_url ?? undefined,
  };
}
