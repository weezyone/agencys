/**
 * In-memory store for in-flight GitHub device-flow attempts. These are
 * short-lived (a few minutes at most) and can safely evaporate on server
 * restart — the user simply retries.
 */

export interface PendingEntry {
  deviceCode: string;
  userCode: string;
  verificationUri: string;
  expiresAt: string;
  interval: number;
  clientId: string;
  cancelled: boolean;
}

const pending = new Map<string, PendingEntry>();

export function put(id: string, entry: PendingEntry): void {
  pending.set(id, entry);
}

export function get(id: string): PendingEntry | undefined {
  return pending.get(id);
}

export function remove(id: string): void {
  pending.delete(id);
}

export function pruneExpired(): void {
  const now = Date.now();
  for (const [id, entry] of pending.entries()) {
    const expires = Date.parse(entry.expiresAt);
    if (Number.isFinite(expires) && expires <= now) {
      pending.delete(id);
    }
  }
}
