import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import type { AuthSession } from '../../shared/auth-contracts.js';

/**
 * File-backed session store. Same atomic-write pattern as the other
 * `FileXStore` singletons in `api/storage/stores.ts` — one flat JSON blob
 * on disk, mirrored to an in-memory map for O(1) lookups.
 */

const DATA_DIR =
  process.env.WEEZY_DATA_DIR ??
  join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'data');

if (!existsSync(DATA_DIR)) {
  mkdirSync(DATA_DIR, { recursive: true });
}

interface SessionRecord {
  id: string;
  session: AuthSession;
}

export class FileSessionStore {
  private sessions: Map<string, AuthSession>;
  private readonly file = 'sessions.json';

  constructor() {
    const path = join(DATA_DIR, this.file);
    let rows: SessionRecord[] = [];
    if (existsSync(path)) {
      try {
        const raw = readFileSync(path, 'utf-8');
        if (raw.trim()) rows = JSON.parse(raw) as SessionRecord[];
      } catch (err) {
        console.warn(
          `[storage] failed to read ${this.file}, starting empty:`,
          (err as Error).message,
        );
      }
    }
    this.sessions = new Map(rows.map((r) => [r.id, r.session]));
  }

  private persist(): void {
    const path = join(DATA_DIR, this.file);
    const rows: SessionRecord[] = Array.from(this.sessions.entries()).map(
      ([id, session]) => ({ id, session }),
    );
    writeFileSync(path, JSON.stringify(rows, null, 2), 'utf-8');
  }

  create(id: string, session: AuthSession): AuthSession {
    this.sessions.set(id, session);
    this.persist();
    return session;
  }

  get(id: string): AuthSession | undefined {
    return this.sessions.get(id);
  }

  delete(id: string): void {
    if (this.sessions.delete(id)) {
      this.persist();
    }
  }

  list(): AuthSession[] {
    return Array.from(this.sessions.values());
  }
}
