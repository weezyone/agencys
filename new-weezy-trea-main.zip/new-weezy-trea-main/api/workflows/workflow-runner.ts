import { nanoid } from 'nanoid';
import type {
  AgentContext,
  AgentRunResult,
  RunStatus,
  StepStatus,
  WorkflowDefinition,
  WorkflowRun,
  WorkflowRunStep,
} from '../../shared/agent-contracts.js';
import { AgentFactory } from '../agents/agent-factory.js';
import { artifactStore, runStore } from '../storage/stores.js';
import { WORKFLOW_DEFINITIONS } from './definitions.js';

const nowIso = () => new Date().toISOString();

const MAX_ATTEMPTS = 3;

/**
 * WorkflowRunner — durable execution inspired by Vercel's WDK.
 *
 * Every step records a checkpoint before running and again after the agent
 * returns, so a crash mid-flight can be replayed on next boot from the last
 * durable point. Failed steps are retried with exponential backoff before
 * being surfaced as `failed`.
 */
export class WorkflowRunner {
  private advancing = new Set<string>();
  private retryTimers = new Map<string, NodeJS.Timeout>();

  constructor(private factory: AgentFactory) {}

  createRun(
    definition: WorkflowDefinition,
    context: AgentContext,
    label?: string,
  ): WorkflowRun {
    const run: WorkflowRun = {
      id: `run_${nanoid(10)}`,
      definitionId: definition.id,
      name: definition.name,
      status: 'running',
      startedAt: nowIso(),
      steps: definition.steps.map((s) => ({
        ...s,
        status: 'pending',
        attempts: 0,
      })),
      context,
      label,
    };
    runStore.save(run);
    // Kick execution asynchronously so the caller can respond immediately.
    void this.advance(run.id);
    return run;
  }

  async advance(runId: string): Promise<WorkflowRun | undefined> {
    // Concurrency guard: prevent overlapping advance() calls for the same run
    // from double-executing steps.
    if (this.advancing.has(runId)) {
      return runStore.get(runId);
    }
    this.advancing.add(runId);
    try {
      return await this.advanceInternal(runId);
    } finally {
      this.advancing.delete(runId);
    }
  }

  private async advanceInternal(runId: string): Promise<WorkflowRun | undefined> {
    const run = runStore.get(runId);
    if (!run) return;
    if (run.status !== 'running') return run;

    while (true) {
      const next = pickNextReadyStep(run);
      if (!next) break;

      // If step is scheduled for a future retry, don't run it now — the
      // timer set in executeStep will re-invoke advance().
      if (next.nextRetryAt && new Date(next.nextRetryAt).getTime() > Date.now()) {
        break;
      }

      const requiresApproval = next.requiresApproval;
      await this.executeStep(run, next);
      const status = next.status as StepStatus;

      if (status === 'failed') {
        run.status = 'failed';
        break;
      }
      // Step deferred for retry — stop advancing this pass; the timer will
      // resume execution.
      if (status === 'pending') {
        break;
      }
      if (requiresApproval && status === 'needs_review') {
        run.status = 'needs_review';
        runStore.save(run);
        return run;
      }
    }

    if (run.steps.every((s) => s.status === 'completed')) {
      run.status = 'completed';
      run.completedAt = nowIso();
    } else if (
      run.steps.some((s) => s.status === 'failed') &&
      (run.status as RunStatus) !== 'needs_review'
    ) {
      run.status = 'failed';
    }

    runStore.save(run);
    return run;
  }

  async approveStep(runId: string, stepId: string): Promise<WorkflowRun | undefined> {
    const run = runStore.get(runId);
    if (!run) return;
    const step = run.steps.find((s) => s.id === stepId);
    if (!step || step.status !== 'needs_review') return run;
    step.status = 'completed';
    step.completedAt = nowIso();
    run.status = 'running';
    runStore.save(run);
    return this.advance(runId);
  }

  async rejectStep(runId: string, stepId: string): Promise<WorkflowRun | undefined> {
    const run = runStore.get(runId);
    if (!run) return;
    const step = run.steps.find((s) => s.id === stepId);
    if (!step) return run;
    step.status = 'pending';
    step.artifactId = undefined;
    step.startedAt = undefined;
    step.completedAt = undefined;
    run.status = 'running';
    runStore.save(run);
    return this.advance(runId);
  }

  /**
   * Manually retry a failed step. Resets attempts/lastError and requeues it.
   */
  async retryStep(runId: string, stepId: string): Promise<WorkflowRun | undefined> {
    const run = runStore.get(runId);
    if (!run) return;
    const step = run.steps.find((s) => s.id === stepId);
    if (!step) return run;
    if (step.status !== 'failed') return run;
    step.attempts = 0;
    step.lastError = undefined;
    step.nextRetryAt = undefined;
    step.status = 'pending';
    step.startedAt = undefined;
    step.completedAt = undefined;
    run.status = 'running';
    runStore.save(run);
    return this.advance(runId);
  }

  /**
   * Replay any in-flight runs from disk. Called once on server boot so a
   * crashed process can pick up exactly where it left off (WDK-style).
   */
  resumeAll(): void {
    for (const run of runStore.list()) {
      if (run.status !== 'running' && !run.steps.some((s) => s.status === 'in_progress')) {
        continue;
      }
      let mutated = false;
      for (const step of run.steps) {
        if (step.status === 'in_progress') {
          // Revert to pending so the runner will pick it back up. The
          // checkpoint (input/output) is preserved for audit + replay.
          step.status = 'pending';
          step.nextRetryAt = undefined;
          mutated = true;
        }
      }
      if (run.status !== 'running') {
        run.status = 'running';
        mutated = true;
      }
      run.resumedAt = nowIso();
      if (mutated || run.resumedAt) {
        runStore.save(run);
      }
      void this.advance(run.id);
    }
  }

  private async executeStep(run: WorkflowRun, step: WorkflowRunStep): Promise<void> {
    step.status = 'in_progress';
    step.startedAt = step.startedAt ?? nowIso();
    step.nextRetryAt = undefined;
    const priorArtifacts = collectPriorArtifacts(run, step);
    const input: Record<string, unknown> = {
      stepId: step.id,
      priorArtifacts,
      ...(run.context as unknown as Record<string, unknown>),
    };

    // Durable checkpoint BEFORE execution — records the exact input the
    // agent will see, so replay is deterministic from this point.
    step.checkpoint = {
      input,
      recordedAt: nowIso(),
    };
    runStore.save(run);

    let result: AgentRunResult | undefined;
    let thrown: Error | undefined;
    try {
      const agent = this.factory.createAgent(step.agentType);
      result = await agent.assignTask(input, {
        ...run.context,
        workflowRunId: run.id,
      });
    } catch (err) {
      thrown = err instanceof Error ? err : new Error(String(err));
    }

    step.attempts = (step.attempts ?? 0) + 1;

    const failed = !!thrown || result?.status === 'failed';
    if (failed) {
      const errorMessage =
        thrown?.message ??
        ((typeof result?.summary === 'string' && result.summary) ||
          'Step failed');
      step.lastError = errorMessage;

      // Checkpoint the (failed) output as well, so operators can inspect
      // the last-known state on disk.
      step.checkpoint = {
        input,
        output: result
          ? {
              status: result.status,
              summary: result.summary,
              output: result.output,
            }
          : { error: errorMessage },
        recordedAt: nowIso(),
      };

      const attempts = step.attempts ?? 1;
      if (attempts < MAX_ATTEMPTS) {
        const backoffMs = 500 * Math.pow(2, attempts - 1);
        step.nextRetryAt = new Date(Date.now() + backoffMs).toISOString();
        step.status = 'pending';
        runStore.save(run);
        this.scheduleRetry(run.id, backoffMs);
        return;
      }

      step.status = 'failed';
      step.completedAt = nowIso();
      runStore.save(run);
      return;
    }

    // Success path — result is defined here.
    const success = result!;
    const artifact = artifactStore.save({
      workflowRunId: run.id,
      projectId: run.context.projectId,
      leadId: run.context.leadId,
      agentType: step.agentType,
      title: `${step.title} — ${run.name}`,
      content: {
        summary: success.summary,
        output: success.output,
        questions: success.questions,
        risks: success.risks,
      },
    });
    step.artifactId = artifact.id;

    step.checkpoint = {
      input,
      output: {
        artifactId: artifact.id,
        summary: success.summary,
        output: success.output,
      },
      recordedAt: nowIso(),
    };

    if (step.requiresApproval) {
      step.status = 'needs_review';
    } else {
      step.status = 'completed';
      step.completedAt = nowIso();
    }
    runStore.save(run);
  }

  private scheduleRetry(runId: string, delayMs: number): void {
    const existing = this.retryTimers.get(runId);
    if (existing) clearTimeout(existing);
    const timer = setTimeout(() => {
      this.retryTimers.delete(runId);
      void this.advance(runId);
    }, delayMs);
    // Don't hold the event loop open just for a retry.
    if (typeof timer.unref === 'function') timer.unref();
    this.retryTimers.set(runId, timer);
  }
}

function collectPriorArtifacts(run: WorkflowRun, step: WorkflowRunStep) {
  return step.dependsOn
    .map((depId) => run.steps.find((s) => s.id === depId))
    .filter((s): s is WorkflowRunStep => !!s && !!s.artifactId)
    .map((s) => artifactStore.get(s.artifactId as string))
    .filter(Boolean);
}

function pickNextReadyStep(run: WorkflowRun): WorkflowRunStep | undefined {
  for (const step of run.steps) {
    if (step.status !== 'pending') continue;
    const depsReady = step.dependsOn.every(
      (depId) =>
        run.steps.find((s) => s.id === depId)?.status === 'completed',
    );
    if (depsReady) return step;
  }
  return undefined;
}

export function findDefinition(id: string) {
  return WORKFLOW_DEFINITIONS[id as keyof typeof WORKFLOW_DEFINITIONS];
}

export function stepStatusOf(step: WorkflowRunStep): StepStatus {
  return step.status;
}
export function runStatusOf(run: WorkflowRun): RunStatus {
  return run.status;
}
