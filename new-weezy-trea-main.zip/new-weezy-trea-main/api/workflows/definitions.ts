import type {
  WorkflowDefinition,
  WorkflowDefinitionId,
} from '../../shared/agent-contracts.js';

export const WORKFLOW_DEFINITIONS: Record<WorkflowDefinitionId, WorkflowDefinition> = {
  lead_to_outreach: {
    id: 'lead_to_outreach',
    name: 'Lead → Outreach',
    description:
      'The Research Agent summarises a prospect, then Client Growth drafts a personalised outreach cadence.',
    steps: [
      {
        id: 'research_prospect',
        title: 'Research prospect',
        agentType: 'research',
        dependsOn: [],
        requiresApproval: false,
      },
      {
        id: 'draft_outreach',
        title: 'Draft outreach cadence',
        agentType: 'client_growth',
        dependsOn: ['research_prospect'],
        requiresApproval: true,
      },
    ],
  },
  intake_to_brief: {
    id: 'intake_to_brief',
    name: 'Intake → Project Brief',
    description:
      'PM captures goals, Research adds market context, PM composes the brief with an approval gate.',
    steps: [
      {
        id: 'capture_goals',
        title: 'Capture client goals',
        agentType: 'project_manager',
        dependsOn: [],
        requiresApproval: false,
      },
      {
        id: 'market_context',
        title: 'Assemble market context',
        agentType: 'research',
        dependsOn: ['capture_goals'],
        requiresApproval: false,
      },
      {
        id: 'compose_brief',
        title: 'Compose project brief',
        agentType: 'project_manager',
        dependsOn: ['market_context'],
        requiresApproval: true,
      },
    ],
  },
  brief_to_build_plan: {
    id: 'brief_to_build_plan',
    name: 'Brief → Build Plan',
    description:
      'Designer proposes direction, Tech Lead outlines the build, QA writes the checklist, then approval.',
    steps: [
      {
        id: 'design_direction',
        title: 'Design direction',
        agentType: 'designer',
        dependsOn: [],
        requiresApproval: false,
      },
      {
        id: 'build_plan',
        title: 'Technical build plan',
        agentType: 'tech_lead',
        dependsOn: ['design_direction'],
        requiresApproval: false,
      },
      {
        id: 'qa_checklist',
        title: 'QA acceptance checklist',
        agentType: 'qa',
        dependsOn: ['build_plan'],
        requiresApproval: true,
      },
    ],
  },
};

export const WORKFLOW_LIST = Object.values(WORKFLOW_DEFINITIONS);
