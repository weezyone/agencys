/**
 * GitHub REST API client. Pure functional module — no persistence, no state.
 * Uses `globalThis.fetch` so no extra deps.
 *
 * Every call handles:
 *   - 401 (bad/expired token) → {@link GitHubAuthError}
 *   - 403 with `x-ratelimit-remaining: 0` → {@link GitHubRateLimitError}
 * All other non-2xx responses throw a generic Error with the status + body.
 */
import type {
  GitHubBranch,
  GitHubRepo,
} from '../../shared/github-contracts.js';

const API_BASE = 'https://api.github.com';
const ACCEPT = 'application/vnd.github+json';
const API_VERSION = '2022-11-28';
const USER_AGENT = 'weezy-platform';

export class GitHubAuthError extends Error {
  constructor(message = 'GitHub authentication failed') {
    super(message);
    this.name = 'GitHubAuthError';
  }
}

export class GitHubRateLimitError extends Error {
  readonly resetAt: Date;
  constructor(resetAt: Date, message = 'GitHub API rate limit exceeded') {
    super(message);
    this.name = 'GitHubRateLimitError';
    this.resetAt = resetAt;
  }
}

interface GitHubHeaders {
  Accept: string;
  Authorization: string;
  'X-GitHub-Api-Version': string;
  'User-Agent': string;
  [key: string]: string;
}

function headers(token: string): Record<string, string> {
  return {
    Accept: ACCEPT,
    Authorization: `Bearer ${token}`,
    'X-GitHub-Api-Version': API_VERSION,
    'User-Agent': USER_AGENT,
  };
}

function resetAtFromHeaders(res: Response): Date {
  const raw = res.headers.get('x-ratelimit-reset');
  const seconds = raw ? Number(raw) : NaN;
  if (Number.isFinite(seconds) && seconds > 0) {
    return new Date(seconds * 1000);
  }
  return new Date(Date.now() + 60_000);
}

async function gh(url: string, token: string): Promise<Response> {
  const res = await globalThis.fetch(url, {
    method: 'GET',
    headers: headers(token),
  });
  if (res.status === 401) {
    throw new GitHubAuthError();
  }
  if (res.status === 403) {
    const remaining = res.headers.get('x-ratelimit-remaining');
    if (remaining === '0') {
      throw new GitHubRateLimitError(resetAtFromHeaders(res));
    }
  }
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`GitHub API ${res.status}: ${text}`);
  }
  return res;
}

interface RawRepo {
  id: number;
  full_name: string;
  name: string;
  owner: { login: string };
  default_branch: string;
  private: boolean;
  description: string | null;
  updated_at: string;
  language: string | null;
  stargazers_count: number;
}

interface RawBranch {
  name: string;
  commit: { sha: string };
  protected: boolean;
}

function mapRepo(raw: RawRepo): GitHubRepo {
  return {
    id: raw.id,
    fullName: raw.full_name,
    name: raw.name,
    owner: raw.owner.login,
    defaultBranch: raw.default_branch,
    private: raw.private,
    description: raw.description ?? undefined,
    updatedAt: raw.updated_at,
    language: raw.language ?? undefined,
    stargazersCount: raw.stargazers_count,
  };
}

function mapBranch(raw: RawBranch): GitHubBranch {
  return {
    name: raw.name,
    sha: raw.commit.sha,
    protected: raw.protected,
  };
}

export async function listUserRepos(
  token: string,
  opts: {
    perPage?: number;
    page?: number;
    sort?: 'updated' | 'pushed' | 'full_name';
  } = {},
): Promise<GitHubRepo[]> {
  const perPage = opts.perPage ?? 50;
  const page = opts.page ?? 1;
  const sort = opts.sort ?? 'updated';
  const params = new URLSearchParams({
    per_page: String(perPage),
    page: String(page),
    sort,
    affiliation: 'owner,collaborator,organization_member',
  });
  const res = await gh(`${API_BASE}/user/repos?${params.toString()}`, token);
  const raw = (await res.json()) as RawRepo[];
  return raw.map(mapRepo);
}

export async function listBranches(
  token: string,
  owner: string,
  repo: string,
  opts: { perPage?: number } = {},
): Promise<GitHubBranch[]> {
  const perPage = opts.perPage ?? 100;
  const params = new URLSearchParams({ per_page: String(perPage) });
  const res = await gh(
    `${API_BASE}/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/branches?${params.toString()}`,
    token,
  );
  const raw = (await res.json()) as RawBranch[];
  return raw.map(mapBranch);
}

export async function getRepoDefaultBranch(
  token: string,
  owner: string,
  repo: string,
): Promise<string> {
  const res = await gh(
    `${API_BASE}/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}`,
    token,
  );
  const raw = (await res.json()) as { default_branch: string };
  return raw.default_branch;
}
