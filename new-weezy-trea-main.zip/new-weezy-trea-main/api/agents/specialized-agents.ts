import { BaseAgent, type AgentDeps } from './base-agent.js';
import type {
  AgentContext,
  AgentRunResult,
} from '../../shared/agent-contracts.js';

const asString = (v: unknown, fallback = ''): string =>
  typeof v === 'string' && v.trim() ? v : fallback;

export class ProjectManagerAgent extends BaseAgent {
  constructor(id: string, deps: AgentDeps) {
    super(id, 'project_manager', deps);
  }
  getDefaultSystemPrompt(): string {
    return 'You are Ines, a decisive project manager. Clarify goals, break work into milestones, name blockers plainly.';
  }
  protected async executeTask(
    input: Record<string, unknown>,
    _ctx: AgentContext,
  ): Promise<AgentRunResult> {
    const brief = asString(input.brief, 'Undefined engagement');
    const objective = asString(input.objective, 'Ship a working V1');
    const milestones = [
      { key: 'M1', title: 'Discovery & Alignment', durationDays: 5 },
      { key: 'M2', title: 'Design Direction', durationDays: 7 },
      { key: 'M3', title: 'Build & Instrument', durationDays: 14 },
      { key: 'M4', title: 'QA & Handoff', durationDays: 5 },
    ];
    return {
      status: 'completed',
      summary: `Structured plan for "${brief}" targeting: ${objective}.`,
      output: {
        objective,
        milestones,
        assignments: {
          research: 'Market context memo by day 3',
          designer: 'Direction A/B by end of M2',
          tech_lead: 'Architecture note before M3 kickoff',
        },
      },
      questions: [
        'What is the definition of success for the launch?',
        'Which stakeholder signs off on tone?',
      ],
      risks: ['Scope creep during discovery', 'Undocumented brand assets'],
    };
  }
}

export class ResearchAgent extends BaseAgent {
  constructor(id: string, deps: AgentDeps) {
    super(id, 'research', deps);
  }
  getDefaultSystemPrompt(): string {
    return 'You are Odele, a bookish research analyst. Cite specific facts, not vibes. Write source memos with a light editorial voice.';
  }
  protected async executeTask(
    input: Record<string, unknown>,
    _ctx: AgentContext,
  ): Promise<AgentRunResult> {
    const subject = asString(input.subject, 'Prospect');
    const industry = asString(input.industry, 'unspecified sector');
    return {
      status: 'completed',
      summary: `Market context memo on ${subject} (${industry}).`,
      output: {
        subject,
        industry,
        signals: [
          `${subject} operates in a market growing ~${(subject.length % 12) + 4}% YoY.`,
          'Two dominant incumbents; long tail of boutique players.',
          'Buyer persona skews toward hands-on operators, not enterprise buyers.',
        ],
        sources: [
          { title: 'Sector overview 2024', url: 'https://example.com/sector' },
          { title: 'Buyer interview notes', url: 'https://example.com/buyers' },
        ],
        angle:
          'Position the agency as the calm partner in a loud category; lead with editorial craft.',
      },
      questions: ['Any preferred competitor to benchmark against?'],
    };
  }
}

export class DesignerAgent extends BaseAgent {
  constructor(id: string, deps: AgentDeps) {
    super(id, 'designer', deps);
  }
  getDefaultSystemPrompt(): string {
    return 'You are Kavi, a designer with an editorial soul. Propose brand and layout direction with restraint and one bold gesture.';
  }
  protected async executeTask(
    input: Record<string, unknown>,
    _ctx: AgentContext,
  ): Promise<AgentRunResult> {
    const brand = asString(input.brand, 'Untitled brand');
    return {
      status: 'completed',
      summary: `Two-track direction for ${brand}: Reserved / Ruptured.`,
      output: {
        brand,
        directions: [
          {
            name: 'Reserved',
            palette: ['#0D0D0F', '#F4EFE6', '#2E5E5E'],
            typography: 'Fraunces + JetBrains Mono',
            mood: 'Editorial, measured, confident.',
          },
          {
            name: 'Ruptured',
            palette: ['#0D0D0F', '#F4EFE6', '#E8B23C', '#D6553B'],
            typography: 'Fraunces + Söhne',
            mood: 'Bauhaus lab notebook meets an operator console.',
          },
        ],
        layout:
          '12-column asymmetric grid, left rail navigation, dense center console, marginal numerals.',
      },
      questions: ['Which direction resonates: Reserved or Ruptured?'],
    };
  }
}

export class TechLeadAgent extends BaseAgent {
  constructor(id: string, deps: AgentDeps) {
    super(id, 'tech_lead', deps);
  }
  getDefaultSystemPrompt(): string {
    return 'You are Junho, a tech lead. Choose boring, well-understood tech unless a bold pick is clearly worth the risk. Enumerate trade-offs.';
  }
  protected async executeTask(
    input: Record<string, unknown>,
    _ctx: AgentContext,
  ): Promise<AgentRunResult> {
    const scope = asString(input.scope, 'V1 platform');
    return {
      status: 'completed',
      summary: `Architecture note for ${scope}.`,
      output: {
        stack: {
          frontend: 'React 18 + TypeScript + Vite + Tailwind',
          backend: 'Node.js + Express + zod validation',
          persistence: 'In-memory store (V1) → Postgres (V2)',
          orchestration: 'AgentFactory + WorkflowRunner (in-process)',
        },
        fileStructure: [
          'shared/agent-types.ts',
          'shared/agent-contracts.ts',
          'api/agents/{base-agent, agent-factory, specialized-agents}.ts',
          'api/workflows/{workflow-runner, definitions}.ts',
          'api/storage/artifact-store.ts',
        ],
        tradeoffs: [
          'In-memory store is fastest to ship; migrate before multi-tenant.',
          'Approval gates halt runs synchronously in V1; move to queued in V2.',
        ],
      },
      risks: ['State loss on server restart until persistence lands'],
    };
  }
}

export class FullStackEngineerAgent extends BaseAgent {
  constructor(id: string, deps: AgentDeps) {
    super(id, 'full_stack_engineer', deps);
  }
  getDefaultSystemPrompt(): string {
    return 'You are Rem, a cheerful pragmatist. Turn plans into small, testable diffs.';
  }
  protected async executeTask(
    input: Record<string, unknown>,
    _ctx: AgentContext,
  ): Promise<AgentRunResult> {
    const feature = asString(input.feature, 'Feature');
    return {
      status: 'completed',
      summary: `Implementation plan for ${feature}.`,
      output: {
        feature,
        commits: [
          `feat(${feature}): types and DTOs`,
          `feat(${feature}): service + repo`,
          `feat(${feature}): route handlers with zod`,
          `feat(${feature}): UI wiring + optimistic updates`,
          `test(${feature}): happy path + gate rejection`,
        ],
      },
    };
  }
}

export class QaAgent extends BaseAgent {
  constructor(id: string, deps: AgentDeps) {
    super(id, 'qa', deps);
  }
  getDefaultSystemPrompt(): string {
    return 'You are Beata. Write acceptance criteria and probe the second question no one asked.';
  }
  protected async executeTask(
    input: Record<string, unknown>,
    _ctx: AgentContext,
  ): Promise<AgentRunResult> {
    const target = asString(input.target, 'Deliverable');
    return {
      status: 'completed',
      summary: `QA checklist for ${target}.`,
      output: {
        target,
        acceptanceCriteria: [
          'Given a running workflow, when a step needs approval, then the run pauses in needs_review.',
          'Given a rejected step, when requeued, then it re-executes with fresh input.',
          'Given a completed run, when opened, then all artifacts are viewable.',
        ],
        edgeCases: [
          'Concurrent approvals on the same step',
          'Artifact content larger than 1MB',
          'Agent throws mid-execution',
        ],
      },
    };
  }
}

export class ClientGrowthAgent extends BaseAgent {
  constructor(id: string, deps: AgentDeps) {
    super(id, 'client_growth', deps);
  }
  getDefaultSystemPrompt(): string {
    return 'You are Theron. Write outreach that reads like a considered letter, not a sales blast.';
  }
  protected async executeTask(
    input: Record<string, unknown>,
    _ctx: AgentContext,
  ): Promise<AgentRunResult> {
    const lead = asString(input.leadCompany, 'the prospect');
    const contact = asString(input.contactName, 'there');
    return {
      status: 'completed',
      summary: `Outreach draft for ${lead}.`,
      output: {
        subject: `A short note about ${lead}`,
        body: `Hi ${contact},

I have been reading about ${lead} lately and was struck by how deliberately you have built the brand voice. We work with a small number of operators each quarter on exactly this kind of editorial system — quiet on the surface, sharp underneath.

If it is useful, I would love to send over a two-page read on how we would approach it, no pitch attached.

— Theron`,
        followUps: [
          'Day 4: reference a specific line from their About page.',
          'Day 11: share a related case study, one paragraph max.',
          'Day 21: retire the thread with a warm sign-off.',
        ],
      },
      questions: ['Preferred voice: warm-editorial or crisp-executive?'],
    };
  }
}
