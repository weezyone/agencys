import { nanoid } from 'nanoid';
import { BaseAgent, type AgentDeps } from './base-agent.js';
import type { AgentType } from '../../shared/agent-types.js';
import {
  ClientGrowthAgent,
  DesignerAgent,
  FullStackEngineerAgent,
  ProjectManagerAgent,
  QaAgent,
  ResearchAgent,
  TechLeadAgent,
} from './specialized-agents.js';

type AgentConstructor = new (id: string, deps: AgentDeps) => BaseAgent;

const registry: Record<AgentType, AgentConstructor> = {
  project_manager: ProjectManagerAgent,
  research: ResearchAgent,
  designer: DesignerAgent,
  tech_lead: TechLeadAgent,
  full_stack_engineer: FullStackEngineerAgent,
  qa: QaAgent,
  client_growth: ClientGrowthAgent,
};

export class AgentFactory {
  constructor(private deps: AgentDeps) {}

  createAgent(type: AgentType): BaseAgent {
    const Ctor = registry[type];
    if (!Ctor) throw new Error(`Unknown agent type: ${type}`);
    return new Ctor(`agent_${nanoid(8)}`, this.deps);
  }
}
