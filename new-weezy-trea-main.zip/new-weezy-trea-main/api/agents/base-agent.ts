import { z } from 'zod';
import type {
  AgentContext,
  AgentRunResult,
} from '../../shared/agent-contracts.js';
import type { AgentType } from '../../shared/agent-types.js';

const agentRunResultSchema = z.object({
  status: z.enum(['completed', 'failed', 'needs_review']),
  summary: z.string().min(1, 'summary must be non-empty'),
  output: z.record(z.unknown()),
  questions: z.array(z.string()).optional(),
  risks: z.array(z.string()).optional(),
  artifactId: z.string().optional(),
});

export interface Logger {
  info: (msg: string, meta?: Record<string, unknown>) => void;
  warn: (msg: string, meta?: Record<string, unknown>) => void;
  error: (msg: string, meta?: Record<string, unknown>) => void;
}

export interface MessageBus {
  emit: (event: string, payload: Record<string, unknown>) => void;
  on: (event: string, handler: (payload: Record<string, unknown>) => void) => void;
}

export interface AiClient {
  complete: (opts: {
    system: string;
    user: string;
    context?: AgentContext;
  }) => Promise<{ text: string }>;
}

export interface AgentDeps {
  ai: AiClient;
  bus: MessageBus;
  logger: Logger;
  now: () => Date;
}

export type TaskLifecycle = 'pending' | 'in_progress' | 'completed' | 'failed';

export abstract class BaseAgent {
  public readonly id: string;
  public readonly type: AgentType;
  protected deps: AgentDeps;
  private lifecycle: TaskLifecycle = 'pending';

  constructor(id: string, type: AgentType, deps: AgentDeps) {
    this.id = id;
    this.type = type;
    this.deps = deps;
  }

  abstract getDefaultSystemPrompt(): string;
  protected abstract executeTask(
    input: Record<string, unknown>,
    context: AgentContext,
  ): Promise<AgentRunResult>;

  async assignTask(
    input: Record<string, unknown>,
    context: AgentContext,
  ): Promise<AgentRunResult> {
    this.lifecycle = 'in_progress';
    this.deps.logger.info(`agent.${this.type}.start`, { id: this.id, context });
    this.deps.bus.emit('agent.started', { type: this.type, id: this.id });
    try {
      const raw = await this.executeTask(input, context);
      const parsed = agentRunResultSchema.safeParse(raw);
      if (!parsed.success) {
        this.lifecycle = 'failed';
        this.deps.logger.error(`agent.${this.type}.invalid_output`, {
          issues: parsed.error.issues,
        });
        return {
          status: 'failed',
          summary: `Agent ${this.type} produced an invalid output shape.`,
          output: { issues: parsed.error.issues },
        };
      }
      const result = parsed.data as AgentRunResult;
      this.lifecycle =
        result.status === 'failed' ? 'failed' : 'completed';
      this.deps.bus.emit('agent.finished', {
        type: this.type,
        id: this.id,
        status: result.status,
      });
      return result;
    } catch (err) {
      this.lifecycle = 'failed';
      this.deps.logger.error(`agent.${this.type}.error`, {
        error: (err as Error).message,
      });
      return {
        status: 'failed',
        summary: `Agent ${this.type} failed: ${(err as Error).message}`,
        output: {},
      };
    }
  }

  getLifecycle(): TaskLifecycle {
    return this.lifecycle;
  }
}
