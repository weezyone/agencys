import OpenAI from 'openai';
import type { AiClient, Logger, MessageBus } from './base-agent.js';

export const consoleLogger: Logger = {
  info: (msg, meta) =>
    console.log(`[info] ${msg}`, meta ? JSON.stringify(meta) : ''),
  warn: (msg, meta) =>
    console.warn(`[warn] ${msg}`, meta ? JSON.stringify(meta) : ''),
  error: (msg, meta) =>
    console.error(`[err] ${msg}`, meta ? JSON.stringify(meta) : ''),
};

export function createInProcessBus(): MessageBus {
  const listeners = new Map<string, Array<(p: Record<string, unknown>) => void>>();
  return {
    emit(event, payload) {
      const l = listeners.get(event);
      if (!l) return;
      for (const fn of l) fn(payload);
    },
    on(event, handler) {
      const arr = listeners.get(event) ?? [];
      arr.push(handler);
      listeners.set(event, arr);
    },
  };
}

/**
 * A deterministic offline AI client. In V1 the platform can run without
 * external LLM keys — the client fabricates plausible structured content
 * grounded in the agent's system prompt and user input.
 */
export function createStubAiClient(): AiClient {
  return {
    async complete({ system, user }) {
      const seed = `${system}::${user}`.length;
      return {
        text: `Signal ${seed % 997}. ${user.slice(0, 60)}`.trim(),
      };
    },
  };
}

/**
 * Real OpenAI-backed client. Uses the Chat Completions API with the model
 * from OPENAI_MODEL (defaults to gpt-4o-mini). Requires OPENAI_API_KEY.
 */
export function createOpenAiClient(logger: Logger = consoleLogger): AiClient {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    throw new Error('OPENAI_API_KEY is not set');
  }
  const client = new OpenAI({ apiKey });
  const model = process.env.OPENAI_MODEL ?? 'gpt-4o-mini';

  return {
    async complete({ system, user }) {
      try {
        const response = await client.chat.completions.create({
          model,
          messages: [
            { role: 'system', content: system },
            { role: 'user', content: user },
          ],
          temperature: 0.4,
        });
        const text = response.choices[0]?.message?.content ?? '';
        return { text };
      } catch (err) {
        logger.error('openai.complete.error', { error: (err as Error).message });
        throw err;
      }
    },
  };
}

/**
 * Selects the AI client based on env: real OpenAI when OPENAI_API_KEY is set,
 * otherwise the deterministic stub. Set WEEZY_FORCE_STUB=1 to always use stub.
 */
export function createConfiguredAiClient(logger: Logger = consoleLogger): AiClient {
  if (process.env.WEEZY_FORCE_STUB === '1') {
    logger.info('ai.client.selected', { mode: 'stub-forced' });
    return createStubAiClient();
  }
  if (process.env.OPENAI_API_KEY) {
    logger.info('ai.client.selected', {
      mode: 'openai',
      model: process.env.OPENAI_MODEL ?? 'gpt-4o-mini',
    });
    return createOpenAiClient(logger);
  }
  logger.info('ai.client.selected', { mode: 'stub' });
  return createStubAiClient();
}
