# Technical Architecture — V1 Agent‑Powered Agency Platform

## 1. Architecture Design

```mermaid
graph TD
    subgraph "Client (Browser)"
        UI["React SPA (Vite)"]
        ACF["Agent Client Factory"]
    end

    subgraph "Server (Next.js API Routes / Express)"
        API["/api/agents/:type/run"]
        WFAPI["/api/workflows/*"]
        WR["WorkflowRunner"]
        AF["AgentFactory"]
        BUS["MessageBus (in-process)"]
        LOG["Logger"]
    end

    subgraph "Agents"
        BA["BaseAgent (abstract)"]
        PM["ProjectManagerAgent"]
        RS["ResearchAgent"]
        DS["DesignerAgent"]
        TL["TechLeadAgent"]
        FS["FullStackEngineerAgent"]
        QA["QAAgent"]
        CG["ClientGrowthAgent"]
    end

    subgraph "Storage"
        AS["ArtifactStore (JSON file / SQLite)"]
        MEM["Workflow State Store"]
    end

    subgraph "External"
        LLM["LLM Provider (OpenAI / Anthropic)"]
    end

    UI --> ACF
    ACF -->|"POST"| API
    UI --> WFAPI
    WFAPI --> WR
    API --> AF
    WR --> AF
    AF --> PM
    AF --> RS
    AF --> DS
    AF --> TL
    AF --> FS
    AF --> QA
    AF --> CG
    PM -.-> BA
    RS -.-> BA
    DS -.-> BA
    TL -.-> BA
    FS -.-> BA
    QA -.-> BA
    CG -.-> BA
    BA --> LLM
    WR --> AS
    WR --> MEM
    BA --> BUS
    BA --> LOG
```

## 2. Technology Description
- **Frontend**: React@18 + TypeScript + tailwindcss@3 + Vite; Motion (framer-motion) for staggered reveals; lucide-react for icons; TanStack Query for server state; Zustand for local UI state.
- **Fonts**: Fraunces (variable) and JetBrains Mono via Fontsource.
- **Backend**: Node.js server exposed via Express@4 (or Next.js API routes if the frontend later moves to Next). All LLM calls happen server‑side to protect keys.
- **Agent runtime**: TypeScript classes; abstract `BaseAgent` with injected `AiClient`, `MessageBus`, `ArtifactStore`, `Logger`.
- **Persistence**: File‑based JSON artifact store under `./data/artifacts` for V1; workflow state in a SQLite file via `better-sqlite3`. Interface designed so it can be swapped for Postgres later.
- **AI Client**: thin wrapper around the OpenAI SDK; provider is configurable through environment variables.
- **Init tool**: vite-init for scaffolding the client.

## 3. Route Definitions
| Route | Purpose |
|-------|---------|
| `/` | Dashboard: metrics strip, active runs, recent artifacts |
| `/agents` | Agents Directory (grid + detail drawer) |
| `/agents/:type` | Deep link to a specific agent card |
| `/workflows` | Workflows Console: catalog + runs table |
| `/workflows/:runId` | Workflow Run Detail: DAG, approvals, artifacts |
| `/artifacts` | Artifacts Library with filters |
| `/artifacts/:id` | Individual artifact viewer |
| `/projects` | Projects list |
| `/projects/:id` | Project detail + associated workflow runs |
| `/leads` | Leads list & context editor |

## 4. API Definitions

### 4.1 Agent execution
`POST /api/agents/:type/run`

Request:
```typescript
type AgentType =
  | 'project_manager'
  | 'research'
  | 'designer'
  | 'tech_lead'
  | 'full_stack_engineer'
  | 'qa'
  | 'client_growth';

interface AgentRunRequest {
  context: {
    tenantId: string;
    projectId?: string;
    leadId?: string;
    workflowRunId?: string;
  };
  input: Record<string, unknown>; // free‑form task payload
}
```

Response:
```typescript
interface AgentRunResult {
  status: 'completed' | 'failed' | 'needs_review';
  summary: string;
  output: Record<string, unknown>;
  questions?: string[];
  risks?: string[];
  artifactId?: string;
}
```

### 4.2 Workflow orchestration
| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/workflows` | List workflow definitions |
| POST | `/api/workflows/:id/runs` | Launch a workflow run |
| GET | `/api/workflows/runs` | List runs (filterable by project/lead/status) |
| GET | `/api/workflows/runs/:runId` | Fetch run detail with steps and artifacts |
| POST | `/api/workflows/runs/:runId/steps/:stepId/approve` | Resolve an approval gate |
| POST | `/api/workflows/runs/:runId/steps/:stepId/reject` | Reject and optionally requeue |

Workflow shapes:
```typescript
interface WorkflowStep {
  id: string;
  title: string;
  agentType: AgentType;
  dependsOn: string[];
  requiresApproval: boolean;
}

interface WorkflowDefinition {
  id: 'lead_to_outreach' | 'intake_to_brief' | 'brief_to_build_plan';
  name: string;
  description: string;
  steps: WorkflowStep[];
}

interface WorkflowRun {
  id: string;
  definitionId: WorkflowDefinition['id'];
  status: 'running' | 'needs_review' | 'completed' | 'failed';
  startedAt: string;
  completedAt?: string;
  steps: Array<WorkflowStep & {
    status: 'pending' | 'in_progress' | 'needs_review' | 'completed' | 'failed';
    artifactId?: string;
    startedAt?: string;
    completedAt?: string;
  }>;
  context: AgentRunRequest['context'];
}
```

### 4.3 Artifacts
| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/artifacts` | List artifacts with filters (agent, workflow, project) |
| GET | `/api/artifacts/:id` | Fetch artifact content |

```typescript
interface Artifact {
  id: string;
  workflowRunId?: string;
  projectId?: string;
  leadId?: string;
  agentType: AgentType;
  title: string;
  content: Record<string, unknown>;
  createdAt: string;
}
```

## 5. Server Architecture Diagram

```mermaid
graph TD
    C["HTTP Controller (Express Router)"] --> S["Service Layer (WorkflowService, AgentService)"]
    S --> R["Repository Layer (ArtifactRepo, RunRepo)"]
    R --> DB["SQLite + JSON files"]
    S --> AF["AgentFactory"]
    AF --> BA["BaseAgent implementations"]
    BA --> LLM["AiClient -> LLM Provider"]
```

Layer responsibilities:
- **Controller**: request validation (zod), auth stub, response shaping.
- **Service**: `WorkflowService.launch/step/approve`, `AgentService.run`. Owns transitions between step states and calls into the `WorkflowRunner`.
- **Repository**: pure data access for `WorkflowRun`, `Artifact`, `Project`, `Lead` records.
- **AgentFactory**: registry mapping `AgentType → constructor`; injects `AiClient`, `MessageBus`, `ArtifactStore`, `Logger`.
- **BaseAgent**: manages task lifecycle and delegates model calls; subclasses override `getDefaultSystemPrompt()` and `executeTask()`.

## 6. Data Model

### 6.1 Data Model Definition

```mermaid
erDiagram
    PROJECT ||--o{ WORKFLOW_RUN : "runs"
    LEAD ||--o{ WORKFLOW_RUN : "runs"
    WORKFLOW_RUN ||--|{ WORKFLOW_STEP : "has"
    WORKFLOW_STEP ||--o| ARTIFACT : "produces"
    PROJECT ||--o{ ARTIFACT : "owns"

    PROJECT {
        string id PK
        string tenant_id
        string name
        string status
        json context
        string created_at
    }
    LEAD {
        string id PK
        string tenant_id
        string company
        string contact_name
        string contact_email
        json context
        string created_at
    }
    WORKFLOW_RUN {
        string id PK
        string definition_id
        string status
        string project_id FK
        string lead_id FK
        json context
        string started_at
        string completed_at
    }
    WORKFLOW_STEP {
        string id PK
        string workflow_run_id FK
        string step_key
        string title
        string agent_type
        json depends_on
        boolean requires_approval
        string status
        string artifact_id FK
        string started_at
        string completed_at
    }
    ARTIFACT {
        string id PK
        string workflow_run_id FK
        string project_id FK
        string lead_id FK
        string agent_type
        string title
        json content
        string created_at
    }
```

### 6.2 Data Definition Language

```sql
-- Projects
CREATE TABLE projects (
    id           TEXT PRIMARY KEY,
    tenant_id    TEXT NOT NULL,
    name         TEXT NOT NULL,
    status       TEXT NOT NULL DEFAULT 'active',
    context      TEXT NOT NULL DEFAULT '{}',
    created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_projects_tenant ON projects(tenant_id);

-- Leads
CREATE TABLE leads (
    id            TEXT PRIMARY KEY,
    tenant_id     TEXT NOT NULL,
    company       TEXT NOT NULL,
    contact_name  TEXT,
    contact_email TEXT,
    context       TEXT NOT NULL DEFAULT '{}',
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_leads_tenant ON leads(tenant_id);

-- Workflow runs
CREATE TABLE workflow_runs (
    id             TEXT PRIMARY KEY,
    definition_id  TEXT NOT NULL,
    status         TEXT NOT NULL,
    project_id     TEXT REFERENCES projects(id),
    lead_id        TEXT REFERENCES leads(id),
    context        TEXT NOT NULL DEFAULT '{}',
    started_at     TEXT NOT NULL DEFAULT (datetime('now')),
    completed_at   TEXT
);
CREATE INDEX idx_runs_status ON workflow_runs(status);

-- Workflow steps
CREATE TABLE workflow_steps (
    id                TEXT PRIMARY KEY,
    workflow_run_id   TEXT NOT NULL REFERENCES workflow_runs(id) ON DELETE CASCADE,
    step_key          TEXT NOT NULL,
    title             TEXT NOT NULL,
    agent_type        TEXT NOT NULL,
    depends_on        TEXT NOT NULL DEFAULT '[]',
    requires_approval INTEGER NOT NULL DEFAULT 0,
    status            TEXT NOT NULL DEFAULT 'pending',
    artifact_id       TEXT,
    started_at        TEXT,
    completed_at      TEXT
);
CREATE INDEX idx_steps_run ON workflow_steps(workflow_run_id);

-- Artifacts
CREATE TABLE artifacts (
    id               TEXT PRIMARY KEY,
    workflow_run_id  TEXT REFERENCES workflow_runs(id),
    project_id       TEXT REFERENCES projects(id),
    lead_id          TEXT REFERENCES leads(id),
    agent_type       TEXT NOT NULL,
    title            TEXT NOT NULL,
    content          TEXT NOT NULL,
    created_at       TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_artifacts_run ON artifacts(workflow_run_id);
CREATE INDEX idx_artifacts_agent ON artifacts(agent_type);

-- Seed workflow definitions (application-level, not stored in DB for V1)
-- lead_to_outreach: research -> client_growth (approval)
-- intake_to_brief: project_manager -> research -> project_manager (approval)
-- brief_to_build_plan: designer -> tech_lead -> qa (approval)
```

## 7. File Structure (agent core)

```
src/
  agents/
    core/
      agent-types.ts         # AgentType enum
      agent-context.ts       # AgentContext interface
      agent-result.ts        # AgentRunResult type
      base-agent.ts          # abstract BaseAgent
      agent-factory.ts       # createAgent(type, deps)
    project-manager-agent.ts
    research-agent.ts
    designer-agent.ts
    tech-lead-agent.ts
    full-stack-engineer-agent.ts
    qa-agent.ts
    client-growth-agent.ts
  workflows/
    workflow-runner.ts
    definitions/
      lead-to-outreach.ts
      intake-to-brief.ts
      brief-to-build-plan.ts
  storage/
    artifact-store.ts        # interface + FileArtifactStore
    run-repository.ts
  services/
    ai-client.ts             # LLM wrapper
    message-bus.ts           # in‑process EventEmitter
    logger.ts
  server/
    routes/
      agents.ts              # POST /api/agents/:type/run
      workflows.ts
      artifacts.ts
  client/
    agent-client-factory.ts  # browser‑side run() wrapper
```

## 8. Non‑Functional Requirements
- All LLM keys read from `process.env` on the server; never exposed to the browser.
- Structured JSON output enforced with a schema validator (zod) before persisting artifacts.
- Deterministic step ordering; the runner never advances a step whose dependencies are not `completed`.
- Approval gates halt execution and emit a `workflow.needs_review` event on the message bus.
- Ready for future upgrades: swap `FileArtifactStore` for a Postgres repository, replace in‑process `MessageBus` with Redis Streams / BullMQ, add parallel step execution.
