# Product Requirements Document — V1 Agent‑Powered Agency Platform

## 1. Product Overview
An AI‑powered design/development agency platform where specialized agents collaborate to research prospects, produce strategy documents, generate code artifacts and orchestrate client outreach.
- Solves the fragmentation of running a boutique agency by unifying research, PM, design, engineering, QA and growth into an orchestrated workflow.
- Target users: solo founders and small agency operators who want to scale delivery capacity without expanding headcount.

## 2. Core Features

### 2.1 User Roles
| Role | Registration Method | Core Permissions |
|------|---------------------|------------------|
| Operator (Agency Owner) | Email login | Create projects/leads, launch workflows, approve gates, review artifacts |
| Reviewer (Optional) | Invitation link | View artifacts, sign off on approval gates |

### 2.2 Feature Module
1. **Dashboard**: workflow overview, active runs, pending approvals, recent artifacts.
2. **Agents Directory**: browse the seven specialized agents, inspect prompts and system persona, run ad‑hoc tasks.
3. **Workflows Console**: launch preset workflows (Lead→Outreach, Intake→Brief, Brief→Build Plan), visualize step DAG, monitor status, resolve approval gates.
4. **Workflow Run Detail**: step‑by‑step timeline, live logs, artifact previews, approve/reject controls, requeue failed steps.
5. **Artifacts Library**: filter/search structured outputs (briefs, research memos, code plans, QA checklists) with preview and download.
6. **Projects & Leads**: manage client records, associated context (tenant/project/lead IDs) that flows into agent context.

### 2.3 Page Details
| Page Name | Module Name | Feature description |
|-----------|-------------|---------------------|
| Dashboard | Metrics strip | Live counts of running workflows, pending approvals, artifacts produced this week |
| Dashboard | Active runs | Cards for each workflow with progress bar, current step, agent avatar, ETA state |
| Dashboard | Recent artifacts | Compact stack of the last 6 artifacts with agent tag and open action |
| Agents Directory | Agent grid | Seven agent cards (PM, Research, Designer, Tech Lead, Full‑Stack, QA, Client Growth) each with tone, capabilities, live status |
| Agents Directory | Agent detail drawer | Shows system prompt, sample outputs, run ad‑hoc task form |
| Workflows Console | Workflow catalog | Three preset workflows with description and launch CTA |
| Workflows Console | Runs table | Sortable list of workflow runs with status pills (running / needs_review / completed / failed) |
| Workflow Run Detail | Step DAG canvas | Ordered vertical timeline with dependency lines, per‑step status and agent chip |
| Workflow Run Detail | Approval gate panel | Diff‑style artifact preview with Approve / Request changes buttons |
| Workflow Run Detail | Artifact preview | Rendered structured output (summary, output, questions, risks) |
| Artifacts Library | Filter rail | Filter by agent type, workflow, project, date |
| Artifacts Library | Artifact card | Title, producing agent, timestamp, quick copy/export |
| Projects & Leads | Records list | CRUD on projects and leads with tenant scope |
| Projects & Leads | Context editor | Set project/lead metadata that agents inject into their runs |

## 3. Core Process
Operators start on the Dashboard, pick or create a Project/Lead, launch a preset workflow from the Workflows Console. The Workflow Runner picks up the first ready step, instantiates the correct agent via the AgentFactory, executes the task, and stores the result in the Artifact Store. When a step is flagged `requiresApproval`, the run pauses in `needs_review` and the operator resolves it in the Workflow Run Detail. On approval the runner continues until completion; artifacts are surfaced in the Artifacts Library.

```mermaid
graph TD
    A["Operator opens Dashboard"] --> B["Select Project or Lead"]
    B --> C["Launch preset workflow"]
    C --> D["WorkflowRunner picks next ready step"]
    D --> E{"Step needs approval?"}
    E -->|"Yes"| F["Pause: needs_review"]
    F --> G["Operator reviews artifact"]
    G -->|"Approve"| D
    G -->|"Reject"| H["Requeue or edit step"]
    E -->|"No"| I["AgentFactory creates agent"]
    I --> J["Agent.executeTask"]
    J --> K["Store artifact"]
    K --> L{"More steps?"}
    L -->|"Yes"| D
    L -->|"No"| M["Workflow completed"]
```

## 4. User Interface Design

### 4.1 Design Style
- **Aesthetic direction**: editorial/technical — think a Bauhaus lab notebook meeting a modern operator console. Deliberate, information‑dense, warm and confident, not another purple‑gradient SaaS clone.
- **Primary palette**: deep ink `#0D0D0F`, bone `#F4EFE6`, signal amber `#E8B23C`, muted teal `#2E5E5E`, alert coral `#D6553B`.
- **Typography**: display in **Fraunces** (variable, high‑contrast serif) for headlines and agent names; body/UI in **JetBrains Mono** for status, labels, artifact IDs; secondary sans in **Söhne / Inter Tight fallback** only where mono density becomes overwhelming.
- **Buttons**: sharp 2px borders, 6px radius, no pill buttons; primary uses ink fill on bone background with amber underline‑hover.
- **Layout**: 12‑column asymmetric grid, wide left rail for navigation, dense center console, right utility drawer for context; grid‑breaking labels in the margins with numeric prefixes (§01 / §02).
- **Icon style**: hand‑drawn 1.25px stroke line icons plus small monogrammed agent glyphs (PM, RS, DS, TL, FS, QA, CG). Emojis are avoided.
- **Motion**: staggered reveals on page load, ticker‑style status transitions, subtle grain overlay, and a persistent workflow "heartbeat" indicator.

### 4.2 Page Design Overview
| Page Name | Module Name | UI Elements |
|-----------|-------------|-------------|
| Dashboard | Metrics strip | Bone background, ink numerals in Fraunces 72pt, mono captions, thin amber divider |
| Dashboard | Active runs | Ink cards with amber progress bar, status ticker, agent monogram badge |
| Agents Directory | Agent grid | 7 asymmetric tiles, each with agent glyph, one‑line manifesto in serif italics, mono capability list |
| Workflows Console | Step DAG canvas | Vertical timeline with connecting rules, teal for completed, amber for running, coral for needs_review |
| Workflow Run Detail | Approval gate | Full‑bleed artifact preview with margin annotations, Approve (ink) / Request changes (coral outline) |
| Artifacts Library | Filter rail | Sticky left rail, mono facets, subtle inset separators |
| Projects & Leads | Context editor | Two‑column form, mono inputs, inline validation with coral underline |

### 4.3 Responsiveness
Desktop‑first (1440 baseline). Below 1024px the utility drawer collapses into a bottom sheet, the DAG canvas becomes horizontally scrollable, and margin numerals fold into inline captions. Touch targets stay ≥44px.
