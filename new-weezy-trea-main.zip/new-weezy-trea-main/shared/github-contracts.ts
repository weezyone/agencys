/**
 * GitHub API contracts — the subset of fields the weezy UI needs.
 * These are the response shapes for the server routes under `/api/github`,
 * NOT raw GitHub JSON (which is snake_case).
 */

export interface GitHubRepo {
  id: number;
  fullName: string;
  name: string;
  owner: string;
  defaultBranch: string;
  private: boolean;
  description?: string;
  updatedAt: string;
  language?: string;
  stargazersCount: number;
}

export interface GitHubBranch {
  name: string;
  sha: string;
  protected: boolean;
}

export interface RepoListResponse {
  repos: GitHubRepo[];
  source: 'github' | 'unconfigured';
}

export interface BranchListResponse {
  branches: GitHubBranch[];
  defaultBranch: string;
}
