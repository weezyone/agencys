export type SandboxStatus =
  | 'provisioning'
  | 'running'
  | 'paused'
  | 'terminated'
  | 'failed';

export type SandboxRuntime = 'node22' | 'python';

export type SandboxLogLevel = 'info' | 'warn' | 'error';

export interface SandboxLog {
  id: string;
  timestamp: string;
  level: SandboxLogLevel;
  message: string;
  source: string;
}

// Git types (co-located per spec)

export interface GitCommit {
  sha: string;
  message: string;
  author: string;
  timestamp: string;
  filesChanged: number;
  additions: number;
  deletions: number;
}

export interface GitBranch {
  name: string;
  isCurrent: boolean;
  ahead: number;
  behind: number;
}

export interface GitDiffFile {
  path: string;
  status: 'added' | 'modified' | 'deleted';
  additions: number;
  deletions: number;
  hunks: string[];
}

export type PullRequestStatus = 'draft' | 'open' | 'merged' | 'closed';

export interface PullRequest {
  id: string;
  number: number;
  title: string;
  description: string;
  sourceBranch: string;
  targetBranch: string;
  url: string;
  status: PullRequestStatus;
  createdAt: string;
}

export interface SandboxGitState {
  branches: GitBranch[];
  currentBranch: string;
  commits: GitCommit[];
  diff: GitDiffFile[];
  pulls: PullRequest[];
  nextPrNumber: number;
}

export interface Sandbox {
  id: string;
  name: string;
  status: SandboxStatus;
  repoUrl?: string;
  branch?: string;
  vcpus: number;
  memoryMb: number;
  timeoutMinutes: number;
  runtime: SandboxRuntime;
  createdAt: string;
  terminatedAt?: string;
  domainUrl?: string;
  projectId?: string;
  logs: SandboxLog[];
  git: SandboxGitState;
}

export interface SandboxCreateInput {
  name: string;
  repoUrl?: string;
  branch?: string;
  vcpus?: number;
  timeoutMinutes?: number;
  runtime?: SandboxRuntime;
  projectId?: string;
  /**
   * Optional GitHub repo selection from the picker. When present, the server
   * synthesises `repoUrl`, initial branch, and a "cloned from …" log entry
   * from these fields. The runtime remains simulated — no real clone happens.
   */
  repo?: {
    owner: string;
    name: string;
    branch: string;
  };
}

export type SandboxAgentKind = 'claude_code' | 'codex_cli';

export interface SandboxAgentRunResult {
  summary: string;
  diff: string;
  agent: SandboxAgentKind;
  task: string;
  timestamp: string;
}

export interface SandboxExecResult {
  command: string;
  stdout: string;
  exitCode: number;
  timestamp: string;
}
