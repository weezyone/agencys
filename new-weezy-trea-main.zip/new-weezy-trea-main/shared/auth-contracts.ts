export interface AuthSession {
  userId: string;
  login: string;
  name?: string;
  avatarUrl?: string;
  scopes: string[];
  connectedAt: string;
  /**
   * GitHub access token. SERVER-ONLY — must never appear in any HTTP response
   * sent to the client. Persisted to the file session store so the server
   * can make GitHub API calls (repos, branches) on behalf of the user.
   */
  accessToken?: string;
  /**
   * GitHub access token used by per-sandbox git operations (branches,
   * commits, PRs). SERVER-ONLY — sanitizeSession() must strip this before
   * any AuthSession is returned to the client. Populated on OAuth success
   * alongside {@link AuthSession.accessToken}.
   */
  githubToken?: string;
}

export interface DeviceFlowInit {
  deviceCode: string;
  userCode: string;
  verificationUri: string;
  expiresAt: string;
  interval: number;
}

export type AuthStatus = 'anonymous' | 'pending' | 'authenticated';

export interface AuthView {
  status: AuthStatus;
  session?: AuthSession;
  pending?: {
    userCode: string;
    verificationUri: string;
    expiresAt: string;
  };
  configured: boolean;
}
