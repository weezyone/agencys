import type { AgentType } from './agent-types';

export interface AgentContext {
  tenantId: string;
  projectId?: string;
  leadId?: string;
  workflowRunId?: string;
}

export type AgentRunStatus = 'completed' | 'failed' | 'needs_review';

export interface AgentRunResult {
  status: AgentRunStatus;
  summary: string;
  output: Record<string, unknown>;
  questions?: string[];
  risks?: string[];
  artifactId?: string;
}

export interface AgentRunRequest {
  context: AgentContext;
  input: Record<string, unknown>;
}

// Workflow types

export type WorkflowDefinitionId =
  | 'lead_to_outreach'
  | 'intake_to_brief'
  | 'brief_to_build_plan';

export interface WorkflowStep {
  id: string;
  title: string;
  agentType: AgentType;
  dependsOn: string[];
  requiresApproval: boolean;
}

export interface WorkflowDefinition {
  id: WorkflowDefinitionId;
  name: string;
  description: string;
  steps: WorkflowStep[];
}

export type StepStatus =
  | 'pending'
  | 'in_progress'
  | 'needs_review'
  | 'completed'
  | 'failed';

export type RunStatus = 'running' | 'needs_review' | 'completed' | 'failed';

/**
 * A durable record of one attempt at a workflow step. Persisted so that
 * on server restart we can rehydrate progress and continue exactly where
 * execution stopped — mirrors the WDK checkpoint concept.
 */
export interface StepCheckpoint {
  attempt: number;
  startedAt: string;
  completedAt?: string;
  status: 'in_progress' | 'succeeded' | 'failed';
  input?: Record<string, unknown>;
  outputSummary?: string;
  error?: string;
}

export interface WorkflowRunStep extends WorkflowStep {
  status: StepStatus;
  artifactId?: string;
  startedAt?: string;
  completedAt?: string;
  /** How many times this step has been attempted (successes + failures). */
  attempts?: number;
  /** Max attempts before the step is marked failed. Defaults to 3. */
  maxAttempts?: number;
  /** ISO timestamp of the next scheduled retry (exponential backoff). */
  nextRetryAt?: string;
  /** Most recent error message from a failed attempt. */
  lastError?: string;
  /** Ordered per-attempt checkpoints for durable replay. */
  checkpoints?: StepCheckpoint[];
  /**
   * Most recent durable checkpoint — the input/output record replayed on
   * restart. Inspired by Vercel WDK's per-step checkpoint semantics.
   */
  checkpoint?: {
    input: Record<string, unknown>;
    output?: Record<string, unknown>;
    recordedAt: string;
  };
}

export interface WorkflowRun {
  id: string;
  definitionId: WorkflowDefinitionId;
  name: string;
  status: RunStatus;
  startedAt: string;
  completedAt?: string;
  steps: WorkflowRunStep[];
  context: AgentContext;
  label?: string;
  /**
   * ISO timestamp captured when a run was replayed from disk on server boot
   * (durable resume). Absent for runs that never needed rehydration.
   */
  resumedAt?: string;
}

// Artifacts

export interface Artifact {
  id: string;
  workflowRunId?: string;
  projectId?: string;
  leadId?: string;
  agentType: AgentType;
  title: string;
  content: {
    summary: string;
    output: Record<string, unknown>;
    questions?: string[];
    risks?: string[];
  };
  createdAt: string;
}

// Projects & Leads

export interface Project {
  id: string;
  tenantId: string;
  name: string;
  status: 'active' | 'archived' | 'discovery';
  context: Record<string, string>;
  createdAt: string;
}

export interface Lead {
  id: string;
  tenantId: string;
  company: string;
  contactName?: string;
  contactEmail?: string;
  context: Record<string, string>;
  createdAt: string;
}
