import type { SandboxRuntime } from './sandbox-contracts';

export interface PlatformSettings {
  aiProviders: {
    anthropicApiKey?: string;
    openaiApiKey?: string;
    googleApiKey?: string;
    nvidiaApiKey?: string;
    /**
     * Optional override for the NVIDIA NIM model id. When unset, defaults to
     * meta/llama-3.1-70b-instruct which is broadly available on integrate.api.nvidia.com.
     */
    nvidiaModel?: string;
  };
  sandboxDefaults: {
    vcpus: number;
    timeoutMinutes: number;
    runtime: SandboxRuntime;
  };
  git: {
    defaultAuthorName?: string;
    defaultAuthorEmail?: string;
    defaultTargetBranch: string;
  };
  updatedAt: string;
}

export const DEFAULT_SETTINGS: PlatformSettings = {
  aiProviders: {},
  sandboxDefaults: {
    vcpus: 2,
    timeoutMinutes: 30,
    runtime: 'node22',
  },
  git: {
    defaultTargetBranch: 'main',
  },
  updatedAt: new Date(0).toISOString(),
};

export const DEFAULT_NVIDIA_MODEL = 'meta/llama-3.1-70b-instruct';
export const NVIDIA_NIM_BASE_URL = 'https://integrate.api.nvidia.com/v1';

/**
 * Mask a secret key so only the last 4 characters are visible, e.g.
 * `sk-…f00d`. Returns undefined for empty / missing values so callers can
 * distinguish "not set" from "set but hidden".
 */
export function maskKey(k?: string): string | undefined {
  if (!k) return undefined;
  const trimmed = k.trim();
  if (!trimmed) return undefined;
  const last4 = trimmed.slice(-4);
  return `sk-…${last4}`;
}
