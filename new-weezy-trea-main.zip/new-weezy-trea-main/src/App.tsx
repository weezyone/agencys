import { BrowserRouter, Route, Routes } from 'react-router-dom';
import AppShell from '@/components/AppShell';
import AuthGate from '@/components/AuthGate';
import DashboardPage from '@/pages/DashboardPage';
import AgentsPage from '@/pages/AgentsPage';
import WorkflowsPage from '@/pages/WorkflowsPage';
import WorkflowRunPage from '@/pages/WorkflowRunPage';
import ArtifactsPage from '@/pages/ArtifactsPage';
import ProjectsPage from '@/pages/ProjectsPage';
import LeadsPage from '@/pages/LeadsPage';
import WorkspacePage from '@/pages/WorkspacePage';
import SettingsPage from '@/pages/SettingsPage';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<AppShell />}>
          <Route path="/" element={<DashboardPage />} />
          <Route path="/agents" element={<AgentsPage />} />
          <Route path="/workflows" element={<WorkflowsPage />} />
          <Route path="/workflows/:runId" element={<WorkflowRunPage />} />
          <Route path="/artifacts" element={<ArtifactsPage />} />
          <Route path="/projects" element={<ProjectsPage />} />
          <Route path="/leads" element={<LeadsPage />} />
          <Route
            path="/workspace"
            element={
              <AuthGate>
                <WorkspacePage />
              </AuthGate>
            }
          />
          <Route path="/settings" element={<SettingsPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
