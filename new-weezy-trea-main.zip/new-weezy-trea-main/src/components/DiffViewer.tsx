import { useMemo } from 'react';

export type DiffRow =
  | { kind: 'context'; before: number; after: number; text: string }
  | { kind: 'add'; after: number; text: string }
  | { kind: 'remove'; before: number; text: string };

interface DiffViewerProps {
  before?: string;
  after: string;
  filename?: string;
  language?: string;
  className?: string;
}

const MAX_ROWS = 500;

/**
 * Compute a line-level diff using an LCS table. Artifacts here are short,
 * so the O(n*m) cost is acceptable and yields readable, well-aligned rows.
 */
function computeDiff(beforeLines: string[], afterLines: string[]): DiffRow[] {
  const n = beforeLines.length;
  const m = afterLines.length;

  // LCS length table
  const lcs: number[][] = Array.from({ length: n + 1 }, () =>
    new Array(m + 1).fill(0),
  );
  for (let i = 1; i <= n; i++) {
    for (let j = 1; j <= m; j++) {
      if (beforeLines[i - 1] === afterLines[j - 1]) {
        lcs[i][j] = lcs[i - 1][j - 1] + 1;
      } else {
        lcs[i][j] = Math.max(lcs[i - 1][j], lcs[i][j - 1]);
      }
    }
  }

  // Backtrack to produce rows
  const rows: DiffRow[] = [];
  let i = n;
  let j = m;
  while (i > 0 && j > 0) {
    if (beforeLines[i - 1] === afterLines[j - 1]) {
      rows.push({
        kind: 'context',
        before: i,
        after: j,
        text: beforeLines[i - 1],
      });
      i--;
      j--;
    } else if (lcs[i - 1][j] >= lcs[i][j - 1]) {
      rows.push({ kind: 'remove', before: i, text: beforeLines[i - 1] });
      i--;
    } else {
      rows.push({ kind: 'add', after: j, text: afterLines[j - 1] });
      j--;
    }
  }
  while (i > 0) {
    rows.push({ kind: 'remove', before: i, text: beforeLines[i - 1] });
    i--;
  }
  while (j > 0) {
    rows.push({ kind: 'add', after: j, text: afterLines[j - 1] });
    j--;
  }
  return rows.reverse();
}

function splitLines(input: string): string[] {
  if (input === '') return [];
  return input.replace(/\r\n/g, '\n').split('\n');
}

/**
 * Compute add/remove counts without allocating the full row list. Handy for
 * summary labels above collapsed diff panels.
 */
export function diffStats(
  before: string | undefined,
  after: string,
): { adds: number; removes: number } {
  const afterLines = splitLines(after);
  if (before === undefined || before === '') {
    return { adds: afterLines.length, removes: 0 };
  }
  const beforeLines = splitLines(before);
  const rows = computeDiff(beforeLines, afterLines);
  let adds = 0;
  let removes = 0;
  for (const r of rows) {
    if (r.kind === 'add') adds++;
    else if (r.kind === 'remove') removes++;
  }
  return { adds, removes };
}

export default function DiffViewer({
  before,
  after,
  filename,
  language,
  className,
}: DiffViewerProps) {
  const isNewFile = before === undefined || before === '';

  const { rows, adds, removes, truncated, totalRows } = useMemo(() => {
    const afterLines = splitLines(after);
    if (isNewFile) {
      const all: DiffRow[] = afterLines.map((text, idx) => ({
        kind: 'add' as const,
        after: idx + 1,
        text,
      }));
      const shown = all.slice(0, MAX_ROWS);
      return {
        rows: shown,
        adds: all.length,
        removes: 0,
        truncated: Math.max(0, all.length - shown.length),
        totalRows: all.length,
      };
    }
    const beforeLines = splitLines(before as string);
    const all = computeDiff(beforeLines, afterLines);
    const a = all.filter((r) => r.kind === 'add').length;
    const r = all.filter((r) => r.kind === 'remove').length;
    const shown = all.slice(0, MAX_ROWS);
    return {
      rows: shown,
      adds: a,
      removes: r,
      truncated: Math.max(0, all.length - shown.length),
      totalRows: all.length,
    };
  }, [before, after, isNewFile]);

  const rootClass = [
    'border border-ink/15 bg-parchment/60',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <div className={rootClass}>
      <header className="flex flex-wrap items-baseline justify-between gap-2 border-b border-ink/15 px-3 py-2">
        <div className="flex items-baseline gap-2">
          <span className="marginal">{isNewFile ? '§ new file' : '§ diff'}</span>
          {filename && (
            <span className="font-mono text-[11px] text-ink">{filename}</span>
          )}
          {language && (
            <span className="font-mono text-[10px] uppercase tracking-marginal text-ink/40">
              {language}
            </span>
          )}
          {isNewFile && (
            <span className="border border-teal-deep px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-marginal text-teal-deep">
              new file
            </span>
          )}
        </div>
        <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-marginal">
          <span className="text-teal-deep">+{adds}</span>
          <span className="text-ink/40">/</span>
          <span className="text-coral">−{removes}</span>
        </div>
      </header>

      {isNewFile ? (
        <div className="max-h-[420px] overflow-auto">
          <div className="grid grid-cols-[auto_1fr]">
            {rows.map((row, idx) => (
              <DiffCell key={idx} row={row} side="after" />
            ))}
          </div>
        </div>
      ) : (
        <div className="max-h-[420px] overflow-auto">
          <div className="grid grid-cols-2 divide-x divide-ink/15">
            <div className="grid grid-cols-[auto_1fr] content-start">
              {rows.map((row, idx) => (
                <DiffCell key={`b-${idx}`} row={row} side="before" />
              ))}
            </div>
            <div className="grid grid-cols-[auto_1fr] content-start">
              {rows.map((row, idx) => (
                <DiffCell key={`a-${idx}`} row={row} side="after" />
              ))}
            </div>
          </div>
        </div>
      )}

      {truncated > 0 && (
        <div className="border-t border-ink/15 px-3 py-2 text-center font-mono text-[10px] uppercase tracking-marginal text-ink/60">
          …{truncated} more lines (of {totalRows})
        </div>
      )}
    </div>
  );
}

function DiffCell({
  row,
  side,
}: {
  row: DiffRow;
  side: 'before' | 'after';
}) {
  // Which line number to show in the gutter for this side
  const lineNo =
    side === 'before'
      ? row.kind === 'add'
        ? undefined
        : row.before
      : row.kind === 'remove'
      ? undefined
      : row.after;

  // Highlight only on the relevant side
  let rowClass = '';
  let showText = true;
  if (side === 'before') {
    if (row.kind === 'remove') {
      rowClass = 'border-l-2 border-coral bg-coral/5 text-ink';
    } else if (row.kind === 'add') {
      // Placeholder to keep alignment with the after column
      rowClass = 'border-l-2 border-transparent';
      showText = false;
    } else {
      rowClass = 'border-l-2 border-transparent text-ink/70';
    }
  } else {
    if (row.kind === 'add') {
      rowClass = 'border-l-2 border-teal-deep bg-teal-deep/5 text-ink';
    } else if (row.kind === 'remove') {
      rowClass = 'border-l-2 border-transparent';
      showText = false;
    } else {
      rowClass = 'border-l-2 border-transparent text-ink/70';
    }
  }

  return (
    <>
      <div
        className={[
          'select-none px-2 py-0.5 font-mono text-[10px] text-ink/40',
          rowClass,
        ].join(' ')}
      >
        {lineNo ?? ' '}
      </div>
      <div
        className={[
          'whitespace-pre-wrap break-all px-2 py-0.5 font-mono text-[11px] leading-relaxed',
          rowClass,
        ].join(' ')}
      >
        {showText ? (row.text === '' ? '\u00A0' : row.text) : '\u00A0'}
      </div>
    </>
  );
}
