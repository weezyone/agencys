import { AGENT_DIRECTORY, type AgentType } from '@shared/agent-types';
import { AGENT_STROKE } from '@/lib/format';

interface AgentGlyphProps {
  type: AgentType;
  size?: number;
  variant?: 'ink' | 'bone' | 'outline';
}

export function AgentGlyph({ type, size = 48, variant = 'ink' }: AgentGlyphProps) {
  const desc = AGENT_DIRECTORY[type];
  const stroke = AGENT_STROKE[type];
  // Use CSS variables so the glyph honours the current theme automatically.
  const inkColor = 'rgb(var(--color-ink))';
  const boneColor = 'rgb(var(--color-bone))';
  const bg =
    variant === 'ink' ? inkColor : variant === 'bone' ? boneColor : 'transparent';
  const fg = variant === 'ink' ? boneColor : inkColor;
  return (
    <span
      className="relative inline-flex shrink-0 items-center justify-center"
      style={{ width: size, height: size }}
      aria-label={desc.name}
    >
      <svg
        width={size}
        height={size}
        viewBox="0 0 48 48"
        className="absolute inset-0"
      >
        <rect
          x="1.5"
          y="1.5"
          width="45"
          height="45"
          fill={bg}
          stroke={stroke}
          strokeWidth="1.5"
        />
        <line x1="1.5" y1="9" x2="46.5" y2="9" stroke={stroke} strokeWidth="0.75" />
      </svg>
      <span
        className="relative font-mono font-medium"
        style={{ color: fg, fontSize: size * 0.28 }}
      >
        {desc.code}
      </span>
    </span>
  );
}
