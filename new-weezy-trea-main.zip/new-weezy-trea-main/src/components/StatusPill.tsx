import type { RunStatus, StepStatus } from '@shared/agent-contracts';
import { RUN_STATUS_TONE, STEP_STATUS_TONE } from '@/lib/format';
import { cn } from '@/lib/utils';

const LABEL: Record<RunStatus | StepStatus, string> = {
  running: 'running',
  needs_review: 'needs review',
  completed: 'completed',
  failed: 'failed',
  pending: 'pending',
  in_progress: 'in progress',
};

export function StatusPill({
  status,
  kind = 'run',
  className,
}: {
  status: RunStatus | StepStatus;
  kind?: 'run' | 'step';
  className?: string;
}) {
  const tone =
    kind === 'run'
      ? RUN_STATUS_TONE[status as RunStatus]
      : STEP_STATUS_TONE[status as StepStatus];
  return (
    <span className={cn('status-pill', tone, className)}>
      <Dot status={status} />
      {LABEL[status]}
    </span>
  );
}

function Dot({ status }: { status: RunStatus | StepStatus }) {
  const cls =
    status === 'running' || status === 'in_progress'
      ? 'heartbeat bg-current'
      : 'bg-current';
  return <span className={cn('inline-block h-1.5 w-1.5 rounded-full', cls)} />;
}
