import { useQuery } from '@tanstack/react-query';
import { GitBranch, Github } from 'lucide-react';
import {
  GitHubAuthRequiredError,
  fetchAuth,
  listBranches,
  listRepos,
} from '@/lib/api';
import { cn } from '@/lib/utils';

export interface RepoPickerValue {
  owner: string;
  name: string;
  branch: string;
}

interface RepoPickerProps {
  value?: RepoPickerValue;
  onChange: (v?: RepoPickerValue) => void;
  disabled?: boolean;
}

/**
 * Compact "scratch vs GitHub" picker for the new-sandbox form. Uses the
 * server-side proxy at /api/github so the OAuth token never leaves the
 * server. When OAuth isn't configured, or the session lacks a GitHub
 * token, we degrade to a marginal explanation and force the "scratch"
 * mode. The workflow keeps working end-to-end.
 */
export default function RepoPicker({
  value,
  onChange,
  disabled,
}: RepoPickerProps) {
  const auth = useQuery({
    queryKey: ['auth'],
    queryFn: fetchAuth,
    refetchInterval: false,
  });

  const mode: 'scratch' | 'github' = value ? 'github' : 'scratch';

  const authenticated =
    auth.data?.status === 'authenticated' && auth.data.configured;
  const oauthUnconfigured = auth.data ? !auth.data.configured : false;

  const reposQuery = useQuery({
    queryKey: ['github-repos'],
    queryFn: listRepos,
    enabled: mode === 'github' && authenticated,
    staleTime: 60_000,
    retry: false,
  });

  const branchesQuery = useQuery({
    queryKey: ['github-branches', value?.owner, value?.name],
    queryFn: () =>
      value
        ? listBranches(value.owner, value.name)
        : Promise.resolve({ branches: [], defaultBranch: 'main' }),
    enabled: mode === 'github' && authenticated && !!value,
    staleTime: 60_000,
    retry: false,
  });

  const repos = reposQuery.data ?? [];
  const branches = branchesQuery.data?.branches ?? [];

  const handleModeChange = (next: 'scratch' | 'github') => {
    if (next === 'scratch') {
      onChange(undefined);
      return;
    }
    // "from GitHub" chip pressed — pick the first repo if we have one.
    const first = repos[0];
    if (first) {
      onChange({
        owner: first.owner,
        name: first.name,
        branch: first.defaultBranch,
      });
    } else {
      // Sentinel: mark github mode with empty selection so the dropdowns render.
      onChange({ owner: '', name: '', branch: '' });
    }
  };

  const handleRepoSelect = (fullName: string) => {
    const found = repos.find((r) => r.fullName === fullName);
    if (!found) {
      onChange({ owner: '', name: '', branch: '' });
      return;
    }
    onChange({
      owner: found.owner,
      name: found.name,
      branch: found.defaultBranch,
    });
  };

  const handleBranchSelect = (branch: string) => {
    if (!value) return;
    onChange({ ...value, branch });
  };

  const isAuthError = reposQuery.error instanceof GitHubAuthRequiredError;

  return (
    <div className="flex flex-col gap-2">
      <span className="font-mono text-[10px] uppercase tracking-marginal text-ink/60">
        Source
      </span>
      <div className="flex gap-2">
        <ModeChip
          active={mode === 'scratch'}
          onClick={() => !disabled && handleModeChange('scratch')}
          disabled={disabled}
        >
          scratch
        </ModeChip>
        <ModeChip
          active={mode === 'github'}
          onClick={() => !disabled && handleModeChange('github')}
          disabled={disabled}
          icon={<Github className="h-3 w-3" />}
        >
          from GitHub
        </ModeChip>
      </div>

      {mode === 'github' && oauthUnconfigured && (
        <p className="mt-1 font-mono text-[11px] leading-relaxed text-coral">
          GitHub OAuth isn&apos;t configured — set GITHUB_CLIENT_ID to enable
          repo picking.
        </p>
      )}

      {mode === 'github' && !oauthUnconfigured && !authenticated && (
        <p className="mt-1 font-mono text-[11px] leading-relaxed text-coral">
          Connect a GitHub account first —{' '}
          <a
            href="/workspace"
            className="underline underline-offset-2 hover:text-ink"
          >
            sign in
          </a>{' '}
          to browse your repos.
        </p>
      )}

      {mode === 'github' && authenticated && (
        <div className="flex flex-col gap-2">
          {isAuthError && (
            <p className="font-mono text-[11px] text-coral">
              GitHub session expired — please sign in again.
            </p>
          )}
          {reposQuery.isLoading && (
            <p className="font-mono text-[11px] text-ink/60">loading repos…</p>
          )}
          {reposQuery.isSuccess && repos.length === 0 && (
            <p className="font-mono text-[11px] text-ink/60">
              no repos found for this account.
            </p>
          )}
          {repos.length > 0 && (
            <label className="flex flex-col gap-1 font-mono text-[10px] uppercase tracking-marginal text-ink/60">
              Repository
              <select
                value={value ? `${value.owner}/${value.name}` : ''}
                onChange={(e) => handleRepoSelect(e.target.value)}
                disabled={disabled}
                className="w-full border border-ink/30 bg-bone px-2 py-1.5 font-mono text-xs text-ink focus:border-ink focus:outline-none"
              >
                <option value="">— select a repo —</option>
                {repos.map((r) => (
                  <option key={r.id} value={r.fullName}>
                    {r.fullName}
                    {r.private ? ' · private' : ''}
                  </option>
                ))}
              </select>
            </label>
          )}
          {value && value.owner && (
            <label className="flex flex-col gap-1 font-mono text-[10px] uppercase tracking-marginal text-ink/60">
              <span className="inline-flex items-center gap-1.5">
                <GitBranch className="h-3 w-3" /> Branch
              </span>
              <select
                value={value.branch}
                onChange={(e) => handleBranchSelect(e.target.value)}
                disabled={disabled || branchesQuery.isLoading}
                className="w-full border border-ink/30 bg-parchment/60 px-2 py-1.5 font-mono text-xs text-teal-deep focus:border-ink focus:outline-none"
              >
                {branchesQuery.isLoading && (
                  <option value={value.branch}>loading…</option>
                )}
                {!branchesQuery.isLoading && branches.length === 0 && (
                  <option value={value.branch}>{value.branch}</option>
                )}
                {branches.map((b) => (
                  <option key={b.sha} value={b.name}>
                    {b.name}
                    {b.protected ? ' · protected' : ''}
                  </option>
                ))}
              </select>
            </label>
          )}
        </div>
      )}
    </div>
  );
}

function ModeChip({
  active,
  onClick,
  children,
  icon,
  disabled,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
  icon?: React.ReactNode;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={cn(
        'inline-flex items-center gap-1.5 border px-3 py-1 font-mono text-[11px] uppercase tracking-marginal transition-colors',
        active
          ? 'border-ink bg-ink text-bone'
          : 'border-ink/30 bg-parchment/60 text-ink/70 hover:border-ink hover:text-ink',
        disabled && 'cursor-not-allowed opacity-60',
      )}
    >
      {icon}
      {children}
    </button>
  );
}
