import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { pad } from '@/lib/format';
import ThemeToggle from '@/components/ThemeToggle';
import { fetchAuth, logout } from '@/lib/api';

const NAV = [
  { path: '/', label: 'Console' },
  { path: '/workspace', label: 'Workspace' },
  { path: '/agents', label: 'Agents' },
  { path: '/workflows', label: 'Workflows' },
  { path: '/artifacts', label: 'Artifacts' },
  { path: '/projects', label: 'Projects' },
  { path: '/leads', label: 'Leads' },
  { path: '/settings', label: 'Settings' },
];

export default function AppShell() {
  const { pathname } = useLocation();
  const activeIdx = Math.max(
    0,
    NAV.findIndex((n) =>
      n.path === '/' ? pathname === '/' : pathname.startsWith(n.path),
    ),
  );

  return (
    <div className="grain relative min-h-screen text-ink">
      <div className="mx-auto flex min-h-screen max-w-[1440px] gap-0 px-6 py-8 lg:px-10">
        <aside className="sticky top-8 hidden h-[calc(100vh-4rem)] w-56 shrink-0 flex-col justify-between border-r border-ink/15 pr-6 lg:flex">
          <div>
            <div className="mb-10">
              <p className="marginal">§00 · Studio Console</p>
              <h1 className="display-serif mt-3 text-3xl leading-[0.95] text-ink">
                weezy
                <span className="text-coral">.</span>
              </h1>
              <p className="mt-2 font-mono text-[11px] text-ink/60">
                Agent‑powered agency, V1
              </p>
            </div>
            <nav className="space-y-1">
              {NAV.map((n, i) => (
                <NavLink
                  key={n.path}
                  to={n.path}
                  end={n.path === '/'}
                  className={({ isActive }) =>
                    [
                      'group flex items-baseline gap-3 border-l-2 py-2 pl-3 font-mono text-xs uppercase tracking-marginal transition-colors',
                      isActive
                        ? 'border-ink text-ink'
                        : 'border-transparent text-ink/50 hover:text-ink',
                    ].join(' ')
                  }
                >
                  <span className="text-[10px] text-ink/40">§{pad(i + 1)}</span>
                  <span>{n.label}</span>
                </NavLink>
              ))}
            </nav>
          </div>
          <footer className="space-y-3 pt-6">
            <div className="rule" />
            <p className="marginal">Now serving</p>
            <p className="font-display text-lg leading-tight text-ink">
              Seven agents,
              <br />
              <em className="text-teal-deep">one calm console.</em>
            </p>
            <div className="flex items-center gap-2 pt-2">
              <span className="heartbeat inline-block h-2 w-2 rounded-full bg-coral" />
              <span className="font-mono text-[10px] uppercase tracking-marginal text-ink/60">
                system live
              </span>
            </div>
          </footer>
        </aside>

        <main className="min-w-0 flex-1 lg:pl-10">
          <TopBar activeIdx={activeIdx} />
          <motion.div
            key={pathname}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
          >
            <Outlet />
          </motion.div>
        </main>
      </div>
    </div>
  );
}

function TopBar({ activeIdx }: { activeIdx: number }) {
  return (
    <div className="mb-8 flex items-center justify-between border-b border-ink/15 pb-4">
      <div className="flex items-baseline gap-3 font-mono text-[11px] uppercase tracking-marginal text-ink/60">
        <span>§{pad(activeIdx + 1)}</span>
        <span className="h-px w-10 bg-ink/40" />
        <span>{new Date().toLocaleDateString('en-GB', { weekday: 'long', day: '2-digit', month: 'short' })}</span>
      </div>
      <div className="flex items-center gap-3">
        <div className="hidden items-center gap-2 md:flex">
          <span className="heartbeat inline-block h-1.5 w-1.5 rounded-full bg-teal-deep" />
          <span className="font-mono text-[10px] uppercase tracking-marginal text-ink/60">
            runner: idle → advancing
          </span>
        </div>
        <ThemeToggle />
        <UserChip />
        <div className="border border-ink px-3 py-1 font-mono text-[10px] uppercase tracking-marginal">
          v1 · demo tenant
        </div>
      </div>
    </div>
  );
}

function UserChip() {
  const qc = useQueryClient();
  const auth = useQuery({
    queryKey: ['auth'],
    queryFn: fetchAuth,
    refetchInterval: false,
  });

  const data = auth.data;
  if (!data || !data.configured) return null;

  if (data.status === 'authenticated' && data.session) {
    return (
      <div className="group inline-flex items-center gap-2 border border-ink/40 px-2.5 py-1 font-mono text-[10px] uppercase tracking-marginal text-ink/70">
        <span className="text-ink">@{data.session.login}</span>
        <button
          type="button"
          onClick={async () => {
            await logout();
            qc.invalidateQueries({ queryKey: ['auth'] });
          }}
          className="hidden border-l border-ink/40 pl-2 text-coral hover:text-ink group-hover:inline"
          aria-label="Log out"
          title="Log out"
        >
          logout
        </button>
      </div>
    );
  }

  return (
    <a
      href="/workspace"
      className="marginal border border-transparent px-2.5 py-1 hover:border-ink/40 hover:text-ink"
    >
      sign in
    </a>
  );
}
