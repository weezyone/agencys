import { useEffect, useRef, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { ExternalLink } from 'lucide-react';
import {
  fetchAuth,
  pollLogin,
  startLogin,
  type StartLoginOk,
} from '@/lib/api';

interface AuthGateProps {
  children: React.ReactNode;
}

/**
 * Full-page sign-in gate for the workspace. If OAuth isn't configured
 * (dev fallback) we still render children so the demo keeps working.
 */
export default function AuthGate({ children }: AuthGateProps) {
  const qc = useQueryClient();
  const auth = useQuery({
    queryKey: ['auth'],
    queryFn: fetchAuth,
    refetchInterval: false,
  });

  if (auth.isLoading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <p className="marginal">verifying session…</p>
      </div>
    );
  }

  const data = auth.data;
  if (!data) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <p className="marginal text-coral">auth service unavailable</p>
      </div>
    );
  }

  // Dev fallback: OAuth not configured — let children through.
  if (!data.configured) {
    return (
      <div className="flex flex-col gap-6">
        <div className="border border-coral/40 bg-coral/5 p-4 font-mono text-[11px] text-coral">
          GitHub OAuth isn&apos;t configured — set GITHUB_CLIENT_ID and restart.
          Rendering workspace unlocked for local development.
        </div>
        {children}
      </div>
    );
  }

  if (data.status === 'authenticated') {
    return <>{children}</>;
  }

  return (
    <SignInScreen
      onAuthenticated={() => {
        qc.invalidateQueries({ queryKey: ['auth'] });
      }}
    />
  );
}

function SignInScreen({ onAuthenticated }: { onAuthenticated: () => void }) {
  const [pending, setPending] = useState<StartLoginOk | null>(null);
  const [starting, setStarting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notConfigured, setNotConfigured] = useState(false);
  const intervalRef = useRef<number | null>(null);

  const stopPolling = () => {
    if (intervalRef.current !== null) {
      window.clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  };

  useEffect(() => {
    return () => stopPolling();
  }, []);

  const beginPolling = (entry: StartLoginOk) => {
    stopPolling();
    const intervalMs = Math.max(entry.interval, 1) * 1000;
    intervalRef.current = window.setInterval(async () => {
      const res = await pollLogin(entry.pendingId);
      if (res.status === 'authenticated') {
        stopPolling();
        onAuthenticated();
      } else if (res.status === 'expired') {
        stopPolling();
        setError('device code expired — please try again.');
        setPending(null);
      } else if (res.status === 'error') {
        stopPolling();
        setError(res.error ?? 'authorization failed.');
        setPending(null);
      }
    }, intervalMs);
  };

  const handleStart = async () => {
    setStarting(true);
    setError(null);
    setNotConfigured(false);
    const res = await startLogin();
    setStarting(false);
    if ('error' in res) {
      if (res.status === 501) {
        setNotConfigured(true);
      } else {
        setError(res.error);
      }
      return;
    }
    setPending(res);
    beginPolling(res);
  };

  const handleCancel = () => {
    stopPolling();
    setPending(null);
  };

  return (
    <div className="flex min-h-[70vh] flex-col justify-center pb-24">
      <header className="mb-10">
        <p className="marginal">§ auth · GitHub</p>
        <h2 className="display-serif mt-3 text-5xl leading-[0.95] md:text-6xl">
          Sign in with GitHub
          <span className="text-coral">.</span>
        </h2>
        <p className="mt-4 max-w-xl font-mono text-xs leading-relaxed text-ink/70">
          The workspace is gated behind a GitHub identity. We use the device
          flow — nothing is stored beyond your username and avatar, and no
          redirect URL is required.
        </p>
      </header>

      {notConfigured && (
        <div className="mb-6 max-w-xl border border-coral/40 bg-coral/5 p-4 font-mono text-[11px] text-coral">
          GitHub OAuth isn&apos;t configured — set GITHUB_CLIENT_ID and restart.
        </div>
      )}

      {error && (
        <div className="mb-6 max-w-xl border border-coral/40 bg-coral/5 p-4 font-mono text-[11px] text-coral">
          {error}
        </div>
      )}

      {!pending ? (
        <div className="flex items-center gap-4">
          <button
            type="button"
            className="btn-ink"
            onClick={handleStart}
            disabled={starting}
          >
            {starting ? 'requesting device code…' : 'authorize weezy'}
          </button>
          <span className="marginal">RFC 8628 · device flow</span>
        </div>
      ) : (
        <div className="surface-card grain flex max-w-2xl flex-col gap-6 p-8">
          <div>
            <p className="marginal">§ one-time code</p>
            <p className="mt-3 font-mono text-5xl font-medium tracking-[0.4em] text-ink md:text-6xl">
              {pending.userCode}
            </p>
          </div>
          <div className="rule" />
          <div className="flex flex-col gap-2">
            <p className="marginal">§ next</p>
            <p className="font-display text-2xl leading-tight text-ink">
              Open GitHub and enter the code above.
            </p>
            <a
              href={pending.verificationUri}
              target="_blank"
              rel="noreferrer noopener"
              className="inline-flex items-center gap-2 font-mono text-xs text-teal-deep underline underline-offset-4 hover:text-ink"
            >
              <ExternalLink className="h-3.5 w-3.5" />
              {pending.verificationUri}
            </a>
          </div>
          <div className="flex items-center gap-4 pt-2">
            <span className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-marginal text-teal-deep">
              <span className="heartbeat inline-block h-1.5 w-1.5 rounded-full bg-current" />
              polling every {pending.interval}s
            </span>
            <button
              type="button"
              className="btn-outline"
              onClick={handleCancel}
            >
              cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
