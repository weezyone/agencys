import type {
  Artifact,
  Lead,
  Project,
  WorkflowDefinition,
  WorkflowRun,
} from '@shared/agent-contracts';
import type { AgentDescriptor, AgentType } from '@shared/agent-types';
import type {
  GitBranch,
  GitCommit,
  GitDiffFile,
  PullRequest,
  Sandbox,
  SandboxAgentKind,
  SandboxAgentRunResult,
  SandboxCreateInput,
  SandboxExecResult,
  SandboxLog,
  SandboxStatus,
} from '@shared/sandbox-contracts';
import type { PlatformSettings } from '@shared/settings-contracts';
import type { AuthSession, AuthView } from '@shared/auth-contracts';
import type {
  BranchListResponse,
  GitHubBranch,
  GitHubRepo,
  RepoListResponse,
} from '@shared/github-contracts';

async function req<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(path, {
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    ...init,
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`${res.status} ${body}`);
  }
  return res.json() as Promise<T>;
}

// Agents
export const fetchAgents = () =>
  req<{ agents: AgentDescriptor[] }>('/api/agents').then((d) => d.agents);

export interface AgentAdHocResult {
  status: 'completed' | 'failed' | 'needs_review';
  summary: string;
  output: Record<string, unknown>;
  questions?: string[];
  risks?: string[];
}
export const runAgent = (type: AgentType, input: Record<string, unknown>) =>
  req<{ result: AgentAdHocResult }>(`/api/agents/${type}/run`, {
    method: 'POST',
    body: JSON.stringify({
      context: { tenantId: 'tenant_default' },
      input,
    }),
  }).then((d) => d.result);

// Workflows
export const fetchWorkflowDefinitions = () =>
  req<{ definitions: WorkflowDefinition[] }>('/api/workflows').then(
    (d) => d.definitions,
  );

export const fetchWorkflowRuns = () =>
  req<{ runs: WorkflowRun[] }>('/api/workflows/runs').then((d) => d.runs);

export const fetchWorkflowRun = (id: string) =>
  req<{ run: WorkflowRun }>(`/api/workflows/runs/${id}`).then((d) => d.run);

export const launchWorkflow = (
  id: string,
  payload: {
    context: { tenantId: string; projectId?: string; leadId?: string };
    label?: string;
  },
) =>
  req<{ run: WorkflowRun }>(`/api/workflows/${id}/runs`, {
    method: 'POST',
    body: JSON.stringify(payload),
  }).then((d) => d.run);

export const approveStep = (runId: string, stepId: string) =>
  req<{ run: WorkflowRun }>(
    `/api/workflows/runs/${runId}/steps/${stepId}/approve`,
    { method: 'POST' },
  ).then((d) => d.run);

export const rejectStep = (runId: string, stepId: string) =>
  req<{ run: WorkflowRun }>(
    `/api/workflows/runs/${runId}/steps/${stepId}/reject`,
    { method: 'POST' },
  ).then((d) => d.run);

export const retryStep = (runId: string, stepId: string) =>
  req<{ run: WorkflowRun }>(
    `/api/workflows/runs/${runId}/steps/${stepId}/retry`,
    { method: 'POST' },
  ).then((d) => d.run);

// Artifacts
export const fetchArtifacts = (filter?: {
  agentType?: string;
  workflowRunId?: string;
  projectId?: string;
  leadId?: string;
}) => {
  const params = new URLSearchParams();
  if (filter?.agentType) params.set('agentType', filter.agentType);
  if (filter?.workflowRunId) params.set('workflowRunId', filter.workflowRunId);
  if (filter?.projectId) params.set('projectId', filter.projectId);
  if (filter?.leadId) params.set('leadId', filter.leadId);
  const q = params.toString();
  return req<{ artifacts: Artifact[] }>(`/api/artifacts${q ? `?${q}` : ''}`).then(
    (d) => d.artifacts,
  );
};

export const fetchArtifact = (id: string) =>
  req<{ artifact: Artifact }>(`/api/artifacts/${id}`).then((d) => d.artifact);

// Directory
export const fetchProjects = () =>
  req<{ projects: Project[] }>('/api/projects').then((d) => d.projects);

export const createProject = (payload: {
  name: string;
  status?: 'active' | 'archived' | 'discovery';
  context?: Record<string, string>;
}) =>
  req<{ project: Project }>('/api/projects', {
    method: 'POST',
    body: JSON.stringify(payload),
  }).then((d) => d.project);

export const fetchLeads = () =>
  req<{ leads: Lead[] }>('/api/leads').then((d) => d.leads);

export const createLead = (payload: {
  company: string;
  contactName?: string;
  contactEmail?: string;
  context?: Record<string, string>;
}) =>
  req<{ lead: Lead }>('/api/leads', {
    method: 'POST',
    body: JSON.stringify(payload),
  }).then((d) => d.lead);

// Sandboxes
export const fetchSandboxes = () =>
  req<{ sandboxes: Sandbox[] }>('/api/sandboxes').then((d) => d.sandboxes);

export const createSandbox = (payload: SandboxCreateInput) =>
  req<{ sandbox: Sandbox }>('/api/sandboxes', {
    method: 'POST',
    body: JSON.stringify(payload),
  }).then((d) => d.sandbox);

export const fetchSandbox = (id: string) =>
  req<{ sandbox: Sandbox }>(`/api/sandboxes/${id}`).then((d) => d.sandbox);

export const fetchSandboxLogs = (id: string, since?: string) => {
  const q = since ? `?since=${encodeURIComponent(since)}` : '';
  return req<{ logs: SandboxLog[]; status: SandboxStatus }>(
    `/api/sandboxes/${id}/logs${q}`,
  );
};

export const pauseSandbox = (id: string) =>
  req<{ sandbox: Sandbox }>(`/api/sandboxes/${id}/pause`, {
    method: 'POST',
  }).then((d) => d.sandbox);

export const resumeSandbox = (id: string) =>
  req<{ sandbox: Sandbox }>(`/api/sandboxes/${id}/resume`, {
    method: 'POST',
  }).then((d) => d.sandbox);

export const terminateSandbox = (id: string) =>
  req<{ sandbox: Sandbox }>(`/api/sandboxes/${id}/terminate`, {
    method: 'POST',
  }).then((d) => d.sandbox);

export const execInSandbox = (id: string, command: string) =>
  req<{ result: SandboxExecResult }>(`/api/sandboxes/${id}/exec`, {
    method: 'POST',
    body: JSON.stringify({ command }),
  }).then((d) => d.result);

export const runAgentInSandbox = (
  id: string,
  agent: SandboxAgentKind,
  task: string,
) =>
  req<{ result: SandboxAgentRunResult }>(`/api/sandboxes/${id}/agent`, {
    method: 'POST',
    body: JSON.stringify({ agent, task }),
  }).then((d) => d.result);

export type GitMode = 'live' | 'simulated';

// Git (per-sandbox)
export const git = {
  branches: (id: string) =>
    req<{ branches: GitBranch[]; mode: GitMode }>(
      `/api/sandboxes/${id}/git/branches`,
    ),
  createBranch: (id: string, name: string) =>
    req<{ branch: GitBranch; branches: GitBranch[]; mode: GitMode }>(
      `/api/sandboxes/${id}/git/branches`,
      { method: 'POST', body: JSON.stringify({ name }) },
    ),
  checkout: (id: string, name: string) =>
    req<{ branches: GitBranch[]; mode: GitMode }>(
      `/api/sandboxes/${id}/git/branches/${encodeURIComponent(name)}/checkout`,
      { method: 'POST' },
    ),
  diff: (id: string) =>
    req<{ diff: GitDiffFile[]; mode: GitMode }>(
      `/api/sandboxes/${id}/git/diff`,
    ),
  commit: (id: string, message: string, author?: string) =>
    req<{ commit: GitCommit; commits: GitCommit[]; mode: GitMode }>(
      `/api/sandboxes/${id}/git/commits`,
      { method: 'POST', body: JSON.stringify({ message, author }) },
    ),
  commits: (id: string) =>
    req<{ commits: GitCommit[]; mode: GitMode }>(
      `/api/sandboxes/${id}/git/commits`,
    ),
  pulls: (id: string) =>
    req<{ pulls: PullRequest[]; mode: GitMode }>(
      `/api/sandboxes/${id}/git/pulls`,
    ),
  createPull: (
    id: string,
    payload: { title: string; description?: string; targetBranch?: string },
  ) =>
    req<{ pull: PullRequest; pulls: PullRequest[]; mode: GitMode }>(
      `/api/sandboxes/${id}/git/pulls`,
      { method: 'POST', body: JSON.stringify(payload) },
    ),
};

// Settings
export interface SettingsView {
  aiProviders: {
    anthropicApiKey?: string;
    openaiApiKey?: string;
    googleApiKey?: string;
    nvidiaApiKey?: string;
    nvidiaModel?: string;
  };
  sandboxDefaults: PlatformSettings['sandboxDefaults'];
  git: PlatformSettings['git'];
  updatedAt: string;
  hasAnthropicKey: boolean;
  hasOpenaiKey: boolean;
  hasGoogleKey: boolean;
  hasNvidiaKey: boolean;
}

export interface SettingsPatch {
  aiProviders?: {
    anthropicApiKey?: string;
    openaiApiKey?: string;
    googleApiKey?: string;
    nvidiaApiKey?: string;
    nvidiaModel?: string;
  };
  sandboxDefaults?: Partial<PlatformSettings['sandboxDefaults']>;
  git?: Partial<PlatformSettings['git']>;
}

export const fetchSettings = () =>
  req<{ settings: SettingsView }>('/api/settings').then((d) => d.settings);

export const updateSettings = (patch: SettingsPatch) =>
  req<{ settings: SettingsView }>('/api/settings', {
    method: 'PUT',
    body: JSON.stringify(patch),
  }).then((d) => d.settings);

// Auth (GitHub device flow)
export interface StartLoginOk {
  pendingId: string;
  userCode: string;
  verificationUri: string;
  expiresAt: string;
  interval: number;
}

export interface StartLoginErr {
  error: string;
  status: number;
}

export interface PollLoginResult {
  status: 'pending' | 'authenticated' | 'expired' | 'error';
  session?: AuthSession;
  error?: string;
}

export const fetchAuth = async (): Promise<AuthView> => {
  const res = await fetch('/api/auth/me', {
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
  });
  if (!res.ok) {
    return { status: 'anonymous', configured: false };
  }
  return (await res.json()) as AuthView;
};

export const startLogin = async (): Promise<StartLoginOk | StartLoginErr> => {
  const res = await fetch('/api/auth/login/start', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
  });
  if (!res.ok) {
    let error = `HTTP ${res.status}`;
    try {
      const body = (await res.json()) as { error?: string };
      if (body?.error) error = body.error;
    } catch {
      /* ignore */
    }
    return { error, status: res.status };
  }
  return (await res.json()) as StartLoginOk;
};

export const pollLogin = async (
  pendingId: string,
): Promise<PollLoginResult> => {
  const res = await fetch('/api/auth/login/poll', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify({ pendingId }),
  });
  if (res.status === 410) {
    return { status: 'expired' };
  }
  if (!res.ok) {
    let error = `HTTP ${res.status}`;
    try {
      const body = (await res.json()) as { error?: string };
      if (body?.error) error = body.error;
    } catch {
      /* ignore */
    }
    return { status: 'error', error };
  }
  const body = (await res.json()) as
    | { status: 'pending' }
    | AuthView
    | { status: 'error'; error?: string };
  if ('session' in body && body.session) {
    return { status: 'authenticated', session: body.session };
  }
  if ('status' in body && body.status === 'pending') {
    return { status: 'pending' };
  }
  if ('status' in body && body.status === 'error') {
    return { status: 'error', error: (body as { error?: string }).error };
  }
  return { status: 'pending' };
};

export const logout = async (): Promise<void> => {
  await fetch('/api/auth/logout', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
  });
};

// GitHub (server-side proxy)
export class GitHubAuthRequiredError extends Error {
  constructor(message = 'GitHub authentication required') {
    super(message);
    this.name = 'GitHubAuthRequiredError';
  }
}

export class GitHubUnconfiguredError extends Error {
  constructor(message = 'GitHub OAuth not configured') {
    super(message);
    this.name = 'GitHubUnconfiguredError';
  }
}

export const listRepos = async (): Promise<GitHubRepo[]> => {
  const res = await fetch('/api/github/repos', {
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
  });
  if (res.status === 501) {
    // OAuth unconfigured — surface an empty list.
    return [];
  }
  if (res.status === 401) {
    throw new GitHubAuthRequiredError();
  }
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`${res.status} ${body}`);
  }
  const data = (await res.json()) as RepoListResponse;
  return data.repos;
};

export const listBranches = async (
  owner: string,
  repo: string,
): Promise<{ branches: GitHubBranch[]; defaultBranch: string }> => {
  const res = await fetch(
    `/api/github/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/branches`,
    {
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
    },
  );
  if (res.status === 501) {
    return { branches: [], defaultBranch: 'main' };
  }
  if (res.status === 401) {
    throw new GitHubAuthRequiredError();
  }
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`${res.status} ${body}`);
  }
  return (await res.json()) as BranchListResponse;
};
