import type { AgentType } from '@shared/agent-types';
import type { RunStatus, StepStatus } from '@shared/agent-contracts';

export const AGENT_STROKE: Record<AgentType, string> = {
  project_manager: '#2E5E5E',
  research: '#0D0D0F',
  designer: '#D6553B',
  tech_lead: '#1F4444',
  full_stack_engineer: '#0D0D0F',
  qa: '#E8B23C',
  client_growth: '#2E5E5E',
};

export const RUN_STATUS_TONE: Record<RunStatus, string> = {
  running: 'text-teal-deep border-teal-deep',
  needs_review: 'text-coral border-coral',
  completed: 'text-ink border-ink',
  failed: 'text-coral border-coral',
};

export const STEP_STATUS_TONE: Record<StepStatus, string> = {
  pending: 'text-ink/40 border-ink/40',
  in_progress: 'text-amber border-amber',
  needs_review: 'text-coral border-coral',
  completed: 'text-teal-deep border-teal-deep',
  failed: 'text-coral border-coral',
};

export function formatRelative(iso?: string) {
  if (!iso) return '—';
  const d = new Date(iso);
  const diff = Date.now() - d.getTime();
  const min = Math.round(diff / 60_000);
  if (min < 1) return 'just now';
  if (min < 60) return `${min}m ago`;
  const hr = Math.round(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const day = Math.round(hr / 24);
  return `${day}d ago`;
}

export function pad(n: number, w = 2) {
  return String(n).padStart(w, '0');
}
