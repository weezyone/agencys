import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { createProject, fetchProjects } from '@/lib/api';
import { formatRelative, pad } from '@/lib/format';

export default function ProjectsPage() {
  const qc = useQueryClient();
  const { data: projects = [] } = useQuery({
    queryKey: ['projects'],
    queryFn: fetchProjects,
  });
  const [name, setName] = useState('');
  const [industry, setIndustry] = useState('');
  const [goal, setGoal] = useState('');

  const mutation = useMutation({
    mutationFn: () =>
      createProject({
        name,
        status: 'discovery',
        context: { industry, goal },
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['projects'] });
      setName('');
      setIndustry('');
      setGoal('');
    },
  });

  return (
    <div className="pb-24">
      <header className="mb-10">
        <p className="marginal">§01 · Ledger</p>
        <h2 className="display-serif mt-3 text-5xl leading-[0.95]">
          Projects
          <em className="text-teal-deep"> on file.</em>
        </h2>
      </header>
      <div className="grid grid-cols-1 gap-10 lg:grid-cols-[1fr_320px]">
        <section>
          <div className="border border-ink/15 bg-bone">
            <div className="grid grid-cols-[80px_1fr_140px_140px] gap-3 border-b border-ink/15 px-4 py-3 font-mono text-[10px] uppercase tracking-marginal text-ink/60">
              <span>id</span>
              <span>name · goal</span>
              <span>status</span>
              <span>opened</span>
            </div>
            {projects.map((p, i) => (
              <div
                key={p.id}
                className="grid grid-cols-[80px_1fr_140px_140px] gap-3 border-b border-ink/10 px-4 py-4 last:border-b-0 hover:bg-parchment"
              >
                <span className="font-mono text-[11px] text-ink/60">§{pad(i + 1)}</span>
                <div>
                  <p className="font-display text-lg leading-tight">{p.name}</p>
                  <p className="font-mono text-[11px] text-ink/60">
                    {p.context.goal ?? '—'}
                  </p>
                </div>
                <span className="font-mono text-[11px] uppercase tracking-marginal text-ink/70">
                  {p.status}
                </span>
                <span className="font-mono text-xs text-ink/70">
                  {formatRelative(p.createdAt)}
                </span>
              </div>
            ))}
            {projects.length === 0 && (
              <p className="p-6 font-mono text-xs text-ink/60">No projects yet.</p>
            )}
          </div>
        </section>

        <aside className="surface-card p-6">
          <p className="marginal">§ New entry</p>
          <h3 className="display-serif mt-2 text-2xl leading-tight">Add a project</h3>
          <form
            className="mt-4 space-y-3"
            onSubmit={(e) => {
              e.preventDefault();
              if (!name.trim()) return;
              mutation.mutate();
            }}
          >
            <Field label="Name">
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="w-full border border-ink/30 bg-bone px-3 py-2 font-mono text-xs focus:border-ink focus:outline-none"
              />
            </Field>
            <Field label="Industry">
              <input
                value={industry}
                onChange={(e) => setIndustry(e.target.value)}
                className="w-full border border-ink/30 bg-bone px-3 py-2 font-mono text-xs focus:border-ink focus:outline-none"
              />
            </Field>
            <Field label="Goal">
              <textarea
                value={goal}
                onChange={(e) => setGoal(e.target.value)}
                rows={3}
                className="w-full resize-none border border-ink/30 bg-bone px-3 py-2 font-mono text-xs focus:border-ink focus:outline-none"
              />
            </Field>
            <button className="btn-ink w-full justify-center" disabled={mutation.isPending}>
              {mutation.isPending ? 'saving…' : 'file project'}
            </button>
          </form>
        </aside>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="marginal">{label}</span>
      <div className="mt-1">{children}</div>
    </label>
  );
}
