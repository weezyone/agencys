import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { X } from 'lucide-react';
import { fetchAgents, runAgent, type AgentAdHocResult } from '@/lib/api';
import { AGENT_DIRECTORY, type AgentType } from '@shared/agent-types';
import { AgentGlyph } from '@/components/AgentGlyph';
import { pad } from '@/lib/format';

export default function AgentsPage() {
  const { data: agents = [] } = useQuery({ queryKey: ['agents'], queryFn: fetchAgents });
  const [openType, setOpenType] = useState<AgentType | null>(null);

  return (
    <div className="pb-24">
      <header className="mb-10">
        <p className="marginal">§01 · Roster</p>
        <h2 className="display-serif mt-3 text-5xl leading-[0.95] md:text-6xl">
          Seven voices,
          <br />
          <em className="text-teal-deep">one editorial line.</em>
        </h2>
        <p className="mt-4 max-w-xl font-mono text-xs leading-relaxed text-ink/70">
          Every agent is a specialist with a persona, a system prompt, and a way of returning
          structured work. Tap a card to review the prompt or run a task ad hoc.
        </p>
      </header>

      <div className="grid grid-cols-1 gap-0 border-l border-t border-ink/15 md:grid-cols-2 xl:grid-cols-3">
        {agents.map((a, i) => (
          <button
            key={a.type}
            onClick={() => setOpenType(a.type)}
            className="group relative flex flex-col gap-4 border-b border-r border-ink/15 p-6 text-left transition-colors hover:bg-parchment"
          >
            <div className="flex items-start justify-between">
              <span className="marginal">§{pad(i + 1)}</span>
              <span className="font-mono text-[10px] uppercase tracking-marginal text-ink/40 group-hover:text-ink/70">
                open —
              </span>
            </div>
            <AgentGlyph type={a.type} size={54} variant={i % 2 === 0 ? 'ink' : 'bone'} />
            <div>
              <p className="font-mono text-[10px] uppercase tracking-marginal text-ink/60">
                {a.role}
              </p>
              <h3 className="display-serif text-3xl leading-tight">{a.name}</h3>
              <p className="mt-2 font-display text-base italic text-teal-deep">
                “{a.manifesto}”
              </p>
            </div>
            <div className="rule mt-2" />
            <ul className="grid grid-cols-2 gap-x-4 gap-y-1 font-mono text-[11px] text-ink/70">
              {a.capabilities.map((c) => (
                <li key={c} className="before:mr-2 before:content-['—']">
                  {c}
                </li>
              ))}
            </ul>
          </button>
        ))}
      </div>

      {openType && <AgentDrawer type={openType} onClose={() => setOpenType(null)} />}
    </div>
  );
}

function AgentDrawer({ type, onClose }: { type: AgentType; onClose: () => void }) {
  const desc = AGENT_DIRECTORY[type];
  const qc = useQueryClient();
  const [notes, setNotes] = useState('');
  const [result, setResult] = useState<AgentAdHocResult | null>(null);

  const mutation = useMutation({
    mutationFn: () =>
      runAgent(type, buildInputForType(type, notes)),
    onSuccess: (r) => {
      setResult(r);
      qc.invalidateQueries({ queryKey: ['artifacts'] });
    },
  });

  return (
    <div className="fixed inset-0 z-40">
      <div
        className="absolute inset-0 bg-ink/40 backdrop-blur-sm"
        onClick={onClose}
        aria-label="Close drawer"
      />
      <aside className="absolute right-0 top-0 flex h-full w-full max-w-xl flex-col overflow-hidden bg-bone shadow-console">
        <header className="flex items-start justify-between border-b border-ink/15 p-6">
          <div className="flex items-center gap-4">
            <AgentGlyph type={type} size={56} />
            <div>
              <p className="marginal">{desc.role}</p>
              <h3 className="display-serif text-3xl leading-tight">{desc.name}</h3>
            </div>
          </div>
          <button className="btn-outline" onClick={onClose}>
            <X className="h-3.5 w-3.5" /> close
          </button>
        </header>
        <div className="flex-1 space-y-6 overflow-y-auto p-6 font-mono text-xs leading-relaxed text-ink">
          <section>
            <p className="marginal mb-2">System prompt</p>
            <pre className="whitespace-pre-wrap border border-ink/15 bg-parchment/60 p-4 text-ink/80">
              {promptFor(type)}
            </pre>
          </section>
          <section>
            <p className="marginal mb-2">Ad‑hoc task</p>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder={placeholderFor(type)}
              className="h-28 w-full resize-none border border-ink/30 bg-bone p-3 text-ink placeholder:text-ink/40 focus:border-ink focus:outline-none"
            />
            <button
              className="btn-ink mt-3"
              onClick={() => mutation.mutate()}
              disabled={mutation.isPending}
            >
              {mutation.isPending ? 'running…' : 'run task'}
            </button>
          </section>
          {result && (
            <section className="border border-ink/15 p-4">
              <p className="marginal">Result · {result.status}</p>
              <p className="mt-2 font-display text-base text-ink">{result.summary}</p>
              <pre className="mt-3 max-h-72 overflow-auto whitespace-pre-wrap bg-parchment/40 p-3 text-[11px]">
                {JSON.stringify(result.output, null, 2)}
              </pre>
              {result.questions?.length ? (
                <div className="mt-3">
                  <p className="marginal">questions</p>
                  <ul className="mt-1 list-disc pl-5 text-ink/70">
                    {result.questions.map((q) => (
                      <li key={q}>{q}</li>
                    ))}
                  </ul>
                </div>
              ) : null}
            </section>
          )}
        </div>
      </aside>
    </div>
  );
}

function promptFor(type: AgentType): string {
  return {
    project_manager:
      'You are Ines, a decisive project manager. Clarify goals, break work into milestones, name blockers plainly.',
    research:
      'You are Odele, a bookish research analyst. Cite specific facts, not vibes. Write source memos with a light editorial voice.',
    designer:
      'You are Kavi, a designer with an editorial soul. Propose brand and layout direction with restraint and one bold gesture.',
    tech_lead:
      'You are Junho, a tech lead. Choose boring, well-understood tech unless a bold pick is clearly worth the risk. Enumerate trade‑offs.',
    full_stack_engineer:
      'You are Rem, a cheerful pragmatist. Turn plans into small, testable diffs.',
    qa: 'You are Beata. Write acceptance criteria and probe the second question no one asked.',
    client_growth:
      'You are Theron. Write outreach that reads like a considered letter, not a sales blast.',
  }[type];
}

function placeholderFor(type: AgentType): string {
  return {
    project_manager: 'Brief: rebrand a boutique coffee co-op…',
    research: 'Subject: Nord Loom Studio, weaving atelier…',
    designer: 'Brand: Halcyon Type Foundry — quiet but confident.',
    tech_lead: 'Scope: build an internal artifact library…',
    full_stack_engineer: 'Feature: approval gates in workflow runner…',
    qa: 'Target: Lead → Outreach workflow…',
    client_growth: 'Lead: Argent & Salt; contact: Milo Kestrel',
  }[type];
}

function buildInputForType(type: AgentType, notes: string): Record<string, unknown> {
  const trimmed = notes.trim();
  switch (type) {
    case 'project_manager':
      return { brief: trimmed || 'V1 launch', objective: 'Ship in six weeks' };
    case 'research':
      return { subject: trimmed || 'Prospect', industry: 'Independent studio' };
    case 'designer':
      return { brand: trimmed || 'New client' };
    case 'tech_lead':
      return { scope: trimmed || 'V1 platform' };
    case 'full_stack_engineer':
      return { feature: trimmed || 'workflow_runner' };
    case 'qa':
      return { target: trimmed || 'Workflow: intake_to_brief' };
    case 'client_growth':
      return { leadCompany: trimmed || 'Nord Loom Studio', contactName: 'Ada' };
  }
}
