import { useEffect, useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  Bot,
  Download,
  GitBranch as GitBranchIcon,
  GitCommit as GitCommitIcon,
  GitPullRequest,
  Pause,
  Play,
  Plus,
  Square,
  Terminal,
} from 'lucide-react';
import {
  createSandbox,
  execInSandbox,
  fetchSandbox,
  fetchSandboxes,
  git as gitApi,
  pauseSandbox,
  resumeSandbox,
  runAgentInSandbox,
  terminateSandbox,
} from '@/lib/api';
import type {
  Sandbox,
  SandboxAgentKind,
  SandboxAgentRunResult,
  SandboxLog,
  SandboxStatus,
} from '@shared/sandbox-contracts';
import { formatRelative, pad } from '@/lib/format';
import { cn } from '@/lib/utils';
import RepoPicker, { type RepoPickerValue } from '@/components/RepoPicker';

type Tab = 'terminal' | 'agent' | 'git';

const STATUS_TONE: Record<SandboxStatus, string> = {
  provisioning: 'text-amber border-amber',
  running: 'text-teal-deep border-teal-deep',
  paused: 'text-ink/60 border-ink/60',
  terminated: 'text-ink/40 border-ink/40',
  failed: 'text-coral border-coral',
};

/**
 * Extract owner/repo from a sandbox repoUrl string for the LIVE chip label.
 * Accepts the same formats as the server-side parseRepoUrl helper.
 */
function parseSandboxRepo(
  repoUrl?: string,
): { owner: string; repo: string } | null {
  if (!repoUrl) return null;
  const raw = repoUrl.trim();
  if (!raw) return null;
  const strip = (s: string) => s.replace(/\.git$/i, '').replace(/\/$/, '');
  const https = raw.match(
    /^https?:\/\/github\.com\/([^/\s]+)\/([^/\s?#]+)(?:\.git)?\/?/i,
  );
  if (https) return { owner: https[1], repo: strip(https[2]) };
  const ssh = raw.match(/^git@github\.com:([^/\s]+)\/([^/\s]+?)(?:\.git)?$/i);
  if (ssh) return { owner: ssh[1], repo: strip(ssh[2]) };
  const short = raw.match(/^([A-Za-z0-9._-]+)\/([A-Za-z0-9._-]+?)(?:\.git)?$/);
  if (short) return { owner: short[1], repo: strip(short[2]) };
  return null;
}

export default function WorkspacePage() {
  const qc = useQueryClient();
  const sandboxes = useQuery({
    queryKey: ['sandboxes'],
    queryFn: fetchSandboxes,
    refetchInterval: 4000,
  });
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>('terminal');

  // Auto-select first sandbox once loaded.
  useEffect(() => {
    if (!selectedId && sandboxes.data && sandboxes.data.length > 0) {
      setSelectedId(sandboxes.data[0].id);
    }
  }, [selectedId, sandboxes.data]);

  const selected = useQuery({
    queryKey: ['sandbox', selectedId],
    queryFn: () => fetchSandbox(selectedId as string),
    enabled: !!selectedId,
    refetchInterval: 2500,
  });

  return (
    <div className="pb-24">
      <header className="mb-10">
        <p className="marginal">§07 · Workspace</p>
        <h2 className="display-serif mt-3 text-5xl leading-[0.95] md:text-6xl">
          Cloud sandboxes,
          <br />
          <em className="text-teal-deep">assembled quietly.</em>
        </h2>
        <p className="mt-4 max-w-xl font-mono text-xs leading-relaxed text-ink/70">
          Provision ephemeral runtimes, hand the keyboard to claude‑code or codex,
          and review the diff before it lands. Everything is mocked in‑process for
          this MVP — no real infra was harmed.
        </p>
      </header>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[320px_1fr]">
        <SandboxList
          sandboxes={sandboxes.data ?? []}
          selectedId={selectedId}
          onSelect={(id) => {
            setSelectedId(id);
            setTab('terminal');
          }}
          onCreated={(sb) => {
            qc.invalidateQueries({ queryKey: ['sandboxes'] });
            setSelectedId(sb.id);
            setTab('terminal');
          }}
        />
        <div>
          {selected.data ? (
            <SandboxConsole
              sandbox={selected.data}
              tab={tab}
              onTabChange={setTab}
            />
          ) : (
            <EmptyPane />
          )}
        </div>
      </div>
    </div>
  );
}

function EmptyPane() {
  return (
    <div className="surface-card grain flex min-h-[420px] flex-col items-start justify-center gap-4 p-10">
      <p className="marginal">§ waiting</p>
      <h3 className="display-serif text-3xl leading-tight">
        Select a sandbox to open the console.
      </h3>
      <p className="max-w-md font-mono text-xs leading-relaxed text-ink/70">
        Or start a new one from the left column. Provisioning is simulated and
        completes in about two seconds.
      </p>
    </div>
  );
}

function SandboxList({
  sandboxes,
  selectedId,
  onSelect,
  onCreated,
}: {
  sandboxes: Sandbox[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  onCreated: (sb: Sandbox) => void;
}) {
  const [showForm, setShowForm] = useState(false);
  return (
    <aside className="flex flex-col gap-4">
      <div className="flex items-baseline justify-between border-b border-ink/15 pb-3">
        <div className="flex items-baseline gap-3">
          <span className="marginal">§01</span>
          <h3 className="display-serif text-2xl leading-none">Sandboxes</h3>
        </div>
        <button
          className="btn-outline"
          onClick={() => setShowForm((s) => !s)}
          type="button"
        >
          <Plus className="h-3.5 w-3.5" /> new
        </button>
      </div>

      {showForm && (
        <NewSandboxForm
          onDone={(sb) => {
            setShowForm(false);
            onCreated(sb);
          }}
          onCancel={() => setShowForm(false)}
        />
      )}

      <div className="flex flex-col">
        {sandboxes.length === 0 && (
          <p className="border border-dashed border-ink/20 p-6 font-mono text-xs text-ink/60">
            No sandboxes yet.
          </p>
        )}
        {sandboxes.map((sb, i) => {
          const active = sb.id === selectedId;
          return (
            <button
              key={sb.id}
              onClick={() => onSelect(sb.id)}
              className={cn(
                'group flex flex-col gap-2 border border-ink/15 p-4 text-left transition-colors -mt-px first:mt-0',
                active ? 'bg-parchment' : 'bg-bone hover:bg-parchment/60',
              )}
            >
              <div className="flex items-baseline justify-between">
                <span className="marginal">§{pad(i + 1)}</span>
                <StatusChip status={sb.status} />
              </div>
              <p className="font-display text-lg leading-tight">{sb.name}</p>
              <p className="truncate font-mono text-[11px] text-ink/60">
                {sb.repoUrl ?? 'no repo · scratch'}
              </p>
              <div className="flex items-center gap-3 font-mono text-[10px] uppercase tracking-marginal text-ink/50">
                <span>{sb.runtime}</span>
                <span>·</span>
                <span>{sb.vcpus} vcpu</span>
                <span>·</span>
                <span>{formatRelative(sb.createdAt)}</span>
              </div>
            </button>
          );
        })}
      </div>
    </aside>
  );
}

function NewSandboxForm({
  onDone,
  onCancel,
}: {
  onDone: (sb: Sandbox) => void;
  onCancel: () => void;
}) {
  const [name, setName] = useState('scratch sandbox');
  const [repoUrl, setRepoUrl] = useState('');
  const [branch, setBranch] = useState('main');
  const [vcpus, setVcpus] = useState(2);
  const [runtime, setRuntime] = useState<'node22' | 'python'>('node22');
  const [timeoutMinutes, setTimeoutMinutes] = useState(30);
  const [pickedRepo, setPickedRepo] = useState<RepoPickerValue | undefined>(
    undefined,
  );

  const hasPick = !!(pickedRepo && pickedRepo.owner && pickedRepo.name);

  const mutation = useMutation({
    mutationFn: () =>
      createSandbox({
        name,
        repoUrl: hasPick ? undefined : repoUrl || undefined,
        branch: hasPick ? undefined : branch || undefined,
        vcpus,
        runtime,
        timeoutMinutes,
        repo: hasPick ? pickedRepo : undefined,
      }),
    onSuccess: (sb) => onDone(sb),
  });

  return (
    <div className="surface-card grain flex flex-col gap-3 p-4">
      <div className="flex items-baseline justify-between">
        <span className="marginal">§ new sandbox</span>
      </div>
      <Labelled label="Name">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="w-full border border-ink/30 bg-bone px-2 py-1.5 font-mono text-xs text-ink focus:border-ink focus:outline-none"
        />
      </Labelled>
      <RepoPicker value={pickedRepo} onChange={setPickedRepo} />
      {!hasPick && (
        <>
          <Labelled label="Repo URL (optional)">
            <input
              value={repoUrl}
              onChange={(e) => setRepoUrl(e.target.value)}
              placeholder="https://github.com/…"
              className="w-full border border-ink/30 bg-bone px-2 py-1.5 font-mono text-xs text-ink placeholder:text-ink/40 focus:border-ink focus:outline-none"
            />
          </Labelled>
          <Labelled label="Branch">
            <input
              value={branch}
              onChange={(e) => setBranch(e.target.value)}
              className="w-full border border-ink/30 bg-bone px-2 py-1.5 font-mono text-xs text-ink focus:border-ink focus:outline-none"
            />
          </Labelled>
        </>
      )}
      <div className="grid grid-cols-2 gap-3">
        <Labelled label="Runtime">
          <select
            value={runtime}
            onChange={(e) => setRuntime(e.target.value as 'node22' | 'python')}
            className="w-full border border-ink/30 bg-bone px-2 py-1.5 font-mono text-xs text-ink focus:border-ink focus:outline-none"
          >
            <option value="node22">node22</option>
            <option value="python">python</option>
          </select>
        </Labelled>
        <Labelled label="vCPUs (1–8)">
          <input
            type="number"
            min={1}
            max={8}
            value={vcpus}
            onChange={(e) => setVcpus(Number(e.target.value) || 1)}
            className="w-full border border-ink/30 bg-bone px-2 py-1.5 font-mono text-xs text-ink focus:border-ink focus:outline-none"
          />
        </Labelled>
      </div>
      <Labelled label="Timeout (5–300 min)">
        <input
          type="number"
          min={5}
          max={300}
          value={timeoutMinutes}
          onChange={(e) => setTimeoutMinutes(Number(e.target.value) || 5)}
          className="w-full border border-ink/30 bg-bone px-2 py-1.5 font-mono text-xs text-ink focus:border-ink focus:outline-none"
        />
      </Labelled>
      <div className="flex gap-2 pt-1">
        <button
          className="btn-ink"
          onClick={() => mutation.mutate()}
          disabled={mutation.isPending || !name.trim()}
          type="button"
        >
          {mutation.isPending ? 'provisioning…' : 'provision'}
        </button>
        <button className="btn-outline" onClick={onCancel} type="button">
          cancel
        </button>
      </div>
      {mutation.isError && (
        <p className="font-mono text-[11px] text-coral">
          {(mutation.error as Error).message}
        </p>
      )}
    </div>
  );
}

function Labelled({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="flex flex-col gap-1 font-mono text-[10px] uppercase tracking-marginal text-ink/60">
      {label}
      {children}
    </label>
  );
}

function StatusChip({ status }: { status: SandboxStatus }) {
  const tone = STATUS_TONE[status];
  const dotCls =
    status === 'running' || status === 'provisioning'
      ? 'heartbeat bg-current'
      : 'bg-current';
  return (
    <span className={cn('status-pill', tone)}>
      <span
        className={cn('inline-block h-1.5 w-1.5 rounded-full', dotCls)}
      />
      {status}
    </span>
  );
}

function SandboxConsole({
  sandbox,
  tab,
  onTabChange,
}: {
  sandbox: Sandbox;
  tab: Tab;
  onTabChange: (t: Tab) => void;
}) {
  const qc = useQueryClient();

  const pause = useMutation({
    mutationFn: () => pauseSandbox(sandbox.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['sandbox', sandbox.id] });
      qc.invalidateQueries({ queryKey: ['sandboxes'] });
    },
  });
  const resume = useMutation({
    mutationFn: () => resumeSandbox(sandbox.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['sandbox', sandbox.id] });
      qc.invalidateQueries({ queryKey: ['sandboxes'] });
    },
  });
  const terminate = useMutation({
    mutationFn: () => terminateSandbox(sandbox.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['sandbox', sandbox.id] });
      qc.invalidateQueries({ queryKey: ['sandboxes'] });
    },
  });

  return (
    <section className="surface-card grain flex min-h-[520px] flex-col">
      <header className="flex flex-wrap items-start justify-between gap-3 border-b border-ink/15 p-5">
        <div className="min-w-0">
          <p className="marginal">{sandbox.id}</p>
          <h3 className="display-serif mt-1 text-3xl leading-tight">
            {sandbox.name}
          </h3>
          <div className="mt-2 flex flex-wrap items-center gap-3 font-mono text-[11px] text-ink/70">
            <StatusChip status={sandbox.status} />
            <span>{sandbox.runtime}</span>
            <span>·</span>
            <span>
              {sandbox.vcpus} vcpu · {sandbox.memoryMb} MB
            </span>
            <span>·</span>
            <span>{sandbox.timeoutMinutes}m timeout</span>
            {sandbox.domainUrl && (
              <>
                <span>·</span>
                <span className="truncate text-ink/60">
                  {sandbox.domainUrl}
                </span>
              </>
            )}
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <a
            className="btn-outline"
            href={`/api/sandboxes/${sandbox.id}/download`}
            download
          >
            <Download className="h-3.5 w-3.5" /> download
          </a>
          {sandbox.status === 'running' && (
            <button
              className="btn-outline"
              onClick={() => pause.mutate()}
              disabled={pause.isPending}
              type="button"
            >
              <Pause className="h-3.5 w-3.5" /> pause
            </button>
          )}
          {sandbox.status === 'paused' && (
            <button
              className="btn-outline"
              onClick={() => resume.mutate()}
              disabled={resume.isPending}
              type="button"
            >
              <Play className="h-3.5 w-3.5" /> resume
            </button>
          )}
          {sandbox.status !== 'terminated' && (
            <button
              className="btn-coral"
              onClick={() => terminate.mutate()}
              disabled={terminate.isPending}
              type="button"
            >
              <Square className="h-3.5 w-3.5" /> terminate
            </button>
          )}
        </div>
      </header>

      <nav className="flex border-b border-ink/15">
        <TabButton
          active={tab === 'terminal'}
          onClick={() => onTabChange('terminal')}
          icon={<Terminal className="h-3.5 w-3.5" />}
          label="terminal · logs"
        />
        <TabButton
          active={tab === 'agent'}
          onClick={() => onTabChange('agent')}
          icon={<Bot className="h-3.5 w-3.5" />}
          label="agent"
        />
        <TabButton
          active={tab === 'git'}
          onClick={() => onTabChange('git')}
          icon={<GitBranchIcon className="h-3.5 w-3.5" />}
          label="git"
        />
      </nav>

      <div className="flex-1 p-5">
        {tab === 'terminal' && <TerminalTab sandbox={sandbox} />}
        {tab === 'agent' && <AgentTab sandbox={sandbox} />}
        {tab === 'git' && <GitTab sandbox={sandbox} />}
      </div>
    </section>
  );
}

function TabButton({
  active,
  onClick,
  icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      type="button"
      className={cn(
        'flex items-center gap-2 border-r border-ink/15 px-5 py-3 font-mono text-[11px] uppercase tracking-marginal transition-colors',
        active
          ? 'bg-ink text-bone'
          : 'text-ink/60 hover:bg-parchment hover:text-ink',
      )}
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}

function TerminalTab({ sandbox }: { sandbox: Sandbox }) {
  const qc = useQueryClient();
  const [liveLogs, setLiveLogs] = useState<SandboxLog[]>(() => sandbox.logs);
  const [streamState, setStreamState] = useState<'connecting' | 'live' | 'closed'>(
    'connecting',
  );

  // Subscribe to the SSE stream. The server replays recent history on
  // connect, so we reset local state each time the sandbox changes.
  useEffect(() => {
    setLiveLogs([]);
    setStreamState('connecting');
    const url = `/api/sandboxes/${sandbox.id}/logs/stream`;
    const es = new EventSource(url);
    es.addEventListener('log', (ev) => {
      const log = JSON.parse((ev as MessageEvent).data) as SandboxLog;
      setLiveLogs((prev) => {
        // Dedup by id in case of reconnect replay overlap.
        if (prev.some((l) => l.id === log.id)) return prev;
        const next = [...prev, log];
        return next.length > 500 ? next.slice(-500) : next;
      });
    });
    es.addEventListener('status', () => {
      // Refresh the sandbox record so header status pill updates promptly.
      qc.invalidateQueries({ queryKey: ['sandbox', sandbox.id] });
      qc.invalidateQueries({ queryKey: ['sandboxes'] });
    });
    es.onopen = () => setStreamState('live');
    es.onerror = () => setStreamState('closed');
    return () => {
      es.close();
    };
  }, [sandbox.id, qc]);

  const [cmd, setCmd] = useState('ls');
  const execMutation = useMutation({
    mutationFn: () => execInSandbox(sandbox.id, cmd),
    // No need to invalidate — SSE will push the new log lines.
  });

  const canExec =
    sandbox.status === 'running' || sandbox.status === 'provisioning';

  return (
    <div className="flex flex-col gap-4">
      <LogConsole logs={liveLogs} streamState={streamState} />
      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (cmd.trim()) execMutation.mutate();
        }}
        className="flex gap-2"
      >
        <span className="flex select-none items-center px-2 font-mono text-xs text-teal-deep">
          $
        </span>
        <input
          value={cmd}
          onChange={(e) => setCmd(e.target.value)}
          disabled={!canExec}
          placeholder={canExec ? 'ls, pwd, npm test…' : 'sandbox not running'}
          className="flex-1 border border-ink/30 bg-bone px-3 py-2 font-mono text-xs text-ink placeholder:text-ink/40 focus:border-ink focus:outline-none"
        />
        <button
          type="submit"
          className="btn-ink"
          disabled={execMutation.isPending || !canExec || !cmd.trim()}
        >
          {execMutation.isPending ? 'running…' : 'run'}
        </button>
      </form>
      {execMutation.data && (
        <pre className="whitespace-pre-wrap border border-ink/15 bg-parchment/60 p-3 font-mono text-[11px] text-ink/80">
          {execMutation.data.stdout}
        </pre>
      )}
    </div>
  );
}

function LogConsole({
  logs,
  streamState,
}: {
  logs: SandboxLog[];
  streamState: 'connecting' | 'live' | 'closed';
}) {
  const rows = useMemo(() => logs.slice(-200), [logs]);
  const streamLabel =
    streamState === 'live'
      ? 'sse · live'
      : streamState === 'connecting'
        ? 'sse · connecting'
        : 'sse · closed';
  const streamTone =
    streamState === 'live'
      ? 'text-teal-deep'
      : streamState === 'connecting'
        ? 'text-amber'
        : 'text-coral';
  return (
    <div className="border border-ink/40 bg-ink/[0.03]">
      <div className="flex items-center justify-between border-b border-ink/15 bg-parchment px-3 py-1.5">
        <div className="flex items-center gap-3">
          <span className="marginal">console</span>
          <span
            className={cn(
              'flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-marginal',
              streamTone,
            )}
          >
            <span
              className={cn(
                'inline-block h-1.5 w-1.5 rounded-full bg-current',
                streamState === 'live' && 'heartbeat',
              )}
            />
            {streamLabel}
          </span>
        </div>
        <span className="font-mono text-[10px] uppercase tracking-marginal text-ink/50">
          {rows.length} lines
        </span>
      </div>
      <div className="max-h-80 overflow-y-auto bg-parchment/40 p-3 font-mono text-[11px] leading-relaxed">
        {rows.length === 0 && (
          <p className="text-ink/50">waiting for first log line…</p>
        )}
        {rows.map((l) => (
          <div key={l.id} className="flex gap-3">
            <span className="w-16 shrink-0 text-ink/40">
              {new Date(l.timestamp).toLocaleTimeString([], {
                hour12: false,
              })}
            </span>
            <span
              className={cn(
                'w-14 shrink-0 uppercase tracking-marginal',
                l.level === 'error'
                  ? 'text-coral'
                  : l.level === 'warn'
                    ? 'text-amber'
                    : 'text-teal-deep',
              )}
            >
              {l.source}
            </span>
            <span className="min-w-0 whitespace-pre-wrap break-words text-ink/80">
              {l.message}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

function AgentTab({ sandbox }: { sandbox: Sandbox }) {
  const [agent, setAgent] = useState<SandboxAgentKind>('claude_code');
  const [task, setTask] = useState(
    'Refactor the greet helper to accept an optional locale',
  );
  const [result, setResult] = useState<SandboxAgentRunResult | null>(null);

  const mutation = useMutation({
    mutationFn: () => runAgentInSandbox(sandbox.id, agent, task),
    onSuccess: (r) => setResult(r),
  });

  const canRun =
    sandbox.status === 'running' || sandbox.status === 'provisioning';

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-1 gap-3 md:grid-cols-[220px_1fr]">
        <Labelled label="Agent">
          <select
            value={agent}
            onChange={(e) => setAgent(e.target.value as SandboxAgentKind)}
            className="w-full border border-ink/30 bg-bone px-2 py-1.5 font-mono text-xs text-ink focus:border-ink focus:outline-none"
          >
            <option value="claude_code">claude-code</option>
            <option value="codex_cli">codex-cli</option>
          </select>
        </Labelled>
        <Labelled label="Task">
          <textarea
            value={task}
            onChange={(e) => setTask(e.target.value)}
            rows={4}
            className="w-full resize-none border border-ink/30 bg-bone p-3 font-mono text-xs text-ink focus:border-ink focus:outline-none"
          />
        </Labelled>
      </div>
      <div>
        <button
          type="button"
          className="btn-ink"
          disabled={!canRun || !task.trim() || mutation.isPending}
          onClick={() => mutation.mutate()}
        >
          <Bot className="h-3.5 w-3.5" />{' '}
          {mutation.isPending ? 'agent running…' : 'run agent'}
        </button>
      </div>
      {result && (
        <div className="border border-ink/15 bg-bone p-4">
          <p className="marginal">summary · {result.agent}</p>
          <p className="mt-2 font-display text-lg text-ink">{result.summary}</p>
          <p className="mt-2 font-mono text-[10px] uppercase tracking-marginal text-ink/50">
            proposed diff
          </p>
          <pre className="mt-2 max-h-72 overflow-auto whitespace-pre-wrap border border-ink/10 bg-parchment/60 p-3 font-mono text-[11px] text-ink/80">
            {result.diff}
          </pre>
        </div>
      )}
    </div>
  );
}

function GitTab({ sandbox }: { sandbox: Sandbox }) {
  const qc = useQueryClient();
  const branchesQuery = useQuery({
    queryKey: ['git-branches', sandbox.id],
    queryFn: () => gitApi.branches(sandbox.id),
  });
  const diffQuery = useQuery({
    queryKey: ['git-diff', sandbox.id],
    queryFn: () => gitApi.diff(sandbox.id),
  });
  const commitsQuery = useQuery({
    queryKey: ['git-commits', sandbox.id],
    queryFn: () => gitApi.commits(sandbox.id),
  });
  const pullsQuery = useQuery({
    queryKey: ['git-pulls', sandbox.id],
    queryFn: () => gitApi.pulls(sandbox.id),
  });

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ['git-branches', sandbox.id] });
    qc.invalidateQueries({ queryKey: ['git-diff', sandbox.id] });
    qc.invalidateQueries({ queryKey: ['git-commits', sandbox.id] });
    qc.invalidateQueries({ queryKey: ['git-pulls', sandbox.id] });
    qc.invalidateQueries({ queryKey: ['sandbox', sandbox.id] });
  };

  const [newBranch, setNewBranch] = useState('');
  const createBranch = useMutation({
    mutationFn: () => gitApi.createBranch(sandbox.id, newBranch),
    onSuccess: () => {
      setNewBranch('');
      invalidate();
    },
  });
  const checkout = useMutation({
    mutationFn: (name: string) => gitApi.checkout(sandbox.id, name),
    onSuccess: () => invalidate(),
  });

  const [commitMsg, setCommitMsg] = useState('');
  const commit = useMutation({
    mutationFn: () => gitApi.commit(sandbox.id, commitMsg),
    onSuccess: () => {
      setCommitMsg('');
      invalidate();
    },
  });

  const [prTitle, setPrTitle] = useState('');
  const [prDesc, setPrDesc] = useState('');
  const [prTarget, setPrTarget] = useState('main');
  const createPr = useMutation({
    mutationFn: () =>
      gitApi.createPull(sandbox.id, {
        title: prTitle,
        description: prDesc,
        targetBranch: prTarget,
      }),
    onSuccess: () => {
      setPrTitle('');
      setPrDesc('');
      invalidate();
    },
  });

  const branches = branchesQuery.data?.branches ?? [];
  const diff = diffQuery.data?.diff ?? [];
  const commits = commitsQuery.data?.commits ?? [];
  const pulls = pullsQuery.data?.pulls ?? [];

  // Prefer the freshest known mode across queries so mutations that just
  // returned live/simulated flip the chip immediately.
  const mode =
    branchesQuery.data?.mode ??
    diffQuery.data?.mode ??
    commitsQuery.data?.mode ??
    pullsQuery.data?.mode;
  const repoRef = parseSandboxRepo(sandbox.repoUrl);

  return (
    <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
      <div className="col-span-full flex items-center justify-end">
        {mode === 'live' && repoRef && (
          <span className="status-pill font-mono text-teal-deep border-teal-deep">
            LIVE · @{repoRef.owner}/{repoRef.repo}
          </span>
        )}
        {mode === 'simulated' && (
          <span className="status-pill font-mono text-ink/50 border-ink/30">
            SIMULATED
          </span>
        )}
      </div>
      <section className="flex flex-col gap-3">
        <SectionHead icon={<GitBranchIcon className="h-3.5 w-3.5" />} title="branches" />
        <div className="border border-ink/15">
          {branches.map((b) => (
            <div
              key={b.name}
              className="flex items-center justify-between border-b border-ink/10 px-3 py-2 last:border-b-0"
            >
              <div className="flex items-center gap-2 font-mono text-xs">
                <GitBranchIcon
                  className={cn(
                    'h-3.5 w-3.5',
                    b.isCurrent ? 'text-teal-deep' : 'text-ink/40',
                  )}
                />
                <span className={b.isCurrent ? 'text-ink' : 'text-ink/70'}>
                  {b.name}
                </span>
                {b.isCurrent && (
                  <span className="marginal text-teal-deep">current</span>
                )}
              </div>
              <div className="flex items-center gap-2 font-mono text-[10px] text-ink/50">
                <span>+{b.ahead}</span>
                <span>−{b.behind}</span>
                {!b.isCurrent && (
                  <button
                    className="ml-2 border border-ink/30 px-2 py-0.5 uppercase tracking-marginal hover:bg-ink hover:text-bone"
                    onClick={() => checkout.mutate(b.name)}
                    type="button"
                  >
                    checkout
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (newBranch.trim()) createBranch.mutate();
          }}
          className="flex gap-2"
        >
          <input
            value={newBranch}
            onChange={(e) => setNewBranch(e.target.value)}
            placeholder="feature/new-branch"
            className="flex-1 border border-ink/30 bg-bone px-2 py-1.5 font-mono text-xs text-ink placeholder:text-ink/40 focus:border-ink focus:outline-none"
          />
          <button
            type="submit"
            className="btn-outline"
            disabled={createBranch.isPending || !newBranch.trim()}
          >
            <Plus className="h-3.5 w-3.5" /> branch
          </button>
        </form>
      </section>

      <section className="flex flex-col gap-3">
        <SectionHead
          icon={<GitCommitIcon className="h-3.5 w-3.5" />}
          title="changed files"
        />
        <div className="border border-ink/15">
          {diff.length === 0 && (
            <p className="p-4 font-mono text-xs text-ink/60">
              working tree clean.
            </p>
          )}
          {diff.map((f) => (
            <div key={f.path} className="border-b border-ink/10 last:border-b-0">
              <div className="flex items-baseline justify-between px-3 py-2 font-mono text-[11px]">
                <span className="text-ink/80">
                  <span
                    className={cn(
                      'mr-2 inline-block w-14 uppercase tracking-marginal',
                      f.status === 'added'
                        ? 'text-teal-deep'
                        : f.status === 'deleted'
                          ? 'text-coral'
                          : 'text-amber',
                    )}
                  >
                    {f.status}
                  </span>
                  {f.path}
                </span>
                <span className="text-ink/50">
                  +{f.additions} / −{f.deletions}
                </span>
              </div>
              {f.hunks.map((h, i) => (
                <pre
                  key={i}
                  className="whitespace-pre-wrap border-t border-ink/10 bg-parchment/60 p-3 font-mono text-[10px] text-ink/80"
                >
                  {h}
                </pre>
              ))}
            </div>
          ))}
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (commitMsg.trim()) commit.mutate();
          }}
          className="flex gap-2"
        >
          <input
            value={commitMsg}
            onChange={(e) => setCommitMsg(e.target.value)}
            placeholder="commit message"
            className="flex-1 border border-ink/30 bg-bone px-2 py-1.5 font-mono text-xs text-ink placeholder:text-ink/40 focus:border-ink focus:outline-none"
          />
          <button
            type="submit"
            className="btn-ink"
            disabled={commit.isPending || diff.length === 0 || !commitMsg.trim()}
          >
            <GitCommitIcon className="h-3.5 w-3.5" /> commit
          </button>
        </form>
      </section>

      <section className="flex flex-col gap-3">
        <SectionHead
          icon={<GitCommitIcon className="h-3.5 w-3.5" />}
          title="history"
        />
        <div className="max-h-72 overflow-auto border border-ink/15">
          {commits.map((c) => (
            <div
              key={c.sha}
              className="flex items-baseline justify-between border-b border-ink/10 px-3 py-2 font-mono text-[11px] last:border-b-0"
            >
              <div className="min-w-0">
                <p className="truncate text-ink">{c.message}</p>
                <p className="text-ink/50">
                  {c.sha} · {c.author}
                </p>
              </div>
              <span className="text-ink/40">{formatRelative(c.timestamp)}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="flex flex-col gap-3">
        <SectionHead
          icon={<GitPullRequest className="h-3.5 w-3.5" />}
          title="pull requests"
        />
        <div className="border border-ink/15">
          {pulls.length === 0 && (
            <p className="p-4 font-mono text-xs text-ink/60">
              no pull requests yet.
            </p>
          )}
          {pulls.map((p) => (
            <div
              key={p.id}
              className="border-b border-ink/10 px-3 py-2 last:border-b-0"
            >
              <div className="flex items-baseline justify-between font-mono text-[11px]">
                <span className="text-ink">
                  #{p.number} · {p.title}
                </span>
                <span className="uppercase tracking-marginal text-teal-deep">
                  {p.status}
                </span>
              </div>
              <p className="mt-1 font-mono text-[10px] text-ink/50">
                {p.sourceBranch} → {p.targetBranch} · {formatRelative(p.createdAt)}
              </p>
              {p.description && (
                <p className="mt-1 font-mono text-[11px] text-ink/70">
                  {p.description}
                </p>
              )}
            </div>
          ))}
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (prTitle.trim()) createPr.mutate();
          }}
          className="flex flex-col gap-2"
        >
          <input
            value={prTitle}
            onChange={(e) => setPrTitle(e.target.value)}
            placeholder="PR title"
            className="border border-ink/30 bg-bone px-2 py-1.5 font-mono text-xs text-ink placeholder:text-ink/40 focus:border-ink focus:outline-none"
          />
          <textarea
            value={prDesc}
            onChange={(e) => setPrDesc(e.target.value)}
            placeholder="description (optional)"
            rows={2}
            className="resize-none border border-ink/30 bg-bone p-2 font-mono text-xs text-ink placeholder:text-ink/40 focus:border-ink focus:outline-none"
          />
          <div className="flex gap-2">
            <input
              value={prTarget}
              onChange={(e) => setPrTarget(e.target.value)}
              placeholder="target branch"
              className="flex-1 border border-ink/30 bg-bone px-2 py-1.5 font-mono text-xs text-ink focus:border-ink focus:outline-none"
            />
            <button
              type="submit"
              className="btn-outline"
              disabled={createPr.isPending || !prTitle.trim()}
            >
              <GitPullRequest className="h-3.5 w-3.5" /> open PR
            </button>
          </div>
        </form>
      </section>
    </div>
  );
}

function SectionHead({
  icon,
  title,
}: {
  icon: React.ReactNode;
  title: string;
}) {
  return (
    <div className="flex items-baseline justify-between border-b border-ink/15 pb-2">
      <div className="flex items-center gap-2 font-mono text-[11px] uppercase tracking-marginal text-ink/70">
        {icon}
        <span>{title}</span>
      </div>
    </div>
  );
}
