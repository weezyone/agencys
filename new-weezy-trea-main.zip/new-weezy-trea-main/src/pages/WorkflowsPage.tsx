import { Link } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Play } from 'lucide-react';
import {
  fetchLeads,
  fetchProjects,
  fetchWorkflowDefinitions,
  fetchWorkflowRuns,
  launchWorkflow,
} from '@/lib/api';
import { AgentGlyph } from '@/components/AgentGlyph';
import { StatusPill } from '@/components/StatusPill';
import { formatRelative, pad } from '@/lib/format';
import { useState } from 'react';
import type { WorkflowDefinitionId } from '@shared/agent-contracts';

export default function WorkflowsPage() {
  const definitions = useQuery({
    queryKey: ['definitions'],
    queryFn: fetchWorkflowDefinitions,
  });
  const runs = useQuery({
    queryKey: ['runs'],
    queryFn: fetchWorkflowRuns,
    refetchInterval: 3000,
  });
  const projects = useQuery({ queryKey: ['projects'], queryFn: fetchProjects });
  const leads = useQuery({ queryKey: ['leads'], queryFn: fetchLeads });

  return (
    <div className="space-y-14 pb-24">
      <header>
        <p className="marginal">§01 · Console</p>
        <h2 className="display-serif mt-3 text-5xl leading-[0.95] md:text-6xl">
          Workflows,
          <br />
          <em className="text-teal-deep">a slow score.</em>
        </h2>
      </header>

      <section>
        <SectionTitle number="02" title="Preset workflows" />
        <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-3">
          {(definitions.data ?? []).map((def, i) => (
            <WorkflowLaunchCard
              key={def.id}
              index={i}
              definition={def}
              projects={projects.data ?? []}
              leads={leads.data ?? []}
            />
          ))}
        </div>
      </section>

      <section>
        <SectionTitle number="03" title="Runs table" />
        <div className="mt-6 border border-ink/15 bg-bone">
          <div className="grid grid-cols-[80px_1fr_140px_120px_120px_100px] items-center gap-3 border-b border-ink/15 px-4 py-3 font-mono text-[10px] uppercase tracking-marginal text-ink/60">
            <span>id</span>
            <span>label · workflow</span>
            <span>status</span>
            <span>steps</span>
            <span>started</span>
            <span></span>
          </div>
          {(runs.data ?? []).map((r, i) => {
            const done = r.steps.filter((s) => s.status === 'completed').length;
            return (
              <div
                key={r.id}
                className="grid grid-cols-[80px_1fr_140px_120px_120px_100px] items-center gap-3 border-b border-ink/10 px-4 py-4 last:border-b-0 hover:bg-parchment"
              >
                <span className="font-mono text-[11px] text-ink/60">§{pad(i + 1)}</span>
                <div className="min-w-0">
                  <p className="font-display text-lg leading-tight">
                    {r.label ?? r.name}
                  </p>
                  <p className="font-mono text-[11px] text-ink/60">
                    {r.definitionId}
                  </p>
                </div>
                <StatusPill status={r.status} />
                <span className="font-mono text-xs text-ink/70">
                  {done}/{r.steps.length}
                </span>
                <span className="font-mono text-xs text-ink/70">
                  {formatRelative(r.startedAt)}
                </span>
                <Link
                  to={`/workflows/${r.id}`}
                  className="justify-self-end font-mono text-[11px] uppercase tracking-marginal text-ink hover:underline"
                >
                  open →
                </Link>
              </div>
            );
          })}
          {(runs.data ?? []).length === 0 && (
            <p className="p-6 font-mono text-xs text-ink/60">No runs yet.</p>
          )}
        </div>
      </section>
    </div>
  );
}

function WorkflowLaunchCard({
  definition,
  index,
  projects,
  leads,
}: {
  definition: {
    id: WorkflowDefinitionId;
    name: string;
    description: string;
    steps: Array<{ id: string; agentType: string; title: string; requiresApproval: boolean }>;
  };
  index: number;
  projects: Array<{ id: string; name: string }>;
  leads: Array<{ id: string; company: string }>;
}) {
  const qc = useQueryClient();
  const [projectId, setProjectId] = useState<string>('');
  const [leadId, setLeadId] = useState<string>('');
  const mutation = useMutation({
    mutationFn: () =>
      launchWorkflow(definition.id, {
        context: {
          tenantId: 'tenant_default',
          projectId: projectId || undefined,
          leadId: leadId || undefined,
        },
        label:
          projects.find((p) => p.id === projectId)?.name ??
          leads.find((l) => l.id === leadId)?.company ??
          undefined,
      }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['runs'] }),
  });

  return (
    <div className="surface-card grain flex flex-col gap-4 p-6">
      <div className="flex items-baseline justify-between">
        <span className="marginal">§{pad(index + 1)} · {definition.id}</span>
        <span className="font-mono text-[10px] uppercase tracking-marginal text-ink/50">
          {definition.steps.length} steps
        </span>
      </div>
      <h3 className="display-serif text-2xl leading-tight">{definition.name}</h3>
      <p className="font-mono text-xs leading-relaxed text-ink/70">{definition.description}</p>
      <div className="flex items-center gap-2">
        {definition.steps.map((s, i) => (
          <div key={s.id} className="flex items-center gap-2">
            <AgentGlyph
              type={s.agentType as any}
              size={28}
              variant={s.requiresApproval ? 'ink' : 'bone'}
            />
            {i < definition.steps.length - 1 && (
              <span className="h-px w-4 bg-ink/40" />
            )}
          </div>
        ))}
      </div>
      <div className="rule" />
      <label className="flex flex-col gap-1 font-mono text-[10px] uppercase tracking-marginal text-ink/60">
        Project (optional)
        <select
          value={projectId}
          onChange={(e) => setProjectId(e.target.value)}
          className="border border-ink/30 bg-bone px-2 py-1.5 font-mono text-xs text-ink focus:border-ink focus:outline-none"
        >
          <option value="">—</option>
          {projects.map((p) => (
            <option key={p.id} value={p.id}>
              {p.name}
            </option>
          ))}
        </select>
      </label>
      <label className="flex flex-col gap-1 font-mono text-[10px] uppercase tracking-marginal text-ink/60">
        Lead (optional)
        <select
          value={leadId}
          onChange={(e) => setLeadId(e.target.value)}
          className="border border-ink/30 bg-bone px-2 py-1.5 font-mono text-xs text-ink focus:border-ink focus:outline-none"
        >
          <option value="">—</option>
          {leads.map((l) => (
            <option key={l.id} value={l.id}>
              {l.company}
            </option>
          ))}
        </select>
      </label>
      <button
        className="btn-ink self-start"
        onClick={() => mutation.mutate()}
        disabled={mutation.isPending}
      >
        <Play className="h-3.5 w-3.5" /> {mutation.isPending ? 'launching…' : 'launch run'}
      </button>
    </div>
  );
}

function SectionTitle({ number, title }: { number: string; title: string }) {
  return (
    <div className="flex items-baseline justify-between border-b border-ink/15 pb-3">
      <div className="flex items-baseline gap-4">
        <span className="marginal">§{number}</span>
        <h3 className="display-serif text-2xl leading-none">{title}</h3>
      </div>
    </div>
  );
}
