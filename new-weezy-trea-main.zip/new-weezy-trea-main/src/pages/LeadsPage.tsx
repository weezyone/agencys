import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { createLead, fetchLeads } from '@/lib/api';
import { formatRelative, pad } from '@/lib/format';

export default function LeadsPage() {
  const qc = useQueryClient();
  const { data: leads = [] } = useQuery({
    queryKey: ['leads'],
    queryFn: fetchLeads,
  });
  const [company, setCompany] = useState('');
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [industry, setIndustry] = useState('');

  const mutation = useMutation({
    mutationFn: () =>
      createLead({
        company,
        contactName,
        contactEmail,
        context: { industry },
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['leads'] });
      setCompany('');
      setContactName('');
      setContactEmail('');
      setIndustry('');
    },
  });

  return (
    <div className="pb-24">
      <header className="mb-10">
        <p className="marginal">§01 · Register</p>
        <h2 className="display-serif mt-3 text-5xl leading-[0.95]">
          Leads
          <em className="text-teal-deep"> in the mail room.</em>
        </h2>
      </header>
      <div className="grid grid-cols-1 gap-10 lg:grid-cols-[1fr_320px]">
        <section className="border border-ink/15 bg-bone">
          <div className="grid grid-cols-[80px_1fr_1fr_140px] gap-3 border-b border-ink/15 px-4 py-3 font-mono text-[10px] uppercase tracking-marginal text-ink/60">
            <span>id</span>
            <span>company</span>
            <span>contact</span>
            <span>added</span>
          </div>
          {leads.map((l, i) => (
            <div
              key={l.id}
              className="grid grid-cols-[80px_1fr_1fr_140px] gap-3 border-b border-ink/10 px-4 py-4 last:border-b-0 hover:bg-parchment"
            >
              <span className="font-mono text-[11px] text-ink/60">§{pad(i + 1)}</span>
              <div>
                <p className="font-display text-lg leading-tight">{l.company}</p>
                <p className="font-mono text-[11px] text-ink/60">
                  {l.context.industry ?? '—'}
                </p>
              </div>
              <div className="font-mono text-xs text-ink/80">
                <p>{l.contactName ?? '—'}</p>
                <p className="text-ink/60">{l.contactEmail ?? ''}</p>
              </div>
              <span className="font-mono text-xs text-ink/70">
                {formatRelative(l.createdAt)}
              </span>
            </div>
          ))}
          {leads.length === 0 && (
            <p className="p-6 font-mono text-xs text-ink/60">No leads yet.</p>
          )}
        </section>

        <aside className="surface-card p-6">
          <p className="marginal">§ New entry</p>
          <h3 className="display-serif mt-2 text-2xl leading-tight">Add a lead</h3>
          <form
            className="mt-4 space-y-3"
            onSubmit={(e) => {
              e.preventDefault();
              if (!company.trim()) return;
              mutation.mutate();
            }}
          >
            <Field label="Company">
              <input
                value={company}
                onChange={(e) => setCompany(e.target.value)}
                required
                className="w-full border border-ink/30 bg-bone px-3 py-2 font-mono text-xs focus:border-ink focus:outline-none"
              />
            </Field>
            <Field label="Contact name">
              <input
                value={contactName}
                onChange={(e) => setContactName(e.target.value)}
                className="w-full border border-ink/30 bg-bone px-3 py-2 font-mono text-xs focus:border-ink focus:outline-none"
              />
            </Field>
            <Field label="Contact email">
              <input
                value={contactEmail}
                onChange={(e) => setContactEmail(e.target.value)}
                type="email"
                className="w-full border border-ink/30 bg-bone px-3 py-2 font-mono text-xs focus:border-ink focus:outline-none"
              />
            </Field>
            <Field label="Industry">
              <input
                value={industry}
                onChange={(e) => setIndustry(e.target.value)}
                className="w-full border border-ink/30 bg-bone px-3 py-2 font-mono text-xs focus:border-ink focus:outline-none"
              />
            </Field>
            <button
              className="btn-ink w-full justify-center"
              disabled={mutation.isPending}
            >
              {mutation.isPending ? 'saving…' : 'file lead'}
            </button>
          </form>
        </aside>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="marginal">{label}</span>
      <div className="mt-1">{children}</div>
    </label>
  );
}
