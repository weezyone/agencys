import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { fetchArtifacts } from '@/lib/api';
import { AGENT_DIRECTORY, AGENT_TYPES, type AgentType } from '@shared/agent-types';
import { AgentGlyph } from '@/components/AgentGlyph';
import { formatRelative, pad } from '@/lib/format';
import type { Artifact } from '@shared/agent-contracts';

export default function ArtifactsPage() {
  const [agentFilter, setAgentFilter] = useState<AgentType | 'all'>('all');
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<Artifact | null>(null);
  const { data: artifacts = [] } = useQuery({
    queryKey: ['artifacts', agentFilter],
    queryFn: () =>
      fetchArtifacts(agentFilter === 'all' ? undefined : { agentType: agentFilter }),
  });

  const filtered = useMemo(
    () =>
      artifacts.filter((a) =>
        search
          ? a.title.toLowerCase().includes(search.toLowerCase()) ||
            a.content.summary.toLowerCase().includes(search.toLowerCase())
          : true,
      ),
    [artifacts, search],
  );

  return (
    <div className="pb-24">
      <header className="mb-10">
        <p className="marginal">§01 · Library</p>
        <h2 className="display-serif mt-3 text-5xl leading-[0.95] md:text-6xl">
          Every deliverable,
          <br />
          <em className="text-teal-deep">on the record.</em>
        </h2>
      </header>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-[240px_1fr]">
        <aside className="space-y-6">
          <div>
            <p className="marginal mb-2">Search</p>
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="filter titles…"
              className="w-full border border-ink/30 bg-bone px-3 py-2 font-mono text-xs placeholder:text-ink/40 focus:border-ink focus:outline-none"
            />
          </div>
          <div>
            <p className="marginal mb-2">Agent</p>
            <div className="flex flex-col">
              <FilterButton
                label="all"
                active={agentFilter === 'all'}
                onClick={() => setAgentFilter('all')}
              />
              {AGENT_TYPES.map((t) => (
                <FilterButton
                  key={t}
                  label={AGENT_DIRECTORY[t].role}
                  active={agentFilter === t}
                  onClick={() => setAgentFilter(t)}
                  code={AGENT_DIRECTORY[t].code}
                />
              ))}
            </div>
          </div>
        </aside>

        <section className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {filtered.map((a, i) => (
            <button
              key={a.id}
              onClick={() => setSelected(a)}
              className="surface-card group text-left transition-colors hover:border-ink"
            >
              <div className="flex items-start gap-4 p-5">
                <AgentGlyph type={a.agentType} size={36} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-baseline justify-between">
                    <span className="marginal">§{pad(i + 1)}</span>
                    <span className="font-mono text-[10px] uppercase tracking-marginal text-ink/60">
                      {formatRelative(a.createdAt)}
                    </span>
                  </div>
                  <h3 className="mt-1 font-display text-lg leading-tight">
                    {a.title}
                  </h3>
                  <p className="mt-1 line-clamp-2 font-mono text-xs text-ink/70">
                    {a.content.summary}
                  </p>
                </div>
              </div>
            </button>
          ))}
          {filtered.length === 0 && (
            <p className="col-span-full font-mono text-xs text-ink/60">
              Nothing here yet.
            </p>
          )}
        </section>
      </div>

      {selected && (
        <ArtifactModal artifact={selected} onClose={() => setSelected(null)} />
      )}
    </div>
  );
}

function FilterButton({
  label,
  active,
  onClick,
  code,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
  code?: string;
}) {
  return (
    <button
      onClick={onClick}
      className={[
        'flex items-center justify-between border-l-2 px-3 py-2 text-left font-mono text-[11px] uppercase tracking-marginal transition-colors',
        active
          ? 'border-ink text-ink'
          : 'border-transparent text-ink/50 hover:text-ink',
      ].join(' ')}
    >
      <span>{label}</span>
      {code && <span className="text-[10px] text-ink/50">{code}</span>}
    </button>
  );
}

function ArtifactModal({
  artifact,
  onClose,
}: {
  artifact: Artifact;
  onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-6">
      <div className="absolute inset-0 bg-ink/50 backdrop-blur-sm" onClick={onClose} />
      <div className="surface-card grain relative z-10 max-h-[85vh] w-full max-w-3xl overflow-hidden">
        <header className="flex items-start justify-between border-b border-ink/15 p-6">
          <div className="flex items-center gap-4">
            <AgentGlyph type={artifact.agentType} size={44} />
            <div>
              <p className="marginal">{AGENT_DIRECTORY[artifact.agentType].role}</p>
              <h3 className="display-serif text-2xl leading-tight">{artifact.title}</h3>
            </div>
          </div>
          <button className="btn-outline" onClick={onClose}>
            close
          </button>
        </header>
        <div className="max-h-[65vh] overflow-y-auto p-6">
          <p className="font-display text-xl italic text-teal-deep">
            “{artifact.content.summary}”
          </p>
          <pre className="mt-4 whitespace-pre-wrap border border-ink/15 bg-parchment/60 p-4 font-mono text-[11px] leading-relaxed">
            {JSON.stringify(artifact.content.output, null, 2)}
          </pre>
        </div>
      </div>
    </div>
  );
}
