import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { ArrowUpRight } from 'lucide-react';
import {
  fetchArtifacts,
  fetchProjects,
  fetchWorkflowRuns,
} from '@/lib/api';
import { AGENT_DIRECTORY } from '@shared/agent-types';
import { StatusPill } from '@/components/StatusPill';
import { AgentGlyph } from '@/components/AgentGlyph';
import { formatRelative, pad } from '@/lib/format';

export default function DashboardPage() {
  const runsQ = useQuery({ queryKey: ['runs'], queryFn: fetchWorkflowRuns, refetchInterval: 3000 });
  const artifactsQ = useQuery({ queryKey: ['artifacts'], queryFn: () => fetchArtifacts() });
  const projectsQ = useQuery({ queryKey: ['projects'], queryFn: fetchProjects });

  const runs = runsQ.data ?? [];
  const artifacts = artifactsQ.data ?? [];
  const projects = projectsQ.data ?? [];

  const activeRuns = runs.filter((r) => r.status === 'running' || r.status === 'needs_review');
  const pendingApprovals = runs.reduce(
    (n, r) => n + r.steps.filter((s) => s.status === 'needs_review').length,
    0,
  );

  return (
    <div className="space-y-16 pb-24">
      <Header />
      <MetricStrip
        counts={{
          active: activeRuns.length,
          approvals: pendingApprovals,
          artifacts: artifacts.length,
          projects: projects.length,
        }}
      />
      <section>
        <SectionTitle number="03" title="Active runs" caption="the console at work" />
        <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2">
          {activeRuns.length === 0 && (
            <p className="col-span-full font-mono text-xs text-ink/60">
              All runs completed. Launch a new workflow.
            </p>
          )}
          {activeRuns.map((run, i) => {
            const currentStep =
              run.steps.find((s) => s.status === 'in_progress' || s.status === 'needs_review') ??
              run.steps[run.steps.length - 1];
            const done = run.steps.filter((s) => s.status === 'completed').length;
            const pct = Math.round((done / run.steps.length) * 100);
            return (
              <motion.div
                key={run.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.06 }}
                className="surface-ink grain relative p-6"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <p className="marginal text-bone/60">§{pad(i + 1)} · {run.definitionId}</p>
                    <h3 className="display-serif mt-2 text-2xl leading-tight">
                      {run.label ?? run.name}
                    </h3>
                  </div>
                  <StatusPill status={run.status} className="text-bone" />
                </div>
                <div className="mt-6 flex items-center gap-3">
                  <AgentGlyph type={currentStep?.agentType ?? 'project_manager'} size={40} variant="bone" />
                  <div>
                    <p className="font-mono text-[11px] uppercase tracking-marginal text-bone/60">
                      current step
                    </p>
                    <p className="font-display text-lg text-bone">
                      {currentStep?.title ?? '—'}
                    </p>
                  </div>
                </div>
                <div className="mt-5">
                  <div className="flex items-center justify-between font-mono text-[10px] uppercase tracking-marginal text-bone/60">
                    <span>progress</span>
                    <span>
                      {done}/{run.steps.length} · {pct}%
                    </span>
                  </div>
                  <div className="mt-2 h-[3px] w-full bg-bone/15">
                    <div
                      className="h-full bg-amber transition-all"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
                <Link
                  to={`/workflows/${run.id}`}
                  className="mt-6 inline-flex items-center gap-1 font-mono text-[11px] uppercase tracking-marginal text-amber hover:underline"
                >
                  open run <ArrowUpRight className="h-3.5 w-3.5" />
                </Link>
              </motion.div>
            );
          })}
        </div>
      </section>

      <section>
        <SectionTitle number="04" title="Recent artifacts" caption="deliverables in flight" />
        <div className="mt-6 grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
          {artifacts.slice(0, 6).map((a) => (
            <Link
              key={a.id}
              to={`/artifacts?agentType=${a.agentType}`}
              className="surface-card group flex flex-col gap-3 p-5 hover:border-ink"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <AgentGlyph type={a.agentType} size={28} />
                  <span className="font-mono text-[10px] uppercase tracking-marginal text-ink/60">
                    {AGENT_DIRECTORY[a.agentType].code} · {formatRelative(a.createdAt)}
                  </span>
                </div>
                <ArrowUpRight className="h-4 w-4 text-ink/40 group-hover:text-ink" />
              </div>
              <h4 className="font-display text-lg leading-tight">{a.title}</h4>
              <p className="line-clamp-2 font-mono text-xs text-ink/70">
                {a.content.summary}
              </p>
            </Link>
          ))}
          {artifacts.length === 0 && (
            <p className="font-mono text-xs text-ink/60">No artifacts yet.</p>
          )}
        </div>
      </section>
    </div>
  );
}

function Header() {
  return (
    <header className="grid grid-cols-1 gap-6 md:grid-cols-[1fr_auto] md:items-end">
      <div>
        <p className="marginal">§01 · Studio Console — Weekly</p>
        <h2 className="display-serif mt-4 text-6xl leading-[0.9] md:text-7xl">
          A quiet control room
          <br />
          <em className="text-teal-deep">for a loud category.</em>
        </h2>
        <p className="mt-6 max-w-xl font-mono text-xs leading-relaxed text-ink/70">
          Seven specialised agents run research, strategy, design, engineering, QA and outreach in
          orchestrated sequence. Every artifact is reviewed here before it leaves the room.
        </p>
      </div>
      <div className="border-2 border-ink p-4 font-mono text-[11px] uppercase tracking-marginal text-ink">
        <p className="text-ink/60">Doctrine</p>
        <p className="mt-2 text-ink">Boring where it counts.</p>
        <p className="text-ink">Bold where it matters.</p>
      </div>
    </header>
  );
}

function MetricStrip({
  counts,
}: {
  counts: { active: number; approvals: number; artifacts: number; projects: number };
}) {
  const items = [
    { label: 'active runs', value: counts.active, tone: 'text-ink' },
    { label: 'awaiting approval', value: counts.approvals, tone: 'text-coral' },
    { label: 'artifacts logged', value: counts.artifacts, tone: 'text-teal-deep' },
    { label: 'projects on file', value: counts.projects, tone: 'text-ink' },
  ];
  return (
    <section>
      <SectionTitle number="02" title="Signals" caption="live tallies" />
      <div className="mt-6 grid grid-cols-2 border border-ink/15 md:grid-cols-4">
        {items.map((it, i) => (
          <div
            key={it.label}
            className={[
              'relative flex flex-col gap-2 p-6',
              i < items.length - 1 ? 'border-r border-ink/15' : '',
            ].join(' ')}
          >
            <span className="marginal">{pad(i + 1)}</span>
            <span className={['display-serif text-6xl leading-none', it.tone].join(' ')}>
              {String(it.value).padStart(2, '0')}
            </span>
            <span className="font-mono text-[11px] uppercase tracking-marginal text-ink/60">
              {it.label}
            </span>
          </div>
        ))}
      </div>
    </section>
  );
}

function SectionTitle({
  number,
  title,
  caption,
}: {
  number: string;
  title: string;
  caption: string;
}) {
  return (
    <div className="flex items-baseline justify-between border-b border-ink/15 pb-3">
      <div className="flex items-baseline gap-4">
        <span className="marginal">§{number}</span>
        <h3 className="display-serif text-2xl leading-none">{title}</h3>
      </div>
      <span className="font-mono text-[10px] uppercase tracking-marginal text-ink/50">
        {caption}
      </span>
    </div>
  );
}
