import { useId, useMemo } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
  useMutation,
  useQuery,
  useQueryClient,
} from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { ArrowLeft, Check, RefreshCcw, RotateCw } from 'lucide-react';
import {
  approveStep,
  fetchArtifact,
  fetchWorkflowRun,
  rejectStep,
  retryStep,
} from '@/lib/api';
import { AGENT_DIRECTORY } from '@shared/agent-types';
import type { Artifact, WorkflowRunStep } from '@shared/agent-contracts';
import { AgentGlyph } from '@/components/AgentGlyph';
import DiffViewer, { diffStats } from '@/components/DiffViewer';
import { StatusPill } from '@/components/StatusPill';
import { formatRelative, pad } from '@/lib/format';

function extractArtifactText(artifact: Artifact | undefined): string {
  if (!artifact) return '';
  // Artifact has no dedicated `body` / `content` string field, so fall back
  // to a stable JSON rendering of `content.output` (mirrors ArtifactPanel).
  try {
    return JSON.stringify(artifact.content.output, null, 2);
  } catch {
    return JSON.stringify(artifact, null, 2);
  }
}

export default function WorkflowRunPage() {
  const { runId = '' } = useParams();
  const runQ = useQuery({
    queryKey: ['run', runId],
    queryFn: () => fetchWorkflowRun(runId),
    refetchInterval: 3000,
    enabled: !!runId,
  });

  const run = runQ.data;
  const activeStep = useMemo(
    () =>
      run?.steps.find(
        (s) => s.status === 'needs_review' || s.status === 'in_progress',
      ) ?? run?.steps.find((s) => s.artifactId),
    [run],
  );

  return (
    <div className="pb-24">
      <div className="mb-6 flex items-center gap-4">
        <Link
          to="/workflows"
          className="btn-outline"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> back
        </Link>
        {run && <StatusPill status={run.status} />}
        {run?.resumedAt && (
          <span className="inline-flex items-center gap-1.5 border border-ink/30 bg-parchment/60 px-2 py-1 font-mono text-[10px] uppercase tracking-marginal text-ink/70">
            <RefreshCcw className="h-3 w-3" />
            resumed {formatRelative(run.resumedAt)}
          </span>
        )}
      </div>

      {run && (
        <>
          <header className="mb-10 flex flex-col gap-2">
            <p className="marginal">┬º Run ┬╖ {run.id}</p>
            <h2 className="display-serif text-5xl leading-[0.95]">
              {run.label ?? run.name}
              <span className="text-coral">.</span>
            </h2>
            <p className="font-mono text-xs text-ink/70">
              {run.definitionId} ┬╖ started {formatRelative(run.startedAt)}
              {run.completedAt ? ` ┬╖ finished ${formatRelative(run.completedAt)}` : ''}
            </p>
          </header>

          <div className="grid grid-cols-1 gap-10 lg:grid-cols-[320px_1fr]">
            <StepTimeline
              runId={run.id}
              steps={run.steps.map((s) => ({
                ...s,
                agentName: AGENT_DIRECTORY[s.agentType].name,
              }))}
              activeStepId={activeStep?.id}
            />
            <div className="min-w-0">
              {activeStep ? (
                <ArtifactPanel
                  runId={run.id}
                  stepId={activeStep.id}
                  artifactId={activeStep.artifactId}
                  status={activeStep.status}
                  requiresApproval={activeStep.requiresApproval}
                  title={activeStep.title}
                  steps={run.steps}
                />
              ) : (
                <p className="font-mono text-xs text-ink/60">
                  Waiting for the first step to produce an artifactΓÇª
                </p>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function StepTimeline({
  runId,
  steps,
  activeStepId,
}: {
  runId: string;
  steps: Array<{
    id: string;
    title: string;
    agentType: keyof typeof AGENT_DIRECTORY;
    status: string;
    startedAt?: string;
    completedAt?: string;
    requiresApproval: boolean;
    attempts?: number;
    lastError?: string;
    nextRetryAt?: string;
  }>;
  activeStepId?: string;
}) {
  const qc = useQueryClient();
  const retry = useMutation({
    mutationFn: (stepId: string) => retryStep(runId, stepId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['run', runId] });
      qc.invalidateQueries({ queryKey: ['runs'] });
    },
  });
  const MAX_ATTEMPTS = 3;
  return (
    <aside className="relative">
      <p className="marginal mb-4">┬º Timeline</p>
      <ol className="space-y-6">
        {steps.map((s, i) => (
          <motion.li
            key={s.id}
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.05 }}
            className="relative pl-10"
          >
            <span
              className="absolute left-3 top-1 h-full w-px bg-ink/30"
              aria-hidden
            />
            <span
              className={[
                'absolute left-1.5 top-1 inline-block h-3 w-3 border',
                s.status === 'in_progress' || s.status === 'needs_review'
                  ? 'bg-amber border-amber'
                  : s.status === 'completed'
                  ? 'bg-teal-deep border-teal-deep'
                  : s.status === 'failed'
                  ? 'bg-coral border-coral'
                  : 'border-ink/40 bg-bone',
              ].join(' ')}
            />
            <div
              className={[
                'border p-4',
                s.id === activeStepId
                  ? 'border-ink bg-parchment/60'
                  : 'border-transparent',
              ].join(' ')}
            >
              <div className="flex items-baseline justify-between">
                <span className="marginal">┬º{pad(i + 1)}</span>
                <StatusPill status={s.status as any} kind="step" />
              </div>
              <div className="mt-2 flex items-center gap-3">
                <AgentGlyph type={s.agentType} size={30} />
                <div>
                  <p className="font-display text-lg leading-tight">{s.title}</p>
                  <p className="font-mono text-[10px] uppercase tracking-marginal text-ink/60">
                    {AGENT_DIRECTORY[s.agentType].role}
                  </p>
                </div>
              </div>
              {s.requiresApproval && (
                <p className="mt-2 font-mono text-[10px] uppercase tracking-marginal text-coral">
                  approval gate
                </p>
              )}
              {typeof s.attempts === 'number' && s.attempts > 0 && (
                <p className="mt-2 font-mono text-[10px] uppercase tracking-marginal text-ink/60">
                  attempt {s.attempts}/{MAX_ATTEMPTS}
                  {s.nextRetryAt && s.status === 'pending'
                    ? ` ┬╖ retry ${formatRelative(s.nextRetryAt)}`
                    : ''}
                </p>
              )}
              {s.lastError && (
                <p className="mt-2 font-mono text-[10px] leading-relaxed text-coral/90">
                  ! {s.lastError}
                </p>
              )}
              {s.status === 'failed' && (
                <button
                  className="btn-outline mt-3"
                  onClick={() => retry.mutate(s.id)}
                  disabled={retry.isPending}
                >
                  <RotateCw className="h-3 w-3" />
                  {retry.isPending && retry.variables === s.id
                    ? 'retryingΓÇª'
                    : 'retry'}
                </button>
              )}
            </div>
          </motion.li>
        ))}
      </ol>
    </aside>
  );
}

function ArtifactPanel({
  runId,
  stepId,
  artifactId,
  status,
  requiresApproval,
  title,
  steps,
}: {
  runId: string;
  stepId: string;
  artifactId?: string;
  status: string;
  requiresApproval: boolean;
  title: string;
  steps: WorkflowRunStep[];
}) {
  const qc = useQueryClient();
  const detailsId = useId();
  const artifactQ = useQuery({
    queryKey: ['artifact', artifactId],
    queryFn: () => fetchArtifact(artifactId as string),
    enabled: !!artifactId,
  });

  // Find the most recent prior step (walking up to but not including the
  // current step) that produced an artifact with the same title, so we can
  // diff its output against the pending one.
  const previousArtifactId = useMemo(() => {
    const idx = steps.findIndex((s) => s.id === stepId);
    if (idx <= 0) return undefined;
    for (let i = idx - 1; i >= 0; i--) {
      const prev = steps[i];
      if (prev.artifactId && prev.title === title) {
        return prev.artifactId;
      }
    }
    return undefined;
  }, [steps, stepId, title]);

  const prevArtifactQ = useQuery({
    queryKey: ['artifact', previousArtifactId],
    queryFn: () => fetchArtifact(previousArtifactId as string),
    enabled: !!previousArtifactId,
  });

  const approve = useMutation({
    mutationFn: () => approveStep(runId, stepId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['run', runId] });
      qc.invalidateQueries({ queryKey: ['runs'] });
      qc.invalidateQueries({ queryKey: ['artifacts'] });
    },
  });
  const reject = useMutation({
    mutationFn: () => rejectStep(runId, stepId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['run', runId] });
      qc.invalidateQueries({ queryKey: ['runs'] });
    },
  });

  const artifact = artifactQ.data;
  const previousArtifact = prevArtifactQ.data;
  const afterText = extractArtifactText(artifact);
  const beforeText = previousArtifact
    ? extractArtifactText(previousArtifact)
    : undefined;
  const showDiff = !!artifact && (status === 'needs_review' || status === 'completed');
  const stats = showDiff ? diffStats(beforeText, afterText) : { adds: 0, removes: 0 };
  return (
    <section className="surface-card grain relative">
      <header className="flex items-baseline justify-between border-b border-ink/15 p-6">
        <div>
          <p className="marginal">Artifact preview</p>
          <h3 className="display-serif mt-1 text-3xl leading-tight">{title}</h3>
        </div>
        <StatusPill status={status as any} kind="step" />
      </header>
      <div className="grid grid-cols-1 gap-6 p-6 md:grid-cols-[220px_1fr]">
        <aside className="space-y-4 border-r border-ink/10 pr-6 font-mono text-[11px] text-ink/70">
          <div>
            <p className="marginal">step</p>
            <p className="mt-1 text-ink">{stepId}</p>
          </div>
          <div>
            <p className="marginal">artifact id</p>
            <p className="mt-1 break-all text-ink">{artifactId ?? 'ΓÇö'}</p>
          </div>
          <div>
            <p className="marginal">approval</p>
            <p className="mt-1 text-ink">
              {requiresApproval ? 'required' : 'not required'}
            </p>
          </div>
        </aside>
        <div className="min-w-0">
          {!artifact ? (
            <p className="font-mono text-xs text-ink/60">
              No artifact yet. The step is still running.
            </p>
          ) : (
            <>
              <p className="font-display text-lg italic text-teal-deep">
                ΓÇ£{artifact.content.summary}ΓÇ¥
              </p>
              <pre className="mt-4 max-h-[420px] overflow-auto whitespace-pre-wrap border border-ink/15 bg-parchment/60 p-4 font-mono text-[11px] leading-relaxed text-ink">
                {JSON.stringify(artifact.content.output, null, 2)}
              </pre>
              {(artifact.content.questions?.length ?? 0) > 0 && (
                <div className="mt-4">
                  <p className="marginal">Questions raised</p>
                  <ul className="mt-2 space-y-1 font-mono text-xs text-ink/80">
                    {artifact.content.questions!.map((q) => (
                      <li key={q} className="before:mr-2 before:content-['ΓÇö']">
                        {q}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              {(artifact.content.risks?.length ?? 0) > 0 && (
                <div className="mt-3">
                  <p className="marginal text-coral">Risks flagged</p>
                  <ul className="mt-2 space-y-1 font-mono text-xs text-coral/90">
                    {artifact.content.risks!.map((r) => (
                      <li key={r} className="before:mr-2 before:content-['!']">
                        {r}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </>
          )}
        </div>
      </div>
      {showDiff && (
        <div className="border-t border-ink/15 px-6 pb-6 pt-4">
          <details
            className="group"
            open={status === 'needs_review'}
          >
            <summary
              aria-controls={detailsId}
              className="flex cursor-pointer list-none items-center justify-between gap-3 border border-ink/15 bg-parchment/60 px-3 py-2 font-mono text-[10px] uppercase tracking-marginal text-ink/70 hover:border-ink"
            >
              <span className="marginal">
                § review diff · <span className="text-teal-deep">+{stats.adds}</span>
                <span className="text-ink/40"> / </span>
                <span className="text-coral">−{stats.removes}</span>
                {!beforeText && (
                  <span className="ml-2 text-ink/50">(new file)</span>
                )}
              </span>
              <span className="text-ink/50 group-open:hidden">expand</span>
              <span className="hidden text-ink/50 group-open:inline">collapse</span>
            </summary>
            <div id={detailsId} className="mt-3">
              <DiffViewer
                before={beforeText}
                after={afterText}
                filename={title}
                language="json"
              />
            </div>
          </details>
        </div>
      )}
      {status === 'needs_review' && (
        <footer className="flex flex-wrap items-center justify-between gap-3 border-t border-ink/15 bg-parchment/40 p-6">
          <div className="font-mono text-[11px] uppercase tracking-marginal text-ink/70">
            This step is paused for editorial review.
          </div>
          <div className="flex gap-3">
            <button
              className="btn-coral"
              onClick={() => reject.mutate()}
              disabled={reject.isPending}
            >
              <RotateCw className="h-3.5 w-3.5" />{' '}
              {reject.isPending ? 'requeuingΓÇª' : 'request changes'}
            </button>
            <button
              className="btn-ink"
              onClick={() => approve.mutate()}
              disabled={approve.isPending}
            >
              <Check className="h-3.5 w-3.5" />{' '}
              {approve.isPending ? 'approvingΓÇª' : 'approve & continue'}
            </button>
          </div>
        </footer>
      )}
    </section>
  );
}
