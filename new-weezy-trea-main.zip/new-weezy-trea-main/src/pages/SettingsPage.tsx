import { useEffect, useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  fetchSettings,
  updateSettings,
  type SettingsPatch,
  type SettingsView,
} from '@/lib/api';

const UNCHANGED = '__unchanged__';

type ProviderKey =
  | 'anthropicApiKey'
  | 'openaiApiKey'
  | 'googleApiKey'
  | 'nvidiaApiKey';

const PROVIDERS: Array<{
  key: ProviderKey;
  label: string;
  hint: string;
  hasKeyField:
    | 'hasAnthropicKey'
    | 'hasOpenaiKey'
    | 'hasGoogleKey'
    | 'hasNvidiaKey';
}> = [
  {
    key: 'anthropicApiKey',
    label: 'Anthropic',
    hint: 'claude · sk-ant-…',
    hasKeyField: 'hasAnthropicKey',
  },
  {
    key: 'openaiApiKey',
    label: 'OpenAI',
    hint: 'gpt · sk-…',
    hasKeyField: 'hasOpenaiKey',
  },
  {
    key: 'googleApiKey',
    label: 'Google',
    hint: 'gemini · AIza…',
    hasKeyField: 'hasGoogleKey',
  },
  {
    key: 'nvidiaApiKey',
    label: 'NVIDIA NIM',
    hint: 'integrate.api.nvidia.com · nvapi-…',
    hasKeyField: 'hasNvidiaKey',
  },
];

interface ProviderDraft {
  mode: 'unchanged' | 'editing';
  value: string;
}

type Runtime = 'node22' | 'python';

export default function SettingsPage() {
  const qc = useQueryClient();
  const { data: settings, isLoading } = useQuery({
    queryKey: ['settings'],
    queryFn: fetchSettings,
  });

  return (
    <div className="pb-24">
      <header className="mb-10">
        <p className="marginal">§08 · Settings</p>
        <h2 className="display-serif mt-3 text-5xl leading-[0.95] md:text-6xl">
          Platform preferences,
          <br />
          <em className="text-teal-deep">kept out of the way.</em>
        </h2>
        <p className="mt-4 max-w-xl font-mono text-xs leading-relaxed text-ink/70">
          Provider keys are stored on the server and only the last four characters
          are ever shown here. Sandbox defaults seed every new workspace; git
          identity signs off commits produced by agents.
        </p>
      </header>

      {isLoading || !settings ? (
        <p className="border border-dashed border-ink/20 p-6 font-mono text-xs text-ink/60">
          loading settings…
        </p>
      ) : (
        <SettingsForm settings={settings} qc={qc} />
      )}
    </div>
  );
}

function SettingsForm({
  settings,
  qc,
}: {
  settings: SettingsView;
  qc: ReturnType<typeof useQueryClient>;
}) {
  const [drafts, setDrafts] = useState<Record<ProviderKey, ProviderDraft>>({
    anthropicApiKey: { mode: 'unchanged', value: '' },
    openaiApiKey: { mode: 'unchanged', value: '' },
    googleApiKey: { mode: 'unchanged', value: '' },
    nvidiaApiKey: { mode: 'unchanged', value: '' },
  });

  const [nvidiaModel, setNvidiaModel] = useState(
    settings.aiProviders.nvidiaModel ?? '',
  );

  const [vcpus, setVcpus] = useState(settings.sandboxDefaults.vcpus);
  const [timeoutMinutes, setTimeoutMinutes] = useState(
    settings.sandboxDefaults.timeoutMinutes,
  );
  const [runtime, setRuntime] = useState<Runtime>(
    settings.sandboxDefaults.runtime,
  );
  const [authorName, setAuthorName] = useState(
    settings.git.defaultAuthorName ?? '',
  );
  const [authorEmail, setAuthorEmail] = useState(
    settings.git.defaultAuthorEmail ?? '',
  );
  const [targetBranch, setTargetBranch] = useState(
    settings.git.defaultTargetBranch,
  );
  const [savedAt, setSavedAt] = useState<string | null>(null);

  // Fade the "saved" note after ~3s.
  useEffect(() => {
    if (!savedAt) return;
    const t = setTimeout(() => setSavedAt(null), 3000);
    return () => clearTimeout(t);
  }, [savedAt]);

  const patch = useMemo<SettingsPatch>(
    () => ({
      aiProviders: {
        anthropicApiKey:
          drafts.anthropicApiKey.mode === 'editing'
            ? drafts.anthropicApiKey.value
            : UNCHANGED,
        openaiApiKey:
          drafts.openaiApiKey.mode === 'editing'
            ? drafts.openaiApiKey.value
            : UNCHANGED,
        googleApiKey:
          drafts.googleApiKey.mode === 'editing'
            ? drafts.googleApiKey.value
            : UNCHANGED,
        nvidiaApiKey:
          drafts.nvidiaApiKey.mode === 'editing'
            ? drafts.nvidiaApiKey.value
            : UNCHANGED,
        // model id isn't secret, so we always send whatever's in the input.
        nvidiaModel: nvidiaModel.trim(),
      },
      sandboxDefaults: { vcpus, timeoutMinutes, runtime },
      git: {
        defaultAuthorName: authorName,
        defaultAuthorEmail: authorEmail,
        defaultTargetBranch: targetBranch,
      },
    }),
    [
      drafts,
      nvidiaModel,
      vcpus,
      timeoutMinutes,
      runtime,
      authorName,
      authorEmail,
      targetBranch,
    ],
  );

  const mutation = useMutation({
    mutationFn: () => updateSettings(patch),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['settings'] });
      setSavedAt(new Date().toISOString());
      setDrafts({
        anthropicApiKey: { mode: 'unchanged', value: '' },
        openaiApiKey: { mode: 'unchanged', value: '' },
        googleApiKey: { mode: 'unchanged', value: '' },
        nvidiaApiKey: { mode: 'unchanged', value: '' },
      });
    },
  });

  return (
    <div className="flex flex-col gap-8">
      <section className="surface-card grain flex flex-col gap-4 p-6">
        <div className="flex items-baseline justify-between border-b border-ink/15 pb-3">
          <div className="flex items-baseline gap-3">
            <span className="marginal">§01</span>
            <h3 className="display-serif text-2xl leading-none">AI providers</h3>
          </div>
          <span className="font-mono text-[10px] uppercase tracking-marginal text-ink/50">
            keys stay on the server
          </span>
        </div>
        <div className="flex flex-col">
          {PROVIDERS.map((p) => (
            <ProviderRow
              key={p.key}
              label={p.label}
              hint={p.hint}
              hasKey={settings[p.hasKeyField]}
              masked={settings.aiProviders[p.key]}
              draft={drafts[p.key]}
              onEdit={() =>
                setDrafts((d) => ({
                  ...d,
                  [p.key]: { mode: 'editing', value: '' },
                }))
              }
              onCancel={() =>
                setDrafts((d) => ({
                  ...d,
                  [p.key]: { mode: 'unchanged', value: '' },
                }))
              }
              onChange={(v) =>
                setDrafts((d) => ({
                  ...d,
                  [p.key]: { mode: 'editing', value: v },
                }))
              }
            />
          ))}
        </div>
        <div className="mt-1 flex flex-col gap-2 border-t border-ink/10 pt-4">
          <label className="flex flex-col gap-1 font-mono text-[10px] uppercase tracking-marginal text-ink/60">
            NVIDIA NIM model id
            <input
              value={nvidiaModel}
              onChange={(e) => setNvidiaModel(e.target.value)}
              placeholder="meta/llama-3.1-70b-instruct"
              className="w-full max-w-md border border-ink/30 bg-bone px-2 py-1.5 font-mono text-xs text-ink placeholder:text-ink/40 focus:border-ink focus:outline-none"
            />
          </label>
          <p className="font-mono text-[10px] text-ink/40">
            leave blank to default to meta/llama-3.1-70b-instruct. active
            whenever a NVIDIA key is set; NVIDIA is preferred over OpenAI.
          </p>
        </div>
      </section>

      <section className="surface-card grain flex flex-col gap-4 p-6">
        <div className="flex items-baseline justify-between border-b border-ink/15 pb-3">
          <div className="flex items-baseline gap-3">
            <span className="marginal">§02</span>
            <h3 className="display-serif text-2xl leading-none">
              Sandbox defaults
            </h3>
          </div>
          <span className="font-mono text-[10px] uppercase tracking-marginal text-ink/50">
            applied to new sandboxes
          </span>
        </div>
        <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
          <Labelled label="vCPUs (1–8)">
            <input
              type="number"
              min={1}
              max={8}
              value={vcpus}
              onChange={(e) =>
                setVcpus(clamp(Number(e.target.value) || 1, 1, 8))
              }
              className="w-full border border-ink/30 bg-bone px-2 py-1.5 font-mono text-xs text-ink focus:border-ink focus:outline-none"
            />
          </Labelled>
          <Labelled label="Timeout (5–300 min)">
            <input
              type="number"
              min={5}
              max={300}
              value={timeoutMinutes}
              onChange={(e) =>
                setTimeoutMinutes(clamp(Number(e.target.value) || 5, 5, 300))
              }
              className="w-full border border-ink/30 bg-bone px-2 py-1.5 font-mono text-xs text-ink focus:border-ink focus:outline-none"
            />
          </Labelled>
          <Labelled label="Runtime">
            <select
              value={runtime}
              onChange={(e) => setRuntime(e.target.value as Runtime)}
              className="w-full border border-ink/30 bg-bone px-2 py-1.5 font-mono text-xs text-ink focus:border-ink focus:outline-none"
            >
              <option value="node22">node22</option>
              <option value="python">python</option>
            </select>
          </Labelled>
        </div>
      </section>

      <section className="surface-card grain flex flex-col gap-4 p-6">
        <div className="flex items-baseline justify-between border-b border-ink/15 pb-3">
          <div className="flex items-baseline gap-3">
            <span className="marginal">§03</span>
            <h3 className="display-serif text-2xl leading-none">Git identity</h3>
          </div>
          <span className="font-mono text-[10px] uppercase tracking-marginal text-ink/50">
            signs agent commits
          </span>
        </div>
        <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
          <Labelled label="Author name">
            <input
              value={authorName}
              onChange={(e) => setAuthorName(e.target.value)}
              placeholder="weezy studio"
              className="w-full border border-ink/30 bg-bone px-2 py-1.5 font-mono text-xs text-ink placeholder:text-ink/40 focus:border-ink focus:outline-none"
            />
          </Labelled>
          <Labelled label="Author email">
            <input
              value={authorEmail}
              onChange={(e) => setAuthorEmail(e.target.value)}
              placeholder="studio@weezy.dev"
              className="w-full border border-ink/30 bg-bone px-2 py-1.5 font-mono text-xs text-ink placeholder:text-ink/40 focus:border-ink focus:outline-none"
            />
          </Labelled>
          <Labelled label="Default target branch">
            <input
              value={targetBranch}
              onChange={(e) => setTargetBranch(e.target.value)}
              placeholder="main"
              className="w-full border border-ink/30 bg-bone px-2 py-1.5 font-mono text-xs text-ink placeholder:text-ink/40 focus:border-ink focus:outline-none"
            />
          </Labelled>
        </div>
      </section>

      <div className="flex items-center gap-4">
        <button
          type="button"
          className="btn-ink"
          disabled={mutation.isPending || !targetBranch.trim()}
          onClick={() => mutation.mutate()}
        >
          {mutation.isPending ? 'saving…' : 'save settings'}
        </button>
        {savedAt && (
          <span className="font-mono text-[11px] uppercase tracking-marginal text-teal-deep">
            saved · {new Date(savedAt).toLocaleTimeString([], { hour12: false })}
          </span>
        )}
        {mutation.isError && (
          <span className="font-mono text-[11px] text-coral">
            {(mutation.error as Error).message}
          </span>
        )}
      </div>
    </div>
  );
}

function ProviderRow({
  label,
  hint,
  hasKey,
  masked,
  draft,
  onEdit,
  onCancel,
  onChange,
}: {
  label: string;
  hint: string;
  hasKey: boolean;
  masked: string | undefined;
  draft: ProviderDraft;
  onEdit: () => void;
  onCancel: () => void;
  onChange: (v: string) => void;
}) {
  return (
    <div className="flex flex-col gap-2 border-b border-ink/10 py-3 last:border-b-0 md:flex-row md:items-center md:justify-between md:gap-4">
      <div className="flex min-w-0 flex-col">
        <p className="font-mono text-[11px] uppercase tracking-marginal text-ink/70">
          {label}
        </p>
        <p className="font-mono text-[10px] text-ink/40">{hint}</p>
      </div>
      <div className="flex flex-1 items-center gap-3 md:justify-end">
        {draft.mode === 'editing' ? (
          <>
            <input
              value={draft.value}
              onChange={(e) => onChange(e.target.value)}
              placeholder="paste new key · leave blank to clear"
              className="flex-1 border border-ink/30 bg-bone px-2 py-1.5 font-mono text-xs text-ink placeholder:text-ink/40 focus:border-ink focus:outline-none md:max-w-md"
            />
            <button
              type="button"
              className="btn-outline"
              onClick={onCancel}
            >
              cancel
            </button>
          </>
        ) : (
          <>
            <span className="font-mono text-xs text-ink/80">
              {hasKey ? (masked ?? '—') : (
                <span className="text-ink/40">not set</span>
              )}
            </span>
            <button type="button" className="btn-outline" onClick={onEdit}>
              replace
            </button>
          </>
        )}
      </div>
    </div>
  );
}

function Labelled({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="flex flex-col gap-1 font-mono text-[10px] uppercase tracking-marginal text-ink/60">
      {label}
      {children}
    </label>
  );
}

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}
