/** @type {import('tailwindcss').Config} */

export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    container: {
      center: true,
    },
    extend: {
      colors: {
        ink: 'rgb(var(--color-ink) / <alpha-value>)',
        bone: 'rgb(var(--color-bone) / <alpha-value>)',
        parchment: 'rgb(var(--color-parchment) / <alpha-value>)',
        amber: {
          DEFAULT: '#E8B23C',
          soft: '#F0C769',
        },
        teal: {
          DEFAULT: '#2E5E5E',
          deep: '#1F4444',
        },
        coral: '#D6553B',
        mist: '#B8B0A2',
        rule: '#1F1F22',
      },
      fontFamily: {
        display: ['"Fraunces Variable"', 'Fraunces', 'Georgia', 'serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular', 'monospace'],
      },
      letterSpacing: {
        marginal: '0.24em',
      },
      boxShadow: {
        console: '0 1px 0 0 rgba(13,13,15,1), 0 24px 60px -30px rgba(13,13,15,0.35)',
      },
      backgroundImage: {
        'grain':
          "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120'><filter id='n'><feTurbulence baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 0.05 0 0 0 0 0.05 0 0 0 0 0.06 0 0 0 0.5 0'/></filter><rect width='100%' height='100%' filter='url(%23n)' opacity='0.35'/></svg>\")",
      },
    },
  },
  plugins: [],
};
