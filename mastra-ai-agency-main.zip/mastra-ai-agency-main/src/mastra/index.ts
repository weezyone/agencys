import { Mastra } from "@mastra/core";

import { projectManagerAgent } from "./agents/project-manager";
import { deepResearchAgent } from "./agents/deep-research";
import { designAgent } from "./agents/design";
import { frontendAgent } from "./agents/frontend";
import { backendAgent } from "./agents/backend";
import { qaAgent } from "./agents/qa";
import { clientOnboardingAgent } from "./agents/client-onboarding";

export const mastra = new Mastra({
  agents: {
    projectManagerAgent,
    deepResearchAgent,
    designAgent,
    frontendAgent,
    backendAgent,
    qaAgent,
    clientOnboardingAgent,
  },
});
