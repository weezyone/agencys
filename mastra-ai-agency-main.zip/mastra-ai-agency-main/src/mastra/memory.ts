import { Memory } from "@mastra/memory";
import { MongoDBStore } from "@mastra/mongodb";

const mongoUrl = process.env.MONGODB_URI || "mongodb://localhost:27017";
const dbName = process.env.MONGODB_DB_NAME || "ai_agency";

export const storage = new MongoDBStore({
  url: mongoUrl,
  dbName,
});

export const createAgentMemory = () =>
  new Memory({
    storage,
    options: {
      lastMessages: 50,
      threads: {
        generateTitle: true,
      },
    },
  });
