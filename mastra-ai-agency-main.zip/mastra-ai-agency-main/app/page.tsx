"use client";

import { useState } from "react";

const agents = [
  { id: "projectManagerAgent", name: "Project Manager", icon: "📋", color: "bg-blue-500" },
  { id: "deepResearchAgent", name: "Deep Research", icon: "🔍", color: "bg-purple-500" },
  { id: "designAgent", name: "Design Lead", icon: "🎨", color: "bg-pink-500" },
  { id: "frontendAgent", name: "Frontend Dev", icon: "⚛️", color: "bg-cyan-500" },
  { id: "backendAgent", name: "Backend Dev", icon: "🔧", color: "bg-green-500" },
  { id: "qaAgent", name: "QA Engineer", icon: "🧪", color: "bg-yellow-500" },
  { id: "clientOnboardingAgent", name: "Client Onboarding", icon: "🤝", color: "bg-orange-500" },
];

export default function Home() {
  const [selectedAgent, setSelectedAgent] = useState(agents[0]);
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<{ role: string; content: string; agent?: string }[]>([]);
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (!message.trim() || loading) return;

    const userMessage = message;
    setMessage("");
    setMessages((prev) => [...prev, { role: "user", content: userMessage }]);
    setLoading(true);

    try {
      const response = await fetch("/api/agents", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ agentId: selectedAgent.id, message: userMessage }),
      });

      const data = await response.json();
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: data.response || data.error, agent: selectedAgent.name },
      ]);
    } catch {
      setMessages((prev) => [...prev, { role: "assistant", content: "Error connecting to agent", agent: selectedAgent.name }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen bg-zinc-950">
      {/* Sidebar */}
      <aside className="w-72 border-r border-zinc-800 p-4 flex flex-col">
        <h1 className="text-xl font-bold text-white mb-2">🏢 AI Agency</h1>
        <p className="text-zinc-500 text-sm mb-6">Design & Development Team</p>
        
        <div className="space-y-2">
          {agents.map((agent) => (
            <button
              key={agent.id}
              onClick={() => setSelectedAgent(agent)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                selectedAgent.id === agent.id
                  ? "bg-zinc-800 text-white"
                  : "text-zinc-400 hover:bg-zinc-900 hover:text-white"
              }`}
            >
              <span className={`w-8 h-8 rounded-lg ${agent.color} flex items-center justify-center text-lg`}>
                {agent.icon}
              </span>
              <span className="text-sm font-medium">{agent.name}</span>
            </button>
          ))}
        </div>
      </aside>

      {/* Main Chat Area */}
      <main className="flex-1 flex flex-col">
        {/* Header */}
        <header className="border-b border-zinc-800 px-6 py-4 flex items-center gap-3">
          <span className={`w-10 h-10 rounded-lg ${selectedAgent.color} flex items-center justify-center text-xl`}>
            {selectedAgent.icon}
          </span>
          <div>
            <h2 className="text-white font-semibold">{selectedAgent.name}</h2>
            <p className="text-zinc-500 text-sm">AI Agent • Online</p>
          </div>
        </header>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <span className={`w-16 h-16 rounded-2xl ${selectedAgent.color} flex items-center justify-center text-3xl mb-4`}>
                {selectedAgent.icon}
              </span>
              <h3 className="text-white text-lg font-medium mb-2">Chat with {selectedAgent.name}</h3>
              <p className="text-zinc-500 max-w-md">
                Start a conversation to get help with your project. This agent specializes in their area of expertise.
              </p>
            </div>
          )}
          
          {messages.map((msg, i) => (
            <div
              key={i}
              className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-2xl rounded-2xl px-4 py-3 ${
                  msg.role === "user"
                    ? "bg-blue-600 text-white"
                    : "bg-zinc-800 text-zinc-100"
                }`}
              >
                {msg.role === "assistant" && (
                  <p className="text-xs text-zinc-400 mb-1">{msg.agent}</p>
                )}
                <p className="whitespace-pre-wrap">{msg.content}</p>
              </div>
            </div>
          ))}
          
          {loading && (
            <div className="flex justify-start">
              <div className="bg-zinc-800 rounded-2xl px-4 py-3">
                <div className="flex gap-1">
                  <span className="w-2 h-2 bg-zinc-500 rounded-full animate-bounce" />
                  <span className="w-2 h-2 bg-zinc-500 rounded-full animate-bounce [animation-delay:0.1s]" />
                  <span className="w-2 h-2 bg-zinc-500 rounded-full animate-bounce [animation-delay:0.2s]" />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Input */}
        <div className="border-t border-zinc-800 p-4">
          <div className="flex gap-3">
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && sendMessage()}
              placeholder={`Message ${selectedAgent.name}...`}
              className="flex-1 bg-zinc-900 border border-zinc-700 rounded-xl px-4 py-3 text-white placeholder-zinc-500 focus:outline-none focus:border-zinc-500"
            />
            <button
              onClick={sendMessage}
              disabled={loading || !message.trim()}
              className="px-6 py-3 bg-blue-600 hover:bg-blue-500 disabled:bg-zinc-700 disabled:cursor-not-allowed text-white rounded-xl font-medium transition-colors"
            >
              Send
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}
