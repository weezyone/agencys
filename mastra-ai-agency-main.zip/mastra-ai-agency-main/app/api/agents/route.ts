import { NextRequest, NextResponse } from "next/server";
import { mastra } from "@/mastra";

export async function POST(request: NextRequest) {
  try {
    const { agentId, message, threadId, resourceId } = await request.json();

    if (!agentId || !message) {
      return NextResponse.json(
        { error: "Missing agentId or message" },
        { status: 400 }
      );
    }

    const agent = mastra.getAgent(agentId);
    if (!agent) {
      return NextResponse.json({ error: "Agent not found" }, { status: 404 });
    }

    const response = await agent.generate(message, {
      threadId: threadId || `thread-${agentId}-default`,
      resourceId: resourceId || "default-user",
    });

    return NextResponse.json({
      response: response.text,
      agentId,
      threadId: threadId || `thread-${agentId}-default`,
    });
  } catch (error) {
    console.error("Agent error:", error);
    return NextResponse.json(
      { error: "Failed to process request" },
      { status: 500 }
    );
  }
}
