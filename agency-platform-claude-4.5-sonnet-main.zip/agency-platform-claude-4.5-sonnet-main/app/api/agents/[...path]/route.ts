import { mastra } from "@/mastra";
import { NextRequest, NextResponse } from "next/server";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  const { path } = await params;
  const agentName = path[0];
  const action = path[1];

  try {
    // Get the agent by name - using type assertion since we validate below
    const agent = mastra.getAgent(agentName as any);
    
    if (!agent) {
      return NextResponse.json({ error: "Agent not found" }, { status: 404 });
    }

    const body = await request.json();
    
    if (action === "generate") {
      const result = await agent.generate(body.messages || body.prompt);
      return NextResponse.json({ text: result.text });
    }

    return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  } catch (error) {
    console.error("Agent error:", error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({ status: "ok" });
}