"use client";

import { useState } from "react";

export default function Dashboard() {
  const [activeAgent, setActiveAgent] = useState("projectManager");
  const [messages, setMessages] = useState<any[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  const agents = [
    { id: "projectManager", name: "Project Manager", icon: "📋" },
    { id: "deepResearcher", name: "Research Agent", icon: "🔍" },
    { id: "productDesigner", name: "Design Agent", icon: "🎨" },
    { id: "frontendDeveloper", name: "Frontend Dev", icon: "⚛️" },
    { id: "backendDeveloper", name: "Backend Dev", icon: "🔧" },
    { id: "qaSpecialist", name: "QA Specialist", icon: "✅" },
    { id: "salesAgent", name: "Sales Agent", icon: "💼" },
    { id: "outreachAgent", name: "Outreach Agent", icon: "📧" },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage = { role: "user", content: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setLoading(true);

    try {
      const response = await fetch(`/api/agents/${activeAgent}/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [input],
        }),
      });

      const data = await response.json();
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: data.text },
      ]);
    } catch (error) {
      console.error("Error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="w-64 bg-white border-r border-gray-200 p-4">
        <h2 className="text-xl font-bold mb-6">Agency Agents</h2>
        <div className="space-y-2">
          {agents.map((agent) => (
            <button
              key={agent.id}
              onClick={() => {
                setActiveAgent(agent.id);
                setMessages([]);
              }}
              className={`w-full text-left p-3 rounded-lg transition-colors ${
                activeAgent === agent.id
                  ? "bg-blue-100 text-blue-700"
                  : "hover:bg-gray-100"
              }`}
            >
              <span className="mr-2">{agent.icon}</span>
              {agent.name}
            </button>
          ))}
        </div>

        <div className="mt-8 pt-8 border-t border-gray-200">
          <h3 className="font-semibold mb-4">Workflows</h3>
          <button className="w-full text-left p-3 rounded-lg hover:bg-gray-100">
            🔄 Complete Project
          </button>
          <button className="w-full text-left p-3 rounded-lg hover:bg-gray-100 mt-2">
            🎯 Client Acquisition
          </button>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 p-4">
          <h1 className="text-2xl font-bold">
            {agents.find((a) => a.id === activeAgent)?.name}
          </h1>
          <p className="text-gray-600 text-sm">
            AI-powered design & development agency
          </p>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.length === 0 && (
            <div className="text-center text-gray-500 mt-12">
              <p className="text-lg mb-2">
                👋 Start a conversation with the{" "}
                {agents.find((a) => a.id === activeAgent)?.name}
              </p>
              <p className="text-sm">
                Ask questions, request tasks, or start a new project
              </p>
            </div>
          )}

          {messages.map((message, index) => (
            <div
              key={index}
              className={`flex ${
                message.role === "user" ? "justify-end" : "justify-start"
              }`}
            >
              <div
                className={`max-w-2xl px-4 py-3 rounded-lg ${
                  message.role === "user"
                    ? "bg-blue-500 text-white"
                    : "bg-white border border-gray-200"
                }`}
              >
                <p className="whitespace-pre-wrap">{message.content}</p>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex justify-start">
              <div className="bg-white border border-gray-200 px-4 py-3 rounded-lg">
                <div className="flex space-x-2">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  <div
                    className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                    style={{ animationDelay: "0.1s" }}
                  ></div>
                  <div
                    className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                    style={{ animationDelay: "0.2s" }}
                  ></div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Input */}
        <div className="bg-white border-t border-gray-200 p-4">
          <form onSubmit={handleSubmit} className="flex space-x-4">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type your message..."
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              disabled={loading}
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
            >
              Send
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}