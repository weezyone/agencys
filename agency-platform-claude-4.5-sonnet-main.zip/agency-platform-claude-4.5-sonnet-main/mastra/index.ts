import { Mastra } from "@mastra/core/mastra";
import { projectManagerAgent } from "./agents/project-manager";
import { researchAgent } from "./agents/research-agent";
import { designAgent } from "./agents/design-agent";
import { frontendAgent } from "./agents/frontend-agent";
import { backendAgent } from "./agents/backend-agent";
import { qaAgent } from "./agents/qa-agent";
import { salesAgent } from "./agents/sales-agent";
import { outreachAgent } from "./agents/outreach-agent";
import { projectWorkflow } from "./workflows/project-workflow";
import { clientAcquisitionWorkflow } from "./workflows/client-acquisition-workflow";

export const mastra = new Mastra({
  agents: {
    projectManager: projectManagerAgent,
    deepResearcher: researchAgent,
    productDesigner: designAgent,
    frontendDeveloper: frontendAgent,
    backendDeveloper: backendAgent,
    qaSpecialist: qaAgent,
    salesAgent: salesAgent,
    outreachAgent: outreachAgent,
  },
  workflows: {
    projectWorkflow,
    clientAcquisitionWorkflow,
  },
});