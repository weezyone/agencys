import { createWorkflow, createStep } from "@mastra/core/workflows";
import { z } from "zod";

const identifyProspects = createStep({
  id: "identify-prospects",
  description: "Outreach agent identifies potential clients",
  inputSchema: z.object({
    industry: z.string(),
    companySize: z.string(),
  }),
  outputSchema: z.object({
    prospects: z.array(
      z.object({
        company: z.string(),
        contact: z.string(),
        email: z.string(),
      })
    ),
  }),
  execute: async ({ inputData, mastra }) => {
    const agent = mastra?.getAgent("outreachAgent");
    const result = await agent?.generate(`
      Identify potential clients in:
      
      Industry: ${inputData.industry}
      Company Size: ${inputData.companySize}
      
      Provide a list of prospects with company info and contact details.
    `);

    return {
      prospects: [
        // Mock data - in production, integrate with lead databases
        { company: "Example Corp", contact: "John Doe", email: "john@example.com" },
      ],
    };
  },
});

const craftOutreach = createStep({
  id: "craft-outreach",
  description: "Create personalized outreach messages",
  inputSchema: z.object({
    prospects: z.array(
      z.object({
        company: z.string(),
        contact: z.string(),
        email: z.string(),
      })
    ),
  }),
  outputSchema: z.object({
    messages: z.array(
      z.object({
        prospect: z.string(),
        subject: z.string(),
        body: z.string(),
      })
    ),
    company: z.string(),
    leadResponse: z.string(),
  }),
  execute: async ({ inputData, mastra }) => {
    const agent = mastra?.getAgent("outreachAgent");

    const messages = await Promise.all(
      inputData.prospects.map(async (prospect: { company: string; contact: string; email: string }) => {
        const result = await agent?.generate(`
          Write a personalized outreach email for:
          
          Company: ${prospect.company}
          Contact: ${prospect.contact}
          
          Make it compelling, value-focused, and include a clear CTA.
        `);

        return {
          prospect: prospect.email,
          subject: "Transform Your Digital Presence",
          body: result?.text || "",
        };
      })
    );

    return {
      messages,
      company: inputData.prospects[0]?.company || "",
      leadResponse: "Interested in learning more",
    };
  },
});

const qualifyLead = createStep({
  id: "qualify-lead",
  description: "Sales agent qualifies interested leads",
  inputSchema: z.object({
    messages: z.array(
      z.object({
        prospect: z.string(),
        subject: z.string(),
        body: z.string(),
      })
    ),
    company: z.string(),
    leadResponse: z.string(),
  }),
  outputSchema: z.object({
    qualified: z.boolean(),
    nextSteps: z.string(),
    company: z.string(),
    requirements: z.string(),
  }),
  execute: async ({ inputData, mastra }) => {
    const agent = mastra?.getAgent("salesAgent");
    const result = await agent?.generate(`
      Qualify this lead response:
      
      Company: ${inputData.company}
      Response: ${inputData.leadResponse}
      
      Determine if they're qualified and suggest next steps.
    `);

    return {
      qualified: true,
      nextSteps: result?.text || "",
      company: inputData.company,
      requirements: "Website redesign with modern tech stack",
    };
  },
});

const createProposal = createStep({
  id: "create-proposal",
  description: "Generate custom proposal",
  inputSchema: z.object({
    qualified: z.boolean(),
    nextSteps: z.string(),
    company: z.string(),
    requirements: z.string(),
  }),
  outputSchema: z.object({
    proposal: z.string(),
  }),
  execute: async ({ inputData, mastra }) => {
    const agent = mastra?.getAgent("salesAgent");
    const result = await agent?.generate(`
      Create a custom proposal for:
      
      Company: ${inputData.company}
      Requirements: ${inputData.requirements}
      
      Include scope, timeline, pricing, and next steps.
    `);

    return {
      proposal: result?.text || "",
    };
  },
});

export const clientAcquisitionWorkflow = createWorkflow({
  id: "client-acquisition-workflow",
  inputSchema: z.object({
    industry: z.string(),
    companySize: z.string(),
  }),
  outputSchema: z.object({
    proposal: z.string(),
  }),
})
  .then(identifyProspects)
  .then(craftOutreach)
  .then(qualifyLead)
  .then(createProposal)
  .commit();