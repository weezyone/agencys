import { createWorkflow, createStep } from "@mastra/core/workflows";
import { z } from "zod";

const gatherRequirements = createStep({
  id: "gather-requirements",
  description: "Project manager gathers client requirements",
  inputSchema: z.object({
    clientBrief: z.string(),
    projectType: z.string(),
    industry: z.string(),
  }),
  outputSchema: z.object({
    requirements: z.string(),
    scope: z.array(z.string()),
    industry: z.string(),
  }),
  execute: async ({ inputData, mastra }) => {
    const agent = mastra?.getAgent("projectManager");
    const result = await agent?.generate(`
      Analyze this client brief and create detailed project requirements:
      
      ${inputData.clientBrief}
      Project Type: ${inputData.projectType}
      
      Provide:
      1. Detailed requirements
      2. Project scope
      3. Success criteria
      4. Potential challenges
    `);

    return {
      requirements: result?.text || "",
      scope: ["Design", "Frontend", "Backend", "Testing"],
      industry: inputData.industry,
    };
  },
});

const conductResearch = createStep({
  id: "conduct-research",
  description: "Research agent performs market analysis",
  inputSchema: z.object({
    requirements: z.string(),
    scope: z.array(z.string()),
    industry: z.string(),
  }),
  outputSchema: z.object({
    research: z.string(),
    requirements: z.string(),
  }),
  execute: async ({ inputData, mastra }) => {
    const agent = mastra?.getAgent("deepResearcher");
    const result = await agent?.generate(`
      Conduct comprehensive research for:
      
      Requirements: ${inputData.requirements}
      Industry: ${inputData.industry}
    `);

    return {
      research: result?.text || "",
      requirements: inputData.requirements,
    };
  },
});

const createDesign = createStep({
  id: "create-design",
  description: "Design agent creates UI/UX specifications",
  inputSchema: z.object({
    requirements: z.string(),
    research: z.string(),
  }),
  outputSchema: z.object({
    designSpecs: z.string(),
    requirements: z.string(),
  }),
  execute: async ({ inputData, mastra }) => {
    const agent = mastra?.getAgent("productDesigner");
    const result = await agent?.generate(`
      Create comprehensive design specifications based on:
      
      Requirements: ${inputData.requirements}
      Research Insights: ${inputData.research}
    `);

    return {
      designSpecs: result?.text || "",
      requirements: inputData.requirements,
    };
  },
});

const developFrontend = createStep({
  id: "develop-frontend",
  description: "Frontend agent implements the UI",
  inputSchema: z.object({
    designSpecs: z.string(),
    requirements: z.string(),
  }),
  outputSchema: z.object({
    frontendCode: z.string(),
  }),
  execute: async ({ inputData, mastra }) => {
    const agent = mastra?.getAgent("frontendDeveloper");
    const result = await agent?.generate(`
      Implement the frontend based on these design specifications:
      
      ${inputData.designSpecs}
    `);

    return {
      frontendCode: result?.text || "",
    };
  },
});

const developBackend = createStep({
  id: "develop-backend",
  description: "Backend agent implements the API",
  inputSchema: z.object({
    designSpecs: z.string(),
    requirements: z.string(),
  }),
  outputSchema: z.object({
    backendCode: z.string(),
  }),
  execute: async ({ inputData, mastra }) => {
    const agent = mastra?.getAgent("frontendDeveloper");
    const result = await agent?.generate(`
      Implement the backend based on these requirements:
      
      ${inputData.requirements}
    `);

    return {
      backendCode: result?.text || "",
    };
  },
});

const performQA = createStep({
  id: "perform-qa",
  description: "QA agent tests all deliverables",
  inputSchema: z.object({
    "develop-frontend": z.object({ frontendCode: z.string() }),
    "develop-backend": z.object({ backendCode: z.string() }),
  }),
  outputSchema: z.object({
    qaReport: z.string(),
    approved: z.boolean(),
  }),
  execute: async ({ inputData, mastra }) => {
    const agent = mastra?.getAgent("frontendDeveloper");
    const frontendCode = inputData["develop-frontend"].frontendCode;
    const backendCode = inputData["develop-backend"].backendCode;
    const result = await agent?.generate(`
      Perform comprehensive QA testing on:
      
      Frontend: ${frontendCode.substring(0, 500)}...
      Backend: ${backendCode.substring(0, 500)}...
      
      Provide a detailed QA report.
    `);

    return {
      qaReport: result?.text || "",
      approved: true,
    };
  },
});

export const projectWorkflow = createWorkflow({
  id: "complete-project-workflow",
  inputSchema: z.object({
    clientBrief: z.string(),
    projectType: z.string(),
    industry: z.string(),
  }),
  outputSchema: z.object({
    qaReport: z.string(),
    approved: z.boolean(),
  }),
})
  .then(gatherRequirements)
  .then(conductResearch)
  .then(createDesign)
  .parallel([developFrontend, developBackend])
  .then(performQA)
  .commit();