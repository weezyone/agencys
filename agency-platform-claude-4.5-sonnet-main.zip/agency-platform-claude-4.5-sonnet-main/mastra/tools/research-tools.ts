import { createTool } from "@mastra/core/tools";
import { z } from "zod";

export const researchAgentTool = createTool({
  id: "research-agent",
  description:
    "Calls the research agent to perform deep market and competitive analysis",
  inputSchema: z.object({
    researchTopic: z.string().describe("The topic or area to research"),
    industry: z.string().describe("The industry or market segment"),
    depth: z
      .enum(["basic", "comprehensive", "deep-dive"])
      .default("comprehensive"),
  }),
  outputSchema: z.object({
    research: z.string(),
    recommendations: z.array(z.string()),
  }),
  execute: async ({ context, mastra }) => {
    const { researchTopic, industry, depth } = context;
    const agent = mastra!.getAgent("deepResearcher");

    const prompt = `Perform a ${depth} research analysis on the following:
    
Topic: ${researchTopic}
Industry: ${industry}

Provide comprehensive insights covering:
- Market overview and trends
- Competitive landscape
- User needs and pain points
- Technology recommendations
- Best practices
- Actionable recommendations`;

    const result = await agent!.generate(prompt);

    return {
      research: result.text,
      recommendations: [
        "Extract key recommendations from research",
        "Prioritize based on impact",
      ],
    };
  },
});