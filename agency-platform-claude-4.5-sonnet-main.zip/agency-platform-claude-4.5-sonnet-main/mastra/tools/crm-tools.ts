import { createTool } from "@mastra/core/tools";
import { z } from "zod";

export const crmTool = createTool({
  id: "crm-tool",
  description: "Manages CRM operations for tracking leads and clients",
  inputSchema: z.object({
    action: z.enum(["create_lead", "update_lead", "get_lead", "create_note"]),
    leadData: z
      .object({
        name: z.string().optional(),
        email: z.string().optional(),
        company: z.string().optional(),
        status: z
          .enum(["new", "contacted", "qualified", "proposal", "closed"])
          .optional(),
        notes: z.string().optional(),
      })
      .optional(),
  }),
  outputSchema: z.object({
    success: z.boolean(),
    message: z.string(),
    data: z.any().optional(),
  }),
  execute: async ({ context }) => {
    const { action, leadData } = context;

    // In production, integrate with actual CRM (HubSpot, Salesforce, etc.)
    console.log(`CRM Action: ${action}`, leadData);

    return {
      success: true,
      message: `Successfully executed ${action}`,
      data: leadData,
    };
  },
});
