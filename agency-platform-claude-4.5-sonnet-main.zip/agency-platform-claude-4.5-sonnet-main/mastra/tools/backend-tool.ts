import { createTool } from "@mastra/core/tools";
import { z } from "zod";


export const backendAgentTool = createTool({
  id: "backend-agent",
  description: "Calls the backend agent to implement APIs and server logic",
  inputSchema: z.object({
    requirements: z.string().describe("Backend requirements and features"),
    endpoints: z.array(z.string()).describe("API endpoints to create"),
    database: z.string().default("PostgreSQL with Prisma"),
  }),
  outputSchema: z.object({
    code: z.string(),
    apiDocs: z.string(),
  }),
  execute: async ({ context, mastra }) => {
    const { requirements, endpoints, database } = context;
    const agent = mastra!.getAgent("backendDeveloper");

    const prompt = `Implement the following backend features:

Requirements: ${requirements}

Endpoints: ${endpoints.join(", ")}
Database: ${database}

Provide:
1. API route implementations
2. Database schema and migrations
3. Authentication and authorization
4. Input validation
5. Error handling
6. API documentation`;

    const result = await agent!.generate(prompt);

    return {
      code: result.text,
      apiDocs: "API documentation generated",
    };
  },
});