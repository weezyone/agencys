import { createTool } from "@mastra/core/tools";
import { z } from "zod";

export const designAgentTool = createTool({
  id: "design-agent",
  description: "Calls the design agent to create UI/UX designs and specifications",
  inputSchema: z.object({
    projectBrief: z.string().describe("The project requirements and goals"),
    designScope: z
      .array(z.string())
      .describe("Specific design deliverables needed"),
    targetAudience: z.string().describe("Target user demographic"),
  }),
  outputSchema: z.object({
    designSpecs: z.string(),
    deliverables: z.array(z.string()),
  }),
  execute: async ({ context, mastra }) => {
    const { projectBrief, designScope, targetAudience } = context;
    const agent = mastra!.getAgent("productDesigner");

    const prompt = `Create comprehensive design specifications for:

Project Brief: ${projectBrief}

Design Scope: ${designScope.join(", ")}
Target Audience: ${targetAudience}

Provide:
1. Design system specifications (colors, typography, spacing)
2. Component library requirements
3. User flow diagrams
4. Wireframe descriptions
5. Accessibility considerations
6. Responsive design breakpoints`;

    const result = await agent!.generate(prompt);

    return {
      designSpecs: result.text,
      deliverables: designScope,
    };
  },
});