import { createTool } from "@mastra/core/tools";
import { z } from "zod";

export const frontendAgentTool = createTool({
  id: "frontend-agent",
  description: "Calls the frontend agent to implement UI components and pages",
  inputSchema: z.object({
    designSpecs: z.string().describe("Design specifications to implement"),
    features: z.array(z.string()).describe("Features to implement"),
    techStack: z
      .array(z.string())
      .default(["Next.js", "React", "TypeScript", "Tailwind CSS"]),
  }),
  outputSchema: z.object({
    code: z.string(),
    components: z.array(z.string()),
  }),
  execute: async ({ context, mastra }) => {
    const { designSpecs, features, techStack } = context;
    const agent = mastra!.getAgent("frontendDeveloper");

    const prompt = `Implement the following frontend features:

Design Specs: ${designSpecs}

Features: ${features.join(", ")}
Tech Stack: ${techStack.join(", ")}

Provide:
1. Complete component code with TypeScript
2. Tailwind CSS styling
3. Responsive design implementation
4. Accessibility features
5. Performance optimizations
6. Usage documentation`;

    const result = await agent!.generate(prompt);

    return {
      code: result.text,
      components: features,
    };
  },
});

