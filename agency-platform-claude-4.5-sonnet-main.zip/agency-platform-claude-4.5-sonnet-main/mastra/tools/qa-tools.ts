import { createTool } from "@mastra/core/tools";
import { z } from "zod";

export const qaAgentTool = createTool({
  id: "qa-agent",
  description: "Calls the QA agent to review and test deliverables",
  inputSchema: z.object({
    deliverable: z.string().describe("What needs to be tested"),
    testScope: z
      .array(z.string())
      .describe("Areas to test (functionality, performance, security, etc.)"),
    criticalPaths: z
      .array(z.string())
      .describe("Critical user flows to verify"),
  }),
  outputSchema: z.object({
    qaReport: z.string(),
    issues: z.array(
      z.object({
        severity: z.enum(["critical", "high", "medium", "low"]),
        description: z.string(),
        recommendation: z.string(),
      })
    ),
    approved: z.boolean(),
  }),
  execute: async ({ context, mastra }) => {
    const { deliverable, testScope, criticalPaths } = context;
    const agent = mastra!.getAgent("qaSpecialist");

    const prompt = `Perform comprehensive QA testing on:

Deliverable: ${deliverable}

Test Scope: ${testScope.join(", ")}
Critical User Paths: ${criticalPaths.join(", ")}

Provide detailed QA report covering:
1. Code quality review
2. Functional testing results
3. Performance metrics
4. Security audit findings
5. Accessibility compliance
6. Cross-browser compatibility
7. List of issues with severity levels
8. Pass/fail recommendation`;

    const result = await agent!.generate(prompt);

    return {
      qaReport: result.text,
      issues: [],
      approved: true,
    };
  },
});
