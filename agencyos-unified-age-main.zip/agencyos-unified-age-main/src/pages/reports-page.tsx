import { useState } from "react"
import { useKV } from "@github/spark/hooks"
import { DashboardHeader } from "@/components/dashboard-header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { 
  ChartBar, 
  TrendUp, 
  TrendDown,
  Download,
  Calendar,
  Users,
  CurrencyDollar,
  Clock,
  Folders,
  Target
} from "@phosphor-icons/react"

interface ReportMetric {
  label: string
  value: string | number
  change?: number
  changeType: "increase" | "decrease" | "neutral"
  icon: React.ElementType
}

interface ProjectPerformance {
  projectName: string
  client: string
  revenue: number
  profitMargin: number
  daysToComplete: number
  teamUtilization: number
  clientSatisfaction: number
}

export function ReportsPage() {
  const [selectedPeriod, setSelectedPeriod] = useState("last-30-days")
  const [selectedReport, setSelectedReport] = useState("overview")

  // Sample data - in real app this would come from API/KV store
  const overviewMetrics: ReportMetric[] = [
    {
      label: "Total Revenue",
      value: "$284,500",
      change: 12.5,
      changeType: "increase",
      icon: CurrencyDollar
    },
    {
      label: "Active Projects",
      value: 14,
      change: -2,
      changeType: "decrease", 
      icon: Folders
    },
    {
      label: "Team Utilization",
      value: "87%",
      change: 5.2,
      changeType: "increase",
      icon: Users
    },
    {
      label: "Avg Project Duration",
      value: "6.2 weeks",
      change: -0.8,
      changeType: "decrease",
      icon: Clock
    },
    {
      label: "Client Retention",
      value: "94%",
      change: 2.1,
      changeType: "increase",
      icon: Target
    },
    {
      label: "Profit Margin",
      value: "32%",
      change: 1.8,
      changeType: "increase",
      icon: TrendUp
    }
  ]

  const projectPerformanceData: ProjectPerformance[] = [
    {
      projectName: "Website Redesign",
      client: "TechFlow Inc",
      revenue: 45000,
      profitMargin: 35,
      daysToComplete: 42,
      teamUtilization: 85,
      clientSatisfaction: 4.8
    },
    {
      projectName: "Brand Identity",
      client: "GreenLeaf Marketing", 
      revenue: 8500,
      profitMargin: 28,
      daysToComplete: 21,
      teamUtilization: 72,
      clientSatisfaction: 4.9
    },
    {
      projectName: "E-commerce Platform",
      client: "Boutique Fashion Co",
      revenue: 65000,
      profitMargin: 38,
      daysToComplete: 84,
      teamUtilization: 91,
      clientSatisfaction: 4.7
    },
    {
      projectName: "Mobile App",
      client: "StartupCo",
      revenue: 32000,
      profitMargin: 25,
      daysToComplete: 56,
      teamUtilization: 78,
      clientSatisfaction: 4.6
    }
  ]

  const revenueByMonth = [
    { month: "Jul", revenue: 45000, projects: 3 },
    { month: "Aug", revenue: 52000, projects: 4 },
    { month: "Sep", revenue: 38000, projects: 2 },
    { month: "Oct", revenue: 68000, projects: 5 },
    { month: "Nov", revenue: 44000, projects: 3 },
    { month: "Dec", revenue: 81000, projects: 6 }
  ]

  const renderOverviewReport = () => (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {overviewMetrics.map((metric, index) => (
          <Card key={index}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{metric.label}</CardTitle>
              <metric.icon size={16} className="text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{metric.value}</div>
              {metric.change !== undefined && (
                <div className="flex items-center gap-1 mt-1">
                  <Badge 
                    variant="secondary" 
                    className={`gap-1 ${
                      metric.changeType === "increase" 
                        ? "text-green-700 bg-green-50" 
                        : metric.changeType === "decrease"
                        ? "text-red-700 bg-red-50"
                        : "text-gray-700 bg-gray-50"
                    }`}
                  >
                    {metric.changeType === "increase" ? (
                      <TrendUp size={12} />
                    ) : metric.changeType === "decrease" ? (
                      <TrendDown size={12} />
                    ) : null}
                    {Math.abs(metric.change)}%
                  </Badge>
                  <p className="text-xs text-muted-foreground">vs last period</p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Revenue Trend */}
      <Card>
        <CardHeader>
          <CardTitle>Revenue Trend</CardTitle>
          <p className="text-sm text-muted-foreground">Monthly revenue and project completion over the last 6 months</p>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {revenueByMonth.map((data, index) => (
              <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-4">
                  <div className="w-12 text-center">
                    <p className="font-medium">{data.month}</p>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-medium">${data.revenue.toLocaleString()}</p>
                      <Badge variant="outline" className="text-xs">
                        {data.projects} projects
                      </Badge>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div 
                        className="bg-primary h-2 rounded-full transition-all"
                        style={{ width: `${(data.revenue / 81000) * 100}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderProjectPerformanceReport = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Project Performance Analysis</CardTitle>
          <p className="text-sm text-muted-foreground">
            Detailed breakdown of project metrics and performance indicators
          </p>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {projectPerformanceData.map((project, index) => (
              <div key={index} className="p-4 border rounded-lg space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-semibold">{project.projectName}</h4>
                    <p className="text-sm text-muted-foreground">{project.client}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">${project.revenue.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">Revenue</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Profit Margin</p>
                    <div className="flex items-center gap-1">
                      <p className="font-medium">{project.profitMargin}%</p>
                      <Badge 
                        variant="outline" 
                        className={project.profitMargin >= 30 ? "text-green-600" : "text-yellow-600"}
                      >
                        {project.profitMargin >= 30 ? "Good" : "Fair"}
                      </Badge>
                    </div>
                  </div>
                  
                  <div>
                    <p className="text-muted-foreground">Duration</p>
                    <p className="font-medium">{project.daysToComplete} days</p>
                  </div>
                  
                  <div>
                    <p className="text-muted-foreground">Team Utilization</p>
                    <p className="font-medium">{project.teamUtilization}%</p>
                  </div>
                  
                  <div>
                    <p className="text-muted-foreground">Client Rating</p>
                    <div className="flex items-center gap-1">
                      <p className="font-medium">{project.clientSatisfaction}/5.0</p>
                      <Badge variant="outline" className="text-green-600">
                        Excellent
                      </Badge>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderFinancialReport = () => (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Total Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$284,500</div>
            <p className="text-xs text-muted-foreground">Last 30 days</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Operating Expenses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$193,200</div>
            <p className="text-xs text-muted-foreground">68% of revenue</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Net Profit</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">$91,300</div>
            <p className="text-xs text-muted-foreground">32% margin</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Expense Breakdown</CardTitle>
          <p className="text-sm text-muted-foreground">Operating expenses by category</p>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { category: "Salaries", amount: 125000, percentage: 65 },
              { category: "Software & Tools", amount: 18000, percentage: 9 },
              { category: "Marketing", amount: 24000, percentage: 12 },
              { category: "Office & Equipment", amount: 15000, percentage: 8 },
              { category: "Other", amount: 11200, percentage: 6 }
            ].map((expense, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <p className="font-medium">{expense.category}</p>
                    <p className="text-sm">${expense.amount.toLocaleString()}</p>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div 
                      className="bg-primary h-2 rounded-full"
                      style={{ width: `${expense.percentage}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  return (
    <>
      <DashboardHeader title="Reports & Analytics" />
      
      <main className="flex-1 space-y-6 p-6 overflow-auto">
        {/* Report Controls */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Select value={selectedReport} onValueChange={setSelectedReport}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="overview">Overview Report</SelectItem>
                <SelectItem value="project-performance">Project Performance</SelectItem>
                <SelectItem value="financial">Financial Report</SelectItem>
                <SelectItem value="team-productivity">Team Productivity</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="last-7-days">Last 7 days</SelectItem>
                <SelectItem value="last-30-days">Last 30 days</SelectItem>
                <SelectItem value="last-90-days">Last 90 days</SelectItem>
                <SelectItem value="last-year">Last year</SelectItem>
                <SelectItem value="custom">Custom range</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <Button className="gap-2">
            <Download size={16} />
            Export Report
          </Button>
        </div>

        {/* Report Content */}
        {selectedReport === "overview" && renderOverviewReport()}
        {selectedReport === "project-performance" && renderProjectPerformanceReport()}
        {selectedReport === "financial" && renderFinancialReport()}
        {selectedReport === "team-productivity" && (
          <Card>
            <CardContent className="flex items-center justify-center py-12">
              <div className="text-center">
                <ChartBar size={48} className="mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">Team Productivity Report</h3>
                <p className="text-muted-foreground">This report is coming soon with detailed team metrics.</p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Report Insights */}
        <Card>
          <CardHeader>
            <CardTitle>Key Insights</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                <div className="flex items-center gap-2 mb-2">
                  <TrendUp size={16} className="text-green-600" />
                  <h4 className="font-medium text-green-900">Revenue Growth</h4>
                </div>
                <p className="text-sm text-green-800">
                  12.5% increase in revenue compared to last period, driven by 3 major project completions.
                </p>
              </div>
              
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <div className="flex items-center gap-2 mb-2">
                  <Users size={16} className="text-blue-600" />
                  <h4 className="font-medium text-blue-900">Team Performance</h4>
                </div>
                <p className="text-sm text-blue-800">
                  Team utilization improved by 5.2%, indicating better project allocation and resource management.
                </p>
              </div>
              
              <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                <div className="flex items-center gap-2 mb-2">
                  <Clock size={16} className="text-yellow-600" />
                  <h4 className="font-medium text-yellow-900">Efficiency Gains</h4>
                </div>
                <p className="text-sm text-yellow-800">
                  Average project duration decreased by 0.8 weeks, showing improved process efficiency.
                </p>
              </div>
              
              <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                <div className="flex items-center gap-2 mb-2">
                  <Target size={16} className="text-purple-600" />
                  <h4 className="font-medium text-purple-900">Client Satisfaction</h4>
                </div>
                <p className="text-sm text-purple-800">
                  Client retention rate at 94%, with average satisfaction score of 4.7/5.0 across all projects.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </>
  )
}