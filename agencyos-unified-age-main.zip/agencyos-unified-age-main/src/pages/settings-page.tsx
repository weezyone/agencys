import { useState } from "react"
import { useKV } from "@github/spark/hooks"
import { DashboardHeader } from "@/components/dashboard-header"
import { DataSeeder } from "@/components/data-seeder"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { 
  User, 
  Building, 
  Bell, 
  Shield, 
  Palette,
  Globe,
  CreditCard,
  Key,
  Download,
  Upload,
  Database
} from "@phosphor-icons/react"
import { toast } from "sonner"

interface AgencySettings {
  companyName: string
  companyEmail: string
  companyPhone: string
  companyAddress: string
  companyWebsite: string
  companyDescription: string
  timezone: string
  currency: string
  dateFormat: string
  notifications: {
    email: boolean
    desktop: boolean
    projectUpdates: boolean
    clientMessages: boolean
    deadlineReminders: boolean
  }
  privacy: {
    showProfileToClients: boolean
    allowClientComments: boolean
    publicPortfolio: boolean
  }
}

interface UserProfile {
  name: string
  email: string
  role: string
  avatar?: string
  phone?: string
  bio?: string
}

export function SettingsPage() {
  const [userProfile, setUserProfile] = useKV<UserProfile>("user-profile", {
    name: "John Doe",
    email: "john@agency.com",
    role: "Agency Owner",
    phone: "+1 (555) 123-4567",
    bio: "Creative director and founder of our digital agency, passionate about delivering exceptional client experiences."
  })

  const [agencySettings, setAgencySettings] = useKV<AgencySettings>("agency-settings", {
    companyName: "Digital Studio Agency",
    companyEmail: "hello@digitalstudio.com",
    companyPhone: "+1 (555) 987-6543",
    companyAddress: "123 Creative Ave, San Francisco, CA 94105",
    companyWebsite: "https://digitalstudio.com",
    companyDescription: "We are a full-service digital agency specializing in web development, design, and digital marketing solutions.",
    timezone: "America/Los_Angeles",
    currency: "USD",
    dateFormat: "MM/DD/YYYY",
    notifications: {
      email: true,
      desktop: true,
      projectUpdates: true,
      clientMessages: true,
      deadlineReminders: true
    },
    privacy: {
      showProfileToClients: true,
      allowClientComments: true,
      publicPortfolio: false
    }
  })

  const [activeTab, setActiveTab] = useState("profile")

  const handleSaveProfile = () => {
    setUserProfile(currentProfile => currentProfile || {
      name: "John Doe",
      email: "john@agency.com",
      role: "Agency Owner"
    })
    toast.success("Profile updated successfully!")
  }

  const handleSaveAgencySettings = () => {
    setAgencySettings(currentSettings => currentSettings || {
      companyName: "Digital Studio Agency",
      companyEmail: "hello@digitalstudio.com",
      companyPhone: "+1 (555) 987-6543",
      companyAddress: "123 Creative Ave, San Francisco, CA 94105",
      companyWebsite: "https://digitalstudio.com",
      companyDescription: "We are a full-service digital agency specializing in web development, design, and digital marketing solutions.",
      timezone: "America/Los_Angeles",
      currency: "USD",
      dateFormat: "MM/DD/YYYY",
      notifications: {
        email: true,
        desktop: true,
        projectUpdates: true,
        clientMessages: true,
        deadlineReminders: true
      },
      privacy: {
        showProfileToClients: true,
        allowClientComments: true,
        publicPortfolio: false
      }
    })
    toast.success("Agency settings saved!")
  }

  const handleNotificationChange = (key: keyof AgencySettings["notifications"], value: boolean) => {
    setAgencySettings(prev => {
      const currentSettings = prev || {
        companyName: "Digital Studio Agency",
        companyEmail: "hello@digitalstudio.com",
        companyPhone: "+1 (555) 987-6543",
        companyAddress: "123 Creative Ave, San Francisco, CA 94105",
        companyWebsite: "https://digitalstudio.com",
        companyDescription: "We are a full-service digital agency specializing in web development, design, and digital marketing solutions.",
        timezone: "America/Los_Angeles",
        currency: "USD",
        dateFormat: "MM/DD/YYYY",
        notifications: {
          email: true,
          desktop: true,
          projectUpdates: true,
          clientMessages: true,
          deadlineReminders: true
        },
        privacy: {
          showProfileToClients: true,
          allowClientComments: true,
          publicPortfolio: false
        }
      }
      return {
        ...currentSettings,
        notifications: {
          ...currentSettings.notifications,
          [key]: value
        }
      }
    })
  }

  const handlePrivacyChange = (key: keyof AgencySettings["privacy"], value: boolean) => {
    setAgencySettings(prev => {
      const currentSettings = prev || {
        companyName: "Digital Studio Agency",
        companyEmail: "hello@digitalstudio.com",
        companyPhone: "+1 (555) 987-6543",
        companyAddress: "123 Creative Ave, San Francisco, CA 94105",
        companyWebsite: "https://digitalstudio.com",
        companyDescription: "We are a full-service digital agency specializing in web development, design, and digital marketing solutions.",
        timezone: "America/Los_Angeles",
        currency: "USD",
        dateFormat: "MM/DD/YYYY",
        notifications: {
          email: true,
          desktop: true,
          projectUpdates: true,
          clientMessages: true,
          deadlineReminders: true
        },
        privacy: {
          showProfileToClients: true,
          allowClientComments: true,
          publicPortfolio: false
        }
      }
      return {
        ...currentSettings,
        privacy: {
          ...currentSettings.privacy,
          [key]: value
        }
      }
    })
  }

  const tabs = [
    { id: "profile", label: "Profile", icon: User },
    { id: "company", label: "Company", icon: Building },
    { id: "notifications", label: "Notifications", icon: Bell },
    { id: "privacy", label: "Privacy & Security", icon: Shield },
    { id: "billing", label: "Billing", icon: CreditCard },
    { id: "integrations", label: "Integrations", icon: Globe },
    { id: "data", label: "Sample Data", icon: Database }
  ]

  return (
    <>
      <DashboardHeader title="Settings" />
      
      <main className="flex-1 p-6 overflow-auto">
        <div className="max-w-6xl mx-auto">
          <div className="grid gap-6 md:grid-cols-4">
            {/* Settings Navigation */}
            <Card className="md:col-span-1 h-fit">
              <CardContent className="p-4">
                <nav className="space-y-1">
                  {tabs.map((tab) => {
                    const Icon = tab.icon
                    return (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id)}
                        className={`w-full flex items-center gap-3 px-3 py-2 text-sm rounded-lg transition-colors ${
                          activeTab === tab.id
                            ? "bg-primary text-primary-foreground"
                            : "text-muted-foreground hover:text-foreground hover:bg-muted"
                        }`}
                      >
                        <Icon size={16} />
                        {tab.label}
                      </button>
                    )
                  })}
                </nav>
              </CardContent>
            </Card>

            {/* Settings Content */}
            <div className="md:col-span-3 space-y-6">
              {/* Profile Settings */}
              {activeTab === "profile" && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <User size={20} />
                      Personal Profile
                    </CardTitle>
                    <p className="text-sm text-muted-foreground">
                      Manage your personal information and profile settings
                    </p>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex items-center gap-6">
                      <Avatar className="h-20 w-20">
                        <AvatarImage src={userProfile?.avatar} alt={userProfile?.name} />
                        <AvatarFallback className="text-lg">
                          {userProfile?.name?.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <div className="space-y-2">
                        <Button variant="outline" size="sm" className="gap-2">
                          <Upload size={16} />
                          Change Photo
                        </Button>
                        <p className="text-xs text-muted-foreground">
                          JPG, PNG or GIF. Max size 2MB.
                        </p>
                      </div>
                    </div>

                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="grid gap-2">
                        <Label htmlFor="profile-name">Full Name</Label>
                        <Input
                          id="profile-name"
                          value={userProfile?.name || ""}
                          onChange={(e) => setUserProfile(prev => ({ ...prev!, name: e.target.value }))}
                        />
                      </div>
                      
                      <div className="grid gap-2">
                        <Label htmlFor="profile-email">Email</Label>
                        <Input
                          id="profile-email"
                          type="email"
                          value={userProfile?.email || ""}
                          onChange={(e) => setUserProfile(prev => ({ ...prev!, email: e.target.value }))}
                        />
                      </div>
                      
                      <div className="grid gap-2">
                        <Label htmlFor="profile-role">Role</Label>
                        <Input
                          id="profile-role"
                          value={userProfile?.role || ""}
                          onChange={(e) => setUserProfile(prev => ({ ...prev!, role: e.target.value }))}
                        />
                      </div>
                      
                      <div className="grid gap-2">
                        <Label htmlFor="profile-phone">Phone</Label>
                        <Input
                          id="profile-phone"
                          value={userProfile?.phone || ""}
                          onChange={(e) => setUserProfile(prev => ({ ...prev!, phone: e.target.value }))}
                        />
                      </div>
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="profile-bio">Bio</Label>
                      <Textarea
                        id="profile-bio"
                        value={userProfile?.bio || ""}
                        onChange={(e) => setUserProfile(prev => ({ ...prev!, bio: e.target.value }))}
                        rows={4}
                        placeholder="Tell us about yourself..."
                      />
                    </div>

                    <Button onClick={handleSaveProfile}>Save Profile</Button>
                  </CardContent>
                </Card>
              )}

              {/* Company Settings */}
              {activeTab === "company" && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Building size={20} />
                      Company Information
                    </CardTitle>
                    <p className="text-sm text-muted-foreground">
                      Update your agency's business information and preferences
                    </p>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="grid gap-2">
                        <Label htmlFor="company-name">Company Name</Label>
                        <Input
                          id="company-name"
                          value={agencySettings?.companyName || ""}
                          onChange={(e) => setAgencySettings(prev => ({ ...prev!, companyName: e.target.value }))}
                        />
                      </div>
                      
                      <div className="grid gap-2">
                        <Label htmlFor="company-email">Company Email</Label>
                        <Input
                          id="company-email"
                          type="email"
                          value={agencySettings?.companyEmail || ""}
                          onChange={(e) => setAgencySettings(prev => ({ ...prev!, companyEmail: e.target.value }))}
                        />
                      </div>
                      
                      <div className="grid gap-2">
                        <Label htmlFor="company-phone">Phone</Label>
                        <Input
                          id="company-phone"
                          value={agencySettings?.companyPhone || ""}
                          onChange={(e) => setAgencySettings(prev => ({ ...prev!, companyPhone: e.target.value }))}
                        />
                      </div>
                      
                      <div className="grid gap-2">
                        <Label htmlFor="company-website">Website</Label>
                        <Input
                          id="company-website"
                          value={agencySettings?.companyWebsite || ""}
                          onChange={(e) => setAgencySettings(prev => ({ ...prev!, companyWebsite: e.target.value }))}
                        />
                      </div>
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="company-address">Address</Label>
                      <Input
                        id="company-address"
                        value={agencySettings?.companyAddress || ""}
                        onChange={(e) => setAgencySettings(prev => ({ ...prev!, companyAddress: e.target.value }))}
                      />
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="company-description">Company Description</Label>
                      <Textarea
                        id="company-description"
                        value={agencySettings?.companyDescription || ""}
                        onChange={(e) => setAgencySettings(prev => ({ ...prev!, companyDescription: e.target.value }))}
                        rows={4}
                      />
                    </div>

                    <Separator />

                    <div className="grid gap-4 md:grid-cols-3">
                      <div className="grid gap-2">
                        <Label htmlFor="timezone">Timezone</Label>
                        <Select 
                          value={agencySettings?.timezone || ""}
                          onValueChange={(value) => setAgencySettings(prev => ({ ...prev!, timezone: value }))}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="America/Los_Angeles">Pacific Time</SelectItem>
                            <SelectItem value="America/Denver">Mountain Time</SelectItem>
                            <SelectItem value="America/Chicago">Central Time</SelectItem>
                            <SelectItem value="America/New_York">Eastern Time</SelectItem>
                            <SelectItem value="Europe/London">GMT</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="grid gap-2">
                        <Label htmlFor="currency">Currency</Label>
                        <Select 
                          value={agencySettings?.currency || ""}
                          onValueChange={(value) => setAgencySettings(prev => ({ ...prev!, currency: value }))}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="USD">USD ($)</SelectItem>
                            <SelectItem value="EUR">EUR (€)</SelectItem>
                            <SelectItem value="GBP">GBP (£)</SelectItem>
                            <SelectItem value="CAD">CAD (C$)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="grid gap-2">
                        <Label htmlFor="date-format">Date Format</Label>
                        <Select 
                          value={agencySettings?.dateFormat || ""}
                          onValueChange={(value) => setAgencySettings(prev => ({ ...prev!, dateFormat: value }))}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                            <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                            <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <Button onClick={handleSaveAgencySettings}>Save Settings</Button>
                  </CardContent>
                </Card>
              )}

              {/* Notification Settings */}
              {activeTab === "notifications" && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Bell size={20} />
                      Notification Preferences
                    </CardTitle>
                    <p className="text-sm text-muted-foreground">
                      Manage how you receive notifications and alerts
                    </p>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Email Notifications</p>
                          <p className="text-sm text-muted-foreground">Receive notifications via email</p>
                        </div>
                        <Switch
                          checked={agencySettings?.notifications.email || false}
                          onCheckedChange={(checked) => handleNotificationChange("email", checked)}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Desktop Notifications</p>
                          <p className="text-sm text-muted-foreground">Show browser notifications</p>
                        </div>
                        <Switch
                          checked={agencySettings?.notifications.desktop || false}
                          onCheckedChange={(checked) => handleNotificationChange("desktop", checked)}
                        />
                      </div>

                      <Separator />

                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Project Updates</p>
                          <p className="text-sm text-muted-foreground">Notifications for project progress and milestones</p>
                        </div>
                        <Switch
                          checked={agencySettings?.notifications.projectUpdates || false}
                          onCheckedChange={(checked) => handleNotificationChange("projectUpdates", checked)}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Client Messages</p>
                          <p className="text-sm text-muted-foreground">Alerts for new client communications</p>
                        </div>
                        <Switch
                          checked={agencySettings?.notifications.clientMessages || false}
                          onCheckedChange={(checked) => handleNotificationChange("clientMessages", checked)}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Deadline Reminders</p>
                          <p className="text-sm text-muted-foreground">Reminders for upcoming project deadlines</p>
                        </div>
                        <Switch
                          checked={agencySettings?.notifications.deadlineReminders || false}
                          onCheckedChange={(checked) => handleNotificationChange("deadlineReminders", checked)}
                        />
                      </div>
                    </div>

                    <Button onClick={handleSaveAgencySettings}>Save Preferences</Button>
                  </CardContent>
                </Card>
              )}

              {/* Privacy & Security */}
              {activeTab === "privacy" && (
                <div className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Shield size={20} />
                        Privacy Settings
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Show Profile to Clients</p>
                          <p className="text-sm text-muted-foreground">Allow clients to view your profile information</p>
                        </div>
                        <Switch
                          checked={agencySettings?.privacy.showProfileToClients || false}
                          onCheckedChange={(checked) => handlePrivacyChange("showProfileToClients", checked)}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Allow Client Comments</p>
                          <p className="text-sm text-muted-foreground">Let clients leave comments on projects</p>
                        </div>
                        <Switch
                          checked={agencySettings?.privacy.allowClientComments || false}
                          onCheckedChange={(checked) => handlePrivacyChange("allowClientComments", checked)}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Public Portfolio</p>
                          <p className="text-sm text-muted-foreground">Make your portfolio publicly visible</p>
                        </div>
                        <Switch
                          checked={agencySettings?.privacy.publicPortfolio || false}
                          onCheckedChange={(checked) => handlePrivacyChange("publicPortfolio", checked)}
                        />
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Key size={20} />
                        Security
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Change Password</p>
                          <p className="text-sm text-muted-foreground">Update your account password</p>
                        </div>
                        <Button variant="outline">Update Password</Button>
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Two-Factor Authentication</p>
                          <p className="text-sm text-muted-foreground">Add an extra layer of security</p>
                        </div>
                        <Button variant="outline">Setup 2FA</Button>
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">API Keys</p>
                          <p className="text-sm text-muted-foreground">Manage your API access keys</p>
                        </div>
                        <Button variant="outline">Manage Keys</Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* Billing */}
              {activeTab === "billing" && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <CreditCard size={20} />
                      Billing & Subscription
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <p className="font-semibold">Professional Plan</p>
                          <p className="text-sm text-muted-foreground">Unlimited projects and team members</p>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-bold">$49</p>
                          <p className="text-sm text-muted-foreground">per month</p>
                        </div>
                      </div>
                      <Button variant="outline" className="w-full">Change Plan</Button>
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <p className="font-medium">Payment Method</p>
                        <Button variant="outline" size="sm">Update</Button>
                      </div>
                      <div className="p-3 border rounded-lg bg-muted/30">
                        <p className="font-medium">•••• •••• •••• 4242</p>
                        <p className="text-sm text-muted-foreground">Expires 12/26</p>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <p className="font-medium">Billing History</p>
                        <Button variant="outline" size="sm" className="gap-2">
                          <Download size={16} />
                          Download
                        </Button>
                      </div>
                      <div className="space-y-2">
                        {[
                          { date: "Jan 1, 2024", amount: "$49.00", status: "Paid" },
                          { date: "Dec 1, 2023", amount: "$49.00", status: "Paid" },
                          { date: "Nov 1, 2023", amount: "$49.00", status: "Paid" }
                        ].map((invoice, index) => (
                          <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                            <div>
                              <p className="font-medium">{invoice.date}</p>
                              <p className="text-sm text-muted-foreground">Professional Plan</p>
                            </div>
                            <div className="text-right">
                              <p className="font-medium">{invoice.amount}</p>
                              <p className="text-sm text-green-600">{invoice.status}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Integrations */}
              {activeTab === "integrations" && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Globe size={20} />
                      Integrations
                    </CardTitle>
                    <p className="text-sm text-muted-foreground">
                      Connect with your favorite tools and services
                    </p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      { name: "Slack", description: "Team communication", connected: true },
                      { name: "Google Drive", description: "File storage and sharing", connected: true },
                      { name: "Figma", description: "Design collaboration", connected: false },
                      { name: "GitHub", description: "Code repository", connected: false },
                      { name: "Zapier", description: "Workflow automation", connected: false }
                    ].map((integration, index) => (
                      <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <p className="font-medium">{integration.name}</p>
                          <p className="text-sm text-muted-foreground">{integration.description}</p>
                        </div>
                        <Button 
                          variant={integration.connected ? "outline" : "default"}
                          size="sm"
                        >
                          {integration.connected ? "Connected" : "Connect"}
                        </Button>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              )}

              {/* Sample Data */}
              {activeTab === "data" && (
                <DataSeeder />
              )}
            </div>
          </div>
        </div>
      </main>
    </>
  )
}