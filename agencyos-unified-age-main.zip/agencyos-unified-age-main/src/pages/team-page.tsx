import { useState } from "react"
import { useKV } from "@github/spark/hooks"
import { DashboardHeader } from "@/components/dashboard-header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Users, Envelope, Phone, Plus, Calendar } from "@phosphor-icons/react"

export interface TeamMember {
  id: string
  name: string
  email: string
  role: string
  department: string
  avatar?: string
  phone?: string
  startDate: string
  status: "active" | "inactive" | "on-leave"
  skills: string[]
  hourlyRate?: number
}

export function TeamPage() {
  const [teamMembers, setTeamMembers] = useKV<TeamMember[]>("agency-team-members", [
    {
      id: "1",
      name: "Sarah Johnson",
      email: "sarah@agency.com",
      role: "Creative Director",
      department: "Design",
      avatar: "",
      phone: "+1 (555) 123-4567",
      startDate: "2022-01-15",
      status: "active",
      skills: ["UI/UX Design", "Brand Strategy", "Adobe Creative Suite"],
      hourlyRate: 125
    },
    {
      id: "2", 
      name: "Mike Chen",
      email: "mike@agency.com",
      role: "Senior Developer",
      department: "Development",
      startDate: "2021-08-20",
      status: "active",
      skills: ["React", "Node.js", "TypeScript", "AWS"],
      hourlyRate: 110
    },
    {
      id: "3",
      name: "Emma Davis",
      email: "emma@agency.com", 
      role: "Project Manager",
      department: "Operations",
      startDate: "2023-03-10",
      status: "active",
      skills: ["Agile", "Stakeholder Management", "Budget Planning"],
      hourlyRate: 95
    }
  ])

  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [newMember, setNewMember] = useState({
    name: "",
    email: "",
    role: "",
    department: "",
    phone: "",
    startDate: "",
    hourlyRate: "",
    skills: ""
  })

  const handleCreateMember = () => {
    const member: TeamMember = {
      id: Date.now().toString(),
      name: newMember.name,
      email: newMember.email,
      role: newMember.role,
      department: newMember.department,
      phone: newMember.phone,
      startDate: newMember.startDate,
      status: "active",
      skills: newMember.skills.split(",").map(skill => skill.trim()).filter(Boolean),
      hourlyRate: parseFloat(newMember.hourlyRate) || undefined
    }

    setTeamMembers(current => [...(current || []), member])
    setIsCreateDialogOpen(false)
    setNewMember({
      name: "",
      email: "",
      role: "",
      department: "",
      phone: "",
      startDate: "",
      hourlyRate: "",
      skills: ""
    })
  }

  const activeMembers = teamMembers?.filter(member => member.status === "active") || []
  const totalBillableRate = activeMembers.reduce((sum, member) => sum + (member.hourlyRate || 0), 0)

  return (
    <>
      <DashboardHeader
        title="Team Members"
        onCreateProject={() => setIsCreateDialogOpen(true)}
        customActionText="Add Member"
        customActionIcon={<Plus size={16} />}
      />
      
      <main className="flex-1 space-y-6 p-6 overflow-auto">
        {/* Team Overview Stats */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Members</CardTitle>
              <Users size={16} className="text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{teamMembers?.length || 0}</div>
              <p className="text-xs text-muted-foreground">
                {activeMembers.length} active members
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Departments</CardTitle>
              <Users size={16} className="text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {new Set(teamMembers?.map(member => member.department)).size || 0}
              </div>
              <p className="text-xs text-muted-foreground">
                across the agency
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Hourly Rate</CardTitle>
              <Calendar size={16} className="text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${totalBillableRate}</div>
              <p className="text-xs text-muted-foreground">
                combined hourly rate
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Team Members Grid */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xl font-semibold">Team Members</h2>
              <p className="text-sm text-muted-foreground">
                Manage your agency team and their information
              </p>
            </div>
          </div>
          
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {teamMembers?.map((member) => (
              <Card key={member.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-4">
                  <div className="flex items-start gap-3">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={member.avatar} alt={member.name} />
                      <AvatarFallback>
                        {member.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <CardTitle className="text-lg font-semibold truncate">
                          {member.name}
                        </CardTitle>
                        <Badge 
                          variant={member.status === "active" ? "default" : "secondary"}
                          className="text-xs"
                        >
                          {member.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{member.role}</p>
                      <p className="text-xs text-muted-foreground">{member.department}</p>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <Envelope size={14} className="text-muted-foreground" />
                      <span className="truncate">{member.email}</span>
                    </div>
                    {member.phone && (
                      <div className="flex items-center gap-2 text-sm">
                        <Phone size={14} className="text-muted-foreground" />
                        <span>{member.phone}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-2 text-sm">
                      <Calendar size={14} className="text-muted-foreground" />
                      <span>Started {new Date(member.startDate).toLocaleDateString()}</span>
                    </div>
                  </div>
                  
                  {member.skills.length > 0 && (
                    <div>
                      <p className="text-xs font-medium text-muted-foreground mb-2">Skills</p>
                      <div className="flex flex-wrap gap-1">
                        {member.skills.slice(0, 3).map((skill, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                        {member.skills.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{member.skills.length - 3}
                          </Badge>
                        )}
                      </div>
                    </div>
                  )}
                  
                  {member.hourlyRate && (
                    <div className="pt-2 border-t">
                      <p className="text-sm font-medium">${member.hourlyRate}/hour</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </main>

      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Add Team Member</DialogTitle>
            <DialogDescription>
              Add a new team member to your agency. Fill in their details below.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="member-name">Full Name</Label>
              <Input
                id="member-name"
                value={newMember.name}
                onChange={(e) => setNewMember(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Sarah Johnson"
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="member-email">Email</Label>
              <Input
                id="member-email"
                type="email"
                value={newMember.email}
                onChange={(e) => setNewMember(prev => ({ ...prev, email: e.target.value }))}
                placeholder="sarah@agency.com"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="member-role">Role</Label>
                <Input
                  id="member-role"
                  value={newMember.role}
                  onChange={(e) => setNewMember(prev => ({ ...prev, role: e.target.value }))}
                  placeholder="Creative Director"
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="member-department">Department</Label>
                <Select 
                  value={newMember.department}
                  onValueChange={(value) => setNewMember(prev => ({ ...prev, department: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Design">Design</SelectItem>
                    <SelectItem value="Development">Development</SelectItem>
                    <SelectItem value="Marketing">Marketing</SelectItem>
                    <SelectItem value="Operations">Operations</SelectItem>
                    <SelectItem value="Strategy">Strategy</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="member-phone">Phone (Optional)</Label>
                <Input
                  id="member-phone"
                  value={newMember.phone}
                  onChange={(e) => setNewMember(prev => ({ ...prev, phone: e.target.value }))}
                  placeholder="+1 (555) 123-4567"
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="member-start-date">Start Date</Label>
                <Input
                  id="member-start-date"
                  type="date"
                  value={newMember.startDate}
                  onChange={(e) => setNewMember(prev => ({ ...prev, startDate: e.target.value }))}
                />
              </div>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="member-hourly-rate">Hourly Rate (Optional)</Label>
              <Input
                id="member-hourly-rate"
                type="number"
                value={newMember.hourlyRate}
                onChange={(e) => setNewMember(prev => ({ ...prev, hourlyRate: e.target.value }))}
                placeholder="125"
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="member-skills">Skills (comma-separated)</Label>
              <Input
                id="member-skills"
                value={newMember.skills}
                onChange={(e) => setNewMember(prev => ({ ...prev, skills: e.target.value }))}
                placeholder="UI/UX Design, Brand Strategy, Adobe Creative Suite"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsCreateDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleCreateMember}
              disabled={!newMember.name || !newMember.email || !newMember.role}
            >
              Add Member
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}