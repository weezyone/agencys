import { useState, useMemo } from "react"
import { useKV } from "@github/spark/hooks"
import { DashboardHeader } from "@/components/dashboard-header"
import { TimeEntryForm } from "@/components/time-entry-form"
import { TimeEntriesTable } from "@/components/time-entries-table"
import { TimeTrackingStats } from "@/components/time-tracking-stats"
import { WeeklyTimesheetView } from "@/components/weekly-timesheet-view"
import { TeamUtilizationPanel } from "@/components/team-utilization-panel"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Clock, Plus } from "@phosphor-icons/react"
import type { TimeEntry } from "@/lib/types"

export function TimeTrackingPage() {
  const [timeEntries, setTimeEntries] = useKV<TimeEntry[]>("agency-time-entries", [])
  const [isEntryFormOpen, setIsEntryFormOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("entries")
  
  const handleCreateEntry = (entry: Omit<TimeEntry, "id">) => {
    const newEntry: TimeEntry = {
      ...entry,
      id: Date.now().toString(),
    }
    setTimeEntries(current => [...(current || []), newEntry])
  }

  const handleUpdateEntry = (id: string, updates: Partial<TimeEntry>) => {
    setTimeEntries(current =>
      (current || []).map(entry =>
        entry.id === id ? { ...entry, ...updates } : entry
      )
    )
  }

  const handleDeleteEntry = (id: string) => {
    setTimeEntries(current => (current || []).filter(entry => entry.id !== id))
  }

  const currentWeekStart = useMemo(() => {
    const now = new Date()
    const day = now.getDay()
    const diff = now.getDate() - day + (day === 0 ? -6 : 1)
    return new Date(now.setDate(diff))
  }, [])

  return (
    <>
      <DashboardHeader
        title="Time Tracking"
        onCreateProject={() => setIsEntryFormOpen(true)}
        customActionText="Log Time"
        customActionIcon={<Plus size={16} />}
      />
      
      <main className="flex-1 space-y-6 p-6 overflow-auto">
        <TimeTrackingStats entries={timeEntries || []} />
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList>
            <TabsTrigger value="entries">Time Entries</TabsTrigger>
            <TabsTrigger value="timesheet">Weekly Timesheet</TabsTrigger>
            <TabsTrigger value="utilization">Team Utilization</TabsTrigger>
          </TabsList>
          
          <TabsContent value="entries" className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-semibold">Time Entries</h2>
                <p className="text-sm text-muted-foreground">
                  {timeEntries?.length || 0} total entries
                </p>
              </div>
              <Button onClick={() => setIsEntryFormOpen(true)}>
                <Clock size={16} className="mr-2" />
                Log Time
              </Button>
            </div>
            
            <TimeEntriesTable
              entries={timeEntries || []}
              onUpdate={handleUpdateEntry}
              onDelete={handleDeleteEntry}
            />
          </TabsContent>
          
          <TabsContent value="timesheet" className="space-y-4">
            <div>
              <h2 className="text-xl font-semibold">Weekly Timesheet</h2>
              <p className="text-sm text-muted-foreground">
                Week of {currentWeekStart.toLocaleDateString()}
              </p>
            </div>
            
            <WeeklyTimesheetView
              entries={timeEntries || []}
              weekStart={currentWeekStart}
              onCreateEntry={() => setIsEntryFormOpen(true)}
            />
          </TabsContent>
          
          <TabsContent value="utilization" className="space-y-4">
            <div>
              <h2 className="text-xl font-semibold">Team Utilization</h2>
              <p className="text-sm text-muted-foreground">
                Monitor team productivity and capacity
              </p>
            </div>
            
            <TeamUtilizationPanel entries={timeEntries || []} />
          </TabsContent>
        </Tabs>
      </main>

      <TimeEntryForm
        open={isEntryFormOpen}
        onOpenChange={setIsEntryFormOpen}
        onSubmit={handleCreateEntry}
      />
    </>
  )
}
