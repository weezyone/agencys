import { useState } from "react"
import { useKV } from "@github/spark/hooks"
import { DashboardHeader } from "@/components/dashboard-header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { 
  Users, 
  Envelope, 
  Phone, 
  Plus, 
  Buildings, 
  MapPin,
  CurrencyDollar,
  Folders
} from "@phosphor-icons/react"

export interface Client {
  id: string
  name: string
  company: string
  email: string
  phone?: string
  address?: string
  industry: string
  status: "active" | "inactive" | "prospect"
  totalProjects: number
  totalRevenue: number
  notes?: string
  avatar?: string
  contactPerson: string
}

export function ClientsPage() {
  const [clients, setClients] = useKV<Client[]>("agency-clients", [
    {
      id: "1",
      name: "Sarah Wilson",
      company: "TechFlow Inc",
      email: "sarah@techflow.com",
      phone: "+1 (555) 789-0123",
      address: "123 Business St, San Francisco, CA 94105",
      industry: "Technology",
      status: "active",
      totalProjects: 8,
      totalRevenue: 240000,
      contactPerson: "Sarah Wilson",
      notes: "Long-term client, prefers agile methodology"
    },
    {
      id: "2",
      name: "Michael Rodriguez",
      company: "GreenLeaf Marketing",
      email: "michael@greenleaf.com", 
      phone: "+1 (555) 456-7890",
      industry: "Marketing",
      status: "active",
      totalProjects: 3,
      totalRevenue: 85000,
      contactPerson: "Michael Rodriguez"
    },
    {
      id: "3",
      name: "Emma Thompson",
      company: "Boutique Fashion Co",
      email: "emma@boutiquefashion.com",
      industry: "Retail",
      status: "prospect",
      totalProjects: 0,
      totalRevenue: 0,
      contactPerson: "Emma Thompson",
      notes: "Interested in e-commerce platform"
    }
  ])

  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [newClient, setNewClient] = useState({
    name: "",
    company: "",
    email: "",
    phone: "",
    address: "",
    industry: "",
    status: "prospect" as Client["status"],
    notes: ""
  })

  const handleCreateClient = () => {
    const client: Client = {
      id: Date.now().toString(),
      name: newClient.name,
      company: newClient.company,
      email: newClient.email,
      phone: newClient.phone,
      address: newClient.address,
      industry: newClient.industry,
      status: newClient.status,
      totalProjects: 0,
      totalRevenue: 0,
      contactPerson: newClient.name,
      notes: newClient.notes
    }

    setClients(current => [...(current || []), client])
    setIsCreateDialogOpen(false)
    setNewClient({
      name: "",
      company: "",
      email: "",
      phone: "",
      address: "",
      industry: "",
      status: "prospect",
      notes: ""
    })
  }

  const activeClients = clients?.filter(client => client.status === "active") || []
  const totalRevenue = clients?.reduce((sum, client) => sum + client.totalRevenue, 0) || 0
  const totalProjects = clients?.reduce((sum, client) => sum + client.totalProjects, 0) || 0

  const statusStyles = {
    active: "bg-green-100 text-green-800",
    inactive: "bg-gray-100 text-gray-800", 
    prospect: "bg-blue-100 text-blue-800"
  }

  return (
    <>
      <DashboardHeader
        title="Clients"
        onCreateProject={() => setIsCreateDialogOpen(true)}
        customActionText="Add Client"
        customActionIcon={<Plus size={16} />}
      />
      
      <main className="flex-1 space-y-6 p-6 overflow-auto">
        {/* Client Overview Stats */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Clients</CardTitle>
              <Users size={16} className="text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{clients?.length || 0}</div>
              <p className="text-xs text-muted-foreground">
                {activeClients.length} active clients
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
              <CurrencyDollar size={16} className="text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${totalRevenue.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                lifetime value
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Projects</CardTitle>
              <Folders size={16} className="text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalProjects}</div>
              <p className="text-xs text-muted-foreground">
                across all clients
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Avg. Project Value</CardTitle>
              <CurrencyDollar size={16} className="text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                ${totalProjects > 0 ? Math.round(totalRevenue / totalProjects).toLocaleString() : 0}
              </div>
              <p className="text-xs text-muted-foreground">
                per project
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Clients Grid */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xl font-semibold">Client Directory</h2>
              <p className="text-sm text-muted-foreground">
                Manage your client relationships and contact information
              </p>
            </div>
          </div>
          
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {clients?.map((client) => (
              <Card key={client.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={client.avatar} alt={client.name} />
                        <AvatarFallback>
                          {client.name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <CardTitle className="text-lg font-semibold truncate">
                          {client.name}
                        </CardTitle>
                        <p className="text-sm text-muted-foreground truncate">{client.company}</p>
                        <p className="text-xs text-muted-foreground">{client.industry}</p>
                      </div>
                    </div>
                    <Badge variant="secondary" className={statusStyles[client.status]}>
                      {client.status}
                    </Badge>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <Envelope size={14} className="text-muted-foreground" />
                      <span className="truncate">{client.email}</span>
                    </div>
                    {client.phone && (
                      <div className="flex items-center gap-2 text-sm">
                        <Phone size={14} className="text-muted-foreground" />
                        <span>{client.phone}</span>
                      </div>
                    )}
                    {client.address && (
                      <div className="flex items-center gap-2 text-sm">
                        <MapPin size={14} className="text-muted-foreground" />
                        <span className="text-xs">{client.address}</span>
                      </div>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 pt-2 border-t">
                    <div>
                      <p className="text-xs text-muted-foreground">Projects</p>
                      <p className="text-sm font-medium">{client.totalProjects}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Revenue</p>
                      <p className="text-sm font-medium">${client.totalRevenue.toLocaleString()}</p>
                    </div>
                  </div>
                  
                  {client.notes && (
                    <div className="pt-2 border-t">
                      <p className="text-xs text-muted-foreground mb-1">Notes</p>
                      <p className="text-xs">{client.notes}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </main>

      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Add New Client</DialogTitle>
            <DialogDescription>
              Add a new client to your portfolio. Fill in their contact details and information.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="client-name">Contact Name</Label>
                <Input
                  id="client-name"
                  value={newClient.name}
                  onChange={(e) => setNewClient(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Sarah Wilson"
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="client-company">Company</Label>
                <Input
                  id="client-company"
                  value={newClient.company}
                  onChange={(e) => setNewClient(prev => ({ ...prev, company: e.target.value }))}
                  placeholder="TechFlow Inc"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="client-email">Email</Label>
                <Input
                  id="client-email"
                  type="email"
                  value={newClient.email}
                  onChange={(e) => setNewClient(prev => ({ ...prev, email: e.target.value }))}
                  placeholder="sarah@techflow.com"
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="client-phone">Phone (Optional)</Label>
                <Input
                  id="client-phone"
                  value={newClient.phone}
                  onChange={(e) => setNewClient(prev => ({ ...prev, phone: e.target.value }))}
                  placeholder="+1 (555) 789-0123"
                />
              </div>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="client-address">Address (Optional)</Label>
              <Input
                id="client-address"
                value={newClient.address}
                onChange={(e) => setNewClient(prev => ({ ...prev, address: e.target.value }))}
                placeholder="123 Business St, San Francisco, CA 94105"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="client-industry">Industry</Label>
                <Select 
                  value={newClient.industry}
                  onValueChange={(value) => setNewClient(prev => ({ ...prev, industry: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select industry..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Technology">Technology</SelectItem>
                    <SelectItem value="Healthcare">Healthcare</SelectItem>
                    <SelectItem value="Finance">Finance</SelectItem>
                    <SelectItem value="Retail">Retail</SelectItem>
                    <SelectItem value="Marketing">Marketing</SelectItem>
                    <SelectItem value="Manufacturing">Manufacturing</SelectItem>
                    <SelectItem value="Education">Education</SelectItem>
                    <SelectItem value="Real Estate">Real Estate</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="client-status">Status</Label>
                <Select 
                  value={newClient.status}
                  onValueChange={(value) => setNewClient(prev => ({ ...prev, status: value as Client["status"] }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="prospect">Prospect</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="client-notes">Notes (Optional)</Label>
              <Textarea
                id="client-notes"
                value={newClient.notes}
                onChange={(e) => setNewClient(prev => ({ ...prev, notes: e.target.value }))}
                placeholder="Any additional notes about this client..."
                rows={3}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsCreateDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleCreateClient}
              disabled={!newClient.name || !newClient.company || !newClient.email}
            >
              Add Client
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}