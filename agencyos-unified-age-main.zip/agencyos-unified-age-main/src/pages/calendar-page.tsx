import { useState } from "react"
import { useKV } from "@github/spark/hooks"
import { DashboardHeader } from "@/components/dashboard-header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { 
  Calendar, 
  Plus, 
  Clock,
  Users,
  MapPin,
  Video,
  CaretLeft,
  CaretRight
} from "@phosphor-icons/react"

interface CalendarEvent {
  id: string
  title: string
  type: "meeting" | "deadline" | "milestone" | "review" | "presentation"
  startTime: string
  endTime?: string
  date: string
  location?: string
  attendees?: string[]
  project?: string
  client?: string
  description?: string
  isOnline?: boolean
}

export function CalendarPage() {
  const [events, setEvents] = useKV<CalendarEvent[]>("agency-calendar-events", [
    {
      id: "1",
      title: "Client Kickoff Meeting - TechFlow",
      type: "meeting",
      startTime: "10:00",
      endTime: "11:30",
      date: "2024-01-29",
      location: "Conference Room A",
      attendees: ["Sarah Johnson", "Mike Chen", "Client Team"],
      project: "Website Redesign",
      client: "TechFlow Inc",
      description: "Project kickoff and requirements gathering session"
    },
    {
      id: "2",
      title: "Design Review - Brand Identity",
      type: "review",
      startTime: "14:00",
      endTime: "15:00",
      date: "2024-01-29",
      location: "Design Studio",
      attendees: ["Emma Davis", "Sarah Johnson"],
      project: "Brand Identity",
      client: "GreenLeaf Marketing"
    },
    {
      id: "3",
      title: "Project Deadline - Website Launch",
      type: "deadline",
      startTime: "23:59",
      date: "2024-01-30",
      project: "Website Redesign",
      client: "TechFlow Inc",
      description: "Final website deployment and launch"
    },
    {
      id: "4",
      title: "Team Standup",
      type: "meeting",
      startTime: "09:00",
      endTime: "09:30",
      date: "2024-01-31",
      isOnline: true,
      attendees: ["All Team Members"],
      description: "Daily team sync and project updates"
    },
    {
      id: "5",
      title: "Client Presentation - E-commerce Demo",
      type: "presentation",
      startTime: "15:00",
      endTime: "16:30",
      date: "2024-02-01",
      location: "Client Office",
      project: "E-commerce Platform",
      client: "Boutique Fashion Co",
      attendees: ["Mike Chen", "Emma Davis", "Client Team"]
    }
  ])

  const [currentDate, setCurrentDate] = useState(new Date())
  const [selectedView, setSelectedView] = useState<"week" | "month">("week")
  const [isCreateEventOpen, setIsCreateEventOpen] = useState(false)
  const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null)
  
  const [newEvent, setNewEvent] = useState({
    title: "",
    type: "meeting" as CalendarEvent["type"],
    startTime: "",
    endTime: "",
    date: "",
    location: "",
    project: "",
    client: "",
    description: "",
    isOnline: false
  })

  const handleCreateEvent = () => {
    const event: CalendarEvent = {
      id: Date.now().toString(),
      title: newEvent.title,
      type: newEvent.type,
      startTime: newEvent.startTime,
      endTime: newEvent.endTime || undefined,
      date: newEvent.date,
      location: newEvent.isOnline ? "Online" : newEvent.location,
      project: newEvent.project || undefined,
      client: newEvent.client || undefined,
      description: newEvent.description || undefined,
      isOnline: newEvent.isOnline,
      attendees: []
    }

    setEvents(current => [...(current || []), event])
    setIsCreateEventOpen(false)
    setNewEvent({
      title: "",
      type: "meeting",
      startTime: "",
      endTime: "",
      date: "",
      location: "",
      project: "",
      client: "",
      description: "",
      isOnline: false
    })
  }

  // Get events for current week
  const getWeekDates = (date: Date): Date[] => {
    const week: Date[] = []
    const startDate = new Date(date)
    const dayOfWeek = startDate.getDay()
    startDate.setDate(startDate.getDate() - dayOfWeek)

    for (let i = 0; i < 7; i++) {
      const day = new Date(startDate)
      day.setDate(startDate.getDate() + i)
      week.push(day)
    }
    return week
  }

  const weekDates = getWeekDates(currentDate)
  const todayString = new Date().toISOString().split('T')[0]

  const getEventsForDate = (date: Date) => {
    const dateString = date.toISOString().split('T')[0]
    return events?.filter(event => event.date === dateString) || []
  }

  const eventTypeStyles = {
    meeting: "bg-blue-100 text-blue-800 border-blue-200",
    deadline: "bg-red-100 text-red-800 border-red-200",
    milestone: "bg-green-100 text-green-800 border-green-200",
    review: "bg-yellow-100 text-yellow-800 border-yellow-200",
    presentation: "bg-purple-100 text-purple-800 border-purple-200"
  }

  const eventTypeIcons = {
    meeting: Users,
    deadline: Clock,
    milestone: Calendar,
    review: Clock,
    presentation: Video
  }

  const navigateWeek = (direction: "prev" | "next") => {
    const newDate = new Date(currentDate)
    newDate.setDate(newDate.getDate() + (direction === "next" ? 7 : -7))
    setCurrentDate(newDate)
  }

  return (
    <>
      <DashboardHeader
        title="Calendar"
        onCreateProject={() => setIsCreateEventOpen(true)}
        customActionText="Add Event"
        customActionIcon={<Plus size={16} />}
      />
      
      <main className="flex-1 space-y-6 p-6 overflow-auto">
        {/* Calendar Controls */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                size="icon"
                onClick={() => navigateWeek("prev")}
              >
                <CaretLeft size={16} />
              </Button>
              <h2 className="text-lg font-semibold min-w-48 text-center">
                {weekDates[0].toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
              </h2>
              <Button 
                variant="outline" 
                size="icon"
                onClick={() => navigateWeek("next")}
              >
                <CaretRight size={16} />
              </Button>
            </div>
            
            <Select value={selectedView} onValueChange={(value: "week" | "month") => setSelectedView(value)}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="week">Week View</SelectItem>
                <SelectItem value="month">Month View</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <Button onClick={() => setCurrentDate(new Date())} variant="outline">
            Today
          </Button>
        </div>

        {/* Week View Calendar */}
        {selectedView === "week" && (
          <div className="grid grid-cols-7 gap-4">
            {weekDates.map((date, index) => {
              const dayEvents = getEventsForDate(date)
              const isToday = date.toISOString().split('T')[0] === todayString
              const dayName = date.toLocaleDateString('en-US', { weekday: 'short' })
              const dayNumber = date.getDate()

              return (
                <Card key={index} className={`min-h-96 ${isToday ? 'ring-2 ring-primary' : ''}`}>
                  <CardHeader className="pb-3">
                    <div className="text-center">
                      <p className="text-sm font-medium text-muted-foreground">{dayName}</p>
                      <p className={`text-lg font-semibold ${isToday ? 'text-primary' : ''}`}>
                        {dayNumber}
                      </p>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {dayEvents.map((event) => {
                      const EventIcon = eventTypeIcons[event.type]
                      return (
                        <div
                          key={event.id}
                          className={`p-2 rounded-lg border cursor-pointer hover:shadow-sm transition-shadow ${eventTypeStyles[event.type]}`}
                          onClick={() => setSelectedEvent(event)}
                        >
                          <div className="flex items-start justify-between gap-1">
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-medium truncate">{event.title}</p>
                              <div className="flex items-center gap-1 mt-1">
                                <Clock size={10} />
                                <p className="text-xs">{event.startTime}</p>
                              </div>
                              {event.client && (
                                <p className="text-xs opacity-75 truncate">{event.client}</p>
                              )}
                            </div>
                            <EventIcon size={12} />
                          </div>
                        </div>
                      )
                    })}
                  </CardContent>
                </Card>
              )
            })}
          </div>
        )}

        {/* Upcoming Events */}
        <Card>
          <CardHeader>
            <CardTitle>Upcoming Events</CardTitle>
            <p className="text-sm text-muted-foreground">Your schedule for the next few days</p>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {events?.slice(0, 5).map((event) => {
                const EventIcon = eventTypeIcons[event.type]
                const eventDate = new Date(event.date)
                const isToday = event.date === todayString
                
                return (
                  <div
                    key={event.id}
                    className="flex items-center gap-4 p-3 rounded-lg border hover:shadow-sm transition-shadow cursor-pointer"
                    onClick={() => setSelectedEvent(event)}
                  >
                    <div className={`p-2 rounded-full ${eventTypeStyles[event.type]}`}>
                      <EventIcon size={16} />
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-medium">{event.title}</p>
                        <Badge variant="secondary" className={eventTypeStyles[event.type]}>
                          {event.type}
                        </Badge>
                        {isToday && (
                          <Badge variant="default" className="text-xs">
                            Today
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Calendar size={14} />
                          <span>{eventDate.toLocaleDateString()}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock size={14} />
                          <span>{event.startTime}{event.endTime && ` - ${event.endTime}`}</span>
                        </div>
                        {event.location && (
                          <div className="flex items-center gap-1">
                            {event.isOnline ? <Video size={14} /> : <MapPin size={14} />}
                            <span>{event.location}</span>
                          </div>
                        )}
                      </div>
                      
                      {event.client && (
                        <p className="text-sm text-muted-foreground mt-1">
                          {event.client} {event.project && `• ${event.project}`}
                        </p>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Create Event Dialog */}
      <Dialog open={isCreateEventOpen} onOpenChange={setIsCreateEventOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Create New Event</DialogTitle>
            <DialogDescription>
              Add a new event to your calendar. Fill in the details below.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="event-title">Event Title</Label>
              <Input
                id="event-title"
                value={newEvent.title}
                onChange={(e) => setNewEvent(prev => ({ ...prev, title: e.target.value }))}
                placeholder="Client Meeting - Project Review"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="event-type">Event Type</Label>
                <Select 
                  value={newEvent.type}
                  onValueChange={(value) => setNewEvent(prev => ({ ...prev, type: value as CalendarEvent["type"] }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="meeting">Meeting</SelectItem>
                    <SelectItem value="deadline">Deadline</SelectItem>
                    <SelectItem value="milestone">Milestone</SelectItem>
                    <SelectItem value="review">Review</SelectItem>
                    <SelectItem value="presentation">Presentation</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="event-date">Date</Label>
                <Input
                  id="event-date"
                  type="date"
                  value={newEvent.date}
                  onChange={(e) => setNewEvent(prev => ({ ...prev, date: e.target.value }))}
                />
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="event-start-time">Start Time</Label>
                <Input
                  id="event-start-time"
                  type="time"
                  value={newEvent.startTime}
                  onChange={(e) => setNewEvent(prev => ({ ...prev, startTime: e.target.value }))}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="event-end-time">End Time (Optional)</Label>
                <Input
                  id="event-end-time"
                  type="time"
                  value={newEvent.endTime}
                  onChange={(e) => setNewEvent(prev => ({ ...prev, endTime: e.target.value }))}
                />
              </div>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="event-location">Location</Label>
              <Input
                id="event-location"
                value={newEvent.location}
                onChange={(e) => setNewEvent(prev => ({ ...prev, location: e.target.value }))}
                placeholder="Conference Room A or Online"
                disabled={newEvent.isOnline}
              />
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="is-online"
                  checked={newEvent.isOnline}
                  onChange={(e) => setNewEvent(prev => ({ 
                    ...prev, 
                    isOnline: e.target.checked,
                    location: e.target.checked ? "Online" : ""
                  }))}
                  className="rounded border-gray-300"
                />
                <Label htmlFor="is-online" className="text-sm">This is an online event</Label>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="event-client">Client (Optional)</Label>
                <Input
                  id="event-client"
                  value={newEvent.client}
                  onChange={(e) => setNewEvent(prev => ({ ...prev, client: e.target.value }))}
                  placeholder="TechFlow Inc"
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="event-project">Project (Optional)</Label>
                <Input
                  id="event-project"
                  value={newEvent.project}
                  onChange={(e) => setNewEvent(prev => ({ ...prev, project: e.target.value }))}
                  placeholder="Website Redesign"
                />
              </div>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="event-description">Description (Optional)</Label>
              <Textarea
                id="event-description"
                value={newEvent.description}
                onChange={(e) => setNewEvent(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Additional details about the event..."
                rows={3}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsCreateEventOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleCreateEvent}
              disabled={!newEvent.title || !newEvent.date || !newEvent.startTime}
            >
              Create Event
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Event Details Dialog */}
      {selectedEvent && (
        <Dialog open={!!selectedEvent} onOpenChange={() => setSelectedEvent(null)}>
          <DialogContent className="sm:max-w-[400px]">
            <DialogHeader>
              <DialogTitle>{selectedEvent.title}</DialogTitle>
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className={eventTypeStyles[selectedEvent.type]}>
                  {selectedEvent.type}
                </Badge>
                {selectedEvent.client && (
                  <Badge variant="outline">{selectedEvent.client}</Badge>
                )}
              </div>
            </DialogHeader>
            
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm">
                <Calendar size={16} className="text-muted-foreground" />
                <span>{new Date(selectedEvent.date).toLocaleDateString()}</span>
              </div>
              
              <div className="flex items-center gap-2 text-sm">
                <Clock size={16} className="text-muted-foreground" />
                <span>
                  {selectedEvent.startTime}
                  {selectedEvent.endTime && ` - ${selectedEvent.endTime}`}
                </span>
              </div>
              
              {selectedEvent.location && (
                <div className="flex items-center gap-2 text-sm">
                  {selectedEvent.isOnline ? (
                    <Video size={16} className="text-muted-foreground" />
                  ) : (
                    <MapPin size={16} className="text-muted-foreground" />
                  )}
                  <span>{selectedEvent.location}</span>
                </div>
              )}
              
              {selectedEvent.project && (
                <div className="flex items-center gap-2 text-sm">
                  <Calendar size={16} className="text-muted-foreground" />
                  <span>Project: {selectedEvent.project}</span>
                </div>
              )}
              
              {selectedEvent.attendees && selectedEvent.attendees.length > 0 && (
                <div className="flex items-start gap-2 text-sm">
                  <Users size={16} className="text-muted-foreground mt-0.5" />
                  <div>
                    <p>Attendees:</p>
                    <ul className="text-muted-foreground">
                      {selectedEvent.attendees.map((attendee, index) => (
                        <li key={index}>• {attendee}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
              
              {selectedEvent.description && (
                <div className="text-sm">
                  <p className="font-medium mb-1">Description:</p>
                  <p className="text-muted-foreground">{selectedEvent.description}</p>
                </div>
              )}
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setSelectedEvent(null)}>
                Close
              </Button>
              <Button>Edit Event</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </>
  )
}