import { useState } from "react"
import { useKV } from "@github/spark/hooks"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { 
  Robot, 
  Play, 
  Pause, 
  Gear, 
  ChatCircle,
  FileText,
  ChartLine,
  PencilSimple,
  Code,
  Calendar
} from "@phosphor-icons/react"
import { AgentConfigDialog } from "@/components/agent-config-dialog"
import { AgentChatPanel } from "@/components/agent-chat-panel"
import { AgentActivityLog } from "@/components/agent-activity-log"

export type AgentType = 
  | "content-writer"
  | "proposal-generator" 
  | "report-analyzer"
  | "code-reviewer"
  | "meeting-scheduler"
  | "project-assistant"

export interface Agent {
  id: string
  type: AgentType
  name: string
  description: string
  status: "active" | "paused" | "idle"
  tasksCompleted: number
  config?: Record<string, any>
}

const agentTemplates: Omit<Agent, "id" | "status" | "tasksCompleted">[] = [
  {
    type: "content-writer",
    name: "Content Writer Agent",
    description: "Generates blog posts, social media content, and marketing copy based on your brand voice",
    config: { tone: "professional", creativity: 0.7 }
  },
  {
    type: "proposal-generator",
    name: "Proposal Generator",
    description: "Creates customized project proposals and SOWs based on client requirements",
    config: { includeTimeline: true, includeBudget: true }
  },
  {
    type: "report-analyzer",
    name: "Report Analyzer",
    description: "Analyzes project metrics and generates insights for stakeholder reports",
    config: { frequency: "weekly", metrics: ["budget", "timeline", "utilization"] }
  },
  {
    type: "code-reviewer",
    name: "Code Reviewer",
    description: "Reviews code changes and provides feedback on best practices and potential issues",
    config: { languages: ["typescript", "javascript", "react"], severity: "medium" }
  },
  {
    type: "meeting-scheduler",
    name: "Meeting Scheduler",
    description: "Intelligently schedules meetings based on team availability and project priorities",
    config: { bufferTime: 15, preferredTimes: ["morning", "early-afternoon"] }
  },
  {
    type: "project-assistant",
    name: "Project Assistant",
    description: "Helps manage project tasks, sends reminders, and tracks deliverables",
    config: { reminderFrequency: "daily", trackMilestones: true }
  }
]

const agentIcons: Record<AgentType, typeof Robot> = {
  "content-writer": PencilSimple,
  "proposal-generator": FileText,
  "report-analyzer": ChartLine,
  "code-reviewer": Code,
  "meeting-scheduler": Calendar,
  "project-assistant": ChatCircle
}

export function AIAgentsPage() {
  const [agents, setAgents] = useKV<Agent[]>("ai-agents", [])
  const [selectedAgent, setSelectedAgent] = useState<Agent | null>(null)
  const [configDialogOpen, setConfigDialogOpen] = useState(false)
  const [chatPanelOpen, setChatPanelOpen] = useState(false)
  const [agentToConfig, setAgentToConfig] = useState<Omit<Agent, "id" | "status" | "tasksCompleted"> | null>(null)

  const agentsList = agents || []

  const handleCreateAgent = (template: Omit<Agent, "id" | "status" | "tasksCompleted">) => {
    setAgentToConfig(template)
    setConfigDialogOpen(true)
  }

  const handleSaveAgent = (config: Record<string, any>) => {
    if (!agentToConfig) return
    
    const newAgent: Agent = {
      ...agentToConfig,
      id: `agent-${Date.now()}`,
      status: "idle",
      tasksCompleted: 0,
      config
    }
    
    setAgents((current) => [...(current || []), newAgent])
    setConfigDialogOpen(false)
    setAgentToConfig(null)
  }

  const handleToggleAgent = (agentId: string) => {
    setAgents((current) =>
      (current || []).map((agent) =>
        agent.id === agentId
          ? { ...agent, status: agent.status === "active" ? "paused" : "active" }
          : agent
      )
    )
  }

  const handleRemoveAgent = (agentId: string) => {
    setAgents((current) => (current || []).filter((agent) => agent.id !== agentId))
  }

  const handleChatWithAgent = (agent: Agent) => {
    setSelectedAgent(agent)
    setChatPanelOpen(true)
  }

  const activeAgents = agentsList.filter(a => a.status === "active")
  const totalTasks = agentsList.reduce((sum, a) => sum + a.tasksCompleted, 0)

  return (
    <div className="flex h-full flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">AI Agents</h1>
        <p className="text-muted-foreground">
          Automate your agency workflows with intelligent AI agents
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Agents</CardTitle>
            <Robot className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeAgents.length}</div>
            <p className="text-xs text-muted-foreground">
              {agentsList.length} total configured
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tasks Completed</CardTitle>
            <ChartLine className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalTasks}</div>
            <p className="text-xs text-muted-foreground">
              Across all agents
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Efficiency Gain</CardTitle>
            <ChartLine className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">~{Math.round(totalTasks * 1.5)}h</div>
            <p className="text-xs text-muted-foreground">
              Estimated time saved
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="all" className="flex-1">
        <TabsList>
          <TabsTrigger value="all">All Agents</TabsTrigger>
          <TabsTrigger value="active">Active ({activeAgents.length})</TabsTrigger>
          <TabsTrigger value="templates">Agent Templates</TabsTrigger>
          <TabsTrigger value="activity">Activity Log</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          {agentsList.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Robot className="mb-4 h-12 w-12 text-muted-foreground" />
                <h3 className="mb-2 text-lg font-semibold">No agents configured</h3>
                <p className="mb-4 text-sm text-muted-foreground">
                  Get started by creating your first AI agent from templates
                </p>
                <Button onClick={() => {
                  const firstTemplate = agentTemplates[0]
                  handleCreateAgent(firstTemplate)
                }}>
                  Create Your First Agent
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {agentsList.map((agent) => {
                const Icon = agentIcons[agent.type]
                return (
                  <Card key={agent.id} className="relative overflow-hidden">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                            <Icon className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <CardTitle className="text-base">{agent.name}</CardTitle>
                            <Badge 
                              variant={agent.status === "active" ? "default" : "secondary"}
                              className="mt-1"
                            >
                              {agent.status}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      <CardDescription className="mt-2">
                        {agent.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Tasks completed</span>
                          <span className="font-medium">{agent.tasksCompleted}</span>
                        </div>
                        <Progress value={Math.min((agent.tasksCompleted / 10) * 100, 100)} className="mt-2" />
                      </div>
                      
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant={agent.status === "active" ? "outline" : "default"}
                          onClick={() => handleToggleAgent(agent.id)}
                          className="flex-1"
                        >
                          {agent.status === "active" ? (
                            <>
                              <Pause className="mr-2 h-4 w-4" />
                              Pause
                            </>
                          ) : (
                            <>
                              <Play className="mr-2 h-4 w-4" />
                              Activate
                            </>
                          )}
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleChatWithAgent(agent)}
                        >
                          <ChatCircle className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleRemoveAgent(agent.id)}
                        >
                          <Gear className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="active" className="space-y-4">
          {activeAgents.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Robot className="mb-4 h-12 w-12 text-muted-foreground" />
                <h3 className="mb-2 text-lg font-semibold">No active agents</h3>
                <p className="text-sm text-muted-foreground">
                  Activate an agent to see it here
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {activeAgents.map((agent) => {
                const Icon = agentIcons[agent.type]
                return (
                  <Card key={agent.id}>
                    <CardHeader>
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                          <Icon className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <CardTitle className="text-base">{agent.name}</CardTitle>
                          <Badge className="mt-1">Active</Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleChatWithAgent(agent)}
                        className="w-full"
                      >
                        <ChatCircle className="mr-2 h-4 w-4" />
                        Chat with Agent
                      </Button>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="templates" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {agentTemplates.map((template) => {
              const Icon = agentIcons[template.type]
              return (
                <Card key={template.type}>
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
                        <Icon className="h-5 w-5 text-accent" />
                      </div>
                      <CardTitle className="text-base">{template.name}</CardTitle>
                    </div>
                    <CardDescription>{template.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button
                      size="sm"
                      onClick={() => handleCreateAgent(template)}
                      className="w-full"
                    >
                      <Play className="mr-2 h-4 w-4" />
                      Create Agent
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>

        <TabsContent value="activity" className="space-y-4">
          <AgentActivityLog agents={agentsList} />
        </TabsContent>
      </Tabs>

      {agentToConfig && (
        <AgentConfigDialog
          open={configDialogOpen}
          onOpenChange={setConfigDialogOpen}
          agent={agentToConfig}
          onSave={handleSaveAgent}
        />
      )}

      {selectedAgent && (
        <AgentChatPanel
          open={chatPanelOpen}
          onOpenChange={setChatPanelOpen}
          agent={selectedAgent}
        />
      )}
    </div>
  )
}
