import { useState } from "react"
import { useKV } from "@github/spark/hooks"
import { DashboardHeader } from "@/components/dashboard-header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { 
  CurrencyDollar, 
  TrendUp, 
  TrendDown,
  Wallet,
  Receipt,
  ChartPie
} from "@phosphor-icons/react"

interface BudgetItem {
  id: string
  category: string
  allocated: number
  spent: number
  month: string
  year: number
}

interface ProjectBudget {
  id: string
  projectName: string
  client: string
  totalBudget: number
  spentAmount: number
  remainingBudget: number
  status: "on-track" | "over-budget" | "under-budget"
  lastUpdated: string
}

export function BudgetsPage() {
  const [monthlyBudgets, setMonthlyBudgets] = useKV<BudgetItem[]>("agency-monthly-budgets", [
    { id: "1", category: "Salaries", allocated: 45000, spent: 45000, month: "January", year: 2024 },
    { id: "2", category: "Marketing", allocated: 8000, spent: 6500, month: "January", year: 2024 },
    { id: "3", category: "Software & Tools", allocated: 3500, spent: 3200, month: "January", year: 2024 },
    { id: "4", category: "Office Expenses", allocated: 2500, spent: 1800, month: "January", year: 2024 },
    { id: "5", category: "Equipment", allocated: 5000, spent: 2100, month: "January", year: 2024 },
    { id: "6", category: "Training", allocated: 2000, spent: 800, month: "January", year: 2024 },
  ])

  const [projectBudgets, setProjectBudgets] = useKV<ProjectBudget[]>("agency-project-budgets", [
    {
      id: "1",
      projectName: "Website Redesign",
      client: "TechFlow Inc",
      totalBudget: 45000,
      spentAmount: 32000,
      remainingBudget: 13000,
      status: "on-track",
      lastUpdated: "2024-01-25"
    },
    {
      id: "2", 
      projectName: "Brand Identity",
      client: "GreenLeaf Marketing",
      totalBudget: 8500,
      spentAmount: 9200,
      remainingBudget: -700,
      status: "over-budget",
      lastUpdated: "2024-01-24"
    },
    {
      id: "3",
      projectName: "Mobile App Development",
      client: "StartupCo",
      totalBudget: 65000,
      spentAmount: 28000,
      remainingBudget: 37000,
      status: "under-budget",
      lastUpdated: "2024-01-23"
    }
  ])

  // Calculate totals
  const totalAllocated = monthlyBudgets?.reduce((sum, item) => sum + item.allocated, 0) || 0
  const totalSpent = monthlyBudgets?.reduce((sum, item) => sum + item.spent, 0) || 0
  const totalRemaining = totalAllocated - totalSpent
  const spentPercentage = totalAllocated > 0 ? (totalSpent / totalAllocated) * 100 : 0

  const projectTotalBudget = projectBudgets?.reduce((sum, project) => sum + project.totalBudget, 0) || 0
  const projectTotalSpent = projectBudgets?.reduce((sum, project) => sum + project.spentAmount, 0) || 0
  const projectTotalRemaining = projectTotalBudget - projectTotalSpent

  const statusStyles = {
    "on-track": "bg-green-100 text-green-800",
    "over-budget": "bg-red-100 text-red-800",
    "under-budget": "bg-blue-100 text-blue-800"
  }

  return (
    <>
      <DashboardHeader title="Budgets & Financials" />
      
      <main className="flex-1 space-y-6 p-6 overflow-auto">
        {/* Financial Overview */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Monthly Budget</CardTitle>
              <Wallet size={16} className="text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${totalAllocated.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">allocated this month</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Spent</CardTitle>
              <Receipt size={16} className="text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${totalSpent.toLocaleString()}</div>
              <div className="flex items-center gap-1 mt-1">
                <Badge variant="secondary" className={`gap-1 ${spentPercentage > 90 ? 'text-red-700 bg-red-50' : 'text-green-700 bg-green-50'}`}>
                  {spentPercentage > 90 ? <TrendUp size={12} /> : <TrendDown size={12} />}
                  {spentPercentage.toFixed(1)}%
                </Badge>
                <p className="text-xs text-muted-foreground">of budget</p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Remaining</CardTitle>
              <CurrencyDollar size={16} className="text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${totalRemaining < 0 ? 'text-red-600' : ''}`}>
                ${Math.abs(totalRemaining).toLocaleString()}
              </div>
              <p className="text-xs text-muted-foreground">
                {totalRemaining < 0 ? 'over budget' : 'remaining'}
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Project Budgets</CardTitle>
              <ChartPie size={16} className="text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${projectTotalBudget.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                ${projectTotalRemaining.toLocaleString()} remaining
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          {/* Monthly Budget Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle>Monthly Budget Breakdown</CardTitle>
              <p className="text-sm text-muted-foreground">January 2024 spending by category</p>
            </CardHeader>
            <CardContent className="space-y-4">
              {monthlyBudgets?.map((budget) => {
                const percentage = (budget.spent / budget.allocated) * 100
                const isOverBudget = budget.spent > budget.allocated
                
                return (
                  <div key={budget.id} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <p className="font-medium">{budget.category}</p>
                        <p className="text-sm text-muted-foreground">
                          ${budget.spent.toLocaleString()} of ${budget.allocated.toLocaleString()}
                        </p>
                      </div>
                      <Badge variant={isOverBudget ? "destructive" : "secondary"} className="text-xs">
                        {percentage.toFixed(1)}%
                      </Badge>
                    </div>
                    <Progress 
                      value={Math.min(percentage, 100)} 
                      className={`h-2 ${isOverBudget ? '[&>div]:bg-red-500' : ''}`} 
                    />
                  </div>
                )
              })}
            </CardContent>
          </Card>

          {/* Project Budget Status */}
          <Card>
            <CardHeader>
              <CardTitle>Project Budget Status</CardTitle>
              <p className="text-sm text-muted-foreground">Current project budget utilization</p>
            </CardHeader>
            <CardContent className="space-y-4">
              {projectBudgets?.map((project) => {
                const percentage = (project.spentAmount / project.totalBudget) * 100
                
                return (
                  <div key={project.id} className="space-y-3 p-4 border rounded-lg">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <p className="font-medium">{project.projectName}</p>
                        <p className="text-sm text-muted-foreground">{project.client}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Updated: {new Date(project.lastUpdated).toLocaleDateString()}
                        </p>
                      </div>
                      <Badge variant="secondary" className={statusStyles[project.status]}>
                        {project.status.replace('-', ' ')}
                      </Badge>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Budget Progress</span>
                        <span>{percentage.toFixed(1)}%</span>
                      </div>
                      <Progress value={Math.min(percentage, 100)} className="h-2" />
                      <div className="grid grid-cols-3 gap-4 text-xs">
                        <div>
                          <p className="text-muted-foreground">Total Budget</p>
                          <p className="font-medium">${project.totalBudget.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Spent</p>
                          <p className="font-medium">${project.spentAmount.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Remaining</p>
                          <p className={`font-medium ${project.remainingBudget < 0 ? 'text-red-600' : ''}`}>
                            ${Math.abs(project.remainingBudget).toLocaleString()}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                )
              })}
            </CardContent>
          </Card>
        </div>

        {/* Budget Insights */}
        <Card>
          <CardHeader>
            <CardTitle>Budget Insights & Recommendations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <div className="flex items-center gap-2 mb-2">
                  <TrendUp size={16} className="text-blue-600" />
                  <h4 className="font-medium text-blue-900">Optimization Opportunity</h4>
                </div>
                <p className="text-sm text-blue-800">
                  Equipment budget is 58% under-utilized. Consider reallocating $2,900 to marketing for Q1 campaigns.
                </p>
              </div>
              
              <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                <div className="flex items-center gap-2 mb-2">
                  <TrendUp size={16} className="text-yellow-600" />
                  <h4 className="font-medium text-yellow-900">Budget Alert</h4>
                </div>
                <p className="text-sm text-yellow-800">
                  GreenLeaf Marketing project is 8.2% over budget. Review scope or request additional funding.
                </p>
              </div>
              
              <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                <div className="flex items-center gap-2 mb-2">
                  <TrendDown size={16} className="text-green-600" />
                  <h4 className="font-medium text-green-900">Savings Achieved</h4>
                </div>
                <p className="text-sm text-green-800">
                  Training budget savings of $1,200 this month. Team utilized free online resources effectively.
                </p>
              </div>
              
              <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                <div className="flex items-center gap-2 mb-2">
                  <ChartPie size={16} className="text-purple-600" />
                  <h4 className="font-medium text-purple-900">Cash Flow Forecast</h4>
                </div>
                <p className="text-sm text-purple-800">
                  Based on current spending, monthly runway extends to 18 months with current client pipeline.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </>
  )
}