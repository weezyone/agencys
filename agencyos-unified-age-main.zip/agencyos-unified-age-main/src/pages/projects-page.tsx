import { useState, useMemo } from "react"
import { useSearchParams } from "react-router-dom"
import { useKV } from "@github/spark/hooks"
import { DashboardHeader } from "@/components/dashboard-header"
import { StatsCards } from "@/components/stats-cards"
import { RecentActivity } from "@/components/recent-activity"
import { ProjectCard, type Project } from "@/components/project-card"
import { ProjectDetailDialog } from "@/components/project-detail-dialog"
import { Button } from "@/components/ui/button"
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Folders } from "@phosphor-icons/react"

export function ProjectsPage() {
  const [searchParams] = useSearchParams()
  const [projects, setProjects] = useKV<Project[]>("agency-projects", [])
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState(searchParams.get("filter") || "all")
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [selectedProject, setSelectedProject] = useState<Project | null>(null)
  
  // New project form state
  const [newProject, setNewProject] = useState({
    name: "",
    client: "",
    description: "",
    budget: "",
    startDate: "",
    endDate: "",
    status: "planning" as Project["status"]
  })

  // Filter and search projects
  const filteredProjects = useMemo(() => {
    if (!projects) return []
    
    return projects.filter(project => {
      const matchesSearch = project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          project.client.toLowerCase().includes(searchQuery.toLowerCase())
      const matchesFilter = statusFilter === "all" || project.status === statusFilter
      
      return matchesSearch && matchesFilter
    })
  }, [projects, searchQuery, statusFilter])

  const handleCreateProject = () => {
    const project: Project = {
      id: Date.now().toString(),
      name: newProject.name,
      client: newProject.client,
      status: newProject.status,
      progress: 0,
      budget: {
        total: parseInt(newProject.budget) || 0,
        spent: 0
      },
      timeline: {
        start: newProject.startDate,
        end: newProject.endDate
      },
      team: [
        {
          id: "1",
          name: "John Doe",
          role: "Project Manager"
        }
      ]
    }

    setProjects(currentProjects => [...(currentProjects || []), project])
    setIsCreateDialogOpen(false)
    setNewProject({
      name: "",
      client: "",
      description: "",
      budget: "",
      startDate: "",
      endDate: "",
      status: "planning"
    })
  }

  return (
    <>
      <DashboardHeader
        title="Projects"
        onCreateProject={() => setIsCreateDialogOpen(true)}
        onSearch={setSearchQuery}
        onFilterChange={setStatusFilter}
      />
      
      <main className="flex-1 space-y-6 p-6 overflow-auto">
        <StatsCards />
        
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <div className="mb-4">
              <h2 className="text-xl font-semibold">Recent Projects</h2>
              <p className="text-sm text-muted-foreground">
                {filteredProjects.length} project(s) found
              </p>
            </div>
            
            {filteredProjects.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="rounded-full bg-muted p-4 mb-4">
                  <Folders size={24} className="text-muted-foreground" />
                </div>
                <h3 className="text-lg font-medium mb-2">No projects found</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  {!projects || projects.length === 0 
                    ? "Get started by creating your first project"
                    : "Try adjusting your search or filter criteria"}
                </p>
                <Button onClick={() => setIsCreateDialogOpen(true)}>
                  Create Project
                </Button>
              </div>
            ) : (
              <div className="grid gap-4 md:grid-cols-2">
                {filteredProjects.map((project) => (
                  <ProjectCard 
                    key={project.id} 
                    project={project}
                    onClick={() => setSelectedProject(project)}
                  />
                ))}
              </div>
            )}
          </div>
          
          <div>
            <RecentActivity />
          </div>
        </div>
      </main>

      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Create New Project</DialogTitle>
            <DialogDescription>
              Add a new project to your agency workspace. Fill in the basic details to get started.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="project-name">Project Name</Label>
              <Input
                id="project-name"
                value={newProject.name}
                onChange={(e) => setNewProject(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Website Redesign"
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="client-name">Client</Label>
              <Input
                id="client-name"
                value={newProject.client}
                onChange={(e) => setNewProject(prev => ({ ...prev, client: e.target.value }))}
                placeholder="Acme Corp"
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="budget">Budget</Label>
              <Input
                id="budget"
                type="number"
                value={newProject.budget}
                onChange={(e) => setNewProject(prev => ({ ...prev, budget: e.target.value }))}
                placeholder="50000"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="start-date">Start Date</Label>
                <Input
                  id="start-date"
                  type="date"
                  value={newProject.startDate}
                  onChange={(e) => setNewProject(prev => ({ ...prev, startDate: e.target.value }))}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="end-date">End Date</Label>
                <Input
                  id="end-date"
                  type="date"
                  value={newProject.endDate}
                  onChange={(e) => setNewProject(prev => ({ ...prev, endDate: e.target.value }))}
                />
              </div>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="status">Initial Status</Label>
              <Select 
                value={newProject.status}
                onValueChange={(value) => setNewProject(prev => ({ ...prev, status: value as Project["status"] }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="planning">Planning</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="review">Review</SelectItem>
                  <SelectItem value="on-hold">On Hold</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsCreateDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleCreateProject}
              disabled={!newProject.name || !newProject.client}
            >
              Create Project
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ProjectDetailDialog
        project={selectedProject}
        open={selectedProject !== null}
        onOpenChange={(open) => !open && setSelectedProject(null)}
      />
    </>
  )
}