import { useState } from "react"
import { useKV } from "@github/spark/hooks"
import { DashboardHeader } from "@/components/dashboard-header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { 
  FileText, 
  Plus, 
  CurrencyDollar,
  Calendar,
  Clock,
  Eye,
  CheckCircle,
  XCircle
} from "@phosphor-icons/react"

export interface Proposal {
  id: string
  title: string
  client: string
  description: string
  amount: number
  status: "draft" | "sent" | "viewed" | "accepted" | "rejected"
  createdDate: string
  sentDate?: string
  dueDate: string
  validUntil: string
  items: Array<{
    description: string
    quantity: number
    rate: number
    total: number
  }>
  notes?: string
}

export function ProposalsPage() {
  const [proposals, setProposals] = useKV<Proposal[]>("agency-proposals", [
    {
      id: "1",
      title: "Website Redesign & Development",
      client: "TechFlow Inc",
      description: "Complete website redesign with modern UI/UX and responsive development",
      amount: 45000,
      status: "sent",
      createdDate: "2024-01-15",
      sentDate: "2024-01-16",
      dueDate: "2024-02-15",
      validUntil: "2024-02-01",
      items: [
        { description: "UI/UX Design", quantity: 1, rate: 15000, total: 15000 },
        { description: "Frontend Development", quantity: 1, rate: 20000, total: 20000 },
        { description: "Backend Integration", quantity: 1, rate: 10000, total: 10000 }
      ]
    },
    {
      id: "2",
      title: "Brand Identity Package",
      client: "GreenLeaf Marketing",
      description: "Complete brand identity including logo, guidelines, and marketing materials",
      amount: 8500,
      status: "viewed",
      createdDate: "2024-01-20",
      sentDate: "2024-01-21",
      dueDate: "2024-02-20",
      validUntil: "2024-02-10",
      items: [
        { description: "Logo Design", quantity: 1, rate: 3500, total: 3500 },
        { description: "Brand Guidelines", quantity: 1, rate: 2500, total: 2500 },
        { description: "Marketing Materials", quantity: 1, rate: 2500, total: 2500 }
      ]
    },
    {
      id: "3",
      title: "E-commerce Platform Development",
      client: "Boutique Fashion Co",
      description: "Custom e-commerce platform with inventory management and payment processing",
      amount: 65000,
      status: "draft",
      createdDate: "2024-01-25",
      dueDate: "2024-03-15",
      validUntil: "2024-02-25",
      items: [
        { description: "Platform Development", quantity: 1, rate: 40000, total: 40000 },
        { description: "Payment Integration", quantity: 1, rate: 15000, total: 15000 },
        { description: "Admin Dashboard", quantity: 1, rate: 10000, total: 10000 }
      ]
    }
  ])

  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [newProposal, setNewProposal] = useState({
    title: "",
    client: "",
    description: "",
    amount: "",
    dueDate: "",
    validUntil: "",
    notes: ""
  })

  const handleCreateProposal = () => {
    const proposal: Proposal = {
      id: Date.now().toString(),
      title: newProposal.title,
      client: newProposal.client,
      description: newProposal.description,
      amount: parseFloat(newProposal.amount) || 0,
      status: "draft",
      createdDate: new Date().toISOString().split('T')[0],
      dueDate: newProposal.dueDate,
      validUntil: newProposal.validUntil,
      items: [],
      notes: newProposal.notes
    }

    setProposals(current => [...(current || []), proposal])
    setIsCreateDialogOpen(false)
    setNewProposal({
      title: "",
      client: "",
      description: "",
      amount: "",
      dueDate: "",
      validUntil: "",
      notes: ""
    })
  }

  const totalProposalValue = proposals?.reduce((sum, proposal) => sum + proposal.amount, 0) || 0
  const sentProposals = proposals?.filter(p => ["sent", "viewed", "accepted"].includes(p.status)) || []
  const acceptedProposals = proposals?.filter(p => p.status === "accepted") || []
  const winRate = sentProposals.length > 0 ? (acceptedProposals.length / sentProposals.length) * 100 : 0

  const statusStyles = {
    draft: "bg-gray-100 text-gray-800",
    sent: "bg-blue-100 text-blue-800", 
    viewed: "bg-yellow-100 text-yellow-800",
    accepted: "bg-green-100 text-green-800",
    rejected: "bg-red-100 text-red-800"
  }

  const statusIcons = {
    draft: FileText,
    sent: Clock,
    viewed: Eye,
    accepted: CheckCircle,
    rejected: XCircle
  }

  return (
    <>
      <DashboardHeader
        title="Proposals"
        onCreateProject={() => setIsCreateDialogOpen(true)}
        customActionText="New Proposal"
        customActionIcon={<Plus size={16} />}
      />
      
      <main className="flex-1 space-y-6 p-6 overflow-auto">
        {/* Proposal Overview Stats */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Proposals</CardTitle>
              <FileText size={16} className="text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{proposals?.length || 0}</div>
              <p className="text-xs text-muted-foreground">
                {sentProposals.length} sent out
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Value</CardTitle>
              <CurrencyDollar size={16} className="text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${totalProposalValue.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                in pending proposals
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Win Rate</CardTitle>
              <CheckCircle size={16} className="text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{winRate.toFixed(1)}%</div>
              <p className="text-xs text-muted-foreground">
                {acceptedProposals.length} accepted
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Avg. Proposal Value</CardTitle>
              <CurrencyDollar size={16} className="text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                ${proposals?.length ? Math.round(totalProposalValue / proposals.length).toLocaleString() : 0}
              </div>
              <p className="text-xs text-muted-foreground">
                average amount
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Proposals List */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xl font-semibold">All Proposals</h2>
              <p className="text-sm text-muted-foreground">
                Track and manage your project proposals
              </p>
            </div>
          </div>
          
          <div className="grid gap-4">
            {proposals?.map((proposal) => {
              const StatusIcon = statusIcons[proposal.status]
              const isOverdue = new Date(proposal.validUntil) < new Date() && proposal.status === "sent"
              
              return (
                <Card key={proposal.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <CardTitle className="text-lg font-semibold">
                            {proposal.title}
                          </CardTitle>
                          <Badge variant="secondary" className={statusStyles[proposal.status]}>
                            <StatusIcon size={12} className="mr-1" />
                            {proposal.status}
                          </Badge>
                          {isOverdue && (
                            <Badge variant="destructive" className="text-xs">
                              Expired
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground mb-1">{proposal.client}</p>
                        <p className="text-sm">{proposal.description}</p>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold">${proposal.amount.toLocaleString()}</div>
                        <p className="text-xs text-muted-foreground">Total Value</p>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div className="flex items-center gap-2">
                        <Calendar size={14} className="text-muted-foreground" />
                        <div>
                          <p className="font-medium">Created</p>
                          <p className="text-muted-foreground">{new Date(proposal.createdDate).toLocaleDateString()}</p>
                        </div>
                      </div>
                      
                      {proposal.sentDate && (
                        <div className="flex items-center gap-2">
                          <Clock size={14} className="text-muted-foreground" />
                          <div>
                            <p className="font-medium">Sent</p>
                            <p className="text-muted-foreground">{new Date(proposal.sentDate).toLocaleDateString()}</p>
                          </div>
                        </div>
                      )}
                      
                      <div className="flex items-center gap-2">
                        <Calendar size={14} className="text-muted-foreground" />
                        <div>
                          <p className="font-medium">Due Date</p>
                          <p className="text-muted-foreground">{new Date(proposal.dueDate).toLocaleDateString()}</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Clock size={14} className="text-muted-foreground" />
                        <div>
                          <p className="font-medium">Valid Until</p>
                          <p className={`${isOverdue ? 'text-red-600' : 'text-muted-foreground'}`}>
                            {new Date(proposal.validUntil).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex justify-end gap-2 mt-4">
                      <Button variant="outline" size="sm">
                        Edit
                      </Button>
                      <Button variant="outline" size="sm">
                        View Details
                      </Button>
                      {proposal.status === "draft" && (
                        <Button size="sm">
                          Send Proposal
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </main>

      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Create New Proposal</DialogTitle>
            <DialogDescription>
              Create a new project proposal for a client. You can add detailed line items later.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="proposal-title">Proposal Title</Label>
              <Input
                id="proposal-title"
                value={newProposal.title}
                onChange={(e) => setNewProposal(prev => ({ ...prev, title: e.target.value }))}
                placeholder="Website Redesign & Development"
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="proposal-client">Client</Label>
              <Input
                id="proposal-client"
                value={newProposal.client}
                onChange={(e) => setNewProposal(prev => ({ ...prev, client: e.target.value }))}
                placeholder="TechFlow Inc"
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="proposal-description">Description</Label>
              <Textarea
                id="proposal-description"
                value={newProposal.description}
                onChange={(e) => setNewProposal(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Brief description of the project scope..."
                rows={3}
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="proposal-amount">Total Amount ($)</Label>
              <Input
                id="proposal-amount"
                type="number"
                value={newProposal.amount}
                onChange={(e) => setNewProposal(prev => ({ ...prev, amount: e.target.value }))}
                placeholder="45000"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="proposal-due-date">Due Date</Label>
                <Input
                  id="proposal-due-date"
                  type="date"
                  value={newProposal.dueDate}
                  onChange={(e) => setNewProposal(prev => ({ ...prev, dueDate: e.target.value }))}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="proposal-valid-until">Valid Until</Label>
                <Input
                  id="proposal-valid-until"
                  type="date"
                  value={newProposal.validUntil}
                  onChange={(e) => setNewProposal(prev => ({ ...prev, validUntil: e.target.value }))}
                />
              </div>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="proposal-notes">Notes (Optional)</Label>
              <Textarea
                id="proposal-notes"
                value={newProposal.notes}
                onChange={(e) => setNewProposal(prev => ({ ...prev, notes: e.target.value }))}
                placeholder="Any additional notes or terms..."
                rows={2}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsCreateDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleCreateProposal}
              disabled={!newProposal.title || !newProposal.client || !newProposal.amount}
            >
              Create Proposal
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}