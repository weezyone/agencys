export interface TimeEntry {
  id: string
  userId: string
  userName: string
  projectId: string
  projectName: string
  taskId?: string
  taskName?: string
  date: string
  hours: number
  description: string
  billable: boolean
  status: "draft" | "submitted" | "approved" | "rejected"
  approvedBy?: string
  approvedAt?: string
  hourlyRate?: number
  tags?: string[]
}

export interface Project {
  id: string
  name: string
  client: string
  status: "planning" | "active" | "review" | "on-hold" | "completed"
  progress: number
  budget: {
    total: number
    spent: number
  }
  timeline: {
    start: string
    end: string
  }
  team: TeamMember[]
}

export interface TeamMember {
  id: string
  name: string
  role: string
  avatar?: string
}

export interface UtilizationMetrics {
  userId: string
  userName: string
  totalHours: number
  billableHours: number
  nonBillableHours: number
  utilizationRate: number
  targetHours: number
  capacity: number
}
