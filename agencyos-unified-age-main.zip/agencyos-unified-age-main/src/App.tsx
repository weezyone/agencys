import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import { SidebarProvider } from "@/components/ui/sidebar"
import { AppLayout } from "@/components/app-layout"
import { ProjectsPage } from "@/pages/projects-page"
import { TeamPage } from "@/pages/team-page"
import { ClientsPage } from "@/pages/clients-page"
import { ProposalsPage } from "@/pages/proposals-page"
import { BudgetsPage } from "@/pages/budgets-page"
import { ReportsPage } from "@/pages/reports-page"
import { CalendarPage } from "@/pages/calendar-page"
import { SettingsPage } from "@/pages/settings-page"
import { TimeTrackingPage } from "@/pages/time-tracking-page"
import { AIAgentsPage } from "@/pages/ai-agents-page"

function App() {
  return (
    <Router>
      <SidebarProvider>
        <AppLayout>
          <Routes>
            <Route path="/" element={<ProjectsPage />} />
            <Route path="/projects" element={<ProjectsPage />} />
            <Route path="/team" element={<TeamPage />} />
            <Route path="/clients" element={<ClientsPage />} />
            <Route path="/proposals" element={<ProposalsPage />} />
            <Route path="/budgets" element={<BudgetsPage />} />
            <Route path="/reports" element={<ReportsPage />} />
            <Route path="/calendar" element={<CalendarPage />} />
            <Route path="/time-tracking" element={<TimeTrackingPage />} />
            <Route path="/ai-agents" element={<AIAgentsPage />} />
            <Route path="/settings" element={<SettingsPage />} />
          </Routes>
        </AppLayout>
      </SidebarProvider>
    </Router>
  )
}

export default App