import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { CheckCircle, Clock, XCircle, Robot } from "@phosphor-icons/react"
import type { Agent } from "@/pages/ai-agents-page"

interface ActivityItem {
  id: string
  agentId: string
  agentName: string
  action: string
  status: "success" | "pending" | "failed"
  timestamp: Date
}

interface AgentActivityLogProps {
  agents: Agent[]
}

const mockActivities: ActivityItem[] = [
  {
    id: "1",
    agentId: "agent-1",
    agentName: "Content Writer Agent",
    action: "Generated blog post: 'Top 10 Design Trends for 2024'",
    status: "success",
    timestamp: new Date(Date.now() - 1000 * 60 * 15)
  },
  {
    id: "2",
    agentId: "agent-2",
    agentName: "Proposal Generator",
    action: "Created proposal for Acme Corp website redesign",
    status: "success",
    timestamp: new Date(Date.now() - 1000 * 60 * 45)
  },
  {
    id: "3",
    agentId: "agent-3",
    agentName: "Report Analyzer",
    action: "Analyzing Q4 project metrics",
    status: "pending",
    timestamp: new Date(Date.now() - 1000 * 60 * 5)
  },
  {
    id: "4",
    agentId: "agent-4",
    agentName: "Code Reviewer",
    action: "Reviewed pull request #234",
    status: "success",
    timestamp: new Date(Date.now() - 1000 * 60 * 120)
  },
  {
    id: "5",
    agentId: "agent-5",
    agentName: "Meeting Scheduler",
    action: "Failed to schedule meeting - no available slots",
    status: "failed",
    timestamp: new Date(Date.now() - 1000 * 60 * 30)
  }
]

export function AgentActivityLog({ agents }: AgentActivityLogProps) {
  const getStatusIcon = (status: ActivityItem["status"]) => {
    switch (status) {
      case "success":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "pending":
        return <Clock className="h-4 w-4 text-yellow-500" />
      case "failed":
        return <XCircle className="h-4 w-4 text-red-500" />
    }
  }

  const getStatusBadge = (status: ActivityItem["status"]) => {
    const variants: Record<ActivityItem["status"], "default" | "secondary" | "destructive"> = {
      success: "default",
      pending: "secondary",
      failed: "destructive"
    }
    return (
      <Badge variant={variants[status]}>
        {status}
      </Badge>
    )
  }

  const formatTime = (date: Date) => {
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffMins = Math.floor(diffMs / 60000)
    
    if (diffMins < 1) return "Just now"
    if (diffMins < 60) return `${diffMins}m ago`
    
    const diffHours = Math.floor(diffMins / 60)
    if (diffHours < 24) return `${diffHours}h ago`
    
    const diffDays = Math.floor(diffHours / 24)
    return `${diffDays}d ago`
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Robot className="h-5 w-5" />
          Activity Log
        </CardTitle>
        <CardDescription>
          Recent actions performed by your AI agents
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[500px] pr-4">
          {mockActivities.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Robot className="mb-4 h-12 w-12 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">
                No activity yet. Your agents will log their actions here.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {mockActivities.map((activity) => (
                <div
                  key={activity.id}
                  className="flex items-start gap-4 rounded-lg border p-4 transition-colors hover:bg-muted/50"
                >
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                    {getStatusIcon(activity.status)}
                  </div>
                  <div className="flex-1 space-y-1">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="text-sm font-medium">{activity.agentName}</p>
                        <p className="text-sm text-muted-foreground">
                          {activity.action}
                        </p>
                      </div>
                      {getStatusBadge(activity.status)}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {formatTime(activity.timestamp)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
