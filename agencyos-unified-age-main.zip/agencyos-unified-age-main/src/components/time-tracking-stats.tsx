import { useMemo } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Clock, CurrencyDollar, CheckCircle, TrendUp } from "@phosphor-icons/react"
import type { TimeEntry } from "@/lib/types"

interface TimeTrackingStatsProps {
  entries: TimeEntry[]
}

export function TimeTrackingStats({ entries }: TimeTrackingStatsProps) {
  const stats = useMemo(() => {
    const now = new Date()
    const currentMonth = now.getMonth()
    const currentYear = now.getFullYear()
    
    const thisMonthEntries = entries.filter(entry => {
      const entryDate = new Date(entry.date)
      return entryDate.getMonth() === currentMonth && entryDate.getFullYear() === currentYear
    })
    
    const totalHours = thisMonthEntries.reduce((sum, entry) => sum + entry.hours, 0)
    const billableHours = thisMonthEntries.filter(e => e.billable).reduce((sum, entry) => sum + entry.hours, 0)
    const approvedHours = thisMonthEntries.filter(e => e.status === "approved").reduce((sum, entry) => sum + entry.hours, 0)
    
    const totalRevenue = thisMonthEntries
      .filter(e => e.billable && e.hourlyRate)
      .reduce((sum, entry) => sum + (entry.hours * (entry.hourlyRate || 0)), 0)
    
    const billableRate = totalHours > 0 ? (billableHours / totalHours) * 100 : 0
    
    return {
      totalHours: totalHours.toFixed(1),
      billableHours: billableHours.toFixed(1),
      approvedHours: approvedHours.toFixed(1),
      totalRevenue: totalRevenue.toFixed(2),
      billableRate: billableRate.toFixed(1),
    }
  }, [entries])

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Hours (Month)</CardTitle>
          <Clock size={16} className="text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{stats.totalHours}</div>
          <p className="text-xs text-muted-foreground">
            {stats.billableHours} billable hours
          </p>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Billable Rate</CardTitle>
          <TrendUp size={16} className="text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{stats.billableRate}%</div>
          <p className="text-xs text-muted-foreground">
            of total time tracked
          </p>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Approved Hours</CardTitle>
          <CheckCircle size={16} className="text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{stats.approvedHours}</div>
          <p className="text-xs text-muted-foreground">
            ready for billing
          </p>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
          <CurrencyDollar size={16} className="text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">${stats.totalRevenue}</div>
          <p className="text-xs text-muted-foreground">
            from tracked time
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
