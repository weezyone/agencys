import { useState, useEffect } from "react"
import { useKV } from "@github/spark/hooks"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import type { TimeEntry, Project } from "@/lib/types"
import type { TeamMember } from "@/pages/team-page"

interface TimeEntryFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSubmit: (entry: Omit<TimeEntry, "id">) => void
  entry?: TimeEntry
}

export function TimeEntryForm({ open, onOpenChange, onSubmit, entry }: TimeEntryFormProps) {
  const [projects] = useKV<Project[]>("agency-projects", [])
  const [teamMembers] = useKV<TeamMember[]>("agency-team-members", [])
  
  const [formData, setFormData] = useState({
    userId: "",
    userName: "",
    projectId: "",
    projectName: "",
    taskName: "",
    date: new Date().toISOString().split("T")[0],
    hours: "",
    description: "",
    billable: true,
    status: "draft" as TimeEntry["status"],
  })

  useEffect(() => {
    if (entry) {
      setFormData({
        userId: entry.userId,
        userName: entry.userName,
        projectId: entry.projectId,
        projectName: entry.projectName,
        taskName: entry.taskName || "",
        date: entry.date,
        hours: entry.hours.toString(),
        description: entry.description,
        billable: entry.billable,
        status: entry.status,
      })
    } else {
      setFormData({
        userId: teamMembers?.[0]?.id || "",
        userName: teamMembers?.[0]?.name || "",
        projectId: "",
        projectName: "",
        taskName: "",
        date: new Date().toISOString().split("T")[0],
        hours: "",
        description: "",
        billable: true,
        status: "draft",
      })
    }
  }, [entry, teamMembers, open])

  const handleSubmit = () => {
    const selectedProject = projects?.find(p => p.id === formData.projectId)
    const selectedMember = teamMembers?.find(m => m.id === formData.userId)
    
    onSubmit({
      userId: formData.userId,
      userName: selectedMember?.name || formData.userName,
      projectId: formData.projectId,
      projectName: selectedProject?.name || formData.projectName,
      taskName: formData.taskName || undefined,
      date: formData.date,
      hours: parseFloat(formData.hours),
      description: formData.description,
      billable: formData.billable,
      status: formData.status,
      hourlyRate: selectedMember?.hourlyRate,
    })
    
    onOpenChange(false)
  }

  const isValid = formData.userId && formData.projectId && formData.hours && parseFloat(formData.hours) > 0

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{entry ? "Edit Time Entry" : "Log Time Entry"}</DialogTitle>
          <DialogDescription>
            Track time spent on project tasks for accurate billing and productivity monitoring.
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="team-member">Team Member</Label>
            <Select 
              value={formData.userId}
              onValueChange={(value) => {
                const member = teamMembers?.find(m => m.id === value)
                setFormData(prev => ({ 
                  ...prev, 
                  userId: value,
                  userName: member?.name || ""
                }))
              }}
            >
              <SelectTrigger id="team-member">
                <SelectValue placeholder="Select team member..." />
              </SelectTrigger>
              <SelectContent>
                {teamMembers?.map((member) => (
                  <SelectItem key={member.id} value={member.id}>
                    {member.name} - {member.role}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="grid gap-2">
            <Label htmlFor="project">Project</Label>
            <Select 
              value={formData.projectId}
              onValueChange={(value) => {
                const project = projects?.find(p => p.id === value)
                setFormData(prev => ({ 
                  ...prev, 
                  projectId: value,
                  projectName: project?.name || ""
                }))
              }}
            >
              <SelectTrigger id="project">
                <SelectValue placeholder="Select project..." />
              </SelectTrigger>
              <SelectContent>
                {projects?.filter(p => p.status === "active" || p.status === "planning")
                  .map((project) => (
                    <SelectItem key={project.id} value={project.id}>
                      {project.name} - {project.client}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="grid gap-2">
            <Label htmlFor="task-name">Task (Optional)</Label>
            <Input
              id="task-name"
              value={formData.taskName}
              onChange={(e) => setFormData(prev => ({ ...prev, taskName: e.target.value }))}
              placeholder="e.g., Homepage design, API development"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="date">Date</Label>
              <Input
                id="date"
                type="date"
                value={formData.date}
                onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="hours">Hours</Label>
              <Input
                id="hours"
                type="number"
                step="0.25"
                min="0"
                value={formData.hours}
                onChange={(e) => setFormData(prev => ({ ...prev, hours: e.target.value }))}
                placeholder="8.0"
              />
            </div>
          </div>
          
          <div className="grid gap-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Describe the work performed..."
              rows={3}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="billable">Billable</Label>
              <p className="text-xs text-muted-foreground">
                Mark if this time should be billed to client
              </p>
            </div>
            <Switch
              id="billable"
              checked={formData.billable}
              onCheckedChange={(checked) => setFormData(prev => ({ ...prev, billable: checked }))}
            />
          </div>
        </div>
        
        <DialogFooter>
          <Button 
            variant="outline" 
            onClick={() => onOpenChange(false)}
          >
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit}
            disabled={!isValid}
          >
            {entry ? "Update Entry" : "Log Time"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
