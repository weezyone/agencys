import { useMemo } from "react"
import { useKV } from "@github/spark/hooks"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import type { TimeEntry, UtilizationMetrics } from "@/lib/types"
import type { TeamMember } from "@/pages/team-page"

interface TeamUtilizationPanelProps {
  entries: TimeEntry[]
}

export function TeamUtilizationPanel({ entries }: TeamUtilizationPanelProps) {
  const [teamMembers] = useKV<TeamMember[]>("agency-team-members", [])
  
  const utilizationMetrics = useMemo(() => {
    const now = new Date()
    const currentMonth = now.getMonth()
    const currentYear = now.getFullYear()
    
    const thisMonthEntries = entries.filter(entry => {
      const entryDate = new Date(entry.date)
      return entryDate.getMonth() === currentMonth && entryDate.getFullYear() === currentYear
    })
    
    const memberMetrics: UtilizationMetrics[] = (teamMembers || []).map(member => {
      const memberEntries = thisMonthEntries.filter(entry => entry.userId === member.id)
      const totalHours = memberEntries.reduce((sum, entry) => sum + entry.hours, 0)
      const billableHours = memberEntries.filter(e => e.billable).reduce((sum, entry) => sum + entry.hours, 0)
      const nonBillableHours = totalHours - billableHours
      
      const workingDaysInMonth = 22
      const hoursPerDay = 8
      const targetHours = workingDaysInMonth * hoursPerDay
      const utilizationRate = targetHours > 0 ? (billableHours / targetHours) * 100 : 0
      const capacity = targetHours > 0 ? (totalHours / targetHours) * 100 : 0
      
      return {
        userId: member.id,
        userName: member.name,
        totalHours,
        billableHours,
        nonBillableHours,
        utilizationRate,
        targetHours,
        capacity,
      }
    })
    
    return memberMetrics.sort((a, b) => b.totalHours - a.totalHours)
  }, [entries, teamMembers])

  const getUtilizationColor = (rate: number) => {
    if (rate >= 80) return "text-success"
    if (rate >= 60) return "text-warning"
    return "text-destructive"
  }

  const getUtilizationBadge = (rate: number) => {
    if (rate >= 80) return <Badge className="bg-success text-success-foreground">Excellent</Badge>
    if (rate >= 60) return <Badge className="bg-warning text-warning-foreground">Good</Badge>
    return <Badge variant="outline">Below Target</Badge>
  }

  const overallMetrics = useMemo(() => {
    const total = utilizationMetrics.reduce(
      (acc, m) => ({
        totalHours: acc.totalHours + m.totalHours,
        billableHours: acc.billableHours + m.billableHours,
        targetHours: acc.targetHours + m.targetHours,
      }),
      { totalHours: 0, billableHours: 0, targetHours: 0 }
    )
    
    const avgUtilization = total.targetHours > 0
      ? (total.billableHours / total.targetHours) * 100
      : 0
    
    return {
      ...total,
      avgUtilization,
    }
  }, [utilizationMetrics])

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Team Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div>
              <p className="text-sm text-muted-foreground">Total Hours Logged</p>
              <p className="text-2xl font-bold">{overallMetrics.totalHours.toFixed(1)}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Billable Hours</p>
              <p className="text-2xl font-bold">{overallMetrics.billableHours.toFixed(1)}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Avg Utilization</p>
              <p className={`text-2xl font-bold ${getUtilizationColor(overallMetrics.avgUtilization)}`}>
                {overallMetrics.avgUtilization.toFixed(1)}%
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        <div>
          <h3 className="text-lg font-semibold mb-2">Individual Utilization</h3>
          <p className="text-sm text-muted-foreground">
            Monthly target: 176 hours (22 working days × 8 hours)
          </p>
        </div>
        
        <div className="grid gap-4">
          {utilizationMetrics.map((metric) => {
            const member = teamMembers?.find(m => m.id === metric.userId)
            
            return (
              <Card key={metric.userId}>
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={member?.avatar} alt={metric.userName} />
                      <AvatarFallback>
                        {metric.userName.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="flex-1 space-y-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-semibold">{metric.userName}</h4>
                          <p className="text-sm text-muted-foreground">{member?.role}</p>
                        </div>
                        {getUtilizationBadge(metric.utilizationRate)}
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Billable Utilization</span>
                          <span className={`font-medium ${getUtilizationColor(metric.utilizationRate)}`}>
                            {metric.utilizationRate.toFixed(1)}%
                          </span>
                        </div>
                        <Progress value={metric.utilizationRate} className="h-2" />
                      </div>
                      
                      <div className="grid grid-cols-3 gap-4 pt-2 border-t text-sm">
                        <div>
                          <p className="text-muted-foreground">Total Hours</p>
                          <p className="font-medium">{metric.totalHours.toFixed(1)}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Billable</p>
                          <p className="font-medium">{metric.billableHours.toFixed(1)}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Non-Billable</p>
                          <p className="font-medium">{metric.nonBillableHours.toFixed(1)}</p>
                        </div>
                      </div>
                      
                      {member?.hourlyRate && (
                        <div className="pt-2 border-t">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">Est. Revenue (Billable)</span>
                            <span className="font-semibold">
                              ${(metric.billableHours * member.hourlyRate).toFixed(2)}
                            </span>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
        
        {utilizationMetrics.length === 0 && (
          <Card>
            <CardContent className="py-8 text-center text-muted-foreground">
              No team members found. Add team members to track utilization.
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
