import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Clock, CheckCircle, Warning, Upload } from "@phosphor-icons/react"

interface ActivityItem {
  id: string
  type: "milestone" | "upload" | "review" | "approval"
  title: string
  description: string
  user: string
  avatar?: string
  timestamp: string
  project: string
}

const activities: ActivityItem[] = [
  {
    id: "1",
    type: "approval",
    title: "Design Phase Approved",
    description: "Client approved final wireframes and design mockups",
    user: "Sarah Chen",
    timestamp: "2 hours ago",
    project: "E-commerce Website Redesign"
  },
  {
    id: "2", 
    type: "upload",
    title: "New Assets Uploaded",
    description: "Brand assets and logo variations added to project files",
    user: "Marcus Johnson",
    timestamp: "4 hours ago",
    project: "Brand Identity System"
  },
  {
    id: "3",
    type: "milestone",
    title: "Development Sprint Started",
    description: "Frontend development phase kicked off",
    user: "Elena Rodriguez", 
    timestamp: "6 hours ago",
    project: "Mobile App Development"
  },
  {
    id: "4",
    type: "review",
    title: "QA Review Completed",
    description: "Quality assurance testing phase completed with minor issues",
    user: "David Kim",
    timestamp: "1 day ago",
    project: "Data Analytics Dashboard"
  }
]

const activityIcons = {
  milestone: CheckCircle,
  upload: Upload,
  review: Warning,
  approval: CheckCircle
}

const activityColors = {
  milestone: "text-green-600",
  upload: "text-blue-600", 
  review: "text-yellow-600",
  approval: "text-green-600"
}

export function RecentActivity() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock size={20} />
          Recent Activity
        </CardTitle>
        <CardDescription>
          Latest updates from your projects
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity) => {
            const Icon = activityIcons[activity.type]
            
            return (
              <div key={activity.id} className="flex gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                <Icon size={16} className={`mt-1 ${activityColors[activity.type]}`} />
                
                <div className="flex-1 space-y-1">
                  <div className="flex items-start justify-between">
                    <h4 className="text-sm font-medium">{activity.title}</h4>
                    <span className="text-xs text-muted-foreground">{activity.timestamp}</span>
                  </div>
                  
                  <p className="text-xs text-muted-foreground">{activity.description}</p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Avatar className="h-5 w-5">
                        <AvatarImage src={activity.avatar} alt={activity.user} />
                        <AvatarFallback className="text-xs">
                          {activity.user.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-xs text-muted-foreground">{activity.user}</span>
                    </div>
                    
                    <Badge variant="secondary" className="text-xs">
                      {activity.project}
                    </Badge>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}