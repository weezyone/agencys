import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import type { Agent, AgentType } from "@/pages/ai-agents-page"

interface AgentConfigDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  agent: Omit<Agent, "id" | "status" | "tasksCompleted">
  onSave: (config: Record<string, any>) => void
}

export function AgentConfigDialog({ open, onOpenChange, agent, onSave }: AgentConfigDialogProps) {
  const [config, setConfig] = useState(agent.config || {})

  const handleSave = () => {
    onSave(config)
  }

  const renderConfigFields = () => {
    switch (agent.type) {
      case "content-writer":
        return (
          <>
            <div className="space-y-2">
              <Label>Tone</Label>
              <Select
                value={config.tone || "professional"}
                onValueChange={(value) => setConfig({ ...config, tone: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="professional">Professional</SelectItem>
                  <SelectItem value="casual">Casual</SelectItem>
                  <SelectItem value="friendly">Friendly</SelectItem>
                  <SelectItem value="formal">Formal</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Creativity Level: {config.creativity || 0.7}</Label>
              <Slider
                value={[config.creativity || 0.7]}
                onValueChange={([value]) => setConfig({ ...config, creativity: value })}
                min={0}
                max={1}
                step={0.1}
              />
            </div>
            <div className="space-y-2">
              <Label>Brand Voice</Label>
              <Textarea
                placeholder="Describe your brand voice..."
                value={config.brandVoice || ""}
                onChange={(e) => setConfig({ ...config, brandVoice: e.target.value })}
              />
            </div>
          </>
        )
      
      case "proposal-generator":
        return (
          <>
            <div className="flex items-center justify-between space-x-2">
              <Label>Include Timeline</Label>
              <Switch
                checked={config.includeTimeline !== false}
                onCheckedChange={(checked) => setConfig({ ...config, includeTimeline: checked })}
              />
            </div>
            <div className="flex items-center justify-between space-x-2">
              <Label>Include Budget Breakdown</Label>
              <Switch
                checked={config.includeBudget !== false}
                onCheckedChange={(checked) => setConfig({ ...config, includeBudget: checked })}
              />
            </div>
            <div className="space-y-2">
              <Label>Default Terms (days)</Label>
              <Input
                type="number"
                value={config.paymentTerms || 30}
                onChange={(e) => setConfig({ ...config, paymentTerms: parseInt(e.target.value) })}
              />
            </div>
          </>
        )
      
      case "report-analyzer":
        return (
          <>
            <div className="space-y-2">
              <Label>Frequency</Label>
              <Select
                value={config.frequency || "weekly"}
                onValueChange={(value) => setConfig({ ...config, frequency: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Include Metrics</Label>
              <div className="space-y-2">
                {["budget", "timeline", "utilization", "revenue"].map((metric) => (
                  <div key={metric} className="flex items-center space-x-2">
                    <Switch
                      checked={config.metrics?.includes(metric) || false}
                      onCheckedChange={(checked) => {
                        const metrics = config.metrics || []
                        setConfig({
                          ...config,
                          metrics: checked
                            ? [...metrics, metric]
                            : metrics.filter((m: string) => m !== metric)
                        })
                      }}
                    />
                    <Label className="capitalize">{metric}</Label>
                  </div>
                ))}
              </div>
            </div>
          </>
        )
      
      case "code-reviewer":
        return (
          <>
            <div className="space-y-2">
              <Label>Languages</Label>
              <div className="space-y-2">
                {["typescript", "javascript", "react", "python", "css"].map((lang) => (
                  <div key={lang} className="flex items-center space-x-2">
                    <Switch
                      checked={config.languages?.includes(lang) || false}
                      onCheckedChange={(checked) => {
                        const languages = config.languages || []
                        setConfig({
                          ...config,
                          languages: checked
                            ? [...languages, lang]
                            : languages.filter((l: string) => l !== lang)
                        })
                      }}
                    />
                    <Label className="capitalize">{lang}</Label>
                  </div>
                ))}
              </div>
            </div>
            <div className="space-y-2">
              <Label>Severity Level</Label>
              <Select
                value={config.severity || "medium"}
                onValueChange={(value) => setConfig({ ...config, severity: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </>
        )
      
      case "meeting-scheduler":
        return (
          <>
            <div className="space-y-2">
              <Label>Buffer Time (minutes)</Label>
              <Input
                type="number"
                value={config.bufferTime || 15}
                onChange={(e) => setConfig({ ...config, bufferTime: parseInt(e.target.value) })}
              />
            </div>
            <div className="space-y-2">
              <Label>Preferred Times</Label>
              <div className="space-y-2">
                {["morning", "early-afternoon", "late-afternoon"].map((time) => (
                  <div key={time} className="flex items-center space-x-2">
                    <Switch
                      checked={config.preferredTimes?.includes(time) || false}
                      onCheckedChange={(checked) => {
                        const times = config.preferredTimes || []
                        setConfig({
                          ...config,
                          preferredTimes: checked
                            ? [...times, time]
                            : times.filter((t: string) => t !== time)
                        })
                      }}
                    />
                    <Label className="capitalize">{time.replace("-", " ")}</Label>
                  </div>
                ))}
              </div>
            </div>
          </>
        )
      
      case "project-assistant":
        return (
          <>
            <div className="space-y-2">
              <Label>Reminder Frequency</Label>
              <Select
                value={config.reminderFrequency || "daily"}
                onValueChange={(value) => setConfig({ ...config, reminderFrequency: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="hourly">Hourly</SelectItem>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center justify-between space-x-2">
              <Label>Track Milestones</Label>
              <Switch
                checked={config.trackMilestones !== false}
                onCheckedChange={(checked) => setConfig({ ...config, trackMilestones: checked })}
              />
            </div>
          </>
        )
      
      default:
        return null
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Configure {agent.name}</DialogTitle>
          <DialogDescription>
            Customize the agent settings to match your workflow
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          {renderConfigFields()}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            Create Agent
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
