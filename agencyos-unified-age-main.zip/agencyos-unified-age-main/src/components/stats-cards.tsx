import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { 
  Folders, 
  Clock, 
  CurrencyDollar, 
  TrendUp,
  TrendDown,
  Users
} from "@phosphor-icons/react"

interface StatCardProps {
  title: string
  value: string | number
  change?: {
    value: number
    type: "increase" | "decrease"
  }
  icon: React.ElementType
  description?: string
}

function StatCard({ title, value, change, icon: Icon, description }: StatCardProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon size={16} className="text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <div className="flex items-center gap-2 mt-1">
          {change && (
            <Badge 
              variant="secondary" 
              className={`gap-1 ${
                change.type === "increase" 
                  ? "text-green-700 bg-green-50" 
                  : "text-red-700 bg-red-50"
              }`}
            >
              {change.type === "increase" ? (
                <TrendUp size={12} />
              ) : (
                <TrendDown size={12} />
              )}
              {Math.abs(change.value)}%
            </Badge>
          )}
          {description && (
            <p className="text-xs text-muted-foreground">{description}</p>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

export function StatsCards() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <StatCard
        title="Active Projects"
        value={12}
        change={{ value: 20, type: "increase" }}
        icon={Folders}
        description="from last month"
      />
      <StatCard
        title="Revenue (MTD)"
        value="$47,250"
        change={{ value: 8, type: "increase" }}
        icon={CurrencyDollar}
        description="from last month"
      />
      <StatCard
        title="Team Utilization"
        value="87%"
        change={{ value: 3, type: "decrease" }}
        icon={Users}
        description="this month"
      />
      <StatCard
        title="Avg. Project Duration"
        value="6.2 weeks"
        icon={Clock}
        description="current average"
      />
    </div>
  )
}