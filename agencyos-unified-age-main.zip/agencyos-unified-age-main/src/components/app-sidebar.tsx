import { 
  Folders, 
  Users, 
  Clock, 
  CurrencyDollar, 
  FileText, 
  Gear,
  ChartBar,
  Calendar,
  ChatCircle,
  Archive,
  Timer,
  Robot
} from "@phosphor-icons/react"
import { Link, useLocation } from "react-router-dom"
import { 
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail
} from "@/components/ui/sidebar"

const navigationItems = [
  {
    title: "Projects",
    items: [
      { title: "All Projects", icon: Folders, url: "/projects" },
      { title: "Active Sprints", icon: Clock, url: "/projects?filter=active" },
      { title: "Reviews", icon: ChatCircle, url: "/projects?filter=review" },
    ]
  },
  {
    title: "Business",
    items: [
      { title: "Proposals", icon: FileText, url: "/proposals" },
      { title: "Budgets", icon: CurrencyDollar, url: "/budgets" },
      { title: "Time Tracking", icon: Timer, url: "/time-tracking" },
      { title: "Reports", icon: ChartBar, url: "/reports" },
      { title: "Calendar", icon: Calendar, url: "/calendar" },
    ]
  },
  {
    title: "Automation",
    items: [
      { title: "AI Agents", icon: Robot, url: "/ai-agents" },
    ]
  },
  {
    title: "Team",
    items: [
      { title: "Members", icon: Users, url: "/team" },
      { title: "Clients", icon: Users, url: "/clients" },
      { title: "Archives", icon: Archive, url: "/projects?filter=completed" },
    ]
  }
]

export function AppSidebar() {
  const location = useLocation()
  
  return (
    <Sidebar>
      <SidebarHeader className="border-b border-border p-4">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
            <Folders size={16} />
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-semibold">AgencyOS</span>
            <span className="text-xs text-muted-foreground">Digital Studio</span>
          </div>
        </div>
      </SidebarHeader>
      
      <SidebarContent>
        {navigationItems.map((group) => (
          <SidebarGroup key={group.title}>
            <SidebarGroupLabel>{group.title}</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {group.items.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild isActive={location.pathname === item.url.split('?')[0]}>
                      <Link to={item.url} className="flex items-center gap-2">
                        <item.icon size={16} />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}
        
        <SidebarGroup className="mt-auto">
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton asChild isActive={location.pathname === "/settings"}>
                  <Link to="/settings" className="flex items-center gap-2">
                    <Gear size={16} />
                    <span>Settings</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarRail />
    </Sidebar>
  )
}