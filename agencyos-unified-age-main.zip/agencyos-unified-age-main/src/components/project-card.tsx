import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Clock, CurrencyDollar, Users } from "@phosphor-icons/react"

export interface Project {
  id: string
  name: string
  client: string
  status: "planning" | "active" | "review" | "completed" | "on-hold"
  progress: number
  budget: {
    total: number
    spent: number
  }
  timeline: {
    start: string
    end: string
  }
  team: Array<{
    id: string
    name: string
    avatar?: string
    role: string
  }>
}

interface ProjectCardProps {
  project: Project
  onClick?: () => void
}

const statusColors = {
  planning: "bg-blue-100 text-blue-800",
  active: "bg-green-100 text-green-800", 
  review: "bg-yellow-100 text-yellow-800",
  completed: "bg-gray-100 text-gray-800",
  "on-hold": "bg-red-100 text-red-800"
}

export function ProjectCard({ project, onClick }: ProjectCardProps) {
  const budgetPercentage = (project.budget.spent / project.budget.total) * 100
  const daysRemaining = Math.ceil(
    (new Date(project.timeline.end).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
  )

  return (
    <Card className="cursor-pointer transition-all hover:shadow-md" onClick={onClick}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-lg font-semibold">{project.name}</CardTitle>
            <p className="text-sm text-muted-foreground">{project.client}</p>
          </div>
          <Badge variant="secondary" className={statusColors[project.status]}>
            {project.status}
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div>
          <div className="flex justify-between text-sm mb-2">
            <span>Progress</span>
            <span>{project.progress}%</span>
          </div>
          <Progress value={project.progress} className="h-2" />
        </div>

        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="flex items-center gap-2">
            <CurrencyDollar size={16} className="text-muted-foreground" />
            <div>
              <p className="font-medium">${project.budget.spent.toLocaleString()}</p>
              <p className="text-muted-foreground">
                of ${project.budget.total.toLocaleString()}
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Clock size={16} className="text-muted-foreground" />
            <div>
              <p className="font-medium">
                {daysRemaining > 0 ? `${daysRemaining} days` : "Overdue"}
              </p>
              <p className="text-muted-foreground">remaining</p>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users size={16} className="text-muted-foreground" />
            <span className="text-sm text-muted-foreground">Team</span>
          </div>
          <div className="flex -space-x-2">
            {project.team.slice(0, 4).map((member) => (
              <Avatar key={member.id} className="h-6 w-6 border-2 border-background">
                <AvatarImage src={member.avatar} alt={member.name} />
                <AvatarFallback className="text-xs">
                  {member.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
            ))}
            {project.team.length > 4 && (
              <div className="flex h-6 w-6 items-center justify-center rounded-full border-2 border-background bg-muted text-xs">
                +{project.team.length - 4}
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}