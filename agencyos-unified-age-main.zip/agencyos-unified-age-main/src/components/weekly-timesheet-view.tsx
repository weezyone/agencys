import { useMemo } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Plus } from "@phosphor-icons/react"
import type { TimeEntry } from "@/lib/types"

interface WeeklyTimesheetViewProps {
  entries: TimeEntry[]
  weekStart: Date
  onCreateEntry: () => void
}

export function WeeklyTimesheetView({ entries, weekStart, onCreateEntry }: WeeklyTimesheetViewProps) {
  const weekDays = useMemo(() => {
    const days: Date[] = []
    for (let i = 0; i < 7; i++) {
      const date = new Date(weekStart)
      date.setDate(weekStart.getDate() + i)
      days.push(date)
    }
    return days
  }, [weekStart])

  const weekEntries = useMemo(() => {
    const weekEnd = new Date(weekStart)
    weekEnd.setDate(weekStart.getDate() + 7)
    
    return entries.filter(entry => {
      const entryDate = new Date(entry.date)
      return entryDate >= weekStart && entryDate < weekEnd
    })
  }, [entries, weekStart])

  const entriesByDate = useMemo(() => {
    const byDate: Record<string, TimeEntry[]> = {}
    weekEntries.forEach(entry => {
      const dateKey = entry.date
      if (!byDate[dateKey]) {
        byDate[dateKey] = []
      }
      byDate[dateKey].push(entry)
    })
    return byDate
  }, [weekEntries])

  const dailyTotals = useMemo(() => {
    return weekDays.map(day => {
      const dateKey = day.toISOString().split('T')[0]
      const dayEntries = entriesByDate[dateKey] || []
      return dayEntries.reduce((sum, entry) => sum + entry.hours, 0)
    })
  }, [weekDays, entriesByDate])

  const weekTotal = dailyTotals.reduce((sum, hours) => sum + hours, 0)

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-7 gap-4">
        {weekDays.map((day, index) => {
          const dateKey = day.toISOString().split('T')[0]
          const dayEntries = entriesByDate[dateKey] || []
          const isToday = day.toDateString() === new Date().toDateString()
          const isWeekend = day.getDay() === 0 || day.getDay() === 6

          return (
            <Card 
              key={day.toISOString()} 
              className={isWeekend ? "bg-muted/30" : ""}
            >
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">
                  <div className={isToday ? "text-primary" : ""}>
                    {day.toLocaleDateString('en-US', { weekday: 'short' })}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {day.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {dayEntries.length === 0 ? (
                  <div className="text-center py-4">
                    <p className="text-xs text-muted-foreground mb-2">No entries</p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={onCreateEntry}
                      className="w-full"
                    >
                      <Plus size={12} className="mr-1" />
                      Add
                    </Button>
                  </div>
                ) : (
                  <>
                    <div className="space-y-1">
                      {dayEntries.map(entry => (
                        <div 
                          key={entry.id}
                          className="text-xs p-2 rounded bg-card border"
                        >
                          <div className="font-medium truncate">{entry.projectName}</div>
                          <div className="text-muted-foreground truncate">
                            {entry.taskName || entry.description}
                          </div>
                          <div className="flex items-center justify-between mt-1">
                            <span className="font-medium">{entry.hours}h</span>
                            {entry.billable && (
                              <Badge variant="outline" className="text-xs px-1">
                                Billable
                              </Badge>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="pt-2 border-t">
                      <div className="flex items-center justify-between text-sm font-medium">
                        <span>Total</span>
                        <span>{dailyTotals[index]}h</span>
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          )
        })}
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold">Week Total</h3>
              <p className="text-sm text-muted-foreground">
                {weekEntries.length} entries logged
              </p>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold">{weekTotal.toFixed(1)}h</div>
              <p className="text-sm text-muted-foreground">
                {weekEntries.filter(e => e.billable).reduce((sum, e) => sum + e.hours, 0).toFixed(1)}h billable
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
