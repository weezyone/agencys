import { useState, useEffect } from "react"
import { useKV } from "@github/spark/hooks"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Database, Trash } from "@phosphor-icons/react"
import { toast } from "sonner"
import type { TimeEntry } from "@/lib/types"
import type { Project } from "@/components/project-card"
import type { TeamMember } from "@/pages/team-page"

export function DataSeeder() {
  const [projects] = useKV<Project[]>("agency-projects", [])
  const [teamMembers] = useKV<TeamMember[]>("agency-team-members", [])
  const [timeEntries, setTimeEntries] = useKV<TimeEntry[]>("agency-time-entries", [])
  const [isSeeded, setIsSeeded] = useState(false)

  useEffect(() => {
    setIsSeeded((timeEntries?.length || 0) > 0)
  }, [timeEntries])

  const seedTimeEntries = () => {
    if (!projects || projects.length === 0) {
      toast.error("Please create some projects first")
      return
    }
    
    if (!teamMembers || teamMembers.length === 0) {
      toast.error("Please add team members first")
      return
    }

    const sampleEntries: TimeEntry[] = []
    const today = new Date()
    
    for (let daysAgo = 0; daysAgo < 30; daysAgo++) {
      const date = new Date(today)
      date.setDate(today.getDate() - daysAgo)
      const dateString = date.toISOString().split('T')[0]
      
      if (date.getDay() !== 0 && date.getDay() !== 6) {
        teamMembers.forEach((member, memberIndex) => {
          if (Math.random() > 0.2) {
            const project = projects[Math.floor(Math.random() * Math.min(projects.length, 3))]
            const hours = [4, 6, 7, 8, 8.5][Math.floor(Math.random() * 5)]
            const isBillable = Math.random() > 0.2
            
            const tasks = [
              "UI/UX Design",
              "Frontend Development",
              "API Development",
              "Code Review",
              "Client Meeting",
              "Sprint Planning",
              "Bug Fixes",
              "Documentation",
              "Testing",
              "Design Review"
            ]
            
            const descriptions = [
              "Implemented new feature components",
              "Fixed critical bugs in production",
              "Reviewed and approved pull requests",
              "Met with client to discuss requirements",
              "Updated project documentation",
              "Conducted QA testing on latest build",
              "Refactored legacy code for better performance",
              "Created wireframes for new pages",
              "Optimized database queries",
              "Integrated third-party API"
            ]
            
            const status: TimeEntry["status"] = 
              daysAgo < 7 ? "submitted" :
              daysAgo < 14 ? "approved" :
              Math.random() > 0.8 ? "draft" : "approved"
            
            sampleEntries.push({
              id: `${Date.now()}-${daysAgo}-${memberIndex}`,
              userId: member.id,
              userName: member.name,
              projectId: project.id,
              projectName: project.name,
              taskName: tasks[Math.floor(Math.random() * tasks.length)],
              date: dateString,
              hours,
              description: descriptions[Math.floor(Math.random() * descriptions.length)],
              billable: isBillable,
              status,
              hourlyRate: member.hourlyRate,
            })
          }
        })
      }
    }

    setTimeEntries(sampleEntries)
    toast.success(`Created ${sampleEntries.length} sample time entries`)
  }

  const clearTimeEntries = () => {
    setTimeEntries([])
    toast.success("Cleared all time entries")
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database size={20} />
          Sample Time Entries
        </CardTitle>
        <CardDescription>
          Generate sample time tracking data to explore the features
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Button 
            onClick={seedTimeEntries}
            disabled={isSeeded}
          >
            <Database size={16} className="mr-2" />
            {isSeeded ? "Sample Data Loaded" : "Generate Sample Data"}
          </Button>
          
          {isSeeded && (
            <Button 
              onClick={clearTimeEntries}
              variant="outline"
            >
              <Trash size={16} className="mr-2" />
              Clear Data
            </Button>
          )}
        </div>
        
        {isSeeded && (
          <p className="text-sm text-muted-foreground">
            {timeEntries?.length || 0} time entries currently loaded
          </p>
        )}
      </CardContent>
    </Card>
  )
}
