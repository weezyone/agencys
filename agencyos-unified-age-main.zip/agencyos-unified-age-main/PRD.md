# AgencyOS - Unified Agency Management Platform

AgencyOS transforms fragmented agency workflows into a unified platform that manages the complete client lifecycle from lead to delivery to ongoing support.

**Experience Qualities**:
1. **Professional** - Clean, confident interface that instills trust with enterprise clients and streamlines complex workflows
2. **Unified** - Seamless integration between all tools and processes, eliminating context switching and data silos  
3. **Transparent** - Real-time visibility into project status, budgets, timelines, and deliverables for both agency and client stakeholders

**Complexity Level**: Complex Application (advanced functionality, accounts)
- Requires multi-tenant architecture, sophisticated RBAC, real-time collaboration, extensive integrations, and enterprise-grade security

## Essential Features

**Multi-Tenant Workspace Management**
- Functionality: Isolated agency workspaces with project-level role-based access control
- Purpose: Enable white-label client portals while maintaining strict data separation
- Trigger: Agency signup or client invitation
- Progression: Agency setup → Team invitation → Client workspace creation → Project assignment → Access provisioning
- Success criteria: Clean tenant isolation, sub-second role verification, audit trail compliance

**Project Lifecycle Management**  
- Functionality: Lead intake through proposal, SOW, delivery, and support workflows
- Purpose: Eliminate scope creep and approval delays through structured processes
- Trigger: New lead form submission or manual project creation
- Progression: Lead qualification → Proposal generation → SOW e-signature → Deposit collection → Project kickoff → Sprint execution → Delivery approval → Invoice generation
- Success criteria: <3 day approval cycles, <5% unbilled scope, >90% on-time milestones

**Design Review & Collaboration**
- Functionality: Annotated feedback on Figma designs, PDFs, images, and video with version control
- Purpose: Accelerate design approval cycles and reduce revision rounds
- Trigger: Designer uploads deliverable or shares Figma link
- Progression: Upload/link asset → Create review session → Stakeholder annotations → Threaded discussions → Version comparison → Final approval/rejection
- Success criteria: 50% reduction in review cycles, clear approval audit trail

**Development Integration & UAT**
- Functionality: Git-aware delivery with automated preview deployments and structured user acceptance testing
- Purpose: Bridge design-dev gap and capture client feedback systematically  
- Trigger: Pull request creation or manual deployment
- Progression: PR opened → Preview URL generated → UAT session initiated → Issues logged to Jira/Linear → Client sign-off → Release approval
- Success criteria: Automated issue tracking, structured UAT feedback, deployment status visibility

**Budget & Time Tracking**
- Functionality: Real-time budget monitoring with utilization tracking and margin analysis
- Purpose: Prevent budget overruns and improve project profitability
- Trigger: Time entry submission or milestone completion
- Progression: Scope definition → Budget allocation → Time tracking → Utilization monitoring → Overage alerts → Margin reporting
- Success criteria: 80/100/120% budget alerts, accurate utilization metrics, real-time margin visibility

**Time Entry & Approval Workflow**
- Functionality: Comprehensive time logging with project/task assignment, billable/non-billable tracking, and approval workflows
- Purpose: Enable accurate project billing and ensure time is properly allocated
- Trigger: Team member logs daily work hours
- Progression: Log entry (date, project, task, hours, description) → Mark billable/non-billable → Submit for approval → Manager approval/rejection → Integration with billing
- Success criteria: Sub-minute entry creation, clear approval status, automated revenue calculation

**Weekly Timesheet View**
- Functionality: Calendar-based weekly view of all time entries with daily totals and visual indicators
- Purpose: Simplify timesheet review and help team members track weekly hours at a glance
- Trigger: Team member or manager views time tracking page
- Progression: Select week → View daily entries by project → Add missing entries → Review totals → Submit for approval
- Success criteria: Easy week navigation, clear daily breakdown, quick entry creation from calendar view

**Team Utilization Analytics**
- Functionality: Team-wide and individual utilization metrics with billable vs non-billable hour tracking
- Purpose: Monitor team productivity, identify capacity issues, and optimize resource allocation
- Trigger: Manager reviews team performance
- Progression: View team overview → Analyze individual utilization rates → Identify underutilized/overworked members → Adjust project assignments → Track improvement
- Success criteria: Real-time utilization calculation, visual progress indicators, revenue impact visibility

**AI Agents Integration**
- Functionality: Intelligent automation agents for content writing, proposal generation, code review, report analysis, meeting scheduling, and project assistance
- Purpose: Automate repetitive agency tasks and augment team productivity with AI-powered assistance
- Trigger: User creates and configures an AI agent from templates
- Progression: Select agent template → Configure settings (tone, frequency, metrics) → Activate agent → Monitor activity → Chat with agent for tasks → Review completed work
- Success criteria: Easy agent creation, real-time chat interface, task completion tracking, activity logging, time savings measurement

**Client Portal & Communication**
- Functionality: Branded client interface for project status, approvals, files, invoices, and timelines
- Purpose: Improve client experience and reduce PM overhead for status updates
- Trigger: Client login or project milestone update
- Progression: Client invitation → Portal setup → Project access → Status monitoring → Approval workflows → Invoice payment
- Success criteria: Reduced client inquiries, faster approval cycles, improved satisfaction scores

## Edge Case Handling

- **Offline Access**: Local data caching for critical review and approval workflows during connectivity issues
- **Failed Integrations**: Graceful degradation with manual workflows when third-party APIs are unavailable
- **Scope Changes**: Structured change request workflow with impact analysis and client approval requirements
- **Budget Overruns**: Automatic work stoppage and stakeholder alerts when budget thresholds are exceeded
- **Data Recovery**: Point-in-time recovery with 15-minute RPO for critical project and financial data
- **Access Revocation**: Immediate permission updates across all integrated systems when team members leave
- **Concurrent Edits**: Real-time conflict resolution for simultaneous document and project updates
- **Large File Handling**: Progressive upload and streaming for design assets and video deliverables

## Design Direction

The interface should feel sophisticated and enterprise-ready while remaining intuitive - think Notion's flexibility meets Linear's precision with Figma's collaborative polish. Emphasize clear information hierarchy and confident use of space that instills trust with high-value clients.

## Color Selection

Triadic (three equally spaced colors) - Professional blue-green-orange palette that conveys trust, growth, and energy while maintaining strong contrast ratios for accessibility.

- **Primary Color**: Deep Professional Blue (oklch(0.45 0.15 250)) - Conveys trust, stability, and enterprise credibility for key actions
- **Secondary Colors**: Sage Green (oklch(0.65 0.1 150)) for positive states/success, Warm Orange (oklch(0.7 0.15 50)) for attention/warnings  
- **Accent Color**: Bright Electric Blue (oklch(0.6 0.2 240)) - High-energy highlight for CTAs and interactive elements
- **Foreground/Background Pairings**: 
  - Background (Pure White oklch(1 0 0)): Dark Gray text (oklch(0.2 0 0)) - Ratio 16:1 ✓
  - Card (Light Gray oklch(0.98 0 0)): Dark Gray text (oklch(0.2 0 0)) - Ratio 15.2:1 ✓
  - Primary (Deep Blue oklch(0.45 0.15 250)): White text (oklch(1 0 0)) - Ratio 5.8:1 ✓
  - Secondary (Sage Green oklch(0.65 0.1 150)): White text (oklch(1 0 0)) - Ratio 4.7:1 ✓
  - Accent (Electric Blue oklch(0.6 0.2 240)): White text (oklch(1 0 0)) - Ratio 4.9:1 ✓

## Font Selection

Typography should feel modern and professional while maintaining excellent readability across complex data tables and long-form content - Inter provides the clarity and versatility needed for both interface and content.

- **Typographic Hierarchy**:
  - H1 (Page Titles): Inter Bold/32px/tight letter spacing (-0.02em)
  - H2 (Section Headers): Inter SemiBold/24px/normal letter spacing  
  - H3 (Subsections): Inter Medium/20px/normal letter spacing
  - H4 (Component Headers): Inter Medium/16px/normal letter spacing
  - Body (Primary Content): Inter Regular/16px/relaxed line height (1.6)
  - Small (Metadata): Inter Regular/14px/normal letter spacing
  - Caption (Labels): Inter Medium/12px/wide letter spacing (0.05em)

## Animations

Subtle and purposeful motion that guides attention and provides feedback without slowing down power users - favor micro-interactions that reinforce actions over decorative animations.

- **Purposeful Meaning**: Quick spring-based transitions (0.2s) communicate system responsiveness while gentle hover states (0.1s) provide affordance feedback
- **Hierarchy of Movement**: Priority on loading states, form validation feedback, and status changes; secondary animations for navigation and progressive disclosure

## Component Selection

- **Components**: Heavy use of shadcn Tables for data display, Cards for project overviews, Dialog/Sheet for forms and details, Tabs for workflow navigation, Progress for budget/timeline tracking, Badge for status indicators, Avatar for team members
- **Customizations**: Custom timeline component for project milestones, kanban board for task management, annotation overlay for design reviews, budget dashboard with charts
- **States**: Buttons with loading spinners, inputs with inline validation, disabled states for workflow gates, success/warning states with appropriate colors
- **Icon Selection**: Phosphor icons - use Folder for projects, Clock for time tracking, DollarSign for budgets, Eye for reviews, Users for teams, CheckCircle for approvals
- **Spacing**: Consistent 4px base unit - component padding p-4/p-6, section gaps gap-6/gap-8, page margins px-8/px-12
- **Mobile**: Responsive sidebar that collapses to hamburger menu, stack cards vertically, simplify tables to key columns, thumb-friendly 44px touch targets