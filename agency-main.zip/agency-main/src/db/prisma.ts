import { PrismaClient } from '@prisma/client';

export const prisma = new PrismaClient();
export const isDbEnabled = Boolean(process.env.DATABASE_URL);

export async function healthcheck(): Promise<boolean> {
  try {
    await prisma.$queryRaw`SELECT 1`;
    return true;
  } catch {
    return false;
  }
}
