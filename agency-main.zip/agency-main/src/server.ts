import http from 'node:http';
import { parse } from 'node:url';
import { TenancyService } from './modules/tenancy/service.js';
import { AuthService } from './modules/auth/service.js';
import { RbacService } from './modules/rbac/service.js';
import { isDbEnabled } from './db/prisma.js';
import { TenancyRepoPrisma } from './modules/tenancy/repo.prisma.js';
import { ProjectRepoPrisma } from './modules/project/repo.prisma.js';
import { ProjectService } from './modules/project/service.js';
import { DesignService } from './modules/design/service.js';
import { NotificationService } from './modules/notification/service.js';
import { BillingService } from './modules/billing/service.js';

const tenancy = new TenancyService();
const auth = new AuthService();
const rbac = new RbacService();
const tenRepo = new TenancyRepoPrisma();
const projRepo = new ProjectRepoPrisma();
const projects = new ProjectService();
const design = new DesignService();
const notif = new NotificationService();
const billing = new BillingService();

const server = http.createServer(async (req, res) => {
  const url = parse(req.url || '', true);
  const path = url.pathname || '';
  const method = req.method || 'GET';
  const userId = (req.headers['x-user-id'] as string) || '';
  const need = (ok: boolean, code = 403) => { if (!ok) { res.writeHead(code, { 'content-type': 'application/json' }); res.end(JSON.stringify({ error: 'forbidden' })); return false; } return true; };

  const readBody = async () => {
    const chunks: Buffer[] = [];
    for await (const chunk of req) chunks.push(chunk as Buffer);
    if (chunks.length === 0) return {} as any;
    return JSON.parse(Buffer.concat(chunks).toString('utf8')) as any;
  };

  try {
    if (method === 'POST' && path === '/tenants') {
      const body = await readBody();
      const t = isDbEnabled ? await tenRepo.createTenant(body.name) : tenancy.createTenant(body.name);
      res.writeHead(201, { 'content-type': 'application/json' });
      res.end(JSON.stringify(t));
      return;
    }
    if (method === 'POST' && path === '/workspaces') {
      const body = await readBody();
      const ws = isDbEnabled ? await tenRepo.createWorkspace(body.tenantId, body.name) : tenancy.createWorkspace(body.tenantId, body.name);
      res.writeHead(201, { 'content-type': 'application/json' });
      res.end(JSON.stringify(ws));
      return;
    }
    if (method === 'POST' && path === '/assign-user') {
      const body = await readBody();
      if (isDbEnabled) await tenRepo.assignUserToWorkspace(body.userId, body.workspaceId); else tenancy.assignUserToWorkspace(body.userId, body.workspaceId);
      res.writeHead(204).end();
      return;
    }
    if (method === 'GET' && path === '/workspaces') {
      const qUser = (url.query.userId as string) || '';
      const list = isDbEnabled ? await tenRepo.listUserWorkspaces(qUser) : tenancy.listUserWorkspaces(qUser);
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify(list));
      return;
    }
    if (method === 'POST' && path === '/auth/login') {
      const body = await readBody();
      const tok = auth.login(body.email, body.password);
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify(tok));
      return;
    }

    if (process.env.NODE_ENV === 'test' && method === 'POST' && path === '/_test/rbac-assign') {
      const body = await readBody();
      rbac.assign({ userId: body.userId, scope: { type: body.scopeType, id: body.scopeId }, role: body.role });
      res.writeHead(204).end();
      return;
    }

    // Projects
    if (method === 'POST' && path === '/projects') {
      const body = await readBody();
      if (!need(rbac.hasPermission(userId, { type: 'tenant', id: body.tenantId }, 'project:write'))) return;
      const p = isDbEnabled ? await projRepo.createProject(body.tenantId, body.name) : projects.createProject(body.tenantId, body.name);
      res.writeHead(201, { 'content-type': 'application/json' });
      res.end(JSON.stringify(p));
      return;
    }

    const pm = path.match(/^\/projects\/([^\/]+)(?:\/(tasks|budget))?$/);
    if (pm) {
      const projectId = pm[1];
      const sub = pm[2];
      const proj = isDbEnabled ? await projRepo.getProject(projectId) : projects.getProject(projectId);
      if (!proj) { res.writeHead(404, { 'content-type': 'application/json' }); res.end(JSON.stringify({ error: 'project_not_found' })); return; }

      if (sub === 'tasks') {
        if (method === 'POST') {
          if (!need(rbac.hasPermission(userId, { type: 'tenant', id: proj.tenantId }, 'project:write'))) return;
          const body = await readBody();
          const t = isDbEnabled ? await projRepo.addTask(projectId, body.title) : projects.addTask(projectId, body.title);
          res.writeHead(201, { 'content-type': 'application/json' });
          res.end(JSON.stringify(t));
          return;
        }
        if (method === 'GET') {
          if (!need(rbac.hasPermission(userId, { type: 'tenant', id: proj.tenantId }, 'project:read'))) return;
          const list = isDbEnabled ? await projRepo.listTasks(projectId) : projects.listTasks(projectId);
          res.writeHead(200, { 'content-type': 'application/json' });
          res.end(JSON.stringify(list));
          return;
        }
      }

      if (sub === 'budget') {
        if (method === 'POST') {
          if (!need(rbac.hasPermission(userId, { type: 'tenant', id: proj.tenantId }, 'project:write'))) return;
          const body = await readBody();
          if (isDbEnabled) await projRepo.setBudget(projectId, body.planned, body.alerts); else projects.setBudget(projectId, body.planned, body.alerts);
          res.writeHead(204).end();
          return;
        }
        if (method === 'GET') {
          if (!need(rbac.hasPermission(userId, { type: 'tenant', id: proj.tenantId }, 'project:read'))) return;
          const b = isDbEnabled ? await projRepo.getBudget(projectId) : projects.getBudget(projectId);
          res.writeHead(200, { 'content-type': 'application/json' });
          res.end(JSON.stringify(b ?? null));
          return;
        }
        if (method === 'PATCH') {
          if (!need(rbac.hasPermission(userId, { type: 'tenant', id: proj.tenantId }, 'project:write'))) return;
          const body = await readBody();
          const r = isDbEnabled ? await projRepo.recordSpend(projectId, body.amount) : projects.recordSpend(projectId, body.amount);
          res.writeHead(200, { 'content-type': 'application/json' });
          res.end(JSON.stringify(r));
          return;
        }
      }
    }

    if (method === 'GET' && path === '/docs') {
      const yaml = await (await import('node:fs/promises')).readFile(new URL('../docs/openapi.yaml', import.meta.url), 'utf8');
      res.writeHead(200, { 'content-type': 'text/yaml' });
      res.end(yaml);
      return;
    }

    // Design assets
    if (method === 'POST' && path === '/designs') {
      const body = await readBody();
      const asset = design.createAsset(body.projectId, body.url, body.figmaFileKey);
      res.writeHead(201, { 'content-type': 'application/json' });
      res.end(JSON.stringify(asset));
      return;
    }

    const dm = path.match(/^\/designs\/([^\/]+)(?:\/(annotations|approvals))?$/);
    if (dm) {
      const assetId = dm[1];
      const sub = dm[2];
      const asset = design.getAsset(assetId);
      if (!asset) { res.writeHead(404, { 'content-type': 'application/json' }); res.end(JSON.stringify({ error: 'asset_not_found' })); return; }

      if (sub === 'annotations') {
        if (method === 'POST') {
          const body = await readBody();
          const ann = design.addAnnotation(assetId, userId, body.type, body.content, body.x, body.y);
          res.writeHead(201, { 'content-type': 'application/json' });
          res.end(JSON.stringify(ann));
          return;
        }
        if (method === 'GET') {
          const list = design.listAnnotations(assetId);
          res.writeHead(200, { 'content-type': 'application/json' });
          res.end(JSON.stringify(list));
          return;
        }
      }

      if (sub === 'approvals') {
        if (method === 'POST') {
          const body = await readBody();
          const app = design.approve(assetId, userId, body.status, body.comment);
          await notif.notifyApproval(assetId, body.approverEmail || 'approver@example.com', body.status);
          res.writeHead(201, { 'content-type': 'application/json' });
          res.end(JSON.stringify(app));
          return;
        }
        if (method === 'GET') {
          const list = design.getApprovals(assetId);
          res.writeHead(200, { 'content-type': 'application/json' });
          res.end(JSON.stringify(list));
          return;
        }
      }
    }

    // Billing
    if (method === 'POST' && path === '/invoices') {
      const body = await readBody();
      const inv = billing.createInvoice(body.projectId, body.amount, body.dueDate ? new Date(body.dueDate) : undefined);
      res.writeHead(201, { 'content-type': 'application/json' });
      res.end(JSON.stringify(inv));
      return;
    }

    if (method === 'POST' && path.startsWith('/invoices/') && path.endsWith('/checkout')) {
      const invoiceId = path.split('/')[2];
      const session = billing.createCheckoutSession(invoiceId);
      res.writeHead(201, { 'content-type': 'application/json' });
      res.end(JSON.stringify(session));
      return;
    }

    if (method === 'POST' && path === '/webhooks/stripe') {
      const body = await readBody();
      billing.handleStripeWebhook(body.type, body.data?.object);
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ received: true }));
      return;
    }

    const im = path.match(/^\/invoices\/([^\/]+)$/);
    if (im) {
      const invoiceId = im[1];
      if (method === 'GET') {
        const inv = billing.getInvoice(invoiceId);
        if (!inv) { res.writeHead(404, { 'content-type': 'application/json' }); res.end(JSON.stringify({ error: 'invoice_not_found' })); return; }
        res.writeHead(200, { 'content-type': 'application/json' });
        res.end(JSON.stringify(inv));
        return;
      }
    }

    if (method === 'GET' && path === '/docs') {
      const yaml = await (await import('node:fs/promises')).readFile(new URL('../docs/openapi.yaml', import.meta.url), 'utf8');
      res.writeHead(200, { 'content-type': 'text/yaml' });
      res.end(yaml);
      return;
    }

    res.writeHead(404, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ error: 'not_found' }));
  } catch (err: any) {
    res.writeHead(400, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ error: err?.message || 'bad_request' }));
  }
});

const port = Number(process.env.PORT || 3010);
if (process.env.NODE_ENV !== 'test') {
  server.listen(port, () => console.log(`api listening on :${port}`));
}

export default server;
