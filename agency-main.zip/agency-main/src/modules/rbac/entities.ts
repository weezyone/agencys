export type Permission =
  | 'tenant:create'
  | 'workspace:read'
  | 'project:read'
  | 'project:write'
  | 'billing:manage'
  | 'admin:all';

export type Role =
  | 'SUPER_ADMIN'
  | 'ADMIN'
  | 'PM'
  | 'DESIGNER'
  | 'ENGINEER'
  | 'QA'
  | 'FINANCE'
  | 'CONTRACTOR'
  | 'CLIENT_ADMIN'
  | 'CLIENT_REVIEWER'
  | 'VIEWER';

export interface UserRole {
  userId: string;
  scope: { type: 'tenant' | 'workspace' | 'project'; id: string };
  role: Role;
}

export interface ProjectMembership {
  userId: string;
  projectId: string;
  role: Role;
}

export const ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  SUPER_ADMIN: ['admin:all'],
  ADMIN: ['tenant:create', 'workspace:read', 'project:read', 'project:write', 'billing:manage'],
  PM: ['project:read', 'project:write'],
  DESIGNER: ['project:read', 'project:write'],
  ENGINEER: ['project:read', 'project:write'],
  QA: ['project:read'],
  FINANCE: ['project:read', 'billing:manage'],
  CONTRACTOR: ['project:read'],
  CLIENT_ADMIN: ['project:read'],
  CLIENT_REVIEWER: ['project:read'],
  VIEWER: ['project:read'],
};
