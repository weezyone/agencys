import type { Permission, Role, UserRole } from './entities.js';
import { ROLE_PERMISSIONS } from './entities.js';

export class RbacService {
  private assignments: UserRole[] = [];

  assign(userRole: UserRole) {
    this.assignments.push(userRole);
  }

  hasPermission(userId: string, scope: { type: 'tenant' | 'workspace' | 'project'; id: string }, perm: Permission): boolean {
    const roles = this.assignments.filter(a => a.userId === userId && a.scope.type === scope.type && a.scope.id === scope.id).map(a => a.role);
    if (roles.includes('SUPER_ADMIN')) return true;
    return roles.some((r: Role) => ROLE_PERMISSIONS[r]?.includes(perm));
  }
}
