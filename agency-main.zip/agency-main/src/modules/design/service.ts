import type { ID, DesignAsset, Annotation, AnnotationType, Approval, ApprovalStatus } from './entities.js';
import { randomUUID } from 'node:crypto';

export class DesignService {
  private assets = new Map<ID, DesignAsset>();
  private annotations = new Map<ID, Annotation>();
  private approvals = new Map<ID, Approval>();
  private assetAnnotations = new Map<ID, ID[]>();

  createAsset(projectId: ID, url: string, figmaFileKey?: string): DesignAsset {
    const id = randomUUID();
    const asset: DesignAsset = { id, projectId, url, figmaFileKey, version: 1, createdAt: new Date() };
    this.assets.set(id, asset);
    return asset;
  }

  getAsset(id: ID): DesignAsset | undefined { return this.assets.get(id); }

  addAnnotation(assetId: ID, userId: ID, type: AnnotationType, content: string, x?: number, y?: number): Annotation {
    if (!this.assets.has(assetId)) throw new Error('asset_not_found');
    const id = randomUUID();
    const ann: Annotation = { id, assetId, userId, type, content, x, y, createdAt: new Date() };
    this.annotations.set(id, ann);
    const idx = this.assetAnnotations.get(assetId) ?? [];
    idx.push(id);
    this.assetAnnotations.set(assetId, idx);
    return ann;
  }

  listAnnotations(assetId: ID): Annotation[] {
    const ids = this.assetAnnotations.get(assetId) ?? [];
    return ids.map(id => this.annotations.get(id)!).filter(Boolean);
  }

  approve(assetId: ID, userId: ID, status: ApprovalStatus, comment?: string): Approval {
    if (!this.assets.has(assetId)) throw new Error('asset_not_found');
    const id = randomUUID();
    const app: Approval = { id, assetId, userId, status, comment, createdAt: new Date() };
    this.approvals.set(id, app);
    return app;
  }

  getApprovals(assetId: ID): Approval[] {
    return Array.from(this.approvals.values()).filter(a => a.assetId === assetId);
  }
}
