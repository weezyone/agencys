export type ID = string;

export type AnnotationType = 'comment' | 'change_request' | 'approval';
export type ApprovalStatus = 'pending' | 'approved' | 'rejected';

export interface DesignAsset {
  id: ID;
  projectId: ID;
  figmaFileKey?: string;
  url: string;
  version: number;
  createdAt: Date;
}

export interface Annotation {
  id: ID;
  assetId: ID;
  userId: ID;
  type: AnnotationType;
  content: string;
  x?: number;
  y?: number;
  createdAt: Date;
}

export interface Approval {
  id: ID;
  assetId: ID;
  userId: ID;
  status: ApprovalStatus;
  comment?: string;
  createdAt: Date;
}
