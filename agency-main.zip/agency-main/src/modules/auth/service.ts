export interface LoginResult { token: string; userId: string; issuedAt: number }

export class AuthService {
  login(email: string, _password: string): LoginResult {
    // Placeholder only; replace with real auth and MFA
    const token = Buffer.from(`${email}:${Date.now()}`).toString('base64url');
    return { token, userId: email, issuedAt: Date.now() };
  }
}
