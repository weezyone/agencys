export type ID = string;
export type InvoiceStatus = 'draft' | 'sent' | 'paid' | 'overdue';
export type PaymentStatus = 'pending' | 'succeeded' | 'failed';

export interface Invoice {
  id: ID;
  projectId: ID;
  amount: number;
  status: InvoiceStatus;
  dueDate?: Date;
  createdAt: Date;
}

export interface Payment {
  id: ID;
  invoiceId: ID;
  amount: number;
  status: PaymentStatus;
  stripePaymentId?: string;
  createdAt: Date;
}

export interface StripeCheckoutSession {
  sessionId: string;
  url: string;
  invoiceId: ID;
}
