import type { ID, Invoice, InvoiceStatus, Payment, PaymentStatus, StripeCheckoutSession } from './entities.js';
import { randomUUID } from 'node:crypto';

export class BillingService {
  private invoices = new Map<ID, Invoice>();
  private payments = new Map<ID, Payment>();

  createInvoice(projectId: ID, amount: number, dueDate?: Date): Invoice {
    const id = randomUUID();
    const inv: Invoice = { id, projectId, amount, status: 'draft', dueDate, createdAt: new Date() };
    this.invoices.set(id, inv);
    return inv;
  }

  getInvoice(id: ID): Invoice | undefined { return this.invoices.get(id); }

  updateInvoiceStatus(id: ID, status: InvoiceStatus) {
    const inv = this.invoices.get(id);
    if (!inv) throw new Error('invoice_not_found');
    inv.status = status;
  }

  createPayment(invoiceId: ID, amount: number, stripePaymentId?: string): Payment {
    if (!this.invoices.has(invoiceId)) throw new Error('invoice_not_found');
    const id = randomUUID();
    const pmt: Payment = { id, invoiceId, amount, status: 'pending', stripePaymentId, createdAt: new Date() };
    this.payments.set(id, pmt);
    return pmt;
  }

  updatePaymentStatus(id: ID, status: PaymentStatus) {
    const pmt = this.payments.get(id);
    if (!pmt) throw new Error('payment_not_found');
    pmt.status = status;
    if (status === 'succeeded') {
      const inv = this.invoices.get(pmt.invoiceId);
      if (inv) inv.status = 'paid';
    }
  }

  // Stripe stub
  createCheckoutSession(invoiceId: ID): StripeCheckoutSession {
    const inv = this.invoices.get(invoiceId);
    if (!inv) throw new Error('invoice_not_found');
    const sessionId = `cs_${randomUUID()}`;
    return { sessionId, url: `https://checkout.stripe.com/pay/${sessionId}`, invoiceId };
  }

  // Webhook stub
  handleStripeWebhook(eventType: string, data: any) {
    if (eventType === 'checkout.session.completed') {
      const invoiceId = data.metadata?.invoiceId;
      if (invoiceId) this.updateInvoiceStatus(invoiceId, 'paid');
    }
  }
}
