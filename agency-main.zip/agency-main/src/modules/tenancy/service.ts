import type { ID, Tenant, Workspace, User } from './entities';
import { prisma } from '../../db/prisma.js';

import { randomUUID } from 'node:crypto';

export class TenancyService {
  private tenants = new Map<ID, Tenant>();
  private workspaces = new Map<ID, Workspace>();
  private userWorkspaceIndex = new Map<ID, ID[]>();

  createTenant(name: string): Tenant {
    const id = randomUUID();
    const t: Tenant = { id, name, createdAt: new Date() };
    this.tenants.set(id, t);
    return t;
  }

  createWorkspace(tenantId: ID, name: string): Workspace {
    if (!this.tenants.has(tenantId)) throw new Error('tenant_not_found');
    const id = randomUUID();
    const ws: Workspace = { id, tenantId, name, createdAt: new Date() };
    this.workspaces.set(id, ws);
    return ws;
  }

  assignUserToWorkspace(userId: ID, workspaceId: ID) {
    if (!this.workspaces.has(workspaceId)) throw new Error('workspace_not_found');
    const arr = this.userWorkspaceIndex.get(userId) ?? [];
    if (!arr.includes(workspaceId)) arr.push(workspaceId);
    this.userWorkspaceIndex.set(userId, arr);
  }

  listUserWorkspaces(userId: ID): Workspace[] {
    const ids = this.userWorkspaceIndex.get(userId) ?? [];
    return ids.map((id) => this.workspaces.get(id)!).filter(Boolean);
  }
}
