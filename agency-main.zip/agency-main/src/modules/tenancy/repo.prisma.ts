import { prisma } from '../../db/prisma.js';
import type { Tenant, Workspace, ID } from './entities.js';

export class TenancyRepoPrisma {
  async createTenant(name: string): Promise<Tenant> {
    const t = await prisma.tenant.create({ data: { name } });
    return { id: t.id, name: t.name, createdAt: t.createdAt };
  }
  async createWorkspace(tenantId: ID, name: string): Promise<Workspace> {
    const ws = await prisma.workspace.create({ data: { tenantId, name } });
    return { id: ws.id, tenantId: ws.tenantId, name: ws.name, createdAt: ws.createdAt };
  }
  async assignUserToWorkspace(userId: ID, workspaceId: ID): Promise<void> {
    await prisma.userWorkspace.upsert({
      where: { userId_workspaceId: { userId, workspaceId } },
      update: {},
      create: { userId, workspaceId },
    });
  }
  async listUserWorkspaces(userId: ID): Promise<Workspace[]> {
    const rows = await prisma.workspace.findMany({ where: { userLinks: { some: { userId } } } });
    return rows.map(ws => ({ id: ws.id, tenantId: ws.tenantId, name: ws.name, createdAt: ws.createdAt }));
  }
}
