export type ID = string;

export interface Tenant {
  id: ID;
  name: string;
  createdAt: Date;
}

export interface Workspace {
  id: ID;
  tenantId: ID;
  name: string;
  createdAt: Date;
}

export interface User {
  id: ID;
  email: string;
  displayName: string;
  createdAt: Date;
}
