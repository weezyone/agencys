import type { ID, Project, Task, TaskStatus, Budget } from './entities.js';
import { prisma } from '../../db/prisma.js';

import { randomUUID } from 'node:crypto';

export class ProjectService {
  private projects = new Map<ID, Project>();
  private tasks = new Map<ID, Task>();
  private projectTasks = new Map<ID, ID[]>();
  private budgets = new Map<ID, Budget>();

  createProject(tenantId: ID, name: string): Project {
    const id = randomUUID();
    const p: Project = { id, tenantId, name, createdAt: new Date() };
    this.projects.set(id, p);
    return p;
  }

  getProject(id: ID): Project | undefined { return this.projects.get(id); }

  addTask(projectId: ID, title: string): Task {
    if (!this.projects.has(projectId)) throw new Error('project_not_found');
    const id = randomUUID();
    const t: Task = { id, projectId, title, status: 'todo', createdAt: new Date() };
    this.tasks.set(id, t);
    const idx = this.projectTasks.get(projectId) ?? [];
    idx.push(id);
    this.projectTasks.set(projectId, idx);
    return t;
  }

  updateTaskStatus(taskId: ID, status: TaskStatus) {
    const t = this.tasks.get(taskId);
    if (!t) throw new Error('task_not_found');
    t.status = status;
  }

  listTasks(projectId: ID): Task[] {
    const ids = this.projectTasks.get(projectId) ?? [];
    return ids.map(id => this.tasks.get(id)!).filter(Boolean);
  }

  setBudget(projectId: ID, planned: number, alerts: number[] = [80,100,120]) {
    if (!this.projects.has(projectId)) throw new Error('project_not_found');
    this.budgets.set(projectId, { projectId, planned, spent: 0, alerts });
  }

  getBudget(projectId: ID): Budget | undefined { return this.budgets.get(projectId); }

  recordSpend(projectId: ID, amount: number): { budget: Budget; triggered: number[] } {
    const b = this.budgets.get(projectId);
    if (!b) throw new Error('budget_not_set');
    b.spent += amount;
    const pct = (b.spent / b.planned) * 100;
    const triggered = b.alerts.filter(th => pct >= th);
    return { budget: b, triggered };
  }
}
