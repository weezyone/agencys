export type ID = string;

export interface Project {
  id: ID;
  tenantId: ID;
  name: string;
  createdAt: Date;
}

export type TaskStatus = 'todo' | 'in_progress' | 'done';

export interface Task {
  id: ID;
  projectId: ID;
  title: string;
  status: TaskStatus;
  createdAt: Date;
}

export interface Budget {
  projectId: ID;
  planned: number; // currency minor units
  spent: number;   // currency minor units
  alerts: number[]; // thresholds e.g., [80,100,120]
}
