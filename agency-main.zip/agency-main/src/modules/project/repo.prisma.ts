import { prisma } from '../../db/prisma.js';
import type { ID, Project, Task, TaskStatus, Budget } from './entities.js';

export class ProjectRepoPrisma {
  async createProject(tenantId: ID, name: string): Promise<Project> {
    const p = await prisma.project.create({ data: { tenantId, name } });
    return { id: p.id, tenantId: p.tenantId, name: p.name, createdAt: p.createdAt };
  }
  async getProject(id: ID): Promise<Project | undefined> {
    const p = await prisma.project.findUnique({ where: { id } });
    return p ? { id: p.id, tenantId: p.tenantId, name: p.name, createdAt: p.createdAt } : undefined;
  }
  async addTask(projectId: ID, title: string): Promise<Task> {
    const t = await prisma.task.create({ data: { projectId, title } });
    return { id: t.id, projectId: t.projectId, title: t.title, status: t.status as TaskStatus, createdAt: t.createdAt };
  }
  async updateTaskStatus(taskId: ID, status: TaskStatus): Promise<void> {
    await prisma.task.update({ where: { id: taskId }, data: { status } });
  }
  async listTasks(projectId: ID): Promise<Task[]> {
    const rows = await prisma.task.findMany({ where: { projectId } });
    return rows.map(t => ({ id: t.id, projectId: t.projectId, title: t.title, status: t.status as TaskStatus, createdAt: t.createdAt }));
  }
  async setBudget(projectId: ID, planned: number, alerts: number[] = [80,100,120]): Promise<void> {
    await prisma.budget.upsert({ where: { projectId }, update: { planned, alerts }, create: { projectId, planned, alerts } });
  }
  async getBudget(projectId: ID): Promise<Budget | undefined> {
    const b = await prisma.budget.findUnique({ where: { projectId } });
    return b ? { projectId: b.projectId, planned: b.planned, spent: b.spent, alerts: b.alerts } : undefined;
  }
  async recordSpend(projectId: ID, amount: number): Promise<{ budget: Budget; triggered: number[] }> {
    const b = await prisma.budget.update({ where: { projectId }, data: { spent: { increment: amount } } });
    const pct = (b.spent / b.planned) * 100;
    const triggered = b.alerts.filter(th => pct >= th);
    return { budget: { projectId: b.projectId, planned: b.planned, spent: b.spent, alerts: b.alerts }, triggered };
  }
}
