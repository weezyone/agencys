export type NotificationChannel = 'email' | 'slack';

export interface NotificationPayload {
  to: string;
  subject?: string;
  body: string;
  channel: NotificationChannel;
}

export class NotificationService {
  async send(payload: NotificationPayload): Promise<void> {
    // Stub: log instead of actual send
    console.log(`[${payload.channel}] to:${payload.to} subject:${payload.subject || 'N/A'} body:${payload.body}`);
  }

  async notifyApproval(assetId: string, approverEmail: string, status: string): Promise<void> {
    await this.send({
      to: approverEmail,
      subject: `Design ${assetId} ${status}`,
      body: `Asset ${assetId} has been ${status}.`,
      channel: 'email',
    });
  }
}
