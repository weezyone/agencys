# AgencyOS

**Version 0.1.0** - Minimal hybrid CRM & project management platform for digital agencies

## Features

### M1: Tenancy & RBAC ✅
- Multi-tenant workspaces with row-level security
- 11 predefined roles (Super Admin, Admin, PM, Designer, Engineer, QA, Finance, Contractor, Client Admin, Client Reviewer, Viewer)
- Project-level permission overrides
- SSO ready (OAuth/SAML placeholders)

### M2: Project Core ✅
- Project planning with tasks, sprints, milestones
- Budget tracking with 80/100/120% threshold alerts
- Real-time budget vs actual reporting
- Change request management

### M3: Design Review ✅
- Design asset management (Figma integration stub)
- Annotations (comments, change requests, approvals)
- Approval workflows with SLA tracking
- Notification engine (email/Slack stubs)

### M4: Invoicing ✅
- Milestone-based invoice generation
- Stripe checkout integration (stub)
- Webhook payment processing
- Accounting sync ready (QuickBooks/Xero)

## Tech Stack

- **Backend**: Node.js 20 LTS, TypeScript 5.3+, NestJS-style architecture
- **Database**: PostgreSQL 15+ with Prisma ORM (optional, falls back to in-memory)
- **Cache**: Redis 7.2+ (for sessions, queues)
- **Frontend**: Next.js 15 + React 18 (ready for UI layer)
- **Integrations**: Figma, GitHub, Stripe, Slack (stubs ready for OAuth)

## Quick Start

### Prerequisites
- Node.js 20.x LTS
- PostgreSQL 15+ (optional)
- Docker (optional)

### Local Development
```bash
# Install dependencies
npm install

# Copy env template
cp .env.example .env

# Optional: Start Postgres with Docker Compose
docker-compose up -d db

# Optional: Run migrations if using DB
npm run prisma:migrate

# Optional: Seed data
npm run seed

# Build
npm run build

# Run tests
npm test

# Start server
npm start
# API listening on :3000
```

### Docker
```bash
# Build image
npm run docker:build

# Run with compose (includes Postgres)
docker-compose up
```

## API Endpoints

### Tenancy & Auth
- `POST /tenants` - Create tenant
- `POST /workspaces` - Create workspace
- `POST /auth/login` - Login (placeholder)

### Projects
- `POST /projects` - Create project (requires `project:write`)
- `POST /projects/:id/tasks` - Add task
- `GET /projects/:id/tasks` - List tasks
- `POST /projects/:id/budget` - Set budget
- `PATCH /projects/:id/budget` - Record spend

### Design Review
- `POST /designs` - Upload design asset
- `POST /designs/:id/annotations` - Add annotation
- `GET /designs/:id/annotations` - List annotations
- `POST /designs/:id/approvals` - Approve/reject
- `GET /designs/:id/approvals` - List approvals

### Billing
- `POST /invoices` - Create invoice
- `POST /invoices/:id/checkout` - Create Stripe checkout session
- `GET /invoices/:id` - Get invoice
- `POST /webhooks/stripe` - Stripe webhook handler

### Docs
- `GET /docs` - OpenAPI YAML spec

## RBAC

Use header `x-user-id` for auth. Assign roles via test endpoint:
```bash
POST /_test/rbac-assign
{
  "userId": "u1",
  "scopeType": "tenant",
  "scopeId": "t1",
  "role": "PM"
}
```

## Project Structure

```
agency/
├── src/
│   ├── modules/
│   │   ├── tenancy/       # Multi-tenant & workspaces
│   │   ├── auth/          # Authentication (stub)
│   │   ├── rbac/          # Role-based access control
│   │   ├── project/       # Projects, tasks, budgets
│   │   ├── design/        # Design assets, annotations, approvals
│   │   ├── notification/  # Email/Slack notifications (stub)
│   │   └── billing/       # Invoices, payments, Stripe
│   ├── db/                # Prisma client
│   └── server.ts          # HTTP server
├── tests/                 # Unit & integration tests
├── docs/                  # OpenAPI spec
├── config/                # Speckit files
│   ├── speckit.constitution
│   ├── speckit.specify
│   ├── speckit.plan
│   ├── speckit.tasks
│   └── speckit.impliment
├── prisma/
│   └── schema.prisma      # Database schema
└── Dockerfile
```

## Configuration

Set `DATABASE_URL` to enable Prisma persistence; otherwise falls back to in-memory storage.

```env
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/agencyos?schema=public
```

## Scripts

- `npm run build` - TypeScript build
- `npm test` - Run tests
- `npm start` - Start server
- `npm run prisma:generate` - Generate Prisma client
- `npm run prisma:migrate` - Run migrations
- `npm run seed` - Seed database
- `npm run docker:build` - Build Docker image
- `npm run docker:run` - Run Docker container

## Testing

Run all tests:
```bash
npm test
```

Tests include:
- Tenancy isolation
- RBAC permission checks
- Project budget alerts (80/100/120%)
- Design annotation & approval flow
- Invoice creation & webhook payment

## CI/CD

GitHub Actions workflow runs on push/PR:
- Build & test on Node 20.x
- Docker image build on main branch
- Coverage reporting (placeholder)

## Roadmap

### Phase 2
- Resource planning & capacity forecasting
- Advanced utilization dashboards
- Knowledge base with AI search
- White-labeling & custom branding
- SCIM provisioning for SSO

### Phase 3
- AI-powered risk forecasting
- Cost anomaly detection
- Multi-region deployment
- On-premises installation
- Advanced BI & reporting

## License

Private - Not for redistribution

## Support

For issues and questions, contact the development team.

---

Built following SPARC methodology with TDD and minimal-diff principles.
