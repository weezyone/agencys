import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const tenant = await prisma.tenant.upsert({
    where: { id: 'seed-tenant' },
    update: {},
    create: { id: 'seed-tenant', name: 'Seed Co' },
  });
  const ws = await prisma.workspace.upsert({
    where: { id: 'seed-ws' },
    update: {},
    create: { id: 'seed-ws', tenantId: tenant.id, name: 'Default' },
  });
  const project = await prisma.project.upsert({
    where: { id: 'seed-proj' },
    update: {},
    create: { id: 'seed-proj', tenantId: tenant.id, name: 'Website' },
  });
  await prisma.budget.upsert({
    where: { projectId: project.id },
    update: { planned: 100000, alerts: [80,100,120] },
    create: { projectId: project.id, planned: 100000, alerts: [80,100,120] },
  });
  console.log('Seeded:', { tenant: tenant.id, ws: ws.id, project: project.id });
}

main().then(() => prisma.$disconnect());
