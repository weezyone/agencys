# Architecture

## System Overview

AgencyOS follows a modular monolithic architecture with optional database persistence.

```
┌─────────────┐
│   Client    │
└──────┬──────┘
       │ HTTP
┌──────▼──────────────────────┐
│     API Server (Node.js)    │
│  ┌────────────────────────┐ │
│  │  Multi-tenant Router   │ │
│  └────────────────────────┘ │
│  ┌────────────────────────┐ │
│  │   RBAC Middleware      │ │
│  └────────────────────────┘ │
│  ┌────────────────────────┐ │
│  │   Service Modules      │ │
│  │  • Tenancy             │ │
│  │  • Auth                │ │
│  │  • Projects            │ │
│  │  • Design              │ │
│  │  • Billing             │ │
│  │  • Notifications       │ │
│  └────────────────────────┘ │
└─────────────┬───────────────┘
              │
    ┌─────────▼──────────┐
    │  Persistence Layer │
    │  ┌──────────────┐  │
    │  │ In-Memory    │  │
    │  │   (default)  │  │
    │  └──────────────┘  │
    │  ┌──────────────┐  │
    │  │ Prisma/PG    │  │
    │  │  (optional)  │  │
    │  └──────────────┘  │
    └────────────────────┘
```

## Module Structure

Each module follows a consistent pattern:
- `entities.ts` - Domain types
- `service.ts` - Business logic (in-memory)
- `repo.prisma.ts` - Database persistence (optional)

## Data Flow

1. Request hits server with `x-user-id` header
2. RBAC middleware checks permissions
3. Service layer processes business logic
4. Persistence layer (in-memory or DB) stores data
5. Response returned to client

## Key Design Decisions

- **In-memory fallback**: Zero database setup for dev/testing
- **Module isolation**: Each module self-contained with clear interfaces
- **RBAC enforcement**: Permission checks at API route level
- **Event-driven ready**: Notification service prepared for async dispatch
- **Integration stubs**: OAuth/webhook handlers ready for real implementations

## Scalability Considerations

- Stateless services enable horizontal scaling
- Prisma connection pooling for DB performance
- Redis caching layer ready for session/queue management
- Multi-region deployment via DATABASE_URL configuration
