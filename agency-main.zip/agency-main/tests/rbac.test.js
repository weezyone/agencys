import assert from 'node:assert/strict';
import test from 'node:test';
import { RbacService } from '../dist/modules/rbac/service.js';

await test('rbac: role permissions and SUPER_ADMIN override', () => {
  const rbac = new RbacService();
  rbac.assign({ userId: 'u1', scope: { type: 'tenant', id: 't1' }, role: 'PM' });
  assert.equal(rbac.hasPermission('u1', { type: 'tenant', id: 't1' }, 'project:write'), true);
  assert.equal(rbac.hasPermission('u1', { type: 'tenant', id: 't1' }, 'billing:manage'), false);

  rbac.assign({ userId: 'u2', scope: { type: 'tenant', id: 't1' }, role: 'SUPER_ADMIN' });
  assert.equal(rbac.hasPermission('u2', { type: 'tenant', id: 't1' }, 'billing:manage'), true);
});
