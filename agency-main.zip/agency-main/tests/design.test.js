import assert from 'node:assert/strict';
import test from 'node:test';
import { DesignService } from '../dist/modules/design/service.js';

await test('design: create asset, annotate, approve', () => {
  const svc = new DesignService();
  const asset = svc.createAsset('proj1', 'https://figma.com/file/abc', 'abc');
  assert.equal(asset.version, 1);
  
  const ann = svc.addAnnotation(asset.id, 'u1', 'comment', 'Nice work', 100, 200);
  assert.equal(ann.content, 'Nice work');
  
  const list = svc.listAnnotations(asset.id);
  assert.equal(list.length, 1);
  
  const app = svc.approve(asset.id, 'u2', 'approved', 'LGTM');
  assert.equal(app.status, 'approved');
  
  const approvals = svc.getApprovals(asset.id);
  assert.equal(approvals.length, 1);
});
