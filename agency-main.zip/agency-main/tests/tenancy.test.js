import assert from 'node:assert/strict';
import test from 'node:test';
import { TenancyService } from '../dist/modules/tenancy/service.js';

await test('tenancy: create tenant, workspace, assign and list', () => {
  const tenancy = new TenancyService();
  const t = tenancy.createTenant('Acme');
  const ws = tenancy.createWorkspace(t.id, 'Core');
  tenancy.assignUserToWorkspace('u1', ws.id);
  const list = tenancy.listUserWorkspaces('u1');
  assert.equal(list.length, 1);
  assert.equal(list[0].id, ws.id);
  assert.equal(list[0].tenantId, t.id);
});
