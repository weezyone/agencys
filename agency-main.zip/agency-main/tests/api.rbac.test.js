import assert from 'node:assert/strict';
import test from 'node:test';

process.env.NODE_ENV = 'test';
const { default: server } = await import('../dist/server.js');

function listen(srv) {
  return new Promise((resolve) => srv.listen(0, () => resolve(srv.address().port)));
}

async function req(port, method, path, body, headers = {}) {
  const res = await fetch(`http://localhost:${port}${path}`, {
    method,
    headers: { 'content-type': 'application/json', ...headers },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  try { return { status: res.status, json: JSON.parse(text) }; } catch { return { status: res.status, text } }
}

await test('RBAC: deny/allow project routes by role', async () => {
  const port = await listen(server);
  const t = await req(port, 'POST', '/tenants', { name: 'Acme' });
  assert.equal(t.status, 201);
  const tenantId = t.json.id;

  // u2 without role cannot create project
  const deny = await req(port, 'POST', '/projects', { tenantId, name: 'Site' }, { 'x-user-id': 'u2' });
  assert.equal(deny.status, 403);

  // assign PM role to u1 on tenant
  const assign = await req(port, 'POST', '/_test/rbac-assign', { userId: 'u1', scopeType: 'tenant', scopeId: tenantId, role: 'PM' });
  assert.equal(assign.status, 204);

  // u1 can create project
  const allow = await req(port, 'POST', '/projects', { tenantId, name: 'Site' }, { 'x-user-id': 'u1' });
  assert.equal(allow.status, 201);
  const projectId = allow.json.id;

  // u2 cannot read tasks, u1 can
  const denyTasks = await req(port, 'GET', `/projects/${projectId}/tasks`, undefined, { 'x-user-id': 'u2' });
  assert.equal(denyTasks.status, 403);
  const okTasks = await req(port, 'GET', `/projects/${projectId}/tasks`, undefined, { 'x-user-id': 'u1' });
  assert.equal(okTasks.status, 200);
});
