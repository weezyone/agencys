import assert from 'node:assert/strict';
import test from 'node:test';
import { BillingService } from '../dist/modules/billing/service.js';

await test('billing: invoice creation, checkout, webhook payment', () => {
  const svc = new BillingService();
  const inv = svc.createInvoice('proj1', 50000);
  assert.equal(inv.status, 'draft');

  const session = svc.createCheckoutSession(inv.id);
  assert.ok(session.url.includes('checkout.stripe.com'));

  svc.handleStripeWebhook('checkout.session.completed', { metadata: { invoiceId: inv.id } });
  const updated = svc.getInvoice(inv.id);
  assert.equal(updated?.status, 'paid');
});
