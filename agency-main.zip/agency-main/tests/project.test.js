import assert from 'node:assert/strict';
import test from 'node:test';
import { ProjectService } from '../dist/modules/project/service.js';

await test('project: budget alerts 80/100/120', () => {
  const svc = new ProjectService();
  const p = svc.createProject('t1', 'Site');
  svc.setBudget(p.id, 100000, [80,100,120]);
  let r = svc.recordSpend(p.id, 85000); // 85%
  assert.deepEqual(r.triggered, [80]);
  r = svc.recordSpend(p.id, 15000); // 100%
  assert.deepEqual(r.triggered, [80,100]);
  r = svc.recordSpend(p.id, 25000); // 125%
  assert.deepEqual(r.triggered, [80,100,120]);
});

await test('project: tasks add and list', () => {
  const svc = new ProjectService();
  const p = svc.createProject('t1', 'App');
  const t1 = svc.addTask(p.id, 'Setup repo');
  const t2 = svc.addTask(p.id, 'Scaffold modules');
  const list = svc.listTasks(p.id);
  assert.equal(list.length, 2);
  assert.equal(list[0].id, t1.id);
  assert.equal(list[1].id, t2.id);
});
