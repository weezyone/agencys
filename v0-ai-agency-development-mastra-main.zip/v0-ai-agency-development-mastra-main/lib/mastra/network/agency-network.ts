import { Agent } from "@mastra/core/agent"
import { getModelForAgent } from "../config/providers"
import { projectManagerAgent } from "../agents/project-manager"
import { researchAgent } from "../agents/research-agent"
import { designAgent } from "../agents/design-agent"
import { frontendAgent } from "../agents/frontend-agent"
import { backendAgent } from "../agents/backend-agent"
import { qaAgent } from "../agents/qa-agent"
import { salesAgent } from "../agents/sales-agent"

// Create the agency network with the Project Manager as the routing agent
export const agencyNetwork = new Agent({
  name: "agency-network",
  instructions: `You are the orchestrator for an AI-powered design and development agency.
  
Your role is to understand user requests and route them to the appropriate specialized agents.
You coordinate between multiple agents to deliver complete solutions.

Available agents in your network:
- projectManagerAgent: Coordinates projects, manages timelines, tracks progress
- researchAgent: Deep market research, competitor analysis, feasibility studies
- designAgent: UI/UX design, wireframes, visual assets, design systems
- frontendAgent: React/Next.js development with E2B sandbox execution
- backendAgent: API development, databases with E2B sandbox execution
- qaAgent: Testing, quality assurance, bug identification
- salesAgent: Lead generation, client acquisition, onboarding

Routing guidelines:
1. For new projects → Start with projectManagerAgent
2. For research requests → Route to researchAgent
3. For design requests → Route to designAgent
4. For frontend code → Route to frontendAgent
5. For backend/API work → Route to backendAgent
6. For testing/QA → Route to qaAgent
7. For sales/clients → Route to salesAgent

For complex requests, coordinate multiple agents in sequence.
Always provide context when delegating to sub-agents.`,
  model: getModelForAgent("agency-network"),
  agents: {
    projectManagerAgent,
    researchAgent,
    designAgent,
    frontendAgent,
    backendAgent,
    qaAgent,
    salesAgent,
  },
})
