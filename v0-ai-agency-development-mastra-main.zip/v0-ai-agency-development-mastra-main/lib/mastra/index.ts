import { Mastra } from "@mastra/core/mastra"
import { projectManagerAgent } from "./agents/project-manager"
import { researchAgent } from "./agents/research-agent"
import { designAgent } from "./agents/design-agent"
import { frontendAgent } from "./agents/frontend-agent"
import { backendAgent } from "./agents/backend-agent"
import { qaAgent } from "./agents/qa-agent"
import { salesAgent } from "./agents/sales-agent"

export const mastra = new Mastra({
  agents: {
    projectManagerAgent,
    researchAgent,
    designAgent,
    frontendAgent,
    backendAgent,
    qaAgent,
    salesAgent,
  },
})

// Export individual agents for direct access
export { projectManagerAgent, researchAgent, designAgent, frontendAgent, backendAgent, qaAgent, salesAgent }
