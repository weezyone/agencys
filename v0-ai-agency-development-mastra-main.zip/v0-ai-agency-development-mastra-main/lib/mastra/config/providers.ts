/**
 * LLM Provider Configuration for the AI Agency
 *
 * Supported providers:
 * - OpenRouter: Access to many models through a single API (OPENROUTER_API_KEY)
 * - HuggingFace: Access to HF inference models (HF_TOKEN)
 * - OpenAI: Direct OpenAI access (OPENAI_API_KEY)
 *
 * Model format: "provider/model-name"
 * Examples:
 * - "openrouter/openai/gpt-oss-120b"
 * - "huggingface/deepseek-ai/DeepSeek-V3.2"
 * - "openai/gpt-4o"
 */

export type Provider = "openrouter" | "huggingface" | "openai"

export interface ModelConfig {
  provider: Provider
  model: string
  displayName: string
  description?: string
}

// Available models configuration
export const MODELS = {
  // OpenRouter models
  "openrouter/openai/gpt-oss-120b": {
    provider: "openrouter" as Provider,
    model: "openrouter/openai/gpt-oss-120b",
    displayName: "GPT-OSS 120B (OpenRouter)",
    description: "Large open-source model via OpenRouter",
  },
  "openrouter/anthropic/claude-3.5-sonnet": {
    provider: "openrouter" as Provider,
    model: "openrouter/anthropic/claude-3.5-sonnet",
    displayName: "Claude 3.5 Sonnet (OpenRouter)",
    description: "Anthropic Claude via OpenRouter",
  },
  "openrouter/meta-llama/llama-3.1-405b-instruct": {
    provider: "openrouter" as Provider,
    model: "openrouter/meta-llama/llama-3.1-405b-instruct",
    displayName: "Llama 3.1 405B (OpenRouter)",
    description: "Meta Llama via OpenRouter",
  },

  // HuggingFace models
  "huggingface/deepseek-ai/DeepSeek-V3.2": {
    provider: "huggingface" as Provider,
    model: "huggingface/deepseek-ai/DeepSeek-V3.2",
    displayName: "DeepSeek V3.2",
    description: "DeepSeek model via HuggingFace Inference",
  },
  "huggingface/MiniMaxAI/MiniMax-M2.1": {
    provider: "huggingface" as Provider,
    model: "huggingface/MiniMaxAI/MiniMax-M2.1",
    displayName: "MiniMax M2.1",
    description: "MiniMax model via HuggingFace Inference",
  },
  "huggingface/Qwen/Qwen2.5-72B-Instruct": {
    provider: "huggingface" as Provider,
    model: "huggingface/Qwen/Qwen2.5-72B-Instruct",
    displayName: "Qwen 2.5 72B",
    description: "Qwen model via HuggingFace Inference",
  },

  // OpenAI models (direct)
  "openai/gpt-4o": {
    provider: "openai" as Provider,
    model: "openai/gpt-4o",
    displayName: "GPT-4o",
    description: "OpenAI GPT-4o",
  },
  "openai/gpt-4o-mini": {
    provider: "openai" as Provider,
    model: "openai/gpt-4o-mini",
    displayName: "GPT-4o Mini",
    description: "OpenAI GPT-4o Mini (faster, cheaper)",
  },
} as const

// Default model for all agents
export const DEFAULT_MODEL = "openrouter/openai/gpt-oss-120b"

// Agent-specific model overrides (optional)
export const AGENT_MODELS = {
  "project-manager": DEFAULT_MODEL,
  "deep-research": DEFAULT_MODEL,
  "design-agent": DEFAULT_MODEL,
  "frontend-agent": DEFAULT_MODEL,
  "backend-agent": DEFAULT_MODEL,
  "qa-agent": DEFAULT_MODEL,
  "sales-team": DEFAULT_MODEL,
  "agency-network": DEFAULT_MODEL,
} as const

// Helper to get model for an agent
export function getModelForAgent(agentName: keyof typeof AGENT_MODELS): string {
  return AGENT_MODELS[agentName] || DEFAULT_MODEL
}

// Environment variables required for each provider
export const PROVIDER_ENV_VARS = {
  openrouter: "OPENROUTER_API_KEY",
  huggingface: "HF_TOKEN",
  openai: "OPENAI_API_KEY",
} as const
