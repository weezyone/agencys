import { createTool } from "@mastra/core/tools"
import { z } from "zod"

export const designGenerationTool = createTool({
  id: "design-generation",
  description: "Generate design specifications, wireframes descriptions, and component designs based on requirements.",
  inputSchema: z.object({
    type: z.enum(["wireframe", "component", "layout", "color-scheme"]).describe("Type of design to generate"),
    description: z.string().describe("Description of the design requirements"),
    style: z.string().optional().describe("Design style preferences (modern, minimal, bold, etc.)"),
  }),
  outputSchema: z.object({
    design: z.string().describe("The generated design specification"),
    components: z.array(z.string()).optional().describe("List of components in the design"),
    notes: z.string().optional().describe("Additional design notes and recommendations"),
  }),
  execute: async ({ context }) => {
    const { type, description, style } = context

    return {
      design: `Design specification for ${type}: ${description}`,
      components: ["header", "main-content", "sidebar", "footer"],
      notes: style ? `Applied ${style} style guidelines` : "Used default style guidelines",
    }
  },
})
