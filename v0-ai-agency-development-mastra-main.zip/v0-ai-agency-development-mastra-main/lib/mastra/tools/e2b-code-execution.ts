import { createTool } from "@mastra/core/tools"
import { z } from "zod"

export const e2bCodeExecutionTool = createTool({
  id: "e2b-code-execution",
  description: `Execute JavaScript/TypeScript code in an isolated E2B sandbox environment. 
Use this tool to run and test code safely without affecting the production environment.
Supports npm packages, TypeScript, ESM imports, and top-level await.`,
  inputSchema: z.object({
    code: z.string().describe("The JavaScript or TypeScript code to execute"),
    language: z.enum(["javascript", "typescript", "js", "ts"]).default("typescript").describe("Programming language"),
    packages: z.array(z.string()).optional().describe("NPM packages to install before execution"),
  }),
  outputSchema: z.object({
    success: z.boolean(),
    output: z.string().optional(),
    error: z.string().optional(),
    executionTime: z.number().optional(),
  }),
  execute: async ({ context }) => {
    const { code, language, packages } = context

    try {
      // Dynamic import to avoid issues if E2B is not installed
      const { Sandbox } = await import("@e2b/code-interpreter")

      // Create sandbox
      const sbx = await Sandbox.create()

      // Install packages if specified
      if (packages && packages.length > 0) {
        await sbx.commands.run(`npm install ${packages.join(" ")}`)
      }

      const startTime = Date.now()

      // Execute code
      const execution = await sbx.runCode(code, {
        language: language === "js" ? "javascript" : language === "ts" ? "typescript" : language,
      })

      const executionTime = Date.now() - startTime

      // Kill sandbox after use
      await sbx.kill()

      // Check for errors
      if (execution.error) {
        return {
          success: false,
          error: execution.error.message || "Execution failed",
          executionTime,
        }
      }

      return {
        success: true,
        output: execution.text || execution.logs.stdout.join("\n"),
        executionTime,
      }
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error occurred",
      }
    }
  },
})
