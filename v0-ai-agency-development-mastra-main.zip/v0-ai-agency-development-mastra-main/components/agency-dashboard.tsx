"use client"

import { useState } from "react"
import { Sidebar } from "@/components/sidebar"
import { AgentGrid } from "@/components/agent-grid"
import { ProjectsPanel } from "@/components/projects-panel"
import { ChatInterface } from "@/components/chat-interface"
import { ClientsPanel } from "@/components/clients-panel"

type View = "agents" | "projects" | "clients" | "chat"

export function AgencyDashboard() {
  const [activeView, setActiveView] = useState<View>("agents")

  return (
    <div className="flex h-screen bg-background">
      <Sidebar activeView={activeView} onViewChange={setActiveView} />
      <main className="flex-1 overflow-hidden">
        {activeView === "agents" && <AgentGrid />}
        {activeView === "projects" && <ProjectsPanel />}
        {activeView === "clients" && <ClientsPanel />}
        {activeView === "chat" && <ChatInterface />}
      </main>
    </div>
  )
}
