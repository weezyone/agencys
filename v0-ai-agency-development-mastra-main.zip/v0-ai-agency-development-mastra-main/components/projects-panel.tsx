"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Clock, MoreVertical } from "lucide-react"
import { Button } from "@/components/ui/button"

const projects = [
  {
    id: 1,
    name: "E-commerce Platform Redesign",
    client: "TechCorp Inc.",
    status: "in-progress" as const,
    progress: 65,
    deadline: "Dec 15, 2025",
    agents: ["design", "frontend", "backend"],
  },
  {
    id: 2,
    name: "Mobile App Development",
    client: "StartupXYZ",
    status: "in-progress" as const,
    progress: 40,
    deadline: "Jan 20, 2026",
    agents: ["frontend", "backend", "qa"],
  },
  {
    id: 3,
    name: "Brand Identity System",
    client: "Creative Studios",
    status: "review" as const,
    progress: 90,
    deadline: "Dec 10, 2025",
    agents: ["design", "research"],
  },
  {
    id: 4,
    name: "SaaS Dashboard",
    client: "DataFlow Ltd.",
    status: "planning" as const,
    progress: 15,
    deadline: "Feb 1, 2026",
    agents: ["research", "design"],
  },
]

const statusColors = {
  planning: "bg-amber-500/10 text-amber-500 border-amber-500/20",
  "in-progress": "bg-blue-500/10 text-blue-500 border-blue-500/20",
  review: "bg-purple-500/10 text-purple-500 border-purple-500/20",
  completed: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20",
}

export function ProjectsPanel() {
  return (
    <div className="p-6 h-full overflow-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Active Projects</h2>
          <p className="text-muted-foreground text-sm mt-1">Track project progress and agent assignments</p>
        </div>
        <Button>New Project</Button>
      </div>

      <div className="space-y-4">
        {projects.map((project) => (
          <Card key={project.id} className="bg-card border-border">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <CardTitle className="text-base">{project.name}</CardTitle>
                  <p className="text-sm text-muted-foreground">{project.client}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className={statusColors[project.status]}>
                    {project.status.replace("-", " ")}
                  </Badge>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Progress</span>
                  <span className="font-medium">{project.progress}%</span>
                </div>
                <Progress value={project.progress} className="h-2" />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">Agents:</span>
                  <div className="flex -space-x-2">
                    {project.agents.map((agent) => (
                      <Avatar key={agent} className="w-6 h-6 border-2 border-background">
                        <AvatarFallback className="text-[10px] bg-primary text-primary-foreground">
                          {agent[0].toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                    ))}
                  </div>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <Clock className="w-3 h-3" />
                  {project.deadline}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
