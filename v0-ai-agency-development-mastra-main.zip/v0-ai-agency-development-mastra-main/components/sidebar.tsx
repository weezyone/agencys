"use client"

import { cn } from "@/lib/utils"
import { Bot, Users, FolderKanban, MessageSquare, Settings, Zap } from "lucide-react"

type View = "agents" | "projects" | "clients" | "chat"

interface SidebarProps {
  activeView: View
  onViewChange: (view: View) => void
}

const navItems = [
  { id: "agents" as const, label: "Agents", icon: Bot },
  { id: "projects" as const, label: "Projects", icon: FolderKanban },
  { id: "clients" as const, label: "Clients", icon: Users },
  { id: "chat" as const, label: "Chat", icon: MessageSquare },
]

export function Sidebar({ activeView, onViewChange }: SidebarProps) {
  return (
    <aside className="w-64 border-r border-border bg-card flex flex-col">
      <div className="p-6 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center">
            <Zap className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="font-semibold text-foreground">AI Agency</h1>
            <p className="text-xs text-muted-foreground">Mastra + E2B</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onViewChange(item.id)}
            className={cn(
              "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
              activeView === item.id
                ? "bg-accent text-accent-foreground"
                : "text-muted-foreground hover:text-foreground hover:bg-accent/50",
            )}
          >
            <item.icon className="w-4 h-4" />
            {item.label}
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-border">
        <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-accent/50 transition-colors">
          <Settings className="w-4 h-4" />
          Settings
        </button>
      </div>
    </aside>
  )
}
