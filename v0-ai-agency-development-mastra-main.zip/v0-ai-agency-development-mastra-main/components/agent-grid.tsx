"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Brain, Search, Palette, Code2, Server, TestTube2, Handshake, Play, Pause, Activity } from "lucide-react"

const agents = [
  {
    id: "project-manager",
    name: "Project Manager",
    description: "Orchestrates all agents, manages timelines, and coordinates project delivery",
    icon: Brain,
    status: "active" as const,
    model: "gpt-4o",
    tasks: 12,
    color: "bg-blue-500/10 text-blue-500 border-blue-500/20",
  },
  {
    id: "research",
    name: "Deep Research",
    description: "Conducts market research, competitor analysis, and technical feasibility studies",
    icon: Search,
    status: "active" as const,
    model: "gpt-4o",
    tasks: 8,
    color: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20",
  },
  {
    id: "design",
    name: "Design Agent",
    description: "Creates UI/UX designs, wireframes, and visual assets for projects",
    icon: Palette,
    status: "idle" as const,
    model: "gpt-4o",
    tasks: 5,
    color: "bg-pink-500/10 text-pink-500 border-pink-500/20",
  },
  {
    id: "frontend",
    name: "Frontend Agent",
    description: "Builds React/Next.js applications with E2B sandbox execution",
    icon: Code2,
    status: "active" as const,
    model: "gpt-4o",
    tasks: 15,
    color: "bg-amber-500/10 text-amber-500 border-amber-500/20",
  },
  {
    id: "backend",
    name: "Backend Agent",
    description: "Develops APIs, databases, and server-side logic with E2B execution",
    icon: Server,
    status: "idle" as const,
    model: "gpt-4o",
    tasks: 10,
    color: "bg-indigo-500/10 text-indigo-500 border-indigo-500/20",
  },
  {
    id: "qa",
    name: "QA Agent",
    description: "Tests code, identifies bugs, and ensures quality standards are met",
    icon: TestTube2,
    status: "idle" as const,
    model: "gpt-4o-mini",
    tasks: 7,
    color: "bg-red-500/10 text-red-500 border-red-500/20",
  },
  {
    id: "sales",
    name: "Sales Team",
    description: "Finds leads, qualifies prospects, and closes new client deals",
    icon: Handshake,
    status: "active" as const,
    model: "gpt-4o",
    tasks: 20,
    color: "bg-teal-500/10 text-teal-500 border-teal-500/20",
  },
]

export function AgentGrid() {
  const [agentStatuses, setAgentStatuses] = useState(
    agents.reduce((acc, agent) => ({ ...acc, [agent.id]: agent.status }), {} as Record<string, "active" | "idle">),
  )

  const toggleAgent = (id: string) => {
    setAgentStatuses((prev) => ({
      ...prev,
      [id]: prev[id] === "active" ? "idle" : "active",
    }))
  }

  return (
    <div className="p-6 h-full overflow-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Agent Network</h2>
          <p className="text-muted-foreground text-sm mt-1">Manage your AI agents powered by Mastra.ai</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="gap-1.5">
            <Activity className="w-3 h-3" />
            {Object.values(agentStatuses).filter((s) => s === "active").length} Active
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {agents.map((agent) => {
          const status = agentStatuses[agent.id]
          return (
            <Card key={agent.id} className="bg-card border-border hover:border-primary/50 transition-colors">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className={`w-10 h-10 rounded-lg border flex items-center justify-center ${agent.color}`}>
                    <agent.icon className="w-5 h-5" />
                  </div>
                  <Badge variant={status === "active" ? "default" : "secondary"} className="text-xs">
                    {status}
                  </Badge>
                </div>
                <CardTitle className="text-base mt-3">{agent.name}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground line-clamp-2">{agent.description}</p>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>Model: {agent.model}</span>
                  <span>{agent.tasks} tasks</span>
                </div>
                <Button
                  variant={status === "active" ? "secondary" : "default"}
                  size="sm"
                  className="w-full"
                  onClick={() => toggleAgent(agent.id)}
                >
                  {status === "active" ? (
                    <>
                      <Pause className="w-3 h-3 mr-2" />
                      Pause Agent
                    </>
                  ) : (
                    <>
                      <Play className="w-3 h-3 mr-2" />
                      Activate Agent
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
