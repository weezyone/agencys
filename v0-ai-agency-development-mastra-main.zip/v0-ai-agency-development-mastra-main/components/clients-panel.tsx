"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Mail, Phone, Building2, DollarSign, TrendingUp, UserPlus } from "lucide-react"

const clients = [
  {
    id: 1,
    name: "TechCorp Inc.",
    contact: "John Smith",
    email: "john@techcorp.com",
    phone: "+1 555-0123",
    status: "active" as const,
    projects: 3,
    revenue: "$125,000",
  },
  {
    id: 2,
    name: "StartupXYZ",
    contact: "Sarah Johnson",
    email: "sarah@startupxyz.io",
    phone: "+1 555-0456",
    status: "active" as const,
    projects: 1,
    revenue: "$45,000",
  },
  {
    id: 3,
    name: "Creative Studios",
    contact: "Mike Chen",
    email: "mike@creativestudios.co",
    phone: "+1 555-0789",
    status: "prospect" as const,
    projects: 0,
    revenue: "$0",
  },
  {
    id: 4,
    name: "DataFlow Ltd.",
    contact: "Emily Brown",
    email: "emily@dataflow.com",
    phone: "+1 555-0321",
    status: "onboarding" as const,
    projects: 1,
    revenue: "$75,000",
  },
]

const leads = [
  { name: "Acme Corp", score: 85, source: "Outbound" },
  { name: "GlobalTech", score: 72, source: "Referral" },
  { name: "InnovateLabs", score: 68, source: "Inbound" },
]

const statusColors = {
  prospect: "bg-amber-500/10 text-amber-500 border-amber-500/20",
  onboarding: "bg-blue-500/10 text-blue-500 border-blue-500/20",
  active: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20",
}

export function ClientsPanel() {
  return (
    <div className="p-6 h-full overflow-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Client Management</h2>
          <p className="text-muted-foreground text-sm mt-1">Manage clients and track sales pipeline</p>
        </div>
        <Button>
          <UserPlus className="w-4 h-4 mr-2" />
          Add Client
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <h3 className="font-semibold text-foreground">Active Clients</h3>
          {clients.map((client) => (
            <Card key={client.id} className="bg-card border-border">
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-10 h-10">
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        {client.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h4 className="font-medium text-foreground">{client.name}</h4>
                      <p className="text-sm text-muted-foreground">{client.contact}</p>
                    </div>
                  </div>
                  <Badge variant="outline" className={statusColors[client.status]}>
                    {client.status}
                  </Badge>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Mail className="w-3.5 h-3.5" />
                    {client.email}
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Phone className="w-3.5 h-3.5" />
                    {client.phone}
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Building2 className="w-3.5 h-3.5" />
                    {client.projects} projects
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <DollarSign className="w-3.5 h-3.5" />
                    {client.revenue}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="space-y-4">
          <h3 className="font-semibold text-foreground">Hot Leads</h3>
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-500" />
                Sales Pipeline
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {leads.map((lead) => (
                <div key={lead.name} className="flex items-center justify-between p-2 rounded-lg bg-accent/50">
                  <div>
                    <p className="font-medium text-sm text-foreground">{lead.name}</p>
                    <p className="text-xs text-muted-foreground">{lead.source}</p>
                  </div>
                  <Badge variant="secondary">{lead.score}%</Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
