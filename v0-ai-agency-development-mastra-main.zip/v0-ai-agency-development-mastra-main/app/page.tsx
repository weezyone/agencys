import { AgencyDashboard } from "@/components/agency-dashboard"

export default function Home() {
  return <AgencyDashboard />
}
