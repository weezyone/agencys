import { mastra } from "@/lib/mastra"
import { streamText } from "ai"

export async function POST(request: Request) {
  const { messages } = await request.json()

  // Get the project manager agent as the main coordinator
  const agent = mastra.getAgent("projectManagerAgent")

  const result = await streamText({
    model: agent.model,
    system: agent.instructions as string,
    messages,
  })

  return result.toUIMessageStreamResponse()
}
