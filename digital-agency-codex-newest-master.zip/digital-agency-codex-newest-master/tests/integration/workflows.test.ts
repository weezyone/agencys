import { describe, expect, it } from "vitest";
import { runAgencyDeliveryLogic } from "@/mastra/workflows/agency-delivery";
import { runClientPipelineLogic } from "@/mastra/workflows/client-pipeline";
import { runProjectLifecycleLogic } from "@/mastra/workflows/project-lifecycle";

describe("workflow integration logic", () => {
  it("client-pipeline branches by leadScore", () => {
    expect(
      runClientPipelineLogic({ company: "Acme", leadScore: 85 }).pipelineStage,
    ).toBe("onboarded");
    expect(
      runClientPipelineLogic({ company: "Beta", leadScore: 55 }).pipelineStage,
    ).toBe("nurturing");
    expect(
      runClientPipelineLogic({ company: "Gamma", leadScore: 10 }).pipelineStage,
    ).toBe("churned");
  });

  it("project-lifecycle reaches delivered", () => {
    const result = runProjectLifecycleLogic({
      projectName: "Portal",
      clientInput: "Build a client portal",
    });
    expect(result.status).toBe("delivered");
    expect(result.completedTasks).toContain("QA");
  });

  it("agency-delivery hands off to PM with scaffold tasks", () => {
    const result = runAgencyDeliveryLogic({
      clientInput: "Need MVP",
      features: ["auth", "billing"],
    });
    expect(result.owner).toBe("project-manager");
    expect(result.tasks).toEqual(["Ship auth", "Ship billing"]);
  });
});
