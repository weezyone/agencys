import { describe, expect, it } from "vitest";
import {
  clientInputSchema,
  projectInputSchema,
} from "@/lib/db/schemas/api";

describe("API validation schemas", () => {
  describe("projectInputSchema", () => {
    it("accepts valid project input", () => {
      const result = projectInputSchema.safeParse({
        name: "Acme Rebrand",
        clientId: "507f1f77bcf86cd799439011",
        status: "active" as const,
        description: "Full rebrand",
      });
      expect(result.success).toBe(true);
    });

    it("rejects missing name", () => {
      const result = projectInputSchema.safeParse({
        clientId: "507f1f77bcf86cd799439011",
      });
      expect(result.success).toBe(false);
    });

    it("rejects missing clientId", () => {
      const result = projectInputSchema.safeParse({
        name: "No Client",
      });
      expect(result.success).toBe(false);
    });

    it("rejects invalid status", () => {
      const result = projectInputSchema.safeParse({
        name: "Bad Status",
        clientId: "507f1f77bcf86cd799439011",
        status: "not-a-status",
      });
      expect(result.success).toBe(false);
    });
  });

  describe("clientInputSchema", () => {
    it("accepts valid client input", () => {
      const result = clientInputSchema.safeParse({
        name: "Jane Doe",
        email: "jane@acme.com",
        company: "Acme",
        leadScore: 75,
      });
      expect(result.success).toBe(true);
    });

    it("rejects invalid email", () => {
      const result = clientInputSchema.safeParse({
        name: "Jane",
        email: "not-an-email",
      });
      expect(result.success).toBe(false);
    });
  });
});
