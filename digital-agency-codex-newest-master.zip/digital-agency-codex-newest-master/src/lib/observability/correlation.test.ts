import { describe, expect, it } from "vitest";
import {
  createCorrelationId,
  getCorrelationId,
  runWithCorrelation,
  runWithCorrelationAsync,
} from "./correlation";

describe("correlation", () => {
  it("creates uuid-like ids", () => {
    const id = createCorrelationId();
    expect(id).toMatch(
      /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i,
    );
  });

  it("propagates correlation id in sync context", () => {
    const result = runWithCorrelation("corr-1", () => getCorrelationId());
    expect(result).toBe("corr-1");
    expect(getCorrelationId()).toBeUndefined();
  });

  it("propagates correlation id in async context", async () => {
    const result = await runWithCorrelationAsync("corr-2", async () => {
      await Promise.resolve();
      return getCorrelationId();
    });
    expect(result).toBe("corr-2");
  });
});
