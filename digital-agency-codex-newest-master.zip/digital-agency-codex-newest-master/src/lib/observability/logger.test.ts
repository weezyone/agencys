import { describe, expect, it } from "vitest";
import { redactSecrets } from "./logger";

describe("redactSecrets", () => {
  it("redacts secret-like keys and openai-style tokens", () => {
    const result = redactSecrets({
      apiKey: "secret-value",
      nested: { token: "abc", safe: "ok" },
      note: "uses sk-abcdefghijklmnopqrstuvwxyz",
    }) as Record<string, unknown>;

    expect(result.apiKey).toBe("[REDACTED]");
    expect((result.nested as Record<string, unknown>).token).toBe("[REDACTED]");
    expect((result.nested as Record<string, unknown>).safe).toBe("ok");
    expect(result.note).toBe("[REDACTED]");
  });
});
