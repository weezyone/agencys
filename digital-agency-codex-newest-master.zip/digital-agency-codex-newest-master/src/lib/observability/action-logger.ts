import { AgentActionLog } from "@/lib/db/models";
import { getCorrelationId } from "./correlation";
import { logger } from "./logger";

export type ActionLogPhase = "before" | "after" | "error";

export type ActionLogInput = {
  agentName: string;
  toolName?: string;
  phase: ActionLogPhase;
  input?: unknown;
  output?: unknown;
  error?: string;
  durationMs?: number;
  projectId?: string;
  userId?: string;
  metadata?: Record<string, unknown>;
  correlationId?: string;
};

/**
 * Append-only stub — persists when DB is available; always logs structured event.
 */
export async function appendActionLog(entry: ActionLogInput): Promise<void> {
  const correlationId =
    entry.correlationId ?? getCorrelationId() ?? "unknown";

  logger.info("agent.action", {
    ...entry,
    correlationId,
  });

  try {
    await AgentActionLog.create({
      correlationId,
      agentName: entry.agentName,
      toolName: entry.toolName,
      phase: entry.phase,
      input: entry.input,
      output: entry.output,
      error: entry.error,
      durationMs: entry.durationMs,
      projectId: entry.projectId,
      userId: entry.userId,
      metadata: entry.metadata ?? {},
    });
  } catch (error) {
    // Stub tolerance: observability must not break request paths before M3 hooks.
    logger.warn("agent.action.persist_failed", {
      correlationId,
      error: error instanceof Error ? error.message : String(error),
    });
  }
}
