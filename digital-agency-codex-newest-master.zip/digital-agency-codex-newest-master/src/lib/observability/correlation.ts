import { AsyncLocalStorage } from "node:async_hooks";
import { randomUUID } from "node:crypto";

export type CorrelationStore = {
  correlationId: string;
};

const storage = new AsyncLocalStorage<CorrelationStore>();

export function getCorrelationId(): string | undefined {
  return storage.getStore()?.correlationId;
}

export function runWithCorrelation<T>(
  correlationId: string | undefined,
  fn: () => T,
): T {
  const id = correlationId?.trim() || randomUUID();
  return storage.run({ correlationId: id }, fn);
}

export async function runWithCorrelationAsync<T>(
  correlationId: string | undefined,
  fn: () => Promise<T>,
): Promise<T> {
  const id = correlationId?.trim() || randomUUID();
  return storage.run({ correlationId: id }, fn);
}

export function createCorrelationId(): string {
  return randomUUID();
}
