import { describe, expect, it } from "vitest";
import {
  assertClientScope,
  AuthenticationError,
  AuthorizationError,
  hasRole,
  isAtLeastRole,
  requireRole,
} from "./rbac";

describe("rbac", () => {
  const adminSession = {
    user: { id: "1", role: "admin" as const, clientId: null },
  };
  const clientSession = {
    user: { id: "2", role: "client" as const, clientId: "c1" },
  };

  it("hasRole checks membership", () => {
    expect(hasRole(adminSession, ["admin"])).toBe(true);
    expect(hasRole(clientSession, ["admin"])).toBe(false);
    expect(hasRole(null, ["admin"])).toBe(false);
  });

  it("requireRole throws auth/authz errors", () => {
    expect(() => requireRole(null, ["admin"])).toThrow(AuthenticationError);
    expect(() => requireRole(clientSession, ["admin"])).toThrow(
      AuthorizationError,
    );
    expect(requireRole(adminSession, ["admin"]).id).toBe("1");
  });

  it("isAtLeastRole respects rank", () => {
    expect(isAtLeastRole(adminSession, "agent-operator")).toBe(true);
    expect(isAtLeastRole(clientSession, "agent-operator")).toBe(false);
  });

  it("assertClientScope enforces portal row access", () => {
    expect(() => assertClientScope(clientSession, "c1")).not.toThrow();
    expect(() => assertClientScope(clientSession, "other")).toThrow(
      AuthorizationError,
    );
    expect(() => assertClientScope(adminSession, "other")).not.toThrow();
  });
});
