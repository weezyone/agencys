import type { UserRole } from "@/lib/db/models/types";

export type SessionLike = {
  user?: {
    id?: string;
    role?: UserRole;
    clientId?: string | null;
  } | null;
} | null;

export class AuthorizationError extends Error {
  readonly status = 403;

  constructor(message = "Forbidden") {
    super(message);
    this.name = "AuthorizationError";
  }
}

export class AuthenticationError extends Error {
  readonly status = 401;

  constructor(message = "Unauthorized") {
    super(message);
    this.name = "AuthenticationError";
  }
}

const ROLE_RANK: Record<UserRole, number> = {
  client: 1,
  "agent-operator": 2,
  admin: 3,
};

export function hasRole(
  session: SessionLike,
  allowed: readonly UserRole[],
): boolean {
  const role = session?.user?.role;
  if (!role) return false;
  return allowed.includes(role);
}

export function requireRole(
  session: SessionLike,
  allowed: readonly UserRole[],
): NonNullable<NonNullable<SessionLike>["user"]> {
  if (!session?.user?.id) {
    throw new AuthenticationError();
  }
  if (!hasRole(session, allowed)) {
    throw new AuthorizationError(
      `Requires one of roles: ${allowed.join(", ")}`,
    );
  }
  return session.user;
}

export function isAtLeastRole(
  session: SessionLike,
  minimum: UserRole,
): boolean {
  const role = session?.user?.role;
  if (!role) return false;
  return ROLE_RANK[role] >= ROLE_RANK[minimum];
}

/**
 * Portal row-level scope: clients may only access their own clientId.
 * Admins and agent-operators are unrestricted.
 */
export function assertClientScope(
  session: SessionLike,
  clientId: string,
): void {
  const user = requireRole(session, ["admin", "agent-operator", "client"]);
  if (user.role === "client" && user.clientId !== clientId) {
    throw new AuthorizationError("Client scope violation");
  }
}
