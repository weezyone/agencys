import type { NextAuthConfig } from "next-auth";
import Credentials from "next-auth/providers/credentials";
import { USER_ROLES, type UserRole } from "@/lib/db/models/types";

function isUserRole(value: unknown): value is UserRole {
  return (
    typeof value === "string" &&
    (USER_ROLES as readonly string[]).includes(value)
  );
}

/**
 * Edge-safe Auth.js config (no Node-only adapters).
 * Full Node config with MongoDB adapter lives in `auth.ts`.
 */
export const authConfig = {
  providers: [
    Credentials({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        // Dev/skeleton only — replace with real credential verification in M7+.
        role: { label: "Role", type: "text" },
      },
      authorize: async (credentials) => {
        const email =
          typeof credentials?.email === "string"
            ? credentials.email.trim().toLowerCase()
            : "";
        if (!email) return null;

        const role = isUserRole(credentials?.role)
          ? credentials.role
          : "client";

        return {
          id: email,
          email,
          name: email.split("@")[0] ?? email,
          role,
          clientId: null,
        };
      },
    }),
  ],
  session: { strategy: "jwt" },
  pages: {
    signIn: "/login",
  },
  callbacks: {
    jwt({ token, user }) {
      if (user) {
        token.role = isUserRole(user.role) ? user.role : "client";
        token.clientId = user.clientId ?? null;
        token.sub = user.id;
      }
      return token;
    },
    session({ session, token }) {
      if (session.user) {
        session.user.id = token.sub ?? "";
        session.user.role = isUserRole(token.role) ? token.role : "client";
        session.user.clientId =
          typeof token.clientId === "string" ? token.clientId : null;
      }
      return session;
    },
  },
} satisfies NextAuthConfig;
