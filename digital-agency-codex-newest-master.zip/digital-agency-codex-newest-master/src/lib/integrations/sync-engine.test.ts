import { describe, expect, it } from "vitest";
import { reconcileFields } from "./sync-engine";

describe("reconcileFields", () => {
  it("merges with last-writer-wins and tracks conflicts", () => {
    const { merged, conflicts } = reconcileFields(
      { title: "New", status: "done" },
      { title: "Old", status: "todo", description: "keep" },
    );
    expect(merged.title).toBe("New");
    expect(merged.status).toBe("done");
    expect(merged.description).toBe("keep");
    expect(conflicts).toContain("title");
    expect(conflicts).toContain("status");
  });
});
