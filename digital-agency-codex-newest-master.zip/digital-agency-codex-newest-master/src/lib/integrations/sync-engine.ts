import { createHash } from "node:crypto";
import { logger } from "@/lib/observability/logger";
import { withResilience } from "@/lib/resilience";
import {
  buildChecksum,
  getSyncMap,
  upsertSyncMap,
  type ExternalIds,
  type SyncEntityType,
} from "./id-map";

export type SyncPayload = {
  entityType: SyncEntityType;
  internalId: string;
  title: string;
  status: string;
  description?: string;
  fields?: Record<string, unknown>;
};

export type SyncResult = {
  reconciled: boolean;
  conflict: boolean;
  escalateToPm: boolean;
  checksum: string;
  external: ExternalIds;
  reason?: string;
};

type TrackerWrite = (payload: SyncPayload) => Promise<string>;

const fieldChecksum = (field: string, value: unknown): string =>
  createHash("sha256").update(`${field}:${JSON.stringify(value)}`).digest("hex");

/** Deterministic last-writer-wins per-field; escalate unresolved conflicts to PM. */
export const reconcileFields = (
  incoming: Record<string, unknown>,
  existing: Record<string, unknown>,
): { merged: Record<string, unknown>; conflicts: string[] } => {
  const keys = new Set([...Object.keys(incoming), ...Object.keys(existing)]);
  const merged: Record<string, unknown> = { ...existing };
  const conflicts: string[] = [];

  for (const key of keys) {
    if (!(key in incoming)) {
      continue;
    }
    if (!(key in existing)) {
      merged[key] = incoming[key];
      continue;
    }
    const inHash = fieldChecksum(key, incoming[key]);
    const exHash = fieldChecksum(key, existing[key]);
    if (inHash === exHash) {
      merged[key] = existing[key];
      continue;
    }
    // Last-writer-wins: prefer incoming
    merged[key] = incoming[key];
    conflicts.push(key);
  }

  return { merged, conflicts };
};

const mockWrite =
  (system: string): TrackerWrite =>
  async (payload) => `${system}-${payload.entityType}-${payload.internalId}`;

export const syncTask = async (
  payload: SyncPayload,
  writers: {
    linear?: TrackerWrite;
    github?: TrackerWrite;
    monday?: TrackerWrite;
  } = {},
): Promise<SyncResult> => {
  const linearWrite = writers.linear ?? mockWrite("linear");
  const githubWrite = writers.github ?? mockWrite("github");
  const mondayWrite = writers.monday ?? mockWrite("monday");

  const existing = await getSyncMap(payload.entityType, payload.internalId);
  const incomingFields = {
    title: payload.title,
    status: payload.status,
    description: payload.description ?? "",
    ...(payload.fields ?? {}),
  };
  const existingFields = existing
    ? {
        title: payload.title,
        status: payload.status,
        description: payload.description ?? "",
      }
    : {};

  const { conflicts } = reconcileFields(incomingFields, existingFields);
  const checksum = buildChecksum(incomingFields);

  if (existing?.checksum === checksum) {
    return {
      reconciled: true,
      conflict: false,
      escalateToPm: false,
      checksum,
      external: {
        linearId: existing.linearId ?? undefined,
        githubRef: existing.githubRef ?? undefined,
        mondayId: existing.mondayId ?? undefined,
      },
      reason: "idempotent-noop",
    };
  }

  const [linearId, githubRef, mondayId] = await Promise.all([
    withResilience(() => linearWrite(payload), {
      circuit: { name: "linear-sync" },
      timeoutMs: 10_000,
    }),
    withResilience(() => githubWrite(payload), {
      circuit: { name: "github-sync" },
      timeoutMs: 10_000,
    }),
    withResilience(() => mondayWrite(payload), {
      circuit: { name: "monday-sync" },
      timeoutMs: 10_000,
    }),
  ]);

  const external = { linearId, githubRef, mondayId };
  await upsertSyncMap({
    entityType: payload.entityType,
    internalId: payload.internalId,
    external,
    checksum,
    operation: "sync",
  });

  const escalateToPm = conflicts.length > 1;
  if (escalateToPm) {
    logger.warn("Sync conflicts escalate to PM", {
      internalId: payload.internalId,
      conflicts,
    });
  }

  return {
    reconciled: true,
    conflict: conflicts.length > 0,
    escalateToPm,
    checksum,
    external,
    reason: conflicts.length ? `conflicts:${conflicts.join(",")}` : "synced",
  };
};
