import { createHash } from "node:crypto";
import { IntegrationSyncMap } from "@/lib/db/models/integration-sync-map";
import { connectToDatabase } from "@/lib/db/mongodb";

export type SyncEntityType = "task" | "project" | "client";

export type ExternalIds = {
  linearId?: string;
  githubRef?: string;
  mondayId?: string;
};

export const buildChecksum = (payload: Record<string, unknown>): string => {
  const normalized = JSON.stringify(
    Object.keys(payload)
      .sort()
      .reduce<Record<string, unknown>>((acc, key) => {
        acc[key] = payload[key];
        return acc;
      }, {}),
  );
  return createHash("sha256").update(normalized).digest("hex");
};

export const buildIdempotencyKey = (
  entityType: SyncEntityType,
  internalId: string,
  operation: string,
): string => `${entityType}:${internalId}:${operation}`;

export const upsertSyncMap = async (input: {
  entityType: SyncEntityType;
  internalId: string;
  external: ExternalIds;
  checksum: string;
  operation: string;
}) => {
  await connectToDatabase();
  const idempotencyKey = buildIdempotencyKey(
    input.entityType,
    input.internalId,
    input.operation,
  );

  return IntegrationSyncMap.findOneAndUpdate(
    { entityType: input.entityType, internalId: input.internalId },
    {
      $set: {
        ...input.external,
        checksum: input.checksum,
        lastSyncedAt: new Date(),
        idempotencyKey,
      },
      $setOnInsert: {
        entityType: input.entityType,
        internalId: input.internalId,
      },
    },
    { upsert: true, new: true },
  );
};

export const getSyncMap = async (
  entityType: SyncEntityType,
  internalId: string,
) => {
  await connectToDatabase();
  return IntegrationSyncMap.findOne({ entityType, internalId }).lean();
};
