import { describe, expect, it } from "vitest";
import { CircuitOpenError, createCircuitBreaker, withRetry, withTimeout } from "./index";

describe("resilience", () => {
  it("withTimeout rejects after deadline", async () => {
    await expect(
      withTimeout(() => new Promise((resolve) => setTimeout(resolve, 50)), 5),
    ).rejects.toThrow(/timed out/i);
  });

  it("withRetry eventually succeeds", async () => {
    let attempts = 0;
    const result = await withRetry(
      async () => {
        attempts += 1;
        if (attempts < 3) {
          throw new Error("transient");
        }
        return "ok";
      },
      { retries: 3, baseDelayMs: 1, maxDelayMs: 2 },
    );
    expect(result).toBe("ok");
    expect(attempts).toBe(3);
  });

  it("circuit breaker opens after threshold", async () => {
    const breaker = createCircuitBreaker({
      failureThreshold: 2,
      cooldownMs: 60_000,
      name: "test-breaker",
    });
    await expect(breaker.exec(async () => {
      throw new Error("fail");
    })).rejects.toThrow("fail");
    await expect(breaker.exec(async () => {
      throw new Error("fail");
    })).rejects.toThrow("fail");
    await expect(breaker.exec(async () => "x")).rejects.toBeInstanceOf(
      CircuitOpenError,
    );
  });
});
