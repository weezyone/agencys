import { createCircuitBreaker, type CircuitBreakerOptions } from "./circuit-breaker";
import { withRetry, type RetryOptions } from "./retry";
import { withTimeout } from "./timeout";

export { createCircuitBreaker, CircuitOpenError } from "./circuit-breaker";
export { withRetry } from "./retry";
export { withTimeout, TimeoutError } from "./timeout";

export type ResilienceOptions = {
  timeoutMs?: number;
  retry?: RetryOptions;
  circuit?: CircuitBreakerOptions;
};

const breakers = new Map<string, ReturnType<typeof createCircuitBreaker>>();

const getBreaker = (options?: CircuitBreakerOptions) => {
  const name = options?.name ?? "default";
  const existing = breakers.get(name);
  if (existing) {
    return existing;
  }
  const created = createCircuitBreaker(options);
  breakers.set(name, created);
  return created;
};

export const withResilience = async <T>(
  fn: () => Promise<T>,
  options: ResilienceOptions = {},
): Promise<T> => {
  const timeoutMs = options.timeoutMs ?? 15_000;
  const breaker = getBreaker(options.circuit);

  return breaker.exec(() =>
    withRetry(
      () => withTimeout(fn, timeoutMs),
      options.retry ?? { retries: 2, baseDelayMs: 250 },
    ),
  );
};
