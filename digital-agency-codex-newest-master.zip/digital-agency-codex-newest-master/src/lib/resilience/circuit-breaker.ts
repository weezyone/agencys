export type CircuitState = "closed" | "open" | "half-open";

export type CircuitBreakerOptions = {
  failureThreshold?: number;
  cooldownMs?: number;
  name?: string;
};

export class CircuitOpenError extends Error {
  constructor(name: string) {
    super(`Circuit breaker open: ${name}`);
    this.name = "CircuitOpenError";
  }
}

export const createCircuitBreaker = (options: CircuitBreakerOptions = {}) => {
  const failureThreshold = options.failureThreshold ?? 5;
  const cooldownMs = options.cooldownMs ?? 10_000;
  const name = options.name ?? "default";

  let state: CircuitState = "closed";
  let failures = 0;
  let openedAt = 0;

  const getState = (): CircuitState => {
    if (state === "open" && Date.now() - openedAt >= cooldownMs) {
      state = "half-open";
    }
    return state;
  };

  const exec = async <T>(fn: () => Promise<T>): Promise<T> => {
    const current = getState();
    if (current === "open") {
      throw new CircuitOpenError(name);
    }
    try {
      const result = await fn();
      failures = 0;
      state = "closed";
      return result;
    } catch (error) {
      failures += 1;
      if (failures >= failureThreshold || current === "half-open") {
        state = "open";
        openedAt = Date.now();
      }
      throw error;
    }
  };

  return {
    exec,
    getState,
    getFailures: () => failures,
  };
};
