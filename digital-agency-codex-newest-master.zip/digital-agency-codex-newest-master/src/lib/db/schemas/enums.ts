import { z } from "zod";

export const userRoleSchema = z.enum(["admin", "agent-operator", "client"]);
export type UserRole = z.infer<typeof userRoleSchema>;

export const pipelineStageSchema = z.enum([
  "lead",
  "qualified",
  "nurturing",
  "onboarded",
  "churned",
]);
export type PipelineStage = z.infer<typeof pipelineStageSchema>;

export const projectStatusSchema = z.enum([
  "intake",
  "briefing",
  "sow",
  "scaffolding",
  "in-progress",
  "review",
  "delivered",
  "paused",
]);
export type ProjectStatus = z.infer<typeof projectStatusSchema>;

export const taskStatusSchema = z.enum([
  "backlog",
  "todo",
  "in-progress",
  "blocked",
  "review",
  "done",
  "cancelled",
]);
export type TaskStatus = z.infer<typeof taskStatusSchema>;

export const actionLogStatusSchema = z.enum([
  "started",
  "succeeded",
  "failed",
  "timeout",
]);
export type ActionLogStatus = z.infer<typeof actionLogStatusSchema>;

export const registryKindSchema = z.enum(["tool", "agent"]);
export type RegistryKind = z.infer<typeof registryKindSchema>;
