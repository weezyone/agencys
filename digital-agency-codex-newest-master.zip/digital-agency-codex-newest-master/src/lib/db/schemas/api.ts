import { z } from "zod";
import {
  CLIENT_STATUSES,
  PROJECT_STATUSES,
} from "@/lib/db/models/types";

export const projectInputSchema = z.object({
  name: z.string().min(1, "Name is required").max(200),
  clientId: z.string().min(1, "Client ID is required"),
  status: z.enum(PROJECT_STATUSES).optional(),
  description: z.string().max(5000).optional(),
  brief: z.string().max(10000).optional(),
  sow: z.string().max(10000).optional(),
  repoUrl: z.string().url().optional().or(z.literal("")),
  dueDate: z.string().datetime().optional(),
  tags: z.array(z.string()).optional(),
});

export type ProjectInput = z.infer<typeof projectInputSchema>;

export const clientInputSchema = z.object({
  name: z.string().min(1, "Name is required").max(200),
  company: z.string().max(200).optional(),
  email: z.string().email("Valid email is required"),
  phone: z.string().max(50).optional(),
  status: z.enum(CLIENT_STATUSES).optional(),
  leadScore: z.number().min(0).max(100).optional(),
  source: z.string().max(200).optional(),
  notes: z.string().max(5000).optional(),
});

export type ClientInput = z.infer<typeof clientInputSchema>;

export const chatMessageSchema = z.object({
  role: z.enum(["user", "assistant", "system"]),
  content: z.string(),
});

export const agentChatInputSchema = z.object({
  messages: z.array(chatMessageSchema).min(1),
});

export const ragIngestInputSchema = z.object({
  type: z.enum(["text", "url", "pdf"]),
  source: z.string().min(1),
  text: z.string().optional(),
  metadata: z.record(z.unknown()).optional(),
});

export const ragQueryInputSchema = z.object({
  query: z.string().min(1),
  topK: z.number().int().min(1).max(20).optional(),
});

export const workflowRunInputSchema = z.object({
  input: z.record(z.unknown()).optional(),
});
