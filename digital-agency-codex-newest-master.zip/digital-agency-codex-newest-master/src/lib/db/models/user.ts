import { Schema, model, models, type InferSchemaType, type Model } from "mongoose";
import { USER_ROLES, type UserRole } from "./types";

const userSchema = new Schema(
  {
    name: { type: String, trim: true },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    emailVerified: { type: Date },
    image: { type: String },
    role: {
      type: String,
      enum: USER_ROLES,
      required: true,
      default: "client" satisfies UserRole,
      index: true,
    },
    clientId: { type: Schema.Types.ObjectId, ref: "Client", default: null },
  },
  { timestamps: true },
);

export type UserDocument = InferSchemaType<typeof userSchema> & {
  _id: Schema.Types.ObjectId;
};

export const User: Model<UserDocument> =
  (models.User as Model<UserDocument> | undefined) ??
  model<UserDocument>("User", userSchema);
