export const USER_ROLES = ["admin", "agent-operator", "client"] as const;
export type UserRole = (typeof USER_ROLES)[number];

export const CLIENT_STATUSES = [
  "lead",
  "qualified",
  "nurturing",
  "onboarded",
  "active",
  "churned",
] as const;
export type ClientStatus = (typeof CLIENT_STATUSES)[number];

export const PROJECT_STATUSES = [
  "intake",
  "briefing",
  "sow",
  "scaffolding",
  "active",
  "review",
  "delivered",
  "paused",
  "cancelled",
] as const;
export type ProjectStatus = (typeof PROJECT_STATUSES)[number];

export const TASK_STATUSES = [
  "backlog",
  "todo",
  "in_progress",
  "blocked",
  "review",
  "done",
] as const;
export type TaskStatus = (typeof TASK_STATUSES)[number];

export const TASK_PRIORITIES = ["low", "medium", "high", "urgent"] as const;
export type TaskPriority = (typeof TASK_PRIORITIES)[number];

export const CONVERSATION_ROLES = ["user", "assistant", "system", "tool"] as const;
export type ConversationRole = (typeof CONVERSATION_ROLES)[number];

export const REGISTRY_KINDS = ["tool", "agent"] as const;
export type RegistryKind = (typeof REGISTRY_KINDS)[number];

export const SYNC_PROVIDERS = ["linear", "monday", "github"] as const;
export type SyncProvider = (typeof SYNC_PROVIDERS)[number];
