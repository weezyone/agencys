import { describe, expect, it } from "vitest";
import {
  CLIENT_STATUSES,
  PROJECT_STATUSES,
  TASK_STATUSES,
  USER_ROLES,
} from "./types";
import { Client } from "./client";
import { Project } from "./project";
import { Task } from "./task";
import { User } from "./user";
import { Conversation } from "./conversation";
import { AgentActionLog } from "./agent-action-log";
import { IntegrationSyncMap } from "./integration-sync-map";
import { DynamicRegistry } from "./dynamic-registry";

describe("mongoose model registration", () => {
  it("exposes expected role and status enums", () => {
    expect(USER_ROLES).toEqual(["admin", "agent-operator", "client"]);
    expect(CLIENT_STATUSES).toContain("lead");
    expect(PROJECT_STATUSES).toContain("intake");
    expect(TASK_STATUSES).toContain("in_progress");
  });

  it("registers all domain models", () => {
    expect(User.modelName).toBe("User");
    expect(Client.modelName).toBe("Client");
    expect(Project.modelName).toBe("Project");
    expect(Task.modelName).toBe("Task");
    expect(Conversation.modelName).toBe("Conversation");
    expect(AgentActionLog.modelName).toBe("AgentActionLog");
    expect(IntegrationSyncMap.modelName).toBe("IntegrationSyncMap");
    expect(DynamicRegistry.modelName).toBe("DynamicRegistry");
  });

  it("requires core fields on Client and Project schemas", () => {
    const clientRequired = Object.entries(Client.schema.paths)
      .filter(([, path]) => path.isRequired)
      .map(([name]) => name);
    const projectRequired = Object.entries(Project.schema.paths)
      .filter(([, path]) => path.isRequired)
      .map(([name]) => name);

    expect(clientRequired).toEqual(
      expect.arrayContaining(["name", "email", "status"]),
    );
    expect(projectRequired).toEqual(
      expect.arrayContaining(["name", "clientId", "status"]),
    );
  });
});
