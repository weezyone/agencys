import { Schema, model, models, type InferSchemaType, type Model } from "mongoose";
import { PROJECT_STATUSES, type ProjectStatus } from "./types";

const projectSchema = new Schema(
  {
    name: { type: String, required: true, trim: true },
    clientId: {
      type: Schema.Types.ObjectId,
      ref: "Client",
      required: true,
      index: true,
    },
    status: {
      type: String,
      enum: PROJECT_STATUSES,
      required: true,
      default: "intake" satisfies ProjectStatus,
      index: true,
    },
    description: { type: String, default: "" },
    brief: { type: String, default: "" },
    sow: { type: String, default: "" },
    repoUrl: { type: String, trim: true },
    startDate: { type: Date },
    dueDate: { type: Date },
    tags: { type: [String], default: [] },
    metadata: { type: Schema.Types.Mixed, default: {} },
  },
  { timestamps: true },
);

projectSchema.index({ clientId: 1, status: 1 });

export type ProjectDocument = InferSchemaType<typeof projectSchema> & {
  _id: Schema.Types.ObjectId;
};

export const Project: Model<ProjectDocument> =
  (models.Project as Model<ProjectDocument> | undefined) ??
  model<ProjectDocument>("Project", projectSchema);
