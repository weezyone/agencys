import { Schema, model, models, type InferSchemaType, type Model } from "mongoose";

/**
 * Append-only audit trail for agent/tool invocations.
 * Do not update or delete documents in application code.
 */
const agentActionLogSchema = new Schema(
  {
    correlationId: { type: String, required: true, index: true },
    agentName: { type: String, required: true, trim: true, index: true },
    toolName: { type: String, trim: true, index: true },
    phase: {
      type: String,
      enum: ["before", "after", "error"] as const,
      required: true,
    },
    input: { type: Schema.Types.Mixed },
    output: { type: Schema.Types.Mixed },
    error: { type: String },
    durationMs: { type: Number },
    projectId: { type: Schema.Types.ObjectId, ref: "Project", index: true },
    userId: { type: Schema.Types.ObjectId, ref: "User", index: true },
    metadata: { type: Schema.Types.Mixed, default: {} },
  },
  {
    timestamps: { createdAt: true, updatedAt: false },
    // Discourage accidental updates at the schema level.
    strict: true,
  },
);

agentActionLogSchema.index({ createdAt: -1 });

export type AgentActionLogDocument = InferSchemaType<
  typeof agentActionLogSchema
> & {
  _id: Schema.Types.ObjectId;
};

export const AgentActionLog: Model<AgentActionLogDocument> =
  (models.AgentActionLog as Model<AgentActionLogDocument> | undefined) ??
  model<AgentActionLogDocument>("AgentActionLog", agentActionLogSchema);
