import { Schema, model, models, type InferSchemaType, type Model } from "mongoose";
import { CLIENT_STATUSES, type ClientStatus } from "./types";

const clientSchema = new Schema(
  {
    name: { type: String, required: true, trim: true },
    company: { type: String, trim: true },
    email: { type: String, required: true, lowercase: true, trim: true },
    phone: { type: String, trim: true },
    status: {
      type: String,
      enum: CLIENT_STATUSES,
      required: true,
      default: "lead" satisfies ClientStatus,
      index: true,
    },
    leadScore: { type: Number, min: 0, max: 100, default: 0 },
    source: { type: String, trim: true },
    notes: { type: String, default: "" },
    metadata: { type: Schema.Types.Mixed, default: {} },
    ownerUserId: { type: Schema.Types.ObjectId, ref: "User", default: null },
  },
  { timestamps: true },
);

clientSchema.index({ email: 1 });
clientSchema.index({ status: 1, leadScore: -1 });

export type ClientDocument = InferSchemaType<typeof clientSchema> & {
  _id: Schema.Types.ObjectId;
};

export const Client: Model<ClientDocument> =
  (models.Client as Model<ClientDocument> | undefined) ??
  model<ClientDocument>("Client", clientSchema);
