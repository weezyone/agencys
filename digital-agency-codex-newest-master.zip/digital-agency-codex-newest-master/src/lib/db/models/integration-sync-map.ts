import { Schema, model, models, type InferSchemaType, type Model } from "mongoose";
import { SYNC_PROVIDERS } from "./types";

const fieldChecksumSchema = new Schema(
  {
    field: { type: String, required: true },
    checksum: { type: String, required: true },
    updatedAt: { type: Date, required: true },
    source: { type: String, required: true },
  },
  { _id: false },
);

const integrationSyncMapSchema = new Schema(
  {
    provider: {
      type: String,
      enum: SYNC_PROVIDERS,
      required: true,
      index: true,
    },
    entityType: { type: String, required: true, trim: true },
    localId: { type: String, required: true, trim: true },
    remoteId: { type: String, required: true, trim: true },
    projectId: { type: Schema.Types.ObjectId, ref: "Project", index: true },
    fieldChecksums: { type: [fieldChecksumSchema], default: [] },
    lastSyncedAt: { type: Date },
    conflict: {
      type: Boolean,
      default: false,
      index: true,
    },
    conflictDetail: { type: String, default: "" },
    metadata: { type: Schema.Types.Mixed, default: {} },
  },
  { timestamps: true },
);

integrationSyncMapSchema.index(
  { provider: 1, entityType: 1, localId: 1 },
  { unique: true },
);
integrationSyncMapSchema.index(
  { provider: 1, entityType: 1, remoteId: 1 },
  { unique: true },
);

export type IntegrationSyncMapDocument = InferSchemaType<
  typeof integrationSyncMapSchema
> & {
  _id: Schema.Types.ObjectId;
};

export const IntegrationSyncMap: Model<IntegrationSyncMapDocument> =
  (models.IntegrationSyncMap as Model<IntegrationSyncMapDocument> | undefined) ??
  model<IntegrationSyncMapDocument>(
    "IntegrationSyncMap",
    integrationSyncMapSchema,
  );
