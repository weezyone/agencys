import { Schema, model, models, type InferSchemaType, type Model } from "mongoose";
import { CONVERSATION_ROLES } from "./types";

const messageSchema = new Schema(
  {
    role: {
      type: String,
      enum: CONVERSATION_ROLES,
      required: true,
    },
    content: { type: String, required: true },
    agentName: { type: String, trim: true },
    toolName: { type: String, trim: true },
    metadata: { type: Schema.Types.Mixed, default: {} },
    createdAt: { type: Date, default: Date.now },
  },
  { _id: true },
);

const conversationSchema = new Schema(
  {
    projectId: { type: Schema.Types.ObjectId, ref: "Project", index: true },
    clientId: { type: Schema.Types.ObjectId, ref: "Client", index: true },
    userId: { type: Schema.Types.ObjectId, ref: "User", index: true },
    agentName: { type: String, required: true, trim: true, index: true },
    title: { type: String, trim: true, default: "Untitled conversation" },
    messages: { type: [messageSchema], default: [] },
    correlationId: { type: String, index: true },
    metadata: { type: Schema.Types.Mixed, default: {} },
  },
  { timestamps: true },
);

export type ConversationDocument = InferSchemaType<typeof conversationSchema> & {
  _id: Schema.Types.ObjectId;
};

export const Conversation: Model<ConversationDocument> =
  (models.Conversation as Model<ConversationDocument> | undefined) ??
  model<ConversationDocument>("Conversation", conversationSchema);
