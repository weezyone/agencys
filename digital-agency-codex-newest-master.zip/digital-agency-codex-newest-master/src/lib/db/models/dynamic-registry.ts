import { Schema, model, models, type InferSchemaType, type Model } from "mongoose";
import { REGISTRY_KINDS } from "./types";

const dynamicRegistrySchema = new Schema(
  {
    kind: {
      type: String,
      enum: REGISTRY_KINDS,
      required: true,
      index: true,
    },
    name: { type: String, required: true, trim: true },
    description: { type: String, default: "" },
    definition: { type: Schema.Types.Mixed, required: true },
    version: { type: Number, required: true, default: 1 },
    enabled: { type: Boolean, required: true, default: true, index: true },
    createdBy: { type: String, trim: true },
    metadata: { type: Schema.Types.Mixed, default: {} },
  },
  { timestamps: true },
);

dynamicRegistrySchema.index({ kind: 1, name: 1 }, { unique: true });

export type DynamicRegistryDocument = InferSchemaType<
  typeof dynamicRegistrySchema
> & {
  _id: Schema.Types.ObjectId;
};

export const DynamicRegistry: Model<DynamicRegistryDocument> =
  (models.DynamicRegistry as Model<DynamicRegistryDocument> | undefined) ??
  model<DynamicRegistryDocument>("DynamicRegistry", dynamicRegistrySchema);
