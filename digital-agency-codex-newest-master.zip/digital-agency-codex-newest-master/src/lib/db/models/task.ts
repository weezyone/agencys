import { Schema, model, models, type InferSchemaType, type Model } from "mongoose";
import {
  TASK_PRIORITIES,
  TASK_STATUSES,
  type TaskPriority,
  type TaskStatus,
} from "./types";

const taskSchema = new Schema(
  {
    projectId: {
      type: Schema.Types.ObjectId,
      ref: "Project",
      required: true,
      index: true,
    },
    title: { type: String, required: true, trim: true },
    description: { type: String, default: "" },
    status: {
      type: String,
      enum: TASK_STATUSES,
      required: true,
      default: "backlog" satisfies TaskStatus,
      index: true,
    },
    priority: {
      type: String,
      enum: TASK_PRIORITIES,
      required: true,
      default: "medium" satisfies TaskPriority,
    },
    assigneeAgent: { type: String, trim: true },
    assigneeUserId: { type: Schema.Types.ObjectId, ref: "User", default: null },
    blockedReason: { type: String, default: "" },
    dueDate: { type: Date },
    order: { type: Number, default: 0 },
    metadata: { type: Schema.Types.Mixed, default: {} },
  },
  { timestamps: true },
);

taskSchema.index({ projectId: 1, status: 1, order: 1 });

export type TaskDocument = InferSchemaType<typeof taskSchema> & {
  _id: Schema.Types.ObjectId;
};

export const Task: Model<TaskDocument> =
  (models.Task as Model<TaskDocument> | undefined) ??
  model<TaskDocument>("Task", taskSchema);
