import { afterEach, describe, expect, it, vi } from "vitest";

vi.mock("mongoose", () => {
  const connect = vi.fn(async () => ({ connection: { readyState: 1 } }));
  return {
    default: {
      connect,
    },
  };
});

import mongoose from "mongoose";
import {
  connectToDatabase,
  getMongodbDbName,
  getMongodbUri,
  resetMongodbCache,
} from "./mongodb";

describe("mongodb connection helpers", () => {
  afterEach(() => {
    resetMongodbCache();
    vi.clearAllMocks();
    delete process.env.MONGODB_URI;
    delete process.env.MONGODB_DB_NAME;
  });

  it("throws when MONGODB_URI is missing", () => {
    expect(() => getMongodbUri()).toThrow(/MONGODB_URI/);
  });

  it("reads URI and default db name", () => {
    process.env.MONGODB_URI = "mongodb://localhost:27017/test";
    expect(getMongodbUri()).toBe("mongodb://localhost:27017/test");
    expect(getMongodbDbName()).toBe("digital-agency");
  });

  it("respects MONGODB_DB_NAME override", () => {
    process.env.MONGODB_DB_NAME = "agency-dev";
    expect(getMongodbDbName()).toBe("agency-dev");
  });

  it("connects once and reuses the singleton", async () => {
    process.env.MONGODB_URI = "mongodb://localhost:27017/test";
    process.env.MONGODB_DB_NAME = "agency-test";

    const first = await connectToDatabase();
    const second = await connectToDatabase();

    expect(first).toBe(second);
    expect(mongoose.connect).toHaveBeenCalledTimes(1);
    expect(mongoose.connect).toHaveBeenCalledWith(
      "mongodb://localhost:27017/test",
      expect.objectContaining({
        dbName: "agency-test",
        bufferCommands: false,
      }),
    );
  });
});
