import mongoose from "mongoose";

type MongooseCache = {
  conn: typeof mongoose | null;
  promise: Promise<typeof mongoose> | null;
};

declare global {
  // eslint-disable-next-line no-var
  var mongooseCache: MongooseCache | undefined;
}

const cache: MongooseCache = global.mongooseCache ?? {
  conn: null,
  promise: null,
};

global.mongooseCache = cache;

export function getMongodbUri(): string {
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    throw new Error("MONGODB_URI is not set");
  }
  return uri;
}

export function getMongodbDbName(): string {
  return process.env.MONGODB_DB_NAME ?? "digital-agency";
}

export async function connectToDatabase(): Promise<typeof mongoose> {
  if (cache.conn) {
    return cache.conn;
  }

  if (!cache.promise) {
    const uri = getMongodbUri();
    const dbName = getMongodbDbName();

    cache.promise = mongoose.connect(uri, {
      dbName,
      bufferCommands: false,
    });
  }

  cache.conn = await cache.promise;
  return cache.conn;
}

/** Test helper — resets the singleton between unit tests. */
export function resetMongodbCache(): void {
  cache.conn = null;
  cache.promise = null;
}
