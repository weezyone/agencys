import { randomUUID } from "node:crypto";
import { appendActionLog } from "@/lib/observability/action-logger";
import { logger } from "@/lib/observability/logger";
import { withResilience } from "@/lib/resilience";
import {
  createChunksFromText,
  extractTextFromPdfBuffer,
  fetchUrlText,
  type IngestType,
} from "./documents";
import { embedTexts, EMBEDDING_DIMENSIONS } from "./embeddings";

type StoredChunk = {
  id: string;
  text: string;
  embedding: number[];
  metadata: {
    sourceId: string;
    sourceType: IngestType;
    source: string;
    chunkIndex: number;
  };
};

const memoryStore: StoredChunk[] = [];

const cosineSimilarity = (a: number[], b: number[]): number => {
  const dot = a.reduce((sum, value, index) => sum + value * (b[index] ?? 0), 0);
  const normA = Math.sqrt(a.reduce((sum, value) => sum + value * value, 0));
  const normB = Math.sqrt(b.reduce((sum, value) => sum + value * value, 0));
  if (normA === 0 || normB === 0) {
    return 0;
  }
  return dot / (normA * normB);
};

export const ingestDocument = async (input: {
  type: IngestType;
  source: string;
  text?: string;
  pdfBuffer?: Buffer;
  metadata?: Record<string, unknown>;
}) => {
  const sourceId = randomUUID();
  let rawText = input.text ?? "";

  if (input.type === "url") {
    rawText = await withResilience(() => fetchUrlText(input.source), {
      circuit: { name: "rag-url" },
    });
  } else if (input.type === "pdf") {
    if (!input.pdfBuffer) {
      throw new Error("pdfBuffer required for pdf ingestion");
    }
    rawText = await extractTextFromPdfBuffer(input.pdfBuffer);
  }

  const chunks = createChunksFromText(
    rawText,
    input.source,
    input.type,
    sourceId,
  );
  const embeddings = await embedTexts(chunks.map((chunk) => chunk.text));

  chunks.forEach((chunk, index) => {
    memoryStore.push({
      id: chunk.id,
      text: chunk.text,
      embedding: embeddings[index] ?? [],
      metadata: chunk.metadata,
    });
  });

  await appendActionLog({
    agentName: "research",
    toolName: "rag-ingest",
    input: { type: input.type, source: input.source, ...input.metadata },
    output: { ingestedChunks: chunks.length, sourceId, dimensions: EMBEDDING_DIMENSIONS },
    status: "succeeded",
  });

  logger.info("RAG ingest complete", {
    sourceId,
    chunks: chunks.length,
  });

  return { ingestedChunks: chunks.length, sourceId };
};

export const queryKnowledgeBase = async (input: {
  query: string;
  topK?: number;
}) => {
  const topK = input.topK ?? 5;
  const [queryEmbedding] = await embedTexts([input.query]);
  const ranked = memoryStore
    .map((chunk) => ({
      chunk,
      score: cosineSimilarity(queryEmbedding ?? [], chunk.embedding),
    }))
    .sort((a, b) => b.score - a.score)
    .slice(0, topK);

  const sources = ranked.map((item) => ({
    sourceId: item.chunk.metadata.sourceId,
    source: item.chunk.metadata.source,
    sourceType: item.chunk.metadata.sourceType,
    excerpt: item.chunk.text.slice(0, 280),
    score: item.score,
  }));

  const answer =
    sources.length === 0
      ? "No indexed documents matched this query."
      : `Based on ${sources.length} source(s): ${sources
          .map((source) => source.excerpt)
          .join(" | ")}`;

  await appendActionLog({
    agentName: "research",
    toolName: "rag-query",
    input: { query: input.query, topK },
    output: { sourceCount: sources.length },
    status: "succeeded",
  });

  return { answer, sources };
};

/** Test helper */
export const __resetKnowledgeBaseForTests = (): void => {
  memoryStore.length = 0;
};
