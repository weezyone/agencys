import { describe, expect, it, beforeEach } from "vitest";
import {
  __resetKnowledgeBaseForTests,
  ingestDocument,
  queryKnowledgeBase,
} from "./knowledge-base";

describe("knowledge-base", () => {
  beforeEach(() => {
    __resetKnowledgeBaseForTests();
  });

  it("ingests text and returns attributed query answers", async () => {
    const ingested = await ingestDocument({
      type: "text",
      source: "inline",
      text: "Digital agency delivers briefs, SOWs, and MVP scaffolds with multi-agent orchestration.",
    });
    expect(ingested.ingestedChunks).toBeGreaterThan(0);

    const result = await queryKnowledgeBase({
      query: "What does the digital agency deliver?",
      topK: 3,
    });
    expect(result.sources.length).toBeGreaterThan(0);
    expect(result.sources[0]?.sourceId).toBe(ingested.sourceId);
    expect(result.answer.toLowerCase()).toContain("source");
  });
});
