import { openai } from "@ai-sdk/openai";
import { embedMany } from "ai";

export const EMBEDDING_MODEL = "text-embedding-3-small";
export const EMBEDDING_DIMENSIONS = 1536;

export const embedTexts = async (values: string[]): Promise<number[][]> => {
  if (!process.env.OPENAI_API_KEY) {
    // Deterministic sandbox embeddings for tests/offline
    return values.map((value) => {
      const vector = Array.from({ length: EMBEDDING_DIMENSIONS }, (_, i) =>
        ((value.charCodeAt(i % value.length) || 0) % 97) / 97,
      );
      return vector;
    });
  }

  const { embeddings } = await embedMany({
    model: openai.embedding(EMBEDDING_MODEL),
    values,
  });
  return embeddings;
};
