import pdfParse from "pdf-parse";
import { z } from "zod";

export const ingestTypeSchema = z.enum(["url", "pdf", "text"]);
export type IngestType = z.infer<typeof ingestTypeSchema>;

export type DocumentChunk = {
  id: string;
  text: string;
  metadata: {
    sourceId: string;
    sourceType: IngestType;
    source: string;
    chunkIndex: number;
  };
};

const chunkText = (text: string, chunkSize = 800): string[] => {
  const normalized = text.replace(/\s+/g, " ").trim();
  if (!normalized) {
    return [];
  }
  const chunks: string[] = [];
  for (let i = 0; i < normalized.length; i += chunkSize) {
    chunks.push(normalized.slice(i, i + chunkSize));
  }
  return chunks;
};

export const createChunksFromText = (
  text: string,
  source: string,
  sourceType: IngestType,
  sourceId: string,
): DocumentChunk[] =>
  chunkText(text).map((chunk, chunkIndex) => ({
    id: `${sourceId}-${chunkIndex}`,
    text: chunk,
    metadata: {
      sourceId,
      sourceType,
      source,
      chunkIndex,
    },
  }));

export const extractTextFromPdfBuffer = async (
  buffer: Buffer,
): Promise<string> => {
  const parsed = await pdfParse(buffer);
  return parsed.text ?? "";
};

export const fetchUrlText = async (url: string): Promise<string> => {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to fetch URL: ${response.status}`);
  }
  const contentType = response.headers.get("content-type") ?? "";
  const body = await response.text();
  if (contentType.includes("text") || contentType.includes("html")) {
    return body.replace(/<[^>]+>/g, " ");
  }
  return body;
};
