import { createTool } from "@mastra/core/tools";
import { z } from "zod";
import { DynamicRegistry } from "@/lib/db/models/dynamic-registry";
import { connectToDatabase } from "@/lib/db/mongodb";
import { appendActionLog } from "@/lib/observability/action-logger";
import { logger } from "@/lib/observability/logger";

export type DynamicToolSpec = {
  name: string;
  description: string;
  inputKeys: string[];
  outputMessage: string;
};

export const createDynamicTool = (spec: DynamicToolSpec) => {
  const shape = Object.fromEntries(
    spec.inputKeys.map((key) => [key, z.unknown()]),
  );

  return createTool({
    id: spec.name,
    description: spec.description,
    inputSchema: z.object(shape).passthrough(),
    outputSchema: z.object({
      ok: z.boolean(),
      message: z.string(),
      echo: z.record(z.unknown()),
    }),
    execute: async (input) => {
      const result = {
        ok: true,
        message: spec.outputMessage,
        echo: input as Record<string, unknown>,
      };
      await appendActionLog({
        agentName: "project-manager",
        toolName: spec.name,
        input,
        output: result,
        status: "succeeded",
      });
      return result;
    },
  });
};

export const persistDynamicTool = async (spec: DynamicToolSpec) => {
  await connectToDatabase();
  await DynamicRegistry.findOneAndUpdate(
    { kind: "tool", name: spec.name },
    {
      kind: "tool",
      name: spec.name,
      description: spec.description,
      spec,
      createdBy: "project-manager",
      active: true,
    },
    { upsert: true, new: true },
  );
  logger.info("Persisted dynamic tool", { name: spec.name });
  return createDynamicTool(spec);
};

export const createDynamicToolFactoryTool = createTool({
  id: "create-dynamic-tool",
  description: "Create and persist a missing tool at runtime",
  inputSchema: z.object({
    name: z.string().min(1),
    description: z.string().min(1),
    inputKeys: z.array(z.string()).default([]),
    outputMessage: z.string().default("Dynamic tool executed"),
  }),
  outputSchema: z.object({
    name: z.string(),
    persisted: z.boolean(),
  }),
  execute: async (spec) => {
    await persistDynamicTool(spec);
    return { name: spec.name, persisted: true };
  },
});
