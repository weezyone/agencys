import { DynamicRegistry } from "@/lib/db/models/dynamic-registry";
import { connectToDatabase } from "@/lib/db/mongodb";
import { logger } from "@/lib/observability/logger";
import {
  createDynamicAgent,
  type DynamicAgentSpec,
} from "./agent-factory";
import {
  createDynamicTool,
  type DynamicToolSpec,
} from "./tool-factory";

export type LoadedRegistry = {
  tools: Record<string, ReturnType<typeof createDynamicTool>>;
  agents: Record<string, ReturnType<typeof createDynamicAgent>>;
};

export const loadRegistry = async (): Promise<LoadedRegistry> => {
  try {
    await connectToDatabase();
    const entries = await DynamicRegistry.find({ active: true }).lean();
    const tools: LoadedRegistry["tools"] = {};
    const agents: LoadedRegistry["agents"] = {};

    for (const entry of entries) {
      if (entry.kind === "tool") {
        const spec = entry.spec as DynamicToolSpec;
        tools[entry.name] = createDynamicTool(spec);
      } else if (entry.kind === "agent") {
        const spec = entry.spec as DynamicAgentSpec;
        agents[entry.name] = createDynamicAgent(spec);
      }
    }

    logger.info("Hydrated dynamic registry", {
      toolCount: Object.keys(tools).length,
      agentCount: Object.keys(agents).length,
    });

    return { tools, agents };
  } catch (error) {
    logger.warn("Registry hydrate skipped", {
      error: error instanceof Error ? error.message : String(error),
    });
    return { tools: {}, agents: {} };
  }
};
