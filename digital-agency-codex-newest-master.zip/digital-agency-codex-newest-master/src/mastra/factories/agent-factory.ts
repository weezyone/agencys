import { Agent } from "@mastra/core/agent";
import { createTool } from "@mastra/core/tools";
import { z } from "zod";
import { DynamicRegistry } from "@/lib/db/models/dynamic-registry";
import { connectToDatabase } from "@/lib/db/mongodb";
import { logger } from "@/lib/observability/logger";
import { DEFAULT_MODEL, SAFETY_RULES } from "@/mastra/agents/shared";
import { allTools } from "@/mastra/tools";

export type DynamicAgentSpec = {
  name: string;
  instructions: string;
  toolNames?: string[];
};

export const createDynamicAgent = (spec: DynamicAgentSpec) => {
  const tools = Object.fromEntries(
    (spec.toolNames ?? [])
      .map((toolName) => {
        const tool = (allTools as Record<string, unknown>)[toolName];
        return tool ? [toolName, tool] : null;
      })
      .filter((entry): entry is [string, unknown] => entry !== null),
  );

  return new Agent({
    id: spec.name,
    name: spec.name,
    instructions: `${spec.instructions}\n${SAFETY_RULES}`,
    model: DEFAULT_MODEL,
    tools: tools as ConstructorParameters<typeof Agent>[0]["tools"],
  });
};

export const persistDynamicAgent = async (spec: DynamicAgentSpec) => {
  await connectToDatabase();
  await DynamicRegistry.findOneAndUpdate(
    { kind: "agent", name: spec.name },
    {
      kind: "agent",
      name: spec.name,
      description: spec.instructions.slice(0, 200),
      spec,
      createdBy: "project-manager",
      active: true,
    },
    { upsert: true, new: true },
  );
  logger.info("Persisted dynamic agent", { name: spec.name });
  return createDynamicAgent(spec);
};

export const createDynamicAgentFactoryTool = createTool({
  id: "create-dynamic-agent",
  description: "Create and persist an additional teammate agent at runtime",
  inputSchema: z.object({
    name: z.string().min(1),
    instructions: z.string().min(1),
    toolNames: z.array(z.string()).default([]),
  }),
  outputSchema: z.object({
    name: z.string(),
    persisted: z.boolean(),
  }),
  execute: async (spec) => {
    await persistDynamicAgent(spec);
    return { name: spec.name, persisted: true };
  },
});
