import { Mastra } from "@mastra/core";
import { agents } from "./agents";
import { allTools } from "./tools";
import { workflows } from "./workflows";

export const mastra = new Mastra({
  agents,
  workflows,
  // tools registered for discovery; agents already hold scoped subsets
  // @ts-expect-error Mastra tools map accepts ToolAction records
  tools: allTools,
});

export const getAgentByName = (name: string) => {
  const agent = agents[name as keyof typeof agents];
  if (!agent) {
    throw new Error(`Unknown agent: ${name}`);
  }
  return agent;
};

export const getWorkflowByName = (name: string) => {
  const workflow = workflows[name as keyof typeof workflows];
  if (!workflow) {
    throw new Error(`Unknown workflow: ${name}`);
  }
  return workflow;
};

export { agents, workflows, allTools };
