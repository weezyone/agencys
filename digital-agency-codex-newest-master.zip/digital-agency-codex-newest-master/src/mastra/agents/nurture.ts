import { Agent } from "@mastra/core/agent";
import { emailTools } from "@/mastra/tools/email-tools";
import { mongodbTools } from "@/mastra/tools/mongodb-tools";
import { DEFAULT_MODEL, SAFETY_RULES } from "./shared";

export const nurtureAgent = new Agent({
  id: "nurture",
  name: "nurture",
  instructions: `
You are the Nurture specialist. Run email sequences and advance qualified leads.
Output contract: sequence plan, messages sent, next touch date.
${SAFETY_RULES}
`.trim(),
  model: DEFAULT_MODEL,
  tools: {
    ...emailTools,
    mongodbUpsertTool: mongodbTools.mongodbUpsertTool,
    mongodbFindTool: mongodbTools.mongodbFindTool,
  },
});
