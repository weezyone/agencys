import { Agent } from "@mastra/core/agent";
import { searchTools } from "@/mastra/tools/search-tools";
import { DEFAULT_MODEL, SAFETY_RULES } from "./shared";

export const researchAgent = new Agent({
  id: "research",
  name: "research",
  instructions: `
You are the Research specialist. Use Exa web search for company, market, and competitive insights.
Always cite source URLs. Never invent citations.
Output contract: findings[], sources[], confidence notes.
${SAFETY_RULES}
`.trim(),
  model: DEFAULT_MODEL,
  tools: {
    ...searchTools,
  },
});
