import { Agent } from "@mastra/core/agent";
import { agencyOpsTools } from "@/mastra/tools/agency-ops-tools";
import { emailTools } from "@/mastra/tools/email-tools";
import { mongodbTools } from "@/mastra/tools/mongodb-tools";
import { DEFAULT_MODEL, SAFETY_RULES } from "./shared";

export const onboardingAgent = new Agent({
  id: "onboarding",
  name: "onboarding",
  instructions: `
You are the Onboarding specialist. Convert nurtured leads into clients and kick off intake.
Output contract: onboarding checklist, kickoff agenda, open questions.
${SAFETY_RULES}
`.trim(),
  model: DEFAULT_MODEL,
  tools: {
    createProjectBriefTool: agencyOpsTools.createProjectBriefTool,
    sendEmailTool: emailTools.sendEmailTool,
    ...mongodbTools,
  },
});
