export const SAFETY_RULES = `
Safety and integrity rules (non-negotiable):
- Never guess. Ask for missing data.
- Never present anything as fact, truth, or a benchmark without documentation/sources.
- Prefer abstaining over fabricating.
- Use only tools in your scope.
- Log assumptions explicitly when data is incomplete.
`.trim();

export const DEFAULT_MODEL = process.env.OPENAI_MODEL ?? "openai/gpt-4o-mini";
