import { describe, expect, it } from "vitest";
import { agents, agentNames } from "./index";
import { projectManagerAgent } from "./project-manager";

describe("agents", () => {
  it("registers all 10 baseline agents", () => {
    expect(agentNames).toHaveLength(10);
    expect(agentNames).toContain("project-manager");
    expect(agents.prospector).toBeTruthy();
  });

  it("PM instructions enforce delegate-only orchestration", () => {
    const instructions = String(projectManagerAgent.getInstructions?.() ?? "");
    const text =
      instructions ||
      // fallback for Agent shape differences across Mastra versions
      JSON.stringify(projectManagerAgent);
    expect(text.toLowerCase()).toMatch(/delegate|never complete specialist/i);
  });
});
