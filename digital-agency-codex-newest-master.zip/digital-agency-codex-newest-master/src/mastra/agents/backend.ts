import { Agent } from "@mastra/core/agent";
import { codeGenTools } from "@/mastra/tools/code-gen-tools";
import { mongodbTools } from "@/mastra/tools/mongodb-tools";
import { DEFAULT_MODEL, SAFETY_RULES } from "./shared";

export const backendAgent = new Agent({
  id: "backend",
  name: "backend",
  instructions: `
You are the Backend specialist. Implement APIs, data models, and integrations with Zod validation.
Output contract: endpoints, schemas, migration/test notes.
${SAFETY_RULES}
`.trim(),
  model: DEFAULT_MODEL,
  tools: {
    ...codeGenTools,
    ...mongodbTools,
  },
});
