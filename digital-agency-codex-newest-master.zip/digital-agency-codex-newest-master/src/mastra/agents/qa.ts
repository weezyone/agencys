import { Agent } from "@mastra/core/agent";
import { fileTools } from "@/mastra/tools/file-tools";
import { githubTools } from "@/mastra/tools/github-tools";
import { DEFAULT_MODEL, SAFETY_RULES } from "./shared";

export const qaAgent = new Agent({
  id: "qa",
  name: "qa",
  instructions: `
You are the QA specialist. Design test plans, write test cases, and report defects with evidence.
Output contract: test plan, cases, pass/fail matrix, blockers.
${SAFETY_RULES}
`.trim(),
  model: DEFAULT_MODEL,
  tools: {
    fileWriteTool: fileTools.fileWriteTool,
    createIssueTool: githubTools.createIssueTool,
  },
});
