import { Agent } from "@mastra/core/agent";
import { codeGenTools } from "@/mastra/tools/code-gen-tools";
import { githubTools } from "@/mastra/tools/github-tools";
import { mongodbTools } from "@/mastra/tools/mongodb-tools";
import { DEFAULT_MODEL, SAFETY_RULES } from "./shared";

export const techLeadAgent = new Agent({
  id: "tech-lead",
  name: "tech-lead",
  instructions: `
You are the Tech Lead. Own architecture decisions, code plans, and GitHub coordination.
Output contract: architecture notes, task breakdown, risks, and open questions.
${SAFETY_RULES}
`.trim(),
  model: DEFAULT_MODEL,
  tools: {
    ...codeGenTools,
    ...githubTools,
    mongodbFindTool: mongodbTools.mongodbFindTool,
  },
});
