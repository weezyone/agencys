import { Agent } from "@mastra/core/agent";
import { fileTools } from "@/mastra/tools/file-tools";
import { mongodbTools } from "@/mastra/tools/mongodb-tools";
import { DEFAULT_MODEL, SAFETY_RULES } from "./shared";

export const designAgent = new Agent({
  id: "design",
  name: "design",
  instructions: `
You are the Design specialist. Produce UX flows, component inventories, and visual direction notes.
Output contract: user flows, component list, accessibility notes.
${SAFETY_RULES}
`.trim(),
  model: DEFAULT_MODEL,
  tools: {
    fileWriteTool: fileTools.fileWriteTool,
    mongodbFindTool: mongodbTools.mongodbFindTool,
  },
});
