import { Agent } from "@mastra/core/agent";
import { mongodbTools } from "@/mastra/tools/mongodb-tools";
import { searchTools } from "@/mastra/tools/search-tools";
import { DEFAULT_MODEL, SAFETY_RULES } from "./shared";

export const prospectorAgent = new Agent({
  id: "prospector",
  name: "prospector",
  instructions: `
You are the Prospector. Find and qualify leads using web research. Score leads 0-100 with rationale.
Output contract: lead profile, score, evidence sources.
${SAFETY_RULES}
`.trim(),
  model: DEFAULT_MODEL,
  tools: {
    ...searchTools,
    ...mongodbTools,
  },
});
