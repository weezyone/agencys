import { Agent } from "@mastra/core/agent";
import { codeGenTools } from "@/mastra/tools/code-gen-tools";
import { fileTools } from "@/mastra/tools/file-tools";
import { DEFAULT_MODEL, SAFETY_RULES } from "./shared";

export const frontendAgent = new Agent({
  id: "frontend",
  name: "frontend",
  instructions: `
You are the Frontend specialist. Implement UI against design specs with TypeScript and tests.
Output contract: files changed, component APIs, test plan.
${SAFETY_RULES}
`.trim(),
  model: DEFAULT_MODEL,
  tools: {
    ...codeGenTools,
    ...fileTools,
  },
});
