import { backendAgent } from "./backend";
import { designAgent } from "./design";
import { frontendAgent } from "./frontend";
import { nurtureAgent } from "./nurture";
import { onboardingAgent } from "./onboarding";
import { projectManagerAgent } from "./project-manager";
import { prospectorAgent } from "./prospector";
import { qaAgent } from "./qa";
import { researchAgent } from "./research";
import { techLeadAgent } from "./tech-lead";

export const agents = {
  "project-manager": projectManagerAgent,
  "tech-lead": techLeadAgent,
  design: designAgent,
  research: researchAgent,
  frontend: frontendAgent,
  backend: backendAgent,
  qa: qaAgent,
  prospector: prospectorAgent,
  nurture: nurtureAgent,
  onboarding: onboardingAgent,
};

export const agentNames = Object.keys(agents) as Array<keyof typeof agents>;

export {
  backendAgent,
  designAgent,
  frontendAgent,
  nurtureAgent,
  onboardingAgent,
  projectManagerAgent,
  prospectorAgent,
  qaAgent,
  researchAgent,
  techLeadAgent,
};
