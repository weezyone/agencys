import { Agent } from "@mastra/core/agent";
import { createDynamicAgentFactoryTool } from "@/mastra/factories/agent-factory";
import { createDynamicToolFactoryTool } from "@/mastra/factories/tool-factory";
import { agencyOpsTools } from "@/mastra/tools/agency-ops-tools";
import { linearTools } from "@/mastra/tools/linear-tools";
import { mondayTools } from "@/mastra/tools/monday-tools";
import { mongodbTools } from "@/mastra/tools/mongodb-tools";
import { backendAgent } from "./backend";
import { designAgent } from "./design";
import { frontendAgent } from "./frontend";
import { nurtureAgent } from "./nurture";
import { onboardingAgent } from "./onboarding";
import { prospectorAgent } from "./prospector";
import { qaAgent } from "./qa";
import { researchAgent } from "./research";
import { DEFAULT_MODEL, SAFETY_RULES } from "./shared";
import { techLeadAgent } from "./tech-lead";

export const projectManagerAgent = new Agent({
  id: "project-manager",
  name: "project-manager",
  instructions: `
You are the Project Manager and central orchestrator of the digital agency.

Defining behaviors:
1. Decompose objectives into discrete tasks.
2. Delegate work to specialist teammates — NEVER complete specialist work yourself.
3. Monitor progress, assist, and unblock stuck agents.
4. Break ties when teammates disagree (deterministic: prefer documented evidence, then client goals, then risk reduction).
5. If a required tool is missing, create it via create-dynamic-tool.
6. If the team is undersized, create teammates via create-dynamic-agent.
7. Do not leave work unfinished or assume someone else will finish later.

Output contract:
- taskBreakdown[]
- assignments[]
- blockers[]
- decisions[]
- nextActions[]

${SAFETY_RULES}
`.trim(),
  model: DEFAULT_MODEL,
  tools: {
    ...mongodbTools,
    ...agencyOpsTools,
    ...linearTools,
    ...mondayTools,
    createDynamicToolFactoryTool,
    createDynamicAgentFactoryTool,
  },
  agents: {
    techLeadAgent,
    designAgent,
    researchAgent,
    frontendAgent,
    backendAgent,
    qaAgent,
    prospectorAgent,
    nurtureAgent,
    onboardingAgent,
  },
});
