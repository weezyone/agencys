import { createTool } from "@mastra/core/tools";
import { LinearClient } from "@linear/sdk";
import { z } from "zod";
import { appendActionLog } from "@/lib/observability/action-logger";
import { withResilience } from "@/lib/resilience";

export const linearCreateIssueTool = createTool({
  id: "linear-create-issue",
  description: "Create a Linear issue (sandboxed without LINEAR_API_KEY)",
  inputSchema: z.object({
    title: z.string().min(1),
    description: z.string().default(""),
    teamId: z.string().optional(),
  }),
  outputSchema: z.object({
    id: z.string(),
    url: z.string(),
    sandboxed: z.boolean(),
  }),
  execute: async ({ title, description, teamId }) => {
    const result = await withResilience(
      async () => {
        if (!process.env.LINEAR_API_KEY) {
          return {
            id: `linear-sandbox-${Date.now()}`,
            url: "https://linear.app/sandbox/issue",
            sandboxed: true,
          };
        }
        // Live Linear SDK calls require workspace team configuration.
        // Keep sandboxed-safe default when teamId is absent.
        if (!teamId) {
          return {
            id: `linear-pending-team-${Date.now()}`,
            url: "https://linear.app/issue/pending-team",
            sandboxed: true,
          };
        }
        const client = new LinearClient({ apiKey: process.env.LINEAR_API_KEY });
        const issuePayload = await client.createIssue({
          teamId,
          title,
          description,
        });
        const issue = await issuePayload.issue;
        return {
          id: issue?.id ?? `linear-${Date.now()}`,
          url: issue?.url ?? "https://linear.app",
          sandboxed: false,
        };
      },
      { circuit: { name: "linear" } },
    );
    await appendActionLog({
      agentName: "project-manager",
      toolName: "linear-create-issue",
      input: { title },
      output: result,
      status: "succeeded",
    });
    return result;
  },
});

export const linearTools = {
  linearCreateIssueTool,
};
