import { agencyOpsTools } from "./agency-ops-tools";
import { codeGenTools } from "./code-gen-tools";
import { emailTools } from "./email-tools";
import { fileTools } from "./file-tools";
import { githubTools } from "./github-tools";
import { linearTools } from "./linear-tools";
import { mondayTools } from "./monday-tools";
import { mongodbTools } from "./mongodb-tools";
import { searchTools } from "./search-tools";

export const allTools = {
  ...mongodbTools,
  ...searchTools,
  ...emailTools,
  ...fileTools,
  ...codeGenTools,
  ...githubTools,
  ...agencyOpsTools,
  ...linearTools,
  ...mondayTools,
};

export {
  agencyOpsTools,
  codeGenTools,
  emailTools,
  fileTools,
  githubTools,
  linearTools,
  mondayTools,
  mongodbTools,
  searchTools,
};
