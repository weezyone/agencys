import { createTool } from "@mastra/core/tools";
import { z } from "zod";
import { appendActionLog } from "@/lib/observability/action-logger";
import { fileWriteTool } from "./file-tools";

export const generateCodePlanTool = createTool({
  id: "generate-code-plan",
  description: "Generate a structured code plan for a feature",
  inputSchema: z.object({
    feature: z.string().min(1),
    stack: z.array(z.string()).default(["nextjs", "typescript"]),
  }),
  outputSchema: z.object({
    feature: z.string(),
    steps: z.array(z.string()),
    files: z.array(z.string()),
  }),
  execute: async ({ feature, stack }) => {
    const plan = {
      feature,
      steps: [
        `Clarify requirements for ${feature}`,
        "Write failing tests",
        "Implement minimal passing code",
        "Refactor with functional patterns",
        `Validate against stack: ${stack.join(", ")}`,
      ],
      files: [
        `src/features/${feature}/index.ts`,
        `src/features/${feature}/index.test.ts`,
      ],
    };
    await appendActionLog({
      agentName: "tech-lead",
      toolName: "generate-code-plan",
      input: { feature, stack },
      output: plan,
      status: "succeeded",
    });
    return plan;
  },
});

export const scaffoldFilesTool = createTool({
  id: "scaffold-files",
  description: "Write starter source files into the agency workspace",
  inputSchema: z.object({
    files: z.array(
      z.object({
        relativePath: z.string(),
        content: z.string(),
      }),
    ),
  }),
  outputSchema: z.object({
    written: z.array(z.string()),
  }),
  execute: async ({ files }) => {
    const written: string[] = [];
    for (const file of files) {
      await fileWriteTool.execute?.(
        { relativePath: file.relativePath, content: file.content },
        // @ts-expect-error optional context
        {},
      );
      written.push(file.relativePath);
    }
    return { written };
  },
});

export const codeGenTools = {
  generateCodePlanTool,
  scaffoldFilesTool,
};
