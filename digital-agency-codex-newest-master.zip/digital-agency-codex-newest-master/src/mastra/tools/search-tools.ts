import { createTool } from "@mastra/core/tools";
import Exa from "exa-js";
import { z } from "zod";
import { appendActionLog } from "@/lib/observability/action-logger";
import { withResilience } from "@/lib/resilience";

const getExa = (): Exa | null => {
  const key = process.env.EXA_API_KEY;
  if (!key) {
    return null;
  }
  return new Exa(key);
};

export const webSearchTool = createTool({
  id: "web-search",
  description: "Search the live web via Exa.ai",
  inputSchema: z.object({
    query: z.string().min(1),
    numResults: z.number().int().min(1).max(10).default(5),
  }),
  outputSchema: z.object({
    results: z.array(
      z.object({
        title: z.string(),
        url: z.string(),
        snippet: z.string(),
      }),
    ),
    source: z.literal("exa"),
  }),
  execute: async ({ query, numResults }) => {
    const result = await withResilience(
      async () => {
        const exa = getExa();
        if (!exa) {
          return {
            results: [
              {
                title: `Sandbox result for: ${query}`,
                url: "https://example.com/sandbox",
                snippet:
                  "EXA_API_KEY not configured; returning sandboxed search placeholder.",
              },
            ],
            source: "exa" as const,
          };
        }
        const response = await exa.searchAndContents(query, {
          numResults,
          text: true,
        });
        return {
          results: response.results.map((item) => ({
            title: item.title ?? "Untitled",
            url: item.url,
            snippet: (item.text ?? "").slice(0, 400),
          })),
          source: "exa" as const,
        };
      },
      { circuit: { name: "exa" }, timeoutMs: 20_000 },
    );
    await appendActionLog({
      agentName: "research",
      toolName: "web-search",
      input: { query, numResults },
      output: { count: result.results.length },
      status: "succeeded",
    });
    return result;
  },
});

export const companyLookupTool = createTool({
  id: "company-lookup",
  description: "Look up a company via Exa web search",
  inputSchema: z.object({
    company: z.string().min(1),
  }),
  outputSchema: z.object({
    company: z.string(),
    findings: z.array(z.string()),
    sources: z.array(z.string()),
  }),
  execute: async ({ company }) => {
    const search = await webSearchTool.execute?.(
      { query: `${company} company overview`, numResults: 3 },
      // @ts-expect-error mastra context optional in unit tests
      {},
    );
    const findings =
      search?.results.map((r) => r.snippet).filter(Boolean) ??
      [`No live data for ${company}`];
    const sources = search?.results.map((r) => r.url) ?? [];
    return { company, findings, sources };
  },
});

export const searchTools = {
  webSearchTool,
  companyLookupTool,
};
