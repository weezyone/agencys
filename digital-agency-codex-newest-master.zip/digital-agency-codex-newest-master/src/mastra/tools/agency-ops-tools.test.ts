import { describe, expect, it, vi } from "vitest";

vi.mock("@/lib/db/mongodb", () => ({
  connectToDatabase: vi.fn(async () => undefined),
}));

vi.mock("@/lib/db/models/project", () => ({
  Project: {
    findByIdAndUpdate: vi.fn(async () => ({})),
  },
}));

vi.mock("@/lib/observability/action-logger", () => ({
  appendActionLog: vi.fn(async () => "log-id"),
}));

import {
  buildMVPScaffoldTool,
  createProjectBriefTool,
  generateSOWTool,
} from "./agency-ops-tools";

describe("agency-ops-tools", () => {
  it("createProjectBriefTool returns structured brief", async () => {
    const brief = await createProjectBriefTool.execute?.(
      { clientInput: "Need a marketing site MVP" },
      // @ts-expect-error test context
      {},
    );
    expect(brief?.goals.length).toBeGreaterThan(0);
    expect(brief?.deliverables).toContain("Project brief");
  });

  it("generateSOWTool builds milestones from brief", async () => {
    const sow = await generateSOWTool.execute?.(
      {
        brief: {
          goals: ["Ship MVP"],
          scope: ["Build"],
          deliverables: ["Site", "CMS"],
          constraints: ["Budget"],
          successMetrics: ["Launch"],
        },
      },
      // @ts-expect-error test context
      {},
    );
    expect(sow?.milestones).toHaveLength(2);
    expect(sow?.timelineWeeks).toBeGreaterThanOrEqual(4);
  });

  it("buildMVPScaffoldTool returns tasks for features", async () => {
    const scaffold = await buildMVPScaffoldTool.execute?.(
      { features: ["auth", "dashboard"], stack: ["nextjs"] },
      // @ts-expect-error test context
      {},
    );
    expect(scaffold?.tasks).toEqual([
      "Ship auth with tests",
      "Ship dashboard with tests",
    ]);
  });
});
