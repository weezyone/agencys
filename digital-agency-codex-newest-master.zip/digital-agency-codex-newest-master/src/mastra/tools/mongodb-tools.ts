import { createTool } from "@mastra/core/tools";
import { z } from "zod";
import { Client } from "@/lib/db/models/client";
import { Project } from "@/lib/db/models/project";
import { Task } from "@/lib/db/models/task";
import { connectToDatabase } from "@/lib/db/mongodb";
import { appendActionLog } from "@/lib/observability/action-logger";
import { withResilience } from "@/lib/resilience";

const collectionSchema = z.enum(["clients", "projects", "tasks"]);

const getModel = (collection: z.infer<typeof collectionSchema>) => {
  switch (collection) {
    case "clients":
      return Client;
    case "projects":
      return Project;
    case "tasks":
      return Task;
    default: {
      const _exhaustive: never = collection;
      return _exhaustive;
    }
  }
};

export const mongodbFindTool = createTool({
  id: "mongodb-find",
  description: "Find documents in agency MongoDB collections",
  inputSchema: z.object({
    collection: collectionSchema,
    filter: z.record(z.unknown()).default({}),
    limit: z.number().int().min(1).max(100).default(20),
  }),
  outputSchema: z.object({
    items: z.array(z.record(z.unknown())),
    count: z.number(),
  }),
  execute: async ({ collection, filter, limit }) => {
    await appendActionLog({
      agentName: "system",
      toolName: "mongodb-find",
      input: { collection, filter, limit },
      status: "started",
    });
    try {
      const result = await withResilience(
        async () => {
          await connectToDatabase();
          const model = getModel(collection);
          const items = await model.find(filter).limit(limit).lean();
          return {
            items: items.map((item) => ({ ...item, _id: String(item._id) })),
            count: items.length,
          };
        },
        { circuit: { name: "mongodb" } },
      );
      await appendActionLog({
        agentName: "system",
        toolName: "mongodb-find",
        input: { collection, filter, limit },
        output: { count: result.count },
        status: "succeeded",
      });
      return result;
    } catch (error) {
      await appendActionLog({
        agentName: "system",
        toolName: "mongodb-find",
        input: { collection, filter, limit },
        status: "failed",
        errorMessage: error instanceof Error ? error.message : String(error),
      });
      throw error;
    }
  },
});

export const mongodbUpsertTool = createTool({
  id: "mongodb-upsert",
  description: "Create or update a document in agency MongoDB collections",
  inputSchema: z.object({
    collection: collectionSchema,
    id: z.string().optional(),
    data: z.record(z.unknown()),
  }),
  outputSchema: z.object({
    id: z.string(),
    created: z.boolean(),
  }),
  execute: async ({ collection, id, data }) => {
    const result = await withResilience(
      async () => {
        await connectToDatabase();
        const model = getModel(collection);
        if (id) {
          const updated = await model.findByIdAndUpdate(id, data, {
            new: true,
            upsert: true,
          });
          return { id: String(updated?._id ?? id), created: false };
        }
        const created = await model.create(data);
        return { id: String(created._id), created: true };
      },
      { circuit: { name: "mongodb" } },
    );
    await appendActionLog({
      agentName: "system",
      toolName: "mongodb-upsert",
      input: { collection, id },
      output: result,
      status: "succeeded",
    });
    return result;
  },
});

export const mongodbTools = {
  mongodbFindTool,
  mongodbUpsertTool,
};
