import { createTool } from "@mastra/core/tools";
import { Octokit } from "@octokit/rest";
import { z } from "zod";
import { appendActionLog } from "@/lib/observability/action-logger";
import { withResilience } from "@/lib/resilience";

const getOctokit = (): Octokit | null => {
  const token = process.env.GITHUB_TOKEN;
  return token ? new Octokit({ auth: token }) : null;
};

export const createIssueTool = createTool({
  id: "github-create-issue",
  description: "Create a GitHub issue (sandboxed when token missing)",
  inputSchema: z.object({
    owner: z.string(),
    repo: z.string(),
    title: z.string(),
    body: z.string().default(""),
  }),
  outputSchema: z.object({
    number: z.number(),
    url: z.string(),
    sandboxed: z.boolean(),
  }),
  execute: async ({ owner, repo, title, body }) => {
    const result = await withResilience(
      async () => {
        const octokit = getOctokit();
        if (!octokit) {
          return {
            number: Math.floor(Math.random() * 1000) + 1,
            url: `https://github.com/${owner}/${repo}/issues/sandbox`,
            sandboxed: true,
          };
        }
        const response = await octokit.issues.create({
          owner,
          repo,
          title,
          body,
        });
        return {
          number: response.data.number,
          url: response.data.html_url,
          sandboxed: false,
        };
      },
      { circuit: { name: "github" } },
    );
    await appendActionLog({
      agentName: "tech-lead",
      toolName: "github-create-issue",
      input: { owner, repo, title },
      output: result,
      status: "succeeded",
    });
    return result;
  },
});

export const createPullRequestTool = createTool({
  id: "github-create-pr",
  description: "Create a GitHub pull request (sandboxed when token missing)",
  inputSchema: z.object({
    owner: z.string(),
    repo: z.string(),
    title: z.string(),
    head: z.string(),
    base: z.string().default("main"),
    body: z.string().default(""),
  }),
  outputSchema: z.object({
    number: z.number(),
    url: z.string(),
    sandboxed: z.boolean(),
  }),
  execute: async ({ owner, repo, title, head, base, body }) => {
    const result = await withResilience(
      async () => {
        const octokit = getOctokit();
        if (!octokit) {
          return {
            number: Math.floor(Math.random() * 1000) + 1,
            url: `https://github.com/${owner}/${repo}/pull/sandbox`,
            sandboxed: true,
          };
        }
        const response = await octokit.pulls.create({
          owner,
          repo,
          title,
          head,
          base,
          body,
        });
        return {
          number: response.data.number,
          url: response.data.html_url,
          sandboxed: false,
        };
      },
      { circuit: { name: "github" } },
    );
    return result;
  },
});

export const githubTools = {
  createIssueTool,
  createPullRequestTool,
};
