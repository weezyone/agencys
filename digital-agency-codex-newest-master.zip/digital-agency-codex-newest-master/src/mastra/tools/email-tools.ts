import { createTool } from "@mastra/core/tools";
import { Resend } from "resend";
import { z } from "zod";
import { appendActionLog } from "@/lib/observability/action-logger";
import { withResilience } from "@/lib/resilience";

const getResend = (): Resend | null => {
  const key = process.env.RESEND_API_KEY;
  return key ? new Resend(key) : null;
};

export const sendEmailTool = createTool({
  id: "send-email",
  description: "Send a transactional email via Resend",
  inputSchema: z.object({
    to: z.string().email(),
    subject: z.string().min(1),
    html: z.string().min(1),
    from: z.string().email().default("agency@example.com"),
  }),
  outputSchema: z.object({
    id: z.string(),
    sandboxed: z.boolean(),
  }),
  execute: async ({ to, subject, html, from }) => {
    const result = await withResilience(
      async () => {
        const resend = getResend();
        if (!resend) {
          return {
            id: `sandbox-email-${Date.now()}`,
            sandboxed: true,
          };
        }
        const response = await resend.emails.send({
          from,
          to,
          subject,
          html,
        });
        return {
          id: response.data?.id ?? `email-${Date.now()}`,
          sandboxed: false,
        };
      },
      { circuit: { name: "resend" } },
    );
    await appendActionLog({
      agentName: "nurture",
      toolName: "send-email",
      input: { to, subject },
      output: result,
      status: "succeeded",
    });
    return result;
  },
});

export const scheduleSequenceTool = createTool({
  id: "schedule-email-sequence",
  description: "Schedule a simple nurture email sequence (persisted plan)",
  inputSchema: z.object({
    to: z.string().email(),
    steps: z
      .array(
        z.object({
          subject: z.string(),
          html: z.string(),
          delayDays: z.number().int().min(0).default(0),
        }),
      )
      .min(1),
  }),
  outputSchema: z.object({
    sequenceId: z.string(),
    stepCount: z.number(),
  }),
  execute: async ({ to, steps }) => {
    const sequenceId = `seq-${to}-${Date.now()}`;
    await appendActionLog({
      agentName: "nurture",
      toolName: "schedule-email-sequence",
      input: { to, stepCount: steps.length },
      output: { sequenceId },
      status: "succeeded",
    });
    return { sequenceId, stepCount: steps.length };
  },
});

export const emailTools = {
  sendEmailTool,
  scheduleSequenceTool,
};
