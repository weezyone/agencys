import { mkdir, readdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { createTool } from "@mastra/core/tools";
import { z } from "zod";
import { appendActionLog } from "@/lib/observability/action-logger";

const WORKSPACE_ROOT = path.join(process.cwd(), ".agency-workspace");

const resolveSafePath = (relativePath: string): string => {
  const resolved = path.resolve(WORKSPACE_ROOT, relativePath);
  if (!resolved.startsWith(WORKSPACE_ROOT)) {
    throw new Error("Path escapes agency workspace");
  }
  return resolved;
};

export const fileWriteTool = createTool({
  id: "file-write",
  description: "Write a file inside the sandboxed agency workspace",
  inputSchema: z.object({
    relativePath: z.string().min(1),
    content: z.string(),
  }),
  outputSchema: z.object({
    path: z.string(),
    bytes: z.number(),
  }),
  execute: async ({ relativePath, content }) => {
    const target = resolveSafePath(relativePath);
    await mkdir(path.dirname(target), { recursive: true });
    await writeFile(target, content, "utf8");
    await appendActionLog({
      agentName: "system",
      toolName: "file-write",
      input: { relativePath },
      output: { bytes: Buffer.byteLength(content, "utf8") },
      status: "succeeded",
    });
    return { path: relativePath, bytes: Buffer.byteLength(content, "utf8") };
  },
});

export const fileReadTool = createTool({
  id: "file-read",
  description: "Read a file from the sandboxed agency workspace",
  inputSchema: z.object({
    relativePath: z.string().min(1),
  }),
  outputSchema: z.object({
    path: z.string(),
    content: z.string(),
  }),
  execute: async ({ relativePath }) => {
    const target = resolveSafePath(relativePath);
    const content = await readFile(target, "utf8");
    return { path: relativePath, content };
  },
});

export const fileListTool = createTool({
  id: "file-list",
  description: "List files in a directory of the agency workspace",
  inputSchema: z.object({
    relativePath: z.string().default("."),
  }),
  outputSchema: z.object({
    entries: z.array(z.string()),
  }),
  execute: async ({ relativePath }) => {
    const target = resolveSafePath(relativePath);
    await mkdir(target, { recursive: true });
    const entries = await readdir(target);
    return { entries };
  },
});

export const fileTools = {
  fileWriteTool,
  fileReadTool,
  fileListTool,
};
