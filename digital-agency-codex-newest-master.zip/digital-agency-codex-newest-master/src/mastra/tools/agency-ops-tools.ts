import { createTool } from "@mastra/core/tools";
import { z } from "zod";
import { Project } from "@/lib/db/models/project";
import { connectToDatabase } from "@/lib/db/mongodb";
import { appendActionLog } from "@/lib/observability/action-logger";

const briefSchema = z.object({
  goals: z.array(z.string()),
  scope: z.array(z.string()),
  deliverables: z.array(z.string()),
  constraints: z.array(z.string()),
  successMetrics: z.array(z.string()),
});

const sowSchema = z.object({
  milestones: z.array(
    z.object({
      title: z.string(),
      dueInDays: z.number(),
      acceptanceCriteria: z.array(z.string()),
    }),
  ),
  timelineWeeks: z.number(),
  pricingAssumptions: z.array(z.string()),
  acceptanceCriteria: z.array(z.string()),
});

export const createProjectBriefTool = createTool({
  id: "create-project-brief",
  description: "Create a structured project brief from client input",
  inputSchema: z.object({
    clientInput: z.string().min(1),
    projectId: z.string().optional(),
  }),
  outputSchema: briefSchema.extend({
    projectId: z.string().optional(),
  }),
  execute: async ({ clientInput, projectId }) => {
    const brief = {
      goals: [`Deliver outcomes described in: ${clientInput.slice(0, 120)}`],
      scope: ["Discovery", "Design", "Implementation", "QA"],
      deliverables: ["Project brief", "SOW", "MVP scaffold", "Launch checklist"],
      constraints: ["Must use documented facts only", "TDD required"],
      successMetrics: ["Accepted SOW", "Working MVP scaffold", "Passing quality gates"],
    };

    if (projectId) {
      await connectToDatabase();
      await Project.findByIdAndUpdate(projectId, {
        brief,
        status: "briefing",
      });
    }

    await appendActionLog({
      agentName: "project-manager",
      toolName: "create-project-brief",
      input: { projectId, clientInputLength: clientInput.length },
      output: brief,
      status: "succeeded",
    });

    return { ...brief, projectId };
  },
});

export const generateSOWTool = createTool({
  id: "generate-sow",
  description: "Generate a statement of work from a project brief",
  inputSchema: z.object({
    brief: briefSchema,
    projectId: z.string().optional(),
  }),
  outputSchema: sowSchema.extend({
    projectId: z.string().optional(),
  }),
  execute: async ({ brief, projectId }) => {
    const sow = {
      milestones: brief.deliverables.map((deliverable, index) => ({
        title: deliverable,
        dueInDays: (index + 1) * 7,
        acceptanceCriteria: [`${deliverable} reviewed and approved`],
      })),
      timelineWeeks: Math.max(4, brief.deliverables.length),
      pricingAssumptions: [
        "Fixed scope based on brief constraints",
        "Excludes unpaid change requests",
      ],
      acceptanceCriteria: brief.successMetrics,
    };

    if (projectId) {
      await connectToDatabase();
      await Project.findByIdAndUpdate(projectId, {
        sow,
        status: "sow",
      });
    }

    await appendActionLog({
      agentName: "project-manager",
      toolName: "generate-sow",
      input: { projectId },
      output: sow,
      status: "succeeded",
    });

    return { ...sow, projectId };
  },
});

export const buildMVPScaffoldTool = createTool({
  id: "build-mvp-scaffold",
  description: "Build an MVP project scaffold plan and starter files/tasks",
  inputSchema: z.object({
    stack: z.array(z.string()).default(["nextjs", "typescript", "mongodb"]),
    features: z.array(z.string()).min(1),
    projectId: z.string().optional(),
  }),
  outputSchema: z.object({
    projectSkeleton: z.array(z.string()),
    codePlan: z.array(z.string()),
    starterFiles: z.array(
      z.object({
        path: z.string(),
        purpose: z.string(),
      }),
    ),
    tasks: z.array(z.string()),
    projectId: z.string().optional(),
  }),
  execute: async ({ stack, features, projectId }) => {
    const scaffold = {
      projectSkeleton: [
        "src/app",
        "src/components",
        "src/lib",
        "src/mastra",
        "tests",
      ],
      codePlan: [
        `Initialize stack: ${stack.join(", ")}`,
        ...features.map((feature) => `Implement feature: ${feature}`),
        "Add tests and CI gates",
      ],
      starterFiles: features.map((feature) => ({
        path: `src/features/${feature}/index.ts`,
        purpose: `Entry module for ${feature}`,
      })),
      tasks: features.map((feature) => `Ship ${feature} with tests`),
      projectId,
    };

    if (projectId) {
      await connectToDatabase();
      await Project.findByIdAndUpdate(projectId, {
        mvpScaffold: scaffold,
        status: "scaffolding",
      });
    }

    await appendActionLog({
      agentName: "tech-lead",
      toolName: "build-mvp-scaffold",
      input: { stack, features, projectId },
      output: { taskCount: scaffold.tasks.length },
      status: "succeeded",
    });

    return scaffold;
  },
});

export const agencyOpsTools = {
  createProjectBriefTool,
  generateSOWTool,
  buildMVPScaffoldTool,
};
