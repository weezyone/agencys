import { createTool } from "@mastra/core/tools";
import { GraphQLClient, gql } from "graphql-request";
import { z } from "zod";
import { appendActionLog } from "@/lib/observability/action-logger";
import { withResilience } from "@/lib/resilience";

export const mondayCreateItemTool = createTool({
  id: "monday-create-item",
  description: "Create a Monday.com board item (sandboxed without MONDAY_API_KEY)",
  inputSchema: z.object({
    boardId: z.string().default("sandbox-board"),
    itemName: z.string().min(1),
  }),
  outputSchema: z.object({
    id: z.string(),
    sandboxed: z.boolean(),
  }),
  execute: async ({ boardId, itemName }) => {
    const result = await withResilience(
      async () => {
        if (!process.env.MONDAY_API_KEY) {
          return {
            id: `monday-sandbox-${Date.now()}`,
            sandboxed: true,
          };
        }
        const client = new GraphQLClient("https://api.monday.com/v2", {
          headers: {
            Authorization: process.env.MONDAY_API_KEY,
          },
        });
        const mutation = gql`
          mutation ($boardId: ID!, $itemName: String!) {
            create_item(board_id: $boardId, item_name: $itemName) {
              id
            }
          }
        `;
        const data = await client.request<{ create_item: { id: string } }>(
          mutation,
          { boardId, itemName },
        );
        return { id: data.create_item.id, sandboxed: false };
      },
      { circuit: { name: "monday" } },
    );
    await appendActionLog({
      agentName: "project-manager",
      toolName: "monday-create-item",
      input: { boardId, itemName },
      output: result,
      status: "succeeded",
    });
    return result;
  },
});

export const mondayTools = {
  mondayCreateItemTool,
};
