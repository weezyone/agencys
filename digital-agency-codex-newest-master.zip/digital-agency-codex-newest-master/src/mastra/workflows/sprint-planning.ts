import { createStep, createWorkflow } from "@mastra/core/workflows";
import { z } from "zod";

const prioritizeStep = createStep({
  id: "prioritize",
  inputSchema: z.object({
    backlog: z.array(z.string()).min(1),
    capacity: z.number().int().min(1).default(5),
  }),
  outputSchema: z.object({
    selected: z.array(z.string()),
    deferred: z.array(z.string()),
  }),
  execute: async ({ inputData }) => ({
    selected: inputData.backlog.slice(0, inputData.capacity),
    deferred: inputData.backlog.slice(inputData.capacity),
  }),
});

const assignStep = createStep({
  id: "assign",
  inputSchema: prioritizeStep.outputSchema,
  outputSchema: z.object({
    assignments: z.array(
      z.object({
        task: z.string(),
        agent: z.string(),
      }),
    ),
    deferred: z.array(z.string()),
  }),
  execute: async ({ inputData }) => {
    const roster = [
      "frontend",
      "backend",
      "design",
      "qa",
      "tech-lead",
    ];
    return {
      assignments: inputData.selected.map((task, index) => ({
        task,
        agent: roster[index % roster.length] ?? "tech-lead",
      })),
      deferred: inputData.deferred,
    };
  },
});

export const sprintPlanningWorkflow = createWorkflow({
  id: "sprint-planning",
  inputSchema: z.object({
    backlog: z.array(z.string()).min(1),
    capacity: z.number().int().min(1).default(5),
  }),
  outputSchema: assignStep.outputSchema,
})
  .then(prioritizeStep)
  .then(assignStep)
  .commit();
