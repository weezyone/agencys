import { createStep, createWorkflow } from "@mastra/core/workflows";
import { z } from "zod";

const qualifyStep = createStep({
  id: "qualify-lead",
  inputSchema: z.object({
    company: z.string(),
    leadScore: z.number().min(0).max(100),
  }),
  outputSchema: z.object({
    company: z.string(),
    leadScore: z.number(),
    stage: z.enum(["qualified", "nurturing", "disqualified"]),
  }),
  execute: async ({ inputData }) => {
    const stage =
      inputData.leadScore >= 70
        ? ("qualified" as const)
        : inputData.leadScore >= 40
          ? ("nurturing" as const)
          : ("disqualified" as const);
    return {
      company: inputData.company,
      leadScore: inputData.leadScore,
      stage,
    };
  },
});

const highTouchStep = createStep({
  id: "high-touch",
  inputSchema: qualifyStep.outputSchema,
  outputSchema: z.object({
    company: z.string(),
    action: z.string(),
    pipelineStage: z.literal("onboarded"),
  }),
  execute: async ({ inputData }) => ({
    company: inputData.company,
    action: "Schedule onboarding kickoff",
    pipelineStage: "onboarded" as const,
  }),
});

const nurtureStep = createStep({
  id: "nurture-sequence",
  inputSchema: qualifyStep.outputSchema,
  outputSchema: z.object({
    company: z.string(),
    action: z.string(),
    pipelineStage: z.literal("nurturing"),
  }),
  execute: async ({ inputData }) => ({
    company: inputData.company,
    action: "Start nurture email sequence",
    pipelineStage: "nurturing" as const,
  }),
});

const rejectStep = createStep({
  id: "reject-lead",
  inputSchema: qualifyStep.outputSchema,
  outputSchema: z.object({
    company: z.string(),
    action: z.string(),
    pipelineStage: z.literal("churned"),
  }),
  execute: async ({ inputData }) => ({
    company: inputData.company,
    action: "Park lead; insufficient score",
    pipelineStage: "churned" as const,
  }),
});

export const clientPipelineWorkflow = createWorkflow({
  id: "client-pipeline",
  inputSchema: z.object({
    company: z.string(),
    leadScore: z.number().min(0).max(100),
  }),
  outputSchema: z.object({
    company: z.string(),
    action: z.string(),
    pipelineStage: z.enum(["onboarded", "nurturing", "churned"]),
  }),
})
  .then(qualifyStep)
  .branch([
    [async ({ inputData }) => inputData.stage === "qualified", highTouchStep],
    [async ({ inputData }) => inputData.stage === "nurturing", nurtureStep],
    [async ({ inputData }) => inputData.stage === "disqualified", rejectStep],
  ])
  .commit();

/** Pure helper for unit/integration tests without Mastra runtime. */
export const runClientPipelineLogic = (input: {
  company: string;
  leadScore: number;
}) => {
  const stage =
    input.leadScore >= 70
      ? "qualified"
      : input.leadScore >= 40
        ? "nurturing"
        : "disqualified";
  if (stage === "qualified") {
    return {
      company: input.company,
      action: "Schedule onboarding kickoff",
      pipelineStage: "onboarded" as const,
    };
  }
  if (stage === "nurturing") {
    return {
      company: input.company,
      action: "Start nurture email sequence",
      pipelineStage: "nurturing" as const,
    };
  }
  return {
    company: input.company,
    action: "Park lead; insufficient score",
    pipelineStage: "churned" as const,
  };
};
