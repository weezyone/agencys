import { agencyDeliveryWorkflow } from "./agency-delivery";
import { clientPipelineWorkflow } from "./client-pipeline";
import { codeReviewWorkflow } from "./code-review";
import { projectLifecycleWorkflow } from "./project-lifecycle";
import { sprintPlanningWorkflow } from "./sprint-planning";

export const workflows = {
  "client-pipeline": clientPipelineWorkflow,
  "project-lifecycle": projectLifecycleWorkflow,
  "code-review": codeReviewWorkflow,
  "sprint-planning": sprintPlanningWorkflow,
  "agency-delivery": agencyDeliveryWorkflow,
};

export {
  agencyDeliveryWorkflow,
  clientPipelineWorkflow,
  codeReviewWorkflow,
  projectLifecycleWorkflow,
  sprintPlanningWorkflow,
};
