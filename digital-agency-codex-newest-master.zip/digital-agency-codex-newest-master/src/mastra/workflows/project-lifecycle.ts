import { createStep, createWorkflow } from "@mastra/core/workflows";
import { z } from "zod";

const intakeStep = createStep({
  id: "intake",
  inputSchema: z.object({
    projectName: z.string(),
    clientInput: z.string(),
  }),
  outputSchema: z.object({
    projectName: z.string(),
    status: z.literal("intake"),
    notes: z.string(),
  }),
  execute: async ({ inputData }) => ({
    projectName: inputData.projectName,
    status: "intake" as const,
    notes: inputData.clientInput,
  }),
});

const planningStep = createStep({
  id: "planning",
  inputSchema: intakeStep.outputSchema,
  outputSchema: z.object({
    projectName: z.string(),
    status: z.literal("in-progress"),
    tasks: z.array(z.string()),
  }),
  execute: async ({ inputData }) => ({
    projectName: inputData.projectName,
    status: "in-progress" as const,
    tasks: ["Design", "Implement", "QA", "Review"],
  }),
});

const deliveryStep = createStep({
  id: "delivery",
  inputSchema: planningStep.outputSchema,
  outputSchema: z.object({
    projectName: z.string(),
    status: z.literal("delivered"),
    completedTasks: z.array(z.string()),
  }),
  execute: async ({ inputData }) => ({
    projectName: inputData.projectName,
    status: "delivered" as const,
    completedTasks: inputData.tasks,
  }),
});

export const projectLifecycleWorkflow = createWorkflow({
  id: "project-lifecycle",
  inputSchema: z.object({
    projectName: z.string(),
    clientInput: z.string(),
  }),
  outputSchema: deliveryStep.outputSchema,
})
  .then(intakeStep)
  .then(planningStep)
  .then(deliveryStep)
  .commit();

export const runProjectLifecycleLogic = (input: {
  projectName: string;
  clientInput: string;
}) => ({
  projectName: input.projectName,
  status: "delivered" as const,
  completedTasks: ["Design", "Implement", "QA", "Review"],
});
