import { createStep, createWorkflow } from "@mastra/core/workflows";
import { z } from "zod";

const intakeStep = createStep({
  id: "agency-intake",
  inputSchema: z.object({
    clientInput: z.string(),
    stack: z.array(z.string()).default(["nextjs", "typescript", "mongodb"]),
    features: z.array(z.string()).default(["core"]),
  }),
  outputSchema: z.object({
    clientInput: z.string(),
    stack: z.array(z.string()),
    features: z.array(z.string()),
    phase: z.literal("intake"),
  }),
  execute: async ({ inputData }) => ({
    ...inputData,
    phase: "intake" as const,
  }),
});

const briefStep = createStep({
  id: "brief",
  inputSchema: intakeStep.outputSchema,
  outputSchema: z.object({
    brief: z.object({
      goals: z.array(z.string()),
      deliverables: z.array(z.string()),
    }),
    stack: z.array(z.string()),
    features: z.array(z.string()),
    phase: z.literal("brief"),
  }),
  execute: async ({ inputData }) => ({
    brief: {
      goals: [inputData.clientInput.slice(0, 160)],
      deliverables: ["SOW", "MVP scaffold"],
    },
    stack: inputData.stack,
    features: inputData.features,
    phase: "brief" as const,
  }),
});

const sowStep = createStep({
  id: "sow",
  inputSchema: briefStep.outputSchema,
  outputSchema: z.object({
    sow: z.object({
      milestones: z.array(z.string()),
      timelineWeeks: z.number(),
    }),
    stack: z.array(z.string()),
    features: z.array(z.string()),
    phase: z.literal("sow"),
  }),
  execute: async ({ inputData }) => ({
    sow: {
      milestones: inputData.brief.deliverables,
      timelineWeeks: 4,
    },
    stack: inputData.stack,
    features: inputData.features,
    phase: "sow" as const,
  }),
});

const scaffoldStep = createStep({
  id: "mvp-scaffold",
  inputSchema: sowStep.outputSchema,
  outputSchema: z.object({
    scaffold: z.object({
      tasks: z.array(z.string()),
    }),
    phase: z.literal("scaffolding"),
  }),
  execute: async ({ inputData }) => ({
    scaffold: {
      tasks: inputData.features.map((feature) => `Ship ${feature}`),
    },
    phase: "scaffolding" as const,
  }),
});

const pmHandoffStep = createStep({
  id: "pm-handoff",
  inputSchema: scaffoldStep.outputSchema,
  outputSchema: z.object({
    status: z.literal("handed-off"),
    tasks: z.array(z.string()),
    owner: z.literal("project-manager"),
  }),
  execute: async ({ inputData }) => ({
    status: "handed-off" as const,
    tasks: inputData.scaffold.tasks,
    owner: "project-manager" as const,
  }),
});

export const agencyDeliveryWorkflow = createWorkflow({
  id: "agency-delivery",
  inputSchema: intakeStep.inputSchema,
  outputSchema: pmHandoffStep.outputSchema,
})
  .then(intakeStep)
  .then(briefStep)
  .then(sowStep)
  .then(scaffoldStep)
  .then(pmHandoffStep)
  .commit();

export const runAgencyDeliveryLogic = (input: {
  clientInput: string;
  features?: string[];
}) => {
  const features = input.features ?? ["core"];
  return {
    status: "handed-off" as const,
    tasks: features.map((feature) => `Ship ${feature}`),
    owner: "project-manager" as const,
  };
};
