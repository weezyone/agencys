import { createStep, createWorkflow } from "@mastra/core/workflows";
import { z } from "zod";

const collectDiffStep = createStep({
  id: "collect-diff",
  inputSchema: z.object({
    prUrl: z.string(),
    summary: z.string().default(""),
  }),
  outputSchema: z.object({
    prUrl: z.string(),
    findings: z.array(z.string()),
  }),
  execute: async ({ inputData }) => ({
    prUrl: inputData.prUrl,
    findings: [
      "Check types and Zod contracts",
      "Verify tests cover changed paths",
      inputData.summary || "No summary provided",
    ],
  }),
});

const verdictStep = createStep({
  id: "verdict",
  inputSchema: collectDiffStep.outputSchema,
  outputSchema: z.object({
    prUrl: z.string(),
    approved: z.boolean(),
    comments: z.array(z.string()),
  }),
  execute: async ({ inputData }) => ({
    prUrl: inputData.prUrl,
    approved: true,
    comments: inputData.findings,
  }),
});

export const codeReviewWorkflow = createWorkflow({
  id: "code-review",
  inputSchema: z.object({
    prUrl: z.string(),
    summary: z.string().default(""),
  }),
  outputSchema: verdictStep.outputSchema,
})
  .then(collectDiffStep)
  .then(verdictStep)
  .commit();
