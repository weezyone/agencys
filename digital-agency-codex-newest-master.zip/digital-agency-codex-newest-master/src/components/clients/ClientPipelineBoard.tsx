import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

type PipelineClient = {
  id: string;
  company: string;
  pipelineStage: string;
  leadScore: number;
};

type ClientPipelineBoardProps = {
  clients: PipelineClient[];
};

const STAGES = ["lead", "qualified", "nurturing", "onboarded", "churned"];

export function ClientPipelineBoard({ clients }: ClientPipelineBoardProps) {
  const stages = [
    ...new Set([...STAGES, ...clients.map((c) => c.pipelineStage)]),
  ];

  return (
    <div className="grid gap-4 md:grid-cols-3 lg:grid-cols-5">
      {stages.map((stage) => {
        const stageClients = clients.filter((c) => c.pipelineStage === stage);
        return (
          <section
            key={stage}
            className="rounded-xl border border-border bg-muted/30 p-3"
          >
            <header className="mb-3 flex items-center justify-between">
              <h3 className="text-sm font-semibold capitalize">{stage}</h3>
              <span className="text-xs text-muted-foreground">
                {stageClients.length}
              </span>
            </header>
            <div className="space-y-2">
              {stageClients.map((client) => (
                <Link key={client.id} href={`/clients/${client.id}`}>
                  <Card className="transition-colors hover:bg-accent/50">
                    <CardHeader className="pb-1 pt-3">
                      <CardTitle className="text-sm">{client.company}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Badge variant="secondary">Score {client.leadScore}</Badge>
                    </CardContent>
                  </Card>
                </Link>
              ))}
              {stageClients.length === 0 && (
                <p className="text-xs text-muted-foreground">No clients</p>
              )}
            </div>
          </section>
        );
      })}
    </div>
  );
}
