/**
 * @vitest-environment jsdom
 */
import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { TaskCard } from "@/components/projects/TaskCard";

describe("TaskCard", () => {
  it("renders title, status, and assigned agent", () => {
    render(
      <TaskCard
        title="Build API"
        status="in-progress"
        assignedAgent="backend"
      />,
    );

    expect(screen.getByText("Build API")).toBeInTheDocument();
    expect(screen.getByText("in-progress")).toBeInTheDocument();
    expect(screen.getByText("backend")).toBeInTheDocument();
  });

  it("renders without assigned agent", () => {
    render(<TaskCard title="Untitled" status="todo" />);
    expect(screen.getByText("Untitled")).toBeInTheDocument();
    expect(screen.getByText("todo")).toBeInTheDocument();
  });
});
