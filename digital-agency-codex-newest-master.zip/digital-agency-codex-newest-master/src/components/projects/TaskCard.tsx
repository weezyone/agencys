import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

type TaskCardProps = {
  title: string;
  status: string;
  assignedAgent?: string;
};

export function TaskCard({ title, status, assignedAgent }: TaskCardProps) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base">{title}</CardTitle>
      </CardHeader>
      <CardContent className="flex items-center justify-between gap-2">
        <Badge variant="secondary">{status}</Badge>
        {assignedAgent && (
          <span className="text-xs text-muted-foreground">{assignedAgent}</span>
        )}
      </CardContent>
    </Card>
  );
}
