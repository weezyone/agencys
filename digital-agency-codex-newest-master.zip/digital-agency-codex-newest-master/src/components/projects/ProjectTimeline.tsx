import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

type Milestone = {
  title: string;
  dueDate?: string;
  status?: string;
};

type ProjectTimelineProps = {
  milestones: Milestone[];
};

export function ProjectTimeline({ milestones }: ProjectTimelineProps) {
  return (
    <div className="space-y-3">
      {milestones.map((milestone, index) => (
        <Card key={`${milestone.title}-${index}`}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-base">{milestone.title}</CardTitle>
            {milestone.status && (
              <Badge variant="outline">{milestone.status}</Badge>
            )}
          </CardHeader>
          {milestone.dueDate && (
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Due {new Date(milestone.dueDate).toLocaleDateString()}
              </p>
            </CardContent>
          )}
        </Card>
      ))}
    </div>
  );
}
