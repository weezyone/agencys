import { TaskCard } from "@/components/projects/TaskCard";

type KanbanTask = {
  id: string;
  title: string;
  status: string;
  assignedAgent?: string;
};

type KanbanBoardProps = {
  tasks: KanbanTask[];
};

const DEFAULT_COLUMNS = ["backlog", "todo", "in-progress", "review", "done"];

export function KanbanBoard({ tasks }: KanbanBoardProps) {
  const statuses = [
    ...new Set([
      ...DEFAULT_COLUMNS,
      ...tasks.map((task) => task.status),
    ]),
  ];

  return (
    <div className="grid gap-4 md:grid-cols-3 lg:grid-cols-5">
      {statuses.map((status) => {
        const columnTasks = tasks.filter((task) => task.status === status);
        return (
          <section
            key={status}
            className="rounded-xl border border-border bg-muted/30 p-3"
          >
            <header className="mb-3 flex items-center justify-between">
              <h3 className="text-sm font-semibold capitalize">{status}</h3>
              <span className="text-xs text-muted-foreground">
                {columnTasks.length}
              </span>
            </header>
            <div className="space-y-2">
              {columnTasks.map((task) => (
                <TaskCard
                  key={task.id}
                  title={task.title}
                  status={task.status}
                  assignedAgent={task.assignedAgent}
                />
              ))}
              {columnTasks.length === 0 && (
                <p className="text-xs text-muted-foreground">No tasks</p>
              )}
            </div>
          </section>
        );
      })}
    </div>
  );
}
