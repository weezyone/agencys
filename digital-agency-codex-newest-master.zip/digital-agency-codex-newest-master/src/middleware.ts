import { auth } from "../auth";

export default auth((req) => {
  const isLoggedIn = !!req.auth;
  const { pathname } = req.nextUrl;

  const isAuthRoute = pathname.startsWith("/api/auth");
  const isPublicRoute = pathname === "/" || pathname.startsWith("/login");

  if (isAuthRoute || isPublicRoute) {
    return;
  }

  const isProtected =
    pathname.startsWith("/dashboard") ||
    pathname.startsWith("/projects") ||
    pathname.startsWith("/clients") ||
    pathname.startsWith("/agents") ||
    pathname.startsWith("/portal") ||
    (pathname.startsWith("/api") && !isAuthRoute);

  if (isProtected && !isLoggedIn) {
    const signInUrl = new URL("/login", req.nextUrl.origin);
    signInUrl.searchParams.set("callbackUrl", pathname);
    return Response.redirect(signInUrl);
  }
});

export const config = {
  matcher: [
    "/",
    "/dashboard/:path*",
    "/projects/:path*",
    "/clients/:path*",
    "/agents/:path*",
    "/portal/:path*",
    "/api/:path*",
  ],
};
