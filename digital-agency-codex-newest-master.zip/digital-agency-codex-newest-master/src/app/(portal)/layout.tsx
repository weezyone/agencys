import Link from "next/link";

export default function PortalLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4">
          <Link href="/portal" className="text-lg font-semibold">
            Client Portal
          </Link>
          <nav className="flex gap-4 text-sm">
            <Link href="/portal" className="text-muted-foreground hover:text-foreground">
              Home
            </Link>
            <Link href="/dashboard" className="text-muted-foreground hover:text-foreground">
              Agency Dashboard
            </Link>
          </nav>
        </div>
      </header>
      <main className="mx-auto max-w-5xl p-6">{children}</main>
    </div>
  );
}
