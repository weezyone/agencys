import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function PortalPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Welcome to your portal</h1>
        <p className="text-muted-foreground">
          Track project status, deliverables, and communications.
        </p>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Active Project</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Your rebrand project is in design review.
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Next Milestone</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Beta launch — September 1, 2026
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
