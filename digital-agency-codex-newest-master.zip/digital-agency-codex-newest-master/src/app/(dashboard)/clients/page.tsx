import { ClientPipelineBoard } from "@/components/clients/ClientPipelineBoard";

const DEMO_CLIENTS = [
  { id: "1", company: "Acme Corp", pipelineStage: "qualified", leadScore: 82 },
  { id: "2", company: "Beta LLC", pipelineStage: "lead", leadScore: 45 },
  { id: "3", company: "Gamma Inc", pipelineStage: "nurturing", leadScore: 61 },
  { id: "4", company: "Delta Co", pipelineStage: "onboarded", leadScore: 90 },
];

async function fetchClients() {
  try {
    const base = process.env.NEXTAUTH_URL ?? "http://localhost:3000";
    const res = await fetch(`${base}/api/clients`, { cache: "no-store" });
    if (!res.ok) return DEMO_CLIENTS;
    const data = (await res.json()) as {
      clients?: Array<{
        _id: string;
        company?: string;
        name?: string;
        status?: string;
        leadScore?: number;
      }>;
    };
    if (!data.clients?.length) return DEMO_CLIENTS;
    return data.clients.map((c) => ({
      id: c._id,
      company: c.company ?? c.name ?? "Unknown",
      pipelineStage: c.status ?? "lead",
      leadScore: c.leadScore ?? 0,
    }));
  } catch {
    return DEMO_CLIENTS;
  }
}

export default async function ClientsPage() {
  const clients = await fetchClients();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Clients</h1>
        <p className="text-muted-foreground">Sales pipeline and lead scoring.</p>
      </div>
      <ClientPipelineBoard clients={clients} />
    </div>
  );
}
