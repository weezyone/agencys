import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

type PageProps = {
  params: Promise<{ id: string }>;
};

export default async function ClientDetailPage({ params }: PageProps) {
  const { id } = await params;

  return (
    <div className="space-y-6">
      <div>
        <Link href="/clients" className="text-sm text-muted-foreground hover:text-foreground">
          ← Back to clients
        </Link>
        <h1 className="mt-2 text-2xl font-bold tracking-tight">Client {id}</h1>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Profile</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <p>Company: Demo Corp</p>
            <p>Email: contact@demo.com</p>
            <Badge variant="secondary">Lead score: 72</Badge>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Pipeline</CardTitle>
          </CardHeader>
          <CardContent>
            <Badge>qualified</Badge>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
