import { AgentChat } from "@/components/agents/AgentChat";
import Link from "next/link";
import { agentNames } from "@/mastra/agents";
import { notFound } from "next/navigation";

type PageProps = {
  params: Promise<{ name: string }>;
};

export default async function AgentDetailPage({ params }: PageProps) {
  const { name } = await params;

  if (!agentNames.includes(name as (typeof agentNames)[number])) {
    notFound();
  }

  return (
    <div className="space-y-6">
      <div>
        <Link href="/agents" className="text-sm text-muted-foreground hover:text-foreground">
          ← Back to agents
        </Link>
        <h1 className="mt-2 text-2xl font-bold capitalize tracking-tight">
          {name.replace(/-/g, " ")}
        </h1>
      </div>
      <AgentChat agentName={name} />
    </div>
  );
}
