import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { agentNames } from "@/mastra/agents";

export default function AgentsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Agents</h1>
        <p className="text-muted-foreground">
          Specialist AI teammates for delivery and growth.
        </p>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {agentNames.map((name) => (
          <Link key={name} href={`/agents/${name}`}>
            <Card className="transition-colors hover:bg-accent/30">
              <CardHeader>
                <CardTitle className="capitalize">{name.replace(/-/g, " ")}</CardTitle>
              </CardHeader>
              <CardContent>
                <Badge variant="outline">Online</Badge>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
