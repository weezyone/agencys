import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

type ProjectRow = {
  _id: string;
  name: string;
  status: string;
  clientId?: string;
};

const DEMO_PROJECTS: ProjectRow[] = [
  { _id: "1", name: "Acme Rebrand", status: "active", clientId: "c1" },
  { _id: "2", name: "Beta App MVP", status: "in-progress", clientId: "c2" },
  { _id: "3", name: "Gamma Portal", status: "review", clientId: "c3" },
];

async function fetchProjects(): Promise<ProjectRow[]> {
  try {
    const base = process.env.NEXTAUTH_URL ?? "http://localhost:3000";
    const res = await fetch(`${base}/api/projects`, { cache: "no-store" });
    if (!res.ok) return DEMO_PROJECTS;
    const data = (await res.json()) as { projects?: ProjectRow[] };
    return data.projects?.length ? data.projects : DEMO_PROJECTS;
  } catch {
    return DEMO_PROJECTS;
  }
}

export default async function ProjectsPage() {
  const projects = await fetchProjects();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Projects</h1>
        <p className="text-muted-foreground">All agency delivery workstreams.</p>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {projects.map((project) => (
          <Link key={project._id} href={`/projects/${project._id}`}>
            <Card className="transition-colors hover:bg-accent/30">
              <CardHeader>
                <CardTitle className="text-lg">{project.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <Badge variant="secondary">{project.status}</Badge>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
