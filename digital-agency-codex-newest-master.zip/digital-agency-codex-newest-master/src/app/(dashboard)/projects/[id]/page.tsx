import { KanbanBoard } from "@/components/projects/KanbanBoard";
import { ProjectTimeline } from "@/components/projects/ProjectTimeline";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

type PageProps = {
  params: Promise<{ id: string }>;
};

const DEMO_TASKS = [
  { id: "t1", title: "Discovery workshop", status: "done", assignedAgent: "project-manager" },
  { id: "t2", title: "Wireframes", status: "review", assignedAgent: "design" },
  { id: "t3", title: "API scaffold", status: "in-progress", assignedAgent: "backend" },
  { id: "t4", title: "Landing page", status: "todo", assignedAgent: "frontend" },
];

const DEMO_MILESTONES = [
  { title: "Kickoff", dueDate: "2026-08-01", status: "complete" },
  { title: "Design review", dueDate: "2026-08-15", status: "in-progress" },
  { title: "Beta launch", dueDate: "2026-09-01", status: "upcoming" },
];

export default async function ProjectDetailPage({ params }: PageProps) {
  const { id } = await params;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Project {id}</h1>
        <p className="text-muted-foreground">Delivery workspace</p>
      </div>

      <Tabs defaultValue="board">
        <TabsList>
          <TabsTrigger value="board">Board</TabsTrigger>
          <TabsTrigger value="timeline">Timeline</TabsTrigger>
          <TabsTrigger value="brief">Brief</TabsTrigger>
          <TabsTrigger value="sow">SOW</TabsTrigger>
        </TabsList>

        <TabsContent value="board">
          <KanbanBoard tasks={DEMO_TASKS} />
        </TabsContent>

        <TabsContent value="timeline">
          <ProjectTimeline milestones={DEMO_MILESTONES} />
        </TabsContent>

        <TabsContent value="brief">
          <Card>
            <CardHeader>
              <CardTitle>Project Brief</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Brief content placeholder — connect to project.brief from MongoDB.
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sow">
          <Card>
            <CardHeader>
              <CardTitle>Statement of Work</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                SOW placeholder — connect to project.sow from MongoDB.
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
