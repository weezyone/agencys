import { NextResponse } from "next/server";
import { auth } from "../../../../../../auth";
import {
  AuthenticationError,
  AuthorizationError,
  requireRole,
} from "@/lib/auth/rbac";
import {
  createCorrelationId,
  runWithCorrelationAsync,
} from "@/lib/observability/correlation";
import { logger } from "@/lib/observability/logger";
import { agentChatInputSchema } from "@/lib/db/schemas/api";
import { agents } from "@/mastra/agents";

type RouteContext = {
  params: Promise<{ name: string }>;
};

function jsonError(error: unknown, correlationId: string) {
  if (error instanceof AuthenticationError) {
    return NextResponse.json(
      { error: error.message, correlationId },
      { status: 401, headers: { "x-correlation-id": correlationId } },
    );
  }
  if (error instanceof AuthorizationError) {
    return NextResponse.json(
      { error: error.message, correlationId },
      { status: 403, headers: { "x-correlation-id": correlationId } },
    );
  }
  logger.error("Agent chat error", { error, correlationId });
  return NextResponse.json(
    { error: error instanceof Error ? error.message : "Internal server error", correlationId },
    { status: 500, headers: { "x-correlation-id": correlationId } },
  );
}

export async function POST(request: Request, context: RouteContext) {
  const correlationId =
    request.headers.get("x-correlation-id") ?? createCorrelationId();
  const { name } = await context.params;

  return runWithCorrelationAsync(correlationId, async () => {
    try {
      const session = await auth();
      requireRole(session, ["admin", "agent-operator"]);

      const agent = agents[name as keyof typeof agents];
      if (!agent) {
        return NextResponse.json(
          {
            error: `Unknown agent: ${name}`,
            available: Object.keys(agents),
            correlationId,
          },
          { status: 404, headers: { "x-correlation-id": correlationId } },
        );
      }

      const body: unknown = await request.json();
      const parsed = agentChatInputSchema.safeParse(body);
      if (!parsed.success) {
        return NextResponse.json(
          { error: parsed.error.flatten(), correlationId },
          { status: 400, headers: { "x-correlation-id": correlationId } },
        );
      }

      if (!process.env.OPENAI_API_KEY) {
        const fallback =
          `[Demo mode] Agent "${name}" received ${parsed.data.messages.length} message(s). ` +
          "Set OPENAI_API_KEY to enable live responses.";
        return new Response(fallback, {
          headers: {
            "Content-Type": "text/plain; charset=utf-8",
            "x-correlation-id": correlationId,
          },
        });
      }

      const lastUser = [...parsed.data.messages].reverse().find((m) => m.role === "user");
      const prompt = lastUser?.content ?? parsed.data.messages.at(-1)?.content ?? "";

      try {
        const streamResult = await agent.stream(prompt, {
          memory: { thread: `chat-${name}`, resource: session?.user?.id ?? "anonymous" },
        });

        if (streamResult.textStream) {
          const stream = new ReadableStream({
            async start(controller) {
              const encoder = new TextEncoder();
              try {
                for await (const chunk of streamResult.textStream) {
                  controller.enqueue(encoder.encode(chunk));
                }
              } catch (streamError) {
                const message =
                  streamError instanceof Error ? streamError.message : "Stream failed";
                controller.enqueue(encoder.encode(`\n[Error: ${message}]`));
              } finally {
                controller.close();
              }
            },
          });

          return new Response(stream, {
            headers: {
              "Content-Type": "text/plain; charset=utf-8",
              "x-correlation-id": correlationId,
            },
          });
        }
      } catch {
        // fall through to generate
      }

      const generated = await agent.generate(prompt);
      const text =
        typeof generated.text === "string"
          ? generated.text
          : JSON.stringify(generated, null, 2);

      return NextResponse.json(
        { text, correlationId },
        { headers: { "x-correlation-id": correlationId } },
      );
    } catch (error) {
      return jsonError(error, correlationId);
    }
  });
}
