import { NextResponse } from "next/server";
import { auth } from "../../../../auth";
import {
  AuthenticationError,
  AuthorizationError,
  requireRole,
} from "@/lib/auth/rbac";
import {
  createCorrelationId,
  runWithCorrelationAsync,
} from "@/lib/observability/correlation";
import { logger } from "@/lib/observability/logger";
import { projectInputSchema } from "@/lib/db/schemas/api";
import { connectToDatabase } from "@/lib/db/mongodb";
import { Project } from "@/lib/db/models/project";

function jsonError(error: unknown, correlationId: string) {
  if (error instanceof AuthenticationError) {
    return NextResponse.json(
      { error: error.message, correlationId },
      { status: 401, headers: { "x-correlation-id": correlationId } },
    );
  }
  if (error instanceof AuthorizationError) {
    return NextResponse.json(
      { error: error.message, correlationId },
      { status: 403, headers: { "x-correlation-id": correlationId } },
    );
  }
  logger.error("Projects API error", { error, correlationId });
  return NextResponse.json(
    { error: "Internal server error", correlationId },
    { status: 500, headers: { "x-correlation-id": correlationId } },
  );
}

export async function GET(request: Request) {
  const correlationId =
    request.headers.get("x-correlation-id") ?? createCorrelationId();

  return runWithCorrelationAsync(correlationId, async () => {
    try {
      const session = await auth();
      requireRole(session, ["admin", "agent-operator"]);

      try {
        await connectToDatabase();
        const projects = await Project.find().sort({ updatedAt: -1 }).limit(100).lean();
        return NextResponse.json(
          { projects, correlationId },
          { headers: { "x-correlation-id": correlationId } },
        );
      } catch {
        return NextResponse.json(
          {
            projects: [
              {
                _id: "demo-1",
                name: "Acme Rebrand",
                status: "active",
                clientId: "demo-client",
              },
            ],
            demo: true,
            correlationId,
          },
          { headers: { "x-correlation-id": correlationId } },
        );
      }
    } catch (error) {
      return jsonError(error, correlationId);
    }
  });
}

export async function POST(request: Request) {
  const correlationId =
    request.headers.get("x-correlation-id") ?? createCorrelationId();

  return runWithCorrelationAsync(correlationId, async () => {
    try {
      const session = await auth();
      requireRole(session, ["admin", "agent-operator"]);

      const body: unknown = await request.json();
      const parsed = projectInputSchema.safeParse(body);
      if (!parsed.success) {
        return NextResponse.json(
          { error: parsed.error.flatten(), correlationId },
          { status: 400, headers: { "x-correlation-id": correlationId } },
        );
      }

      await connectToDatabase();
      const project = await Project.create({
        ...parsed.data,
        dueDate: parsed.data.dueDate ? new Date(parsed.data.dueDate) : undefined,
      });

      return NextResponse.json(
        { project, correlationId },
        { status: 201, headers: { "x-correlation-id": correlationId } },
      );
    } catch (error) {
      return jsonError(error, correlationId);
    }
  });
}
