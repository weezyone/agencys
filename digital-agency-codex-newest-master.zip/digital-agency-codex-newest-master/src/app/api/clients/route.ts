import { NextResponse } from "next/server";
import { auth } from "../../../../auth";
import {
  AuthenticationError,
  AuthorizationError,
  requireRole,
} from "@/lib/auth/rbac";
import {
  createCorrelationId,
  runWithCorrelationAsync,
} from "@/lib/observability/correlation";
import { logger } from "@/lib/observability/logger";
import { clientInputSchema } from "@/lib/db/schemas/api";
import { connectToDatabase } from "@/lib/db/mongodb";
import { Client } from "@/lib/db/models/client";

function jsonError(error: unknown, correlationId: string) {
  if (error instanceof AuthenticationError) {
    return NextResponse.json(
      { error: error.message, correlationId },
      { status: 401, headers: { "x-correlation-id": correlationId } },
    );
  }
  if (error instanceof AuthorizationError) {
    return NextResponse.json(
      { error: error.message, correlationId },
      { status: 403, headers: { "x-correlation-id": correlationId } },
    );
  }
  logger.error("Clients API error", { error, correlationId });
  return NextResponse.json(
    { error: "Internal server error", correlationId },
    { status: 500, headers: { "x-correlation-id": correlationId } },
  );
}

export async function GET(request: Request) {
  const correlationId =
    request.headers.get("x-correlation-id") ?? createCorrelationId();

  return runWithCorrelationAsync(correlationId, async () => {
    try {
      const session = await auth();
      requireRole(session, ["admin", "agent-operator"]);

      try {
        await connectToDatabase();
        const clients = await Client.find().sort({ leadScore: -1 }).limit(100).lean();
        return NextResponse.json(
          { clients, correlationId },
          { headers: { "x-correlation-id": correlationId } },
        );
      } catch {
        return NextResponse.json(
          {
            clients: [
              {
                _id: "demo-1",
                company: "Acme Corp",
                name: "Jane Acme",
                status: "lead",
                leadScore: 72,
              },
            ],
            demo: true,
            correlationId,
          },
          { headers: { "x-correlation-id": correlationId } },
        );
      }
    } catch (error) {
      return jsonError(error, correlationId);
    }
  });
}

export async function POST(request: Request) {
  const correlationId =
    request.headers.get("x-correlation-id") ?? createCorrelationId();

  return runWithCorrelationAsync(correlationId, async () => {
    try {
      const session = await auth();
      requireRole(session, ["admin", "agent-operator"]);

      const body: unknown = await request.json();
      const parsed = clientInputSchema.safeParse(body);
      if (!parsed.success) {
        return NextResponse.json(
          { error: parsed.error.flatten(), correlationId },
          { status: 400, headers: { "x-correlation-id": correlationId } },
        );
      }

      await connectToDatabase();
      const client = await Client.create(parsed.data);

      return NextResponse.json(
        { client, correlationId },
        { status: 201, headers: { "x-correlation-id": correlationId } },
      );
    } catch (error) {
      return jsonError(error, correlationId);
    }
  });
}
