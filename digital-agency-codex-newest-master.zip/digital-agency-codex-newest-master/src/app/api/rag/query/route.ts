import { NextResponse } from "next/server";
import { auth } from "../../../../../auth";
import {
  AuthenticationError,
  AuthorizationError,
  requireRole,
} from "@/lib/auth/rbac";
import {
  createCorrelationId,
  runWithCorrelationAsync,
} from "@/lib/observability/correlation";
import { logger } from "@/lib/observability/logger";
import { ragQueryInputSchema } from "@/lib/db/schemas/api";
import { queryKnowledgeBase } from "@/mastra/rag/knowledge-base";

function jsonError(error: unknown, correlationId: string) {
  if (error instanceof AuthenticationError) {
    return NextResponse.json(
      { error: error.message, correlationId },
      { status: 401, headers: { "x-correlation-id": correlationId } },
    );
  }
  if (error instanceof AuthorizationError) {
    return NextResponse.json(
      { error: error.message, correlationId },
      { status: 403, headers: { "x-correlation-id": correlationId } },
    );
  }
  logger.error("RAG query error", { error, correlationId });
  return NextResponse.json(
    { error: error instanceof Error ? error.message : "Internal server error", correlationId },
    { status: 500, headers: { "x-correlation-id": correlationId } },
  );
}

export async function POST(request: Request) {
  const correlationId =
    request.headers.get("x-correlation-id") ?? createCorrelationId();

  return runWithCorrelationAsync(correlationId, async () => {
    try {
      const session = await auth();
      requireRole(session, ["admin", "agent-operator", "client"]);

      const body: unknown = await request.json();
      const parsed = ragQueryInputSchema.safeParse(body);
      if (!parsed.success) {
        return NextResponse.json(
          { error: parsed.error.flatten(), correlationId },
          { status: 400, headers: { "x-correlation-id": correlationId } },
        );
      }

      const result = await queryKnowledgeBase(parsed.data);

      return NextResponse.json(
        { ...result, correlationId },
        { headers: { "x-correlation-id": correlationId } },
      );
    } catch (error) {
      return jsonError(error, correlationId);
    }
  });
}
