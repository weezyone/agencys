import { NextResponse } from "next/server";
import { auth } from "../../../../../auth";
import {
  AuthenticationError,
  AuthorizationError,
  requireRole,
} from "@/lib/auth/rbac";
import {
  createCorrelationId,
  runWithCorrelationAsync,
} from "@/lib/observability/correlation";
import { logger } from "@/lib/observability/logger";
import { workflowRunInputSchema } from "@/lib/db/schemas/api";
import { workflows } from "@/mastra/workflows";

type RouteContext = {
  params: Promise<{ name: string }>;
};

function jsonError(error: unknown, correlationId: string) {
  if (error instanceof AuthenticationError) {
    return NextResponse.json(
      { error: error.message, correlationId },
      { status: 401, headers: { "x-correlation-id": correlationId } },
    );
  }
  if (error instanceof AuthorizationError) {
    return NextResponse.json(
      { error: error.message, correlationId },
      { status: 403, headers: { "x-correlation-id": correlationId } },
    );
  }
  logger.error("Workflow API error", { error, correlationId });
  return NextResponse.json(
    { error: "Internal server error", correlationId },
    { status: 500, headers: { "x-correlation-id": correlationId } },
  );
}

export async function POST(request: Request, context: RouteContext) {
  const correlationId =
    request.headers.get("x-correlation-id") ?? createCorrelationId();
  const { name } = await context.params;

  return runWithCorrelationAsync(correlationId, async () => {
    try {
      const session = await auth();
      requireRole(session, ["admin", "agent-operator"]);

      const workflow = workflows[name as keyof typeof workflows];
      if (!workflow) {
        return NextResponse.json(
          {
            error: `Unknown workflow: ${name}`,
            available: Object.keys(workflows),
            correlationId,
          },
          { status: 404, headers: { "x-correlation-id": correlationId } },
        );
      }

      const body: unknown = await request.json().catch(() => ({}));
      const parsed = workflowRunInputSchema.safeParse(body);
      if (!parsed.success) {
        return NextResponse.json(
          { error: parsed.error.flatten(), correlationId },
          { status: 400, headers: { "x-correlation-id": correlationId } },
        );
      }

      const run = workflow.createRun();
      const result = await run.start({
        inputData: parsed.data.input ?? {},
      });

      return NextResponse.json(
        { workflow: name, result, correlationId },
        { headers: { "x-correlation-id": correlationId } },
      );
    } catch (error) {
      return jsonError(error, correlationId);
    }
  });
}
