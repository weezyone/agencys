# Digital Agency

Multi-agent digital agency platform built with Next.js 15, Mastra, MongoDB, and Auth.js.

## Stack

- Next.js 15 (App Router) + TypeScript + Tailwind v4 + shadcn/ui
- Mastra agents/workflows/RAG
- MongoDB via Mongoose
- Auth.js v5 (RBAC: `admin` | `agent-operator` | `client`)
- Vitest for unit/integration tests

## Setup

```bash
cp .env.example .env.local
npm install
npm run dev
```

See [docs/plan.md](docs/plan.md) for the living milestone board.

## Quality gates

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```
