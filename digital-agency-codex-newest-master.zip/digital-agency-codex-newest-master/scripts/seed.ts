import { connectToDatabase } from "../src/lib/db/mongodb";
import { Client } from "../src/lib/db/models/client";
import { Project } from "../src/lib/db/models/project";
import { Task } from "../src/lib/db/models/task";
import { User } from "../src/lib/db/models/user";

const seed = async () => {
  await connectToDatabase();

  await Promise.all([
    User.deleteMany({}),
    Client.deleteMany({}),
    Project.deleteMany({}),
    Task.deleteMany({}),
  ]);

  const [admin, operator, clientUser] = await User.create([
    { email: "admin@agency.test", role: "admin", name: "Admin" },
    { email: "ops@agency.test", role: "agent-operator", name: "Operator" },
    { email: "client@acme.test", role: "client", name: "Acme Client" },
  ]);

  const [acme, beta] = await Client.create([
    {
      company: "Acme Labs",
      contacts: [{ name: "Ada", email: "ada@acme.test", role: "CEO" }],
      pipelineStage: "qualified",
      leadScore: 82,
      notes: ["Inbound from conference"],
      ownerUserId: clientUser._id,
    },
    {
      company: "Beta Works",
      contacts: [{ name: "Ben", email: "ben@beta.test" }],
      pipelineStage: "nurturing",
      leadScore: 54,
      notes: ["Needs nurture sequence"],
    },
  ]);

  await User.findByIdAndUpdate(clientUser._id, { clientRef: acme._id });

  const project = await Project.create({
    name: "Acme Marketing Site",
    client: acme._id,
    status: "in-progress",
    agents: ["project-manager", "design", "frontend", "qa"],
    timeline: {
      milestones: [
        { title: "Brief", dueDate: new Date(), status: "done" },
        { title: "SOW", dueDate: new Date(), status: "done" },
        { title: "MVP", dueDate: new Date(), status: "in-progress" },
      ],
    },
    budget: { currency: "USD", amount: 48000 },
    brief: {
      goals: ["Launch marketing site"],
      scope: ["Design", "Build"],
      deliverables: ["Site", "CMS"],
      constraints: ["8 weeks"],
      successMetrics: ["Launch"],
    },
  });

  const tasks = await Task.create([
    {
      title: "Homepage hero",
      description: "Implement hero section",
      assignedAgent: "frontend",
      status: "in-progress",
      projectRef: project._id,
      sprint: "sprint-1",
    },
    {
      title: "Design system tokens",
      assignedAgent: "design",
      status: "done",
      projectRef: project._id,
      sprint: "sprint-1",
    },
    {
      title: "QA smoke suite",
      assignedAgent: "qa",
      status: "todo",
      projectRef: project._id,
      sprint: "sprint-1",
    },
  ]);

  await Project.findByIdAndUpdate(project._id, {
    tasks: tasks.map((task) => task._id),
  });

  console.log(
    JSON.stringify(
      {
        users: [admin.email, operator.email, clientUser.email],
        clients: [acme.company, beta.company],
        project: project.name,
        tasks: tasks.length,
      },
      null,
      2,
    ),
  );
};

seed()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
