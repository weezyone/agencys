import { appendActionLog } from "../src/lib/observability/action-logger";
import { withCorrelation } from "../src/lib/observability/correlation";
import { runAgencyDeliveryLogic } from "../src/mastra/workflows/agency-delivery";
import { runClientPipelineLogic } from "../src/mastra/workflows/client-pipeline";

const demo = async () => {
  await withCorrelation(async () => {
    console.log("=== Demo: lead → qualify → nurture/onboard ===");
    const high = runClientPipelineLogic({ company: "Acme Labs", leadScore: 88 });
    const mid = runClientPipelineLogic({ company: "Beta Works", leadScore: 52 });
    await appendActionLog({
      agentName: "prospector",
      toolName: "demo-qualify",
      input: { high, mid },
      output: { ok: true },
      status: "succeeded",
    });
    console.log({ high, mid });

    console.log("=== Demo: intake → brief → SOW → MVP scaffold ===");
    const delivery = runAgencyDeliveryLogic({
      clientInput: "Build a digital agency MVP with multi-agent delivery",
      features: ["chat", "kanban", "portal"],
    });
    await appendActionLog({
      agentName: "project-manager",
      toolName: "demo-agency-delivery",
      input: { clientInput: "MVP" },
      output: delivery,
      status: "succeeded",
    });
    console.log(delivery);
  }, "demo-correlation");
};

demo()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
