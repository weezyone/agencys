# Runbooks

## Local setup

1. Copy `.env.example` to `.env.local` and fill keys.
2. `npm install --legacy-peer-deps`
3. Ensure MongoDB Atlas (or local) URI is reachable.
4. `npm run seed` (requires `MONGODB_URI`)
5. `npm run dev`

## Quality gates

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

## Atlas Vector Search

Provision a vector index with **1536** dimensions for `text-embedding-3-small` on the RAG embeddings collection. Until Atlas is configured, the app uses an in-memory vector store suitable for local/demo.

## Sandboxed integrations

When `EXA_API_KEY`, `RESEND_API_KEY`, `GITHUB_TOKEN`, `LINEAR_API_KEY`, or `MONDAY_API_KEY` are missing, tools return sandboxed responses so demos/tests remain offline-safe.

## Demo flows

```bash
npm run demo
```

Runs lead qualification branching and intake→scaffold handoff with correlation-stamped action logs (Mongo optional; failures are logged).

## Incident: circuit open

If external calls fail repeatedly, circuit breakers open for ~10s. Check structured logs for `Circuit breaker open` and upstream status.
