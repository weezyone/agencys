# Architecture

## Overview

`digital-agency` is a Next.js 15 App Router modular monolith embedding a Mastra multi-agent runtime, MongoDB persistence, streaming chat APIs, an agency dashboard, and a client portal.

## Tiers

1. **Presentation** — `(dashboard)` and `(portal)` route groups, shadcn-style UI, composite boards/chat.
2. **API** — Zod-validated route handlers for projects, clients, workflows, RAG, and agent chat SSE/JSON.
3. **Orchestration** — Mastra agents (PM supervisor + 9 specialists), deterministic workflows, dynamic factories.
4. **Persistence** — Mongoose domain models, append-only action log, sync map, dynamic registry, RAG store.
5. **Cross-cutting** — Auth.js RBAC, correlation IDs, structured logging with redaction, resilience wrappers.

## PM orchestration

The Project Manager decomposes work, delegates via agents-as-tools, monitors/unblocks, breaks ties, and creates missing tools/agents through persisted factories. It never performs specialist implementation work.

## Workflows

Deterministic Mastra workflows cover `client-pipeline`, `project-lifecycle`, `code-review`, `sprint-planning`, and `agency-delivery`.

## Security

Roles: `admin`, `agent-operator`, `client`. Portal access is row-scoped via `clientRef`. Secrets never appear in logs or client responses.
