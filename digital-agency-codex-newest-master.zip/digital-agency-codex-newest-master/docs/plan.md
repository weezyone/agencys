# Digital Agency — Living Task Board

## Status Legend

- `[ ]` pending
- `[~]` in progress
- `[x]` done

## Bootstrap

- [x] Project scaffold (Next.js 15 + TypeScript + Tailwind + ESLint + src/)
- [~] shadcn/ui init + primitives
- [~] Core dependency install
- [x] `.env.example`
- [x] Living `docs/plan.md`

## M1 — Foundation

- [x] MongoDB singleton connection
- [x] Domain models (Client, Project, Task, Conversation, AgentActionLog, User, IntegrationSyncMap, DynamicRegistry)
- [x] Auth.js v5 + RBAC skeleton (`admin | agent-operator | client`)
- [x] Observability (logger, correlation, action-logger)
- [~] Quality scripts (`lint`, `typecheck`, `test`, `build`) + Vitest

## M2 — Core Tools

- [ ] Resilience layer (retry / timeout / circuit-breaker)
- [ ] mongodb / search / email / code-gen / github / file / agency-ops / linear / monday tools
- [ ] Tri-directional sync engine + id-map
- [ ] Unit tests (externals mocked)

## M3 — Agents

- [ ] 10 baseline agents with scoped tools
- [ ] Project Manager supervisor (delegate-only)
- [ ] Dynamic tool/agent factories + persisted registry
- [ ] Mastra instance + action-log hooks

## M4 — Workflows

- [ ] client-pipeline (branch by leadScore)
- [ ] project-lifecycle
- [ ] code-review
- [ ] sprint-planning
- [ ] agency-delivery (intake → brief → SOW → MVP scaffold → PM handoff)
- [ ] Integration tests

## M5 — RAG

- [ ] Ingest URL / PDF / text
- [ ] text-embedding-3-small + MongoDBVector (1536-dim)
- [ ] Query + attribution (+ optional Exa synthesis)

## M6 — UI

- [ ] Dashboard route group
- [ ] Portal route group
- [ ] Composites: AgentChat, KanbanBoard, ProjectTimeline, ClientPipelineBoard, TaskCard

## M7 — API + Streaming

- [ ] Streaming agent chat
- [ ] REST: projects, clients, workflows, rag
- [ ] Zod validation + RBAC + correlation
- [ ] Smoke tests

## M8 — Hardening

- [ ] Seed + demo scripts
- [ ] Docs: architecture, workflows, runbooks
- [ ] CI workflow
- [ ] DoD: lint / typecheck / test / build all green
