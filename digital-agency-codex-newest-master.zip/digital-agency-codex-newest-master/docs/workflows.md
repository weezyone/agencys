# Workflows

## client-pipeline

Input: `{ company, leadScore }`

- `leadScore >= 70` → onboarded (high-touch)
- `40–69` → nurturing sequence
- `< 40` → churned / parked

## project-lifecycle

`intake → planning → delivered`

## code-review

`collect-diff → verdict`

## sprint-planning

Prioritize backlog by capacity, then assign across specialist roster.

## agency-delivery

`intake → brief → SOW → MVP scaffold → PM handoff`

Trigger via `POST /api/workflows/{name}` with a JSON body matching the workflow input schema.
