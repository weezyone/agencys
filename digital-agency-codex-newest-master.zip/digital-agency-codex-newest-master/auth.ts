import NextAuth from "next-auth";
import { authConfig } from "@/lib/auth/auth.config";

/**
 * Auth.js v5 entrypoint.
 * MongoDB adapter can be wired when MONGODB_URI is available and
 * session strategy switches to database sessions (M7 hardening).
 */
export const { handlers, auth, signIn, signOut } = NextAuth({
  ...authConfig,
  secret: process.env.AUTH_SECRET,
  trustHost: true,
});
