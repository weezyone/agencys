# Implementation Runbook

This is the operating runbook for Codex and other agents working in this repository.

## Required Reading

Before editing code, read:

1. `Prompt.md`
2. `Plan.md`
3. `Documentation.md`
4. `AGENTS.md`
5. Relevant docs under `docs/`

## Execution Loop

For each milestone:

1. Identify the first incomplete milestone in `Plan.md`.
2. Restate the milestone goal and acceptance criteria in the working context.
3. Inspect the relevant code and docs before editing.
4. Make the smallest coherent set of changes that satisfies the milestone.
5. Run the validation commands listed for that milestone.
6. If validation fails, fix the failure and rerun validation.
7. Update `Documentation.md` with:
   - What changed
   - Commands run
   - Validation results
   - Decisions made
   - Known issues and follow-ups
8. Mark the milestone status in `Plan.md`.
9. Move to the next milestone only after validation passes or the blocker is documented.

## Scope Control

- Do not expand goals beyond `Prompt.md` without updating the spec.
- Do not introduce a new framework, service, or major dependency without recording the decision.
- Keep unrelated refactors out of milestone work.
- Prefer simple, verifiable changes over broad rewrites.

## Validation

The default quality gate is:

```bash
./scripts/verify.sh
```

If a project needs additional checks, add them to `scripts/verify.sh` and document them in `Plan.md`.

## Status Updates

Use `Documentation.md` as durable memory. It should let a human return after hours away and understand:

- What is done
- What is currently in progress
- What changed since the last checkpoint
- What failed and how it was fixed
- What still needs a decision

## Stop Conditions

Stop and ask for human input when:

- The spec conflicts with the plan.
- A required credential, account, private system, or production data source is unavailable.
- A validation failure points to an ambiguous product or architecture decision.
- Continuing would require destructive changes outside the active scope.
