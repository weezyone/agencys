# Contributing

## Workflow

1. Read `Prompt.md`, `Plan.md`, `Implement.md`, and `AGENTS.md`.
2. Choose the active milestone or create a task from `tasks/TEMPLATE.md`.
3. Keep changes scoped.
4. Run `./scripts/verify.sh`.
5. Update `Documentation.md` with meaningful status, decisions, and validation results.
6. Open a PR using `.github/pull_request_template.md`.

## Quality Gates

All changes should pass:

```bash
./scripts/verify.sh
```

Add project-specific checks to `scripts/verify.sh` so the quality gate stays shared across local development, CI, and Codex runs.

## Commit Messages

Use clear, imperative commit messages:

```text
Add baseline verification script
Fix auth token refresh handling
Document local development setup
```
