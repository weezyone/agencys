# Project Documentation And Status

This file is the durable project memory and audit log. Update it after each milestone and any time project state changes materially.

## Current Snapshot

- Date: TODO
- Active milestone: TODO
- Current branch: TODO
- Current objective: TODO
- Overall status: TODO

## How To Run

```bash
./scripts/bootstrap.sh
./scripts/verify.sh
```

TODO: Add project-specific run commands once the stack is chosen.

## Milestone Status

| Milestone | Status | Notes |
| --- | --- | --- |
| 0. Repository Setup | TODO | TODO |
| 1. Core Functionality | TODO | TODO |
| 2. Reliability And Edge Cases | TODO | TODO |
| 3. Polish, Release, And Handoff | TODO | TODO |

## Validation Log

| Date | Command | Result | Notes |
| --- | --- | --- | --- |
| TODO | `./scripts/verify.sh` | TODO | TODO |

## Decisions

| Date | Decision | Rationale |
| --- | --- | --- |
| TODO | TODO | TODO |

## Known Issues

- TODO: Known issue or limitation.

## Follow-Ups

- TODO: Follow-up task.

## Demo Notes

TODO: Add the repeatable demo or smoke-test flow.
