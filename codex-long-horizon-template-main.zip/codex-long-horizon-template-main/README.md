# Codex-Ready Repository Skeleton

This repository is a cloneable starting point for projects that will use Codex for long-running implementation work.

It follows the durable project memory pattern from OpenAI's Codex long-horizon task writeup:

- `Prompt.md` freezes the target: goals, non-goals, constraints, deliverables, and "done when".
- `Plan.md` breaks the target into milestone-sized checkpoints with acceptance criteria and validation commands.
- `Implement.md` tells Codex how to execute: follow the plan, keep scope tight, verify each milestone, and update status.
- `Documentation.md` is the live project memory and audit log.
- `AGENTS.md` gives repo-wide operating rules for Codex and other coding agents.

## Start A New Repo From This Skeleton

1. Clone or copy this repository.
2. Replace placeholder names in `README.md`, `Prompt.md`, `Plan.md`, and `Documentation.md`.
3. Add the real source tree and dependency manifests for the project.
4. Update `scripts/bootstrap.sh` and `scripts/verify.sh` only if the defaults do not fit the stack.
5. Run:

```bash
./scripts/bootstrap.sh
./scripts/verify.sh
```

## Suggested First Codex Prompt

```text
Read Prompt.md, Plan.md, Implement.md, Documentation.md, and AGENTS.md.
Treat Prompt.md as the project specification and Plan.md as the current milestone plan.
Follow Implement.md exactly. Start at the first incomplete milestone, keep changes scoped,
run validation before moving on, and update Documentation.md with status, decisions, and commands.
```

## Repository Layout

```text
.
|-- AGENTS.md
|-- Prompt.md
|-- Plan.md
|-- Implement.md
|-- Documentation.md
|-- docs/
|   |-- architecture.md
|   |-- decisions/
|   `-- runbooks/
|-- scripts/
|   |-- bootstrap.sh
|   `-- verify.sh
|-- tasks/
|-- .github/
|   |-- ISSUE_TEMPLATE/
|   |-- pull_request_template.md
|   `-- workflows/
`-- README.md
```

## Verification

`scripts/verify.sh` is intentionally generic. It runs common checks when it detects a matching project file:

- Node: `npm`, `pnpm`, or `yarn` lint/typecheck/test/build scripts
- Python: `ruff`, `mypy`, `pytest`, and package build checks when configured
- Go: `gofmt`, `go vet`, and `go test`
- Rust: `cargo fmt`, `cargo clippy`, and `cargo test`
- Make: `make verify`

Keep project-specific quality gates in this script so humans and agents share the same definition of passing work.

## Source Inspiration

This template is based on OpenAI's February 23, 2026 developer blog post, "Run long horizon tasks with Codex":
https://developers.openai.com/blog/run-long-horizon-tasks-with-codex
