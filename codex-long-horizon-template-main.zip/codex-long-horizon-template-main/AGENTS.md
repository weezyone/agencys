# Agent Instructions

These instructions apply to the entire repository.

## Operating Model

Before making non-trivial changes, read:

- `Prompt.md`
- `Plan.md`
- `Implement.md`
- `Documentation.md`
- Any relevant files under `docs/`

For long-running work, use the loop described in `Implement.md`:

1. Confirm the active milestone.
2. Make scoped edits.
3. Run the validation commands for that milestone.
4. Fix failures before moving on.
5. Update `Documentation.md` with status, decisions, commands, and follow-ups.

## Source Of Truth

- `Prompt.md` defines the target behavior and constraints.
- `Plan.md` defines milestone order and acceptance criteria.
- `Implement.md` defines how to execute work.
- `Documentation.md` records current status and historical decisions.

If these files conflict, stop and update the docs so the repo has one clear instruction set before continuing.

## Engineering Rules

- Keep changes scoped to the active task or milestone.
- Prefer existing project patterns over new abstractions.
- Add or update tests when behavior changes.
- Run `./scripts/verify.sh` before claiming work is complete.
- Do not hide failing checks. Record failures and fixes in `Documentation.md`.
- Do not commit secrets, credentials, tokens, private keys, or production data.
- Preserve user changes. Do not revert unrelated work unless explicitly instructed.

## Documentation Rules

Update `Documentation.md` whenever work changes project state:

- Current milestone status
- Commands run and their results
- Decisions made and why
- Known issues or follow-ups
- Demo or smoke-test notes

For architecture decisions that affect future work, add a short ADR under `docs/decisions/`.

## Pull Requests

Every PR should include:

- Summary of behavior or docs changed
- Validation commands run
- Known gaps or deferred follow-ups
- Screenshots or recordings for UI changes, when applicable
