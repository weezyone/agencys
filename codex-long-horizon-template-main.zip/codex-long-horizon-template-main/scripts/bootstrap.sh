#!/usr/bin/env bash
set -Eeuo pipefail

log() {
  printf '[bootstrap] %s\n' "$1"
}

have() {
  command -v "$1" >/dev/null 2>&1
}

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$repo_root"

log "repo: $repo_root"

if [[ -f .env.example && ! -f .env ]]; then
  cp .env.example .env
  log "created .env from .env.example"
fi

if [[ -f package.json ]]; then
  if [[ -f pnpm-lock.yaml ]]; then
    have pnpm || { log "pnpm is required but not installed"; exit 1; }
    log "installing Node dependencies with pnpm"
    pnpm install
  elif [[ -f yarn.lock ]]; then
    have yarn || { log "yarn is required but not installed"; exit 1; }
    log "installing Node dependencies with yarn"
    yarn install --frozen-lockfile
  else
    have npm || { log "npm is required but not installed"; exit 1; }
    log "installing Node dependencies with npm"
    npm install
  fi
fi

if [[ -f pyproject.toml ]]; then
  if [[ -f uv.lock ]]; then
    have uv || { log "uv is required but not installed"; exit 1; }
    log "syncing Python dependencies with uv"
    uv sync
  elif [[ -f requirements.txt ]]; then
    have python3 || { log "python3 is required but not installed"; exit 1; }
    log "installing Python dependencies from requirements.txt"
    python3 -m pip install -r requirements.txt
  else
    log "pyproject.toml detected; add project-specific install steps if needed"
  fi
elif [[ -f requirements.txt ]]; then
  have python3 || { log "python3 is required but not installed"; exit 1; }
  log "installing Python dependencies from requirements.txt"
  python3 -m pip install -r requirements.txt
fi

if [[ -f go.mod ]]; then
  have go || { log "go is required but not installed"; exit 1; }
  log "downloading Go modules"
  go mod download
fi

if [[ -f Cargo.toml ]]; then
  have cargo || { log "cargo is required but not installed"; exit 1; }
  log "fetching Rust dependencies"
  cargo fetch
fi

log "complete"
