#!/usr/bin/env bash
set -Eeuo pipefail

log() {
  printf '[verify] %s\n' "$1"
}

have() {
  command -v "$1" >/dev/null 2>&1
}

run() {
  log "$*"
  "$@"
}

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$repo_root"

checks_run=0

run_shell_check() {
  while IFS= read -r script; do
    run bash -n "$script"
    checks_run=$((checks_run + 1))
  done < <(find scripts -type f -name '*.sh' | sort)
}

run_make_checks() {
  if [[ -f Makefile ]]; then
    if make -n verify >/dev/null 2>&1; then
      run make verify
      checks_run=$((checks_run + 1))
    else
      log "Makefile found, but no verify target detected"
    fi
  fi
}

run_node_checks() {
  [[ -f package.json ]] || return 0

  if [[ -f pnpm-lock.yaml ]]; then
    have pnpm || { log "pnpm is required but not installed"; exit 1; }
    package_runner=(pnpm)
  elif [[ -f yarn.lock ]]; then
    have yarn || { log "yarn is required but not installed"; exit 1; }
    package_runner=(yarn)
  else
    have npm || { log "npm is required but not installed"; exit 1; }
    package_runner=(npm run)
  fi

  for script in lint typecheck test build; do
    if node -e "const p=require('./package.json'); process.exit(p.scripts && p.scripts['$script'] ? 0 : 1)" >/dev/null 2>&1; then
      run "${package_runner[@]}" "$script"
      checks_run=$((checks_run + 1))
    fi
  done
}

run_python_checks() {
  [[ -f pyproject.toml || -f requirements.txt || -d tests ]] || return 0
  have python3 || { log "python3 is required but not installed"; exit 1; }

  if have ruff; then
    run ruff check .
    checks_run=$((checks_run + 1))
  fi

  if have mypy; then
    run mypy .
    checks_run=$((checks_run + 1))
  fi

  if have pytest && [[ -d tests ]]; then
    run pytest
    checks_run=$((checks_run + 1))
  fi
}

run_go_checks() {
  [[ -f go.mod ]] || return 0
  have go || { log "go is required but not installed"; exit 1; }

  run test -z "$(gofmt -l .)"
  checks_run=$((checks_run + 1))

  run go vet ./...
  checks_run=$((checks_run + 1))

  run go test ./...
  checks_run=$((checks_run + 1))
}

run_rust_checks() {
  [[ -f Cargo.toml ]] || return 0
  have cargo || { log "cargo is required but not installed"; exit 1; }

  run cargo fmt --check
  checks_run=$((checks_run + 1))

  if have cargo-clippy || cargo clippy --version >/dev/null 2>&1; then
    run cargo clippy --all-targets --all-features -- -D warnings
    checks_run=$((checks_run + 1))
  fi

  run cargo test
  checks_run=$((checks_run + 1))
}

run_required_file_checks() {
  local required=(
    AGENTS.md
    Prompt.md
    Plan.md
    Implement.md
    Documentation.md
    README.md
  )

  for path in "${required[@]}"; do
    if [[ ! -s "$path" ]]; then
      log "required file is missing or empty: $path"
      exit 1
    fi
  done

  checks_run=$((checks_run + 1))
}

run_required_file_checks
run_shell_check
run_make_checks
run_node_checks
run_python_checks
run_go_checks
run_rust_checks

log "complete ($checks_run checks run)"
