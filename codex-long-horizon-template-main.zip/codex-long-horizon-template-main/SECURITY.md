# Security

## Reporting

TODO: Add the preferred private disclosure channel for this project.

Do not report suspected vulnerabilities in public issues if they involve exploitable behavior, credentials, production data, or private infrastructure.

## Secret Handling

- Do not commit secrets, tokens, credentials, private keys, or production data.
- Use `.env.example` to document required environment variables.
- Keep local `.env` files untracked.
- Rotate any credential that may have been committed or pasted into logs.

## Agent Safety

Agents working in this repository should not access production systems, customer data, or destructive infrastructure commands unless that access is explicitly required and approved for the task.
