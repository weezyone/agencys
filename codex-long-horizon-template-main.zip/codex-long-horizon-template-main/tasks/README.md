# Tasks

Use this directory for task-specific specs that are smaller than the main `Prompt.md`.

Create a new task by copying `tasks/TEMPLATE.md` and naming it with a short slug:

```text
tasks/2026-05-01-add-billing-export.md
```

Task files should link back to the relevant milestone in `Plan.md` and record validation commands.
