# Task: TODO

## Context

TODO: Why this task matters and what existing behavior it touches.

## Scope

- TODO: In scope.
- TODO: In scope.

## Out Of Scope

- TODO: Out of scope.

## Acceptance Criteria

- TODO: Observable behavior or artifact.
- TODO: Tests or documentation updated.

## Validation

```bash
./scripts/verify.sh
```

## Notes

TODO: Constraints, links, or decisions.
