# Local Development Runbook

## Setup

```bash
./scripts/bootstrap.sh
```

## Verify

```bash
./scripts/verify.sh
```

## Environment

1. Copy `.env.example` to `.env`.
2. Fill in project-specific values.
3. Keep `.env` untracked.

## Troubleshooting

- If dependencies fail to install, confirm the package manager and runtime versions.
- If verification fails, fix the first failing check before running broader work.
- If a missing secret is required, document the variable in `.env.example` without adding the secret value.
