# ADR 0001: Use Durable Project Memory For Agentic Work

## Status

Accepted

## Context

Long-running Codex work needs stable project state outside the chat transcript so the agent can revisit the target, plan, constraints, validations, and current status throughout the run.

## Decision

This repository keeps four top-level memory files:

- `Prompt.md` for the project specification.
- `Plan.md` for milestones and validation commands.
- `Implement.md` for execution rules.
- `Documentation.md` for current status, decisions, and audit history.

`AGENTS.md` points agents to those files before they edit code.

## Consequences

- Humans can steer work by editing durable files instead of repeating instructions.
- Codex can resume long-running tasks with less drift.
- Contributors must keep these files current when project state changes.
