import React, { useState, useEffect } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { getAgents, sendMessage, uploadFile, startConversation, getConversationMessages, Agent, Message, FileAttachment } from '@/api/agents';
import { useToast } from '@/hooks/useToast';
import { Send, Paperclip, User, Bot, Loader } from 'lucide-react';
import { cn } from '@/lib/utils';

export function Chat() {
  const { agentType } = useParams<{ agentType: string }>();
  const [searchParams] = useSearchParams();
  const conversationIdParam = searchParams.get('conversationId');
  
  const [agent, setAgent] = useState<Agent | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const [files, setFiles] = useState<FileAttachment[]>([]);
  const [conversationId, setConversationId] = useState<string | null>(conversationIdParam);
  const { toast } = useToast();

  useEffect(() => {
    loadAgent();
  }, [agentType]);

  useEffect(() => {
    if (conversationId && agent) {
      loadExistingConversation();
    }
  }, [conversationId, agent]);

  const loadAgent = async () => {
    if (!agentType) {
      console.error('Chat: No agent type provided');
      toast({
        title: "Error",
        description: "No agent type specified",
        variant: "destructive"
      });
      setIsLoading(false);
      return;
    }

    try {
      console.log(`Chat: Loading agent data for type: ${agentType}`);
      setIsLoading(true);

      const response = await getAgents();
      console.log('Chat: Agents response:', response);

      const agents = (response as any)?.data?.agents || [];
      console.log('Chat: Available agents:', agents);

      const selectedAgent = agents.find((a: Agent) => a.type === agentType);
      console.log('Chat: Selected agent:', selectedAgent);

      if (!selectedAgent) {
        console.error(`Chat: No agent found for type: ${agentType}`);
        toast({
          title: "Error",
          description: `No agent found for type: ${agentType}`,
          variant: "destructive"
        });
        setIsLoading(false);
        return;
      }

      setAgent(selectedAgent);
      console.log('Chat: Agent loaded successfully:', selectedAgent.name);

      // If no existing conversation, show welcome message
      if (!conversationId) {
        setMessages([
          {
            _id: 'welcome',
            role: 'assistant',
            content: `Hello! I'm ${selectedAgent.name}. ${selectedAgent.description}. How can I help you today?`,
            timestamp: new Date().toISOString()
          }
        ]);
        setIsLoading(false);
      }

    } catch (error) {
      console.error('Chat: Error loading agent:', error);
      toast({
        title: "Error",
        description: "Failed to load agent information.",
        variant: "destructive"
      });
      setIsLoading(false);
    }
  };

  const loadExistingConversation = async () => {
    if (!conversationId || !agent) return;

    try {
      console.log('Chat: Loading existing conversation:', conversationId);
      const response = await getConversationMessages(conversationId);
      console.log('Chat: Conversation messages loaded:', response);

      if (response.messages && response.messages.length > 0) {
        setMessages(response.messages);
        console.log('Chat: Set messages from existing conversation:', response.messages.length);
      } else {
        // If no messages, show welcome message
        setMessages([
          {
            _id: 'welcome',
            role: 'assistant',
            content: `Hello! I'm ${agent.name}. ${agent.description}. How can I help you today?`,
            timestamp: new Date().toISOString()
          }
        ]);
      }
    } catch (error) {
      console.error('Chat: Error loading existing conversation:', error);
      toast({
        title: "Error",
        description: "Failed to load conversation messages.",
        variant: "destructive"
      });
      
      // Show welcome message as fallback
      setMessages([
        {
          _id: 'welcome',
          role: 'assistant',
          content: `Hello! I'm ${agent.name}. ${agent.description}. How can I help you today?`,
          timestamp: new Date().toISOString()
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !agent || isSending) return;

    const userMessage: Message = {
      _id: Date.now().toString(),
      role: 'user',
      content: newMessage,
      timestamp: new Date().toISOString(),
      files: files.length > 0 ? files : undefined
    };

    setMessages(prev => [...prev, userMessage]);
    const messageToSend = newMessage;
    setNewMessage('');
    setFiles([]);
    setIsSending(true);

    try {
      console.log('Chat: Sending message to agent:', agent.type);
      console.log('Chat: Current conversation ID:', conversationId);

      let response;

      if (!conversationId) {
        // First message - create new conversation
        console.log('Chat: Creating new conversation');
        response = await startConversation({
          agentType: agent.type,
          message: messageToSend,
          files: files.length > 0 ? files : undefined
        });

        console.log('Chat: New conversation created:', response);

        // Extract conversation ID from response
        const newConversationId = response.conversation?._id;
        if (newConversationId) {
          setConversationId(newConversationId);
          console.log('Chat: Set conversation ID:', newConversationId);
          
          // Update URL to include conversation ID
          const newUrl = new URL(window.location.href);
          newUrl.searchParams.set('conversationId', newConversationId);
          window.history.replaceState({}, '', newUrl.toString());
        }

        // Get the assistant message from the response
        const conversationMessages = response.conversation?.messages || [];
        const assistantMessage = conversationMessages.find((msg: Message) => msg.role === 'assistant');
        
        if (assistantMessage) {
          setMessages(prev => [...prev, assistantMessage]);
        }
      } else {
        // Subsequent messages - send to existing conversation
        console.log('Chat: Sending message to existing conversation:', conversationId);
        response = await sendMessage(conversationId, {
          message: messageToSend,
          files: files.length > 0 ? files : undefined
        });

        console.log('Chat: Message response:', response);

        const assistantMessage = (response as any).data?.message || (response as any).message;
        if (assistantMessage) {
          setMessages(prev => [...prev, assistantMessage]);
        }
      }
    } catch (error) {
      console.error('Chat: Error sending message:', error);
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSending(false);
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      console.log('Chat: Uploading file:', file.name);
      const response = await uploadFile(file);
      const uploadedFile = (response as any).file;

      setFiles(prev => [...prev, uploadedFile]);
      console.log('Chat: File uploaded successfully:', uploadedFile);
    } catch (error) {
      console.error('Chat: Error uploading file:', error);
      toast({
        title: "Error",
        description: "Failed to upload file. Please try again.",
        variant: "destructive"
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center space-y-4">
          <Loader className="w-8 h-8 animate-spin mx-auto" />
          <p className="text-muted-foreground">Loading agent...</p>
        </div>
      </div>
    );
  }

  if (!agent) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center space-y-4">
          <p className="text-lg font-medium">Agent not found</p>
          <p className="text-muted-foreground">The requested agent could not be loaded.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full max-w-4xl mx-auto">
      {/* Chat Header */}
      <Card className="mb-4">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-3">
            <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center", agent.color)}>
              <Bot className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-semibold">{agent.name}</h1>
              <p className="text-sm text-muted-foreground font-normal">{agent.description}</p>
              {conversationId && (
                <p className="text-xs text-muted-foreground font-normal">
                  Conversation ID: {conversationId}
                </p>
              )}
            </div>
          </CardTitle>
        </CardHeader>
      </Card>

      {/* Messages Area */}
      <Card className="flex-1 flex flex-col">
        <div className="flex-1 p-4 overflow-y-auto space-y-4">
          {messages.map((message) => (
            <div
              key={message._id}
              className={cn("flex gap-3", message.role === 'user' ? 'justify-end' : 'justify-start')}
            >
              <div className={cn("flex gap-3 max-w-[70%]", message.role === 'user' ? 'flex-row-reverse' : 'flex-row')}>
                <div className={cn("w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0",
                  message.role === 'user' ? 'bg-primary' : agent.color
                )}>
                  {message.role === 'user' ? (
                    <User className="w-4 h-4 text-white" />
                  ) : (
                    <Bot className="w-4 h-4 text-white" />
                  )}
                </div>
                <div className={cn("rounded-lg p-3",
                  message.role === 'user'
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted'
                )}>
                  <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                  {message.files && message.files.length > 0 && (
                    <div className="mt-2 space-y-1">
                      {message.files.map((file) => (
                        <div key={file._id} className="text-xs opacity-75">
                          📎 {file.name}
                        </div>
                      ))}
                    </div>
                  )}
                  <p className="text-xs opacity-60 mt-1">
                    {new Date(message.timestamp).toLocaleTimeString()}
                  </p>
                </div>
              </div>
            </div>
          ))}
          {isSending && (
            <div className="flex gap-3 justify-start">
              <div className="flex gap-3 max-w-[70%]">
                <div className={cn("w-8 h-8 rounded-full flex items-center justify-center", agent.color)}>
                  <Bot className="w-4 h-4 text-white" />
                </div>
                <div className="bg-muted rounded-lg p-3">
                  <div className="flex items-center gap-2">
                    <Loader className="w-4 h-4 animate-spin" />
                    <span className="text-sm">Thinking...</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="border-t p-4">
          {files.length > 0 && (
            <div className="mb-3 flex flex-wrap gap-2">
              {files.map((file) => (
                <div key={file._id} className="bg-muted rounded px-2 py-1 text-xs flex items-center gap-1">
                  📎 {file.name}
                  <button
                    onClick={() => setFiles(files.filter(f => f._id !== file._id))}
                    className="ml-1 text-muted-foreground hover:text-foreground"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          )}
          <div className="flex gap-2">
            <div className="flex-1 relative">
              <Textarea
                placeholder="Type your message here..."
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                className="min-h-[60px] pr-12 resize-none"
              />
              <input
                type="file"
                id="file-upload"
                className="hidden"
                onChange={handleFileUpload}
              />
              <label
                htmlFor="file-upload"
                className="absolute bottom-2 right-2 p-2 hover:bg-muted rounded cursor-pointer"
              >
                <Paperclip className="w-4 h-4" />
              </label>
            </div>
            <Button
              onClick={handleSendMessage}
              disabled={!newMessage.trim() || isSending}
              className="px-4"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}