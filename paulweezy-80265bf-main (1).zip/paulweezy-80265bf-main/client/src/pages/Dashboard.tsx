import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { getAgents, getConversations, startConversation, createAgent, deleteAgent, deleteConversation, Agent, Conversation } from '@/api/agents';
import { useToast } from '@/hooks/useToast';
import { Palette, Code, Calendar, MessageCircle, Plus, Search, Clock, ArrowRight, Sparkles, Zap, Target, Trash2 } from 'lucide-react';
import { cn } from '@/lib/utils';

const iconMap = {
  Palette,
  Code,
  Calendar,
  MessageCircle
};

export function Dashboard() {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedAgent, setSelectedAgent] = useState<Agent | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [isStartingConversation, setIsStartingConversation] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateAgent, setShowCreateAgent] = useState(false);
  const [newAgentData, setNewAgentData] = useState({
    type: '',
    name: '',
    description: '',
    icon: 'MessageCircle',
    color: 'bg-gradient-to-br from-gray-500 to-gray-600',
    capabilities: '',
    status: 'active'
  });
  const [isCreatingAgent, setIsCreatingAgent] = useState(false);
  const [deletingAgentId, setDeletingAgentId] = useState<string | null>(null);
  const [deletingConversationId, setDeletingConversationId] = useState<string | null>(null);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      console.log('Dashboard: Loading data...');
      const [agentsResponse, conversationsResponse] = await Promise.all([
        getAgents(),
        getConversations()
      ]);

      console.log('Dashboard: Agents response:', agentsResponse);
      console.log('Dashboard: Conversations response:', conversationsResponse);

      // Fix: Access agents from the correct nested path
      setAgents((agentsResponse as any)?.data?.agents || []);
      setConversations((conversationsResponse as any)?.conversations || []);

      console.log('Dashboard: Data loaded successfully');
      console.log('Dashboard: Agents set to state:', (agentsResponse as any)?.data?.agents || []);
    } catch (error) {
      console.error('Dashboard: Error loading data:', error);
      // Set empty arrays as fallback
      setAgents([]);
      setConversations([]);
      toast({
        title: "Error",
        description: "Failed to load data. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreateAgent = async () => {
    if (!newAgentData.type || !newAgentData.name || !newAgentData.description) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    setIsCreatingAgent(true);
    try {
      console.log('Dashboard: Creating new agent:', newAgentData);

      const capabilities = newAgentData.capabilities
        .split(',')
        .map(cap => cap.trim())
        .filter(cap => cap.length > 0);

      const response = await createAgent({
        ...newAgentData,
        capabilities
      });

      console.log('Dashboard: Agent created:', response);

      toast({
        title: "Success",
        description: "Agent created successfully",
      });

      // Reset form
      setNewAgentData({
        type: '',
        name: '',
        description: '',
        icon: 'MessageCircle',
        color: 'bg-gradient-to-br from-gray-500 to-gray-600',
        capabilities: '',
        status: 'active'
      });
      setShowCreateAgent(false);

      // Reload data to show new agent
      await loadData();
    } catch (error) {
      console.error('Dashboard: Error creating agent:', error);
      toast({
        title: "Error",
        description: "Failed to create agent. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsCreatingAgent(false);
    }
  };

  const handleDeleteAgent = async (agentId: string, agentName: string) => {
    setDeletingAgentId(agentId);
    try {
      console.log('Dashboard: Deleting agent:', agentId);
      await deleteAgent(agentId);

      console.log('Dashboard: Agent deleted successfully');
      toast({
        title: "Success",
        description: `${agentName} has been deleted successfully`,
      });

      // Remove the deleted agent from the state
      setAgents(prev => prev.filter(agent => agent._id !== agentId));
    } catch (error) {
      console.error('Dashboard: Error deleting agent:', error);
      toast({
        title: "Error",
        description: "Failed to delete agent. Please try again.",
        variant: "destructive"
      });
    } finally {
      setDeletingAgentId(null);
    }
  };

  const handleDeleteConversation = async (conversationId: string, conversationTitle: string) => {
    setDeletingConversationId(conversationId);
    try {
      console.log('Dashboard: Deleting conversation:', conversationId);
      await deleteConversation(conversationId);

      console.log('Dashboard: Conversation deleted successfully');
      toast({
        title: "Success",
        description: `Conversation "${conversationTitle}" has been deleted successfully`,
      });

      // Remove the deleted conversation from the state
      setConversations(prev => prev.filter(conversation => conversation._id !== conversationId));
    } catch (error) {
      console.error('Dashboard: Error deleting conversation:', error);
      toast({
        title: "Error",
        description: "Failed to delete conversation. Please try again.",
        variant: "destructive"
      });
    } finally {
      setDeletingConversationId(null);
    }
  };

  const handleStartConversation = async () => {
    if (!selectedAgent || !newMessage.trim()) return;

    setIsStartingConversation(true);
    try {
      console.log('Dashboard: Starting conversation with agent:', selectedAgent.type);
      const response = await startConversation({
        agentType: selectedAgent.type,
        message: newMessage
      });

      console.log('Dashboard: Conversation started:', response);

      toast({
        title: "Conversation Started",
        description: `Started a new conversation with ${selectedAgent.name}`,
      });

      navigate(`/chat/${selectedAgent.type}`);
    } catch (error) {
      console.error('Dashboard: Error starting conversation:', error);
      toast({
        title: "Error",
        description: "Failed to start conversation. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsStartingConversation(false);
    }
  };

  const quickActions = [
    { title: "Plan a new project", description: "Get help with project planning and timeline", icon: Target },
    { title: "Review code", description: "Get code review and optimization suggestions", icon: Code },
    { title: "Design feedback", description: "Get expert feedback on your designs", icon: Palette },
    { title: "Client proposal", description: "Generate professional client proposals", icon: MessageCircle }
  ];

  const filteredConversations = conversations.filter(conv =>
    conv.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    conv.preview.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  console.log('Dashboard: Rendering with agents:', agents);

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="text-center space-y-4">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-900/30 dark:to-pink-900/30 rounded-full text-sm font-medium">
          <Sparkles className="w-4 h-4 text-purple-600 dark:text-purple-400" />
          AI-Powered Agency Assistant
        </div>
        <h1 className="text-4xl font-bold bg-gradient-to-r from-gray-900 to-gray-600 dark:from-white dark:to-gray-300 bg-clip-text text-transparent">
          Welcome to Your Design & Development Hub
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Connect with specialized AI agents to streamline your agency workflow, from design feedback to code reviews and project management.
        </p>
      </div>

      {/* Create Agent Button */}
      <div className="flex justify-center">
        <Dialog open={showCreateAgent} onOpenChange={setShowCreateAgent}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
              <Plus className="w-4 h-4 mr-2" />
              Create New Agent
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[525px] bg-background border">
            <DialogHeader>
              <DialogTitle>Create New AI Agent</DialogTitle>
              <DialogDescription>
                Create a specialized AI agent to help with your design and development tasks.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Type</label>
                  <select
                    value={newAgentData.type}
                    onChange={(e) => setNewAgentData({ ...newAgentData, type: e.target.value })}
                    className="w-full p-2 border rounded-md bg-background"
                  >
                    <option value="">Select type</option>
                    <option value="design">Design</option>
                    <option value="development">Development</option>
                    <option value="project-manager">Project Manager</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium">Icon</label>
                  <select
                    value={newAgentData.icon}
                    onChange={(e) => setNewAgentData({ ...newAgentData, icon: e.target.value })}
                    className="w-full p-2 border rounded-md bg-background"
                  >
                    <option value="MessageCircle">MessageCircle</option>
                    <option value="Palette">Palette</option>
                    <option value="Code">Code</option>
                    <option value="Calendar">Calendar</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="text-sm font-medium">Name</label>
                <Input
                  value={newAgentData.name}
                  onChange={(e) => setNewAgentData({ ...newAgentData, name: e.target.value })}
                  placeholder="Enter agent name"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Description</label>
                <Textarea
                  value={newAgentData.description}
                  onChange={(e) => setNewAgentData({ ...newAgentData, description: e.target.value })}
                  placeholder="Describe what this agent specializes in"
                  className="min-h-[80px] resize-none"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Capabilities (comma-separated)</label>
                <Input
                  value={newAgentData.capabilities}
                  onChange={(e) => setNewAgentData({ ...newAgentData, capabilities: e.target.value })}
                  placeholder="e.g., UI Design, Code Review, Project Planning"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Color Theme</label>
                <Input
                  value={newAgentData.color}
                  onChange={(e) => setNewAgentData({ ...newAgentData, color: e.target.value })}
                  placeholder="CSS gradient class"
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowCreateAgent(false)}>
                  Cancel
                </Button>
                <Button
                  onClick={handleCreateAgent}
                  disabled={isCreatingAgent}
                >
                  {isCreatingAgent ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Creating...
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4 mr-2" />
                      Create Agent
                    </>
                  )}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Agent Selection Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {agents.map((agent) => {
          const IconComponent = iconMap[agent.icon as keyof typeof iconMap] || MessageCircle;

          return (
            <Card key={agent._id} className="group hover:shadow-xl transition-all duration-300 border-0 glass-effect">
              <CardHeader className="text-center pb-4">
                <div className="flex justify-end mb-2">
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 w-8 p-0 text-muted-foreground hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950"
                        disabled={deletingAgentId === agent._id}
                      >
                        {deletingAgentId === agent._id ? (
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-red-500"></div>
                        ) : (
                          <Trash2 className="w-4 h-4" />
                        )}
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete Agent</AlertDialogTitle>
                        <AlertDialogDescription>
                          Are you sure you want to delete "{agent.name}"? This action cannot be undone and will permanently remove the agent and all associated conversations.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => handleDeleteAgent(agent._id, agent.name)}
                          className="bg-red-500 hover:bg-red-600 text-white"
                        >
                          Delete Agent
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
                <div className={cn("w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300", agent.color)}>
                  <IconComponent className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-xl">{agent.name}</CardTitle>
                <CardDescription className="text-sm">{agent.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex flex-wrap gap-2">
                  {agent.capabilities.slice(0, 3).map((capability, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {capability}
                    </Badge>
                  ))}
                  {agent.capabilities.length > 3 && (
                    <Badge variant="outline" className="text-xs">
                      +{agent.capabilities.length - 3} more
                    </Badge>
                  )}
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button
                      className="w-full group-hover:shadow-lg transition-all duration-300"
                      onClick={() => setSelectedAgent(agent)}
                      disabled={deletingAgentId === agent._id}
                    >
                      <MessageCircle className="w-4 h-4 mr-2" />
                      Start Conversation
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[525px] bg-background border">
                    <DialogHeader>
                      <DialogTitle className="flex items-center gap-2">
                        <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", agent.color)}>
                          <IconComponent className="w-4 h-4 text-white" />
                        </div>
                        Start conversation with {agent.name}
                      </DialogTitle>
                      <DialogDescription>
                        Describe your project or question in detail. You can also upload files to provide more context.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <Textarea
                        placeholder="Describe your project, ask a question, or explain what you need help with..."
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        className="min-h-[120px] resize-none"
                      />
                      <div className="flex justify-end gap-2">
                        <Button variant="outline" onClick={() => setNewMessage('')}>
                          Clear
                        </Button>
                        <Button
                          onClick={handleStartConversation}
                          disabled={!newMessage.trim() || isStartingConversation}
                        >
                          {isStartingConversation ? (
                            <>
                              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                              Starting...
                            </>
                          ) : (
                            <>
                              <Zap className="w-4 h-4 mr-2" />
                              Start Conversation
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Show message if no agents */}
      {agents.length === 0 && (
        <Card className="text-center py-12 border-dashed border-2 glass-effect">
          <CardContent>
            <MessageCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">No agents available</h3>
            <p className="text-muted-foreground mb-4">
              Create your first AI agent to get started
            </p>
          </CardContent>
        </Card>
      )}

      {/* Quick Actions */}
      <div className="space-y-4">
        <h2 className="text-2xl font-semibold">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action, index) => (
            <Card key={index} className="group hover:shadow-lg transition-all duration-300 cursor-pointer border-0 glass-effect">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-gradient-to-br from-blue-500 to-purple-500 group-hover:scale-110 transition-transform duration-300">
                    <action.icon className="w-4 h-4 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-sm group-hover:text-primary transition-colors">
                      {action.title}
                    </h3>
                    <p className="text-xs text-muted-foreground mt-1">
                      {action.description}
                    </p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all duration-300" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Recent Conversations */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-semibold">Recent Conversations</h2>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search conversations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
        </div>

        {filteredConversations.length === 0 ? (
          <Card className="text-center py-12 border-dashed border-2 glass-effect">
            <CardContent>
              <MessageCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">No conversations yet</h3>
              <p className="text-muted-foreground mb-4">
                Start your first conversation with one of our AI agents above
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredConversations.map((conversation) => {
              const agent = agents.find(a => a.type === conversation.agentType);
              const IconComponent = agent ? iconMap[agent.icon as keyof typeof iconMap] : MessageCircle;

              return (
                <Card
                  key={conversation._id}
                  className="group hover:shadow-lg transition-all duration-300 cursor-pointer border-0 glass-effect relative"
                >
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <div
                        className={cn("p-2 rounded-lg flex items-center justify-center flex-shrink-0", agent?.color || 'bg-gray-500')}
                        onClick={() => navigate(`/chat/${conversation.agentType}?conversationId=${conversation._id}`)}
                      >
                        <IconComponent className="w-4 h-4 text-white" />
                      </div>
                      <div
                        className="flex-1 min-w-0"
                        onClick={() => navigate(`/chat/${conversation.agentType}?conversationId=${conversation._id}`)}
                      >
                        <h3 className="font-medium text-sm group-hover:text-primary transition-colors truncate">
                          {conversation.title}
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                          {conversation.preview}
                        </p>
                        <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                          <Clock className="w-3 h-3" />
                          {new Date(conversation.timestamp).toLocaleDateString()}
                        </div>
                      </div>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0 text-muted-foreground hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950"
                              disabled={deletingConversationId === conversation._id}
                              onClick={(e) => e.stopPropagation()}
                            >
                              {deletingConversationId === conversation._id ? (
                                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-red-500"></div>
                              ) : (
                                <Trash2 className="w-4 h-4" />
                              )}
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete Conversation</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to delete the conversation "{conversation.title}"? This action cannot be undone and will permanently remove the conversation and all its messages.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => handleDeleteConversation(conversation._id, conversation.title)}
                                className="bg-red-500 hover:bg-red-600 text-white"
                              >
                                Delete Conversation
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                        <div onClick={() => navigate(`/chat/${conversation.agentType}?conversationId=${conversation._id}`)}>
                          <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all duration-300" />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}