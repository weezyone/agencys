import api from './api';

export interface Agent {
  _id: string;
  type: 'design' | 'development' | 'project-manager';
  name: string;
  description: string;
  icon: string;
  color: string;
  capabilities: string[];
  status: 'active' | 'inactive' | 'maintenance';
}

export interface Conversation {
  _id: string;
  agentType: string;
  title: string;
  preview: string;
  timestamp: string;
  messages: Message[];
}

export interface Message {
  _id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  files?: FileAttachment[];
}

export interface FileAttachment {
  _id: string;
  name: string;
  type: string;
  size: number;
  url: string;
}

export interface QueryResponse {
  response: string;
  agentType: string;
  query: string;
  timestamp: string;
}

// Description: Get available AI agents
// Endpoint: GET /api/agents
// Request: {}
// Response: { agents: Agent[] }
export const getAgents = async () => {
  try {
    console.log('API: Making GET request to /api/agents');
    const response = await api.get('/api/agents');
    console.log('API: GET /api/agents response:', response);
    console.log('API: Response data:', response.data);
    return response;
  } catch (error) {
    console.error('API: Error in getAgents:', error);
    console.error('API: Error response:', error?.response);
    console.error('API: Error message:', error?.message);
    throw new Error(error?.response?.data?.error || error.message);
  }
};

// Description: Create a new AI agent
// Endpoint: POST /api/agents
// Request: { type: string, name: string, description: string, icon?: string, color?: string, capabilities?: string[], status?: string }
// Response: { agent: Agent, message: string }
export const createAgent = async (data: {
  type: string;
  name: string;
  description: string;
  icon?: string;
  color?: string;
  capabilities?: string[];
  status?: string;
}) => {
  try {
    console.log('API: Making POST request to /api/agents with data:', data);
    const response = await api.post('/api/agents', data);
    console.log('API: POST /api/agents response:', response);
    console.log('API: Response data:', response.data);
    return response;
  } catch (error) {
    console.error('API: Error in createAgent:', error);
    console.error('API: Error response:', error?.response);
    console.error('API: Error message:', error?.message);
    throw new Error(error?.response?.data?.error || error.message);
  }
};

// Description: Get agent by ID
// Endpoint: GET /api/agents/:id
// Request: {}
// Response: { agent: Agent }
export const getAgentById = async (id: string) => {
  try {
    console.log(`API: Making GET request to /api/agents/${id}`);
    const response = await api.get(`/api/agents/${id}`);
    console.log('API: GET /api/agents/:id response:', response);
    console.log('API: Response data:', response.data);
    return response;
  } catch (error) {
    console.error('API: Error in getAgentById:', error);
    console.error('API: Error response:', error?.response);
    console.error('API: Error message:', error?.message);
    throw new Error(error?.response?.data?.error || error.message);
  }
};

// Description: Send direct query to agent without creating conversation
// Endpoint: POST /api/agents/query
// Request: { agentType: string, message: string, context?: string }
// Response: { response: string, agentType: string, query: string, timestamp: string }
export const queryAgent = async (data: {
  agentType: string;
  message: string;
  context?: string;
}) => {
  try {
    console.log('API: Making POST request to /api/agents/query with data:', data);
    const response = await api.post('/api/agents/query', data);
    console.log('API: POST /api/agents/query response:', response);
    console.log('API: Response data:', response.data);
    return response.data;
  } catch (error) {
    console.error('API: Error in queryAgent:', error);
    console.error('API: Error response:', error?.response);
    console.error('API: Error message:', error?.message);
    throw new Error(error?.response?.data?.error || error.message);
  }
};

// Description: Get recent conversations
// Endpoint: GET /api/conversations
// Request: {}
// Response: { conversations: Conversation[] }
export const getConversations = async () => {
  try {
    console.log('API: Making GET request to /api/conversations');
    const response = await api.get('/api/conversations');
    console.log('API: GET /api/conversations response:', response);
    console.log('API: Response data:', response.data);
    return response.data;
  } catch (error) {
    console.error('API: Error in getConversations:', error);
    console.error('API: Error response:', error?.response);
    console.error('API: Error message:', error?.message);
    throw new Error(error?.response?.data?.error || error.message);
  }
};

// Description: Get conversation by ID
// Endpoint: GET /api/conversations/:id
// Request: {}
// Response: { conversation: Conversation }
export const getConversationById = async (id: string) => {
  try {
    console.log(`API: Making GET request to /api/conversations/${id}`);
    const response = await api.get(`/api/conversations/${id}`);
    console.log('API: GET /api/conversations/:id response:', response);
    console.log('API: Response data:', response.data);
    return response.data;
  } catch (error) {
    console.error('API: Error in getConversationById:', error);
    console.error('API: Error response:', error?.response);
    console.error('API: Error message:', error?.message);
    throw new Error(error?.response?.data?.error || error.message);
  }
};

// Description: Delete a conversation
// Endpoint: DELETE /api/conversations/:id
// Request: {}
// Response: { message: string, conversation: Conversation }
export const deleteConversation = async (id: string) => {
  try {
    console.log(`API: Making DELETE request to /api/conversations/${id}`);
    const response = await api.delete(`/api/conversations/${id}`);
    console.log('API: DELETE /api/conversations/:id response:', response);
    console.log('API: Response data:', response.data);
    return response.data;
  } catch (error) {
    console.error('API: Error in deleteConversation:', error);
    console.error('API: Error response:', error?.response);
    console.error('API: Error message:', error?.message);
    throw new Error(error?.response?.data?.error || error.message);
  }
};

// Description: Start a new conversation with an agent
// Endpoint: POST /api/conversations
// Request: { agentType: string, message: string, files?: FileAttachment[] }
// Response: { conversation: Conversation }
export const startConversation = async (data: { agentType: string; message: string; files?: FileAttachment[] }) => {
  try {
    console.log('API: Making POST request to /api/conversations with data:', data);
    const response = await api.post('/api/conversations', data);
    console.log('API: POST /api/conversations response:', response);
    console.log('API: Response data:', response.data);
    return response.data;
  } catch (error) {
    console.error('API: Error in startConversation:', error);
    console.error('API: Error response:', error?.response);
    console.error('API: Error message:', error?.message);
    throw new Error(error?.response?.data?.error || error.message);
  }
};

// Description: Send a message to an existing conversation
// Endpoint: POST /api/conversations/:id/messages
// Request: { message: string, files?: FileAttachment[] }
// Response: { message: Message }
export const sendMessage = async (conversationId: string, data: { message: string; files?: FileAttachment[] }) => {
  try {
    return await api.post(`/api/conversations/${conversationId}/messages`, data);
  } catch (error) {
    throw new Error(error?.response?.data?.error || error.message);
  }
  // Fallback to mocked data if API fails
  // return new Promise((resolve) => {
  //   setTimeout(() => {
  //     resolve({
  //       message: {
  //         _id: Date.now().toString(),
  //         role: 'assistant',
  //         content: `I understand your request: "${data.message}". Here's my detailed response with actionable recommendations...`,
  //         timestamp: new Date().toISOString()
  //       }
  //     });
  //   }, 1000);
  // });
};

// Description: Upload file for conversation
// Endpoint: POST /api/files/upload
// Request: FormData with file
// Response: { file: FileAttachment }
export const uploadFile = async (file: File) => {
  try {
    const formData = new FormData();
    formData.append('file', file);
    console.log('API: Uploading file:', file.name);
    const response = await api.post('/api/files/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
    console.log('API: File upload response:', response);
    return response.data;
  } catch (error) {
    console.error('API: Error uploading file:', error);
    throw new Error(error?.response?.data?.error || error.message);
  }
  // Fallback to mocked data if API fails
  // return new Promise((resolve) => {
  //   setTimeout(() => {
  //     resolve({
  //       file: {
  //         _id: Date.now().toString(),
  //         name: file.name,
  //         type: file.type,
  //         size: file.size,
  //         url: URL.createObjectURL(file)
  //       }
  //     });
  //   }, 500);
  // });
};

// Description: Get file details by ID
// Endpoint: GET /api/files/:id
// Request: {}
// Response: { file: { _id: string, name: string, type: string, size: number, url: string, createdAt: string } }
export const getFileById = async (fileId: string) => {
  try {
    console.log(`API: Making GET request to /api/files/${fileId}`);
    const response = await api.get(`/api/files/${fileId}`);
    console.log('API: GET /api/files/:id response:', response);
    console.log('API: Response data:', response.data);
    return response.data;
  } catch (error) {
    console.error('API: Error in getFileById:', error);
    console.error('API: Error response:', error?.response);
    console.error('API: Error message:', error?.message);
    throw new Error(error?.response?.data?.error || error.message);
  }
};

// Description: Get messages for a conversation
// Endpoint: GET /api/conversations/:id/messages
// Request: {}
// Response: { messages: Message[], conversationInfo: { _id: string, agentType: string, title: string, preview: string } }
export const getConversationMessages = async (conversationId: string) => {
  try {
    console.log(`API: Making GET request to /api/conversations/${conversationId}/messages`);
    const response = await api.get(`/api/conversations/${conversationId}/messages`);
    console.log('API: GET /api/conversations/:id/messages response:', response);
    console.log('API: Response data:', response.data);

    // Transform the messages to match frontend interface
    const transformedData = {
      ...response.data,
      messages: response.data.messages?.map((message: any) => ({
        ...message,
        timestamp: message.createdAt || message.timestamp || new Date().toISOString()
      })) || []
    };

    console.log('API: Transformed messages with timestamp field:', transformedData);
    return transformedData;
  } catch (error) {
    console.error('API: Error in getConversationMessages:', error);
    console.error('API: Error response:', error?.response);
    console.error('API: Error message:', error?.message);
    throw new Error(error?.response?.data?.error || error.message);
  }
};

// Description: Delete an agent
// Endpoint: DELETE /api/agents/:id
// Request: {}
// Response: { message: string }
export const deleteAgent = async (id: string) => {
  try {
    console.log(`API: Making DELETE request to /api/agents/${id}`);
    const response = await api.delete(`/api/agents/${id}`);
    console.log('API: DELETE /api/agents/:id response:', response);
    console.log('API: Response data:', response.data);
    return response;
  } catch (error) {
    console.error('API: Error in deleteAgent:', error);
    console.error('API: Error response:', error?.response);
    console.error('API: Error message:', error?.message);
    throw new Error(error?.response?.data?.error || error.message);
  }
};

// Description: Delete a file by ID
// Endpoint: DELETE /api/files/:id
// Request: {}
// Response: { message: string, file: { _id: string, name: string, type: string, size: number, url: string } }
export const deleteFile = async (fileId: string) => {
  try {
    console.log(`API: Making DELETE request to /api/files/${fileId}`);
    const response = await api.delete(`/api/files/${fileId}`);
    console.log('API: DELETE /api/files/:id response:', response);
    console.log('API: Response data:', response.data);
    return response.data;
  } catch (error) {
    console.error('API: Error in deleteFile:', error);
    console.error('API: Error response:', error?.response);
    console.error('API: Error message:', error?.message);
    throw new Error(error?.response?.data?.error || error.message);
  }
};