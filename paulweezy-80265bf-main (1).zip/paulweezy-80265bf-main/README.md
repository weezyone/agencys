# PaulWeezy

PaulWeezy is an innovative AI Assistant Interface designed specifically for design and development agencies. This Minimal Viable Product (MVP) connects users with AI agents specialized in various tasks such as project planning, code generation, design decisions, and more. It aims to streamline workflow and enhance productivity by providing quick, intelligent assistance for everyday tasks in a user-friendly, conversational interface.

## Overview

PaulWeezy consists of two main parts: the frontend, built with ReactJS and Vite, and the backend, powered by Express.js with REST API endpoints and MongoDB for database support.

### Architecture

- **Frontend**:
  - **Client**: ReactJS
  - **Styling**: Tailwind CSS with shadcn-ui component library
  - **Client-Side Routing**: react-router-dom
  - **Build Tool**: Vite
  - **Port**: 5173
  
- **Backend**:
  - **Server**: Express.js
  - **Database**: MongoDB with Mongoose
  - **Port**: 3000

### Project Structure

- **Frontend**: Located in the `client/` directory.
  - `client/src/pages/`: Contains page components.
  - `client/src/components/`: Contains reusable UI components.
  - `client/src/api/`: Manages API requests, including mocking data.

- **Backend**: Located in the `server/` directory.
  - `server/api/`: Contains REST API endpoints.
  - `server/models/`: Defines Mongoose models.
  - `server/services/`: Business logic layer.
  - `server/routes/`: Express route handlers.

## Features

PaulWeezy boasts an array of features designed to facilitate and enhance the daily operations of design/development agencies:

### Main Dashboard

- **Conversation Hub**: Start conversations with specialized AI agents.
- **Agent Selection**: Quick access to Design, Development, and Project Manager agents.
- **Recent Conversations**: Review recent interactions with timestamps and previews.
- **Quick Actions**: Pre-defined prompts for common tasks.

### Chat Interface

- **Message Input**: Large text area for detailed requests.
- **File Upload**: Upload design files, code snippets, project briefs, etc.
- **Agent Response Area**: Clear display of AI responses with syntax highlighting.
- **Action Buttons**: Quick options like "Refine this", "Generate alternatives".
- **Copy/Export**: Easy copying of code or exporting conversation summaries.

### Agent Specializations

- **Design Agent**: Wireframe feedback, design system recommendations, color palette suggestions, etc.
- **Development Agent**: Code review, bug fixing, architecture recommendations, boilerplate code generation.
- **Project Manager Agent**: Project timelines, task organization, client communication templates, pricing guidance.

### Additional Features

- **File Management**: Organize files by project/client.
- **Context Awareness**: Remember previous conversations and project details.
- **Multi-Agent Collaboration**: Interact with multiple agents in a single thread.
- **Template Responses**: Save and reuse successful conversation patterns.
- **Search History**: Quickly find previous solutions and recommendations.

## Getting Started

### Requirements

Ensure the following technologies are installed on your computer:

- Node.js (latest LTS version recommended)
- npm (included with Node.js)
- MongoDB (running locally or accessible via a connection string)

### Quickstart

1. Clone the repository:
   ```sh
   git clone <repository_url>
   ```

2. Install dependencies:
   ```sh
   cd PaulWeezy
   npm install
   ```

3. Start the application:
   ```sh
   npm run start
   ```

4. Access the frontend at:
   ```
   http://localhost:5173
   ```

### License

This project is proprietary. 

```
Copyright (c) 2024.
```