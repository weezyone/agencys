const mongoose = require('mongoose');

const messageSchema = new mongoose.Schema({
  role: {
    type: String,
    required: true,
    enum: ['user', 'assistant']
  },
  content: {
    type: String,
    required: true,
    trim: true
  },
  files: [{
    _id: { type: mongoose.Schema.Types.ObjectId },
    name: { type: String, required: true },
    type: { type: String, required: true },
    size: { type: Number, required: true },
    url: { type: String, required: true }
  }]
}, {
  timestamps: true
});

const conversationSchema = new mongoose.Schema({
  agentType: {
    type: String,
    required: true,
    enum: ['design', 'development', 'project-manager']
  },
  title: {
    type: String,
    required: true,
    trim: true
  },
  preview: {
    type: String,
    required: true,
    trim: true
  },
  messages: [messageSchema],
  status: {
    type: String,
    enum: ['active', 'archived', 'deleted'],
    default: 'active'
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Conversation', conversationSchema);