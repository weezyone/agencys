const mongoose = require('mongoose');

const agentSchema = new mongoose.Schema({
  type: {
    type: String,
    required: true,
    enum: ['design', 'development', 'project-manager']
  },
  name: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true,
    trim: true
  },
  icon: {
    type: String,
    required: true,
    default: 'MessageCircle'
  },
  color: {
    type: String,
    required: true,
    default: 'bg-gradient-to-br from-gray-500 to-gray-600'
  },
  capabilities: [{
    type: String,
    trim: true
  }],
  status: {
    type: String,
    enum: ['active', 'inactive', 'maintenance'],
    default: 'active'
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Agent', agentSchema);