const path = require('path');
const fs = require('fs').promises;

class FileStorageService {
  constructor() {
    this.uploadDir = path.join(__dirname, '../uploads');
    this.ensureUploadDir();
  }

  async ensureUploadDir() {
    try {
      await fs.access(this.uploadDir);
    } catch (error) {
      // Directory doesn't exist, create it
      await fs.mkdir(this.uploadDir, { recursive: true });
      console.log('FileStorage: Upload directory created:', this.uploadDir);
    }
  }

  // Description: Store uploaded file and return file metadata
  // Input: { buffer: Buffer, originalName: string, mimetype: string, size: number }
  // Output: { fileName: string, filePath: string, url: string }
  async storeFile(fileData) {
    try {
      console.log('FileStorage: Storing file:', fileData.originalName);

      // Generate unique filename
      const timestamp = Date.now();
      const extension = path.extname(fileData.originalName);
      const baseName = path.basename(fileData.originalName, extension);
      const fileName = `${baseName}_${timestamp}${extension}`;
      const filePath = path.join(this.uploadDir, fileName);

      // Write file to disk
      await fs.writeFile(filePath, fileData.buffer);

      // Generate URL for accessing the file
      const url = `/api/files/download/${fileName}`;

      console.log('FileStorage: File stored successfully:', fileName);

      return {
        fileName,
        filePath,
        url
      };
    } catch (error) {
      console.error('FileStorage: Error storing file:', error);
      throw new Error('Failed to store file');
    }
  }

  // Description: Delete file from storage
  // Input: { filePath: string }
  // Output: { success: boolean }
  async deleteFile(filePath) {
    try {
      console.log('FileStorage: Deleting file:', filePath);
      await fs.unlink(filePath);
      console.log('FileStorage: File deleted successfully');
      return { success: true };
    } catch (error) {
      console.error('FileStorage: Error deleting file:', error);
      throw new Error('Failed to delete file');
    }
  }

  // Description: Get file from storage
  // Input: { fileName: string }
  // Output: { filePath: string, exists: boolean }
  async getFile(fileName) {
    try {
      const filePath = path.join(this.uploadDir, fileName);
      
      try {
        await fs.access(filePath);
        return { filePath, exists: true };
      } catch (error) {
        return { filePath, exists: false };
      }
    } catch (error) {
      console.error('FileStorage: Error getting file:', error);
      throw new Error('Failed to get file');
    }
  }
}

module.exports = new FileStorageService();