const express = require('express');
const multer = require('multer');
const path = require('path');
const router = express.Router();
const fileService = require('../services/fileService');

// Configure multer for file upload
const storage = multer.memoryStorage();
const upload = multer({
  storage: storage,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    // Allow common file types
    const allowedTypes = [
      'image/jpeg',
      'image/jpg',
      'image/png',
      'image/gif',
      'image/webp',
      'application/pdf',
      'text/plain',
      'text/csv',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/json',
      'text/html',
      'text/css',
      'text/javascript',
      'application/javascript'
    ];

    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('File type not allowed'), false);
    }
  }
});

// POST /api/files/upload - Upload file
router.post('/upload', upload.single('file'), async (req, res) => {
  try {
    console.log('POST /api/files/upload - Uploading file');

    if (!req.file) {
      return res.status(400).json({
        error: 'No file provided'
      });
    }

    console.log('File details:', {
      originalname: req.file.originalname,
      mimetype: req.file.mimetype,
      size: req.file.size
    });

    // Upload file using service
    const uploadedFile = await fileService.uploadFile(req.file);

    console.log('File uploaded successfully:', uploadedFile._id);
    res.status(201).json({ file: uploadedFile });
  } catch (error) {
    console.error('Error uploading file:', error);
    
    if (error.message === 'File type not allowed') {
      res.status(400).json({ error: 'File type not allowed' });
    } else if (error.message.includes('File too large')) {
      res.status(400).json({ error: 'File too large. Maximum size is 10MB' });
    } else {
      res.status(500).json({ error: error.message });
    }
  }
});

// GET /api/files/download/:fileName - Download file
router.get('/download/:fileName', async (req, res) => {
  try {
    console.log(`GET /api/files/download/${req.params.fileName} - Downloading file`);

    const fileName = req.params.fileName;

    if (!fileName) {
      return res.status(400).json({
        error: 'File name is required'
      });
    }

    // Get file details
    const file = await fileService.getFileByName(fileName);

    // Set appropriate headers
    res.setHeader('Content-Type', file.type);
    res.setHeader('Content-Disposition', `inline; filename="${file.originalName}"`);

    // Send file
    res.sendFile(file.filePath);
  } catch (error) {
    console.error('Error downloading file:', error);
    if (error.message === 'File not found' || error.message === 'File not found in storage') {
      res.status(404).json({ error: 'File not found' });
    } else {
      res.status(500).json({ error: error.message });
    }
  }
});

// GET /api/files/:id - Get file details by ID
router.get('/:id', async (req, res) => {
  try {
    console.log(`GET /api/files/${req.params.id} - Fetching file details`);

    const fileId = req.params.id;

    if (!fileId) {
      return res.status(400).json({
        error: 'File ID is required'
      });
    }

    const file = await fileService.getFileById(fileId);

    console.log('File details fetched successfully');
    res.json({
      file: {
        _id: file._id,
        name: file.originalName,
        type: file.type,
        size: file.size,
        url: file.url,
        createdAt: file.createdAt
      }
    });
  } catch (error) {
    console.error('Error fetching file details:', error);
    if (error.message === 'File not found') {
      res.status(404).json({ error: error.message });
    } else {
      res.status(500).json({ error: error.message });
    }
  }
});

// GET /api/files - Get all files
router.get('/', async (req, res) => {
  try {
    console.log('GET /api/files - Fetching all files');

    const files = await fileService.getFiles();

    console.log('Files fetched successfully:', files.length);
    res.json({
      files: files.map(file => ({
        _id: file._id,
        name: file.originalName,
        type: file.type,
        size: file.size,
        url: file.url,
        createdAt: file.createdAt
      }))
    });
  } catch (error) {
    console.error('Error fetching files:', error);
    res.status(500).json({ error: error.message });
  }
});

// DELETE /api/files/:id - Delete file
router.delete('/:id', async (req, res) => {
  try {
    console.log(`DELETE /api/files/${req.params.id} - Deleting file`);

    const fileId = req.params.id;

    if (!fileId) {
      return res.status(400).json({
        error: 'File ID is required'
      });
    }

    const deletedFile = await fileService.deleteFile(fileId);

    console.log('File deleted successfully:', deletedFile._id);
    res.json({
      message: 'File deleted successfully',
      file: {
        _id: deletedFile._id,
        name: deletedFile.originalName,
        type: deletedFile.type,
        size: deletedFile.size,
        url: deletedFile.url
      }
    });
  } catch (error) {
    console.error('Error deleting file:', error);
    if (error.message === 'File not found') {
      res.status(404).json({ error: error.message });
    } else {
      res.status(500).json({ error: error.message });
    }
  }
});

module.exports = router;