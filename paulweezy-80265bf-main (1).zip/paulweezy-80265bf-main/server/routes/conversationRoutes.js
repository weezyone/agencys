const express = require('express');
const router = express.Router();
const conversationService = require('../services/conversationService');
const { sendLLMRequest } = require('../services/llmService');

// POST /api/conversations - Start new conversation
router.post('/', async (req, res) => {
  try {
    console.log('POST /api/conversations - Starting new conversation');
    console.log('Request body:', req.body);

    const { agentType, message, files } = req.body;

    if (!agentType || !message) {
      return res.status(400).json({
        error: 'Agent type and message are required'
      });
    }

    // Validate agentType
    const validAgentTypes = ['design', 'development', 'project-manager'];
    if (!validAgentTypes.includes(agentType)) {
      return res.status(400).json({
        error: 'Invalid agent type. Must be one of: ' + validAgentTypes.join(', ')
      });
    }

    // Create conversation using service
    const conversation = await conversationService.createConversation({
      agentType,
      message,
      files
    });

    console.log('Conversation created successfully:', conversation._id);

    // Generate AI response after creating the conversation
    let systemPrompt = 'You are a helpful AI assistant. Provide helpful and accurate information.';
    
    switch (agentType) {
      case 'design':
        systemPrompt = 'You are a design expert specializing in UI/UX design, wireframes, and design systems. Provide helpful design advice and recommendations with specific examples and best practices.';
        break;
      case 'development':
        systemPrompt = 'You are a development expert specializing in code review, architecture, and implementation. Provide helpful programming advice, code solutions, and technical guidance with examples.';
        break;
      case 'project-manager':
        systemPrompt = 'You are a project management expert specializing in project planning, timelines, and client communication. Provide helpful project management advice, strategies, and actionable recommendations.';
        break;
      default:
        systemPrompt = 'You are a helpful AI assistant. Provide helpful and accurate information.';
    }

    console.log('Generating AI response for new conversation...');
    console.log('System prompt:', systemPrompt);
    console.log('User message:', message);

    // Send to LLM service to get AI response
    const llmResponse = await sendLLMRequest(message, 'openai', {
    
      temperature: 0.7
    });

    console.log('LLM response received:', llmResponse.substring(0, 100) + '...');

    // Add the assistant message to the conversation
    const assistantMessage = await conversationService.addMessageToConversation(conversation._id, {
      role: 'assistant',
      content: llmResponse,
      files: []
    });

    console.log('Assistant message added to conversation:', assistantMessage._id);

    // Get the updated conversation with both messages
    const updatedConversation = await conversationService.getConversationById(conversation._id);

    console.log('Returning updated conversation with both user and assistant messages');
    res.status(201).json({ conversation: updatedConversation });
  } catch (error) {
    console.error('Error creating conversation:', error);
    res.status(500).json({ error: error.message });
  }
});

// POST /api/conversations/:id/messages - Send message to conversation
router.post('/:id/messages', async (req, res) => {
  try {
    console.log(`POST /api/conversations/${req.params.id}/messages - Sending message`);
    console.log('Request body:', req.body);

    const { message, files, agentType } = req.body;
    const conversationId = req.params.id;

    if (!message) {
      return res.status(400).json({
        error: 'Message is required'
      });
    }

    // First, add the user message to the conversation
    const userMessage = await conversationService.addMessageToConversation(conversationId, {
      role: 'user',
      content: message,
      files: files || []
    });

    console.log('User message added to conversation:', userMessage._id);

    // Get the conversation to determine agent type if not provided
    let effectiveAgentType = agentType;
    if (!effectiveAgentType) {
      const conversation = await conversationService.getConversationById(conversationId);
      effectiveAgentType = conversation.agentType;
    }

    // Get agent information to customize the prompt
    let systemPrompt = 'You are a helpful AI assistant. Provide helpful and accurate information.';

    if (effectiveAgentType) {
      switch (effectiveAgentType) {
        case 'design':
          systemPrompt = 'You are a design expert specializing in UI/UX design, wireframes, and design systems. Provide helpful design advice and recommendations with specific examples and best practices.';
          break;
        case 'development':
          systemPrompt = 'You are a development expert specializing in code review, architecture, and implementation. Provide helpful programming advice, code solutions, and technical guidance with examples.';
          break;
        case 'project-manager':
          systemPrompt = 'You are a project management expert specializing in project planning, timelines, and client communication. Provide helpful project management advice, strategies, and actionable recommendations.';
          break;
        default:
          systemPrompt = 'You are a helpful AI assistant. Provide helpful and accurate information.';
      }
    }

    console.log('Sending request to LLM service...');
    console.log('System prompt:', systemPrompt);
    console.log('User message:', message);

    // Send to LLM service
    const llmResponse = await sendLLMRequest(message, 'openai', {
      systemPrompt: systemPrompt,
      maxTokens: 1500,
      temperature: 0.7
    });

    console.log('LLM response received:', llmResponse.substring(0, 100) + '...');

    // Add the assistant message to the conversation
    const assistantMessage = await conversationService.addMessageToConversation(conversationId, {
      role: 'assistant',
      content: llmResponse,
      files: []
    });

    console.log('Assistant message added to conversation:', assistantMessage._id);
    res.json({ message: assistantMessage });
  } catch (error) {
    console.error('Error sending message:', error);
    res.status(500).json({ error: error.message });
  }
});

// GET /api/conversations - Get all conversations
router.get('/', async (req, res) => {
  try {
    console.log('GET /api/conversations - Fetching conversations');

    const { agentType } = req.query;
    const filters = {};

    if (agentType) {
      filters.agentType = agentType;
    }

    const conversations = await conversationService.getConversations(filters);

    console.log('Conversations fetched successfully:', conversations.length);
    res.json({ conversations });
  } catch (error) {
    console.error('Error fetching conversations:', error);
    res.status(500).json({ error: error.message });
  }
});

// GET /api/conversations/:id - Get conversation by ID
router.get('/:id', async (req, res) => {
  try {
    console.log(`GET /api/conversations/${req.params.id} - Fetching conversation`);

    const conversation = await conversationService.getConversationById(req.params.id);

    console.log('Conversation fetched successfully');
    res.json({ conversation });
  } catch (error) {
    console.error('Error fetching conversation:', error);
    if (error.message === 'Conversation not found') {
      res.status(404).json({ error: error.message });
    } else {
      res.status(500).json({ error: error.message });
    }
  }
});

// DELETE /api/conversations/:id - Delete conversation
router.delete('/:id', async (req, res) => {
  try {
    console.log(`DELETE /api/conversations/${req.params.id} - Deleting conversation`);

    const conversationId = req.params.id;

    if (!conversationId) {
      return res.status(400).json({
        error: 'Conversation ID is required'
      });
    }

    // Delete conversation using service (soft delete)
    const deletedConversation = await conversationService.deleteConversation(conversationId);

    console.log('Conversation deleted successfully:', deletedConversation._id);
    res.json({
      message: 'Conversation deleted successfully',
      conversation: deletedConversation
    });
  } catch (error) {
    console.error('Error deleting conversation:', error);
    if (error.message === 'Conversation not found') {
      res.status(404).json({ error: error.message });
    } else {
      res.status(500).json({ error: error.message });
    }
  }
});

// GET /api/conversations/:id/messages - Get messages for a conversation
router.get('/:id/messages', async (req, res) => {
  try {
    console.log(`GET /api/conversations/${req.params.id}/messages - Fetching messages`);

    const conversationId = req.params.id;

    if (!conversationId) {
      return res.status(400).json({
        error: 'Conversation ID is required'
      });
    }

    // Get conversation with messages
    const conversation = await conversationService.getConversationById(conversationId);

    if (!conversation) {
      return res.status(404).json({
        error: 'Conversation not found'
      });
    }

    console.log('Messages fetched successfully:', conversation.messages.length);
    res.json({ 
      messages: conversation.messages,
      conversationInfo: {
        _id: conversation._id,
        agentType: conversation.agentType,
        title: conversation.title,
        preview: conversation.preview
      }
    });
  } catch (error) {
    console.error('Error fetching messages:', error);
    if (error.message === 'Conversation not found') {
      res.status(404).json({ error: error.message });
    } else {
      res.status(500).json({ error: error.message });
    }
  }
});

module.exports = router;