const express = require('express');
const router = express.Router();
const agentRoutes = require('./agentRoutes');
const conversationRoutes = require('./conversationRoutes');
const fileRoutes = require('./fileRoutes');

// API Routes
router.use('/api/agents', agentRoutes);
router.use('/api/conversations', conversationRoutes);
router.use('/api/files', fileRoutes);

// Home route
router.get('/', (req, res) => {
  res.json({ message: 'PaulWeezy API Server' });
});

module.exports = router;