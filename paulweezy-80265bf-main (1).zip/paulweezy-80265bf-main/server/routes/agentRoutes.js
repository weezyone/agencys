const express = require('express');
const router = express.Router();
const agentService = require('../services/agentService');
const { sendLLMRequest } = require('../services/llmService');

// GET /api/agents - Get all agents
router.get('/', async (req, res) => {
  try {
    console.log('GET /api/agents - Fetching agents');
    console.log('AgentRoutes: Starting to fetch agents');
    
    const agents = await agentService.getAllAgents();
    
    console.log('AgentRoutes: Agents fetched successfully, count:', agents.length);
    res.json({ agents });
  } catch (error) {
    console.error('AgentRoutes: Error fetching agents:', error);
    res.status(500).json({ error: error.message });
  }
});

// POST /api/agents - Create new agent
router.post('/', async (req, res) => {
  try {
    console.log('POST /api/agents - Creating agent');
    console.log('Request body:', req.body);

    const agent = await agentService.createAgent(req.body);
    
    console.log('AgentRoutes: Agent created successfully:', agent._id);
    res.status(201).json({ agent, message: 'Agent created successfully' });
  } catch (error) {
    console.error('AgentRoutes: Error creating agent:', error);
    res.status(500).json({ error: error.message });
  }
});

// GET /api/agents/:id - Get agent by ID
router.get('/:id', async (req, res) => {
  try {
    console.log(`GET /api/agents/${req.params.id} - Fetching agent`);

    const agent = await agentService.getAgentById(req.params.id);
    
    console.log('AgentRoutes: Agent fetched successfully');
    res.json({ agent });
  } catch (error) {
    console.error('AgentRoutes: Error fetching agent:', error);
    if (error.message === 'Agent not found') {
      res.status(404).json({ error: error.message });
    } else {
      res.status(500).json({ error: error.message });
    }
  }
});

// PUT /api/agents/:id - Update agent
router.put('/:id', async (req, res) => {
  try {
    console.log(`PUT /api/agents/${req.params.id} - Updating agent`);
    console.log('Request body:', req.body);

    const agent = await agentService.updateAgent(req.params.id, req.body);
    
    console.log('AgentRoutes: Agent updated successfully');
    res.json({ agent, message: 'Agent updated successfully' });
  } catch (error) {
    console.error('AgentRoutes: Error updating agent:', error);
    if (error.message === 'Agent not found') {
      res.status(404).json({ error: error.message });
    } else {
      res.status(500).json({ error: error.message });
    }
  }
});

// DELETE /api/agents/:id - Delete agent
router.delete('/:id', async (req, res) => {
  try {
    console.log(`DELETE /api/agents/${req.params.id} - Deleting agent`);

    const result = await agentService.deleteAgent(req.params.id);
    
    console.log('AgentRoutes: Agent deleted successfully');
    res.json(result);
  } catch (error) {
    console.error('AgentRoutes: Error deleting agent:', error);
    if (error.message === 'Agent not found') {
      res.status(404).json({ error: error.message });
    } else {
      res.status(500).json({ error: error.message });
    }
  }
});

// POST /api/agents/query - Direct query to agent without creating conversation
router.post('/query', async (req, res) => {
  try {
    console.log('POST /api/agents/query - Processing direct agent query');
    console.log('Request body:', req.body);

    const { agentType, message, context } = req.body;

    if (!agentType || !message) {
      return res.status(400).json({
        error: 'Agent type and message are required'
      });
    }

    // Validate agentType
    const validAgentTypes = ['design', 'development', 'project-manager'];
    if (!validAgentTypes.includes(agentType)) {
      return res.status(400).json({
        error: 'Invalid agent type. Must be one of: ' + validAgentTypes.join(', ')
      });
    }

    // Get agent-specific system prompt
    let systemPrompt = 'You are a helpful AI assistant. Provide helpful and accurate information.';

    switch (agentType) {
      case 'design':
        systemPrompt = 'You are a design expert specializing in UI/UX design, wireframes, and design systems. Provide helpful design advice and recommendations with specific examples and best practices.';
        break;
      case 'development':
        systemPrompt = 'You are a development expert specializing in code review, architecture, and implementation. Provide helpful programming advice, code solutions, and technical guidance with examples.';
        break;
      case 'project-manager':
        systemPrompt = 'You are a project management expert specializing in project planning, timelines, and client communication. Provide helpful project management advice, strategies, and actionable recommendations.';
        break;
      default:
        systemPrompt = 'You are a helpful AI assistant. Provide helpful and accurate information.';
    }

    // Add context to the message if provided
    let fullMessage = message;
    if (context && context.trim()) {
      fullMessage = `Context: ${context}\n\nQuery: ${message}`;
    }

    console.log('AgentRoutes: Sending query to LLM service...');
    console.log('AgentRoutes: System prompt:', systemPrompt);
    console.log('AgentRoutes: Full message:', fullMessage);

    // Send to LLM service to get AI response
    const llmResponse = await sendLLMRequest(fullMessage, 'openai', {
      systemPrompt: systemPrompt,
      maxTokens: 1500,
      temperature: 0.7
    });

    console.log('AgentRoutes: LLM response received:', llmResponse.substring(0, 100) + '...');

    res.json({
      response: llmResponse,
      agentType: agentType,
      query: message,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('AgentRoutes: Error processing agent query:', error);
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;