const OpenAI = require('openai');

// Initialize OpenAI client
const openai = process.env.OPENAI_API_KEY ? new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
}) : null;

/**
 * Send request to LLM service
 * @param {string} message - User message
 * @param {string} provider - LLM provider ('openai' or 'anthropic')
 * @param {object} options - Additional options
 * @returns {Promise<string>} - LLM response
 */
async function sendLLMRequest(message, provider = 'openai', options = {}) {
  try {
    console.log('LLMService: Sending request to', provider);
    console.log('LLMService: Message:', message.substring(0, 100) + '...');
    console.log('LLMService: Options:', options);

    // Extract options with explicit defaults
    const systemPrompt = options.systemPrompt || 'You are a helpful AI assistant.';
    const model = options.model || 'gpt-3.5-turbo';
    const maxTokens = options.maxTokens || 1500;
    const temperature = options.temperature || 0.7;

    console.log('LLMService: Using model:', model);
    console.log('LLMService: Max tokens:', maxTokens);
    console.log('LLMService: Temperature:', temperature);

    // If OpenAI is not configured, return mock response
    if (!openai || !process.env.OPENAI_API_KEY) {
      console.log('LLMService: OpenAI not configured, returning mock response');
      return generateMockResponse(message, systemPrompt);
    }

    // Prepare messages for OpenAI API
    const messages = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: message }
    ];

    console.log('LLMService: Calling OpenAI API with messages:', messages);

    const response = await openai.chat.completions.create({
      model: model,
      messages: messages,
      max_tokens: maxTokens,
      temperature: temperature
    });

    const aiResponse = response.choices[0].message.content;
    console.log('LLMService: Received response from OpenAI:', aiResponse.substring(0, 100) + '...');

    return aiResponse;
  } catch (error) {
    console.error('LLMService: Error calling LLM service:', error);
    console.error('LLMService: Error details - Status:', error.status, 'Code:', error.code, 'Type:', error.type);

    // Fallback to mock response on error
    console.log('LLMService: Falling back to mock response');
    return generateMockResponse(message, options.systemPrompt);
  }
}

/**
 * Generate mock response for testing/fallback
 * @param {string} message - User message
 * @param {string} systemPrompt - System prompt to determine response type
 * @returns {string} - Mock response
 */
function generateMockResponse(message, systemPrompt = '') {
  console.log('LLMService: Generating mock response');

  // Customize response based on system prompt
  if (systemPrompt.includes('design')) {
    return `Thank you for your design question: "${message}". Here are some design recommendations:

1. **User Experience**: Focus on creating intuitive user flows that guide users naturally through your interface.

2. **Visual Hierarchy**: Use typography, spacing, and color to create clear information hierarchy.

3. **Accessibility**: Ensure your design meets WCAG guidelines for color contrast and keyboard navigation.

4. **Design System**: Consider creating reusable components to maintain consistency across your project.

5. **Mobile-First**: Start with mobile design and progressively enhance for larger screens.

Would you like me to elaborate on any of these points or help with specific design challenges?`;
  }

  if (systemPrompt.includes('development')) {
    return `Thank you for your development question: "${message}". Here are some technical recommendations:

1. **Code Quality**: Follow established coding standards and use linting tools to maintain consistency.

2. **Architecture**: Consider using modular architecture patterns that promote code reusability and maintainability.

3. **Testing**: Implement unit tests and integration tests to ensure code reliability.

4. **Performance**: Optimize for performance by minimizing bundle size and implementing efficient algorithms.

5. **Security**: Follow security best practices, especially for user input validation and data handling.

Would you like me to provide more specific guidance on any of these areas?`;
  }

  if (systemPrompt.includes('project')) {
    return `Thank you for your project management question: "${message}". Here are some project management recommendations:

1. **Planning**: Break down the project into smaller, manageable tasks with clear deliverables.

2. **Timeline**: Create realistic timelines with buffer time for unexpected challenges.

3. **Communication**: Establish regular check-ins with stakeholders and team members.

4. **Risk Management**: Identify potential risks early and have mitigation strategies in place.

5. **Documentation**: Keep thorough documentation of decisions, requirements, and progress.

Would you like me to help you create a specific project plan or address any particular challenges?`;
  }

  // Default response
  return `Thank you for your message: "${message}". I understand you're looking for assistance with your project. Here are some general recommendations to help you move forward:

1. **Define Clear Objectives**: Start by clearly defining what you want to achieve.

2. **Research and Planning**: Take time to research best practices and create a solid plan.

3. **Iterative Approach**: Break your work into smaller iterations and test frequently.

4. **Seek Feedback**: Get feedback from users or stakeholders early and often.

5. **Documentation**: Keep track of your decisions and learnings for future reference.

Would you like me to provide more specific guidance based on your particular needs?`;
}

module.exports = {
  sendLLMRequest
};