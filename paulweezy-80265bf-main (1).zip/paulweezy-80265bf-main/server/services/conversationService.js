const Conversation = require('../models/Conversation');

class ConversationService {

  // Create a new conversation
  async createConversation(data) {
    try {
      console.log('ConversationService: Creating conversation with data:', data);

      const { agentType, message, files } = data;

      if (!agentType || !message) {
        throw new Error('Agent type and message are required');
      }

      // Generate title and preview from the message
      const title = message.length > 50 ? message.substring(0, 50) + '...' : message;
      const preview = message.length > 100 ? message.substring(0, 100) + '...' : message;

      // Create initial user message
      const initialMessage = {
        role: 'user',
        content: message,
        files: files || []
      };

      const conversation = new Conversation({
        agentType,
        title,
        preview,
        messages: [initialMessage],
        status: 'active'
      });

      const savedConversation = await conversation.save();
      console.log('ConversationService: Conversation created successfully:', savedConversation._id);

      return savedConversation;
    } catch (error) {
      console.error('ConversationService: Error creating conversation:', error);
      throw error;
    }
  }

  // Add message to existing conversation
  async addMessageToConversation(conversationId, messageData) {
    try {
      console.log('ConversationService: Adding message to conversation:', conversationId);
      console.log('ConversationService: Message data:', messageData);

      const { role, content, files } = messageData;

      if (!role || !content) {
        throw new Error('Message role and content are required');
      }

      if (!['user', 'assistant'].includes(role)) {
        throw new Error('Message role must be either "user" or "assistant"');
      }

      // Find the conversation
      const conversation = await Conversation.findOne({
        _id: conversationId,
        status: { $ne: 'deleted' }
      });

      if (!conversation) {
        throw new Error('Conversation not found');
      }

      // Create new message
      const newMessage = {
        role,
        content,
        files: files || []
      };

      // Add message to conversation
      conversation.messages.push(newMessage);

      // Update preview if it's a user message
      if (role === 'user') {
        conversation.preview = content.length > 100 ? content.substring(0, 100) + '...' : content;
      }

      // Save the conversation
      const savedConversation = await conversation.save();
      
      // Get the newly added message (last one in the array)
      const addedMessage = savedConversation.messages[savedConversation.messages.length - 1];

      console.log('ConversationService: Message added successfully:', addedMessage._id);
      return addedMessage;
    } catch (error) {
      console.error('ConversationService: Error adding message to conversation:', error);
      throw error;
    }
  }

  // Get all conversations
  async getConversations(filters = {}) {
    try {
      console.log('ConversationService: Fetching conversations with filters:', filters);

      const query = { status: { $ne: 'deleted' } };

      // Add filters if provided
      if (filters.agentType) {
        query.agentType = filters.agentType;
      }

      const conversations = await Conversation.find(query)
        .sort({ updatedAt: -1 })
        .lean();

      console.log('ConversationService: Found conversations:', conversations.length);
      return conversations;
    } catch (error) {
      console.error('ConversationService: Error fetching conversations:', error);
      throw error;
    }
  }

  // Get conversation by ID
  async getConversationById(id) {
    try {
      console.log('ConversationService: Fetching conversation by ID:', id);

      const conversation = await Conversation.findOne({
        _id: id,
        status: { $ne: 'deleted' }
      }).lean();

      if (!conversation) {
        throw new Error('Conversation not found');
      }

      console.log('ConversationService: Conversation found:', conversation._id);
      return conversation;
    } catch (error) {
      console.error('ConversationService: Error fetching conversation:', error);
      throw error;
    }
  }

  // Update conversation
  async updateConversation(id, updates) {
    try {
      console.log('ConversationService: Updating conversation:', id, updates);

      const conversation = await Conversation.findOneAndUpdate(
        { _id: id, status: { $ne: 'deleted' } },
        { $set: updates },
        { new: true, runValidators: true }
      );

      if (!conversation) {
        throw new Error('Conversation not found');
      }

      console.log('ConversationService: Conversation updated successfully');
      return conversation;
    } catch (error) {
      console.error('ConversationService: Error updating conversation:', error);
      throw error;
    }
  }

  // Delete conversation (soft delete)
  async deleteConversation(id) {
    try {
      console.log('ConversationService: Deleting conversation:', id);

      const conversation = await Conversation.findOneAndUpdate(
        { _id: id, status: { $ne: 'deleted' } },
        { $set: { status: 'deleted' } },
        { new: true }
      );

      if (!conversation) {
        throw new Error('Conversation not found');
      }

      console.log('ConversationService: Conversation deleted successfully');
      return conversation;
    } catch (error) {
      console.error('ConversationService: Error deleting conversation:', error);
      throw error;
    }
  }
}

module.exports = new ConversationService();