const Agent = require('../models/Agent');
const mongoose = require('mongoose');

/**
 * Create a new agent
 * @param {Object} agentData - Agent data
 * @returns {Promise<Object>} Created agent
 */
const createAgent = async (agentData) => {
  try {
    console.log('=== AgentService.createAgent START ===');
    console.log('AgentService: Creating agent with data:', agentData);
    console.log('AgentService: Database connection state:', mongoose.connection.readyState);
    console.log('AgentService: Database name:', mongoose.connection.db.databaseName);
    console.log('AgentService: Collection name: agents');

    const agent = new Agent(agentData);
    console.log('AgentService: Agent model instance created:', { 
      id: agent._id, 
      name: agent.name, 
      type: agent.type 
    });
    
    const savedAgent = await agent.save();
    console.log('AgentService: Agent saved to database successfully');
    console.log('AgentService: Saved to database:', mongoose.connection.db.databaseName);
    console.log('AgentService: Saved to collection: agents');
    console.log('AgentService: Saved agent details:', { 
      id: savedAgent._id, 
      name: savedAgent.name, 
      type: savedAgent.type,
      createdAt: savedAgent.createdAt
    });
    console.log('=== AgentService.createAgent END ===');
    
    return savedAgent;
  } catch (error) {
    console.error('=== AgentService.createAgent ERROR ===');
    console.error('AgentService: Error creating agent:', error.message);
    console.error('AgentService: Error code:', error.code);
    console.error('AgentService: Full error:', error);
    console.error('AgentService: Stack trace:', error.stack);
    
    if (error.code === 11000) {
      console.error('AgentService: Duplicate key error - agent type already exists');
      throw new Error('Agent type already exists');
    }
    throw new Error(error.message);
  }
};

/**
 * Get all agents
 * @returns {Promise<Array>} List of agents
 */
const getAllAgents = async () => {
  try {
    console.log('=== AgentService.getAllAgents START ===');
    console.log('AgentService: Fetching all active agents from database');
    console.log('AgentService: Database connection state:', mongoose.connection.readyState);
    console.log('AgentService: Database name:', mongoose.connection.db.databaseName);
    console.log('AgentService: Collection name: agents');

    const agents = await Agent.find({ status: 'active' }).sort({ createdAt: -1 });
    console.log(`AgentService: Database query completed - found ${agents.length} active agents`);
    console.log('AgentService: Query executed on database:', mongoose.connection.db.databaseName);
    console.log('AgentService: Query executed on collection: agents');

    if (agents.length > 0) {
      console.log('AgentService: Agent details:', agents.map(a => ({
        id: a._id,
        name: a.name,
        type: a.type,
        status: a.status,
        createdAt: a.createdAt
      })));
    } else {
      console.log('AgentService: No agents found in database');
    }

    console.log('=== USER DATABASE VERIFICATION INFO ===');
    console.log('To verify data in your MongoDB database:');
    console.log('Database Name:', mongoose.connection.db.databaseName);
    console.log('Collection Name: agents');
    console.log('Connection String: mongodb+srv://weezy:weezy@cluster0.7z3jnii.mongodb.net/' + mongoose.connection.db.databaseName);
    console.log('MongoDB Compass Connection String: mongodb+srv://weezy:weezy@cluster0.7z3jnii.mongodb.net/' + mongoose.connection.db.databaseName);
    console.log('=== END DATABASE VERIFICATION INFO ===');

    console.log('=== AgentService.getAllAgents END ===');
    return agents;
  } catch (error) {
    console.error('=== AgentService.getAllAgents ERROR ===');
    console.error('AgentService: Error fetching agents:', error.message);
    console.error('AgentService: Full error:', error);
    console.error('AgentService: Stack trace:', error.stack);
    throw new Error(error.message);
  }
};

/**
 * Get agent by ID
 * @param {String} id - Agent ID
 * @returns {Promise<Object>} Agent data
 */
const getAgentById = async (id) => {
  try {
    console.log(`AgentService: Fetching agent by ID: ${id}`);
    const agent = await Agent.findById(id);
    if (!agent) {
      console.log(`AgentService: Agent not found with ID: ${id}`);
      throw new Error('Agent not found');
    }
    console.log(`AgentService: Found agent: ${agent.name}`);
    return agent;
  } catch (error) {
    console.error(`AgentService: Error fetching agent ${id}:`, error.message);
    throw new Error(error.message);
  }
};

/**
 * Update agent
 * @param {String} id - Agent ID
 * @param {Object} updateData - Data to update
 * @returns {Promise<Object>} Updated agent
 */
const updateAgent = async (id, updateData) => {
  try {
    console.log(`AgentService: Updating agent ${id} with data:`, updateData);
    const agent = await Agent.findByIdAndUpdate(id, updateData, {
      new: true,
      runValidators: true
    });
    if (!agent) {
      console.log(`AgentService: Agent not found for update with ID: ${id}`);
      throw new Error('Agent not found');
    }
    console.log(`AgentService: Agent updated successfully: ${agent.name}`);
    return agent;
  } catch (error) {
    console.error(`AgentService: Error updating agent ${id}:`, error.message);
    throw new Error(error.message);
  }
};

/**
 * Delete agent
 * @param {String} id - Agent ID
 * @returns {Promise<Object>} Success message
 */
const deleteAgent = async (id) => {
  try {
    console.log(`AgentService: Deleting agent with ID: ${id}`);
    const agent = await Agent.findByIdAndDelete(id);
    if (!agent) {
      console.log(`AgentService: Agent not found for deletion with ID: ${id}`);
      throw new Error('Agent not found');
    }
    console.log(`AgentService: Agent deleted successfully: ${agent.name}`);
    return { message: 'Agent deleted successfully' };
  } catch (error) {
    console.error(`AgentService: Error deleting agent ${id}:`, error.message);
    throw new Error(error.message);
  }
};

module.exports = {
  createAgent,
  getAllAgents,
  getAgentById,
  updateAgent,
  deleteAgent
};