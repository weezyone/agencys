const File = require('../models/File');
const fileStorage = require('../utils/fileStorage');

class FileService {

  // Upload and store file
  async uploadFile(fileData) {
    try {
      console.log('FileService: Processing file upload:', fileData.originalname);

      // Store file using file storage service
      const storageResult = await fileStorage.storeFile({
        buffer: fileData.buffer,
        originalName: fileData.originalname,
        mimetype: fileData.mimetype,
        size: fileData.size
      });

      // Save file metadata to database
      const file = new File({
        name: storageResult.fileName,
        originalName: fileData.originalname,
        type: fileData.mimetype,
        size: fileData.size,
        url: storageResult.url,
        path: storageResult.filePath,
        status: 'active'
      });

      const savedFile = await file.save();
      console.log('FileService: File uploaded successfully:', savedFile._id);

      return {
        _id: savedFile._id,
        name: savedFile.originalName,
        type: savedFile.type,
        size: savedFile.size,
        url: savedFile.url
      };
    } catch (error) {
      console.error('FileService: Error uploading file:', error);
      throw error;
    }
  }

  // Get file by ID
  async getFileById(id) {
    try {
      console.log('FileService: Fetching file by ID:', id);

      const file = await File.findOne({
        _id: id,
        status: 'active'
      }).lean();

      if (!file) {
        throw new Error('File not found');
      }

      console.log('FileService: File found:', file._id);
      return file;
    } catch (error) {
      console.error('FileService: Error fetching file:', error);
      throw error;
    }
  }

  // Get file by name for download
  async getFileByName(fileName) {
    try {
      console.log('FileService: Fetching file by name:', fileName);

      const file = await File.findOne({
        name: fileName,
        status: 'active'
      }).lean();

      if (!file) {
        throw new Error('File not found');
      }

      // Get file from storage
      const storageResult = await fileStorage.getFile(fileName);
      
      if (!storageResult.exists) {
        throw new Error('File not found in storage');
      }

      console.log('FileService: File found for download:', file._id);
      return {
        ...file,
        filePath: storageResult.filePath
      };
    } catch (error) {
      console.error('FileService: Error fetching file by name:', error);
      throw error;
    }
  }

  // Delete file
  async deleteFile(id) {
    try {
      console.log('FileService: Deleting file:', id);

      const file = await File.findOneAndUpdate(
        { _id: id, status: 'active' },
        { $set: { status: 'deleted' } },
        { new: true }
      );

      if (!file) {
        throw new Error('File not found');
      }

      // Optionally delete from storage (commented out for safety)
      // await fileStorage.deleteFile(file.path);

      console.log('FileService: File deleted successfully');
      return file;
    } catch (error) {
      console.error('FileService: Error deleting file:', error);
      throw error;
    }
  }

  // Get all files
  async getFiles(filters = {}) {
    try {
      console.log('FileService: Fetching files with filters:', filters);

      const query = { status: 'active' };

      const files = await File.find(query)
        .sort({ createdAt: -1 })
        .lean();

      console.log('FileService: Found files:', files.length);
      return files;
    } catch (error) {
      console.error('FileService: Error fetching files:', error);
      throw error;
    }
  }
}

module.exports = new FileService();