const mongoose = require('mongoose');
require('dotenv').config();

const connectDB = async () => {
  try {
    console.log('=== Database Connection START ===');
    console.log('Database: Attempting to connect to MongoDB...');
    console.log('Database: Connection URL:', process.env.DATABASE_URL ? 'URL provided' : 'NO URL PROVIDED');
    
    const conn = await mongoose.connect(process.env.DATABASE_URL, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    console.log('Database: MongoDB Connected successfully');
    console.log('Database: Connection host:', conn.connection.host);
    console.log('Database: Connection name:', conn.connection.name);
    console.log('Database: Connection state:', conn.connection.readyState);
    console.log('Database: Full database name:', conn.connection.db.databaseName);
    console.log('Database: Database URL (parsed):', conn.connection.db.s.options.host);
    console.log('=== Database Connection END ===');

    // Listen for connection events
    mongoose.connection.on('connected', () => {
      console.log('Database: Mongoose connected to MongoDB');
      console.log('Database: Connected to database:', mongoose.connection.db.databaseName);
      console.log('Database: Available collections will be: agents, conversations, messages, files');
    });

    mongoose.connection.on('error', (err) => {
      console.error('Database: Mongoose connection error:', err);
    });

    mongoose.connection.on('disconnected', () => {
      console.log('Database: Mongoose disconnected from MongoDB');
    });

  } catch (error) {
    console.error('=== Database Connection ERROR ===');
    console.error('Database: Error connecting to MongoDB:', error.message);
    console.error('Database: Full error:', error);
    console.error('Database: Stack trace:', error.stack);
    process.exit(1);
  }
};

module.exports = { connectDB };