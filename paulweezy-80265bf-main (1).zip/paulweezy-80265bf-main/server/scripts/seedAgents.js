const mongoose = require('mongoose');
const Agent = require('../models/Agent');
require('dotenv').config();

const defaultAgents = [
  {
    type: 'design',
    name: 'Design Agent',
    description: 'Expert in UI/UX design, wireframes, and design systems',
    icon: 'Palette',
    color: 'bg-gradient-to-br from-purple-500 to-pink-500',
    capabilities: ['UI/UX Design', 'Design Systems', 'Wireframing', 'Color Theory', 'Typography'],
    status: 'active'
  },
  {
    type: 'development',
    name: 'Development Agent',
    description: 'Specialized in code review, architecture, and implementation',
    icon: 'Code',
    color: 'bg-gradient-to-br from-blue-500 to-cyan-500',
    capabilities: ['Code Review', 'Architecture', 'Bug Fixing', 'Performance Optimization', 'Best Practices'],
    status: 'active'
  },
  {
    type: 'project-manager',
    name: 'Project Manager Agent',
    description: 'Helps with project planning, timelines, and client communication',
    icon: 'Calendar',
    color: 'bg-gradient-to-br from-green-500 to-emerald-500',
    capabilities: ['Project Planning', 'Timeline Management', 'Client Communication', 'Task Organization', 'Reporting'],
    status: 'active'
  }
];

const seedAgents = async () => {
  try {
    await mongoose.connect(process.env.DATABASE_URL, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    console.log('Connected to MongoDB');

    // Clear existing agents
    await Agent.deleteMany({});
    console.log('Cleared existing agents');

    // Insert default agents
    await Agent.insertMany(defaultAgents);
    console.log('Default agents seeded successfully');

    process.exit(0);
  } catch (error) {
    console.error('Error seeding agents:', error);
    process.exit(1);
  }
};

seedAgents();