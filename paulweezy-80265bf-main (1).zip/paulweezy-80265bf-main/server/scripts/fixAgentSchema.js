const mongoose = require('mongoose');
require('dotenv').config();

const fixAgentSchema = async () => {
  try {
    console.log('Connecting to MongoDB...');
    await mongoose.connect(process.env.DATABASE_URL);
    console.log('Connected to MongoDB');

    const db = mongoose.connection.db;
    const collection = db.collection('agents');

    // Check existing indexes
    const indexes = await collection.indexes();
    console.log('Existing indexes:', indexes);

    // Drop the unique index on type field if it exists
    try {
      await collection.dropIndex('type_1');
      console.log('Successfully dropped unique index on type field');
    } catch (error) {
      if (error.code === 27) {
        console.log('Index type_1 does not exist, no need to drop');
      } else {
        console.error('Error dropping index:', error.message);
      }
    }

    // Verify indexes after dropping
    const indexesAfter = await collection.indexes();
    console.log('Indexes after cleanup:', indexesAfter);

    console.log('Schema fix completed successfully');
    process.exit(0);
  } catch (error) {
    console.error('Error fixing schema:', error.message);
    process.exit(1);
  }
};

fixAgentSchema();