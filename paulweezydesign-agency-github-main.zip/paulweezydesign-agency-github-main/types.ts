export type ViewState = 'dashboard' | 'projects' | 'clients' | 'reports' | 'settings';

export interface Project {
  id: string;
  name: string;
  client: string;
  status: 'On Track' | 'At Risk' | 'Delayed';
  progress: number;
  dueDate: string;
}

export interface RecurrenceConfig {
  frequency: 'daily' | 'weekly' | 'monthly';
  interval: number;
  endDate?: string;
}

export interface Task {
  id: string;
  title: string;
  priority: 'High' | 'Medium' | 'Low' | 'Critical';
  dueDate: string;
  assigneeAvatar?: string;
  assigneeId?: string;
  status: 'backlog' | 'in_progress' | 'review' | 'done';
  dependencies?: string[];
  recurrence?: RecurrenceConfig;
}

export interface TaskTemplate {
  id: string;
  title: string;
  priority: 'High' | 'Medium' | 'Low' | 'Critical';
}

export interface Proposal {
  id: string;
  title: string;
  status: 'Signed' | 'Pending' | 'Sent' | 'Draft';
  value: string;
  date: string;
}

export interface Activity {
  id: string;
  text: string;
  highlight?: string;
  time: string;
  type: 'system' | 'user' | 'client';
}