import React from 'react';
import { ArrowUp, ArrowDown, CheckCircle2, Timer, DollarSign, Smile } from 'lucide-react';
import { Project } from '../types';

const Dashboard: React.FC = () => {
  const metrics = [
    {
      title: 'On-Time Delivery',
      value: '92%',
      change: '+1.5%',
      trend: 'up',
      icon: CheckCircle2,
      color: 'text-green-500'
    },
    {
      title: 'Avg. Approval Cycle',
      value: '2.5 Days',
      change: '-0.2 Days',
      trend: 'down', // Good for time
      icon: Timer,
      color: 'text-blue-500'
    },
    {
      title: 'Total Unbilled Scope',
      value: '$15,800',
      change: '+$1.2k',
      trend: 'up', // Maybe neutral/bad contextually but lets stick to visual
      icon: DollarSign,
      color: 'text-yellow-500'
    },
    {
      title: 'Client Satisfaction',
      value: '4.8/5',
      change: '+0.1',
      trend: 'up',
      icon: Smile,
      color: 'text-purple-500'
    }
  ];

  const projects: Project[] = [
    { id: '1', name: 'InnovateX Website Redesign', client: 'InnovateX', status: 'On Track', progress: 65, dueDate: 'Oct 15, 2024' },
    { id: '2', name: 'QuantumLeap Branding', client: 'QuantumLeap', status: 'At Risk', progress: 40, dueDate: 'Sep 28, 2024' },
    { id: '3', name: 'Aperture Mobile App', client: 'Aperture Science', status: 'Delayed', progress: 25, dueDate: 'Aug 30, 2024' },
    { id: '4', name: 'Zenith Corp Marketing', client: 'Zenith Corp', status: 'On Track', progress: 10, dueDate: 'Dec 01, 2024' },
  ];

  const teamLoad = [
    { name: 'Olivia Chen', load: 95, color: 'bg-red-500' },
    { name: 'Benjamin Carter', load: 80, color: 'bg-green-500' },
    { name: 'Sophia Rodriguez', load: 60, color: 'bg-blue-500' },
    { name: 'Liam Goldberg', load: 35, color: 'bg-yellow-500' },
  ];

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8 animate-fade-in">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">Good morning, Alex</h1>
        <p className="text-textMuted">Here's a look at your agency's health today.</p>
      </header>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((m, i) => (
          <div key={i} className="bg-surface border border-border p-6 hover:border-border/80 transition-colors">
            <div className="flex justify-between items-start mb-4">
              <span className="text-textMuted font-medium text-sm">{m.title}</span>
              <m.icon size={20} className={m.color} />
            </div>
            <div className="text-4xl font-bold text-white mb-2">{m.value}</div>
            <div className={`text-sm font-medium flex items-center gap-1 ${
              m.trend === 'up' && m.title !== 'Avg. Approval Cycle' ? 'text-green-500' : 
              m.trend === 'down' && m.title === 'Avg. Approval Cycle' ? 'text-red-500' : // contextually down is good for time? Usually UI implies green=good.
              'text-green-500' 
            }`}>
              {m.trend === 'up' ? <ArrowUp size={14} /> : <ArrowDown size={14} />}
              {m.change}
              <span className="text-textMuted font-normal ml-1">vs last month</span>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Active Projects */}
        <div className="lg:col-span-2 bg-surface border border-border p-6">
          <h2 className="text-lg font-bold text-white mb-6">Active Projects</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-border">
                  <th className="pb-4 text-xs font-bold text-textMuted uppercase tracking-wider">Project</th>
                  <th className="pb-4 text-xs font-bold text-textMuted uppercase tracking-wider">Status</th>
                  <th className="pb-4 text-xs font-bold text-textMuted uppercase tracking-wider">Progress</th>
                  <th className="pb-4 text-xs font-bold text-textMuted uppercase tracking-wider text-right">Due Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {projects.map((p) => (
                  <tr key={p.id} className="group">
                    <td className="py-4 font-medium text-white">{p.name}</td>
                    <td className="py-4">
                      <span className={`px-2 py-1 text-xs font-bold uppercase tracking-wide rounded-sm ${
                        p.status === 'On Track' ? 'bg-green-500/10 text-green-500' :
                        p.status === 'At Risk' ? 'bg-yellow-500/10 text-yellow-500' :
                        'bg-red-500/10 text-red-500'
                      }`}>
                        {p.status}
                      </span>
                    </td>
                    <td className="py-4 w-1/4">
                      <div className="h-1.5 w-full bg-border rounded-full overflow-hidden">
                        <div 
                          className={`h-full rounded-full ${
                            p.status === 'On Track' ? 'bg-green-500' :
                            p.status === 'At Risk' ? 'bg-yellow-500' :
                            'bg-red-500'
                          }`} 
                          style={{ width: `${p.progress}%` }}
                        />
                      </div>
                    </td>
                    <td className="py-4 text-textMuted text-right text-sm">{p.dueDate}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-6 text-center">
             <button className="text-primary hover:text-primaryHover text-sm font-medium transition-colors">View All Projects</button>
          </div>
        </div>

        {/* Team Workload */}
        <div className="bg-surface border border-border p-6">
          <h2 className="text-lg font-bold text-white mb-6">Team Workload</h2>
          <div className="space-y-6">
            {teamLoad.map((member, i) => (
              <div key={i}>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-white font-medium">{member.name}</span>
                  <span className="text-textMuted">{member.load}%</span>
                </div>
                <div className="h-2 w-full bg-border rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full ${member.color}`} 
                    style={{ width: `${member.load}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
          <div className="mt-8 pt-6 border-t border-border text-center">
             <button className="text-primary hover:text-primaryHover text-sm font-medium transition-colors">View Team Schedule</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;