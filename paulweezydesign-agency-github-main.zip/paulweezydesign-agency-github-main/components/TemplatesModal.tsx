import React from 'react';
import { X, Trash2, FileText, ArrowRight } from 'lucide-react';
import { TaskTemplate } from '../types';

interface TemplatesModalProps {
  templates: TaskTemplate[];
  onClose: () => void;
  onUseTemplate: (template: TaskTemplate) => void;
  onDeleteTemplate: (id: string) => void;
  onCreateTemplate: (e: React.FormEvent) => void;
  newTemplateTitle: string;
  onNewTemplateTitleChange: (title: string) => void;
  newTemplatePriority: 'High' | 'Medium' | 'Low' | 'Critical';
  onNewTemplatePriorityChange: (priority: 'High' | 'Medium' | 'Low' | 'Critical') => void;
}

const TemplatesModal: React.FC<TemplatesModalProps> = ({
  templates,
  onClose,
  onUseTemplate,
  onDeleteTemplate,
  onCreateTemplate,
  newTemplateTitle,
  onNewTemplateTitleChange,
  newTemplatePriority,
  onNewTemplatePriorityChange,
}) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4" onClick={(e) => {
      if(e.target === e.currentTarget) onClose();
  }}>
    <div className="bg-surface border border-border w-full max-w-2xl shadow-2xl animate-fade-in flex flex-col max-h-[85vh]">
      <div className="flex justify-between items-center p-6 border-b border-border bg-surfaceHighlight/20">
          <div className="flex items-center gap-3">
              <FileText className="text-primary" />
              <h3 className="text-lg font-bold text-white tracking-wide">Task Templates</h3>
          </div>
          <button onClick={onClose} className="text-textMuted hover:text-white transition-colors">
              <X size={20} />
          </button>
      </div>
      
      <div className="p-6 flex-1 overflow-y-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {templates.map(template => (
                  <div key={template.id} className="bg-background border border-border p-4 hover:border-primary transition-colors group relative">
                      <div className="flex justify-between items-start mb-2">
                          <h4 className="font-bold text-white text-sm">{template.title}</h4>
                          <span className={`text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 border ${
                             template.priority === 'Critical' ? 'border-primary text-primary' :
                             template.priority === 'High' ? 'border-orange-500 text-orange-500' :
                             'border-textMuted text-textMuted'
                          }`}>
                             {template.priority}
                          </span>
                      </div>
                      <p className="text-xs text-textMuted mb-4">Creates a new task in Backlog.</p>
                      
                      <div className="flex gap-2 mt-auto">
                          <button 
                              onClick={() => onUseTemplate(template)}
                              className="flex-1 bg-white text-black text-xs font-bold uppercase tracking-wider py-2 hover:bg-primary hover:text-white transition-colors flex items-center justify-center gap-2"
                          >
                              Use Template <ArrowRight size={12} />
                          </button>
                          <button 
                              onClick={() => onDeleteTemplate(template.id)}
                              className="px-2 border border-border text-textMuted hover:text-red-500 hover:border-red-500 transition-colors"
                          >
                              <Trash2 size={14} />
                          </button>
                      </div>
                  </div>
              ))}
          </div>
          
          {templates.length === 0 && (
              <div className="text-center py-12 border-2 border-dashed border-border/50 rounded-lg">
                  <p className="text-textMuted">No templates found. Create one below.</p>
              </div>
          )}
      </div>

      <div className="p-6 border-t border-border bg-surfaceHighlight/5">
          <h4 className="text-xs font-bold uppercase tracking-widest text-white mb-4">Create New Template</h4>
          <form onSubmit={onCreateTemplate} className="flex gap-4 items-end">
              <div className="flex-1">
                  <label className="block text-xs font-bold text-textMuted uppercase tracking-wider mb-2">Template Title</label>
                  <input 
                      type="text" 
                      value={newTemplateTitle}
                      onChange={(e) => onNewTemplateTitleChange(e.target.value)}
                      placeholder="e.g. Monthly Report"
                      className="w-full bg-background border border-border px-4 py-2 text-white focus:outline-none focus:border-primary text-sm font-medium"
                  />
              </div>
              <div className="w-32">
                  <label className="block text-xs font-bold text-textMuted uppercase tracking-wider mb-2">Priority</label>
                   <div className="relative">
                        <select 
                            value={newTemplatePriority}
                            onChange={(e) => onNewTemplatePriorityChange(e.target.value as any)}
                            className="w-full bg-background border border-border px-4 py-2 text-white focus:outline-none focus:border-primary text-sm font-medium appearance-none cursor-pointer"
                        >
                            <option value="Low">Low</option>
                            <option value="Medium">Medium</option>
                            <option value="High">High</option>
                            <option value="Critical">Critical</option>
                        </select>
                        <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-textMuted">
                            <svg width="8" height="5" viewBox="0 0 10 6" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 1L5 5L9 1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
                        </div>
                    </div>
              </div>
              <button type="submit" className="px-6 py-2 bg-primary text-white text-sm font-bold uppercase tracking-wider hover:bg-primaryHover transition-colors h-[38px]">
                  Create
              </button>
          </form>
      </div>
    </div>
  </div>
);

export default TemplatesModal;
