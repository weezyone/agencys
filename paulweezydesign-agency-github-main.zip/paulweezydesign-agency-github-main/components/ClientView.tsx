import React from 'react';
import { Proposal, Activity } from '../types';
import { ArrowRight, Download, Send, AlertCircle } from 'lucide-react';

const ClientView: React.FC = () => {
  const proposals: Proposal[] = [
    { id: '1', title: 'Q3 2024 Marketing Retainer', status: 'Signed', value: '$25,000', date: 'July 15, 2024' },
    { id: '2', title: 'Website Redesign Project', status: 'Pending', value: '$48,000', date: 'Aug 01, 2024' },
    { id: '3', title: 'Initial SEO Audit & Strategy', status: 'Sent', value: '$5,000', date: 'June 28, 2024' },
    { id: '4', title: 'Brand Identity Exploration', status: 'Draft', value: '$12,000', date: 'Aug 05, 2024' },
  ];

  const activityLog: Activity[] = [
    { id: '1', text: 'Proposal Q3 Marketing Retainer was signed.', type: 'system', time: '2d ago', highlight: 'Q3 Marketing Retainer' },
    { id: '2', text: 'You sent proposal Website Redesign.', type: 'user', time: '5d ago', highlight: 'Website Redesign' },
    { id: '3', text: 'Client account created by Alex Johnson.', type: 'client', time: '1m ago', highlight: 'Alex Johnson' },
  ];

  return (
    <div className="flex h-full animate-fade-in bg-background">
      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-y-auto">
         <header className="px-12 py-10 border-b border-border">
            <div className="flex justify-between items-start mb-12">
               <div className="flex gap-6">
                  <div className="w-24 h-24 bg-white p-2 flex items-center justify-center">
                     <img src="https://picsum.photos/80/80?random=10" alt="Logo" className="grayscale" />
                  </div>
                  <div>
                     <h1 className="text-5xl font-extrabold text-white tracking-tighter mb-2 uppercase">Innovate Inc.</h1>
                     <div className="flex items-center gap-3 text-textMuted mb-1">
                        <span className="uppercase text-xs font-bold tracking-widest">Status</span>
                        <span className="text-white font-bold">Active</span>
                     </div>
                     <div className="text-textMuted">
                        Key Contact: <span className="text-white">Jane Doe</span> <span className="text-primary underline ml-2">jane.doe@innovate.com</span>
                     </div>
                  </div>
               </div>
               <div className="flex gap-4">
                  <button className="px-6 py-3 text-white font-bold uppercase tracking-wider text-sm hover:text-primary transition-colors">More Actions</button>
                  <button className="px-6 py-3 bg-primary text-white font-bold uppercase tracking-wider text-sm hover:bg-primaryHover transition-colors shadow-[4px_4px_0px_rgba(255,255,255,0.1)]">Create Proposal</button>
               </div>
            </div>

            <div className="flex gap-8 border-b border-white">
               {['Proposals', 'Overview', 'Communication', 'Projects', 'Files'].map((tab, i) => (
                  <button key={tab} className={`pb-4 text-sm font-bold uppercase tracking-widest ${i === 0 ? 'text-primary' : 'text-textMuted hover:text-white transition-colors'}`}>
                     {tab}
                  </button>
               ))}
            </div>
         </header>

         <div className="p-12">
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-4">
               Proposals & SOWs 
               <span className="h-[1px] bg-border flex-1"></span>
            </h2>

            <div className="overflow-x-auto mb-12">
               <table className="w-full text-left border-collapse">
                  <thead>
                     <tr className="border-b-2 border-white">
                        <th className="py-4 text-xs font-bold text-white uppercase tracking-widest w-1/3">Title</th>
                        <th className="py-4 text-xs font-bold text-white uppercase tracking-widest">Status</th>
                        <th className="py-4 text-xs font-bold text-white uppercase tracking-widest">Value</th>
                        <th className="py-4 text-xs font-bold text-white uppercase tracking-widest">Date</th>
                        <th className="py-4 text-xs font-bold text-white uppercase tracking-widest text-right">Actions</th>
                     </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                     {proposals.map(p => (
                        <tr key={p.id} className="group hover:bg-surfaceHighlight/30 transition-colors">
                           <td className="py-5 font-bold text-white relative">
                              {p.status === 'Pending' && <span className="absolute -left-3 top-1/2 -translate-y-1/2 w-1.5 h-1.5 bg-primary rounded-full"></span>}
                              {p.title}
                           </td>
                           <td className="py-5">
                              <span className={`px-2 py-0.5 border text-[10px] font-bold uppercase tracking-wider ${
                                 p.status === 'Signed' ? 'border-white text-white' :
                                 p.status === 'Pending' ? 'bg-primary border-primary text-white' :
                                 p.status === 'Sent' ? 'border-border text-textMuted' :
                                 'border-dashed border-textMuted text-textMuted'
                              }`}>
                                 {p.status}
                              </span>
                           </td>
                           <td className="py-5 text-textMuted font-mono">{p.value}</td>
                           <td className="py-5 text-textMuted text-sm">{p.date}</td>
                           <td className="py-5 text-right">
                              <div className="flex justify-end gap-4 opacity-0 group-hover:opacity-100 transition-opacity">
                                 {p.status === 'Pending' ? (
                                    <>
                                       <button className="text-xs font-bold uppercase tracking-wider text-white hover:text-primary underline decoration-1 underline-offset-4">Edit</button>
                                       <button className="text-xs font-bold uppercase tracking-wider text-primary hover:text-white underline decoration-1 underline-offset-4">Sign</button>
                                    </>
                                 ) : (
                                    <button className="text-xs font-bold uppercase tracking-wider text-white hover:text-primary underline decoration-1 underline-offset-4">View</button>
                                 )}
                              </div>
                           </td>
                        </tr>
                     ))}
                  </tbody>
               </table>
            </div>

            {/* Alert Box */}
            <div className="bg-white p-8 flex items-center justify-between border border-white shadow-[8px_8px_0px_rgba(208,2,27,0.2)]">
               <div className="border-l-4 border-primary pl-6">
                  <h3 className="text-black font-bold uppercase tracking-tight text-lg">Deposit Required</h3>
                  <p className="text-neutral-600 mt-1">A deposit of <span className="text-primary font-bold font-mono">$24,000</span> is pending for the "Website Redesign Project".</p>
               </div>
               <button className="bg-black text-white hover:bg-primary px-6 py-3 font-bold uppercase tracking-wider text-sm flex items-center gap-2 transition-colors">
                  <Download size={16} /> Process Payment
               </button>
            </div>
         </div>
      </div>

      {/* Right Sidebar - Activity */}
      <aside className="w-80 bg-surface border-l border-border flex flex-col">
         <div className="p-6 border-b border-border bg-background">
            <h3 className="text-xs font-bold uppercase tracking-widest text-white">Recent Activity</h3>
         </div>
         <div className="flex-1 p-6 overflow-y-auto">
            <div className="relative pl-4 border-l border-border space-y-8">
               {activityLog.map((act, i) => (
                  <div key={act.id} className="relative">
                     <div className={`absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full border-2 border-surface ${i === 0 ? 'bg-primary' : 'bg-white'}`}></div>
                     <p className="text-sm text-white leading-relaxed">
                        {act.text.split(act.highlight || '').map((part, idx) => (
                           <React.Fragment key={idx}>
                              {part}
                              {idx === 0 && act.highlight && <span className="font-bold underline decoration-1 underline-offset-2 hover:text-primary cursor-pointer">{act.highlight}</span>}
                           </React.Fragment>
                        ))}
                     </p>
                     <span className="text-xs text-textMuted uppercase font-bold tracking-wider mt-1 block">{act.time}</span>
                  </div>
               ))}
            </div>
         </div>
         <div className="p-6 bg-background border-t border-border">
            <label className="text-xs font-bold uppercase tracking-widest text-textMuted block mb-2">Log Note</label>
            <div className="flex">
               <input type="text" placeholder="Type here..." className="w-full bg-surface border border-border px-3 py-2 text-sm text-white focus:outline-none focus:border-primary" />
               <button className="bg-white text-black px-3 hover:bg-primary hover:text-white transition-colors"><ArrowRight size={16} /></button>
            </div>
         </div>
      </aside>
    </div>
  );
};

export default ClientView;