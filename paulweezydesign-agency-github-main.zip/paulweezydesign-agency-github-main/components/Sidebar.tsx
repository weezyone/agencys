import React from 'react';
import { ViewState } from '../types';
import { 
  LayoutDashboard, 
  FolderKanban, 
  Users, 
  BarChart3, 
  Settings, 
  HelpCircle, 
  LogOut,
  Plus
} from 'lucide-react';

interface SidebarProps {
  currentView: ViewState;
  onChangeView: (view: ViewState) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, onChangeView }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'projects', label: 'Projects', icon: FolderKanban },
    { id: 'clients', label: 'Clients', icon: Users },
    { id: 'reports', label: 'Reports', icon: BarChart3 },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <aside className="w-64 bg-background border-r border-border flex flex-col h-full shrink-0">
      <div className="p-6 border-b border-border flex items-center gap-3">
        <div className="w-8 h-8 bg-primary rounded-none flex items-center justify-center font-bold text-white">
          A
        </div>
        <span className="font-bold text-lg tracking-wide">AGENCYOS</span>
      </div>

      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {menuItems.map((item) => {
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onChangeView(item.id as ViewState)}
              className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium transition-colors ${
                isActive 
                  ? 'text-white bg-surfaceHighlight border-l-2 border-primary' 
                  : 'text-textMuted hover:text-white hover:bg-surfaceHighlight/50 border-l-2 border-transparent'
              }`}
            >
              <item.icon size={18} className={isActive ? 'text-primary' : 'text-textMuted'} />
              {item.label}
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-border space-y-4">
        <button className="w-full bg-primary hover:bg-primaryHover text-white py-2.5 px-4 text-sm font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-colors">
          <Plus size={16} />
          Add New
        </button>
        
        <div className="space-y-1">
            <button className="w-full flex items-center gap-3 px-4 py-2 text-sm font-medium text-textMuted hover:text-white transition-colors">
            <HelpCircle size={18} />
            Help Center
            </button>
            <button className="w-full flex items-center gap-3 px-4 py-2 text-sm font-medium text-textMuted hover:text-white transition-colors">
            <LogOut size={18} />
            Log Out
            </button>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;