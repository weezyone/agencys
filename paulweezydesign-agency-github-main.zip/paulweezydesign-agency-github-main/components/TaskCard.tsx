import React from 'react';
import { Lock, RotateCw, UserX } from 'lucide-react';
import { Task } from '../types';
import type { Member } from './projectConstants';

interface TaskCardProps {
  task: Task;
  assignee: Member | undefined;
  blockedBy: Task | null;
  isDragged: boolean;
  onDragStart: (e: React.DragEvent<HTMLDivElement>, taskId: string) => void;
  onClick: () => void;
}

const TaskCard: React.FC<TaskCardProps> = ({
  task,
  assignee,
  blockedBy,
  isDragged,
  onDragStart,
  onClick,
}) => (
  <div 
    draggable
    onDragStart={(e) => onDragStart(e, task.id)}
    onClick={onClick}
    className={`bg-surface border border-border p-4 hover:border-textMuted hover:shadow-[0_0_15px_rgba(255,255,255,0.05)] transition-all cursor-pointer group select-none relative z-10 
      ${isDragged ? 'opacity-40 rotate-2 scale-95' : ''}
      ${blockedBy ? 'border-red-900/50 bg-red-900/5' : ''}
    `}
  >
    <div className="flex justify-between items-start mb-3">
      <div className="flex-1 pr-2">
        <h4 className={`font-bold text-sm mb-1 ${task.status === 'done' ? 'line-through text-textMuted' : 'text-white'}`}>{task.title}</h4>
      </div>
      {assignee ? (
           <img src={assignee.avatar} className="w-6 h-6 rounded-full grayscale group-hover:grayscale-0 border border-transparent group-hover:border-white/20" alt={assignee.name} title={assignee.name} />
      ) : (
           <div className="w-6 h-6 rounded-full bg-surfaceHighlight border border-white/10 flex items-center justify-center" title="Unassigned">
               <UserX size={12} className="text-textMuted" />
           </div>
      )}
    </div>
    
    {blockedBy && (
      <div className="mb-3 flex items-center gap-1.5 text-xs text-red-400 font-medium bg-red-500/10 px-2 py-1.5 rounded border border-red-500/20" title={`Waiting for: ${blockedBy.title}`}>
        <Lock size={12} />
        <span className="truncate max-w-[150px]">Blocked by {blockedBy.title}</span>
      </div>
    )}

    <div className="flex items-center justify-between pt-3 border-t border-border mt-3">
       <span className={`text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 border ${
         task.priority === 'Critical' ? 'border-primary text-primary' :
         task.priority === 'High' ? 'border-orange-500 text-orange-500' :
         'border-textMuted text-textMuted'
       }`}>
         {task.priority === 'Critical' && task.dueDate === 'Tomorrow' ? 'Due Tomorrow' : task.priority === 'Critical' ? 'Critical' : task.priority}
       </span>
       
       <div className="flex items-center gap-3">
         {task.recurrence && (
             <div className="text-textMuted flex items-center" title={`Repeats every ${task.recurrence.interval} ${task.recurrence.frequency}`}>
                 <RotateCw size={12} />
             </div>
         )}
         <span className="text-xs text-textMuted">{task.status === 'done' ? `Completed ${task.dueDate}` : `Due: ${task.dueDate}`}</span>
       </div>
    </div>
  </div>
);

export default TaskCard;
