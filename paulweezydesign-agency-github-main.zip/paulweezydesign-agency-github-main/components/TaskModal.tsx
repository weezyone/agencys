import React from 'react';
import { X, Save, Trash2, AlertCircle, Link as LinkIcon, Copy, RotateCw, Calendar } from 'lucide-react';
import { Task } from '../types';
import type { Member } from './projectConstants';

interface TaskModalProps {
  editingTask: Task;
  tasks: Task[];
  members: Member[];
  errors: { title?: string; dueDate?: string };
  onSave: (e?: React.FormEvent) => void;
  onDelete: () => void;
  onClose: () => void;
  onTaskChange: (task: Task) => void;
  onErrorChange: (errors: { title?: string; dueDate?: string }) => void;
  onSaveAsTemplate: () => void;
  checkCycle: (sourceId: string, targetId: string, allTasks: Task[]) => boolean;
  toggleDependency: (targetTaskId: string) => void;
}

const TaskModal: React.FC<TaskModalProps> = ({
  editingTask,
  tasks,
  members,
  errors,
  onSave,
  onDelete,
  onClose,
  onTaskChange,
  onErrorChange,
  onSaveAsTemplate,
  checkCycle,
  toggleDependency,
}) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4" onClick={(e) => {
       if(e.target === e.currentTarget) {
           onClose();
       }
  }}>
    <form onSubmit={onSave} className="bg-surface border border-border w-full max-w-lg shadow-2xl animate-fade-in relative max-h-[90vh] flex flex-col">
      <div className="flex justify-between items-center p-6 border-b border-border bg-surfaceHighlight/20 shrink-0">
          <h3 className="text-lg font-bold text-white tracking-wide">Edit Task</h3>
          <div className="flex items-center gap-2">
              <button 
                  type="button" 
                  onClick={onSaveAsTemplate}
                  className="text-xs font-bold text-textMuted hover:text-primary uppercase tracking-wider flex items-center gap-1 px-2 py-1 hover:bg-surfaceHighlight rounded transition-colors mr-2"
                  title="Save as Template"
              >
                  <Copy size={14} /> Save as Template
              </button>
              <button type="button" onClick={onClose} className="text-textMuted hover:text-white transition-colors">
                  <X size={20} />
              </button>
          </div>
      </div>
      
      <div className="p-6 space-y-6 overflow-y-auto">
          {/* Title */}
          <div>
              <label className="block text-xs font-bold text-textMuted uppercase tracking-wider mb-2">Title</label>
              <input 
                  type="text" 
                  value={editingTask.title} 
                  onChange={(e) => {
                      onTaskChange({...editingTask, title: e.target.value});
                      if (errors.title) onErrorChange({...errors, title: undefined});
                  }}
                  className={`w-full bg-background border px-4 py-3 text-white focus:outline-none focus:border-primary text-sm font-medium transition-colors ${errors.title ? 'border-primary' : 'border-border'}`}
                  autoFocus
              />
              {errors.title && (
                  <div className="flex items-center gap-1 mt-1 text-primary text-xs font-bold">
                      <AlertCircle size={12} />
                      <span>{errors.title}</span>
                  </div>
              )}
          </div>

          {/* Priority & Status */}
          <div className="grid grid-cols-2 gap-4">
            <div>
                <label className="block text-xs font-bold text-textMuted uppercase tracking-wider mb-2">Priority</label>
                <div className="relative">
                    <select 
                        value={editingTask.priority}
                        onChange={(e) => onTaskChange({...editingTask, priority: e.target.value as any})}
                        className="w-full bg-background border border-border px-4 py-3 text-white focus:outline-none focus:border-primary text-sm font-medium appearance-none cursor-pointer"
                    >
                        <option value="Low">Low</option>
                        <option value="Medium">Medium</option>
                        <option value="High">High</option>
                        <option value="Critical">Critical</option>
                    </select>
                    <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-textMuted">
                        <svg width="10" height="6" viewBox="0 0 10 6" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 1L5 5L9 1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
                    </div>
                </div>
            </div>
            <div>
                <label className="block text-xs font-bold text-textMuted uppercase tracking-wider mb-2">Status</label>
                <div className="relative">
                    <select 
                        value={editingTask.status}
                        onChange={(e) => onTaskChange({...editingTask, status: e.target.value as any})}
                        className="w-full bg-background border border-border px-4 py-3 text-white focus:outline-none focus:border-primary text-sm font-medium appearance-none cursor-pointer"
                    >
                        <option value="backlog">Backlog</option>
                        <option value="in_progress">In Progress</option>
                        <option value="review">Review</option>
                        <option value="done">Done</option>
                    </select>
                    <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-textMuted">
                        <svg width="10" height="6" viewBox="0 0 10 6" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 1L5 5L9 1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
                    </div>
                </div>
            </div>
          </div>

          {/* Due Date & Assignee */}
          <div className="grid grid-cols-2 gap-4">
              <div>
                  <label className="block text-xs font-bold text-textMuted uppercase tracking-wider mb-2">Due Date</label>
                  <input 
                      type="text" 
                      value={editingTask.dueDate} 
                      onChange={(e) => {
                          onTaskChange({...editingTask, dueDate: e.target.value});
                          if (errors.dueDate) onErrorChange({...errors, dueDate: undefined});
                      }}
                      className={`w-full bg-background border px-4 py-3 text-white focus:outline-none focus:border-primary text-sm font-medium transition-colors ${errors.dueDate ? 'border-primary' : 'border-border'}`}
                  />
                  {errors.dueDate && (
                      <div className="flex items-center gap-1 mt-1 text-primary text-xs font-bold">
                          <AlertCircle size={12} />
                          <span>{errors.dueDate}</span>
                      </div>
                  )}
              </div>
              <div>
                  <label className="block text-xs font-bold text-textMuted uppercase tracking-wider mb-2">Assignee</label>
                  <div className="relative">
                      <select 
                          value={editingTask.assigneeId || ''}
                          onChange={(e) => onTaskChange({...editingTask, assigneeId: e.target.value})}
                          className="w-full bg-background border border-border px-4 py-3 text-white focus:outline-none focus:border-primary text-sm font-medium appearance-none cursor-pointer"
                      >
                          <option value="">Unassigned</option>
                          {members.map(m => (
                              <option key={m.id} value={m.id}>{m.name}</option>
                          ))}
                      </select>
                      <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-textMuted">
                          <svg width="10" height="6" viewBox="0 0 10 6" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 1L5 5L9 1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
                      </div>
                  </div>
              </div>
          </div>

          {/* Recurrence Section */}
          <div className="border-t border-border pt-6">
              <label className="flex items-center gap-2 text-xs font-bold text-textMuted uppercase tracking-wider mb-4">
                  <RotateCw size={14} /> Recurrence
              </label>
              
              <div className="bg-background border border-border rounded p-4">
                  <div className="flex items-center gap-3 mb-4">
                      <input 
                          type="checkbox" 
                          id="recurrence-toggle"
                          className="w-4 h-4 rounded border-border bg-surface text-primary focus:ring-primary"
                          checked={!!editingTask.recurrence}
                          onChange={(e) => {
                              if (e.target.checked) {
                                  onTaskChange({
                                      ...editingTask, 
                                      recurrence: { frequency: 'weekly', interval: 1 }
                                  });
                              } else {
                                  onTaskChange({
                                      ...editingTask, 
                                      recurrence: undefined
                                  });
                              }
                          }}
                      />
                      <label htmlFor="recurrence-toggle" className="text-sm font-medium text-white cursor-pointer select-none">
                          Make this a recurring task
                      </label>
                  </div>

                  {editingTask.recurrence && (
                      <div className="space-y-4 animate-fade-in">
                          <div className="flex gap-4">
                              <div className="w-24">
                                  <label className="block text-[10px] font-bold text-textMuted uppercase mb-1">Interval</label>
                                  <input 
                                      type="number" 
                                      min="1"
                                      value={editingTask.recurrence.interval}
                                      onChange={(e) => onTaskChange({
                                          ...editingTask,
                                          recurrence: { ...editingTask.recurrence!, interval: parseInt(e.target.value) || 1 }
                                      })}
                                      className="w-full bg-surface border border-border px-3 py-2 text-white text-sm focus:border-primary focus:outline-none"
                                  />
                              </div>
                              <div className="flex-1">
                                  <label className="block text-[10px] font-bold text-textMuted uppercase mb-1">Frequency</label>
                                  <select 
                                      value={editingTask.recurrence.frequency}
                                      onChange={(e) => onTaskChange({
                                          ...editingTask,
                                          recurrence: { ...editingTask.recurrence!, frequency: e.target.value as any }
                                      })}
                                      className="w-full bg-surface border border-border px-3 py-2 text-white text-sm focus:border-primary focus:outline-none appearance-none"
                                  >
                                      <option value="daily">Day(s)</option>
                                      <option value="weekly">Week(s)</option>
                                      <option value="monthly">Month(s)</option>
                                  </select>
                              </div>
                          </div>
                          
                          <div>
                              <label className="block text-[10px] font-bold text-textMuted uppercase mb-1">End Date (Optional)</label>
                              <div className="relative">
                                  <Calendar size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-textMuted" />
                                  <input 
                                      type="text" 
                                      placeholder="e.g. Dec 31, 2024"
                                      value={editingTask.recurrence.endDate || ''}
                                      onChange={(e) => onTaskChange({
                                          ...editingTask,
                                          recurrence: { ...editingTask.recurrence!, endDate: e.target.value }
                                      })}
                                      className="w-full bg-surface border border-border pl-9 pr-3 py-2 text-white text-sm focus:border-primary focus:outline-none"
                                  />
                              </div>
                          </div>
                          
                          <div className="text-xs text-textMuted italic bg-surfaceHighlight/20 p-2 rounded border border-white/5">
                              Summary: Repeats every {editingTask.recurrence.interval} {editingTask.recurrence.frequency.replace('ly', '')}(s)
                              {editingTask.recurrence.endDate ? ` until ${editingTask.recurrence.endDate}` : ' forever'}.
                          </div>
                      </div>
                  )}
              </div>
          </div>

          {/* Dependencies Section */}
          <div className="border-t border-border pt-6">
              <label className="flex items-center gap-2 text-xs font-bold text-textMuted uppercase tracking-wider mb-4">
                  <LinkIcon size={14} /> Dependencies
              </label>
              <div className="bg-background border border-border rounded max-h-40 overflow-y-auto p-2 space-y-1">
                  {tasks.filter(t => t.id !== editingTask.id).map(task => {
                      const isDependent = editingTask.dependencies?.includes(task.id);
                      const createsCycle = checkCycle(editingTask.id, task.id, tasks);
                      const disabled = !isDependent && createsCycle;
                      
                      return (
                          <label key={task.id} className={`flex items-center gap-3 p-2 rounded cursor-pointer transition-colors ${disabled ? 'opacity-30 cursor-not-allowed' : 'hover:bg-surfaceHighlight'}`}>
                              <div className={`w-4 h-4 border flex items-center justify-center rounded-sm transition-colors ${isDependent ? 'bg-primary border-primary' : 'border-textMuted bg-transparent'}`}>
                                  {isDependent && <svg width="10" height="8" viewBox="0 0 10 8" fill="none"><path d="M1 4L3.5 6.5L9 1" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>}
                              </div>
                              <input 
                                  type="checkbox" 
                                  className="hidden" 
                                  checked={!!isDependent}
                                  disabled={disabled}
                                  onChange={() => toggleDependency(task.id)}
                              />
                              <span className="text-sm font-medium text-white truncate flex-1">{task.title}</span>
                              <span className={`text-[10px] font-bold uppercase tracking-wider px-1 rounded ${
                                  task.status === 'done' ? 'text-green-500 bg-green-500/10' : 'text-textMuted bg-surface'
                              }`}>
                                  {task.status.replace('_', ' ')}
                              </span>
                          </label>
                      );
                  })}
                  {tasks.length <= 1 && (
                      <div className="text-center py-4 text-xs text-textMuted">No other tasks available</div>
                  )}
              </div>
              <p className="text-[10px] text-textMuted mt-2">
                  Select tasks that must be completed before this one.
              </p>
          </div>
      </div>

      <div className="p-6 border-t border-border flex justify-between items-center bg-surfaceHighlight/10 shrink-0">
          <button type="button" onClick={onDelete} className="px-4 py-2 text-sm font-bold text-red-500 hover:text-red-400 hover:bg-red-500/10 transition-colors flex items-center gap-2">
              <Trash2 size={16} /> Delete
          </button>
          <div className="flex gap-3">
              <button type="button" onClick={onClose} className="px-5 py-2.5 text-sm font-bold text-textMuted hover:text-white hover:bg-surfaceHighlight transition-colors">Cancel</button>
              <button type="submit" className="px-5 py-2.5 bg-primary hover:bg-primaryHover text-white text-sm font-bold flex items-center gap-2 transition-colors shadow-lg shadow-primary/20">
                  <Save size={16} /> Save Changes
              </button>
          </div>
      </div>
    </form>
  </div>
);

export default TaskModal;
