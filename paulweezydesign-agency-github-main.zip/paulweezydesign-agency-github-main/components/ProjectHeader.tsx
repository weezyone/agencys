import React from 'react';
import { Plus, Clock, FileText } from 'lucide-react';
import type { Member } from './projectConstants';

interface ProjectHeaderProps {
  members: Member[];
  completedTasks: number;
  inProgressTasks: number;
  backlogTasks: number;
  progressPercentage: number;
  circumference: number;
  dashOffset: number;
  onOpenTemplates: () => void;
}

const ProjectHeader: React.FC<ProjectHeaderProps> = ({
  members,
  completedTasks,
  inProgressTasks,
  backlogTasks,
  progressPercentage,
  circumference,
  dashOffset,
  onOpenTemplates,
}) => (
  <>
    {/* Header */}
    <header className="px-8 py-6 border-b border-border bg-background sticky top-0 z-10">
      <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-textMuted mb-2">
        <span>Projects</span> / <span className="text-white">Phoenix</span>
      </div>
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-4xl font-extrabold text-white tracking-tight mb-2">Project Phoenix</h1>
          <div className="flex items-center gap-3">
            <span className="text-textMuted">Client: <span className="text-white">Innovate Inc.</span></span>
            <span className="px-2 py-0.5 border border-green-500/50 text-green-500 text-xs font-bold uppercase tracking-wider bg-green-500/10">On Track</span>
          </div>
        </div>
        <div className="flex items-center gap-4">
           <div className="flex -space-x-2 mr-4">
             {members.map(m => (
               <img key={m.id} src={m.avatar} className="w-8 h-8 rounded-full border-2 border-background" alt={m.name} title={m.name} />
             ))}
             <div className="w-8 h-8 rounded-full border-2 border-background bg-surfaceHighlight flex items-center justify-center text-xs font-bold text-white">+2</div>
           </div>
           <button onClick={onOpenTemplates} className="px-4 py-2 border border-border text-white text-sm font-bold uppercase tracking-wider hover:bg-surfaceHighlight transition-colors flex items-center gap-2">
              <FileText size={16} /> Templates
           </button>
           <button className="px-4 py-2 bg-primary text-white text-sm font-bold uppercase tracking-wider hover:bg-primaryHover transition-colors flex items-center gap-2">
             <Plus size={16} /> Add Task
           </button>
        </div>
      </div>
    </header>

    {/* Stats Bar */}
    <div className="grid grid-cols-1 md:grid-cols-3 border-b border-border bg-surface/50">
      <div className="p-6 border-r border-border group hover:bg-surfaceHighlight/50 transition-colors">
        <div className="flex justify-between items-start mb-4">
          <span className="text-xs font-bold uppercase tracking-widest text-textMuted">Budget</span>
          <span className="text-white font-mono">$</span>
        </div>
        <div className="flex items-baseline gap-2 mb-2">
          <span className="text-3xl font-bold text-white">$40,150</span>
          <span className="text-sm text-textMuted">/ $50k</span>
        </div>
        <div className="w-full bg-border h-1 mb-2">
          <div className="bg-primary h-1" style={{width: '80%'}}></div>
        </div>
        <span className="text-xs text-primary font-medium">80% utilized. Needs review.</span>
      </div>

      <div className="p-6 border-r border-border group hover:bg-surfaceHighlight/50 transition-colors">
        <div className="flex justify-between items-start mb-4">
          <span className="text-xs font-bold uppercase tracking-widest text-textMuted">Sprint Timeline</span>
          <Clock size={16} className="text-textMuted" />
        </div>
        <div className="flex items-baseline gap-2 mb-2">
          <span className="text-3xl font-bold text-white">12 Days</span>
          <span className="text-sm text-textMuted">Remaining</span>
        </div>
        <div className="w-full bg-border h-1 mb-2">
          <div className="bg-white h-1" style={{width: '60%'}}></div>
        </div>
        <span className="text-xs text-textMuted">Next Deadline: UI Design Sign-off</span>
      </div>

      <div className="p-6 group hover:bg-surfaceHighlight/50 transition-colors flex items-center justify-between">
         <div>
            <div className="text-xs font-bold uppercase tracking-widest text-textMuted mb-4">Completion</div>
            <div className="flex flex-col gap-1">
               <div className="flex items-center gap-2 text-xs text-textMuted"><span className="w-2 h-2 bg-green-500 rounded-sm"></span> {completedTasks} Done</div>
               <div className="flex items-center gap-2 text-xs text-textMuted"><span className="w-2 h-2 bg-yellow-500 rounded-sm"></span> {inProgressTasks} In Progress</div>
               <div className="flex items-center gap-2 text-xs text-textMuted"><span className="w-2 h-2 bg-primary rounded-sm"></span> {backlogTasks} To Do</div>
            </div>
         </div>
         <div className="relative w-20 h-20 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90">
              <circle cx="40" cy="40" r="32" stroke="#262626" strokeWidth="6" fill="transparent" />
              <circle cx="40" cy="40" r="32" stroke="#D0021B" strokeWidth="6" fill="transparent" strokeDasharray={circumference} strokeDashoffset={dashOffset} strokeLinecap="round" className="transition-all duration-500 ease-in-out" />
            </svg>
            <span className="absolute text-xl font-bold text-white">{progressPercentage}%</span>
         </div>
      </div>
    </div>
  </>
);

export default ProjectHeader;
