import React, { useRef, useEffect } from 'react';
import { Search, Filter, Check, UserX, ArrowUpDown, XCircle } from 'lucide-react';
import type { Member } from './projectConstants';

export interface FilterState {
  priorities: string[];
  assignees: string[];
  dateRange: 'all' | 'overdue' | 'next7' | 'next30';
}

export type SortBy = 'default' | 'priority' | 'date';

interface ProjectFiltersProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  filters: FilterState;
  onFiltersChange: (filters: FilterState) => void;
  sortBy: SortBy;
  onSortChange: (sort: SortBy) => void;
  activeFilterCount: number;
  members: Member[];
  isFilterOpen: boolean;
  onFilterOpenChange: (open: boolean) => void;
}

const ProjectFilters: React.FC<ProjectFiltersProps> = ({
  searchQuery,
  onSearchChange,
  filters,
  onFiltersChange,
  sortBy,
  onSortChange,
  activeFilterCount,
  members,
  isFilterOpen,
  onFilterOpenChange,
}) => {
  const filterRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (filterRef.current && !filterRef.current.contains(e.target as Node)) {
        onFilterOpenChange(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [onFilterOpenChange]);

  return (
    <>
      {/* Navigation & Search */}
      <div className="px-8 border-b border-border flex justify-between items-center bg-background z-20">
        <div className="flex gap-8">
          {['Kanban Board', 'Timeline', 'Resources'].map((tab, i) => (
            <button 
              key={tab} 
              className={`py-4 text-sm font-bold uppercase tracking-wider border-b-2 transition-colors ${i === 0 ? 'text-primary border-primary' : 'text-textMuted border-transparent hover:text-white'}`}
            >
              {tab}
            </button>
          ))}
        </div>
        <div className="flex gap-3 relative" ref={filterRef}>
             <div className="relative">
                 <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-textMuted" size={14} />
                 <input 
                     type="text" 
                     placeholder="Search tasks..." 
                     value={searchQuery}
                     onChange={(e) => onSearchChange(e.target.value)}
                     className="bg-surface border border-border pl-9 pr-4 py-1.5 text-sm text-white focus:outline-none focus:border-primary w-64 transition-all focus:w-80 placeholder:text-textMuted"
                 />
             </div>
             
             <button 
                onClick={() => onFilterOpenChange(!isFilterOpen)}
                className={`px-3 py-1.5 border flex items-center gap-2 text-xs font-bold uppercase tracking-wider transition-colors relative
                    ${isFilterOpen || activeFilterCount > 0 ? 'border-primary text-white bg-primary/10' : 'border-border text-textMuted hover:border-textMuted hover:text-white'}`}
             >
                <Filter size={14} />
                Filters
                {activeFilterCount > 0 && (
                    <span className="bg-primary text-white text-[9px] w-4 h-4 rounded-full flex items-center justify-center ml-1">
                        {activeFilterCount}
                    </span>
                )}
             </button>

             {/* Filter Popover */}
             {isFilterOpen && (
                <div className="absolute top-full right-0 mt-2 w-80 bg-surface border border-border shadow-2xl rounded p-5 z-50 animate-fade-in">
                    {/* Sort By */}
                    <div className="mb-5 pb-5 border-b border-border">
                        <h4 className="text-xs font-bold text-textMuted uppercase tracking-wider mb-3 flex items-center gap-2">
                           <ArrowUpDown size={12} /> Sort By
                        </h4>
                        <div className="flex gap-2">
                           {[
                               { id: 'default', label: 'Default' },
                               { id: 'priority', label: 'Priority' },
                               { id: 'date', label: 'Due Date' },
                           ].map(opt => (
                               <button
                                   key={opt.id}
                                   onClick={() => onSortChange(opt.id as SortBy)}
                                   className={`px-2 py-1 text-[10px] font-bold uppercase tracking-wider border rounded transition-all
                                       ${sortBy === opt.id
                                           ? 'bg-white text-black border-white' 
                                           : 'bg-transparent text-textMuted border-border hover:border-textMuted'}`}
                               >
                                   {opt.label}
                               </button>
                           ))}
                        </div>
                    </div>

                    {/* Priority Filter */}
                    <div className="mb-5">
                        <h4 className="text-xs font-bold text-textMuted uppercase tracking-wider mb-3">Priority</h4>
                        <div className="flex flex-wrap gap-2">
                            {['Critical', 'High', 'Medium', 'Low'].map(p => (
                                <button
                                    key={p}
                                    onClick={() => {
                                        const newPriorities = filters.priorities.includes(p) 
                                            ? filters.priorities.filter(item => item !== p)
                                            : [...filters.priorities, p];
                                        onFiltersChange({...filters, priorities: newPriorities});
                                    }}
                                    className={`px-2 py-1 text-[10px] font-bold uppercase tracking-wider border rounded transition-all
                                        ${filters.priorities.includes(p) 
                                            ? 'bg-white text-black border-white' 
                                            : 'bg-transparent text-textMuted border-border hover:border-textMuted'}`}
                                >
                                    {p}
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Assignee Filter */}
                    <div className="mb-5">
                        <h4 className="text-xs font-bold text-textMuted uppercase tracking-wider mb-3">Assignee</h4>
                        <div className="flex gap-2 flex-wrap">
                            <button
                                onClick={() => {
                                    const newAssignees = filters.assignees.includes('unassigned')
                                        ? filters.assignees.filter(id => id !== 'unassigned')
                                        : [...filters.assignees, 'unassigned'];
                                    onFiltersChange({...filters, assignees: newAssignees});
                                }}
                                className={`relative w-8 h-8 rounded-full border-2 transition-all flex items-center justify-center
                                    ${filters.assignees.includes('unassigned') ? 'border-primary bg-primary/20 text-white' : 'border-border text-textMuted hover:border-white hover:text-white'}`}
                                title="Unassigned"
                            >
                                <UserX size={14} />
                            </button>
                            {members.map(m => (
                                <button
                                    key={m.id}
                                    onClick={() => {
                                        const newAssignees = filters.assignees.includes(m.id)
                                            ? filters.assignees.filter(id => id !== m.id)
                                            : [...filters.assignees, m.id];
                                        onFiltersChange({...filters, assignees: newAssignees});
                                    }}
                                    className={`relative w-8 h-8 rounded-full border-2 transition-all overflow-hidden group
                                        ${filters.assignees.includes(m.id) ? 'border-primary scale-110' : 'border-transparent opacity-60 hover:opacity-100'}`}
                                    title={m.name}
                                >
                                    <img src={m.avatar} alt={m.name} className="w-full h-full" />
                                    {filters.assignees.includes(m.id) && (
                                        <div className="absolute inset-0 bg-primary/40 flex items-center justify-center">
                                            <Check size={12} className="text-white" />
                                        </div>
                                    )}
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Date Range Filter */}
                    <div className="mb-5">
                        <h4 className="text-xs font-bold text-textMuted uppercase tracking-wider mb-3">Due Date</h4>
                        <div className="grid grid-cols-2 gap-2">
                             {[
                                { id: 'all', label: 'Any Date' },
                                { id: 'overdue', label: 'Overdue' },
                                { id: 'next7', label: 'Next 7 Days' },
                                { id: 'next30', label: 'Next 30 Days' }
                             ].map(opt => (
                                 <button
                                    key={opt.id}
                                    onClick={() => onFiltersChange({...filters, dateRange: opt.id as FilterState['dateRange']})}
                                    className={`text-left px-3 py-2 text-xs font-medium border rounded transition-colors
                                        ${filters.dateRange === opt.id 
                                            ? 'bg-primary/20 border-primary text-white' 
                                            : 'bg-transparent border-border text-textMuted hover:text-white'}`}
                                 >
                                     {opt.label}
                                 </button>
                             ))}
                        </div>
                    </div>

                    <div className="pt-4 border-t border-border flex justify-end">
                        <button 
                            onClick={() => {
                                onFiltersChange({ priorities: [], assignees: [], dateRange: 'all' });
                                onSortChange('default');
                            }}
                            className="text-xs text-textMuted hover:text-white underline"
                        >
                            Clear All
                        </button>
                    </div>
                </div>
             )}
        </div>
      </div>
      
      {/* Active Filters Bar */}
      {activeFilterCount > 0 && (
          <div className="px-8 py-3 border-b border-border flex flex-wrap gap-2 items-center bg-surfaceHighlight/10 animate-fade-in">
              <span className="text-[10px] font-bold uppercase tracking-wider text-textMuted mr-2 flex items-center gap-1">
                  <Filter size={10} /> Active Filters:
              </span>
              
              {/* Sort Chip */}
              {sortBy !== 'default' && (
                  <button 
                    onClick={() => onSortChange('default')}
                    className="flex items-center gap-1 px-2 py-1 rounded bg-surface border border-border text-[10px] font-medium text-white hover:border-red-500 hover:text-red-500 group transition-colors"
                  >
                      <span>Sort: {sortBy === 'priority' ? 'Priority' : 'Due Date'}</span>
                      <XCircle size={10} className="text-textMuted group-hover:text-red-500" />
                  </button>
              )}

              {/* Priority Chips */}
              {filters.priorities.map(p => (
                  <button 
                    key={p}
                    onClick={() => onFiltersChange({...filters, priorities: filters.priorities.filter(i => i !== p)})}
                    className="flex items-center gap-1 px-2 py-1 rounded bg-surface border border-border text-[10px] font-medium text-white hover:border-red-500 hover:text-red-500 group transition-colors"
                  >
                      <span>{p}</span>
                      <XCircle size={10} className="text-textMuted group-hover:text-red-500" />
                  </button>
              ))}

              {/* Assignee Chips */}
              {filters.assignees.map(id => {
                  const member = members.find(m => m.id === id);
                  const label = id === 'unassigned' ? 'Unassigned' : member?.name || 'Unknown';
                  return (
                      <button 
                        key={id}
                        onClick={() => onFiltersChange({...filters, assignees: filters.assignees.filter(i => i !== id)})}
                        className="flex items-center gap-1 px-2 py-1 rounded bg-surface border border-border text-[10px] font-medium text-white hover:border-red-500 hover:text-red-500 group transition-colors"
                      >
                          <span>Assigned: {label}</span>
                          <XCircle size={10} className="text-textMuted group-hover:text-red-500" />
                      </button>
                  );
              })}

              {/* Date Chip */}
              {filters.dateRange !== 'all' && (
                  <button 
                    onClick={() => onFiltersChange({...filters, dateRange: 'all'})}
                    className="flex items-center gap-1 px-2 py-1 rounded bg-surface border border-border text-[10px] font-medium text-white hover:border-red-500 hover:text-red-500 group transition-colors"
                  >
                      <span>Date: {
                          filters.dateRange === 'overdue' ? 'Overdue' : 
                          filters.dateRange === 'next7' ? 'Next 7 Days' : 'Next 30 Days'
                      }</span>
                      <XCircle size={10} className="text-textMuted group-hover:text-red-500" />
                  </button>
              )}
              
              <button 
                onClick={() => {
                    onFiltersChange({ priorities: [], assignees: [], dateRange: 'all' });
                    onSortChange('default');
                }}
                className="ml-auto text-[10px] text-primary hover:underline font-bold"
              >
                  Clear All
              </button>
          </div>
      )}
    </>
  );
};

export default ProjectFilters;
