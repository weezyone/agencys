export const MEMBERS = [
  { id: '1', name: 'Alex', avatar: 'https://picsum.photos/32/32?random=1' },
  { id: '2', name: 'Sarah', avatar: 'https://picsum.photos/32/32?random=2' },
  { id: '3', name: 'Mike', avatar: 'https://picsum.photos/32/32?random=3' },
];

export type Member = (typeof MEMBERS)[number];
