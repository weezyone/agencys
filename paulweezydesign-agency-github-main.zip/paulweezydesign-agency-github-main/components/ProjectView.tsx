import React, { useState } from 'react';
import { Task, TaskTemplate } from '../types';
import { MEMBERS } from './projectConstants';
import ProjectHeader from './ProjectHeader';
import ProjectFilters, { type FilterState, type SortBy } from './ProjectFilters';
import ProjectBoard from './ProjectBoard';
import TaskModal from './TaskModal';
import TemplatesModal from './TemplatesModal';

const ProjectView: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([
    { 
      id: '1', 
      title: 'User Authentication Flow', 
      priority: 'High', 
      dueDate: 'Oct 25', 
      status: 'backlog',
      assigneeId: '1',
      recurrence: { frequency: 'weekly', interval: 1 } 
    },
    { id: '2', title: 'Setup Staging Environment', priority: 'Medium', dueDate: 'Nov 1', status: 'backlog', dependencies: ['1'], assigneeId: '2' },
    { id: '3', title: 'Dashboard UI Design', priority: 'Critical', dueDate: 'Tomorrow', status: 'in_progress', assigneeId: '1' },
    { id: '4', title: 'API Integration with Stripe', priority: 'High', dueDate: 'Oct 28', status: 'in_progress', dependencies: ['2'], assigneeId: '3' },
    { id: '5', title: 'Landing Page Copywriting', priority: 'Low', dueDate: 'Oct 20', status: 'review', assigneeId: '2' },
    { id: '6', title: 'Project Kick-off Meeting', priority: 'Medium', dueDate: 'Oct 15', status: 'done', assigneeId: '3' },
  ]);

  const [templates, setTemplates] = useState<TaskTemplate[]>([
    { id: 't1', title: 'Standard Bug Report', priority: 'High' },
    { id: 't2', title: 'New Feature Spec', priority: 'Medium' },
    { id: 't3', title: 'Client Feedback Review', priority: 'Low' },
  ]);

  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [isTemplatesModalOpen, setIsTemplatesModalOpen] = useState(false);
  const [draggedTaskId, setDraggedTaskId] = useState<string | null>(null);
  const [errors, setErrors] = useState<{title?: string; dueDate?: string}>({});
  
  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  
  const [filters, setFilters] = useState<FilterState>({
    priorities: [],
    assignees: [],
    dateRange: 'all'
  });
  
  const [sortBy, setSortBy] = useState<SortBy>('default');

  // New Template Form State
  const [newTemplateTitle, setNewTemplateTitle] = useState('');
  const [newTemplatePriority, setNewTemplatePriority] = useState<'High' | 'Medium' | 'Low' | 'Critical'>('Medium');

  const columns = [
    { id: 'backlog', label: 'Backlog', count: tasks.filter(t => t.status === 'backlog').length },
    { id: 'in_progress', label: 'In Progress', count: tasks.filter(t => t.status === 'in_progress').length },
    { id: 'review', label: 'In Review', count: tasks.filter(t => t.status === 'review').length },
    { id: 'done', label: 'Done', count: tasks.filter(t => t.status === 'done').length },
  ];

  // --- Validation & Save ---
  const validate = () => {
    const newErrors: {title?: string; dueDate?: string} = {};
    if (!editingTask?.title.trim()) {
        newErrors.title = 'Task title is required';
    }
    if (!editingTask?.dueDate.trim()) {
        newErrors.dueDate = 'Due date is required';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (editingTask) {
        if (validate()) {
            setTasks(tasks.map(t => t.id === editingTask.id ? editingTask : t));
            setEditingTask(null);
            setErrors({});
        }
    }
  };
  
  const handleDelete = () => {
    if (editingTask) {
      setTasks(tasks.filter(t => t.id !== editingTask.id));
      setEditingTask(null);
      setErrors({});
    }
  };

  // --- Template Handlers ---
  const handleCreateTemplate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTemplateTitle.trim()) return;
    const newTemplate: TaskTemplate = {
        id: Date.now().toString(),
        title: newTemplateTitle,
        priority: newTemplatePriority
    };
    setTemplates([...templates, newTemplate]);
    setNewTemplateTitle('');
  };

  const handleDeleteTemplate = (id: string) => {
    setTemplates(templates.filter(t => t.id !== id));
  };

  const handleUseTemplate = (template: TaskTemplate) => {
    const newTask: Task = {
        id: Date.now().toString(),
        title: template.title,
        priority: template.priority,
        dueDate: 'TBD',
        status: 'backlog'
    };
    setTasks([...tasks, newTask]);
    setIsTemplatesModalOpen(false);
  };

  const saveCurrentTaskAsTemplate = () => {
    if (editingTask && editingTask.title) {
        const newTemplate: TaskTemplate = {
            id: Date.now().toString(),
            title: editingTask.title,
            priority: editingTask.priority
        };
        setTemplates([...templates, newTemplate]);
    }
  };

  // --- Drag & Drop ---
  const handleDragStart = (e: React.DragEvent<HTMLDivElement>, taskId: string) => {
    setDraggedTaskId(taskId);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault(); 
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>, status: Task['status']) => {
    e.preventDefault();
    if (draggedTaskId) {
      setTasks(tasks.map(t => 
        t.id === draggedTaskId ? { ...t, status } : t
      ));
      setDraggedTaskId(null);
    }
  };

  // --- Close modals on Escape ---
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape') {
            if (editingTask) {
                setEditingTask(null);
                setErrors({});
            } else if (isTemplatesModalOpen) {
                setIsTemplatesModalOpen(false);
            } else if (isFilterOpen) {
                setIsFilterOpen(false);
            }
        }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [editingTask, isTemplatesModalOpen, isFilterOpen]);

  // --- Dependency Logic ---
  const getBlockingTask = (task: Task) => {
    if (!task.dependencies || task.dependencies.length === 0) return null;
    return tasks.find(t => task.dependencies?.includes(t.id) && t.status !== 'done') || null;
  };

  const checkCycle = (sourceId: string, targetId: string, allTasks: Task[]) => {
    const visited = new Set<string>();
    const stack = [targetId];
    
    while(stack.length > 0) {
        const currentId = stack.pop()!;
        if (currentId === sourceId) return true;
        if (!visited.has(currentId)) {
            visited.add(currentId);
            const currentTask = allTasks.find(t => t.id === currentId);
            if (currentTask && currentTask.dependencies) {
                stack.push(...currentTask.dependencies);
            }
        }
    }
    return false;
  };

  const toggleDependency = (targetTaskId: string) => {
    if (!editingTask) return;
    const currentDeps = editingTask.dependencies || [];
    let newDeps;
    
    if (currentDeps.includes(targetTaskId)) {
        newDeps = currentDeps.filter(id => id !== targetTaskId);
    } else {
        newDeps = [...currentDeps, targetTaskId];
    }
    
    setEditingTask({ ...editingTask, dependencies: newDeps });
  };

  // --- Filtering Logic ---
  const parseTaskDate = (dateStr: string): Date | null => {
    const now = new Date();
    const currentYear = now.getFullYear();
    
    if (dateStr.toLowerCase() === 'tomorrow') {
      const d = new Date();
      d.setDate(d.getDate() + 1);
      return d;
    }
    if (dateStr.toLowerCase() === 'tbd') return null;
    
    const parsed = new Date(`${dateStr} ${currentYear}`);
    return isNaN(parsed.getTime()) ? null : parsed;
  };

  const isDateInFilterRange = (dateStr: string, filter: string) => {
    if (filter === 'all') return true;
    
    const taskDate = parseTaskDate(dateStr);
    if (!taskDate) return false;

    const now = new Date();
    now.setHours(0,0,0,0);
    taskDate.setHours(0,0,0,0);

    const diffTime = taskDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (filter === 'overdue') return diffDays < 0;
    if (filter === 'next7') return diffDays >= 0 && diffDays <= 7;
    if (filter === 'next30') return diffDays >= 0 && diffDays <= 30;
    return true;
  };

  const getPriorityWeight = (p: string) => {
    switch (p) {
      case 'Critical': return 4;
      case 'High': return 3;
      case 'Medium': return 2;
      case 'Low': return 1;
      default: return 0;
    }
  };

  const filteredTasks = tasks.filter(t => {
    const matchesSearch = t.title.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesPriority = filters.priorities.length === 0 || filters.priorities.includes(t.priority);
    
    const matchesAssignee = filters.assignees.length === 0 || 
        (filters.assignees.includes('unassigned') && !t.assigneeId) ||
        (t.assigneeId && filters.assignees.includes(t.assigneeId));
    
    const matchesDate = isDateInFilterRange(t.dueDate, filters.dateRange);

    return matchesSearch && matchesPriority && matchesAssignee && matchesDate;
  }).sort((a, b) => {
    if (sortBy === 'priority') {
        return getPriorityWeight(b.priority) - getPriorityWeight(a.priority);
    }
    if (sortBy === 'date') {
        const dateA = parseTaskDate(a.dueDate);
        const dateB = parseTaskDate(b.dueDate);
        if (!dateA) return 1;
        if (!dateB) return -1;
        return dateA.getTime() - dateB.getTime();
    }
    return 0;
  });

  const activeFilterCount = 
    filters.priorities.length + 
    filters.assignees.length + 
    (filters.dateRange !== 'all' ? 1 : 0) +
    (sortBy !== 'default' ? 1 : 0);

  // --- Calculations ---
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(t => t.status === 'done').length;
  const inProgressTasks = tasks.filter(t => t.status === 'in_progress' || t.status === 'review').length;
  const backlogTasks = tasks.filter(t => t.status === 'backlog').length;
  const progressPercentage = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
  
  const circumference = 201; 
  const dashOffset = circumference - (progressPercentage / 100) * circumference;

  return (
    <div className="flex flex-col h-full bg-background animate-fade-in relative">
      <ProjectHeader
        members={MEMBERS}
        completedTasks={completedTasks}
        inProgressTasks={inProgressTasks}
        backlogTasks={backlogTasks}
        progressPercentage={progressPercentage}
        circumference={circumference}
        dashOffset={dashOffset}
        onOpenTemplates={() => setIsTemplatesModalOpen(true)}
      />

      <ProjectFilters
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        filters={filters}
        onFiltersChange={setFilters}
        sortBy={sortBy}
        onSortChange={setSortBy}
        activeFilterCount={activeFilterCount}
        members={MEMBERS}
        isFilterOpen={isFilterOpen}
        onFilterOpenChange={setIsFilterOpen}
      />

      <ProjectBoard
        columns={columns}
        filteredTasks={filteredTasks}
        draggedTaskId={draggedTaskId}
        searchQuery={searchQuery}
        activeFilterCount={activeFilterCount}
        onDragStart={handleDragStart}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        onTaskClick={(task) => {
            setEditingTask(task);
            setErrors({});
        }}
        members={MEMBERS}
        getBlockingTask={getBlockingTask}
      />

      {/* Templates Modal */}
      {isTemplatesModalOpen && (
        <TemplatesModal
          templates={templates}
          onClose={() => setIsTemplatesModalOpen(false)}
          onUseTemplate={handleUseTemplate}
          onDeleteTemplate={handleDeleteTemplate}
          onCreateTemplate={handleCreateTemplate}
          newTemplateTitle={newTemplateTitle}
          onNewTemplateTitleChange={setNewTemplateTitle}
          newTemplatePriority={newTemplatePriority}
          onNewTemplatePriorityChange={setNewTemplatePriority}
        />
      )}

      {/* Edit Task Modal */}
      {editingTask && (
        <TaskModal
          editingTask={editingTask}
          tasks={tasks}
          members={MEMBERS}
          errors={errors}
          onSave={handleSave}
          onDelete={handleDelete}
          onClose={() => {
              setEditingTask(null);
              setErrors({});
          }}
          onTaskChange={setEditingTask}
          onErrorChange={setErrors}
          onSaveAsTemplate={saveCurrentTaskAsTemplate}
          checkCycle={checkCycle}
          toggleDependency={toggleDependency}
        />
      )}
    </div>
  );
};

export default ProjectView;
