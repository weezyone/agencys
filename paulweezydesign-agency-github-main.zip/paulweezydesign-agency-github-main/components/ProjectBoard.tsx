import React from 'react';
import { Task } from '../types';
import type { Member } from './projectConstants';
import TaskCard from './TaskCard';

interface Column {
  id: string;
  label: string;
  count: number;
}

interface ProjectBoardProps {
  columns: Column[];
  filteredTasks: Task[];
  draggedTaskId: string | null;
  searchQuery: string;
  activeFilterCount: number;
  onDragStart: (e: React.DragEvent<HTMLDivElement>, taskId: string) => void;
  onDragOver: (e: React.DragEvent<HTMLDivElement>) => void;
  onDrop: (e: React.DragEvent<HTMLDivElement>, status: Task['status']) => void;
  onTaskClick: (task: Task) => void;
  members: Member[];
  getBlockingTask: (task: Task) => Task | null;
}

const ProjectBoard: React.FC<ProjectBoardProps> = ({
  columns,
  filteredTasks,
  draggedTaskId,
  searchQuery,
  activeFilterCount,
  onDragStart,
  onDragOver,
  onDrop,
  onTaskClick,
  members,
  getBlockingTask,
}) => (
  <div className="flex-1 overflow-x-auto p-8">
    <div className="flex gap-6 min-w-[1200px]">
      {columns.map(col => (
        <div 
          key={col.id} 
          className="flex-1 min-w-[280px] flex flex-col"
          onDragOver={onDragOver}
          onDrop={(e) => onDrop(e, col.id as Task['status'])}
        >
          <div className="flex justify-between items-center mb-4 pb-2 border-b border-border">
            <h3 className="text-xs font-bold uppercase tracking-widest text-textMuted">{col.label}</h3>
            <span className="text-xs text-textMuted">{
              filteredTasks.filter(t => t.status === col.id).length
            }</span>
          </div>
          
          <div className={`space-y-4 flex-1 rounded-lg transition-all ${draggedTaskId ? 'bg-surfaceHighlight/10 border-2 border-dashed border-border/40 p-2 -m-2' : ''}`}>
            {filteredTasks.filter(t => t.status === col.id).map(task => {
              const blockedBy = getBlockingTask(task);
              const assignee = members.find(m => m.id === task.assigneeId);
              
              return (
                <TaskCard
                  key={task.id}
                  task={task}
                  assignee={assignee}
                  blockedBy={blockedBy}
                  isDragged={draggedTaskId === task.id}
                  onDragStart={onDragStart}
                  onClick={() => onTaskClick(task)}
                />
              );
            })}
            {filteredTasks.filter(t => t.status === col.id).length === 0 && (
               <div className="h-24 border-2 border-dashed border-border/30 rounded flex items-center justify-center text-textMuted text-xs uppercase tracking-widest opacity-50">
                  {searchQuery || activeFilterCount > 0 ? 'No matches' : 'Drop here'}
               </div>
            )}
          </div>
        </div>
      ))}
    </div>
  </div>
);

export default ProjectBoard;
