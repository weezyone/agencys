<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://github.com/user-attachments/assets/0aa67016-6eaf-458a-adb2-6e31a0763ed6" />
</div>

# AgencyOS — Paulweezydesign Agency

> Internal operations platform for managing projects, clients, proposals, and tasks.

## Overview

AgencyOS is the command center for **Paulweezydesign Agency** — a full-service digital design and development agency based in Houston, TX. Built with React, TypeScript, and Vite.

## Features

| View | Status | Description |
|------|--------|-------------|
| **Dashboard** | ✅ Live | KPI overview, recent activity, quick actions |
| **Projects** | ✅ Live | Kanban board with task management, dependencies, and recurrence |
| **Clients** | ✅ Live | Client directory and relationship management |
| **Reports** | 🚧 Planned | Analytics and reporting (coming soon) |
| **Settings** | 🚧 Planned | App configuration (coming soon) |

## Tech Stack

- **Framework:** React 19 + TypeScript
- **Build:** Vite 6
- **Icons:** Lucide React
- **Styling:** Tailwind CSS (custom dark theme)

## Getting Started

### Prerequisites
- Node.js 18+

### Install & Run

```bash
# Install dependencies
npm install

# Start dev server
npm run dev

# Build for production
npm run build
```

## Project Structure

```
├── App.tsx              # Main app with view routing
├── types.ts             # TypeScript interfaces (Project, Task, Proposal, etc.)
├── components/
│   ├── Sidebar.tsx      # Navigation sidebar
│   ├── Dashboard.tsx    # Dashboard view
│   ├── ProjectView.tsx  # Project management (kanban + tasks)
│   └── ClientView.tsx   # Client management
├── index.html           # Entry HTML
├── index.tsx            # React entry point
├── vite.config.ts       # Vite configuration
└── tsconfig.json        # TypeScript configuration
```

## Roadmap

- [ ] Reports view — analytics dashboards for revenue, project velocity, and utilization
- [ ] Settings view — user preferences, integrations config, team management
- [ ] Authentication — login/signup with role-based access
- [ ] API backend — persistent data storage (replace mock data)
- [ ] Refactor ProjectView — split 60KB component into smaller modules

## License

Private — © 2026 Paulweezydesign Agency
