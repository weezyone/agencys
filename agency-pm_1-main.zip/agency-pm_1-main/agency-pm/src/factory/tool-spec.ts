import { err, ok, type Result } from '../domain/result.js';

/**
 * Dynamic tool creation, done safely.
 *
 * When the PM (or a specialist) lacks a tool, it does not write and eval
 * arbitrary code at runtime. It emits a *declarative spec* for an HTTP tool:
 * method, URL template, headers, body template, and typed inputs. The
 * factory validates the spec, then compiles it into an executor.
 *
 * Secrets use `{{secret:NAME}}` placeholders that are resolved from the
 * process environment at execution time — the model never sees or
 * round-trips credential values.
 */

export type HttpToolSpec = Readonly<{
  name: string;
  description: string;
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  urlTemplate: string;
  headers?: Readonly<Record<string, string>>;
  bodyTemplate?: string;
  inputs: Readonly<Record<string, 'string' | 'number' | 'boolean'>>;
}>;

const NAME_PATTERN = /^[a-z][a-z0-9_-]*$/;
const VAR_PATTERN = /\{\{([a-zA-Z0-9_:-]+)\}\}/g;

const templateVars = (template: string): ReadonlyArray<string> =>
  [...template.matchAll(VAR_PATTERN)]
    .map((m) => m[1] as string)
    .filter((name) => !name.startsWith('secret:'));

export const validateHttpToolSpec = (spec: HttpToolSpec): Result<true> => {
  if (!NAME_PATTERN.test(spec.name)) {
    return err(`tool name "${spec.name}" must match ${NAME_PATTERN}`);
  }
  if (!/^https?:\/\//.test(spec.urlTemplate)) {
    return err('urlTemplate must be an http(s) URL');
  }
  const declared = new Set(Object.keys(spec.inputs));
  const used = [
    ...templateVars(spec.urlTemplate),
    ...templateVars(spec.bodyTemplate ?? ''),
    ...Object.values(spec.headers ?? {}).flatMap(templateVars),
  ];
  const undeclared = used.filter((name) => !declared.has(name));
  return undeclared.length > 0
    ? err(`template variables not declared in inputs: ${[...new Set(undeclared)].join(', ')}`)
    : ok(true);
};

/**
 * Interpolates `{{var}}` placeholders. `{{secret:NAME}}` placeholders are
 * intentionally left untouched — they belong to the secret-resolution pass.
 */
export const renderTemplate = (
  template: string,
  vars: Readonly<Record<string, string | number | boolean>>,
): Result<string> => {
  const missing = templateVars(template).filter((name) => !(name in vars));
  if (missing.length > 0) {
    return err(`missing template variables: ${[...new Set(missing)].join(', ')}`);
  }
  return ok(
    template.replace(VAR_PATTERN, (whole, name: string) =>
      name.startsWith('secret:') ? whole : String(vars[name]),
    ),
  );
};

const resolveSecrets = (
  template: string,
  secrets: Readonly<Record<string, string | undefined>>,
): Result<string> => {
  const names = [...template.matchAll(/\{\{secret:([A-Za-z0-9_]+)\}\}/g)].map(
    (m) => m[1] as string,
  );
  const missing = names.filter((name) => secrets[name] === undefined);
  if (missing.length > 0) {
    return err(`missing secrets in environment: ${[...new Set(missing)].join(', ')}`);
  }
  return ok(
    template.replace(/\{\{secret:([A-Za-z0-9_]+)\}\}/g, (_, name: string) =>
      String(secrets[name]),
    ),
  );
};

export type HttpToolDeps = Readonly<{
  fetchImpl: typeof fetch;
  secrets: Readonly<Record<string, string | undefined>>;
}>;

export type HttpToolResult = Readonly<{ status: number; body: unknown }>;

export const buildHttpExecutor =
  (spec: HttpToolSpec) =>
  async (
    input: Readonly<Record<string, string | number | boolean>>,
    deps: HttpToolDeps,
  ): Promise<Result<HttpToolResult>> => {
    const url = renderTemplate(spec.urlTemplate, input);
    if (!url.ok) return url;

    const body =
      spec.bodyTemplate === undefined ? ok(undefined) : renderTemplate(spec.bodyTemplate, input);
    if (!body.ok) return body;

    const headerResults = Object.entries(spec.headers ?? {}).map(([key, value]) => {
      const rendered = renderTemplate(value, input);
      if (!rendered.ok) return rendered;
      const resolved = resolveSecrets(rendered.value, deps.secrets);
      return resolved.ok ? ok([key, resolved.value] as const) : resolved;
    });
    const failedHeader = headerResults.find((r) => !r.ok);
    if (failedHeader && !failedHeader.ok) return failedHeader;

    const headers = Object.fromEntries(
      headerResults.flatMap((r) => (r.ok ? [r.value] : [])),
    );

    try {
      const response = await deps.fetchImpl(url.value, {
        method: spec.method,
        headers,
        ...(body.value !== undefined ? { body: body.value } : {}),
      });
      const contentType = response.headers.get('content-type') ?? '';
      const parsed = contentType.includes('application/json')
        ? await response.json()
        : await response.text();
      return ok(Object.freeze({ status: response.status, body: parsed }));
    } catch (cause) {
      return err(`request failed: ${cause instanceof Error ? cause.message : String(cause)}`);
    }
  };
