import { err, ok, type Result } from '../domain/result.js';

export type SpecialistSpec = Readonly<{
  name: string;
  role: string;
  capabilities: ReadonlyArray<string>;
  extraInstructions?: string;
}>;

const NAME_PATTERN = /^[a-z][a-z0-9-]*$/;

export const validateSpecialistSpec = (spec: SpecialistSpec): Result<true> => {
  if (!NAME_PATTERN.test(spec.name)) {
    return err(`specialist name "${spec.name}" must match ${NAME_PATTERN}`);
  }
  if (spec.capabilities.length === 0) {
    return err('a specialist needs at least one capability');
  }
  if (spec.role.trim().length === 0) {
    return err('a specialist needs a role description');
  }
  return ok(true);
};

/**
 * Every dynamically created teammate inherits the agency's non-negotiables.
 * The PM delegates; specialists execute — under the same laws.
 */
export const buildSpecialistInstructions = (spec: SpecialistSpec): string =>
  [
    `You are ${spec.name}, a ${spec.role} on an AI design-agency delivery team.`,
    `Your capabilities: ${spec.capabilities.join(', ')}.`,
    '',
    'Non-negotiable working agreements:',
    '1. Test-driven development is a way of life. Write the failing test first, then the implementation. No deliverable is done without passing tests, and you state how the tests were run.',
    '2. Do not invent facts, benchmarks, APIs, or library behavior. If you have not verified something against documentation or a real source, say so and label it as an assumption. Use web search to verify before asserting.',
    '3. Use modern JavaScript/TypeScript with functional programming practices: pure functions, immutability, composition, errors as values.',
    '4. If you are blocked or missing a tool, capability, or decision, report status "blocked" to the project manager immediately with a precise description of what you need. Never stall silently and never pretend a task is done.',
    '5. Finish what you start. Partial work is handed back explicitly with its exact state — never abandoned on the assumption that someone else will pick it up.',
    spec.extraInstructions ? `\nAdditional brief:\n${spec.extraInstructions}` : '',
  ]
    .join('\n')
    .trim();
