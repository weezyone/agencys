import type { Task } from './types.js';

export type MonitorPolicy = Readonly<{ staleAfterMs: number }>;

export type Assessment = 'closed' | 'needs_unblock' | 'stale' | 'on_track';

/**
 * The monitoring rule the PM applies on every sweep:
 *  - blocked tasks always surface for unblocking, regardless of recency
 *  - in-flight tasks with no update inside the staleness window are stale
 *    and require a check-in (no task is assumed to be "probably fine")
 */
export const assessTask = (task: Task, nowMs: number, policy: MonitorPolicy): Assessment =>
  task.status === 'done' || task.status === 'cancelled'
    ? 'closed'
    : task.status === 'blocked'
      ? 'needs_unblock'
      : nowMs - task.updatedAt > policy.staleAfterMs
        ? 'stale'
        : 'on_track';

export type SweepReport = Readonly<{
  closed: ReadonlyArray<Task>;
  needs_unblock: ReadonlyArray<Task>;
  stale: ReadonlyArray<Task>;
  on_track: ReadonlyArray<Task>;
}>;

export const sweep = (
  tasks: ReadonlyArray<Task>,
  nowMs: number,
  policy: MonitorPolicy,
): SweepReport =>
  tasks.reduce<SweepReport>(
    (report, task) => {
      const bucket = assessTask(task, nowMs, policy);
      return Object.freeze({ ...report, [bucket]: Object.freeze([...report[bucket], task]) });
    },
    Object.freeze({ closed: [], needs_unblock: [], stale: [], on_track: [] }),
  );
