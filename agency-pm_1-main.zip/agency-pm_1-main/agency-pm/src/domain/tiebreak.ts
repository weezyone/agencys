import { err, ok, type Result } from './result.js';

export type TieOption = Readonly<{
  id: string;
  label: string;
  scores: Readonly<Record<string, number>>;
}>;

export type TieDecision = Readonly<{
  winner: string;
  ranking: ReadonlyArray<Readonly<{ id: string; total: number }>>;
  rationale: string;
}>;

/**
 * Weighted, deterministic tie-breaking. The PM is the tie-breaker, but its
 * decision must be reproducible and auditable: same options + same weights
 * always produce the same winner, and the rationale shows the arithmetic.
 * Exact numeric ties fall back to lexicographic id order — arbitrary, but
 * deterministic and stated out loud.
 */
export const resolveTie = (
  options: ReadonlyArray<TieOption>,
  weights: Readonly<Record<string, number>>,
): Result<TieDecision> => {
  if (options.length === 0) return err('no options to decide between');

  const knownCriteria = new Set(options.flatMap((o) => Object.keys(o.scores)));
  const unknown = Object.keys(weights).filter((k) => !knownCriteria.has(k));
  if (unknown.length > 0) {
    return err(
      `weights reference criteria no option was scored on: ${unknown.join(', ')}`,
    );
  }

  const total = (option: TieOption): number =>
    Object.entries(weights).reduce(
      (sum, [criterion, weight]) => sum + weight * (option.scores[criterion] ?? 0),
      0,
    );

  const ranking = [...options]
    .map((o) => ({ id: o.id, total: total(o) }))
    .sort((a, b) => b.total - a.total || a.id.localeCompare(b.id));

  const [first, second] = ranking;
  const winner = (first as (typeof ranking)[number]).id;
  const exactTie = second !== undefined && second.total === (first as (typeof ranking)[number]).total;

  const scoreboard = ranking.map((r) => `${r.id}=${r.total}`).join(', ');
  const rationale = exactTie
    ? `Exact tie on weighted totals (${scoreboard}); winner "${winner}" chosen by deterministic lexicographic id order.`
    : `Winner "${winner}" by weighted totals: ${scoreboard}. Weights: ${JSON.stringify(weights)}.`;

  return ok(
    Object.freeze({ winner, ranking: Object.freeze(ranking), rationale }),
  );
};
