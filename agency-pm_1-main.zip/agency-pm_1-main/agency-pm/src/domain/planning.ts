import type { Task } from './types.js';

export type TaskDraft = Readonly<{
  id: string;
  title: string;
  description?: string;
  deps?: ReadonlyArray<string>;
  requiredCapabilities?: ReadonlyArray<string>;
}>;

/**
 * Pure mapping from a PM's plan input to canonical tasks. Every drafted task
 * starts unassigned in 'todo' with empty external refs; graph validity is the
 * caller's job (validateTaskGraph) so this stays a single-purpose function.
 */
export const draftTasks = (
  drafts: ReadonlyArray<TaskDraft>,
  nowMs: number,
): ReadonlyArray<Task> =>
  Object.freeze(
    drafts.map((draft) =>
      Object.freeze({
        id: draft.id,
        title: draft.title,
        ...(draft.description !== undefined ? { description: draft.description } : {}),
        deps: Object.freeze([...(draft.deps ?? [])]),
        status: 'todo',
        requiredCapabilities: Object.freeze([...(draft.requiredCapabilities ?? [])]),
        assignee: null,
        updatedAt: nowMs,
        external: Object.freeze({}),
      } satisfies Task),
    ),
  );
