import { err, ok, type Result } from './result.js';
import type { Task, Teammate } from './types.js';

/**
 * The three reasons assignment can fail. Each one maps to a different PM
 * action, which is why they are explicit variants instead of a string:
 *  - capability_gap  -> create a new specialist agent with those capabilities
 *  - no_single_match -> split the task, or create a combined specialist
 *  - at_capacity     -> wait, re-prioritise, or scale the team
 */
export type AssignmentFailure =
  | Readonly<{ kind: 'capability_gap'; missingCapabilities: ReadonlyArray<string> }>
  | Readonly<{ kind: 'no_single_match'; requiredCapabilities: ReadonlyArray<string> }>
  | Readonly<{ kind: 'at_capacity'; qualified: ReadonlyArray<string> }>;

const utilisation = (m: Teammate): number =>
  m.maxConcurrent === 0 ? Number.POSITIVE_INFINITY : m.activeTaskCount / m.maxConcurrent;

export const selectAssignee = (
  task: Task,
  roster: ReadonlyArray<Teammate>,
): Result<Teammate, AssignmentFailure> => {
  const qualified = roster.filter((m) =>
    task.requiredCapabilities.every((cap) => m.capabilities.includes(cap)),
  );

  if (qualified.length === 0) {
    const covered = new Set(roster.flatMap((m) => m.capabilities));
    const missing = task.requiredCapabilities.filter((cap) => !covered.has(cap));
    return missing.length > 0
      ? err({ kind: 'capability_gap', missingCapabilities: Object.freeze(missing) })
      : err({
          kind: 'no_single_match',
          requiredCapabilities: task.requiredCapabilities,
        });
  }

  const available = qualified.filter((m) => m.activeTaskCount < m.maxConcurrent);
  if (available.length === 0) {
    return err({
      kind: 'at_capacity',
      qualified: Object.freeze(qualified.map((m) => m.name)),
    });
  }

  const [best] = [...available].sort(
    (a, b) => utilisation(a) - utilisation(b) || a.name.localeCompare(b.name),
  );
  return ok(best as Teammate);
};
