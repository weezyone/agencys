/**
 * Canonical task model. This is the single source of truth the PM reasons in.
 * Linear, GitHub, and monday.com are projections of this model (see sync.ts);
 * each tracker is lossier than the canonical form, never richer.
 */
export type CanonicalStatus =
  | 'todo'
  | 'in_progress'
  | 'blocked'
  | 'in_review'
  | 'done'
  | 'cancelled';

export const CANONICAL_STATUSES: ReadonlyArray<CanonicalStatus> = Object.freeze([
  'todo',
  'in_progress',
  'blocked',
  'in_review',
  'done',
  'cancelled',
]);

export type ExternalRefs = Readonly<{
  linearIssueId?: string;
  githubIssueNumber?: number;
  mondayItemId?: string;
}>;

export type Task = Readonly<{
  id: string;
  title: string;
  description?: string;
  deps: ReadonlyArray<string>;
  status: CanonicalStatus;
  requiredCapabilities: ReadonlyArray<string>;
  assignee: string | null;
  /** epoch ms of the last status/progress change */
  updatedAt: number;
  external: ExternalRefs;
}>;

export type Teammate = Readonly<{
  name: string;
  role: string;
  capabilities: ReadonlyArray<string>;
  activeTaskCount: number;
  maxConcurrent: number;
}>;
