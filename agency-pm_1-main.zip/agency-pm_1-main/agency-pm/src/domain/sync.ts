import { err, ok, type Result } from './result.js';
import type { CanonicalStatus, Task } from './types.js';

/**
 * Sync model
 * ----------
 * The canonical task store is the source of truth. Linear, GitHub, and
 * monday.com are projections, each lossier than the canonical model:
 *
 *  - Linear workflow states have a `type` enum (triage/backlog/unstarted/
 *    started/completed/canceled) — richer states like "blocked" are
 *    conventionally states of type `started`.
 *    https://linear.app/developers/issues (workflow states)
 *  - GitHub issues are open/closed with a state_reason
 *    (completed | not_planned | reopened).
 *    https://docs.github.com/en/rest/issues/issues
 *  - monday.com status columns are free-form labels per board, so the
 *    label mapping is configuration, not code.
 *    https://developer.monday.com/api-reference/reference/status
 */

export type LinearStateType =
  | 'triage'
  | 'backlog'
  | 'unstarted'
  | 'started'
  | 'completed'
  | 'canceled';

export type GitHubIssueState = Readonly<{
  state: 'open' | 'closed';
  stateReason: 'completed' | 'not_planned' | 'reopened' | null;
}>;

export type MondayStatusLabels = Readonly<Record<CanonicalStatus, string>>;

export const DEFAULT_MONDAY_STATUS_LABELS: MondayStatusLabels = Object.freeze({
  todo: 'Not Started',
  in_progress: 'Working on it',
  blocked: 'Stuck',
  in_review: 'In Review',
  done: 'Done',
  cancelled: 'Cancelled',
});

/** 'non_terminal' = the tracker only tells us the work is not finished. */
export type InboundStatus = CanonicalStatus | 'non_terminal';

// --- Linear -----------------------------------------------------------------

const LINEAR_TO_CANONICAL: Readonly<Record<LinearStateType, CanonicalStatus>> =
  Object.freeze({
    triage: 'todo',
    backlog: 'todo',
    unstarted: 'todo',
    started: 'in_progress',
    completed: 'done',
    canceled: 'cancelled',
  });

export const fromLinearStateType = (type: LinearStateType): CanonicalStatus =>
  LINEAR_TO_CANONICAL[type];

export const toLinearStateType = (status: CanonicalStatus): LinearStateType => {
  switch (status) {
    case 'todo':
      return 'unstarted';
    case 'in_progress':
    case 'blocked':
    case 'in_review':
      return 'started';
    case 'done':
      return 'completed';
    case 'cancelled':
      return 'canceled';
  }
};

// --- GitHub -----------------------------------------------------------------

export const fromGitHub = (issue: GitHubIssueState): InboundStatus =>
  issue.state === 'closed'
    ? issue.stateReason === 'not_planned'
      ? 'cancelled'
      : 'done'
    : 'non_terminal';

export const toGitHubState = (status: CanonicalStatus): GitHubIssueState =>
  status === 'done'
    ? Object.freeze({ state: 'closed' as const, stateReason: 'completed' as const })
    : status === 'cancelled'
      ? Object.freeze({ state: 'closed' as const, stateReason: 'not_planned' as const })
      : Object.freeze({ state: 'open' as const, stateReason: null });

// --- monday.com ---------------------------------------------------------------

export const toMondayLabel = (
  status: CanonicalStatus,
  labels: MondayStatusLabels,
): string => labels[status];

export const fromMondayLabel = (
  label: string,
  labels: MondayStatusLabels,
): Result<CanonicalStatus> => {
  const entry = Object.entries(labels).find(([, value]) => value === label);
  return entry
    ? ok(entry[0] as CanonicalStatus)
    : err(`unmapped monday label: "${label}" — add it to the status label mapping`);
};

// --- Outbound diff ------------------------------------------------------------

export type TrackerName = 'linear' | 'github' | 'monday';

export type SyncOp =
  | Readonly<{ kind: 'set_status'; target: TrackerName; taskId: string; status: CanonicalStatus }>
  | Readonly<{ kind: 'create'; target: TrackerName; taskId: string }>;

/**
 * Snapshot of what each tracker currently shows.
 *  - key absent  -> tracker not configured, ignore it
 *  - value null  -> tracker configured but the task doesn't exist there yet
 */
export type TrackerSnapshot = Readonly<{
  linear?: Readonly<{ stateType: LinearStateType }> | null;
  github?: GitHubIssueState | null;
  monday?: Readonly<{ label: string }> | null;
}>;

const githubMatches = (a: GitHubIssueState, b: GitHubIssueState): boolean =>
  a.state === b.state && (a.state === 'open' || a.stateReason === b.stateReason);

/**
 * Pure diff: compares the canonical task against each configured tracker and
 * returns the minimal set of idempotent operations needed to converge.
 */
export const outboundOps = (
  task: Task,
  snapshot: TrackerSnapshot,
  labels: MondayStatusLabels = DEFAULT_MONDAY_STATUS_LABELS,
): ReadonlyArray<SyncOp> => {
  const ops: ReadonlyArray<SyncOp | null> = [
    !('linear' in snapshot)
      ? null
      : snapshot.linear === null
        ? { kind: 'create', target: 'linear', taskId: task.id }
        : snapshot.linear.stateType !== toLinearStateType(task.status)
          ? { kind: 'set_status', target: 'linear', taskId: task.id, status: task.status }
          : null,
    !('github' in snapshot)
      ? null
      : snapshot.github === null
        ? { kind: 'create', target: 'github', taskId: task.id }
        : !githubMatches(snapshot.github, toGitHubState(task.status))
          ? { kind: 'set_status', target: 'github', taskId: task.id, status: task.status }
          : null,
    !('monday' in snapshot)
      ? null
      : snapshot.monday === null
        ? { kind: 'create', target: 'monday', taskId: task.id }
        : snapshot.monday.label !== toMondayLabel(task.status, labels)
          ? { kind: 'set_status', target: 'monday', taskId: task.id, status: task.status }
          : null,
  ];
  return Object.freeze(ops.filter((op): op is SyncOp => op !== null));
};

// --- Reconciliation -----------------------------------------------------------

export type ReconcileInput = Readonly<{
  localStatus: CanonicalStatus;
  localUpdatedAt: number;
  remoteStatus: InboundStatus;
  remoteUpdatedAt: number;
  lastSyncedAt: number;
}>;

export type ReconcileDecision = 'noop' | 'push' | 'pull' | 'conflict';

/**
 * Decide what to do when local store and a tracker may disagree.
 * 'conflict' is deliberately not auto-resolved here — both sides changed,
 * so the decision goes to the PM's tie-breaker with a recorded rationale.
 */
export const reconcile = (input: ReconcileInput): ReconcileDecision => {
  const { localStatus, localUpdatedAt, remoteStatus, remoteUpdatedAt, lastSyncedAt } =
    input;

  if (remoteStatus === 'non_terminal' || remoteStatus === localStatus) return 'noop';

  const localChanged = localUpdatedAt > lastSyncedAt;
  const remoteChanged = remoteUpdatedAt > lastSyncedAt;

  if (localChanged && remoteChanged) return 'conflict';
  if (remoteChanged) return 'pull';
  return 'push';
};

// --- Push-mode projection -------------------------------------------------

const TERMINAL: ReadonlyArray<CanonicalStatus> = Object.freeze(['done', 'cancelled']);

const refFor = (task: Task, target: TrackerName): boolean =>
  target === 'linear'
    ? task.external.linearIssueId !== undefined
    : target === 'github'
      ? task.external.githubIssueNumber !== undefined
      : task.external.mondayItemId !== undefined;

/**
 * Push-mode sync: project the canonical task outward without reading remote
 * state. Trackers with a stored ref get an idempotent status push; trackers
 * missing the task get a create — unless the task is already terminal, in
 * which case creating a tracker item would only add noise about work that
 * never lived there. (outboundOps/reconcile handle the richer read-back path
 * once inbound webhooks land.)
 */
export const pushOps = (
  task: Task,
  configured: ReadonlyArray<TrackerName>,
): ReadonlyArray<SyncOp> =>
  Object.freeze(
    configured.flatMap((target): ReadonlyArray<SyncOp> =>
      refFor(task, target)
        ? [{ kind: 'set_status', target, taskId: task.id, status: task.status }]
        : TERMINAL.includes(task.status)
          ? []
          : [{ kind: 'create', target, taskId: task.id }],
    ),
  );
