import { err, ok, type Result } from './result.js';
import type { Task } from './types.js';

type GraphNode = Pick<Task, 'id' | 'deps'>;

/**
 * Deterministic topological order via Kahn's algorithm.
 * Among equally-ready nodes, ids are processed in lexicographic order so the
 * same graph always dispatches in the same order. Local mutation is scoped
 * inside this pure function; inputs are never touched.
 */
export const topologicalOrder = (
  tasks: ReadonlyArray<GraphNode>,
): Result<ReadonlyArray<string>> => {
  const indegree = new Map(tasks.map((t) => [t.id, t.deps.length]));
  const dependents = tasks.reduce((acc, t) => {
    t.deps.forEach((dep) => acc.set(dep, [...(acc.get(dep) ?? []), t.id]));
    return acc;
  }, new Map<string, ReadonlyArray<string>>());

  const order: string[] = [];
  const ready = [...indegree.entries()]
    .filter(([, deg]) => deg === 0)
    .map(([id]) => id)
    .sort();

  while (ready.length > 0) {
    const id = ready.shift() as string;
    order.push(id);
    (dependents.get(id) ?? []).forEach((dependent) => {
      const remaining = (indegree.get(dependent) ?? 0) - 1;
      indegree.set(dependent, remaining);
      if (remaining === 0) {
        // keep the ready queue sorted for determinism
        const at = ready.findIndex((r) => r > dependent);
        at === -1 ? ready.push(dependent) : ready.splice(at, 0, dependent);
      }
    });
  }

  return order.length === tasks.length
    ? ok(Object.freeze(order))
    : err('dependency cycle detected');
};

/**
 * A graph is valid when ids are unique, every dependency points at a known
 * task, and the dependency relation is acyclic.
 */
export const validateTaskGraph = (tasks: ReadonlyArray<GraphNode>): Result<true> => {
  const ids = tasks.map((t) => t.id);
  const duplicate = ids.find((id, i) => ids.indexOf(id) !== i);
  if (duplicate !== undefined) return err(`duplicate task id: ${duplicate}`);

  const known = new Set(ids);
  const unknown = tasks.flatMap((t) =>
    t.deps.filter((d) => !known.has(d)).map((d) => `${t.id} -> ${d}`),
  );
  if (unknown.length > 0) return err(`unknown dependencies: ${unknown.join(', ')}`);

  const order = topologicalOrder(tasks);
  return order.ok ? ok(true) : err(order.error);
};

/**
 * Tasks that can be dispatched right now: status 'todo' with every
 * dependency 'done'. Cancelled dependencies do NOT satisfy a dependent —
 * the PM must explicitly re-plan, never silently drop scope.
 */
export const readyTasks = (tasks: ReadonlyArray<Task>): ReadonlyArray<Task> => {
  const byId = new Map(tasks.map((t) => [t.id, t]));
  return Object.freeze(
    tasks.filter(
      (t) =>
        t.status === 'todo' && t.deps.every((dep) => byId.get(dep)?.status === 'done'),
    ),
  );
};
