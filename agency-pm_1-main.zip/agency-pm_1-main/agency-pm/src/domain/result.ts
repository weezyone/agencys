/**
 * Result type — errors as values, not exceptions.
 * Every fallible domain function returns one of these so callers
 * (including the PM agent's tools) are forced to handle failure explicitly.
 */
export type Ok<T> = Readonly<{ ok: true; value: T }>;
export type Err<E> = Readonly<{ ok: false; error: E }>;
export type Result<T, E = string> = Ok<T> | Err<E>;

export const ok = <T>(value: T): Ok<T> => Object.freeze({ ok: true as const, value });
export const err = <E>(error: E): Err<E> => Object.freeze({ ok: false as const, error });

export const map =
  <T, U, E>(fn: (value: T) => U) =>
  (result: Result<T, E>): Result<U, E> =>
    result.ok ? ok(fn(result.value)) : result;

export const andThen =
  <T, U, E>(fn: (value: T) => Result<U, E>) =>
  (result: Result<T, E>): Result<U, E> =>
    result.ok ? fn(result.value) : result;
