import { MongoClient, type Collection } from 'mongodb';
import { err, ok, type Result } from '../domain/result.js';
import type { CanonicalStatus, ExternalRefs, Task } from '../domain/types.js';

/**
 * Canonical task board in MongoDB.
 *
 * Two collections:
 *  - pm_tasks   : current state of every task (the board)
 *  - pm_events  : append-only journal of everything that happened —
 *                 plans, delegations, status changes, decisions, tool and
 *                 specialist creations. This is what makes the system
 *                 auditable: `db.pm_events.find().sort({at:1})` replays
 *                 the whole project.
 */

export type TaskEvent = Readonly<{
  at: number;
  kind:
    | 'planned'
    | 'delegated'
    | 'status_changed'
    | 'tie_broken'
    | 'specialist_created'
    | 'tool_created'
    | 'sync_applied'
    | 'sync_conflict'
    | 'unblock_started';
  taskId?: string;
  detail: Readonly<Record<string, unknown>>;
}>;

let client: MongoClient | null = null;

const db = async () => {
  const uri = process.env.MONGODB_URI;
  if (uri === undefined) throw new Error('Missing required environment variable: MONGODB_URI');
  client = client ?? new MongoClient(uri);
  await client.connect();
  return client.db(process.env.MONGODB_DB_NAME ?? 'agency_pm');
};

const tasks = async (): Promise<Collection<Task & { _id: string }>> =>
  (await db()).collection('pm_tasks');

const events = async (): Promise<Collection<TaskEvent>> =>
  (await db()).collection('pm_events');

export const recordEvent = async (event: Omit<TaskEvent, 'at'>): Promise<void> => {
  await (await events()).insertOne({ ...event, at: Date.now() });
};

export const upsertTasks = async (
  incoming: ReadonlyArray<Task>,
): Promise<Result<number>> => {
  try {
    const collection = await tasks();
    await Promise.all(
      incoming.map((task) =>
        collection.updateOne(
          { _id: task.id },
          { $set: { ...task, _id: task.id } },
          { upsert: true },
        ),
      ),
    );
    return ok(incoming.length);
  } catch (cause) {
    return err(`task upsert failed: ${cause instanceof Error ? cause.message : String(cause)}`);
  }
};

export const loadBoard = async (): Promise<Result<ReadonlyArray<Task>>> => {
  try {
    const collection = await tasks();
    const docs = await collection.find().toArray();
    return ok(Object.freeze(docs.map(({ _id, ...task }) => Object.freeze(task) as Task)));
  } catch (cause) {
    return err(`board load failed: ${cause instanceof Error ? cause.message : String(cause)}`);
  }
};

export const setTaskStatus = async (
  taskId: string,
  status: CanonicalStatus,
  note?: string,
): Promise<Result<Task>> => {
  try {
    const collection = await tasks();
    const updated = await collection.findOneAndUpdate(
      { _id: taskId },
      { $set: { status, updatedAt: Date.now() } },
      { returnDocument: 'after' },
    );
    if (updated === null) return err(`no task with id "${taskId}"`);
    await recordEvent({
      kind: 'status_changed',
      taskId,
      detail: { status, ...(note !== undefined ? { note } : {}) },
    });
    const { _id, ...task } = updated;
    return ok(Object.freeze(task) as Task);
  } catch (cause) {
    return err(`status update failed: ${cause instanceof Error ? cause.message : String(cause)}`);
  }
};

export const setExternalRefs = async (
  taskId: string,
  refs: Partial<ExternalRefs>,
): Promise<Result<Task>> => {
  try {
    const collection = await tasks();
    const sets = Object.fromEntries(
      Object.entries(refs)
        .filter(([, value]) => value !== undefined)
        .map(([key, value]) => [`external.${key}`, value]),
    );
    const updated = await collection.findOneAndUpdate(
      { _id: taskId },
      { $set: sets },
      { returnDocument: 'after' },
    );
    if (updated === null) return err(`no task with id "${taskId}"`);
    const { _id, ...task } = updated;
    return ok(Object.freeze(task) as Task);
  } catch (cause) {
    return err(`external ref update failed: ${cause instanceof Error ? cause.message : String(cause)}`);
  }
};

export const setAssignee = async (
  taskId: string,
  assignee: string,
): Promise<Result<Task>> => {
  try {
    const collection = await tasks();
    const updated = await collection.findOneAndUpdate(
      { _id: taskId },
      { $set: { assignee, status: 'in_progress' satisfies CanonicalStatus, updatedAt: Date.now() } },
      { returnDocument: 'after' },
    );
    if (updated === null) return err(`no task with id "${taskId}"`);
    const { _id, ...task } = updated;
    return ok(Object.freeze(task) as Task);
  } catch (cause) {
    return err(`assignment failed: ${cause instanceof Error ? cause.message : String(cause)}`);
  }
};
