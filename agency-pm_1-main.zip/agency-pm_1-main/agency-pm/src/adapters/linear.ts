import { LinearClient } from '@linear/sdk';
import { err, ok, type Result } from '../domain/result.js';
import { toLinearStateType, type LinearStateType } from '../domain/sync.js';
import type { CanonicalStatus, Task } from '../domain/types.js';

/**
 * Linear adapter.
 *
 * Linear models status as team-scoped workflow states, each carrying a
 * `type` from a fixed enum (triage/backlog/unstarted/started/completed/
 * canceled). We resolve canonical status -> state type -> a concrete state
 * id in the configured team.
 * SDK + API docs: https://linear.app/developers/sdk
 *                 https://linear.app/developers/issues
 */

export type LinearDeps = Readonly<{
  client: LinearClient;
  teamId: string;
}>;

export const buildLinearClient = (): LinearClient =>
  new LinearClient({ apiKey: requiredEnv('LINEAR_API_KEY') });

const stateIdForType = async (
  deps: LinearDeps,
  type: LinearStateType,
): Promise<Result<string>> => {
  const states = await deps.client.workflowStates({
    filter: { team: { id: { eq: deps.teamId } } },
  });
  const match = states.nodes.find((state) => state.type === type);
  return match
    ? ok(match.id)
    : err(`team ${deps.teamId} has no workflow state of type "${type}"`);
};

export const linearSetStatus = async (
  deps: LinearDeps,
  issueId: string,
  status: CanonicalStatus,
): Promise<Result<string>> => {
  const stateId = await stateIdForType(deps, toLinearStateType(status));
  if (!stateId.ok) return stateId;
  try {
    await deps.client.updateIssue(issueId, { stateId: stateId.value });
    return ok(`linear issue ${issueId} -> ${status}`);
  } catch (cause) {
    return err(`linear update failed: ${cause instanceof Error ? cause.message : String(cause)}`);
  }
};

export const linearCreateIssue = async (
  deps: LinearDeps,
  task: Task,
): Promise<Result<string>> => {
  try {
    const payload = await deps.client.createIssue({
      teamId: deps.teamId,
      title: task.title,
      ...(task.description !== undefined ? { description: task.description } : {}),
    });
    const issue = await payload.issue;
    return issue ? ok(issue.id) : err('linear createIssue returned no issue');
  } catch (cause) {
    return err(`linear create failed: ${cause instanceof Error ? cause.message : String(cause)}`);
  }
};

const requiredEnv = (name: string): string => {
  const value = process.env[name];
  if (value === undefined || value.length === 0) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
};
