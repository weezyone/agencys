import { Octokit } from 'octokit';
import { err, ok, type Result } from '../domain/result.js';
import { toGitHubState } from '../domain/sync.js';
import type { CanonicalStatus, Task } from '../domain/types.js';

/**
 * GitHub adapter over Octokit's REST issues API.
 * Issues are open/closed with a state_reason (completed | not_planned).
 * Docs: https://docs.github.com/en/rest/issues/issues
 */

export type GitHubDeps = Readonly<{
  octokit: Octokit;
  owner: string;
  repo: string;
}>;

export const buildOctokit = (): Octokit =>
  new Octokit({ auth: requiredEnv('GITHUB_TOKEN') });

export const githubSetStatus = async (
  deps: GitHubDeps,
  issueNumber: number,
  status: CanonicalStatus,
): Promise<Result<string>> => {
  const target = toGitHubState(status);
  try {
    await deps.octokit.rest.issues.update({
      owner: deps.owner,
      repo: deps.repo,
      issue_number: issueNumber,
      state: target.state,
      ...(target.stateReason !== null ? { state_reason: target.stateReason } : {}),
    });
    return ok(`github #${issueNumber} -> ${target.state}`);
  } catch (cause) {
    return err(`github update failed: ${cause instanceof Error ? cause.message : String(cause)}`);
  }
};

export const githubCreateIssue = async (
  deps: GitHubDeps,
  task: Task,
): Promise<Result<number>> => {
  try {
    const created = await deps.octokit.rest.issues.create({
      owner: deps.owner,
      repo: deps.repo,
      title: task.title,
      ...(task.description !== undefined ? { body: task.description } : {}),
    });
    return ok(created.data.number);
  } catch (cause) {
    return err(`github create failed: ${cause instanceof Error ? cause.message : String(cause)}`);
  }
};

const requiredEnv = (name: string): string => {
  const value = process.env[name];
  if (value === undefined || value.length === 0) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
};
