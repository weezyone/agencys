import type { Result } from '../domain/result.js';
import type { SyncOp, TrackerName } from '../domain/sync.js';
import type { CanonicalStatus } from '../domain/types.js';

/**
 * The minimal capability surface every tracker adapter must implement.
 * Linear, GitHub, and monday.com each get an adapter that closes over its
 * SDK client and returns this shape — so the sync engine never touches an
 * SDK directly and the whole pipeline is testable with fakes.
 */
export type TrackerPort = Readonly<{
  setStatus: (taskId: string, status: CanonicalStatus) => Promise<Result<string>>;
  createTask: (taskId: string) => Promise<Result<string>>;
}>;

export type TrackerPorts = Readonly<Partial<Record<TrackerName, TrackerPort>>>;

export type SyncReport = Readonly<{
  applied: ReadonlyArray<Readonly<{ op: SyncOp; detail: string }>>;
  failed: ReadonlyArray<Readonly<{ op: SyncOp; error: string }>>;
}>;

const applyOne = async (op: SyncOp, ports: TrackerPorts) => {
  const port = ports[op.target];
  if (port === undefined) {
    return { op, error: `tracker "${op.target}" is not configured` } as const;
  }
  const result =
    op.kind === 'set_status'
      ? await port.setStatus(op.taskId, op.status)
      : await port.createTask(op.taskId);
  return result.ok
    ? ({ op, detail: result.value } as const)
    : ({ op, error: result.error } as const);
};

/**
 * Applies ops sequentially (trackers rate-limit; politeness beats speed),
 * never throws, and reports every outcome — including failures — honestly.
 */
export const applySyncOps = async (
  ops: ReadonlyArray<SyncOp>,
  ports: TrackerPorts,
): Promise<SyncReport> => {
  const outcomes = await ops.reduce<Promise<ReadonlyArray<Awaited<ReturnType<typeof applyOne>>>>>(
    async (accPromise, op) => {
      const acc = await accPromise;
      const outcome = await applyOne(op, ports);
      return [...acc, outcome];
    },
    Promise.resolve([]),
  );

  return Object.freeze({
    applied: Object.freeze(outcomes.filter((o): o is Extract<typeof o, { detail: string }> => 'detail' in o)),
    failed: Object.freeze(outcomes.filter((o): o is Extract<typeof o, { error: string }> => 'error' in o)),
  });
};
