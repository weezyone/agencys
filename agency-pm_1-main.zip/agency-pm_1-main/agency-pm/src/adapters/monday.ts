import { err, ok, type Result } from '../domain/result.js';
import { toMondayLabel, DEFAULT_MONDAY_STATUS_LABELS, type MondayStatusLabels } from '../domain/sync.js';
import type { CanonicalStatus, Task } from '../domain/types.js';

/**
 * monday.com adapter over the GraphQL API (https://api.monday.com/v2).
 *
 * Status columns are board-specific labels, so the canonical->label mapping
 * is configuration (MONDAY_STATUS_LABELS env as JSON), defaulting to
 * monday's stock labels. Mutations used:
 *  - create_item                  https://developer.monday.com/api-reference/reference/items
 *  - change_simple_column_value   https://developer.monday.com/api-reference/reference/columns
 */

export type MondayDeps = Readonly<{
  token: string;
  boardId: string;
  statusColumnId: string;
  labels: MondayStatusLabels;
  fetchImpl: typeof fetch;
}>;

export const buildMondayDeps = (): MondayDeps => ({
  token: requiredEnv('MONDAY_API_TOKEN'),
  boardId: requiredEnv('MONDAY_BOARD_ID'),
  statusColumnId: process.env.MONDAY_STATUS_COLUMN_ID ?? 'status',
  labels: parseLabels(process.env.MONDAY_STATUS_LABELS),
  fetchImpl: fetch,
});

const gql = async (
  deps: MondayDeps,
  query: string,
  variables: Readonly<Record<string, unknown>>,
): Promise<Result<unknown>> => {
  try {
    const response = await deps.fetchImpl('https://api.monday.com/v2', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: deps.token,
      },
      body: JSON.stringify({ query, variables }),
    });
    const payload = (await response.json()) as { data?: unknown; errors?: ReadonlyArray<{ message: string }> };
    return payload.errors && payload.errors.length > 0
      ? err(`monday API error: ${payload.errors.map((e) => e.message).join('; ')}`)
      : ok(payload.data);
  } catch (cause) {
    return err(`monday request failed: ${cause instanceof Error ? cause.message : String(cause)}`);
  }
};

export const mondaySetStatus = async (
  deps: MondayDeps,
  itemId: string,
  status: CanonicalStatus,
): Promise<Result<string>> => {
  const label = toMondayLabel(status, deps.labels);
  const result = await gql(
    deps,
    `mutation ($boardId: ID!, $itemId: ID!, $columnId: String!, $value: String!) {
       change_simple_column_value(board_id: $boardId, item_id: $itemId, column_id: $columnId, value: $value) { id }
     }`,
    { boardId: deps.boardId, itemId, columnId: deps.statusColumnId, value: label },
  );
  return result.ok ? ok(`monday item ${itemId} -> "${label}"`) : result;
};

export const mondayCreateItem = async (
  deps: MondayDeps,
  task: Task,
): Promise<Result<string>> => {
  const result = await gql(
    deps,
    `mutation ($boardId: ID!, $name: String!) {
       create_item(board_id: $boardId, item_name: $name) { id }
     }`,
    { boardId: deps.boardId, name: task.title },
  );
  if (!result.ok) return result;
  const id = (result.value as { create_item?: { id?: string } } | null)?.create_item?.id;
  return id !== undefined ? ok(id) : err('monday create_item returned no id');
};

const parseLabels = (raw: string | undefined): MondayStatusLabels => {
  if (raw === undefined) return DEFAULT_MONDAY_STATUS_LABELS;
  const parsed = JSON.parse(raw) as Record<string, string>;
  return Object.freeze({ ...DEFAULT_MONDAY_STATUS_LABELS, ...parsed });
};

const requiredEnv = (name: string): string => {
  const value = process.env[name];
  if (value === undefined || value.length === 0) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
};
