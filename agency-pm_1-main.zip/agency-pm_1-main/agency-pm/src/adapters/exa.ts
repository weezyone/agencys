import Exa from 'exa-js';
import { err, ok, type Result } from '../domain/result.js';

/**
 * Exa web search adapter.
 * searchAndContents returns ranked results with page text in one call.
 * Docs: https://docs.exa.ai/reference/quickstart
 */

export type SearchHit = Readonly<{
  title: string | null;
  url: string;
  publishedDate: string | null;
  excerpt: string;
}>;

let exa: Exa | null = null;

const client = (): Exa => {
  exa = exa ?? new Exa(requiredEnv('EXA_API_KEY'));
  return exa;
};

export const searchWeb = async (
  query: string,
  numResults: number,
): Promise<Result<ReadonlyArray<SearchHit>>> => {
  try {
    const response = await client().searchAndContents(query, {
      type: 'auto',
      numResults,
      text: true,
    });
    return ok(
      Object.freeze(
        response.results.map((r) =>
          Object.freeze({
            title: r.title ?? null,
            url: r.url,
            publishedDate: r.publishedDate ?? null,
            excerpt: (r.text ?? '').slice(0, 1500),
          }),
        ),
      ),
    );
  } catch (cause) {
    return err(`exa search failed: ${cause instanceof Error ? cause.message : String(cause)}`);
  }
};

const requiredEnv = (name: string): string => {
  const value = process.env[name];
  if (value === undefined || value.length === 0) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
};
