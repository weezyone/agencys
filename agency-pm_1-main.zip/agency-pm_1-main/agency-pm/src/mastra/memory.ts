import { Memory } from '@mastra/memory';
import { MongoDBStore, MongoDBVector } from '@mastra/mongodb';
import { fastembed } from '@mastra/fastembed';

/**
 * Observable memory on MongoDB.
 *
 * - MongoDBStore persists threads, messages, and working memory as plain
 *   collections in your database — inspectable with Compass/mongosh.
 * - MongoDBVector + fastembed (local embeddings, no extra API key) power
 *   semantic recall over past project conversations.
 *
 * Pattern verified against the Mastra MongoDB reference:
 * https://mastra.ai/reference/storage/mongodb
 * Requires MongoDB Atlas (cloud) or Atlas Local via Docker, since semantic
 * recall uses Atlas Vector Search.
 */
export const buildMongoStorage = () =>
  new MongoDBStore({
    id: 'agency-pm-storage',
    uri: requiredEnv('MONGODB_URI'),
    dbName: process.env.MONGODB_DB_NAME ?? 'agency_pm',
  });

export const buildAgencyMemory = () =>
  new Memory({
    storage: buildMongoStorage(),
    vector: new MongoDBVector({
      id: 'agency-pm-vector',
      uri: requiredEnv('MONGODB_URI'),
      dbName: process.env.MONGODB_DB_NAME ?? 'agency_pm',
    }),
    embedder: fastembed,
    options: {
      lastMessages: 20,
      semanticRecall: {
        topK: 4,
        messageRange: 2,
      },
      workingMemory: {
        enabled: true,
        template: `# Agency Delivery State
## Active objectives
## Roster (name — role — capabilities — load)
## Open decisions / ties pending
## Blockers being worked
## Tracker sync notes (conflicts, unmapped labels)`,
      },
      generateTitle: true,
    },
  });

const requiredEnv = (name: string): string => {
  const value = process.env[name];
  if (value === undefined || value.length === 0) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
};
