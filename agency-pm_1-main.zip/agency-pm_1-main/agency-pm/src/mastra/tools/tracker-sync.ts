import { createTool } from '@mastra/core/tools';
import { z } from 'zod';
import { err, ok, type Result } from '../../domain/result.js';
import { pushOps, type TrackerName } from '../../domain/sync.js';
import type { ExternalRefs, Task } from '../../domain/types.js';
import { buildLinearClient, linearCreateIssue, linearSetStatus } from '../../adapters/linear.js';
import { buildOctokit, githubCreateIssue, githubSetStatus } from '../../adapters/github.js';
import { buildMondayDeps, mondayCreateItem, mondaySetStatus } from '../../adapters/monday.js';
import { applySyncOps, type SyncReport, type TrackerPort, type TrackerPorts } from '../../adapters/trackers.js';
import { loadBoard, recordEvent, setExternalRefs } from '../../adapters/task-repo.js';

const isSet = (name: string): boolean => {
  const value = process.env[name];
  return value !== undefined && value.length > 0;
};

const configuredTrackers = (): ReadonlyArray<TrackerName> =>
  Object.freeze(
    [
      isSet('LINEAR_API_KEY') && isSet('LINEAR_TEAM_ID') ? ('linear' as const) : null,
      isSet('GITHUB_TOKEN') && isSet('GITHUB_OWNER') && isSet('GITHUB_REPO')
        ? ('github' as const)
        : null,
      isSet('MONDAY_API_TOKEN') && isSet('MONDAY_BOARD_ID') ? ('monday' as const) : null,
    ].filter((t): t is TrackerName => t !== null),
  );

const missingRef = (target: TrackerName): Result<string> =>
  err(`task has no ${target} ref yet — a create op should run first`);

/** Bind each configured tracker's port to this task's stored external refs. */
const buildPorts = (task: Task, configured: ReadonlyArray<TrackerName>): TrackerPorts => {
  const linear = (): TrackerPort => {
    const deps = { client: buildLinearClient(), teamId: process.env.LINEAR_TEAM_ID ?? '' };
    return Object.freeze({
      setStatus: (_taskId, status) =>
        task.external.linearIssueId !== undefined
          ? linearSetStatus(deps, task.external.linearIssueId, status)
          : Promise.resolve(missingRef('linear')),
      createTask: () => linearCreateIssue(deps, task),
    });
  };

  const github = (): TrackerPort => {
    const deps = {
      octokit: buildOctokit(),
      owner: process.env.GITHUB_OWNER ?? '',
      repo: process.env.GITHUB_REPO ?? '',
    };
    return Object.freeze({
      setStatus: (_taskId, status) =>
        task.external.githubIssueNumber !== undefined
          ? githubSetStatus(deps, task.external.githubIssueNumber, status)
          : Promise.resolve(missingRef('github')),
      createTask: async () => {
        const created = await githubCreateIssue(deps, task);
        return created.ok ? ok(String(created.value)) : created;
      },
    });
  };

  const monday = (): TrackerPort => {
    const deps = buildMondayDeps();
    return Object.freeze({
      setStatus: (_taskId, status) =>
        task.external.mondayItemId !== undefined
          ? mondaySetStatus(deps, task.external.mondayItemId, status)
          : Promise.resolve(missingRef('monday')),
      createTask: () => mondayCreateItem(deps, task),
    });
  };

  return Object.freeze({
    ...(configured.includes('linear') ? { linear: linear() } : {}),
    ...(configured.includes('github') ? { github: github() } : {}),
    ...(configured.includes('monday') ? { monday: monday() } : {}),
  });
};

/** Persist tracker ids returned by successful create ops back onto the task. */
const persistNewRefs = async (taskId: string, report: SyncReport): Promise<void> => {
  const created = report.applied.filter((entry) => entry.op.kind === 'create');
  if (created.length === 0) return;

  const refs = created.reduce<Partial<ExternalRefs>>(
    (acc, { op, detail }) =>
      op.target === 'linear'
        ? { ...acc, linearIssueId: detail }
        : op.target === 'github'
          ? { ...acc, githubIssueNumber: Number(detail) }
          : { ...acc, mondayItemId: detail },
    {},
  );
  await setExternalRefs(taskId, refs);
};

/**
 * Law 9: keep the trackers true. Push-mode projection — the canonical board
 * is the source of truth; Linear, GitHub, and monday.com converge to it.
 * Trackers the task is missing from get created (ids persisted back onto the
 * task); trackers with refs get an idempotent status push. The richer
 * read-back path (outboundOps + reconcile, where genuine conflicts surface
 * to break_tie) is in the domain and activates when inbound webhooks land.
 */
export const syncTrackersTool = createTool({
  id: 'sync_trackers',
  description:
    'Push a task\'s canonical state to every configured tracker (Linear, GitHub, monday.com). Creates the item where it does not exist yet and stores the new id; pushes status where it does. Call this after every status change. Reports exactly what was applied and what failed — failures must be acted on, not ignored.',
  inputSchema: z.object({
    taskId: z.string().min(1),
  }),
  execute: async ({ taskId }) => {
    const board = await loadBoard();
    if (!board.ok) return { ok: false as const, error: board.error };

    const task = board.value.find((t) => t.id === taskId);
    if (task === undefined) return { ok: false as const, error: `no task with id "${taskId}"` };

    const configured = configuredTrackers();
    if (configured.length === 0) {
      return {
        ok: true as const,
        applied: [],
        failed: [],
        note: 'no trackers configured (set LINEAR_*, GITHUB_*, or MONDAY_* env vars)',
      };
    }

    const ops = pushOps(task, configured);
    if (ops.length === 0) {
      return { ok: true as const, applied: [], failed: [], note: 'nothing to sync' };
    }

    const report = await applySyncOps(ops, buildPorts(task, configured));
    await persistNewRefs(taskId, report);
    await recordEvent({
      kind: 'sync_applied',
      taskId,
      detail: { applied: report.applied, failed: report.failed },
    });

    return { ok: true as const, applied: report.applied, failed: report.failed };
  },
});
