import { Agent } from '@mastra/core/agent';
import { createTool } from '@mastra/core/tools';
import { z } from 'zod';
import { buildSpecialistInstructions, validateSpecialistSpec } from '../../factory/agent-spec.js';
import { recordEvent } from '../../adapters/task-repo.js';
import { buildAgencyMemory } from '../memory.js';
import { getSpecialist, registerSpecialist } from '../registry.js';
import { runDynamicToolTool } from './create-tool.js';
import { webSearchTool } from './web-search.js';

const SPECIALIST_MODEL = process.env.SPECIALIST_MODEL ?? 'openai/gpt-4o';

/**
 * Law 2: staff the work. New specialists are real Mastra agents built from a
 * validated spec; the agency's laws (TDD first, no fabrication, FP style,
 * report blocked immediately, finish what you start) are baked into their
 * instructions by the tested factory — a dynamically hired teammate is held
 * to the same standard as a founding one. The spec is journaled to MongoDB
 * so the roster can be rebuilt after a restart.
 */
export const createSpecialistTool = createTool({
  id: 'create_specialist',
  description:
    'Hire a new specialist agent when delegate_task reports a capability gap. Provide a kebab-case name, a role, the capabilities they cover, and optional extra instructions. The agency laws are added to every specialist automatically. Fails if the name is taken.',
  inputSchema: z.object({
    name: z
      .string()
      .regex(/^[a-z][a-z0-9-]*$/, 'kebab-case, starting with a letter')
      .describe('Unique kebab-case handle, e.g. "motion-designer"'),
    role: z.string().min(1).describe('One-line role, e.g. "Motion design specialist"'),
    capabilities: z
      .array(z.string().min(1))
      .min(1)
      .describe('Capability tags matched against task requiredCapabilities'),
    extraInstructions: z
      .string()
      .optional()
      .describe('Domain-specific guidance beyond the standard agency laws'),
    maxConcurrent: z
      .number()
      .int()
      .min(1)
      .max(10)
      .default(2)
      .describe('How many tasks they may hold at once (default 2)'),
  }),
  execute: async ({ name, role, capabilities, extraInstructions, maxConcurrent }) => {
    if (getSpecialist(name) !== undefined) {
      return { ok: false as const, error: `specialist "${name}" already exists` };
    }

    const spec = Object.freeze({
      name,
      role,
      capabilities: Object.freeze([...capabilities]),
      ...(extraInstructions !== undefined ? { extraInstructions } : {}),
    });

    const valid = validateSpecialistSpec(spec);
    if (!valid.ok) return { ok: false as const, error: valid.error };

    const agent = new Agent({
      id: name,
      name: `${role} (${name})`,
      instructions: buildSpecialistInstructions(spec),
      model: SPECIALIST_MODEL,
      tools: { web_search: webSearchTool, run_dynamic_tool: runDynamicToolTool },
      memory: buildAgencyMemory(),
    });

    registerSpecialist(
      Object.freeze({
        name,
        role,
        capabilities: Object.freeze([...capabilities]),
        activeTaskCount: 0,
        maxConcurrent,
      }),
      agent,
    );

    await recordEvent({
      kind: 'specialist_created',
      taskId: 'roster',
      detail: { name, role, capabilities, maxConcurrent, ...(extraInstructions !== undefined ? { extraInstructions } : {}) },
    });

    return { ok: true as const, name, role, capabilities, maxConcurrent };
  },
});
