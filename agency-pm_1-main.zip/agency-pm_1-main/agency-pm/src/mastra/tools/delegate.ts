import { createTool } from '@mastra/core/tools';
import { z } from 'zod';
import { selectAssignee } from '../../domain/assignment.js';
import { loadBoard, recordEvent, setAssignee } from '../../adapters/task-repo.js';
import { adjustLoad, getSpecialist, listRoster } from '../registry.js';

/**
 * Delegation is the PM's core move. The assignee is chosen deterministically
 * by the tested domain rule (capability match, then lowest utilisation, then
 * name); when no one fits, the structured failure tells the PM exactly which
 * law-2 action to take next. The specialist runs synchronously and its answer
 * comes back to the PM, who then judges status (law 8: "show me the tests")
 * and records it via update_task_status + sync_trackers.
 */
export const delegateTaskTool = createTool({
  id: 'delegate_task',
  description:
    'Assign a planned task to the best-fit specialist and hand them a brief. Selection is by capability match and lowest utilisation. On failure you get a structured reason: capability_gap -> create_specialist; no_single_match -> split the task or create a combined specialist; at_capacity -> re-prioritise or grow the team. The specialist works the brief and you receive their full response to review.',
  inputSchema: z.object({
    taskId: z.string().min(1),
    brief: z
      .string()
      .min(1)
      .describe(
        'The delegation brief: context, acceptance criteria, and the reminder that tests come first. Only include facts you can back up.',
      ),
  }),
  execute: async ({ taskId, brief }) => {
    const board = await loadBoard();
    if (!board.ok) return { ok: false as const, error: board.error };

    const task = board.value.find((t) => t.id === taskId);
    if (task === undefined) return { ok: false as const, error: `no task with id "${taskId}"` };

    const choice = selectAssignee(task, listRoster());
    if (!choice.ok) return { ok: false as const, failure: choice.error };

    const entry = getSpecialist(choice.value.name);
    if (entry === undefined) {
      return { ok: false as const, error: `roster out of sync: "${choice.value.name}" has no agent` };
    }

    const assigned = await setAssignee(taskId, choice.value.name);
    if (!assigned.ok) return { ok: false as const, error: assigned.error };

    adjustLoad(choice.value.name, +1);
    await recordEvent({ kind: 'delegated', taskId, detail: { assignee: choice.value.name } });

    try {
      const response = await entry.agent.generate(
        [
          `# Delegated task: ${task.title} (${task.id})`,
          task.description !== undefined ? `\n${task.description}\n` : '',
          `\n## Brief from Atlas (PM)\n${brief}`,
          `\n## Non-negotiables\n- TDD: failing test first, implementation second, paste the green run as evidence.`,
          `- Do not state anything as fact without a source; label assumptions as assumptions.`,
          `- If you are blocked, say "BLOCKED:" followed by exactly what you need.`,
        ].join(''),
        {
          memory: {
            resource: `specialist:${choice.value.name}`,
            thread: `task:${taskId}`,
          },
        },
      );
      return {
        ok: true as const,
        assignee: choice.value.name,
        specialistResponse: response.text,
      };
    } catch (cause) {
      return {
        ok: false as const,
        error: `specialist run failed: ${cause instanceof Error ? cause.message : String(cause)}`,
        assignee: choice.value.name,
      };
    } finally {
      adjustLoad(choice.value.name, -1);
    }
  },
});

export const listTeamTool = createTool({
  id: 'list_team',
  description:
    'List the current specialist roster: name, role, capabilities, and live load (active tasks vs max concurrent).',
  inputSchema: z.object({}),
  execute: async () => ({ ok: true as const, roster: listRoster() }),
});
