import { createTool } from '@mastra/core/tools';
import { z } from 'zod';
import { draftTasks } from '../../domain/planning.js';
import { readyTasks, validateTaskGraph } from '../../domain/task-graph.js';
import { CANONICAL_STATUSES, type CanonicalStatus, type Task } from '../../domain/types.js';
import { loadBoard, recordEvent, setTaskStatus, upsertTasks } from '../../adapters/task-repo.js';

const statusSchema = z.enum(
  CANONICAL_STATUSES as [CanonicalStatus, ...CanonicalStatus[]],
);

const compact = (task: Task) =>
  Object.freeze({
    id: task.id,
    title: task.title,
    status: task.status,
    assignee: task.assignee,
    deps: task.deps,
    requiredCapabilities: task.requiredCapabilities,
    updatedAt: new Date(task.updatedAt).toISOString(),
    external: task.external,
  });

export const planTasksTool = createTool({
  id: 'plan_tasks',
  description:
    'Decompose an objective into a dependency-ordered task graph and persist it to the canonical board. Rejects duplicate ids, unknown dependencies, and cycles before anything is saved. Returns the tasks that are immediately ready to delegate.',
  inputSchema: z.object({
    objective: z.string().min(1).describe('The objective this plan delivers'),
    tasks: z
      .array(
        z.object({
          id: z.string().min(1).describe('Stable slug, e.g. "landing-hero-copy"'),
          title: z.string().min(1),
          description: z.string().optional(),
          deps: z.array(z.string()).default([]).describe('Ids of tasks that must be done first'),
          requiredCapabilities: z
            .array(z.string())
            .default([])
            .describe('Capabilities the assignee must have, e.g. ["frontend", "tdd"]'),
        }),
      )
      .min(1),
  }),
  execute: async ({ objective, tasks }) => {
    const drafted = draftTasks(tasks, Date.now());

    const valid = validateTaskGraph(drafted);
    if (!valid.ok) return { ok: false as const, error: valid.error };

    const saved = await upsertTasks(drafted);
    if (!saved.ok) return { ok: false as const, error: saved.error };

    await recordEvent({
      kind: 'planned',
      taskId: drafted[0]?.id ?? 'unknown',
      detail: { objective, taskIds: drafted.map((t) => t.id) },
    });

    return {
      ok: true as const,
      planned: drafted.length,
      ready: readyTasks(drafted).map((t) => t.id),
    };
  },
});

export const updateTaskStatusTool = createTool({
  id: 'update_task_status',
  description:
    'Set the canonical status of a task (todo | in_progress | blocked | in_review | done | cancelled) with an optional note. Cancellations require a reason in the note — that is the recorded sign-off. Follow every status change with sync_trackers.',
  inputSchema: z.object({
    taskId: z.string().min(1),
    status: statusSchema,
    note: z
      .string()
      .optional()
      .describe('Evidence for done, reason for cancelled, context for blocked'),
  }),
  execute: async ({ taskId, status, note }) => {
    if (status === 'cancelled' && (note === undefined || note.trim().length === 0)) {
      return {
        ok: false as const,
        error: 'cancellation requires a recorded reason in `note` (law 5: nothing left unfinished without sign-off)',
      };
    }
    const result = await setTaskStatus(taskId, status, note);
    return result.ok
      ? { ok: true as const, task: compact(result.value) }
      : { ok: false as const, error: result.error };
  },
});

export const getBoardTool = createTool({
  id: 'get_board',
  description:
    'Read the full canonical task board: every task with status, assignee, dependencies, and tracker refs, plus which tasks are ready to delegate right now.',
  inputSchema: z.object({}),
  execute: async () => {
    const board = await loadBoard();
    if (!board.ok) return { ok: false as const, error: board.error };
    return {
      ok: true as const,
      tasks: board.value.map(compact),
      ready: readyTasks(board.value).map((t) => t.id),
    };
  },
});
