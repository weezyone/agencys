import { createTool } from '@mastra/core/tools';
import { z } from 'zod';
import { resolveTie } from '../../domain/tiebreak.js';
import { recordEvent } from '../../adapters/task-repo.js';

/**
 * Law 6: the PM is the tie-breaker, but the decision must be auditable.
 * Options are scored against explicit criteria, the PM supplies the weights,
 * and the tested domain rule produces a deterministic winner with arithmetic
 * in the rationale. Exact ties fall back to lexicographic id — arbitrary,
 * deterministic, and said out loud. Every decision is journaled.
 */
export const breakTieTool = createTool({
  id: 'break_tie',
  description:
    'Resolve a disagreement or evenly-matched choice. Provide each option with numeric scores per criterion, plus your weights for those criteria. Returns a deterministic winner, full ranking, and a rationale showing the arithmetic. The decision is recorded and final unless new evidence arrives.',
  inputSchema: z.object({
    question: z.string().min(1).describe('What is being decided'),
    options: z
      .array(
        z.object({
          id: z.string().min(1),
          label: z.string().min(1),
          scores: z
            .record(z.string(), z.number())
            .describe('Numeric score per criterion, e.g. {"speed": 7, "risk": 3}'),
        }),
      )
      .min(2),
    weights: z
      .record(z.string(), z.number())
      .describe('Your weighting per criterion; criteria must appear in option scores'),
    taskId: z.string().optional().describe('Related task, if any'),
  }),
  execute: async ({ question, options, weights, taskId }) => {
    const decision = resolveTie(options, weights);
    if (!decision.ok) return { ok: false as const, error: decision.error };

    await recordEvent({
      kind: 'tie_broken',
      taskId: taskId ?? 'decision',
      detail: { question, options, weights, decision: decision.value },
    });

    return { ok: true as const, ...decision.value };
  },
});
