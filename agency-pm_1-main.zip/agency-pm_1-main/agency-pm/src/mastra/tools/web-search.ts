import { createTool } from '@mastra/core/tools';
import { z } from 'zod';
import { searchWeb } from '../../adapters/exa.js';

/**
 * Web access for the PM and every specialist, via Exa search-and-contents.
 * Law 7 lives or dies on this tool: claims get verified here before they are
 * stated as fact, and results carry URLs so citations are checkable.
 */
export const webSearchTool = createTool({
  id: 'web_search',
  description:
    'Search the web with Exa and return results with title, URL, published date, and a content excerpt. Use this to verify any claim before stating it as fact, to research solutions for blocked tasks, and to audit citations in teammate deliverables.',
  inputSchema: z.object({
    query: z.string().min(1).describe('Natural-language search query'),
    numResults: z
      .number()
      .int()
      .min(1)
      .max(10)
      .optional()
      .describe('How many results to return (default 5)'),
  }),
  execute: async ({ query, numResults }) => {
    const result = await searchWeb(query, numResults ?? 5);
    return result.ok
      ? { ok: true as const, results: result.value }
      : { ok: false as const, error: result.error };
  },
});
