import { createTool } from '@mastra/core/tools';
import { z } from 'zod';
import { buildHttpExecutor, validateHttpToolSpec, type HttpToolSpec } from '../../factory/tool-spec.js';
import { recordEvent } from '../../adapters/task-repo.js';
import { getDynamicTool, listDynamicTools, registerDynamicTool } from '../registry.js';

const inputTypeSchema = z.enum(['string', 'number', 'boolean']);

/**
 * Law 3: tool the work. Dynamic tools are declarative HTTP specs — validated,
 * compiled, and template-rendered — never runtime-eval'd code. Secrets stay
 * server-side: a spec references {{secret:NAME}} and the executor resolves it
 * from process env at call time, so credentials never pass through any model.
 */
export const createHttpToolTool = createTool({
  id: 'create_http_tool',
  description:
    'Create a new HTTP tool from a declarative spec when no existing tool fits the job. Declare every input the templates use; reference credentials as {{secret:ENV_VAR_NAME}} in headers — they are resolved server-side and never pass through you. The spec is validated and journaled, then immediately runnable via run_dynamic_tool (by you or any specialist).',
  inputSchema: z.object({
    name: z
      .string()
      .regex(/^[a-z][a-z0-9_-]*$/, 'lowercase slug, starting with a letter')
      .describe('Unique tool slug, e.g. "figma-get-file"'),
    description: z.string().min(1).describe('What the tool does and when to use it'),
    method: z.enum(['GET', 'POST', 'PUT', 'PATCH', 'DELETE']),
    urlTemplate: z
      .string()
      .min(1)
      .describe('http(s) URL with {{placeholders}}, e.g. "https://api.figma.com/v1/files/{{fileKey}}"'),
    headers: z
      .record(z.string(), z.string())
      .optional()
      .describe('Header templates; use {{secret:NAME}} for credentials'),
    bodyTemplate: z
      .string()
      .optional()
      .describe('Request body template with {{placeholders}}'),
    inputs: z
      .array(z.object({ name: z.string().min(1), type: inputTypeSchema }))
      .describe('Every placeholder the templates use must be declared here'),
  }),
  execute: async ({ name, description, method, urlTemplate, headers, bodyTemplate, inputs }) => {
    if (getDynamicTool(name) !== undefined) {
      return { ok: false as const, error: `tool "${name}" already exists` };
    }

    const spec: HttpToolSpec = Object.freeze({
      name,
      description,
      method,
      urlTemplate,
      ...(headers !== undefined ? { headers: Object.freeze({ ...headers }) } : {}),
      ...(bodyTemplate !== undefined ? { bodyTemplate } : {}),
      inputs: Object.freeze(
        inputs.map((i: { name: string; type: 'string' | 'number' | 'boolean' }) =>
          Object.freeze({ ...i }),
        ),
      ),
    });

    const valid = validateHttpToolSpec(spec);
    if (!valid.ok) return { ok: false as const, error: valid.error };

    registerDynamicTool(spec);
    await recordEvent({ kind: 'tool_created', taskId: 'toolbox', detail: { spec } });

    return { ok: true as const, name, runWith: 'run_dynamic_tool' };
  },
});

export const runDynamicToolTool = createTool({
  id: 'run_dynamic_tool',
  description:
    'Run a previously created HTTP tool by name with its declared inputs. Returns the HTTP status and parsed body. Call with no name to list available dynamic tools.',
  inputSchema: z.object({
    name: z.string().optional().describe('Tool slug; omit to list available tools'),
    input: z
      .record(z.string(), z.union([z.string(), z.number(), z.boolean()]))
      .default({})
      .describe('Values for the declared inputs'),
  }),
  execute: async ({ name, input }) => {
    if (name === undefined) {
      return {
        ok: true as const,
        available: listDynamicTools().map((t) => ({
          name: t.name,
          description: t.description,
          inputs: t.inputs,
        })),
      };
    }

    const spec = getDynamicTool(name);
    if (spec === undefined) {
      return {
        ok: false as const,
        error: `no dynamic tool named "${name}" — create it with create_http_tool`,
      };
    }

    const result = await buildHttpExecutor(spec)(input, {
      fetchImpl: fetch,
      secrets: process.env,
    });

    return result.ok
      ? { ok: true as const, status: result.value.status, body: result.value.body }
      : { ok: false as const, error: result.error };
  },
});
