import { createTool } from '@mastra/core/tools';
import { z } from 'zod';
import { sweep } from '../../domain/progress.js';
import type { Task } from '../../domain/types.js';
import { loadBoard } from '../../adapters/task-repo.js';

const DEFAULT_STALE_AFTER_MS = 24 * 60 * 60 * 1000;

const staleAfterDefault = (): number => {
  const raw = process.env.STALE_AFTER_MS;
  const parsed = raw === undefined ? Number.NaN : Number(raw);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : DEFAULT_STALE_AFTER_MS;
};

const brief = (task: Task) =>
  Object.freeze({
    id: task.id,
    title: task.title,
    status: task.status,
    assignee: task.assignee,
    lastTouched: new Date(task.updatedAt).toISOString(),
  });

/**
 * Law 4: monitor relentlessly. The sweep buckets every task into
 * needs_unblock / stale / on_track / closed using the tested assessment rule.
 * Blocked work always surfaces as needs_unblock — unblocking is the PM's own
 * work and is never deferred.
 */
export const runStatusSweepTool = createTool({
  id: 'run_status_sweep',
  description:
    'Sweep the whole board and bucket every task: needs_unblock (blocked — act now), stale (no movement past the threshold — check in), on_track, and closed. Run this after every batch of delegations and on a regular cadence.',
  inputSchema: z.object({
    staleAfterHours: z
      .number()
      .positive()
      .optional()
      .describe('Override the staleness threshold (default 24h or STALE_AFTER_MS env)'),
  }),
  execute: async ({ staleAfterHours }) => {
    const board = await loadBoard();
    if (!board.ok) return { ok: false as const, error: board.error };

    const staleAfterMs =
      staleAfterHours !== undefined ? staleAfterHours * 60 * 60 * 1000 : staleAfterDefault();

    const report = sweep(board.value, Date.now(), { staleAfterMs });

    return {
      ok: true as const,
      staleAfterMs,
      needs_unblock: report.needs_unblock.map(brief),
      stale: report.stale.map(brief),
      on_track: report.on_track.map(brief),
      closed: report.closed.map(brief),
    };
  },
});
