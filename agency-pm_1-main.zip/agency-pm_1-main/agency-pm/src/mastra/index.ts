import { Mastra } from '@mastra/core';
import { projectManagerAgent } from './agents/project-manager.js';
import { buildMongoStorage } from './memory.js';




/**
 * Application entrypoint. `mastra dev` serves Atlas with a playground and
 * REST API; the same MongoDB instance backs agent memory (threads, working
 * memory, semantic recall) and the canonical task board — one database to
 * observe everything.
 */
export const mastra = new Mastra({
  agents: { projectManagerAgent },
  storage: buildMongoStorage(),
});
