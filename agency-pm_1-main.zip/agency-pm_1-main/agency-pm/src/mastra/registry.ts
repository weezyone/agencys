import type { Agent } from '@mastra/core/agent';
import type { Teammate } from '../domain/types.js';
import type { HttpToolSpec } from '../factory/tool-spec.js';

/**
 * Runtime registries for dynamically created teammates and tools.
 *
 * This is the one place in the codebase with module-level state, and it is
 * deliberate: the roster and toolbox ARE mutable runtime resources — agents
 * get hired mid-project. The state is encapsulated behind a small functional
 * surface; nothing else reaches in.
 *
 * Durability note (honest limitation): registries live in process memory.
 * Specialist specs and tool specs are also journaled to MongoDB via the
 * task event log so a restarted process can be re-hydrated, but automatic
 * re-hydration on boot is left as a documented next step in the README.
 */

type RosterEntry = Readonly<{ teammate: Teammate; agent: Agent }>;

const roster = new Map<string, RosterEntry>();
const dynamicTools = new Map<string, HttpToolSpec>();

export const registerSpecialist = (teammate: Teammate, agent: Agent): void => {
  roster.set(teammate.name, Object.freeze({ teammate, agent }));
};

export const getSpecialist = (name: string): RosterEntry | undefined => roster.get(name);

export const listRoster = (): ReadonlyArray<Teammate> =>
  Object.freeze([...roster.values()].map((entry) => entry.teammate));

export const adjustLoad = (name: string, delta: number): void => {
  const entry = roster.get(name);
  if (entry === undefined) return;
  roster.set(
    name,
    Object.freeze({
      ...entry,
      teammate: Object.freeze({
        ...entry.teammate,
        activeTaskCount: Math.max(0, entry.teammate.activeTaskCount + delta),
      }),
    }),
  );
};

export const registerDynamicTool = (spec: HttpToolSpec): void => {
  dynamicTools.set(spec.name, spec);
};

export const getDynamicTool = (name: string): HttpToolSpec | undefined =>
  dynamicTools.get(name);

export const listDynamicTools = (): ReadonlyArray<HttpToolSpec> =>
  Object.freeze([...dynamicTools.values()]);
