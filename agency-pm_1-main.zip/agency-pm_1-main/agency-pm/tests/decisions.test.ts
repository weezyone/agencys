import { describe, expect, it } from 'vitest';
import { resolveTie } from '../src/domain/tiebreak.js';
import { assessTask, sweep } from '../src/domain/progress.js';
import type { Task } from '../src/domain/types.js';

describe('resolveTie', () => {
  const options = [
    { id: 'rest', label: 'REST API', scores: { speed: 9, scalability: 5 } },
    { id: 'graphql', label: 'GraphQL', scores: { speed: 5, scalability: 9 } },
  ];

  it('weights decide the winner and the rationale shows its work', () => {
    const speedFirst = resolveTie(options, { speed: 2, scalability: 1 });
    expect(speedFirst.ok && speedFirst.value.winner).toBe('rest');

    const scaleFirst = resolveTie(options, { speed: 1, scalability: 2 });
    expect(scaleFirst.ok && scaleFirst.value.winner).toBe('graphql');
    if (scaleFirst.ok) {
      expect(scaleFirst.value.rationale).toContain('graphql');
      expect(scaleFirst.value.ranking).toHaveLength(2);
    }
  });

  it('is deterministic on exact ties: lexicographic id order, documented in rationale', () => {
    const tied = [
      { id: 'beta', label: 'B', scores: { x: 1 } },
      { id: 'alpha', label: 'A', scores: { x: 1 } },
    ];
    const result = resolveTie(tied, { x: 1 });
    expect(result.ok && result.value.winner).toBe('alpha');
    if (result.ok) expect(result.value.rationale).toContain('deterministic');
  });

  it('rejects an empty option set and unknown score keys in weights', () => {
    expect(resolveTie([], { x: 1 }).ok).toBe(false);
    const result = resolveTie(options, { vibes: 1 });
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error).toContain('vibes');
  });
});

describe('progress monitoring', () => {
  const policy = { staleAfterMs: 60_000 };
  const t = (overrides: Partial<Task>): Task => ({
    id: 'x',
    title: 'x',
    deps: [],
    status: 'in_progress',
    requiredCapabilities: [],
    assignee: 'ada',
    updatedAt: 0,
    external: {},
    ...overrides,
  });

  it('classifies tasks: closed, needs_unblock, stale, on_track', () => {
    expect(assessTask(t({ status: 'done' }), 1, policy)).toBe('closed');
    expect(assessTask(t({ status: 'cancelled' }), 1, policy)).toBe('closed');
    expect(assessTask(t({ status: 'blocked' }), 1, policy)).toBe('needs_unblock');
    expect(assessTask(t({ updatedAt: 0 }), 61_000, policy)).toBe('stale');
    expect(assessTask(t({ updatedAt: 0 }), 59_000, policy)).toBe('on_track');
  });

  it('a blocked task is needs_unblock even if recently updated', () => {
    expect(assessTask(t({ status: 'blocked', updatedAt: 100 }), 200, policy)).toBe(
      'needs_unblock',
    );
  });

  it('sweep groups a board without mutating it', () => {
    const board = [
      t({ id: 'a', status: 'done' }),
      t({ id: 'b', status: 'blocked' }),
      t({ id: 'c', updatedAt: 0 }),
      t({ id: 'd', updatedAt: 100_000 }),
    ];
    const snapshot = JSON.parse(JSON.stringify(board));
    const groups = sweep(board, 120_000, policy);
    expect(groups.closed.map((x) => x.id)).toEqual(['a']);
    expect(groups.needs_unblock.map((x) => x.id)).toEqual(['b']);
    expect(groups.stale.map((x) => x.id)).toEqual(['c']);
    expect(groups.on_track.map((x) => x.id)).toEqual(['d']);
    expect(board).toEqual(snapshot);
  });
});
