import { describe, expect, it } from 'vitest';
import {
  DEFAULT_MONDAY_STATUS_LABELS,
  fromGitHub,
  fromLinearStateType,
  fromMondayLabel,
  outboundOps,
  reconcile,
  toGitHubState,
  toLinearStateType,
  toMondayLabel,
} from '../src/domain/sync.js';
import type { Task } from '../src/domain/types.js';

const task = (overrides: Partial<Task>): Task => ({
  id: 'PAU-1',
  title: 'Build settings page',
  deps: [],
  status: 'todo',
  requiredCapabilities: [],
  assignee: null,
  updatedAt: 1_000,
  external: {},
  ...overrides,
});

describe('canonical status mapping', () => {
  it('maps Linear workflow state types to canonical statuses', () => {
    expect(fromLinearStateType('backlog')).toBe('todo');
    expect(fromLinearStateType('unstarted')).toBe('todo');
    expect(fromLinearStateType('started')).toBe('in_progress');
    expect(fromLinearStateType('completed')).toBe('done');
    expect(fromLinearStateType('canceled')).toBe('cancelled');
  });

  it('maps canonical statuses to Linear state types, collapsing rich states to started', () => {
    expect(toLinearStateType('todo')).toBe('unstarted');
    expect(toLinearStateType('in_progress')).toBe('started');
    expect(toLinearStateType('blocked')).toBe('started');
    expect(toLinearStateType('in_review')).toBe('started');
    expect(toLinearStateType('done')).toBe('completed');
    expect(toLinearStateType('cancelled')).toBe('canceled');
  });

  it('maps GitHub issue state lossily and honestly', () => {
    expect(fromGitHub({ state: 'closed', stateReason: 'completed' })).toBe('done');
    expect(fromGitHub({ state: 'closed', stateReason: 'not_planned' })).toBe('cancelled');
    // an open issue tells us only that work is not finished
    expect(fromGitHub({ state: 'open', stateReason: null })).toBe('non_terminal');

    expect(toGitHubState('done')).toEqual({ state: 'closed', stateReason: 'completed' });
    expect(toGitHubState('cancelled')).toEqual({ state: 'closed', stateReason: 'not_planned' });
    expect(toGitHubState('in_progress')).toEqual({ state: 'open', stateReason: null });
  });

  it('maps monday labels both ways via configurable mapping', () => {
    const labels = DEFAULT_MONDAY_STATUS_LABELS;
    expect(toMondayLabel('blocked', labels)).toBe('Stuck');
    expect(fromMondayLabel('Stuck', labels)).toEqual({ ok: true, value: 'blocked' });
    const unknown = fromMondayLabel('Vibing', labels);
    expect(unknown.ok).toBe(false);
  });
});

describe('outboundOps', () => {
  it('returns no ops when every connected tracker already matches', () => {
    const t = task({
      status: 'in_progress',
      external: { linearIssueId: 'lin_1', githubIssueNumber: 7, mondayItemId: 'm1' },
    });
    const ops = outboundOps(t, {
      linear: { stateType: 'started' },
      github: { state: 'open', stateReason: null },
      monday: { label: 'Working on it' },
    });
    expect(ops).toEqual([]);
  });

  it('emits minimal set_status ops only for drifted trackers', () => {
    const t = task({
      status: 'done',
      external: { linearIssueId: 'lin_1', githubIssueNumber: 7, mondayItemId: 'm1' },
    });
    const ops = outboundOps(t, {
      linear: { stateType: 'completed' }, // already correct
      github: { state: 'open', stateReason: null }, // drifted
      monday: { label: 'Working on it' }, // drifted
    });
    expect(ops.map((o) => o.target).sort()).toEqual(['github', 'monday']);
    expect(ops.every((o) => o.kind === 'set_status')).toBe(true);
  });

  it('emits create ops for connected trackers the task does not exist in yet', () => {
    const t = task({ status: 'todo', external: { linearIssueId: 'lin_1' } });
    const ops = outboundOps(t, {
      linear: { stateType: 'unstarted' },
      github: null, // connected, no snapshot -> needs creation
      monday: null,
    });
    expect(ops.map((o) => `${o.kind}:${o.target}`).sort()).toEqual([
      'create:github',
      'create:monday',
    ]);
  });

  it('ignores trackers that are not configured at all', () => {
    const t = task({ status: 'todo', external: { linearIssueId: 'lin_1' } });
    const ops = outboundOps(t, { linear: { stateType: 'unstarted' } });
    expect(ops).toEqual([]);
  });
});

describe('reconcile', () => {
  const base = { localStatus: 'in_progress', lastSyncedAt: 100 } as const;

  it('noop when remote agrees with local', () => {
    expect(
      reconcile({ ...base, localUpdatedAt: 150, remoteStatus: 'in_progress', remoteUpdatedAt: 150 }),
    ).toBe('noop');
  });

  it('push when only local changed since last sync', () => {
    expect(
      reconcile({ ...base, localUpdatedAt: 150, remoteStatus: 'todo', remoteUpdatedAt: 90 }),
    ).toBe('push');
  });

  it('pull when only remote changed since last sync', () => {
    expect(
      reconcile({ ...base, localUpdatedAt: 90, remoteStatus: 'done', remoteUpdatedAt: 150 }),
    ).toBe('pull');
  });

  it('conflict when both sides changed to different statuses — PM breaks the tie', () => {
    expect(
      reconcile({ ...base, localUpdatedAt: 150, remoteStatus: 'cancelled', remoteUpdatedAt: 160 }),
    ).toBe('conflict');
  });

  it('a non_terminal remote signal never conflicts', () => {
    expect(
      reconcile({ ...base, localUpdatedAt: 150, remoteStatus: 'non_terminal', remoteUpdatedAt: 160 }),
    ).toBe('noop');
  });
});
