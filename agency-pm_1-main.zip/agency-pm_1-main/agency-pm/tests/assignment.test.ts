import { describe, expect, it } from 'vitest';
import { selectAssignee } from '../src/domain/assignment.js';
import type { Task, Teammate } from '../src/domain/types.js';

const task = (caps: ReadonlyArray<string>): Task => ({
  id: 't1',
  title: 't1',
  deps: [],
  status: 'todo',
  requiredCapabilities: caps,
  assignee: null,
  updatedAt: 0,
  external: {},
});

const mate = (
  name: string,
  capabilities: ReadonlyArray<string>,
  activeTaskCount = 0,
  maxConcurrent = 3,
): Teammate => ({ name, role: name, capabilities, activeTaskCount, maxConcurrent });

describe('selectAssignee', () => {
  it('picks a qualified teammate', () => {
    const result = selectAssignee(task(['frontend']), [
      mate('ada', ['frontend', 'design']),
      mate('bob', ['backend']),
    ]);
    expect(result.ok).toBe(true);
    if (result.ok) expect(result.value.name).toBe('ada');
  });

  it('balances load: lowest utilisation wins, name breaks exact ties', () => {
    const result = selectAssignee(task(['frontend']), [
      mate('ada', ['frontend'], 2, 3),
      mate('bob', ['frontend'], 1, 3),
    ]);
    expect(result.ok && result.value.name).toBe('bob');

    const tie = selectAssignee(task(['frontend']), [
      mate('zoe', ['frontend'], 1, 3),
      mate('ann', ['frontend'], 1, 3),
    ]);
    expect(tie.ok && tie.value.name).toBe('ann');
  });

  it('signals a capability gap when nobody on the roster has a required skill', () => {
    const result = selectAssignee(task(['ml-ops']), [mate('ada', ['frontend'])]);
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.error.kind).toBe('capability_gap');
      if (result.error.kind === 'capability_gap') {
        expect(result.error.missingCapabilities).toEqual(['ml-ops']);
      }
    }
  });

  it('signals no_single_match when skills exist but no one person covers them all', () => {
    const result = selectAssignee(task(['frontend', 'backend']), [
      mate('ada', ['frontend']),
      mate('bob', ['backend']),
    ]);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error.kind).toBe('no_single_match');
  });

  it('signals at_capacity when all qualified teammates are maxed out', () => {
    const result = selectAssignee(task(['frontend']), [mate('ada', ['frontend'], 3, 3)]);
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.error.kind).toBe('at_capacity');
      if (result.error.kind === 'at_capacity') {
        expect(result.error.qualified).toEqual(['ada']);
      }
    }
  });
});
