import { describe, expect, it } from 'vitest';
import {
  readyTasks,
  topologicalOrder,
  validateTaskGraph,
} from '../src/domain/task-graph.js';
import type { Task } from '../src/domain/types.js';

const task = (overrides: Partial<Task> & Pick<Task, 'id'>): Task => ({
  title: overrides.id,
  deps: [],
  status: 'todo',
  requiredCapabilities: [],
  assignee: null,
  updatedAt: 0,
  external: {},
  ...overrides,
});

describe('validateTaskGraph', () => {
  it('accepts a valid DAG', () => {
    const tasks = [
      task({ id: 'design' }),
      task({ id: 'build', deps: ['design'] }),
      task({ id: 'ship', deps: ['build'] }),
    ];
    expect(validateTaskGraph(tasks)).toEqual({ ok: true, value: true });
  });

  it('rejects duplicate task ids', () => {
    const result = validateTaskGraph([task({ id: 'a' }), task({ id: 'a' })]);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error).toContain('duplicate');
  });

  it('rejects dependencies on unknown tasks', () => {
    const result = validateTaskGraph([task({ id: 'a', deps: ['ghost'] })]);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error).toContain('ghost');
  });

  it('rejects dependency cycles', () => {
    const result = validateTaskGraph([
      task({ id: 'a', deps: ['b'] }),
      task({ id: 'b', deps: ['a'] }),
    ]);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error).toContain('cycle');
  });

  it('rejects a self-dependency (1-cycle)', () => {
    const result = validateTaskGraph([task({ id: 'a', deps: ['a'] })]);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error).toContain('cycle');
  });
});

describe('topologicalOrder', () => {
  it('orders dependencies before dependents', () => {
    const result = topologicalOrder([
      task({ id: 'ship', deps: ['build', 'qa'] }),
      task({ id: 'build', deps: ['design'] }),
      task({ id: 'qa', deps: ['build'] }),
      task({ id: 'design' }),
    ]);
    expect(result.ok).toBe(true);
    if (result.ok) {
      const order = result.value;
      const pos = (id: string) => order.indexOf(id);
      expect(pos('design')).toBeLessThan(pos('build'));
      expect(pos('build')).toBeLessThan(pos('qa'));
      expect(pos('qa')).toBeLessThan(pos('ship'));
      expect(order).toHaveLength(4);
    }
  });

  it('is deterministic: equal-rank tasks come out in id order', () => {
    const tasks = [task({ id: 'b' }), task({ id: 'a' }), task({ id: 'c' })];
    const first = topologicalOrder(tasks);
    const second = topologicalOrder([...tasks].reverse());
    expect(first).toEqual(second);
    if (first.ok) expect(first.value).toEqual(['a', 'b', 'c']);
  });

  it('fails on cyclic input', () => {
    const result = topologicalOrder([
      task({ id: 'a', deps: ['b'] }),
      task({ id: 'b', deps: ['a'] }),
    ]);
    expect(result.ok).toBe(false);
  });
});

describe('readyTasks', () => {
  it('returns only todo tasks whose dependencies are all done', () => {
    const tasks = [
      task({ id: 'design', status: 'done' }),
      task({ id: 'build', deps: ['design'], status: 'todo' }),
      task({ id: 'qa', deps: ['build'], status: 'todo' }),
      task({ id: 'copy', status: 'in_progress' }),
    ];
    expect(readyTasks(tasks).map((t) => t.id)).toEqual(['build']);
  });

  it('treats cancelled dependencies as not satisfied', () => {
    const tasks = [
      task({ id: 'design', status: 'cancelled' }),
      task({ id: 'build', deps: ['design'], status: 'todo' }),
    ];
    expect(readyTasks(tasks)).toEqual([]);
  });

  it('does not mutate its input', () => {
    const tasks = [task({ id: 'a', status: 'done' }), task({ id: 'b', deps: ['a'] })];
    const snapshot = JSON.parse(JSON.stringify(tasks));
    readyTasks(tasks);
    expect(tasks).toEqual(snapshot);
  });
});
