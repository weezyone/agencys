import { describe, expect, it, vi } from 'vitest';
import { buildSpecialistInstructions, validateSpecialistSpec } from '../src/factory/agent-spec.js';
import { applySyncOps, type TrackerPort } from '../src/adapters/trackers.js';
import type { SyncOp } from '../src/domain/sync.js';

describe('specialist agent factory', () => {
  const spec = {
    name: 'motion-designer',
    role: 'Motion design specialist',
    capabilities: ['motion-design', 'after-effects'],
  };

  it('accepts a valid spec and rejects bad names or empty capabilities', () => {
    expect(validateSpecialistSpec(spec).ok).toBe(true);
    expect(validateSpecialistSpec({ ...spec, name: 'Motion Designer!!' }).ok).toBe(false);
    expect(validateSpecialistSpec({ ...spec, capabilities: [] }).ok).toBe(false);
  });

  it('generated instructions carry the non-negotiables: TDD, no fabrication, report blockers', () => {
    const instructions = buildSpecialistInstructions(spec);
    expect(instructions).toContain('motion-design');
    expect(instructions.toLowerCase()).toContain('test');
    expect(instructions.toLowerCase()).toContain('blocked');
    expect(instructions.toLowerCase()).toContain('do not invent');
  });
});

describe('applySyncOps', () => {
  const ops: ReadonlyArray<SyncOp> = [
    { kind: 'set_status', target: 'linear', taskId: 'PAU-1', status: 'done' },
    { kind: 'set_status', target: 'github', taskId: 'PAU-1', status: 'done' },
    { kind: 'create', target: 'monday', taskId: 'PAU-1' },
  ];

  const port = (overrides: Partial<TrackerPort> = {}): TrackerPort => ({
    setStatus: vi.fn().mockResolvedValue({ ok: true, value: 'updated' }),
    createTask: vi.fn().mockResolvedValue({ ok: true, value: 'ext_1' }),
    ...overrides,
  });

  it('routes each op to the right tracker port', async () => {
    const linear = port();
    const github = port();
    const monday = port();
    const report = await applySyncOps(ops, { linear, github, monday });

    expect(linear.setStatus).toHaveBeenCalledWith('PAU-1', 'done');
    expect(github.setStatus).toHaveBeenCalledWith('PAU-1', 'done');
    expect(monday.createTask).toHaveBeenCalledWith('PAU-1');
    expect(report.applied).toHaveLength(3);
    expect(report.failed).toHaveLength(0);
  });

  it('keeps going when one tracker fails and reports the failure honestly', async () => {
    const github = port({
      setStatus: vi.fn().mockResolvedValue({ ok: false, error: 'rate limited' }),
    });
    const report = await applySyncOps(ops, { linear: port(), github, monday: port() });
    expect(report.applied).toHaveLength(2);
    expect(report.failed).toEqual([
      { op: ops[1], error: 'rate limited' },
    ]);
  });

  it('fails ops aimed at a tracker that has no configured port', async () => {
    const report = await applySyncOps(ops, { linear: port() });
    expect(report.applied).toHaveLength(1);
    expect(report.failed).toHaveLength(2);
    expect(report.failed.every((f) => f.error.includes('not configured'))).toBe(true);
  });
});
