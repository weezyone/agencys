import { describe, expect, it } from 'vitest';
import { pushOps } from '../src/domain/sync.js';
import type { Task } from '../src/domain/types.js';

const task = (overrides: Partial<Task>): Task =>
  Object.freeze({
    id: 't1',
    title: 'Task one',
    deps: [],
    status: 'in_progress',
    requiredCapabilities: [],
    assignee: 'kai',
    updatedAt: 0,
    external: {},
    ...overrides,
  });

describe('pushOps', () => {
  it('creates items on configured trackers the task is missing from', () => {
    const ops = pushOps(task({ external: {} }), ['linear', 'github', 'monday']);

    expect(ops).toEqual([
      { kind: 'create', target: 'linear', taskId: 't1' },
      { kind: 'create', target: 'github', taskId: 't1' },
      { kind: 'create', target: 'monday', taskId: 't1' },
    ]);
  });

  it('pushes status where an external ref already exists', () => {
    const ops = pushOps(
      task({
        status: 'blocked',
        external: { linearIssueId: 'lin_1', githubIssueNumber: 7, mondayItemId: 'm9' },
      }),
      ['linear', 'github', 'monday'],
    );

    expect(ops).toEqual([
      { kind: 'set_status', target: 'linear', taskId: 't1', status: 'blocked' },
      { kind: 'set_status', target: 'github', taskId: 't1', status: 'blocked' },
      { kind: 'set_status', target: 'monday', taskId: 't1', status: 'blocked' },
    ]);
  });

  it('ignores trackers that are not configured', () => {
    const ops = pushOps(
      task({ external: { githubIssueNumber: 7 } }),
      ['github'],
    );

    expect(ops).toEqual([
      { kind: 'set_status', target: 'github', taskId: 't1', status: 'in_progress' },
    ]);
  });

  it('never creates tracker items for terminal tasks, but still pushes their status to existing refs', () => {
    const done = task({ status: 'done', external: { linearIssueId: 'lin_1' } });

    expect(pushOps(done, ['linear', 'github'])).toEqual([
      { kind: 'set_status', target: 'linear', taskId: 't1', status: 'done' },
    ]);

    const cancelledUnlinked = task({ status: 'cancelled', external: {} });
    expect(pushOps(cancelledUnlinked, ['linear', 'github', 'monday'])).toEqual([]);
  });

  it('returns a frozen op list', () => {
    expect(Object.isFrozen(pushOps(task({}), ['linear']))).toBe(true);
  });
});
