import { describe, expect, it, vi } from 'vitest';
import {
  buildHttpExecutor,
  renderTemplate,
  validateHttpToolSpec,
  type HttpToolSpec,
} from '../src/factory/tool-spec.js';

const spec: HttpToolSpec = {
  name: 'create_dribbble_shot',
  description: 'Posts a new shot to the agency Dribbble account',
  method: 'POST',
  urlTemplate: 'https://api.example.com/v1/shots/{{shotId}}',
  headers: { Authorization: 'Bearer {{secret:EXAMPLE_TOKEN}}' },
  bodyTemplate: '{"title": "{{title}}"}',
  inputs: { shotId: 'string', title: 'string' },
};

describe('validateHttpToolSpec', () => {
  it('accepts a well-formed spec', () => {
    expect(validateHttpToolSpec(spec).ok).toBe(true);
  });

  it('rejects bad names, non-http urls, and undeclared template variables', () => {
    const badName = validateHttpToolSpec({ ...spec, name: 'Bad Name!' });
    expect(badName.ok).toBe(false);

    const badUrl = validateHttpToolSpec({ ...spec, urlTemplate: 'ftp://nope/{{shotId}}' });
    expect(badUrl.ok).toBe(false);

    const undeclared = validateHttpToolSpec({
      ...spec,
      bodyTemplate: '{"title": "{{mystery}}"}',
    });
    expect(undeclared.ok).toBe(false);
    if (!undeclared.ok) expect(undeclared.error).toContain('mystery');
  });
});

describe('renderTemplate', () => {
  it('interpolates declared variables and fails loudly on missing ones', () => {
    expect(renderTemplate('hi {{name}}', { name: 'weezy' })).toEqual({
      ok: true,
      value: 'hi weezy',
    });
    const missing = renderTemplate('hi {{name}}', {});
    expect(missing.ok).toBe(false);
  });

  it('leaves secret placeholders alone — secrets never pass through the model', () => {
    const result = renderTemplate('Bearer {{secret:TOKEN}}', {});
    expect(result).toEqual({ ok: true, value: 'Bearer {{secret:TOKEN}}' });
  });
});

describe('buildHttpExecutor', () => {
  it('renders url/body, resolves secrets from the environment side, and calls fetch', async () => {
    const fetchImpl = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ id: 'shot_9' }), {
        status: 201,
        headers: { 'content-type': 'application/json' },
      }),
    );

    const execute = buildHttpExecutor(spec);
    const result = await execute(
      { shotId: '42', title: 'Neon grid' },
      { fetchImpl, secrets: { EXAMPLE_TOKEN: 'tok_abc' } },
    );

    expect(fetchImpl).toHaveBeenCalledOnce();
    const [url, init] = fetchImpl.mock.calls[0]!;
    expect(url).toBe('https://api.example.com/v1/shots/42');
    expect(init.method).toBe('POST');
    expect(init.headers.Authorization).toBe('Bearer tok_abc');
    expect(JSON.parse(init.body)).toEqual({ title: 'Neon grid' });

    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.value.status).toBe(201);
      expect(result.value.body).toEqual({ id: 'shot_9' });
    }
  });

  it('reports missing secrets as an error instead of sending a broken request', async () => {
    const fetchImpl = vi.fn();
    const execute = buildHttpExecutor(spec);
    const result = await execute(
      { shotId: '42', title: 'x' },
      { fetchImpl, secrets: {} },
    );
    expect(result.ok).toBe(false);
    expect(fetchImpl).not.toHaveBeenCalled();
  });
});
