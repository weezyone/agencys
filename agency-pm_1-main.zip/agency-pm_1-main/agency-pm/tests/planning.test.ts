import { describe, expect, it } from 'vitest';
import { draftTasks } from '../src/domain/planning.js';

const NOW = 1_750_000_000_000;

describe('draftTasks', () => {
  it('maps plan input onto canonical defaults', () => {
    const tasks = draftTasks(
      [
        {
          id: 'design-tokens',
          title: 'Extract design tokens',
          deps: [],
          requiredCapabilities: ['design-systems'],
        },
      ],
      NOW,
    );

    expect(tasks).toHaveLength(1);
    expect(tasks[0]).toEqual({
      id: 'design-tokens',
      title: 'Extract design tokens',
      deps: [],
      status: 'todo',
      requiredCapabilities: ['design-systems'],
      assignee: null,
      updatedAt: NOW,
      external: {},
    });
  });

  it('keeps description only when provided', () => {
    const [withDesc, withoutDesc] = draftTasks(
      [
        { id: 'a', title: 'A', description: 'details', deps: [], requiredCapabilities: [] },
        { id: 'b', title: 'B', deps: [], requiredCapabilities: [] },
      ],
      NOW,
    );

    expect(withDesc?.description).toBe('details');
    expect(withoutDesc !== undefined && 'description' in withoutDesc).toBe(false);
  });

  it('defaults deps and requiredCapabilities to empty arrays when omitted', () => {
    const [task] = draftTasks([{ id: 'solo', title: 'Solo task' }], NOW);

    expect(task?.deps).toEqual([]);
    expect(task?.requiredCapabilities).toEqual([]);
  });

  it('returns frozen tasks in a frozen list', () => {
    const tasks = draftTasks([{ id: 'x', title: 'X' }], NOW);

    expect(Object.isFrozen(tasks)).toBe(true);
    expect(Object.isFrozen(tasks[0])).toBe(true);
  });
});
