# agency-pm — Atlas, a delegation-only project manager agent

A [Mastra](https://mastra.ai) agent that runs delivery for an AI agency without doing the delivery itself. Atlas decomposes objectives into dependency-ordered task graphs, delegates every task to specialist agents (hiring new ones when the roster can't cover a capability), monitors progress, unblocks stuck work, breaks ties with auditable arithmetic, and keeps Linear, GitHub, and monday.com converged to one canonical board in MongoDB.

## Quick start

```bash
npm install
cp .env.example .env        # fill in OPENAI_API_KEY, OPENROUTER_API_KEY, MONGODB_URI, EXA_API_KEY at minimum
npm run verify              # tests + typecheck — should be green before anything else
npm run dev                 # mastra dev: playground + REST API for Atlas
```

MongoDB must be **Atlas** (cloud) or **Atlas Local via Docker** — semantic recall uses Atlas Vector Search, which a plain community `mongod` does not provide ([Mastra MongoDB reference](https://mastra.ai/reference/storage/mongodb)).

```bash
docker run -d -p 27017:27017 mongodb/mongodb-atlas-local
# MONGODB_URI=mongodb://localhost:27017/?directConnection=true
```

Trackers are optional and independently configured: the sync tool only touches a tracker whose env vars are all present (`LINEAR_API_KEY`+`LINEAR_TEAM_ID`, `GITHUB_TOKEN`+`GITHUB_OWNER`+`GITHUB_REPO`, `MONDAY_API_TOKEN`+`MONDAY_BOARD_ID`).

## How Atlas works

**The canonical board is the source of truth.** Tasks live in MongoDB (`pm_tasks`) with a six-state lifecycle (`todo → in_progress → blocked/in_review → done | cancelled`). Linear, GitHub, and monday.com are lossy *projections* of this model — each tracker maps the canonical status into whatever vocabulary it speaks (`src/domain/sync.ts` holds all three mappings, tested in both directions).

**Delegation, never execution.** `plan_tasks` validates the task graph (duplicate ids, unknown deps, and cycles are rejected before anything persists), `delegate_task` picks the assignee deterministically — capability match first, then lowest utilisation, then name — and runs the specialist with the brief. When nobody fits, the tool returns a structured failure that tells Atlas exactly which lever to pull: `capability_gap` → `create_specialist`, `no_single_match` → split the task or hire a hybrid, `at_capacity` → re-prioritise or grow the team.

**Dynamic teammates and tools.** `create_specialist` builds a real Mastra `Agent` from a validated spec; the agency's laws (TDD first, no fabrication, functional style, report blocked immediately, finish what you start) are baked into every hire by the tested instruction factory. `create_http_tool` accepts a **declarative HTTP spec** — validated templates, declared inputs, `{{secret:NAME}}` placeholders resolved server-side at call time — never runtime-eval'd code, and credentials never pass through any model. `run_dynamic_tool` executes them.

**Monitoring and unblocking.** `run_status_sweep` buckets the whole board: `needs_unblock` (blocked — Atlas acts now, researching with `web_search` where needed), `stale` (no movement past the threshold), `on_track`, `closed`. Unblocking is the PM's own work and its instructions say so.

**Tie-breaking.** `break_tie` is deterministic and auditable: explicit criteria scores, explicit weights, full ranking, rationale showing the arithmetic, exact ties broken lexicographically and stated out loud. Every decision is journaled.

**Observable memory.** All state is plain MongoDB you can open in Compass: agent threads/messages/working memory (Mastra's `MongoDBStore`), vector recall (`MongoDBVector` + local `fastembed` embeddings — no extra API key), the task board (`pm_tasks`), and an append-only event journal (`pm_events`: planned, delegated, status_changed, tie_broken, specialist_created, tool_created, sync_applied).

## TDD receipts

This repo was built red-first, and the discipline is enforced on the team by Atlas's instructions (law 8: "show me the tests").

- Domain + factories + sync seam: **6 test files written before implementation, 6/6 failing**, then implemented to green.
- Tool-layer pure logic (`draftTasks`, `pushOps`): tests written first, confirmed failing, then implemented.
- Final state: **8 files, 55/55 passing** (`vitest run`), `tsc --noEmit` clean under `strict` + `exactOptionalPropertyTypes` + `noUncheckedIndexedAccess`.

What the tests cover: graph validation and deterministic topological order, ready-task gating (cancelled deps don't satisfy), assignment selection and all three failure modes, every status mapping for all three trackers in both directions, push-op derivation, reconcile decisions (including conflict detection for the future inbound path), tie-break arithmetic and determinism, monitor bucketing, HTTP tool spec validation/template rendering/secret resolution, specialist spec validation and law-baking, and the sync engine against fake tracker ports (sequential application, honest failure reporting, unconfigured-tracker handling).

I/O adapter internals (Mongo queries, SDK calls) are thin, typed pass-throughs verified by the compiler against real SDK types rather than unit-tested with mocks — mocking an SDK only tests the mock.

## Verified vs. assumed

Per the no-fabrication rule, here is exactly what is verified and what is an assumption:

| Claim | Status | Evidence |
| --- | --- | --- |
| `MongoDBStore`/`MongoDBVector` constructor shape (`{ id, uri, dbName }`) | Verified | [storage ref](https://mastra.ai/reference/storage/mongodb), [vector ref](https://mastra.ai/reference/vectors/mongodb) + compiles against `@mastra/mongodb@1.9.1` |
| Atlas Vector Search required for semantic recall | Verified (docs) | Same Mastra MongoDB reference |
| `createTool` v1 signature (`execute: async (inputData)`) | Verified | [create-tool ref](https://mastra.ai/reference/tools/create-tool) + compiles against `@mastra/core@1.41.0` |
| Agent model routing strings (`openai/gpt-4o`, `openrouter/openai/gpt-4o`) | Verified (docs) | [agent ref](https://mastra.ai/reference/agents/agent), [OpenRouter gateway](https://mastra.ai/models/gateways/openrouter) |
| Exa `searchAndContents` usage | Verified | [Exa quickstart](https://docs.exa.ai/reference/quickstart) + compiles against `exa-js@2.13.0` |
| Linear: status set via workflow-state lookup by `type` + `updateIssue({ stateId })` | Verified | [Linear SDK docs](https://linear.app/developers/sdk) + compiles against `@linear/sdk@86.0.0` |
| GitHub: `issues.update` with `state`/`state_reason`, `issues.create` | Verified | [REST issues docs](https://docs.github.com/en/rest/issues/issues) + compiles against `octokit@5.0.5` |
| monday.com: `change_simple_column_value` / `create_item` mutations | Verified (docs) | [monday column API](https://developer.monday.com/api-reference/reference/columns) |
| Your monday board's status **column id** is `status` | **Assumption** | Column ids are workspace-specific — check yours and set `MONDAY_STATUS_COLUMN_ID` |
| Your monday board's status **label text** matches the defaults | **Assumption** | Override with `MONDAY_STATUS_LABELS` JSON if your labels differ |
| Live end-to-end calls against Linear/GitHub/monday/Exa/Atlas | **Not exercised here** | No credentials in the build environment; surfaces are compiler-verified, behaviour is doc-sourced |

## Design decisions worth knowing

- **TypeScript, not plain JS.** Mastra is TypeScript-native, and in a codebase whose prime directive is "never present something as fact without backing," types are executable documentation — the compiler is the cheapest auditor you'll ever hire. The functional discipline you asked for is throughout: pure domain functions, `Object.freeze` immutability, `Result` discriminated unions instead of thrown control flow, composition over classes, and the one deliberate piece of module state (the runtime roster/toolbox registry) is documented as exactly that.
- **Push-mode sync today, reconcile tomorrow.** `sync_trackers` projects canonical state outward (create where missing — unless the task is already terminal — push status where linked) and persists new tracker ids back onto the task. The richer read-back path (`outboundOps` + `reconcile`, where a genuine both-sides-changed conflict is detected and routed to `break_tie`) is implemented and tested in the domain, ready for inbound webhooks.
- **Registry durability (honest limitation).** Dynamically created specialists and tools live in process memory; their specs are journaled to `pm_events`, but automatic re-hydration on boot is a documented next step, not a shipped feature.
- **Delegation is synchronous in v1.** `delegate_task` awaits the specialist and hands Atlas the full response to judge (tests shown? sources cited?) before Atlas sets `in_review`/`done`/`blocked` and syncs. Parallel fan-out is a natural next step once you want it.

## Layout

```
src/
  domain/      pure, tested logic: task graph, assignment, sync mappings,
               push ops, reconcile, tie-break, progress, planning, Result
  factory/     validated specs -> specialists & declarative HTTP tools
  adapters/    I/O edges: Mongo task repo + event journal, Linear, GitHub,
               monday.com, Exa, tracker port seam
  mastra/      the app: Atlas agent, tools, memory wiring, registry, entrypoint
tests/         8 suites, 55 tests, written before the code they test
```
