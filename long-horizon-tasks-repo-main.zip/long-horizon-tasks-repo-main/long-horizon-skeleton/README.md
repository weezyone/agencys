# Long-horizon task skeleton

A minimal codebase for starting **Codex-style long-horizon tasks**: multi-step, agent-driven work with durable memory and continuous verification.

Based on learnings from [OpenAI’s “Run long-horizon tasks with Codex”](https://developers.openai.com/blog/run-long-horizon-tasks-with-codex/) and the agent loop: **Plan → Edit → Run tools → Observe → Repair → Update docs → Repeat**.

## How to use this skeleton

1. **Copy this folder** (or clone the repo) when starting a new long-horizon task.
2. **Fill in the durable memory files** (the agent will revisit these):
   - **SPEC.md** — Goal, requirements, constraints, definition of done.
   - **PLANS.md** — Checkpointed milestones with acceptance criteria.
   - **IMPLEMENT.md** — Already contains the runbook; adjust commands if you change the stack.
   - **STATUS.md** — Append after each verified step (live audit log).
   - **AGENTS.md** — Root-level agent guidance; edit if your commands or conventions differ.
3. **Run the loop:** Plan a small step → edit code → `npm run verify` → repair until it passes → update STATUS.md → repeat.
4. **Optional:** Use Git worktrees to isolate parallel runs and keep diffs reviewable.

## Verification

After any code change, run:

```bash
npm run verify
```

This runs **lint → typecheck → test → build** in order. Do not proceed to the next milestone until it passes.

Individual commands:

| Command            | Purpose        |
|--------------------|----------------|
| `npm run verify`   | Full gate      |
| `npm run lint`     | ESLint         |
| `npm run typecheck`| TypeScript     |
| `npm run test`     | Vitest         |
| `npm run build`    | Emit to `dist/`|

Or use the script:

```bash
./scripts/verify.sh
```

## Layout

```
long-horizon-skeleton/
├── AGENTS.md       # Agent guidance (read first)
├── SPEC.md         # Requirements and constraints
├── PLANS.md        # Milestones and acceptance criteria
├── IMPLEMENT.md    # Runbook for the agent loop
├── STATUS.md       # Live audit log
├── src/            # Application source
├── tests/          # Unit tests
├── scripts/        # verify.sh and other helpers
└── package.json    # Scripts and deps
```

## Stack

- **Runtime:** Node (ESM)
- **Language:** TypeScript
- **Lint:** ESLint 9 + typescript-eslint
- **Tests:** Vitest
- **Build:** `tsc` → `dist/`

Replace or extend this stack as needed; keep the same pattern: durable memory files + a single `verify` gate the agent must pass before moving on.
