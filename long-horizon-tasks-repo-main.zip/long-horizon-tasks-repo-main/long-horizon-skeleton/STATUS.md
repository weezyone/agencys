# Status — live audit log

Append entries after each verified step. Keeps the run inspectable and prevents lost context.

---

## YYYY-MM-DD HH:MM — _Short title_

- **Milestone:** _e.g. Milestone 1_
- **Done:** _What was completed._
- **Verify:** Passed (lint, typecheck, test, build).

---

_Example:_

## 2025-03-05 14:00 — Skeleton setup

- **Milestone:** Initial setup
- **Done:** Created SPEC, PLANS, IMPLEMENT, STATUS, AGENTS; added verify script and placeholder src/tests.
- **Verify:** Passed.

---
