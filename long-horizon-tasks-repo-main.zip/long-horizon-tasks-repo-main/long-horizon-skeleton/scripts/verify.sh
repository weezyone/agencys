#!/usr/bin/env bash
# Full verification gate for long-horizon runs. Exit on first failure.
set -e
cd "$(dirname "$0")/.."
echo "> lint"
npm run lint
echo "> typecheck"
npm run typecheck
echo "> test"
npm run test
echo "> build"
npm run build
echo "> verify passed"
