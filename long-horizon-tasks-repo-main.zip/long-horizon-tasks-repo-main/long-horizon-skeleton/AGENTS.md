# Agent guidance (long-horizon tasks)

This repo is set up for Codex-style long-horizon work. Read this file and the runbook before making changes.

## Navigation and state

- **SPEC.md** — Requirements, constraints, and definition of done. Revisit often to avoid drift.
- **PLANS.md** — Milestones and acceptance criteria. Complete and verify one milestone before the next.
- **IMPLEMENT.md** — Runbook: agent loop, commands to run, and when to run them.
- **STATUS.md** — Live audit log. Update after each verified step so the run stays inspectable.

## Commands you must run

After editing code, run verification **before** moving on:

```bash
npm run verify
```

This runs (in order): lint → typecheck → test → build. Do not start the next milestone until `verify` passes.

Individual commands (for repair loops):

- `npm run lint` — Lint
- `npm run typecheck` — TypeScript check
- `npm run test` — Unit tests
- `npm run build` — Build

## Conventions

- Keep changes small and milestone-scoped.
- After fixing failures, run `npm run verify` again until it passes, then update **STATUS.md**.
- Prefer functional style and modern JS/TS; no inline imports (keep imports at top of file).

## Recovery

If something breaks, isolate to the current milestone in PLANS.md. Fix, re-run `verify`, then continue. Do not skip verification.
