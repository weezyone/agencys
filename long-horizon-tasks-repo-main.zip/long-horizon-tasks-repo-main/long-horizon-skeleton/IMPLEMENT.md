# Implement — agent runbook

This is the runbook for the agent loop. Follow it on every cycle.

## Loop (repeat until done)

1. **Plan** — Read SPEC.md and PLANS.md. Decide the next small step (one milestone or part of one).
2. **Edit** — Make the code changes.
3. **Verify** — Run:
   ```bash
   npm run verify
   ```
4. **Observe** — Check stdout/stderr. If anything failed, go to step 5; else go to step 6.
5. **Repair** — Fix the failing tests/lint/typecheck/build. Go back to step 3.
6. **Update** — Append to STATUS.md what was completed and that verify passed. If the milestone is done, mark it in PLANS.md. Then go to step 1 for the next chunk, or stop if the spec is done.

## Verification commands

| Command            | Purpose        |
|--------------------|----------------|
| `npm run verify`   | Full gate: lint + typecheck + test + build |
| `npm run lint`     | Lint only      |
| `npm run typecheck`| TypeScript only|
| `npm run test`     | Tests only     |
| `npm run build`    | Build only     |

## Done when

- All acceptance criteria in SPEC.md and PLANS.md are satisfied.
- `npm run verify` passes.
- STATUS.md is up to date.

Do not mark the task complete until all of the above hold.
