# Plans — checkpointed milestones

Break the work into discrete milestones. Complete and verify one before starting the next.

## Milestone 1: _Name_

**Goal:** _One sentence._

**Acceptance criteria:**

- [ ] _Criterion 1_
- [ ] _Criterion 2_
- [ ] `npm run verify` passes

**Notes:** _Optional._

---

## Milestone 2: _Name_

**Goal:** _One sentence._

**Acceptance criteria:**

- [ ] _Criterion 1_
- [ ] `npm run verify` passes

---

## Milestone 3: _Name_

**Goal:** _One sentence._

**Acceptance criteria:**

- [ ] _Criterion 1_
- [ ] `npm run verify` passes

---

_Add or remove milestones as needed. Keep each milestone small enough to verify and repair within one loop._
