/**
 * Entry point. Replace with your application logic.
 */
export function greet(name: string): string {
  return `Hello, ${name}`;
}
