# Specification

Replace this with the actual spec for your long-horizon task. The agent will revisit this file to stay aligned.

## Goal

_Describe the high-level goal and outcome._

## Requirements

- _Requirement 1_
- _Requirement 2_
- _Add more as needed_

## Constraints

- _Constraint 1 (e.g. tech stack, performance, compatibility)_
- _Constraint 2_

## Definition of done

- [ ] _Criterion 1_
- [ ] _Criterion 2_
- [ ] All verification commands pass (`npm run verify`)
- [ ] STATUS.md updated with completed steps

## Out of scope

- _What this task explicitly does not include_
