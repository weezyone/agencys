# Executive Summary

Running 'long-horizon tasks' with OpenAI Codex refers to the capabilities of the new, autonomous software engineering agent system introduced around 2025, which is fundamentally different from the original Codex API that was deprecated and shut down in March 2023. The original Codex was a stateless code generation model, whereas the new Codex is a stateful agent designed to execute end-to-end, multi-step software projects that can span hours or even days. These long-horizon tasks involve a continuous loop of planning, implementing code, running tools like tests and builds, observing the results, and repairing errors. This modern system, powered by advanced models such as 'codex-1' (an o3-based model) and the GPT-5 series, is designed to 'stay coherent for longer, complete larger chunks of work end-to-end, and recover from errors without losing the thread.' Therefore, any discussion of long-horizon capabilities pertains exclusively to this current agentic framework, not the legacy API.

# Codex Evolution Overview

OpenAI Codex has evolved through two distinct phases. The first phase began in 2021 with the introduction of the original Codex, a GPT language model fine-tuned on publicly available code from GitHub. This version was accessible via an API using models such as 'code-davinci-001', 'code-davinci-002', and 'code-cushman-001'. It was primarily a code generation tool that could translate natural language prompts into code. While groundbreaking, its limitations included 'difficulty with docstrings describing long chains of operations and with binding operations to variables.' This original Codex API was officially deprecated and shut down on March 23, 2023, with users advised to migrate to newer GPT models.

The second and current phase, emerging around 2025, represents a paradigm shift from a code generation tool to a full-fledged autonomous software engineering agent. This new Codex is powered by significantly more advanced models, starting with 'codex-1' (a version of OpenAI's 'o3' model optimized for software engineering) and later 'GPT-5.2-Codex'. This system is designed for long-horizon, complex tasks. It features long-context understanding (tested up to 192k tokens), reliable tool calling, and the ability to 'iteratively run tests until it receives a passing result.' It achieves state-of-the-art performance on agentic benchmarks like SWE-Bench Pro and is capable of handling large-scale refactors, migrations, and feature builds by working in large repositories over extended sessions without losing context.

# New Codex Agent Description

The current iteration of Codex, from 2025 onwards, is an autonomous software engineering agent designed to perform complex, end-to-end tasks. Powered by codex-1, an OpenAI o3-class model optimized for software engineering, this agent operates within a secure cloud environment to independently work on codebases. Its capabilities include writing new features from scratch, debugging issues, executing tests, and refactoring large codebases. Unlike earlier versions, which were primarily API-based code completion tools, the modern Codex is an agent-focused system that can manage long-running tasks over hours or days. It is engineered to work within large repositories, maintaining context and coherence throughout extended sessions to complete significant chunks of work, such as code migrations and full feature builds, from planning to completion.

# Long Horizon Task Capabilities

The new Codex agent's ability to perform long-horizon tasks is supported by several key capabilities. Firstly, it can maintain coherence over extended periods, allowing it to work on tasks for hours or even days without losing track of the overall objective. This is crucial for large-scale work like repository-wide refactors or building features from scratch. Secondly, it excels at multi-step execution, operating in a disciplined loop of planning, implementing, validating with tools (like tests and linters), observing feedback, and repairing errors before repeating the cycle. Thirdly, the agent has robust error recovery mechanisms, enabling it to 'recover from errors without losing the thread,' which is essential for tasks that inevitably encounter failures. These capabilities are underpinned by technical improvements in the underlying model, including long-context understanding (tested up to 192k tokens), reliable tool calling, and the ability to iteratively run tests until a passing result is achieved, ensuring it can work effectively in large repositories with full context intact.

# Codex Agent Loop

## Summary

The Codex agent operates in a disciplined, iterative cycle designed for software development. This loop enables it to tackle complex tasks by breaking them down into manageable steps involving planning, implementation, continuous verification via tools, observation of feedback, and self-correction before documenting progress and repeating the process.

## Planning Phase

This is the initial stage where the agent formulates a strategy to address the given task. It often involves consulting in-repository files like `SPEC.md` for requirements and `PLANS.md` for milestones and acceptance criteria to create a clear path forward.

## Execution And Feedback Phase

In this core stage, the agent actively implements the plan by editing code. Immediately after, it runs a suite of tools such as tests, build scripts, and linters. It then observes the output, including logs and file diffs, to gather direct feedback on the success and correctness of its changes.

## Repair And Update Phase

Following the feedback phase, if any failures or errors were detected (e.g., failed tests), the agent enters a repair stage to fix the issues. Once the code passes all verification checks, the agent updates documentation or status files (like `STATUS.md`) to log its progress before beginning the next cycle of the loop.


# Key Techniques For Long Tasks

## Technique

Durable Project Memory

## Description

This involves maintaining key project documents—such as specifications (`SPEC.md`), plans (`PLANS.md`), constraints, and live status logs (`STATUS.md`)—as markdown files directly within the code repository. The agent is instructed to revisit these files repeatedly throughout its run.

## Purpose

To prevent 'drift' from the original objectives and maintain a stable 'definition of done' over long periods, ensuring the agent stays on track.

## Technique

Continuous Verification

## Description

The agent is configured to automatically run a suite of verification commands (e.g., unit tests, integration tests, linters, type checkers, build scripts) after making code changes and before proceeding to the next step.

## Purpose

To ensure code quality, provide immediate execution-based feedback, catch errors as they are introduced, and serve as a quality gate that must be passed before making further progress.

## Technique

Checkpointed Milestones

## Description

Large tasks are broken down into smaller, discrete milestones, each with its own clear acceptance criteria. These are often defined in a `PLANS.md` file. The agent must complete and verify one milestone before starting the next.

## Purpose

To structure the long-horizon task, provide clear points for progress tracking and human review, and enable easier recovery from failures by isolating them to a specific milestone.

## Technique

Clear Runbooks and Guidance Files

## Description

Providing explicit instructions to the agent through files like `IMPLEMENT.md` (a 'runbook' for the agent's loop and commands) and `AGENTS.md`. The `AGENTS.md` files, placed in relevant directories, guide the agent on how to navigate the codebase, which commands to run, and how to adhere to project conventions.

## Purpose

To steer the agent's behavior, enforce coding standards and best practices, and ensure it uses the correct tools and processes for the specific repository.

## Technique

Structured Context and Harness

## Description

Utilizing a dedicated CLI or 'Codex surface' that provides the agent with structured information about its environment, including repository metadata, file trees, code diffs, and the outputs of commands it runs.

## Purpose

To give the agent a clear, organized view of the repository and the state of its work, which is essential for making correct decisions over many steps.

## Technique

Isolation with Git Worktrees

## Description

Using Git worktrees to create isolated environments for different agent runs or parallel tasks within the same repository.

## Purpose

To prevent concurrent tasks from interfering with each other and to keep the resulting code changes (diffs) clean, isolated, and easily reviewable by humans.


# Steering And Configuration

## Primary Method

AGENTS.md files

## File Purpose

To inform the Codex agent on how to navigate the codebase, which specific commands to run for testing, how to adhere to the project's standard practices and coding conventions, and how to format pull requests.

## File Scope

The instructions provided in an AGENTS.md file apply at the repository scope, guiding the agent's behavior within the entire directory tree where the file is located.


# Example Long Horizon Projects

## Project Name

Design tool built from scratch

## Summary

This project was a documented stress test where the Codex agent was tasked with building a complete design tool from only a high-level specification. The goal was to demonstrate the agent's ability to maintain coherence over an extended period, execute a complex plan with multiple milestones, verify its own work, and recover from errors without human intervention. The success of this multi-day run was attributed to a structured approach involving durable project memory (using SPEC.md, PLANS.md, etc.) and a continuous, execution-based verification loop.

## Key Metrics

The task ran for approximately 25 hours uninterrupted, consumed about 13 million tokens, and resulted in the generation of roughly 30,000 lines of code.

## Implemented Capabilities

The agent demonstrated long-run coherence by following a disciplined agent loop: Plan → Edit code → Run tools (tests/build/lint) → Observe results → Repair failures → Update documentation → Repeat. It utilized durable project memory by repeatedly consulting markdown files for the specification, plan, and constraints to prevent strategic drift. It also performed continuous verification by running test, lint, and build commands at checkpointed milestones and repairing any failures before proceeding.


# Current Codex Models And Availability

The new OpenAI Codex agent is powered by advanced models specifically optimized for software engineering, including 'codex-1', which is a version of OpenAI's o3 model, and 'GPT-5.2-Codex'. These models are designed for long-horizon tasks, featuring capabilities such as long-context understanding (tested up to 192k tokens), reliable tool calling, and the ability to iteratively run tests until a passing result is achieved. This modern agent-focused system is distinct from the original Codex API models (e.g., code-davinci-002, code-cushman-001), which were officially deprecated and shut down on March 23, 2023. Users can interact with and orchestrate the new Codex agent through specific tooling referred to as 'Codex CLI' and 'Codex surfaces'.

# Original Codex Model Description

The original Codex model, introduced in 2021, was a GPT (Generative Pre-trained Transformer) language model developed by OpenAI. It was specifically fine-tuned on a massive dataset of publicly available source code sourced from GitHub. This specialized training distinguished it from general-purpose GPT models by equipping it with a deep understanding of programming languages and coding patterns. As detailed in the foundational 2021 paper by Chen et al., this model was designed to translate natural language into code. It powered the first version of GitHub Copilot, providing code suggestions and completions to developers. The research highlighted its capabilities but also noted limitations, such as difficulties with prompts that required long sequences of operations or complex variable bindings, which are challenges that can compound in long-horizon tasks.

# Original Codex Research And Benchmarks

## Summary

Research on the original Codex model, introduced in 2021, focused on its ability to generate functionally correct code from natural language prompts. The foundational paper introduced the 'pass@k' metric, which measures the model's success rate over multiple attempts, finding that repeated sampling was a highly effective strategy for improving results. Researchers also identified key limitations, including the model's difficulty in handling prompts that described long, sequential chains of operations and challenges with correctly binding operations to variables. Subsequent research explored its capabilities in adjacent software engineering tasks, such as automated program repair (APR). A notable study found that Codex, despite not being specifically trained for bug fixing, was surprisingly effective and competitive with state-of-the-art APR techniques, validating the potential of using iterative feedback loops for code correction.

## Humaneval Performance

The performance of the original Codex model was evaluated on the HumanEval benchmark, a test suite designed to measure the functional correctness of code generated from docstrings. According to the foundational 2021 paper, the model was able to solve 28.8% of the problems on this benchmark. A key finding from this evaluation was that using a strategy of repeated sampling, known as pass@k, was 'surprisingly effective' in generating a correct solution. This method involves generating multiple code samples (k samples) and checking if any of them pass the unit tests, which significantly increases the probability of success compared to a single-shot generation.

## Program Repair Evaluation

The original Codex model's ability to fix bugs was evaluated using the multi-language QuixBugs benchmark, which contains 40 bugs in both Python and Java. A 2021 study found that Codex was 'surprisingly effective' at automated program repair (APR), achieving results that were competitive with contemporary state-of-the-art techniques, even though it had not been specifically fine-tuned for this task. The findings showed that the model was more successful at repairing bugs in Python code compared to Java. This research validated the concept of using iterative repair loops, a core component of modern long-horizon coding agents, with large language models.

## Foundational Paper

The foundational paper for the original Codex model is titled 'Evaluating Large Language Models Trained on Code' (Chen et al., 2021). The reference provided in the context is arXiv:2107.03374.


# Deprecation Of Original Codex

## Deprecation Date

The original Codex API models were officially deprecated on March 20, 2023, with a full shutdown occurring on March 23, 2023.

## Deprecated Models

The specific models that were shut down as part of this deprecation included 'code-davinci-002', 'code-davinci-001', 'code-cushman-002', and 'code-cushman-001'.

## Recommended Replacement

At the time of the deprecation in March 2023, OpenAI's official guidance recommended that users migrate their applications to the 'gpt-4o' model as a replacement for the deprecated Codex models.


# Comparison Old Vs New Codex

The fundamental difference between the original Codex (2021-2023) and the new Codex (2025-present) is the shift from a stateless code completion tool to a stateful autonomous agent capable of long-running task execution. 

**Original Codex (Code Completion Tool):**
*   **Interaction Model:** Operated on a one-shot generation basis. It took a prompt (e.g., a function signature and docstring) and generated a block of code in a single, stateless transaction. 
*   **State Management:** It was stateless, meaning it had no memory of previous interactions or the broader project context beyond what was provided in a single prompt. This made it susceptible to 'failure modes that accumulate over long horizons,' such as an inability to handle long chains of operations or bind variables correctly over time.
*   **Core Function:** Its primary purpose was to assist developers by generating code snippets, effectively acting as an advanced autocompletion tool.

**New Codex (Autonomous Agent):**
*   **Interaction Model:** Operates in a disciplined, continuous 'agent loop': Plan → Edit code → Run tools (tests, build, lint) → Observe results → Repair failures → Update documentation → Repeat. This is a cyclical, long-running process, not a one-shot generation.
*   **State Management:** It is inherently stateful. It maintains context over hours or days using 'durable project memory'—reading and writing to dedicated files within the code repository (e.g., `SPEC.md`, `PLANS.md`, `STATUS.md`). This allows it to track objectives, plans, and progress, preventing drift and enabling recovery from errors without 'losing the thread.'
*   **Core Function:** Its purpose is to execute end-to-end software engineering tasks, such as implementing entire features, performing large-scale refactors, or migrating codebases. It acts more like a junior developer, taking high-level instructions and working autonomously to complete them, using real-world tools for verification.

# Industry Adoption Examples


# Future Direction And Takeaways

OpenAI's stated future direction for Codex is to evolve it from a simple tool into a 'more dependable partner' and a 'trusted teammate' for developers. The focus is on enhancing its ability to tackle complex, long-horizon work by improving long-context understanding, reliable tool calling, and overall factuality. This vision positions Codex as a collaborative agent that can be entrusted with significant software engineering responsibilities.

For developers looking to leverage the new Codex for long-horizon tasks, the key takeaway is that success hinges on providing clear specifications, guardrails, and a robust verification environment. The practical recipe for effective use includes:

1.  **Prepare the Repository with Durable Memory:** Create a set of markdown files to guide the agent and maintain state. This includes `SPEC.md` for requirements and constraints, `PLANS.md` for milestones and acceptance criteria, `IMPLEMENT.md` for the agent's runbook and commands, and `STATUS.md` to serve as a live audit log. Additionally, `AGENTS.md` files can be placed in directories to provide context-specific guidance on navigation and testing.

2.  **Enable Continuous Verification:** The agent's reliability depends on its ability to test its own work. Developers must set up a reliable suite of unit/integration tests, linters, type checkers, and build commands that the agent can run locally. These commands act as quality gates at each milestone, allowing the agent to repair failures before proceeding.

3.  **Orchestrate the Agent Loop:** Use the provided Codex surfaces or CLI to manage the agent's workflow. This involves supplying structured context (like file trees and diffs), executing skills or automations, and isolating different workstreams using tools like Git worktrees to keep changes reviewable and contained.

4.  **Operate in Iterative Cycles:** Guide the agent to work in small, manageable increments. The process should be: plan a small change, implement it, run verification tools, inspect the output, repair until all checks pass, update status documentation, and then commit the changes before moving to the next increment. This allows for human oversight and course correction at key checkpoints.
