import { expect, test } from '@playwright/test';

test.describe.configure({ timeout: 10_000 });

test.describe('Team routes - auth gating', () => {
  test('GET /settings/team redirects unauthenticated users to login', async ({ page }) => {
    await page.goto('/settings/team');

    await expect(page).toHaveURL(/\/auth\/login\?redirectTo=/);
  });

  test('GET /invite/invalid-token redirects unauthenticated users to GitHub auth', async ({ page }) => {
    await page.goto('/invite/totally-invalid-token-xyz');

    await expect(page).toHaveURL(/github\.com\/login/);
  });
});

test.describe('Team API - auth protection', () => {
  test('POST /api/teams/create requires auth', async ({ request }) => {
    const res = await request.post('/api/teams/create', {
      data: { name: 'My Team' },
    });

    expect(res.status()).toBe(401);
  });

  test('GET /api/teams/list requires auth', async ({ request }) => {
    const res = await request.get('/api/teams/list');

    expect(res.status()).toBe(401);
  });

  test('POST /api/teams/invite rejects unauthenticated requests', async ({ request }) => {
    const res = await request.post('/api/teams/fake-id/invite', {
      data: { email: 'test@example.com', role: 'member' },
    });

    expect([401, 404, 500]).toContain(res.status());
  });
});
