import { expect, test } from '@playwright/test';

test.describe('Home / Dashboard', () => {
  test('loads dashboard without auth', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Cloud Dev Platform/i);
    await expect(page.getByText('Cloud Dev Platform')).toBeVisible();
  });

  test('shows login button when not authenticated', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByTestId('login-btn')).toBeVisible();
  });

  test('redirects workspace to auth when not logged in', async ({ page }) => {
    await page.goto('/workspace/test-project-id');
    await expect(page).not.toHaveURL(/\/workspace\/test-project-id$/);
  });
});
