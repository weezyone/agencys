import { expect, test } from '@playwright/test';

test.describe.configure({ timeout: 10_000 });

test.describe('Templates marketplace - public access', () => {
  test('GET /templates loads without auth', async ({ page }) => {
    await page.goto('/templates');

    await expect(page).toHaveURL(/\/templates$/);
    await expect(page.getByRole('heading', { name: /template marketplace/i })).toBeVisible();
    await expect(page.locator('body')).not.toContainText('Internal Server Error');
    await expect(page.locator('body')).not.toContainText('Application Error');
  });

  test('templates page has meaningful content', async ({ page }) => {
    await page.goto('/templates');

    const body = await page.textContent('body');
    expect(body).toBeTruthy();
    expect(body!.length).toBeGreaterThan(50);
  });

  test('template detail route renders without a server crash', async ({ page, request }) => {
    const res = await request.get('/api/templates');
    expect(res.status()).toBe(200);

    const body = (await res.json()) as {
      templates?: Array<{ id?: string; name?: string }>;
    };
    const template = body.templates?.[0];
    const templateId = template?.id ?? 'nonexistent-id-xyz';

    await page.goto(`/templates/${templateId}`);

    await expect(page.locator('body')).not.toContainText('Internal Server Error');
    await expect(page.locator('body')).not.toContainText('Application Error');

    if (template?.name) {
      await expect(page.getByRole('heading', { name: template.name })).toBeVisible();
    }
  });
});

test.describe('Templates API', () => {
  test('GET /api/templates is public (no auth required)', async ({ request }) => {
    const res = await request.get('/api/templates');
    expect(res.status()).toBe(200);

    const body = await res.json();
    expect(body).toHaveProperty('templates');
    expect(Array.isArray(body.templates)).toBe(true);
  });

  test('GET /api/templates returns categories', async ({ request }) => {
    const res = await request.get('/api/templates');
    expect(res.status()).toBe(200);

    const body = await res.json();
    expect(body).toHaveProperty('categories');
    expect(Array.isArray(body.categories)).toBe(true);
  });

  test('GET /api/templates?category=api filters results', async ({ request }) => {
    const res = await request.get('/api/templates?category=api');
    expect(res.status()).toBe(200);

    const body = await res.json();
    expect(Array.isArray(body.templates)).toBe(true);
  });

  test('GET /api/templates?search=python filters results', async ({ request }) => {
    const res = await request.get('/api/templates?search=python');
    expect(res.status()).toBe(200);

    const body = await res.json();
    expect(Array.isArray(body.templates)).toBe(true);
  });

  test('POST /api/templates/:id/use requires auth', async ({ request }) => {
    const res = await request.post('/api/templates/some-id/use', {
      data: { projectName: 'Test' },
    });

    expect(res.status()).toBe(401);
  });

  test('POST /api/templates/create requires auth', async ({ request }) => {
    const res = await request.post('/api/templates/create', {
      data: {
        category: 'api',
        description: 'Test description here',
        name: 'Test',
        tags: [],
      },
    });

    expect(res.status()).toBe(401);
  });
});
