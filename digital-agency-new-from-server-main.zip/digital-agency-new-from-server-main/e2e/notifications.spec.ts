import { expect, test } from '@playwright/test';

test.describe.configure({ timeout: 10_000 });

test.describe('Notification routes - auth gating', () => {
  test('GET /settings/notifications redirects unauthenticated users to login', async ({ page }) => {
    await page.goto('/settings/notifications');

    await expect(page).toHaveURL(/\/auth\/login\?redirectTo=/);
  });
});

test.describe('Notification API - auth protection', () => {
  test('GET /api/notifications requires auth', async ({ request }) => {
    const res = await request.get('/api/notifications');
    expect(res.status()).toBe(401);
  });

  test('POST /api/notifications/read-all requires auth', async ({ request }) => {
    const res = await request.post('/api/notifications/read-all');
    expect(res.status()).toBe(401);
  });

  test('GET /api/notifications/preferences requires auth', async ({ request }) => {
    const res = await request.get('/api/notifications/preferences');
    expect(res.status()).toBe(401);
  });

  test('GET /api/stream/notifications requires auth', async ({ request }) => {
    const res = await request.get('/api/stream/notifications');
    expect(res.status()).toBe(401);
  });
});
