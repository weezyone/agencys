import { expect, test } from '@playwright/test';

test.describe('Navigation', () => {
  test('dashboard page loads and has correct title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/Cloud/i);
  });

  test('settings page is accessible', async ({ page }) => {
    await page.goto('/settings');
    await expect(page.locator('body')).toBeVisible();
  });

  test('404 page for unknown routes', async ({ page }) => {
    const response = await page.goto('/this-route-does-not-exist-xyz');
    expect(response?.status()).not.toBe(500);
  });

  test('no console errors on homepage', async ({ page }) => {
    const errors: string[] = [];
    page.on('console', (msg) => {
      if (msg.type() === 'error') {
        errors.push(msg.text());
      }
    });

    await page.goto('/');
    await page.waitForTimeout(1000);

    const unexpectedErrors = errors.filter(
      (error) =>
        !error.includes('hydration') &&
        !error.includes('Warning:') &&
        !error.includes('favicon'),
    );

    expect(unexpectedErrors).toHaveLength(0);
  });
});
