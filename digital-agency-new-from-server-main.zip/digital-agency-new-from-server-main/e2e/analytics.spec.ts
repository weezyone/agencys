import { expect, test } from '@playwright/test';

test.describe.configure({ timeout: 10_000 });

test.describe('Analytics routes - auth gating', () => {
  test('GET /analytics redirects unauthenticated users to login', async ({ page }) => {
    await page.goto('/analytics');

    await expect(page).toHaveURL(/\/auth\/login\?redirectTo=/);
  });
});

test.describe('Analytics API - auth protection', () => {
  test('GET /api/analytics/overview requires auth', async ({ request }) => {
    const res = await request.get('/api/analytics/overview');
    expect(res.status()).toBe(401);
  });

  test('GET /api/analytics/workflows requires auth', async ({ request }) => {
    const res = await request.get('/api/analytics/workflows');
    expect(res.status()).toBe(401);
  });

  test('GET /api/analytics/ai-usage requires auth', async ({ request }) => {
    const res = await request.get('/api/analytics/ai-usage');
    expect(res.status()).toBe(401);
  });

  test('GET /api/analytics/sandboxes requires auth', async ({ request }) => {
    const res = await request.get('/api/analytics/sandboxes');
    expect(res.status()).toBe(401);
  });

  test('GET /api/analytics/export requires auth', async ({ request }) => {
    const res = await request.get('/api/analytics/export');
    expect(res.status()).toBe(401);
  });
});
