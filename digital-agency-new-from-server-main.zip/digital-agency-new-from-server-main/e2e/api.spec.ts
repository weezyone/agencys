import { expect, test } from '@playwright/test';

test.describe('API Endpoints', () => {
  test('GET /api/ai/providers returns JSON when mounted', async ({
    request,
  }) => {
    const response = await request.get('/api/ai/providers');

    if (response.status() === 200) {
      const body = await response.json();
      expect(body).toHaveProperty('providers');
      expect(Array.isArray(body.providers)).toBe(true);
      return;
    }

    expect([404, 500]).toContain(response.status());
  });

  test('POST /api/sandbox/create is protected', async ({ request }) => {
    const response = await request.post('/api/sandbox/create', {
      data: { projectId: '00000000-0000-0000-0000-000000000000' },
    });
    expect([401, 404]).toContain(response.status());
  });

  test('POST /api/ai/task is protected', async ({ request }) => {
    const response = await request.post('/api/ai/task', {
      data: { provider: 'claude', prompt: 'hello world test prompt' },
    });
    expect([401, 404]).toContain(response.status());
  });

  test('POST /api/workflow/start is protected', async ({ request }) => {
    const response = await request.post('/api/workflow/start', {
      data: {
        projectId: '00000000-0000-0000-0000-000000000000',
        task: 'Validate workflow auth protection.',
        workflowType: 'cloud-task',
      },
    });
    expect([401, 404]).toContain(response.status());
  });

  test('POST /api/git/commit is protected', async ({ request }) => {
    const response = await request.post('/api/git/commit', {
      data: {
        branch: 'main',
        files: [],
        message: 'test',
        projectId: '00000000-0000-0000-0000-000000000000',
      },
    });
    expect([401, 404]).toContain(response.status());
  });

  test('POST /api/artifacts/create with bad data is rejected', async ({
    request,
  }) => {
    const response = await request.post('/api/artifacts/create', {
      data: {},
    });
    expect([400, 401, 404]).toContain(response.status());
  });
});
