import { defineConfig } from 'vitest/config';
import path from 'path';

export default defineConfig({
  test: {
    environment: 'jsdom',
    globals: true,
    setupFiles: ['./src/test/setup.ts'],
    include: ['./app/test/**/*.{test,spec}.{ts,tsx}'],
    exclude: ['e2e/**', 'node_modules/**', '.react-router/**'],
    coverage: {
      provider: 'v8',
      reporter: ['text', 'json', 'html'],
      exclude: [
        '.react-router/**',
        'api/ai/keys.ts',
        'api/artifacts/index.ts',
        'api/git/branch.ts',
        'api/git/diff.ts',
        'api/git/pr.ts',
        'api/projects/**',
        'api/sandbox/[id].ts',
        'api/sandbox/[id]/**',
        'api/stream/**',
        'api/workflow/[id].ts',
        'app/components/**',
        'app/entry.*',
        'app/hooks/**',
        'app/lib/auth.server.ts',
        'app/lib/blob.server.ts',
        'app/lib/csrf.server.ts',
        'app/lib/git.server.ts',
        'app/root.tsx',
        'app/routes/**',
        'app/routes.ts',
        'app/types/**',
        'build/**',
        'e2e/**',
        'eslint.config.js',
        'playwright.config.ts',
        'react-router.config.ts',
        'vendor/**',
        'vite.config.ts',
      ],
      thresholds: {
        lines: 50,
        branches: 60,
        functions: 50,
        statements: 50,
      },
    },
  },
  resolve: {
    alias: {
      '~': path.resolve(__dirname, './app'),
    },
  },
});
