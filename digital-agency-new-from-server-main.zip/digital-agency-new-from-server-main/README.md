# Cloud-First AI Development Platform

A modern cloud-first development platform built with React 19.2, React Router v7, and Vercel infrastructure.

## Tech Stack

- **Frontend**: React 19.2, React Router v7, Vite 6, Tailwind CSS v4
- **Backend**: Vercel Functions, Workflow Development Kit (WDK)
- **AI**: Anthropic Claude, OpenAI Codex
- **Sandboxes**: Vercel Sandbox (Firecracker microVMs)
- **Database**: Vercel Postgres (Prisma), Vercel KV (Redis)
- **Storage**: Vercel Blob

## Getting Started

### Prerequisites

- Node.js 22+
- npm 10+
- Docker and Docker Compose for local Postgres/Redis

### Setup

```bash
npm install
# Create or update your local env file with the required variables
npm run db:setup     # Start Postgres/Redis and sync the Prisma schema
```

For local infrastructure, copy the database and Redis values from `.env.example`
into your local `.env`, then run:

```bash
npm run services:up  # Start Postgres and Redis containers
npm run db:push      # Apply the Prisma schema to local Postgres
```

Use `npm run services:down` to stop the containers while preserving their Docker
volumes, or `docker compose down -v` to remove local service data.

### Development

```bash
npm run dev          # Start dev server
npm run test:unit    # Run unit tests
npm run test:e2e     # Run E2E tests
npm run typecheck    # TypeScript check
```

### Environment Variables

Configure your local env file with the values required for your deployment.

| Variable | Purpose |
| --- | --- |
| `DATABASE_URL` | Prisma Postgres connection string. The Docker Compose default is `postgresql://copilot:copilot@localhost:5432/copilot?schema=public`. |
| `REDIS_URL` | Optional direct Redis connection string for local KV-backed presence, streams, and rate limits. The Docker Compose default is `redis://localhost:6379`. |
| `RESEND_API_KEY` | Enables notification email delivery via Resend. |
| `ADMIN_SECRET` | Protects privileged template seeding and enables service-level admin access. |
| `STRIPE_WEBHOOK_SECRET` | Verifies Stripe billing webhooks; optional in local development. |
| `GITHUB_APP_ID` | Numeric GitHub App ID used to mint app JWTs. |
| `GITHUB_APP_PRIVATE_KEY` | Base64-encoded or PEM GitHub App private key. |
| `GITHUB_APP_CLIENT_ID` | GitHub App OAuth client ID. |
| `GITHUB_APP_CLIENT_SECRET` | GitHub App OAuth client secret. |
| `GITHUB_WEBHOOK_SECRET` | HMAC secret used to validate GitHub webhooks. |
| `GITHUB_APP_SLUG` | App slug used to build the installation link in settings. |

## Architecture

See `prd.md` for full product requirements and architecture documentation.

## Features

- 🚀 **Sandbox Provisioning** — On-demand Firecracker microVM environments
- 🤖 **AI Agent Integration** — Claude Code and Codex CLI
- ⚡ **Durable Workflows** — Long-running tasks with automatic resumption
- 🔀 **Git Integration** — GitHub/GitLab commit, branch, PR automation
- 📦 **Artifact Management** — ZIP archives with signed download URLs
- 📡 **Real-time Streaming** — <300ms SSE log streaming

## Team Workspaces

Collaborative team management for shared projects, membership, and invite flows.

Key routes:
- `/settings/team`
- `/invite/:token`
- `/api/teams/create`
- `/api/teams/list`

## Usage Analytics

Workspace analytics dashboards and export endpoints for workflows, AI usage, and sandbox activity.

Key routes:
- `/analytics`
- `/api/analytics/overview`
- `/api/analytics/workflows`
- `/api/analytics/ai-usage`
- `/api/analytics/sandboxes`
- `/api/analytics/export`

## Notification System

In-app notifications with read state, preferences, streaming updates, and optional email delivery.

Key routes:
- `/settings/notifications`
- `/api/notifications`
- `/api/notifications/read-all`
- `/api/notifications/preferences`
- `/api/stream/notifications`

Required env vars:
- `RESEND_API_KEY`

## Billing & Plan Tiers

Billing combines a Prisma-backed `Subscription` record with usage enforcement across sandboxes, AI tokens, and project counts.

| Plan | Sandbox hours / month | AI tokens / month | Projects | Max vCPUs | Max timeout |
| --- | ---: | ---: | ---: | ---: | ---: |
| `FREE` | 10 | 100,000 | 3 | 2 | 30 min |
| `PRO` | 100 | 1,000,000 | 20 | 4 | 120 min |
| `TEAM` | 500 | 5,000,000 | 100 | 8 | 300 min |

Key routes:
- `/settings/billing`
- `/api/billing/usage`
- `/api/billing/upgrade`
- `/api/billing/webhook`

Use `POST /api/billing/upgrade` to move between plan tiers and `/api/billing/usage` to drive UI elements like `UsageMeter` and `UsageLimitBanner`.

## Admin Panel

The admin experience is available at `/admin` and supports detailed user drill-downs at `/admin/users/:id`.

Access is granted when either:
- the request includes a matching `ADMIN_SECRET` header, or
- the signed-in user has `isAdmin = true`

Banned users are blocked by `requireAuth`, and admin APIs provide ban/promote/revoke actions plus audit logs and platform health data.

## GitHub App Integration

GitHub App support adds app JWT generation, installation token exchange, webhook verification, and check run automation.

Required env vars:
- `GITHUB_APP_ID`
- `GITHUB_APP_PRIVATE_KEY`
- `GITHUB_APP_CLIENT_ID`
- `GITHUB_APP_CLIENT_SECRET`
- `GITHUB_WEBHOOK_SECRET`
- `GITHUB_APP_SLUG`

Key routes:
- `/settings/github-app`
- `/api/github/app-manifest`
- `/api/github/app-callback`
- `/api/github/installations`
- `/api/github/webhook`

Configure the GitHub App webhook to point at `/api/github/webhook` and use `GITHUB_WEBHOOK_SECRET` for signature validation.

## Real-Time Collaboration

Presence is stored in Vercel KV and streamed over SSE so workspace participants can see active collaborators and tabs in near real time.

Key routes:
- `/api/presence/heartbeat`
- `/api/stream/presence`

No extra environment variables are required beyond the existing KV configuration.

## Template Marketplace

Browse reusable templates, inspect template details, create custom templates, and seed built-in starter packs.

Key routes:
- `/templates`
- `/templates/:id`
- `/api/templates`
- `/api/templates/create`
- `/api/templates/seed`

Seeding instructions:
```bash
curl -X POST http://localhost:3000/api/templates/seed \
  -H "ADMIN_SECRET: $ADMIN_SECRET"
```
