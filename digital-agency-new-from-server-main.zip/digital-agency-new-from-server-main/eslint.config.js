export default [
  {
    ignores: [
      '**/*.ts',
      '**/*.tsx',
      'build/**',
      'node_modules/**',
      '.react-router/**',
    ],
  },
];
