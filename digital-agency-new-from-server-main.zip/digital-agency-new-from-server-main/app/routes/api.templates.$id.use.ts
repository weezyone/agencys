export async function loader({ request }: { request: Request }) {
  return Response.json({ error: 'Method not allowed' }, { status: 405 });
}

export async function action({ request }: { request: Request }) {
  const { default: handler } = await import('../../api/templates/[id]/use');
  return handler(request);
}
