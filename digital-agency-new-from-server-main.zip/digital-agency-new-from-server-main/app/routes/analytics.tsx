import type { LoaderFunctionArgs } from 'react-router';
import { useLoaderData } from 'react-router';
import { AnalyticsDashboardClient } from '~/components/Analytics/AnalyticsDashboardClient';
import { getOverviewMetrics, getWorkflowTimeSeries } from '~/lib/analytics.server';
import { requireAuth } from '~/lib/session.server';

export async function loader({ request }: LoaderFunctionArgs) {
  const session = await requireAuth(request);
  const userId = session.userId;
  const [overview, workflowSeries] = await Promise.all([
    getOverviewMetrics(userId, 30),
    getWorkflowTimeSeries(userId, 30),
  ]);

  return { overview, workflowSeries, userId };
}

export default function AnalyticsPage() {
  const { overview, workflowSeries, userId } = useLoaderData<typeof loader>();

  return (
    <AnalyticsDashboardClient
      initialOverview={overview}
      initialWorkflowSeries={workflowSeries}
      userId={userId}
    />
  );
}
