import { z } from 'zod';
import { upgradePlan } from '~/lib/billing.server';
import { requireAuth } from '~/lib/session.server';

const upgradePlanSchema = z.object({
  plan: z.enum(['PRO', 'TEAM']),
});

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

async function authenticate(request: Request) {
  try {
    return await requireAuth(request);
  } catch {
    return null;
  }
}

async function handler(request: Request) {
  if (request.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  const session = await authenticate(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  const payload = await request.json().catch(() => ({}));
  const parsed = upgradePlanSchema.safeParse(payload);
  if (!parsed.success) {
    return errorResponse(
      'Invalid billing upgrade payload',
      400,
      parsed.error.flatten(),
    );
  }

  try {
    const subscription = await upgradePlan(session.userId, parsed.data.plan);

    return Response.json({
      checkoutUrl: null,
      message: `Plan upgraded to ${parsed.data.plan}`,
      note: 'Stripe not configured - plan upgraded directly for demo',
      subscription,
    });
  } catch (error) {
    return errorResponse(
      'Unable to upgrade plan',
      500,
      error instanceof Error ? error.message : undefined,
    );
  }
}

export async function loader({ request }: { request: Request }) {
  return handler(request);
}

export async function action({ request }: { request: Request }) {
  return handler(request);
}
