import { useEffect, useMemo, useState } from 'react';
import type { LoaderFunctionArgs } from 'react-router';
import { useLoaderData } from 'react-router';
import { Sidebar } from '~/components/shared/Sidebar';
import { Header } from '~/components/shared/Header';
import { AIPrompt } from '~/components/Workspace/AIPrompt';
import { FileTree } from '~/components/Workspace/FileTree';
import { LogConsole } from '~/components/Workspace/LogConsole';
import { WorkflowTimeline } from '~/components/Workspace/WorkflowTimeline';
import { PresenceAvatars } from '~/components/Workspace/PresenceAvatars';
import {
  Badge,
  Button,
  Card,
  StatusIndicator,
  workflowStatusToBadgeVariant,
} from '~/components/ui';
import { getProjectById, getProjectWorkflows } from '~/lib/data.server';
import { requireAuth } from '~/lib/session.server';

const demoWorkspace = {
  activeWorkflowId: '33333333-3333-4333-8333-333333333333',
  changedPaths: ['src/index.ts', 'src/agent.ts'],
  project: {
    id: '11111111-1111-4111-8111-111111111111',
    name: 'Cloud-First AI Development Platform',
    status: 'running',
  },
  recentWorkflows: [
    {
      id: '33333333-3333-4333-8333-333333333333',
      name: 'Cloud Task Workflow',
      status: 'running',
      updatedAt: new Date(Date.now() - 1000 * 60 * 3).toISOString(),
    },
    {
      id: '44444444-4444-4444-8444-444444444444',
      name: 'Artifact Packaging',
      status: 'completed',
      updatedAt: new Date(Date.now() - 1000 * 60 * 22).toISOString(),
    },
  ],
  sandboxId: undefined as string | undefined,
};

type WorkspaceTab = 'ai' | 'workflow' | 'files';

function normalizeWorkflowStatus(status?: string | null) {
  switch ((status ?? '').toLowerCase()) {
    case 'completed':
      return 'completed';
    case 'failed':
    case 'expired':
      return 'failed';
    case 'running':
    case 'suspended':
      return 'running';
    default:
      return 'idle';
  }
}

function getPresenceTab(activeTab: WorkspaceTab) {
  return activeTab === 'workflow' ? 'logs' : activeTab;
}

export async function loader({ params, request }: LoaderFunctionArgs) {
  const user = await requireAuth(request);
  const projectId = params.projectId ?? demoWorkspace.project.id;

  if (!process.env.DATABASE_URL) {
    return { ...demoWorkspace, projectId, user };
  }

  try {
    const project = await getProjectById(projectId, user.userId);
    if (!project) {
      return { ...demoWorkspace, projectId, user };
    }

    const workflows = await getProjectWorkflows(project.id);
    const recentWorkflows = workflows.slice(0, 5).map((workflow) => ({
      id: workflow.id,
      name: workflow.name,
      status: normalizeWorkflowStatus(workflow.status),
      updatedAt: workflow.updatedAt.toISOString(),
    }));

    return {
      activeWorkflowId: workflows[0]?.id,
      changedPaths:
        workflows[0]?.steps
          .slice(0, 2)
          .map((step) => `steps/${step.stepName}.log`) ??
        demoWorkspace.changedPaths,
      project: {
        id: project.id,
        name: project.name,
        status: recentWorkflows[0]?.status ?? 'idle',
      },
      projectId,
      recentWorkflows,
      sandboxId: project.sandboxes[0]?.id,
      user,
    };
  } catch {
    return { ...demoWorkspace, projectId, user };
  }
}

export default function WorkspacePage() {
  const {
    activeWorkflowId,
    changedPaths,
    project,
    projectId,
    recentWorkflows,
    sandboxId,
    user,
  } = useLoaderData<typeof loader>();
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('ai');
  const [showFileTree, setShowFileTree] = useState(true);
  const latestWorkflow = useMemo(() => recentWorkflows[0], [recentWorkflows]);

  useEffect(() => {
    if (typeof window === 'undefined') {
      return;
    }

    const nextTab = getPresenceTab(activeTab);
    if (window.location.hash !== `#${nextTab}`) {
      window.location.hash = nextTab;
    }
  }, [activeTab]);

  return (
    <div className="min-h-screen bg-gray-950">
      <Header user={user} />
      <div className="mx-auto flex max-w-7xl flex-col gap-6 px-4 py-6 lg:flex-row">
        <Sidebar
          onToggleFileTree={() => setShowFileTree((current) => !current)}
          projectId={projectId}
          projectName={project.name}
          recentWorkflows={recentWorkflows}
        />
        <main className="min-w-0 flex-1 space-y-6">
          <div className="sticky top-4 z-10 rounded-2xl border border-gray-800 bg-gray-900/95 p-4 backdrop-blur">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
              <div className="space-y-2">
                <div className="flex flex-wrap items-center gap-3">
                  <h1 className="text-2xl font-semibold text-gray-100">
                    {project.name}
                  </h1>
                  <Badge variant={workflowStatusToBadgeVariant(project.status)}>
                    {project.status}
                  </Badge>
                  <PresenceAvatars
                    currentUser={{ id: user.userId, name: user.name }}
                    projectId={projectId}
                  />
                </div>
                <StatusIndicator
                  label={
                    latestWorkflow
                      ? `Latest workflow: ${latestWorkflow.name}`
                      : 'No active workflow'
                  }
                  status={
                    project.status === 'running'
                      ? 'running'
                      : project.status === 'failed'
                        ? 'error'
                        : 'connected'
                  }
                />
              </div>
              <div className="flex flex-wrap gap-2">
                {(
                  [
                    { key: 'ai', label: 'AI Prompt' },
                    { key: 'workflow', label: 'Workflow Monitor' },
                    { key: 'files', label: 'File Browser' },
                  ] as const
                ).map((tab) => (
                  <Button
                    key={tab.key}
                    onClick={() => setActiveTab(tab.key)}
                    variant={activeTab === tab.key ? 'primary' : 'secondary'}
                  >
                    {tab.label}
                  </Button>
                ))}
              </div>
            </div>
          </div>

          {activeTab === 'ai' ? (
            <div className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
              <AIPrompt projectId={projectId} sandboxId={sandboxId} />
              <LogConsole
                className="h-full"
                sandboxId={sandboxId}
                workflowId={activeWorkflowId}
              />
            </div>
          ) : null}

          {activeTab === 'workflow' ? (
            <div className="space-y-6">
              <WorkflowTimeline workflowId={activeWorkflowId} />
              <LogConsole sandboxId={sandboxId} workflowId={activeWorkflowId} />
            </div>
          ) : null}

          {activeTab === 'files' ? (
            showFileTree ? (
              <div className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
                <FileTree
                  changedPaths={changedPaths}
                  onSelectionChange={() => undefined}
                  sandboxId={sandboxId}
                />
                <Card
                  title="Workspace output"
                  description="Use the file browser to select files for export or inspect changed paths."
                >
                  <div className="rounded-xl border border-gray-800 bg-gray-950 p-4 text-sm text-gray-300">
                    Changed paths: {changedPaths.join(', ')}
                  </div>
                </Card>
              </div>
            ) : (
              <Card
                title="File tree hidden"
                description="Use the sidebar toggle to show the workspace file browser again."
              />
            )
          ) : null}
        </main>
      </div>
    </div>
  );
}
