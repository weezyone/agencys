import { useMemo, useState } from 'react';
import type { LoaderFunctionArgs } from 'react-router';
import { useLoaderData } from 'react-router';
import { DownloadCenter } from '~/components/Artifacts/DownloadCenter';
import { ArchiveProgress } from '~/components/Artifacts/ArchiveProgress';
import { FileSelector } from '~/components/Artifacts/FileSelector';
import { CommitInterface } from '~/components/Git/CommitInterface';
import { DiffViewer } from '~/components/Git/DiffViewer';
import { Header } from '~/components/shared/Header';
import { Sidebar } from '~/components/shared/Sidebar';
import { FileTree } from '~/components/Workspace/FileTree';
import { AIPrompt } from '~/components/Workspace/AIPrompt';
import { LogConsole } from '~/components/Workspace/LogConsole';
import { WorkflowMonitor } from '~/components/Workspace/WorkflowMonitor';
import { WorkflowTimeline } from '~/components/Workspace/WorkflowTimeline';
import {
  Badge,
  Card,
  StatusIndicator,
  Tabs,
  workflowStatusToBadgeVariant,
} from '~/components/ui';
import type { FileDiff } from '~/lib/git.server';
import { getProjectById, getProjectWorkflows } from '~/lib/data.server';
import { requireAuth } from '~/lib/session.server';

const demoWorkspace = {
  activeWorkflowId: '33333333-3333-4333-8333-333333333333',
  changedPaths: ['src/index.ts', 'src/agent.ts'],
  project: {
    branch: 'main',
    id: '11111111-1111-4111-8111-111111111111',
    name: 'Cloud-First AI Development Platform',
    repositoryUrl: '',
    status: 'running',
  },
  recentWorkflows: [
    {
      id: '33333333-3333-4333-8333-333333333333',
      name: 'Cloud Task Workflow',
      status: 'running',
      updatedAt: new Date(Date.now() - 1000 * 60 * 3).toISOString(),
    },
    {
      id: '44444444-4444-4444-8444-444444444444',
      name: 'Artifact Packaging',
      status: 'completed',
      updatedAt: new Date(Date.now() - 1000 * 60 * 22).toISOString(),
    },
  ],
  sandboxId: undefined as string | undefined,
};

function normalizeWorkflowStatus(status?: string | null) {
  switch ((status ?? '').toLowerCase()) {
    case 'completed':
      return 'completed';
    case 'failed':
    case 'expired':
      return 'failed';
    case 'running':
    case 'suspended':
      return 'running';
    default:
      return 'idle';
  }
}

function buildPreviewDiff(changedPaths: string[]): FileDiff[] {
  return changedPaths.map((path) => ({
    additions: 2,
    deletions: 1,
    filename: path,
    patch: [
      '@@ -1,2 +1,3 @@',
      '-// previous line',
      `+// preview change for ${path}`,
      '+// updated workspace content',
    ].join('\n'),
    status: 'modified',
  }));
}

export async function loader({ params, request }: LoaderFunctionArgs) {
  const user = await requireAuth(request);
  const projectId = params.projectId ?? demoWorkspace.project.id;

  if (!process.env.DATABASE_URL) {
    return { ...demoWorkspace, projectId, user };
  }

  try {
    const project = await getProjectById(projectId, user.userId);
    if (!project) {
      return { ...demoWorkspace, projectId, user };
    }

    const workflows = await getProjectWorkflows(project.id);
    const recentWorkflows = workflows.slice(0, 5).map((workflow) => ({
      id: workflow.id,
      name: workflow.name,
      status: normalizeWorkflowStatus(workflow.status),
      updatedAt: workflow.updatedAt.toISOString(),
    }));

    return {
      activeWorkflowId: workflows[0]?.id,
      changedPaths:
        workflows[0]?.steps
          .slice(0, 2)
          .map((step) => `steps/${step.stepName}.log`) ??
        demoWorkspace.changedPaths,
      project: {
        branch: project.branch,
        id: project.id,
        name: project.name,
        repositoryUrl: project.repositoryUrl ?? '',
        status: recentWorkflows[0]?.status ?? 'idle',
      },
      projectId,
      recentWorkflows,
      sandboxId: project.sandboxes[0]?.id,
      user,
    };
  } catch {
    return { ...demoWorkspace, projectId, user };
  }
}

export default function WorkspacePage() {
  const {
    activeWorkflowId,
    changedPaths,
    project,
    projectId,
    recentWorkflows,
    sandboxId,
    user,
  } = useLoaderData<typeof loader>();
  const [activeTab, setActiveTab] = useState<
    'ai' | 'downloads' | 'files' | 'git' | 'logs'
  >('ai');
  const [showFileTree, setShowFileTree] = useState(true);
  const [artifactId, setArtifactId] = useState<string | undefined>();
  const latestWorkflow = useMemo(() => recentWorkflows[0], [recentWorkflows]);
  const changedFiles = useMemo(
    () =>
      changedPaths.map((path) => ({
        content: `// Pending workspace update for ${path}\nexport const updated = true;`,
        path,
      })),
    [changedPaths],
  );
  const previewDiff = useMemo(
    () => buildPreviewDiff(changedPaths),
    [changedPaths],
  );
  const archiveFiles = useMemo(
    () => changedPaths.map((path) => ({ path, size: 1024 })),
    [changedPaths],
  );

  return (
    <div className="min-h-screen bg-gray-950">
      <Header user={user} />
      <div className="mx-auto flex max-w-7xl flex-col gap-6 px-4 py-6 lg:flex-row">
        <Sidebar
          onToggleFileTree={() => setShowFileTree((current) => !current)}
          projectId={projectId}
          projectName={project.name}
          recentWorkflows={recentWorkflows}
        />
        <main className="min-w-0 flex-1 space-y-6">
          <div className="sticky top-4 z-10 rounded-2xl border border-gray-800 bg-gray-900/95 p-4 backdrop-blur">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <h1 className="text-2xl font-semibold text-gray-100">
                    {project.name}
                  </h1>
                  <Badge variant={workflowStatusToBadgeVariant(project.status)}>
                    {project.status}
                  </Badge>
                </div>
                <StatusIndicator
                  label={
                    latestWorkflow
                      ? `Latest workflow: ${latestWorkflow.name}`
                      : 'No active workflow'
                  }
                  status={
                    project.status === 'running'
                      ? 'running'
                      : project.status === 'failed'
                        ? 'error'
                        : 'connected'
                  }
                />
              </div>
              <div className="text-sm text-gray-400">
                Branch:{' '}
                <span className="font-mono text-gray-100">
                  {project.branch}
                </span>
              </div>
            </div>
            <div className="mt-4">
              <Tabs
                activeTab={activeTab}
                onTabChange={(tab) => setActiveTab(tab as typeof activeTab)}
                tabs={[
                  { icon: '🤖', id: 'ai', label: 'AI Task' },
                  { icon: '🌿', id: 'git', label: 'Git' },
                  { icon: '📁', id: 'files', label: 'Files' },
                  { icon: '⬇️', id: 'downloads', label: 'Downloads' },
                  { icon: '🪵', id: 'logs', label: 'Logs' },
                ]}
              />
            </div>
          </div>

          {activeTab === 'ai' ? (
            <div className="space-y-6">
              <div className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
                <AIPrompt projectId={projectId} sandboxId={sandboxId} />
                <WorkflowTimeline workflowId={activeWorkflowId} />
              </div>
              <WorkflowMonitor
                activeWorkflowId={activeWorkflowId}
                projectId={projectId}
                recentRuns={recentWorkflows}
                sandboxId={sandboxId}
              />
            </div>
          ) : null}

          {activeTab === 'git' ? (
            <div className="grid gap-6 xl:grid-cols-[1fr_1fr]">
              <CommitInterface
                changedFiles={changedFiles}
                projectId={projectId}
                sandboxId={sandboxId}
              />
              <DiffViewer files={previewDiff} />
            </div>
          ) : null}

          {activeTab === 'files' ? (
            <div className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
              {showFileTree ? (
                <FileTree
                  changedPaths={changedPaths}
                  onSelectionChange={() => undefined}
                  sandboxId={sandboxId}
                />
              ) : (
                <Card
                  title="File tree hidden"
                  description="Use the sidebar toggle to restore the workspace browser."
                />
              )}
              <div className="space-y-6">
                <FileSelector
                  files={archiveFiles}
                  onArchiveCreated={setArtifactId}
                  projectId={projectId}
                  sandboxId={sandboxId}
                />
                <ArchiveProgress artifactId={artifactId} />
              </div>
            </div>
          ) : null}

          {activeTab === 'downloads' ? (
            <DownloadCenter projectId={projectId} />
          ) : null}

          {activeTab === 'logs' ? (
            <LogConsole
              className="min-h-[40rem]"
              sandboxId={sandboxId}
              workflowId={activeWorkflowId}
            />
          ) : null}
        </main>
      </div>
    </div>
  );
}
