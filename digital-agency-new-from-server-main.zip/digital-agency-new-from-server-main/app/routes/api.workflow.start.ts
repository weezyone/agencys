export async function loader({ request }: { request: Request }) {
  const { default: handler } = await import('../../api/workflow/start');
  return handler(request);
}

export async function action({ request }: { request: Request }) {
  const { default: handler } = await import('../../api/workflow/start');
  return handler(request);
}
