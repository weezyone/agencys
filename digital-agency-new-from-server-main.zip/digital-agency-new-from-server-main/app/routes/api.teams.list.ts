export { action, loader } from './api.teams._index';
