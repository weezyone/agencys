import { db } from '~/lib/db.server';
import { requireTeamRole } from '~/lib/team-auth.server';
import { deleteExpiredInvites, getTeamById, TeamError } from '~/lib/teams.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

function getTeamId(params: { id?: string }) {
  return params.id ?? '';
}

export async function loader({
  params,
  request,
}: {
  params: { id?: string };
  request: Request;
}) {
  const teamId = getTeamId(params);
  if (!teamId) {
    return errorResponse('Team not found', 404);
  }

  const team = await getTeamById(teamId);
  if (!team) {
    return errorResponse('Team not found', 404);
  }

  try {
    await requireTeamRole(request, teamId, 'VIEWER');
    void deleteExpiredInvites().catch(() => undefined);
    return Response.json({ team });
  } catch (error) {
    if (error instanceof Response) {
      return error;
    }

    if (error instanceof TeamError) {
      return errorResponse(error.message, error.status);
    }

    return errorResponse(
      'Unable to process team request',
      500,
      error instanceof Error ? error.message : undefined,
    );
  }
}

export async function action({
  params,
  request,
}: {
  params: { id?: string };
  request: Request;
}) {
  if (request.method !== 'DELETE') {
    return errorResponse('Method not allowed', 405);
  }

  const teamId = getTeamId(params);
  if (!teamId) {
    return errorResponse('Team not found', 404);
  }

  const team = await getTeamById(teamId);
  if (!team) {
    return errorResponse('Team not found', 404);
  }

  try {
    await requireTeamRole(request, teamId, 'OWNER');
    await db.team.delete({ where: { id: teamId } });
    return Response.json({ deleted: true, teamId });
  } catch (error) {
    if (error instanceof Response) {
      return error;
    }

    if (error instanceof TeamError) {
      return errorResponse(error.message, error.status);
    }

    return errorResponse(
      'Unable to process team request',
      500,
      error instanceof Error ? error.message : undefined,
    );
  }
}
