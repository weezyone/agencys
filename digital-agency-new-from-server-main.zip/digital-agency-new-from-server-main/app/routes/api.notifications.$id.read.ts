import { markNotificationRead } from '~/lib/notifications.server';
import { requireAuth } from '~/lib/session.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

export function loader() {
  return errorResponse('Method not allowed', 405);
}

export async function action({
  params,
  request,
}: {
  params: { id?: string };
  request: Request;
}) {
  if (request.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  const notificationId = params.id ?? '';
  if (!notificationId) {
    return errorResponse('Notification not found', 404);
  }

  let session;
  try {
    session = await requireAuth(request);
  } catch {
    return errorResponse('Unauthorized', 401);
  }

  await markNotificationRead(notificationId, session.userId);
  return Response.json({ read: true, notificationId });
}
