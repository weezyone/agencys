import type { LoaderFunctionArgs } from 'react-router';
import { redirect } from 'react-router';
import {
  generateCodeVerifier,
  generateState,
  getGitHubAuthUrl,
} from '../lib/auth.server';
import { sessionStorage } from '../lib/session.server';

export async function loader({ request }: LoaderFunctionArgs) {
  const session = await sessionStorage.getSession(
    request.headers.get('Cookie'),
  );
  const url = new URL(request.url);
  const requestedRedirect =
    url.searchParams.get('redirectTo') ??
    url.searchParams.get('returnTo') ??
    '/';
  const redirectTo =
    requestedRedirect.startsWith('/') && !requestedRedirect.startsWith('//')
      ? requestedRedirect
      : '/';
  const codeVerifier = generateCodeVerifier();
  const state = generateState();

  session.set('pkceCodeVerifier', codeVerifier);
  session.set('oauthState', state);
  session.set('redirectTo', redirectTo);

  return redirect(getGitHubAuthUrl(state, codeVerifier), {
    headers: {
      'Set-Cookie': await sessionStorage.commitSession(session),
    },
  });
}

export default function AuthGithubRoute() {
  return null;
}
