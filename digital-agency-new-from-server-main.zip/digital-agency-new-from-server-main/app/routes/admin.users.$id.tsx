import type { LoaderFunctionArgs } from 'react-router';
import { Link, useLoaderData } from 'react-router';
import { UserDetailPanel } from '~/components/Admin/UserDetailPanel';
import { getUserDetails, requireAdmin } from '~/lib/admin.server';

export async function loader({ params, request }: LoaderFunctionArgs) {
  await requireAdmin(request);
  if (!params.id) {
    throw new Response('Not Found', { status: 404 });
  }

  const user = await getUserDetails(params.id);

  return {
    user: {
      ...user,
      createdAt: user.createdAt.toISOString(),
      lastActiveAt: user.lastActiveAt?.toISOString() ?? null,
      projects: user.projects.map((project) => ({
        ...project,
        createdAt: project.createdAt.toISOString(),
      })),
      recentAuditLogs: user.recentAuditLogs.map((log) => ({
        ...log,
        createdAt: log.createdAt.toISOString(),
      })),
    },
  };
}

export default function AdminUserDetailPage() {
  const { user } = useLoaderData<typeof loader>();

  return (
    <div className="min-h-screen bg-gray-900 px-4 py-8 text-gray-100 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-6xl space-y-6">
        <Link className="inline-flex text-sm text-indigo-300 hover:text-indigo-200" to="/admin">
          ← Back to Users
        </Link>
        <UserDetailPanel initialUser={user} mode="inline" onClose={() => {}} userId={user.id} />
      </div>
    </div>
  );
}
