import type { LoaderFunctionArgs } from 'react-router';
import { useLoaderData } from 'react-router';
import { ActivityFeed } from '~/components/Dashboard/ActivityFeed';
import { ProjectGrid } from '~/components/Dashboard/ProjectGrid';
import { QuickActions } from '~/components/Dashboard/QuickActions';
import { Header } from '~/components/shared/Header';
import { Badge, Button, Card } from '~/components/ui';
import { getProjectWorkflows, getUserProjects } from '~/lib/data.server';
import { getOptionalAuth } from '~/lib/session.server';

const demoProjects = [
  {
    id: '11111111-1111-4111-8111-111111111111',
    name: 'Cloud-First AI Development Platform',
    description:
      'Workspace for orchestrating AI-assisted coding, sandboxes, and workflow execution.',
    repositoryUrl: 'https://github.com/example/cloud-dev-platform',
    branch: 'main',
    settings: {
      aiProvider: 'nvidia' as const,
      sandboxConfig: {
        memoryMb: 8192,
        runtime: 'node22' as const,
        timeoutMinutes: 45,
        vcpus: 4,
      },
      gitIntegration: {
        defaultBranch: 'main',
        provider: 'github' as const,
        repositoryUrl: 'https://github.com/example/cloud-dev-platform',
      },
    },
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 10).toISOString(),
    updatedAt: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
    lastActivityAt: new Date(Date.now() - 1000 * 60 * 6).toISOString(),
    lastWorkflowStatus: 'running',
  },
  {
    id: '22222222-2222-4222-8222-222222222222',
    name: 'Workspace Templates',
    description: 'Reusable project templates for agentic development flows.',
    repositoryUrl: 'https://github.com/example/workspace-templates',
    branch: 'main',
    settings: {
      aiProvider: 'claude' as const,
      sandboxConfig: {
        memoryMb: 4096,
        runtime: 'node22' as const,
        timeoutMinutes: 30,
        vcpus: 2,
      },
      gitIntegration: {
        defaultBranch: 'main',
        provider: 'github' as const,
        repositoryUrl: 'https://github.com/example/workspace-templates',
      },
    },
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString(),
    updatedAt: new Date(Date.now() - 1000 * 60 * 40).toISOString(),
    lastActivityAt: new Date(Date.now() - 1000 * 60 * 40).toISOString(),
    lastWorkflowStatus: 'completed',
  },
];

const demoActivities = [
  {
    type: 'workflow' as const,
    description: 'Cloud task workflow is provisioning a fresh sandbox',
    timestamp: new Date(Date.now() - 1000 * 60 * 4).toISOString(),
    status: 'running',
  },
  {
    type: 'commit' as const,
    description: 'Repository import completed from GitHub',
    timestamp: new Date(Date.now() - 1000 * 60 * 18).toISOString(),
    status: 'completed',
  },
  {
    type: 'artifact' as const,
    description: 'Artifact bundle downloaded by the latest workflow',
    timestamp: new Date(Date.now() - 1000 * 60 * 52).toISOString(),
    status: 'completed',
  },
];

function normalizeStatus(status?: string | null) {
  switch ((status ?? '').toLowerCase()) {
    case 'completed':
      return 'completed';
    case 'failed':
    case 'expired':
      return 'failed';
    case 'running':
    case 'suspended':
      return 'running';
    default:
      return 'idle';
  }
}

export async function loader({ request }: LoaderFunctionArgs) {
  const user = await getOptionalAuth(request);

  if (!user || !process.env.DATABASE_URL) {
    return { activities: demoActivities, projects: demoProjects, user };
  }

  try {
    const projects = await getUserProjects(user.userId, 12, 0);
    const workflowSets = await Promise.all(
      projects.map((project) => getProjectWorkflows(project.id)),
    );

    const normalizedProjects = projects.map((project, index) => ({
      branch: project.branch,
      createdAt: project.createdAt.toISOString(),
      description: project.description ?? undefined,
      id: project.id,
      lastActivityAt:
        workflowSets[index]?.[0]?.updatedAt?.toISOString?.() ??
        project.updatedAt.toISOString(),
      lastWorkflowStatus: normalizeStatus(workflowSets[index]?.[0]?.status),
      name: project.name,
      repositoryUrl: project.repositoryUrl ?? undefined,
      settings: (project.settings ?? {
        aiProvider: 'nvidia',
        gitIntegration: { defaultBranch: project.branch, provider: 'github' },
        sandboxConfig: {
          memoryMb: 4096,
          runtime: 'node22',
          timeoutMinutes: 30,
          vcpus: 2,
        },
      }) as (typeof demoProjects)[number]['settings'],
      updatedAt: project.updatedAt.toISOString(),
    }));

    const activities = workflowSets
      .flatMap((workflows) => workflows.slice(0, 3))
      .sort(
        (left, right) => right.updatedAt.getTime() - left.updatedAt.getTime(),
      )
      .slice(0, 10)
      .map((workflow) => ({
        description: `${workflow.name} workflow updated`,
        status: normalizeStatus(workflow.status),
        timestamp: workflow.updatedAt.toISOString(),
        type: 'workflow' as const,
      }));

    return {
      activities: activities.length > 0 ? activities : demoActivities,
      projects:
        normalizedProjects.length > 0 ? normalizedProjects : demoProjects,
      user,
    };
  } catch {
    return { activities: demoActivities, projects: demoProjects, user };
  }
}

export default function DashboardPage() {
  const { activities, projects, user } = useLoaderData<typeof loader>();

  return (
    <div className="min-h-screen bg-gray-950">
      <Header user={user} />
      <main className="mx-auto max-w-7xl space-y-8 px-4 py-8">
        {!user ? (
          <Card className="overflow-hidden border-indigo-500/20 bg-gradient-to-br from-indigo-600/10 via-gray-900 to-gray-950">
            <div className="grid gap-8 lg:grid-cols-[1.3fr_0.7fr] lg:items-center">
              <div className="space-y-5">
                <Badge variant="info">Cloud-first AI delivery</Badge>
                <div className="space-y-3">
                  <h1 className="text-4xl font-semibold tracking-tight text-gray-100">
                    Build, stream, and ship code from one intelligent workspace.
                  </h1>
                  <p className="max-w-2xl text-base text-gray-300">
                    Spin up sandboxes, run AI tasks, monitor workflows, and
                    export artifacts without leaving the dashboard.
                  </p>
                </div>
                <div className="flex flex-wrap gap-3">
                  <a href="/auth/login">
                    <Button>Sign in / Register</Button>
                  </a>
                  <a href="/auth/github">
                    <Button variant="secondary">Login with GitHub</Button>
                  </a>
                  <a href="#quick-actions">
                    <Button variant="ghost">Explore quick actions</Button>
                  </a>
                </div>
              </div>
              <div className="grid gap-3 rounded-2xl border border-gray-800 bg-gray-900/70 p-5">
                {[
                  'Live SSE workflow logs',
                  'One-click sandbox provisioning',
                  'Claude + Codex task execution',
                ].map((feature) => (
                  <div
                    key={feature}
                    className="rounded-xl border border-gray-800 bg-gray-800/50 px-4 py-3 text-sm text-gray-200"
                  >
                    {feature}
                  </div>
                ))}
              </div>
            </div>
          </Card>
        ) : null}

        <section id="quick-actions">
          <QuickActions />
        </section>

        {user ? <ProjectGrid projects={projects} /> : null}

        <ActivityFeed activities={activities} />
      </main>
    </div>
  );
}
