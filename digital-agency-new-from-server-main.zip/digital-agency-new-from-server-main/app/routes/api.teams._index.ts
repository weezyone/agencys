import { requireAuth } from '~/lib/session.server';
import { getUserTeams, TeamError } from '~/lib/teams.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

export async function loader({ request }: { request: Request }) {
  let session;
  try {
    session = await requireAuth(request);
  } catch {
    return errorResponse('Unauthorized', 401);
  }

  try {
    const teams = await getUserTeams(session.userId);
    return Response.json({ teams });
  } catch (error) {
    if (error instanceof TeamError) {
      return errorResponse(error.message, error.status);
    }

    return errorResponse(
      'Unable to list teams',
      500,
      error instanceof Error ? error.message : undefined,
    );
  }
}

export function action() {
  return errorResponse('Method not allowed', 405);
}
