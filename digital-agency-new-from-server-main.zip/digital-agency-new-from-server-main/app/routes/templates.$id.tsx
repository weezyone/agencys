import { useMemo, useState } from 'react';
import type { LoaderFunctionArgs } from 'react-router';
import { Link, useLoaderData, useNavigate } from 'react-router';
import { UseTemplateModal } from '~/components/Templates/UseTemplateModal';
import {
  formatCategoryLabel,
  getTemplateCategoryMeta,
  getTemplateSandboxConfig,
} from '~/components/Templates/template-utils';
import { Badge, Button } from '~/components/ui';
import { getOptionalAuth } from '~/lib/session.server';
import { getTemplateById, isTemplateStorageUnavailable } from '~/lib/templates.server';

export async function loader({ params, request }: LoaderFunctionArgs) {
  try {
    const [template, user] = await Promise.all([
      params.id ? getTemplateById(params.id) : Promise.resolve(null),
      getOptionalAuth(request),
    ]);
    if (!template) {
      throw new Response('Template not found', { status: 404 });
    }

    return { template, isAuthenticated: Boolean(user) };
  } catch (error) {
    if (isTemplateStorageUnavailable(error)) {
      throw new Response('Template not found', { status: 404 });
    }

    throw error;
  }
}

export default function TemplateDetailPage() {
  const { isAuthenticated, template } = useLoaderData<typeof loader>();
  const navigate = useNavigate();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const categoryMeta = getTemplateCategoryMeta(template.category);
  const sandboxConfig = useMemo(
    () => getTemplateSandboxConfig(template.sandboxConfig),
    [template.sandboxConfig],
  );

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="space-y-8 rounded-3xl border border-gray-800 bg-gray-900 p-6 sm:p-8">
        <Link className="inline-flex text-sm text-indigo-300 hover:text-indigo-200" to="/templates">
          ← Back to templates
        </Link>

        <div className="space-y-5">
          <div className="flex flex-wrap items-center gap-3">
            <Badge className={categoryMeta.badgeClass} variant="default">
              {formatCategoryLabel(template.category)}
            </Badge>
            {template.isBuiltIn ? (
              <Badge
                className="border-gray-500/30 bg-gray-500/10 text-gray-200"
                variant="default"
              >
                Built-in
              </Badge>
            ) : null}
          </div>

          <div className="space-y-3">
            <h1 className="text-3xl font-semibold text-gray-100">{template.name}</h1>
            <p className="max-w-3xl text-lg text-gray-400">{template.description}</p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <span className="text-sm text-gray-500">Tags:</span>
            {template.tags.map((tag) => (
              <Badge key={tag} className="text-gray-300" variant="default">
                {tag}
              </Badge>
            ))}
          </div>

          <p className="text-sm text-gray-400">Used {template.useCount} times</p>
        </div>

        <section className="space-y-4 border-t border-gray-800 pt-6">
          <h2 className="text-lg font-semibold text-gray-100">Configuration</h2>
          <div className="rounded-2xl border border-gray-800 bg-gray-950 px-4 py-4 text-sm text-gray-300">
            Runtime: {sandboxConfig.runtime} | vCPUs: {sandboxConfig.vcpus} |
            Timeout: {sandboxConfig.timeoutMinutes}m
          </div>
        </section>

        <section className="space-y-4 border-t border-gray-800 pt-6">
          <h2 className="text-lg font-semibold text-gray-100">AI Starter Prompt</h2>
          <pre className="overflow-x-auto rounded-2xl border border-gray-800 bg-gray-950 p-4 text-sm text-gray-300 whitespace-pre-wrap">
            <code>{template.aiPrompt || 'No starter prompt provided.'}</code>
          </pre>
        </section>

        <section className="space-y-4 border-t border-gray-800 pt-6">
          <h2 className="text-lg font-semibold text-gray-100">Repository</h2>
          {template.repositoryUrl ? (
            <a
              className="text-indigo-300 underline-offset-4 hover:text-indigo-200 hover:underline"
              href={template.repositoryUrl}
              rel="noreferrer"
              target="_blank"
            >
              {template.repositoryUrl}
            </a>
          ) : (
            <p className="text-sm text-gray-500">No repository linked.</p>
          )}
        </section>

        <div className="flex justify-end border-t border-gray-800 pt-6">
          <Button
            onClick={() => {
              if (!isAuthenticated) {
                navigate('/auth/github');
                return;
              }

              setIsModalOpen(true);
            }}
            size="lg"
          >
            Use This Template →
          </Button>
        </div>
      </div>

      <UseTemplateModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        template={template}
      />
    </div>
  );
}
