import type { ActionFunctionArgs, LoaderFunctionArgs } from 'react-router';
import {
  Form,
  Link,
  redirect,
  useActionData,
  useLoaderData,
} from 'react-router';
import { Header } from '~/components/shared/Header';
import { Badge } from '~/components/ui/Badge';
import { Button } from '~/components/ui/Button';
import { Card } from '~/components/ui/Card';
import { getOptionalAuth, requireAuth } from '~/lib/session.server';
import { TeamError, acceptTeamInvite, getTeamInviteByToken } from '~/lib/teams.server';
import { formatTeamDate, teamRoleClasses, teamRoleLabel } from '~/components/Team/team-utils';

function errorResponse(message: string, status: number) {
  return Response.json({ error: message }, { status });
}

export async function loader({ params, request }: LoaderFunctionArgs) {
  const token = params.token ?? '';
  const user = await getOptionalAuth(request);
  if (!user) {
    throw redirect(
      `/auth/github?returnTo=${encodeURIComponent(`/invite/${token}`)}`,
    );
  }

  const invite = token ? await getTeamInviteByToken(token) : null;

  return {
    invite: invite
      ? {
          createdAt: invite.createdAt.toISOString(),
          email: invite.email,
          role: invite.role,
          team: {
            id: invite.team.id,
            name: invite.team.name,
            ownerName: invite.team.owner.name,
          },
          token: invite.token,
        }
      : null,
    user,
  };
}

export async function action({ params, request }: ActionFunctionArgs) {
  const user = await requireAuth(request);
  const formData = await request.formData();
  const intent = String(formData.get('intent') ?? 'accept');
  const token = String(formData.get('token') ?? params.token ?? '');

  if (intent === 'decline') {
    return redirect('/');
  }

  if (!token) {
    return errorResponse('Invite is invalid or expired.', 400);
  }

  try {
    await acceptTeamInvite(token, user.userId);
    return redirect('/settings/team');
  } catch (error) {
    if (error instanceof TeamError) {
      return errorResponse(error.message, error.status);
    }
    return errorResponse('Unable to accept invite.', 500);
  }
}

export default function InviteTokenPage() {
  const { invite, user } = useLoaderData<typeof loader>();
  const actionData = useActionData<typeof action>() as
    | { error?: string }
    | undefined;

  return (
    <div className="min-h-screen bg-gray-950">
      <Header user={user} />
      <main className="mx-auto flex max-w-3xl flex-col gap-6 px-4 py-12">
        <div className="space-y-2">
          <h1 className="text-3xl font-semibold text-gray-100">
            Team invitation
          </h1>
          <p className="text-sm text-gray-400">
            Review the invite details before joining the workspace.
          </p>
        </div>

        {!invite ? (
          <Card title="Invite unavailable" description="This invite is invalid or has expired.">
            <p className="text-sm text-gray-300">
              Ask the team owner to send you a new invitation.
            </p>
          </Card>
        ) : (
          <Card title={invite.team.name} description={`Sent ${formatTeamDate(invite.createdAt)}`}>
            <div className="space-y-4 text-sm text-gray-300">
              <p>
                You're invited to join <span className="font-medium text-gray-100">{invite.team.name}</span>{' '}
                as{' '}
                <Badge className={teamRoleClasses(invite.role)}>
                  {teamRoleLabel(invite.role)}
                </Badge>
                .
              </p>
              <div className="rounded-xl border border-gray-800 bg-gray-800/60 p-4">
                <p className="text-xs uppercase tracking-wide text-gray-400">Inviter</p>
                <p className="mt-2 text-base font-medium text-gray-100">
                  {invite.team.ownerName}
                </p>
                <p className="mt-3 text-xs uppercase tracking-wide text-gray-400">Invite email</p>
                <p className="mt-2 text-base font-medium text-gray-100">{invite.email}</p>
              </div>
              {actionData?.error ? (
                <p className="rounded-lg border border-red-500/40 bg-red-500/10 px-3 py-2 text-sm text-red-200">
                  {actionData.error}
                </p>
              ) : null}
              <div className="flex flex-wrap gap-3">
                <Form method="post">
                  <input name="intent" type="hidden" value="accept" />
                  <input name="token" type="hidden" value={invite.token} />
                  <Button type="submit">Accept invite</Button>
                </Form>
                <Form method="post">
                  <input name="intent" type="hidden" value="decline" />
                  <Button type="submit" variant="ghost">
                    Decline
                  </Button>
                </Form>
                <Link className="inline-flex items-center text-sm text-gray-400 hover:text-gray-200" to="/settings/team">
                  Review team settings
                </Link>
              </div>
            </div>
          </Card>
        )}
      </main>
    </div>
  );
}
