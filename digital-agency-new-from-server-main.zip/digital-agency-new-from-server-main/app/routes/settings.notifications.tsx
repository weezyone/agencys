import type { LoaderFunctionArgs } from 'react-router';
import { useLoaderData } from 'react-router';
import { NotificationPreferencesForm } from '~/components/Notifications/NotificationPreferencesForm';
import { Header } from '~/components/shared/Header';
import { getPreferences } from '~/lib/notifications.server';
import { requireAuth } from '~/lib/session.server';

export async function loader({ request }: LoaderFunctionArgs) {
  const user = await requireAuth(request);
  const preferences = await getPreferences(user.userId);

  return { preferences, user };
}

export default function SettingsNotificationsPage() {
  const { preferences, user } = useLoaderData<typeof loader>();

  return (
    <div className="min-h-screen bg-gray-950">
      <Header user={user} />
      <main className="mx-auto max-w-4xl px-4 py-8">
        <NotificationPreferencesForm
          email={user.email}
          initialPreferences={preferences}
        />
      </main>
    </div>
  );
}
