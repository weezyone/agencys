import { z } from 'zod';
import { getUserNotifications } from '~/lib/notifications.server';
import { requireAuth } from '~/lib/session.server';

const querySchema = z.object({
  limit: z.coerce.number().int().min(1).max(100).default(20),
  offset: z.coerce.number().int().min(0).default(0),
  unreadOnly: z
    .union([z.literal('true'), z.literal('false'), z.boolean()])
    .optional()
    .transform((value) => value === true || value === 'true'),
});

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

export async function loader({ request }: { request: Request }) {
  let session;
  try {
    session = await requireAuth(request);
  } catch {
    return errorResponse('Unauthorized', 401);
  }

  const parsed = querySchema.safeParse(
    Object.fromEntries(new URL(request.url).searchParams),
  );
  if (!parsed.success) {
    return errorResponse('Invalid notification query', 400, parsed.error.flatten());
  }

  return Response.json(await getUserNotifications(session.userId, parsed.data));
}

export function action() {
  return errorResponse('Method not allowed', 405);
}
