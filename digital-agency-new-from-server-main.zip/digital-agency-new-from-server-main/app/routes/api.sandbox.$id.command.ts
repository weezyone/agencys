export async function loader({ request }: { request: Request }) {
  const { default: handler } = await import('../../api/sandbox/[id]/command');
  return handler(request);
}

export async function action({ request }: { request: Request }) {
  const { default: handler } = await import('../../api/sandbox/[id]/command');
  return handler(request);
}
