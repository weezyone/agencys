import { updatePreferencesSchema } from '~/lib/schemas.server';
import { requireAuth } from '~/lib/session.server';
import {
  deliverWebhook,
  getPreferences,
  updatePreferences,
} from '~/lib/notifications.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

export async function loader({ request }: { request: Request }) {
  let session;
  try {
    session = await requireAuth(request);
  } catch {
    return errorResponse('Unauthorized', 401);
  }

  return Response.json({ preferences: await getPreferences(session.userId) });
}

export async function action({ request }: { request: Request }) {
  let session;
  try {
    session = await requireAuth(request);
  } catch {
    return errorResponse('Unauthorized', 401);
  }

  const payload = await request.json().catch(() => ({}));

  if (request.method === 'POST') {
    const webhookUrl =
      typeof payload.webhookUrl === 'string' ? payload.webhookUrl : '';
    if (!webhookUrl) {
      return errorResponse('Webhook URL is required', 400);
    }

    try {
      await deliverWebhook(webhookUrl, {
        body: 'This is a test notification from your workspace settings.',
        metadata: { test: true, userId: session.userId },
        timestamp: new Date().toISOString(),
        title: 'Test notification',
        type: 'SYSTEM',
      });
      return Response.json({ ok: true });
    } catch (error) {
      return errorResponse(
        'Unable to test webhook',
        500,
        error instanceof Error ? error.message : undefined,
      );
    }
  }

  if (request.method !== 'PUT') {
    return errorResponse('Method not allowed', 405);
  }

  const parsed = updatePreferencesSchema.safeParse(payload);
  if (!parsed.success) {
    return errorResponse('Invalid preferences payload', 400, parsed.error.flatten());
  }

  const preferences = await updatePreferences(session.userId, parsed.data);
  return Response.json({ preferences });
}
