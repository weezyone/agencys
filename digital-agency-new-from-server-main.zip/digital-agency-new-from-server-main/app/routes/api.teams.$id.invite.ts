import { db } from '~/lib/db.server';
import { inviteTeamMemberSchema } from '~/lib/schemas.server';
import { TeamRole } from '~/lib/team-roles';
import { requireTeamRole } from '~/lib/team-auth.server';
import { createTeamInvite, TeamError } from '~/lib/teams.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

export function loader() {
  return errorResponse('Method not allowed', 405);
}

export async function action({
  params,
  request,
}: {
  params: { id?: string };
  request: Request;
}) {
  if (request.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  const teamId = params.id ?? '';
  if (!teamId) {
    return errorResponse('Team not found', 404);
  }

  let team;
  try {
    team = await db.team.findUnique({ where: { id: teamId } });
  } catch (error) {
    return errorResponse(
      'Unable to create invite',
      500,
      error instanceof Error ? error.message : undefined,
    );
  }

  if (!team) {
    return errorResponse('Team not found', 404);
  }

  const payload = await request.json().catch(() => ({}));
  const parsed = inviteTeamMemberSchema.safeParse(payload);
  if (!parsed.success) {
    return errorResponse('Invalid invite payload', 400, parsed.error.flatten());
  }

  try {
    const { user } = await requireTeamRole(request, teamId, 'COLLABORATOR');
    const invite = await createTeamInvite(
      teamId,
      parsed.data.email,
      parsed.data.role === 'VIEWER' ? TeamRole.VIEWER : TeamRole.COLLABORATOR,
      user.userId,
    );

    return Response.json({
      invite: {
        email: invite.email,
        expiresAt: invite.expiresAt.toISOString(),
        token: invite.token,
      },
    });
  } catch (error) {
    if (error instanceof Response) {
      return error;
    }

    if (error instanceof TeamError) {
      return errorResponse(error.message, error.status);
    }

    return errorResponse(
      'Unable to create invite',
      500,
      error instanceof Error ? error.message : undefined,
    );
  }
}
