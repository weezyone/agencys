import { drainLiveNotifications } from '~/lib/notifications.server';
import {
  createSSEResponse,
  createSSEStream,
  type SSEEvent,
} from '~/lib/sse.server';
import { requireAuth } from '~/lib/session.server';
import { sleep } from '~/lib/utils';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

async function* notificationStream(
  userId: string,
  signal: AbortSignal,
): AsyncGenerator<SSEEvent> {
  let id = 0;
  let lastHeartbeat = 0;

  while (!signal.aborted) {
    const notifications = await drainLiveNotifications(userId);
    for (const notification of notifications) {
      id += 1;
      yield {
        data: { notification },
        event: 'notification',
        id: String(id),
      };
    }

    if (Date.now() - lastHeartbeat >= 15_000) {
      lastHeartbeat = Date.now();
      yield { data: { timestamp: lastHeartbeat }, event: 'heartbeat' };
    }

    await sleep(2_000);
  }
}

export async function loader({ request }: { request: Request }) {
  let session;
  try {
    session = await requireAuth(request);
  } catch {
    return errorResponse('Unauthorized', 401);
  }

  return createSSEResponse(
    createSSEStream(notificationStream(session.userId, request.signal), request.signal),
  );
}

export function action() {
  return errorResponse('Method not allowed', 405);
}
