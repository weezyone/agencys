import { useState } from 'react';
import type { LoaderFunctionArgs } from 'react-router';
import { useLoaderData, useRevalidator } from 'react-router';
import { CurrentPlanCard } from '~/components/Billing/CurrentPlanCard';
import { PlanComparisonTable } from '~/components/Billing/PlanComparisonTable';
import { UpgradeModal } from '~/components/Billing/UpgradeModal';
import { UsageMeter } from '~/components/Billing/UsageMeter';
import { Header } from '~/components/shared/Header';
import { Card } from '~/components/ui/Card';
import { getUsageSummary } from '~/lib/billing.server';
import { requireAuth } from '~/lib/session.server';
import { formatCompactNumber, formatHours } from '~/components/Billing/billing-config';

export async function loader({ request }: LoaderFunctionArgs) {
  const user = await requireAuth(request);
  const usage = await getUsageSummary(user.userId);
  return { usage, user };
}

export default function BillingSettingsPage() {
  const { usage, user } = useLoaderData<typeof loader>();
  const [isUpgradeOpen, setIsUpgradeOpen] = useState(false);
  const revalidator = useRevalidator();

  const handleUpgraded = () => {
    void revalidator.revalidate();
  };

  return (
    <div className="min-h-screen bg-gray-950">
      <Header user={user} />
      <main className="mx-auto max-w-7xl space-y-6 px-4 py-8">
        <div className="space-y-2">
          <h1 className="text-3xl font-semibold text-gray-100">Billing &amp; Usage</h1>
          <p className="text-sm text-gray-400">
            Monitor plan limits, review usage, and upgrade instantly in demo mode.
          </p>
        </div>

        <CurrentPlanCard
          onUpgrade={() => setIsUpgradeOpen(true)}
          periodEnd={usage.periodEnd}
          plan={usage.plan}
        />

        <Card title="Usage This Period">
          <div className="space-y-5">
            <UsageMeter
              formatValue={formatHours}
              label="Sandbox Hours"
              limit={usage.sandboxHours.limit}
              percent={usage.sandboxHours.percent}
              unit="hours"
              used={usage.sandboxHours.used}
            />
            <UsageMeter
              formatValue={formatCompactNumber}
              label="AI Tokens"
              limit={usage.aiTokens.limit}
              percent={usage.aiTokens.percent}
              unit="tokens"
              used={usage.aiTokens.used}
            />
            <UsageMeter
              label="Projects"
              limit={usage.projects.limit}
              percent={usage.projects.percent}
              unit="projects"
              used={usage.projects.used}
            />
          </div>
        </Card>

        <Card
          description="Compare monthly limits and upgrade when you need more capacity."
          title="Plan Comparison"
        >
          <PlanComparisonTable currentPlan={usage.plan} onUpgraded={handleUpgraded} />
        </Card>

        <Card title="Billing History">
          <p className="text-sm text-gray-400">No invoices yet</p>
        </Card>
      </main>

      <UpgradeModal
        currentPlan={usage.plan}
        isOpen={isUpgradeOpen}
        onClose={() => setIsUpgradeOpen(false)}
        onUpgraded={handleUpgraded}
      />
    </div>
  );
}
