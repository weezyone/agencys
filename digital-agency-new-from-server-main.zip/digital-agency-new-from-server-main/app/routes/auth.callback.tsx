import type { LoaderFunctionArgs } from 'react-router';
import { Prisma } from '@prisma/client';
import db from '../lib/db.server';
import {
  createUserSession,
  sessionStorage,
  type SessionData,
} from '../lib/session.server';
import {
  exchangeGitHubCode,
  exchangeGitLabCode,
  getGitHubUser,
  getGitLabUser,
} from '../lib/auth.server';

type AuthProvider = 'github' | 'gitlab';

async function buildUserSession(
  provider: AuthProvider,
  accessToken: string,
  expiresAt: number,
  profile: {
    id: number;
    email: string;
    name: string;
    avatar_url: string;
  },
): Promise<SessionData> {
  if (!process.env.DATABASE_URL) {
    return {
      userId: `mock-${provider}-${profile.id}`,
      email: profile.email,
      name: profile.name,
      avatarUrl: profile.avatar_url || undefined,
      accessToken,
      provider,
      expiresAt,
    };
  }

  const existingUser = await db.user.findUnique({
    where: { email: profile.email },
    select: { oauthTokens: true },
  });
  const existingTokens =
    existingUser?.oauthTokens &&
    typeof existingUser.oauthTokens === 'object' &&
    !Array.isArray(existingUser.oauthTokens)
      ? (existingUser.oauthTokens as Record<string, Prisma.JsonValue>)
      : {};
  const mergedTokens = {
    ...existingTokens,
    [provider]: {
      accessToken,
      expiresAt,
    },
  } as Prisma.InputJsonObject;

  const user = await db.user.upsert({
    where: { email: profile.email },
    update: {
      name: profile.name,
      avatarUrl: profile.avatar_url || null,
      oauthTokens: mergedTokens,
    },
    create: {
      email: profile.email,
      name: profile.name,
      avatarUrl: profile.avatar_url || null,
      oauthTokens: mergedTokens,
    },
    select: {
      id: true,
      email: true,
      name: true,
      avatarUrl: true,
    },
  });

  return {
    userId: user.id,
    email: user.email,
    name: user.name,
    avatarUrl: user.avatarUrl ?? undefined,
    accessToken,
    provider,
    expiresAt,
  };
}

export async function loader({ request }: LoaderFunctionArgs) {
  const url = new URL(request.url);
  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state');
  const provider = url.searchParams.get('provider');

  if (!code || !state || (provider !== 'github' && provider !== 'gitlab')) {
    throw new Response('Invalid OAuth callback', { status: 400 });
  }

  const session = await sessionStorage.getSession(
    request.headers.get('Cookie'),
  );
  const expectedState = session.get('oauthState');
  const codeVerifier = session.get('pkceCodeVerifier');
  const redirectTo = session.get('redirectTo') ?? '/';

  if (!expectedState || !codeVerifier || state !== expectedState) {
    throw new Response('Invalid OAuth state', { status: 400 });
  }

  if (provider === 'github') {
    const token = await exchangeGitHubCode(code, codeVerifier);
    const profile = await getGitHubUser(token.accessToken);
    const userData = await buildUserSession(
      provider,
      token.accessToken,
      Date.now() + 24 * 60 * 60 * 1000,
      profile,
    );
    return createUserSession(userData, redirectTo);
  }

  const token = await exchangeGitLabCode(code, codeVerifier);
  const profile = await getGitLabUser(token.accessToken);
  const expiresAt = Date.now() + (token.expiresIn ?? 24 * 60 * 60) * 1000;
  const userData = await buildUserSession(
    provider,
    token.accessToken,
    expiresAt,
    profile,
  );
  return createUserSession(userData, redirectTo);
}

export default function AuthCallbackRoute() {
  return null;
}
