import { db } from '~/lib/db.server';
import { requireTeamRole } from '~/lib/team-auth.server';
import { removeTeamMember, TeamError } from '~/lib/teams.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

async function ensureTeam(teamId: string) {
  if (!teamId) {
    return null;
  }

  return db.team.findUnique({ where: { id: teamId } });
}

export async function loader({
  params,
  request,
}: {
  params: { id?: string };
  request: Request;
}) {
  const teamId = params.id ?? '';
  const team = await ensureTeam(teamId);
  if (!team) {
    return errorResponse('Team not found', 404);
  }

  try {
    await requireTeamRole(request, teamId, 'VIEWER');
    const members = await db.teamMember.findMany({
      include: {
        user: {
          select: {
            avatarUrl: true,
            email: true,
            id: true,
            name: true,
          },
        },
      },
      orderBy: { joinedAt: 'asc' },
      where: { teamId },
    });

    return Response.json({ members });
  } catch (error) {
    if (error instanceof Response) {
      return error;
    }

    if (error instanceof TeamError) {
      return errorResponse(error.message, error.status);
    }

    return errorResponse(
      'Unable to manage team members',
      500,
      error instanceof Error ? error.message : undefined,
    );
  }
}

export async function action({
  params,
  request,
}: {
  params: { id?: string };
  request: Request;
}) {
  if (request.method !== 'DELETE') {
    return errorResponse('Method not allowed', 405);
  }

  const teamId = params.id ?? '';
  const team = await ensureTeam(teamId);
  if (!team) {
    return errorResponse('Team not found', 404);
  }

  try {
    const url = new URL(request.url);
    const userId = url.searchParams.get('userId');
    if (!userId) {
      return errorResponse('Member not found', 404);
    }

    const { user } = await requireTeamRole(request, teamId, 'COLLABORATOR');
    await removeTeamMember(teamId, userId, user.userId);
    return Response.json({ removed: true, userId });
  } catch (error) {
    if (error instanceof Response) {
      return error;
    }

    if (error instanceof TeamError) {
      return errorResponse(error.message, error.status);
    }

    return errorResponse(
      'Unable to manage team members',
      500,
      error instanceof Error ? error.message : undefined,
    );
  }
}
