import { z } from 'zod';
import { createProject } from '~/lib/data.server';
import { requireAuth } from '~/lib/session.server';

const createProjectBodySchema = z.object({
  branch: z.string().trim().min(1).max(255).default('main'),
  description: z.string().trim().max(5000).optional(),
  name: z.string().trim().min(1).max(255),
  repositoryUrl: z.string().trim().url().optional(),
  settings: z.record(z.string(), z.unknown()).optional(),
});

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

function buildDefaultSettings(branch: string, repositoryUrl?: string) {
  return {
    aiProvider: 'nvidia',
    gitIntegration: {
      defaultBranch: branch,
      provider: 'github',
      repositoryUrl,
    },
    sandboxConfig: {
      memoryMb: 4096,
      runtime: 'node22',
      timeoutMinutes: 30,
      vcpus: 2,
    },
  };
}

function serializeProject(project: {
  id: string;
  name: string;
  description: string | null;
  repositoryUrl: string | null;
  branch: string;
  settings: unknown;
  createdAt: Date;
  updatedAt: Date;
}) {
  return {
    ...project,
    createdAt: project.createdAt.toISOString(),
    description: project.description ?? undefined,
    repositoryUrl: project.repositoryUrl ?? undefined,
    updatedAt: project.updatedAt.toISOString(),
  };
}

export async function loader() {
  return errorResponse('Method not allowed', 405);
}

export async function action({ request }: { request: Request }) {
  let session;
  try {
    session = await requireAuth(request);
  } catch {
    return errorResponse('Unauthorized', 401);
  }

  const payload = await request.json().catch(() => ({}));
  const parsed = createProjectBodySchema.safeParse(payload);
  if (!parsed.success) {
    return errorResponse(
      'Invalid project payload',
      400,
      parsed.error.flatten(),
    );
  }

  const mergedSettings = {
    ...buildDefaultSettings(parsed.data.branch, parsed.data.repositoryUrl),
    ...(parsed.data.settings ?? {}),
  };

  if (!process.env.DATABASE_URL) {
    return Response.json({
      project: {
        branch: parsed.data.branch,
        createdAt: new Date().toISOString(),
        description: parsed.data.description,
        id: crypto.randomUUID(),
        name: parsed.data.name,
        repositoryUrl: parsed.data.repositoryUrl,
        settings: mergedSettings,
        updatedAt: new Date().toISOString(),
      },
    });
  }

  try {
    const project = await createProject(session.userId, {
      branch: parsed.data.branch,
      description: parsed.data.description,
      name: parsed.data.name,
      repositoryUrl: parsed.data.repositoryUrl,
      settings: mergedSettings,
    });

    return Response.json({ project: serializeProject(project) });
  } catch (error) {
    return errorResponse(
      'Unable to create project',
      500,
      error instanceof Error ? error.message : undefined,
    );
  }
}
