import { useState } from 'react';
import type { LoaderFunctionArgs } from 'react-router';
import { useLoaderData } from 'react-router';
import { Header } from '~/components/shared/Header';
import { Badge, Button, Card } from '~/components/ui';
import { requireAuth } from '~/lib/session.server';

type ProviderId = 'claude' | 'codex' | 'openrouter' | 'huggingface' | 'nvidia';

const PROVIDER_META: Array<{
  id: ProviderId;
  label: string;
  description: string;
  placeholder: string;
}> = [
  {
    description: 'Anthropic API key',
    id: 'claude',
    label: 'Anthropic (Claude)',
    placeholder: 'sk-ant-••••••••',
  },
  {
    description: 'OpenAI API key',
    id: 'codex',
    label: 'OpenAI (Codex)',
    placeholder: 'sk-proj-••••••••',
  },
  {
    description: 'OpenRouter API key',
    id: 'openrouter',
    label: 'OpenRouter',
    placeholder: 'sk-or-••••••••',
  },
  {
    description: 'Hugging Face access token',
    id: 'huggingface',
    label: 'Hugging Face',
    placeholder: 'hf_••••••••',
  },
  {
    description: 'NVIDIA NIM API key',
    id: 'nvidia',
    label: 'NVIDIA NIM',
    placeholder: 'nvapi-••••••••',
  },
];

export async function loader({ request }: LoaderFunctionArgs) {
  return {
    user: await requireAuth(request),
  };
}

export default function SettingsPage() {
  const { user } = useLoaderData<typeof loader>();
  const [keys, setKeys] = useState<Record<ProviderId, string>>({
    claude: '',
    codex: '',
    huggingface: '',
    nvidia: '',
    openrouter: '',
  });
  const [status, setStatus] = useState<string | null>(null);
  const [savingProvider, setSavingProvider] = useState<ProviderId | null>(null);

  const saveKey = async (provider: ProviderId, apiKey: string) => {
    setSavingProvider(provider);
    setStatus(null);
    try {
      const response = await fetch('/api/ai/keys', {
        body: JSON.stringify({ apiKey, provider }),
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
      });
      const payload = (await response.json().catch(() => null)) as {
        error?: string;
      } | null;
      if (!response.ok) {
        throw new Error(payload?.error ?? 'Unable to save key');
      }
      const label =
        PROVIDER_META.find((p) => p.id === provider)?.label ?? provider;
      setStatus(`${label} key saved.`);
    } catch (error) {
      setStatus(error instanceof Error ? error.message : 'Unable to save key');
    } finally {
      setSavingProvider(null);
    }
  };

  return (
    <div className="min-h-screen bg-gray-950">
      <Header user={user} />
      <main className="mx-auto max-w-7xl space-y-6 px-4 py-8">
        {status ? (
          <div className="rounded-xl border border-gray-800 bg-gray-900 px-4 py-3 text-sm text-gray-200">
            {status}
          </div>
        ) : null}

        <div className="grid gap-6 xl:grid-cols-2">
          <Card
            title="AI provider keys"
            description="Store provider keys securely for workflow and prompt execution."
          >
            <div className="space-y-4">
              {PROVIDER_META.map((provider) => (
                <div key={provider.id} className="space-y-2">
                  <label className="block space-y-2 text-sm text-gray-200">
                    <span>{provider.label}</span>
                    <input
                      className="w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100"
                      onChange={(event) =>
                        setKeys((prev) => ({
                          ...prev,
                          [provider.id]: event.target.value,
                        }))
                      }
                      placeholder={provider.placeholder}
                      type="password"
                      value={keys[provider.id]}
                    />
                  </label>
                  <Button
                    loading={savingProvider === provider.id}
                    onClick={() => saveKey(provider.id, keys[provider.id])}
                  >
                    Save {provider.label} key
                  </Button>
                </div>
              ))}
            </div>
          </Card>

          <Card
            title="Source control connections"
            description="Manage GitHub and GitLab connectivity for imports, commits, and pull requests."
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between rounded-xl border border-gray-800 bg-gray-800/40 px-4 py-3">
                <div>
                  <p className="text-sm font-medium text-gray-100">GitHub</p>
                  <p className="text-xs text-gray-400">
                    Connected through OAuth session
                  </p>
                </div>
                <Badge variant="success">Connected</Badge>
              </div>
              <div className="flex items-center justify-between rounded-xl border border-gray-800 bg-gray-800/40 px-4 py-3">
                <div>
                  <p className="text-sm font-medium text-gray-100">GitLab</p>
                  <p className="text-xs text-gray-400">
                    Optional self-hosted integration
                  </p>
                </div>
                <Button size="sm" variant="secondary">
                  Connect
                </Button>
              </div>
            </div>
          </Card>

          <Card
            title="Sandbox defaults"
            description="Tune CPU, timeout, and runtime defaults for new sandboxes."
          >
            <div className="grid gap-4 md:grid-cols-3">
              <label className="space-y-2 text-sm text-gray-200">
                <span>CPU</span>
                <input
                  className="w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100"
                  defaultValue="2"
                />
              </label>
              <label className="space-y-2 text-sm text-gray-200">
                <span>Timeout (min)</span>
                <input
                  className="w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100"
                  defaultValue="30"
                />
              </label>
              <label className="space-y-2 text-sm text-gray-200">
                <span>Runtime</span>
                <select
                  className="w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100"
                  defaultValue="node22"
                >
                  <option value="node22">node22</option>
                  <option value="python3.13">python3.13</option>
                </select>
              </label>
            </div>
          </Card>

          <Card
            title="Account"
            description="Current workspace operator details."
          >
            <div className="flex items-center gap-4 rounded-xl border border-gray-800 bg-gray-800/40 p-4">
              {user.avatarUrl ? (
                <img
                  alt={user.name}
                  className="h-16 w-16 rounded-full border border-gray-800 object-cover"
                  src={user.avatarUrl}
                />
              ) : (
                <div className="flex h-16 w-16 items-center justify-center rounded-full border border-gray-800 bg-gray-900 text-xl font-semibold text-indigo-200">
                  {user.name.slice(0, 1).toUpperCase()}
                </div>
              )}
              <div>
                <p className="text-base font-semibold text-gray-100">
                  {user.name}
                </p>
                <p className="text-sm text-gray-400">{user.email}</p>
              </div>
            </div>
          </Card>
        </div>
      </main>
    </div>
  );
}
