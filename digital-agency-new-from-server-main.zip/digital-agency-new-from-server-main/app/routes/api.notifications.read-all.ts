import { getUserNotifications, markAllRead } from '~/lib/notifications.server';
import { requireAuth } from '~/lib/session.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

export function loader() {
  return errorResponse('Method not allowed', 405);
}

export async function action({ request }: { request: Request }) {
  if (request.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  let session;
  try {
    session = await requireAuth(request);
  } catch {
    return errorResponse('Unauthorized', 401);
  }

  await markAllRead(session.userId);
  return Response.json(await getUserNotifications(session.userId));
}
