import type { LoaderFunctionArgs } from 'react-router';
import { requireAuth } from '~/lib/session.server';

export async function loader({ request }: LoaderFunctionArgs) {
  const { userId } = await requireAuth(request);
  return { userId };
}

export default function GitHubAppSettingsPage() {
  return (
    <div className="p-8 text-white max-w-2xl">
      <h1 className="text-2xl font-bold mb-2">GitHub App Integration</h1>
      <p className="text-gray-400 mb-6">
        Install the Cloud Platform GitHub App to enable automatic code analysis on
        push and pull requests.
      </p>
      <a
        href={`https://github.com/apps/${process.env.GITHUB_APP_SLUG ?? 'cloud-platform-dev'}/installations/new`}
        className="inline-flex items-center px-4 py-2 bg-gray-800 hover:bg-gray-700 border border-gray-600 rounded-lg text-white transition-colors"
        target="_blank"
        rel="noreferrer"
      >
        Install GitHub App →
      </a>
    </div>
  );
}
