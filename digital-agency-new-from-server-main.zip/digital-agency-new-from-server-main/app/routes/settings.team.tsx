import type { ActionFunctionArgs, LoaderFunctionArgs } from 'react-router';
import { redirect, useActionData, useLoaderData } from 'react-router';
import { Header } from '~/components/shared/Header';
import { TeamWorkspace } from '~/components/Team/TeamWorkspace';
import { db } from '~/lib/db.server';
import { requireAuth } from '~/lib/session.server';
import { TeamError, getTeamById, getUserTeams, transferOwnership } from '~/lib/teams.server';

function errorResponse(message: string, status: number) {
  return Response.json({ error: message }, { status });
}

export async function loader({ request }: LoaderFunctionArgs) {
  const user = await requireAuth(request);
  const url = new URL(request.url);
  const requestedTeamId = url.searchParams.get('teamId');
  const teams = await getUserTeams(user.userId);
  const selectedTeamSummary =
    teams.find((team) => team.id === requestedTeamId) ?? teams[0] ?? null;
  const team = selectedTeamSummary
    ? await getTeamById(selectedTeamSummary.id)
    : null;

  return {
    currentUserRole: selectedTeamSummary?.role ?? null,
    team: team
      ? {
          createdAt: team.createdAt.toISOString(),
          id: team.id,
          members: team.members.map((member) => ({
            id: member.id,
            joinedAt: member.joinedAt.toISOString(),
            role: member.role,
            user: member.user,
          })),
          name: team.name,
        }
      : null,
    teams: teams.map((teamEntry) => ({
      id: teamEntry.id,
      memberCount: teamEntry.memberCount,
      name: teamEntry.name,
      role: teamEntry.role,
    })),
    user,
  };
}

export async function action({ request }: ActionFunctionArgs) {
  const user = await requireAuth(request);
  const formData = await request.formData();
  const intent = String(formData.get('intent') ?? '');
  const teamId = String(formData.get('teamId') ?? '');

  if (!teamId) {
    return errorResponse('Team not found.', 404);
  }

  try {
    if (intent === 'transfer-ownership') {
      const newOwnerId = String(formData.get('newOwnerId') ?? '');
      if (!newOwnerId) {
        return errorResponse('Choose a new owner.', 400);
      }
      await transferOwnership(teamId, newOwnerId, user.userId);
      return redirect(`/settings/team?teamId=${teamId}`);
    }

    if (intent === 'delete-team') {
      const membership = await db.teamMember.findUnique({
        where: { teamId_userId: { teamId, userId: user.userId } },
      });
      if (!membership || membership.role !== 'OWNER') {
        return errorResponse('Forbidden', 403);
      }
      await db.team.delete({ where: { id: teamId } });
      return redirect('/settings/team');
    }

    return errorResponse('Unsupported action.', 400);
  } catch (error) {
    if (error instanceof TeamError) {
      return errorResponse(error.message, error.status);
    }
    return errorResponse('Unable to update team.', 500);
  }
}

export default function TeamSettingsPage() {
  const data = useLoaderData<typeof loader>();
  const actionData = useActionData<typeof action>() as
    | { error?: string }
    | undefined;

  return (
    <div className="min-h-screen bg-gray-950">
      <Header
        currentTeamId={data.team?.id}
        teams={data.teams}
        user={data.user}
      />
      <main className="mx-auto max-w-7xl space-y-6 px-4 py-8">
        <div className="space-y-2">
          <h1 className="text-3xl font-semibold text-gray-100">
            Team Workspace
          </h1>
          <p className="text-sm text-gray-400">
            Invite collaborators, manage access, and control ownership.
          </p>
        </div>
        <TeamWorkspace
          actionError={actionData?.error}
          currentUserRole={data.currentUserRole ?? undefined}
          team={data.team}
          teams={data.teams}
          user={data.user}
        />
      </main>
    </div>
  );
}
