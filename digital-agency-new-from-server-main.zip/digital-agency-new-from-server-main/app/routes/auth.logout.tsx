import type { ActionFunctionArgs } from 'react-router';
import { destroySession } from '../lib/session.server';

export async function action({ request }: ActionFunctionArgs) {
  return destroySession(request, '/');
}

export default function AuthLogoutRoute() {
  return null;
}
