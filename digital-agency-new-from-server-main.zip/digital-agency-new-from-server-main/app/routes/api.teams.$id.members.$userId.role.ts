import { db } from '~/lib/db.server';
import { updateMemberRoleSchema } from '~/lib/schemas.server';
import { TeamRole } from '~/lib/team-roles';
import { requireTeamRole } from '~/lib/team-auth.server';
import { TeamError, updateMemberRole } from '~/lib/teams.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

export function loader() {
  return errorResponse('Method not allowed', 405);
}

export async function action({
  params,
  request,
}: {
  params: { id?: string; userId?: string };
  request: Request;
}) {
  if (request.method !== 'PUT') {
    return errorResponse('Method not allowed', 405);
  }

  const teamId = params.id ?? '';
  const userId = params.userId ?? '';
  if (!teamId || !userId) {
    return errorResponse('Member not found', 404);
  }

  const team = await db.team.findUnique({ where: { id: teamId } });
  if (!team) {
    return errorResponse('Team not found', 404);
  }

  const payload = await request.json().catch(() => ({}));
  const parsed = updateMemberRoleSchema.safeParse(payload);
  if (!parsed.success) {
    return errorResponse('Invalid role payload', 400, parsed.error.flatten());
  }

  try {
    const { user } = await requireTeamRole(request, teamId, 'COLLABORATOR');
    const member = await updateMemberRole(
      teamId,
      userId,
      parsed.data.role === 'VIEWER' ? TeamRole.VIEWER : TeamRole.COLLABORATOR,
      user.userId,
    );

    return Response.json({ member });
  } catch (error) {
    if (error instanceof Response) {
      return error;
    }

    if (error instanceof TeamError) {
      return errorResponse(error.message, error.status);
    }

    return errorResponse(
      'Unable to update member role',
      500,
      error instanceof Error ? error.message : undefined,
    );
  }
}
