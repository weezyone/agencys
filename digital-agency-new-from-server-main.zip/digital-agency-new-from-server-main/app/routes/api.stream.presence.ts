import {
  createSSEResponse,
  createSSEStream,
  type SSEEvent,
} from '~/lib/sse.server';
import kv from '~/lib/kv.server';
import {
  getPresence,
  getUserColor,
  heartbeat,
  leavePresence,
  publishPresenceUpdate,
  type PresenceTab,
  type PresenceUser,
} from '~/lib/presence.server';
import { requireAuth } from '~/lib/session.server';
import { sleep } from '~/lib/utils';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

async function authenticate(request: Request) {
  try {
    return await requireAuth(request);
  } catch {
    return null;
  }
}

function parsePresenceSnapshot(value: unknown): PresenceUser[] | null {
  if (typeof value !== 'string') {
    return null;
  }

  try {
    const parsed = JSON.parse(value) as unknown;
    return Array.isArray(parsed) ? (parsed as PresenceUser[]) : null;
  } catch {
    return null;
  }
}

async function* presenceStream(
  projectId: string,
  user: PresenceUser,
  signal: AbortSignal,
): AsyncGenerator<SSEEvent> {
  let lastSnapshot = '';
  let lastHeartbeat = 0;

  try {
    await heartbeat(projectId, user);
    await publishPresenceUpdate(projectId);

    const initialUsers = await getPresence(projectId);
    lastSnapshot = JSON.stringify(initialUsers);
    yield {
      data: { count: initialUsers.length, users: initialUsers },
      event: 'presence',
    };

    while (!signal.aborted) {
      const now = Date.now();
      if (now - lastHeartbeat >= 10_000) {
        lastHeartbeat = now;
        yield { data: { ts: now }, event: 'heartbeat' };
      }

      const nextSnapshot = await kv.get<string>(`presence:updates:${projectId}`);
      if (typeof nextSnapshot === 'string' && nextSnapshot !== lastSnapshot) {
        lastSnapshot = nextSnapshot;
        const users = parsePresenceSnapshot(nextSnapshot) ?? (await getPresence(projectId));
        yield {
          data: { count: users.length, users },
          event: 'presence',
        };
      }

      await sleep(2_000);
    }
  } finally {
    await leavePresence(projectId, user.userId);
    await publishPresenceUpdate(projectId);
  }
}

async function handler(request: Request) {
  if (request.method !== 'GET') {
    return errorResponse('Method not allowed', 405);
  }

  const session = await authenticate(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  const url = new URL(request.url);
  const projectId = url.searchParams.get('projectId') ?? '';
  if (!projectId) {
    return errorResponse('Project ID is required', 400);
  }

  const rawTab = url.searchParams.get('activeTab');
  const activeTab =
    rawTab === 'git' ||
    rawTab === 'files' ||
    rawTab === 'downloads' ||
    rawTab === 'logs'
      ? rawTab
      : 'ai';

  return createSSEResponse(
    createSSEStream(
      presenceStream(
        projectId,
        {
          activeTab: activeTab as PresenceTab,
          color: getUserColor(session.userId),
          cursor: null,
          lastSeen: Date.now(),
          name: session.name,
          userId: session.userId,
        },
        request.signal,
      ),
      request.signal,
    ),
  );
}

export async function loader({ request }: { request: Request }) {
  return handler(request);
}

export function action() {
  return errorResponse('Method not allowed', 405);
}
