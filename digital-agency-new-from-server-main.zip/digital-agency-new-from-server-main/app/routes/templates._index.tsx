import type { ProjectTemplate } from '@prisma/client';
import { useEffect, useRef, useState } from 'react';
import type { LoaderFunctionArgs } from 'react-router';
import { useLoaderData, useLocation } from 'react-router';
import { CategoryFilter } from '~/components/Templates/CategoryFilter';
import { SearchBar } from '~/components/Templates/SearchBar';
import { TemplateGrid } from '~/components/Templates/TemplateGrid';
import { UseTemplateModal } from '~/components/Templates/UseTemplateModal';
import { Button } from '~/components/ui';
import {
  isTemplateStorageUnavailable,
  listTemplateCategories,
  listTemplates,
} from '~/lib/templates.server';

const PAGE_SIZE = 20;

export async function loader({ request }: LoaderFunctionArgs) {
  const url = new URL(request.url);
  const category = url.searchParams.get('category') || undefined;
  const search = url.searchParams.get('search') || undefined;

  try {
    const [{ templates, total }, categories] = await Promise.all([
      listTemplates({ category, search }),
      listTemplateCategories(),
    ]);

    return { templates, total, categories };
  } catch (error) {
    if (isTemplateStorageUnavailable(error)) {
      return { categories: [], templates: [], total: 0 };
    }

    throw error;
  }
}

export default function TemplatesPage() {
  const { categories, templates: initialTemplates, total: initialTotal } =
    useLoaderData<typeof loader>();
  const location = useLocation();
  const initialParams = new URLSearchParams(location.search);
  const [templates, setTemplates] = useState(initialTemplates);
  const [total, setTotal] = useState(initialTotal);
  const [selectedCategory, setSelectedCategory] = useState<string | undefined>(
    initialParams.get('category') || undefined,
  );
  const [searchQuery, setSearchQuery] = useState(initialParams.get('search') || '');
  const [currentPage, setCurrentPage] = useState(() => {
    const offset = Number(initialParams.get('offset') || '0');
    return Number.isFinite(offset) ? Math.floor(offset / PAGE_SIZE) + 1 : 1;
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeTemplate, setActiveTemplate] = useState<ProjectTemplate | null>(null);
  const isFirstFetch = useRef(true);

  useEffect(() => {
    if (isFirstFetch.current) {
      isFirstFetch.current = false;
      return;
    }

    const controller = new AbortController();
    const searchParams = new URLSearchParams();

    if (selectedCategory) {
      searchParams.set('category', selectedCategory);
    }
    if (searchQuery.trim()) {
      searchParams.set('search', searchQuery.trim());
    }
    searchParams.set('limit', String(PAGE_SIZE));
    searchParams.set('offset', String((currentPage - 1) * PAGE_SIZE));

    setLoading(true);
    setError(null);

    void fetch(`/api/templates?${searchParams.toString()}`, {
      signal: controller.signal,
    })
      .then(async (response) => {
        const payload = (await response.json().catch(() => null)) as {
          error?: string;
          templates?: ProjectTemplate[];
          total?: number;
        } | null;

        if (!response.ok) {
          throw new Error(payload?.error ?? 'Unable to load templates');
        }

        setTemplates(payload?.templates ?? []);
        setTotal(payload?.total ?? 0);
      })
      .catch((nextError) => {
        if (controller.signal.aborted) {
          return;
        }

        setError(
          nextError instanceof Error
            ? nextError.message
            : 'Unable to load templates',
        );
      })
      .finally(() => {
        if (!controller.signal.aborted) {
          setLoading(false);
        }
      });

    return () => controller.abort();
  }, [currentPage, searchQuery, selectedCategory]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <div className="mx-auto max-w-7xl space-y-8 px-4 py-10 sm:px-6 lg:px-8">
      <div className="space-y-3">
        <h1 className="text-3xl font-semibold text-gray-100">
          Template Marketplace
        </h1>
        <p className="text-lg text-gray-400">
          Start your next project in seconds
        </p>
      </div>

      <div className="space-y-4 rounded-2xl border border-gray-800 bg-gray-900 p-5">
        <CategoryFilter
          categories={categories}
          onChange={(category) => {
            setSelectedCategory(category);
            setCurrentPage(1);
          }}
          selected={selectedCategory}
        />
        <SearchBar
          onChange={(value) => {
            setSearchQuery(value);
            setCurrentPage(1);
          }}
          placeholder="Search by name, description, or tag"
          value={searchQuery}
        />
      </div>

      {error ? (
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-200">
          {error}
        </div>
      ) : null}

      <TemplateGrid
        loading={loading}
        onUseTemplate={(template) => setActiveTemplate(template)}
        templates={templates}
      />

      {total > PAGE_SIZE ? (
        <div className="flex items-center justify-between gap-4 rounded-2xl border border-gray-800 bg-gray-900 p-4">
          <p className="text-sm text-gray-400">
            Page {currentPage} of {totalPages}
          </p>
          <div className="flex gap-3">
            <Button
              disabled={currentPage === 1 || loading}
              onClick={() => setCurrentPage((page) => Math.max(1, page - 1))}
              variant="secondary"
            >
              Previous
            </Button>
            <Button
              disabled={currentPage >= totalPages || loading}
              onClick={() => setCurrentPage((page) => Math.min(totalPages, page + 1))}
            >
              Next
            </Button>
          </div>
        </div>
      ) : null}

      {activeTemplate ? (
        <UseTemplateModal
          isOpen={!!activeTemplate}
          onClose={() => setActiveTemplate(null)}
          template={activeTemplate}
        />
      ) : null}
    </div>
  );
}
