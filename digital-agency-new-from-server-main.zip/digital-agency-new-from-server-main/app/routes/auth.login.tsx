import { useState } from 'react';
import type { ActionFunctionArgs, LoaderFunctionArgs } from 'react-router';
import {
  Form,
  Link,
  redirect,
  useActionData,
  useLoaderData,
  useNavigation,
  useSearchParams,
} from 'react-router';
import { Button, Card } from '~/components/ui';
import { isConfiguredLocalDatabaseReachable } from '~/lib/database-availability.server';
import db from '~/lib/db.server';
import { hashPassword, verifyPassword } from '~/lib/password.server';
import {
  createUserSession,
  getOptionalAuth,
  type SessionData,
} from '~/lib/session.server';

const SESSION_TTL_MS = 1000 * 60 * 60 * 24;

function canUseLocalAuthFallback() {
  return process.env.NODE_ENV !== 'production';
}

function isDatabaseUnavailableError(error: unknown) {
  if (!(error instanceof Error)) {
    return false;
  }

  const prismaError = error as Error & { code?: string; errorCode?: string };
  return (
    prismaError.name === 'PrismaClientInitializationError' ||
    prismaError.code === 'P1001' ||
    prismaError.errorCode === 'P1001' ||
    prismaError.code === 'P2021' ||
    prismaError.errorCode === 'P2021' ||
    error.message.includes("Can't reach database server") ||
    error.message.includes('does not exist in the current database')
  );
}

function createLocalDevSession({
  email,
  expiresAt,
  name,
  redirectTo,
}: {
  email: string;
  expiresAt: number;
  name: string;
  redirectTo: string;
}) {
  const session: SessionData = {
    accessToken: 'local-dev-token',
    avatarUrl: undefined,
    email,
    expiresAt,
    name: name || email.split('@')[0],
    provider: 'email',
    userId: `local-${Buffer.from(email).toString('hex').slice(0, 16)}`,
  };
  return createUserSession(session, redirectTo);
}

export async function loader({ request }: LoaderFunctionArgs) {
  const user = await getOptionalAuth(request);
  if (user) {
    throw redirect('/');
  }
  return { dbConfigured: Boolean(process.env.DATABASE_URL) };
}

function bad(message: string) {
  return Response.json({ error: message }, { status: 400 });
}

function databaseUnavailable() {
  return Response.json(
    { error: 'Database is currently unavailable. Please try again later.' },
    { status: 503 },
  );
}

export async function action({ request }: ActionFunctionArgs) {
  const formData = await request.formData();
  const intent = String(formData.get('intent') ?? 'login');
  const email = String(formData.get('email') ?? '')
    .trim()
    .toLowerCase();
  const password = String(formData.get('password') ?? '');
  const name = String(formData.get('name') ?? '').trim();
  const redirectTo = String(formData.get('redirectTo') ?? '/') || '/';

  if (!email || !email.includes('@')) {
    return bad('A valid email is required.');
  }
  if (password.length < 8) {
    return bad('Password must be at least 8 characters.');
  }

  const expiresAt = Date.now() + SESSION_TTL_MS;

  if (!process.env.DATABASE_URL) {
    return createLocalDevSession({ email, expiresAt, name, redirectTo });
  }

  if (!(await isConfiguredLocalDatabaseReachable())) {
    if (canUseLocalAuthFallback()) {
      return createLocalDevSession({ email, expiresAt, name, redirectTo });
    }

    return databaseUnavailable();
  }

  try {
    if (intent === 'register') {
      if (!name) {
        return bad('Name is required.');
      }
      const existing = await db.user.findUnique({ where: { email } });
      if (existing) {
        return bad('An account with that email already exists. Try logging in.');
      }
      const user = await db.user.create({
        data: {
          email,
          name,
          passwordHash: hashPassword(password),
        },
        select: { avatarUrl: true, email: true, id: true, name: true },
      });
      return createUserSession(
        {
          accessToken: 'email-session',
          avatarUrl: user.avatarUrl ?? undefined,
          email: user.email,
          expiresAt,
          name: user.name,
          provider: 'email',
          userId: user.id,
        },
        redirectTo,
      );
    }

    // login
    const user = await db.user.findUnique({
      where: { email },
      select: {
        avatarUrl: true,
        email: true,
        id: true,
        name: true,
        passwordHash: true,
      },
    });
    if (
      !user ||
      !user.passwordHash ||
      !verifyPassword(password, user.passwordHash)
    ) {
      return bad('Invalid email or password.');
    }

    return createUserSession(
      {
        accessToken: 'email-session',
        avatarUrl: user.avatarUrl ?? undefined,
        email: user.email,
        expiresAt,
        name: user.name,
        provider: 'email',
        userId: user.id,
      },
      redirectTo,
    );
  } catch (error) {
    if (!isDatabaseUnavailableError(error)) {
      throw error;
    }

    if (canUseLocalAuthFallback()) {
      return createLocalDevSession({ email, expiresAt, name, redirectTo });
    }

    return databaseUnavailable();
  }
}

export default function LoginPage() {
  const { dbConfigured } = useLoaderData<typeof loader>();
  const actionData = useActionData<typeof action>() as
    | { error?: string }
    | undefined;
  const navigation = useNavigation();
  const [searchParams] = useSearchParams();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const redirectTo =
    searchParams.get('redirectTo') ?? searchParams.get('returnTo') ?? '/';
  const submitting = navigation.state === 'submitting';

  return (
    <div className="min-h-screen bg-gray-950">
      <main className="mx-auto flex max-w-md flex-col gap-6 px-4 py-16">
        <div className="text-center">
          <h1 className="text-3xl font-semibold text-gray-100">
            Cloud-First AI Platform
          </h1>
          <p className="mt-2 text-sm text-gray-400">
            {mode === 'login'
              ? 'Sign in to your account.'
              : 'Create a new account.'}
          </p>
        </div>

        <Card>
          <Form method="post" className="space-y-4">
            <input type="hidden" name="intent" value={mode} />
            <input type="hidden" name="redirectTo" value={redirectTo} />

            {mode === 'register' ? (
              <label className="block space-y-2 text-sm text-gray-200">
                <span>Name</span>
                <input
                  className="w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100"
                  name="name"
                  placeholder="Ada Lovelace"
                  required
                  type="text"
                />
              </label>
            ) : null}

            <label className="block space-y-2 text-sm text-gray-200">
              <span>Email</span>
              <input
                autoComplete="email"
                className="w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100"
                name="email"
                placeholder="you@example.com"
                required
                type="email"
              />
            </label>

            <label className="block space-y-2 text-sm text-gray-200">
              <span>Password</span>
              <input
                autoComplete={
                  mode === 'login' ? 'current-password' : 'new-password'
                }
                className="w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100"
                minLength={8}
                name="password"
                placeholder="At least 8 characters"
                required
                type="password"
              />
            </label>

            {actionData?.error ? (
              <p className="rounded-lg border border-red-500/40 bg-red-500/10 px-3 py-2 text-sm text-red-200">
                {actionData.error}
              </p>
            ) : null}

            <Button className="w-full" loading={submitting} type="submit">
              {mode === 'login' ? 'Sign in' : 'Create account'}
            </Button>
          </Form>

          <div className="mt-4 flex items-center justify-between text-sm text-gray-400">
            <button
              className="text-indigo-300 hover:text-indigo-200"
              onClick={() => setMode(mode === 'login' ? 'register' : 'login')}
              type="button"
            >
              {mode === 'login'
                ? 'Need an account? Register'
                : 'Already registered? Sign in'}
            </button>
            <Link className="hover:text-gray-200" to="/auth/github">
              Use GitHub
            </Link>
          </div>

          {!dbConfigured ? (
            <p className="mt-4 text-xs text-amber-300">
              No DATABASE_URL configured — sessions will be ephemeral and
              local-only.
            </p>
          ) : null}
        </Card>
      </main>
    </div>
  );
}
