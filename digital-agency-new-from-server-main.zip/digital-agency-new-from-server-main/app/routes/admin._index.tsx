import type { LoaderFunctionArgs } from 'react-router';
import { Link, useLoaderData } from 'react-router';
import { AuditLogFeed } from '~/components/Admin/AuditLogFeed';
import { StatsGrid } from '~/components/Admin/StatsGrid';
import { SystemHealthCard } from '~/components/Admin/SystemHealthCard';
import { UserTable } from '~/components/Admin/UserTable';
import { getPlatformStats, getSystemHealth, listUsers, requireAdmin } from '~/lib/admin.server';

export async function loader({ request }: LoaderFunctionArgs) {
  await requireAdmin(request);
  const [stats, health, users] = await Promise.all([
    getPlatformStats(),
    getSystemHealth(),
    listUsers({ limit: 20, offset: 0 }),
  ]);

  return {
    health,
    stats,
    totalUsers: users.total,
    users: users.users.map((user) => ({
      ...user,
      createdAt: user.createdAt.toISOString(),
      lastActiveAt: user.lastActiveAt?.toISOString() ?? null,
    })),
  };
}

export default function AdminPage() {
  const { health, stats, totalUsers, users } = useLoaderData<typeof loader>();

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100">
      <main className="mx-auto max-w-7xl space-y-6 px-4 py-8 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-4 rounded-3xl border border-gray-800 bg-gray-900/90 p-6 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-sm font-medium uppercase tracking-[0.25em] text-indigo-300">🛡 Admin Panel</p>
            <h1 className="mt-2 text-3xl font-semibold tracking-tight text-gray-100">Platform control center</h1>
            <p className="mt-2 text-sm text-gray-400">Monitor platform health, review audit activity, and manage member access.</p>
          </div>
          <Link
            className="inline-flex h-10 items-center justify-center rounded-lg border border-gray-700 bg-gray-800 px-4 text-sm font-medium text-gray-100 transition hover:bg-gray-700"
            reloadDocument
            to="/admin"
          >
            Refresh
          </Link>
        </div>

        <StatsGrid stats={stats} />

        <div className="grid grid-cols-1 gap-6 xl:grid-cols-[minmax(320px,1fr)_minmax(0,2fr)]">
          <SystemHealthCard health={health} />
          <AuditLogFeed limit={8} />
        </div>

        <UserTable initialUsers={users} total={totalUsers} />
      </main>
    </div>
  );
}
