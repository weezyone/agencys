import {
  PROVIDER_DEFINITIONS,
  validateProviderConfig,
  type AIProvider,
} from '~/lib/ai-providers';

const PROVIDER_DISPLAY: Record<AIProvider, string> = {
  claude: 'Claude',
  codex: 'Codex',
  huggingface: 'Hugging Face',
  nvidia: 'NVIDIA NIM',
  openrouter: 'OpenRouter',
};

const PROVIDER_IDS = Object.keys(PROVIDER_DEFINITIONS) as AIProvider[];

export async function loader({ request }: { request: Request }) {
  if (request.method !== 'GET') {
    return Response.json({ error: 'Method not allowed' }, { status: 405 });
  }

  return Response.json({
    providers: PROVIDER_IDS.map((id) => ({
      available: validateProviderConfig(id).valid,
      id,
      model: PROVIDER_DEFINITIONS[id].model,
      name: PROVIDER_DISPLAY[id],
    })),
  });
}
