import { getUsageSummary } from '~/lib/billing.server';
import { requireAuth } from '~/lib/session.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

async function authenticate(request: Request) {
  try {
    return await requireAuth(request);
  } catch {
    return null;
  }
}

async function handler(request: Request) {
  if (request.method !== 'GET') {
    return errorResponse('Method not allowed', 405);
  }

  const session = await authenticate(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  try {
    const usage = await getUsageSummary(session.userId);
    return Response.json({ usage });
  } catch (error) {
    return errorResponse(
      'Unable to load billing usage',
      500,
      error instanceof Error ? error.message : undefined,
    );
  }
}

export async function loader({ request }: { request: Request }) {
  return handler(request);
}

export async function action({ request }: { request: Request }) {
  return handler(request);
}
