import {
  createSSEResponse,
  createSSEStream,
  pollSandboxLogs,
  withHeartbeat,
} from '~/lib/sse.server';
import { requireAuth } from '~/lib/session.server';

function errorResponse(message: string, status: number) {
  return Response.json({ error: message }, { status });
}

async function authenticate(request: Request) {
  try {
    return await requireAuth(request);
  } catch {
    return null;
  }
}

function getSandboxId(request: Request) {
  return new URL(request.url).pathname.split('/').filter(Boolean).at(-1) ?? '';
}

function getLastEventIndex(request: Request, url: URL) {
  const value =
    url.searchParams.get('lastEventId') ??
    request.headers.get('Last-Event-ID') ??
    '0';
  const parsed = Number.parseInt(value, 10);
  return Number.isNaN(parsed) || parsed < 0 ? 0 : parsed;
}

async function handler(request: Request) {
  if (request.method !== 'GET') {
    return errorResponse('Method not allowed', 405);
  }

  const session = await authenticate(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  const url = new URL(request.url);
  const sandboxId = getSandboxId(request);
  if (!sandboxId) {
    return errorResponse('Sandbox ID is required', 400);
  }

  const lastEventIndex = getLastEventIndex(request, url);
  const stream = createSSEStream(
    withHeartbeat(pollSandboxLogs(sandboxId, lastEventIndex), {
      intervalMs: 15_000,
      signal: request.signal,
    }),
    request.signal,
  );

  return createSSEResponse(stream);
}

export async function loader({ request }: { request: Request }) {
  return handler(request);
}

export function action() {
  return errorResponse('Method not allowed', 405);
}
