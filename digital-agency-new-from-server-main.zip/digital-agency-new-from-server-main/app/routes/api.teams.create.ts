import { createTeamSchema } from '~/lib/schemas.server';
import { requireAuth } from '~/lib/session.server';
import { createTeam, getTeamById, TeamError } from '~/lib/teams.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

export function loader() {
  return errorResponse('Method not allowed', 405);
}

export async function action({ request }: { request: Request }) {
  let session;
  try {
    session = await requireAuth(request);
  } catch {
    return errorResponse('Unauthorized', 401);
  }

  const payload = await request.json().catch(() => ({}));
  const parsed = createTeamSchema.safeParse(payload);
  if (!parsed.success) {
    return errorResponse('Invalid team payload', 400, parsed.error.flatten());
  }

  try {
    const team = await createTeam(session.userId, parsed.data);
    const populatedTeam = await getTeamById(team.id);

    return Response.json({ team: populatedTeam ?? team });
  } catch (error) {
    if (error instanceof TeamError) {
      return errorResponse(error.message, error.status);
    }

    return errorResponse(
      'Unable to create team',
      500,
      error instanceof Error ? error.message : undefined,
    );
  }
}
