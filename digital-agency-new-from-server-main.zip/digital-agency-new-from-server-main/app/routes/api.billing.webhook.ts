import { handleStripeWebhook } from '~/lib/billing.server';

function successResponse() {
  return Response.json({ received: true }, { status: 200 });
}

async function handler(request: Request) {
  if (request.method !== 'POST') {
    return Response.json({ error: 'Method not allowed' }, { status: 405 });
  }

  const body = await request.text();
  const signature =
    request.headers.get('stripe-signature') ??
    request.headers.get('STRIPE_WEBHOOK_SECRET') ??
    '';

  try {
    await handleStripeWebhook(body, signature);
  } catch (error) {
    if (error instanceof Error) {
      console.warn(`[billing] Stripe webhook ignored: ${error.message}`);
    }
  }

  return successResponse();
}

export async function loader({ request }: { request: Request }) {
  return handler(request);
}

export async function action({ request }: { request: Request }) {
  return handler(request);
}
