'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { useSSE } from '~/hooks/useSSE';
import type { Notification } from '~/types/notifications';
import { normalizeNotification } from '~/types/notifications';

interface NotificationsResponse {
  notifications?: unknown[];
  unreadCount?: number;
}

export function useNotifications() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const notificationsRef = useRef<Notification[]>([]);
  const unreadCountRef = useRef(0);

  useEffect(() => {
    notificationsRef.current = notifications;
  }, [notifications]);

  useEffect(() => {
    unreadCountRef.current = unreadCount;
  }, [unreadCount]);

  useEffect(() => {
    let cancelled = false;

    const loadNotifications = async () => {
      setIsLoading(true);

      try {
        const response = await fetch('/api/notifications');
        if (cancelled) {
          return;
        }

        if (response.status === 401) {
          setIsAuthenticated(false);
          setNotifications([]);
          setUnreadCount(0);
          return;
        }

        if (!response.ok) {
          throw new Error('Failed to load notifications');
        }

        const payload = (await response.json()) as NotificationsResponse;
        const nextNotifications = (payload.notifications ?? [])
          .map((notification) => normalizeNotification(notification))
          .filter((notification): notification is Notification => Boolean(notification));

        setNotifications(nextNotifications);
        setUnreadCount(typeof payload.unreadCount === 'number' ? payload.unreadCount : 0);
        setIsAuthenticated(true);
      } catch {
        if (!cancelled) {
          setIsAuthenticated(false);
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    };

    void loadNotifications();

    return () => {
      cancelled = true;
    };
  }, []);

  const handleEvent = useCallback(
    ({ data, type }: { type: string; data: unknown }) => {
      if (type !== 'notification' || !data || typeof data !== 'object') {
        return;
      }

      const nextNotification = normalizeNotification(
        (data as { notification?: unknown }).notification,
      );
      if (!nextNotification) {
        return;
      }

      setNotifications((current) => [
        nextNotification,
        ...current.filter((notification) => notification.id !== nextNotification.id),
      ]);
      if (!nextNotification.readAt) {
        setUnreadCount((current) => current + 1);
      }
    },
    [],
  );

  useSSE({
    enabled: isAuthenticated,
    onEvent: handleEvent,
    url: '/api/stream/notifications',
  });

  const markRead = useCallback(async (id: string) => {
    const existing = notificationsRef.current.find((notification) => notification.id === id);
    if (!existing || existing.readAt) {
      return;
    }

    const response = await fetch(`/api/notifications/${id}/read`, {
      method: 'POST',
    });
    if (!response.ok) {
      return;
    }

    setNotifications((current) =>
      current.map((notification) =>
        notification.id === id
          ? {
              ...notification,
              readAt: notification.readAt ?? new Date().toISOString(),
            }
          : notification,
      ),
    );
    setUnreadCount((current) => Math.max(0, current - 1));
  }, []);

  const markAllRead = useCallback(async () => {
    if (unreadCountRef.current === 0) {
      return;
    }

    const response = await fetch('/api/notifications/read-all', {
      method: 'POST',
    });
    if (!response.ok) {
      return;
    }

    const readAt = new Date().toISOString();
    setNotifications((current) =>
      current.map((notification) => ({
        ...notification,
        readAt: notification.readAt ?? readAt,
      })),
    );
    setUnreadCount(0);
  }, []);

  return {
    isLoading,
    markAllRead,
    markRead,
    notifications,
    unreadCount,
  };
}
