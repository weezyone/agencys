'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { useSSE } from '~/hooks/useSSE';
import type { PresenceTab, PresenceUser } from '~/lib/presence.server';

const PRESENCE_TABS = new Set<PresenceTab>([
  'ai',
  'git',
  'files',
  'downloads',
  'logs',
]);

function getActiveTab(): PresenceTab {
  if (typeof window === 'undefined') {
    return 'ai';
  }

  const hash = window.location.hash.replace(/^#/, '');
  return PRESENCE_TABS.has(hash as PresenceTab) ? (hash as PresenceTab) : 'ai';
}

function isPresenceUser(value: unknown): value is PresenceUser {
  return Boolean(
    value &&
      typeof value === 'object' &&
      typeof (value as PresenceUser).userId === 'string' &&
      typeof (value as PresenceUser).name === 'string' &&
      typeof (value as PresenceUser).color === 'string' &&
      typeof (value as PresenceUser).activeTab === 'string' &&
      typeof (value as PresenceUser).lastSeen === 'number',
  );
}

export function usePresence(
  projectId: string,
  currentUser: { id: string; name: string },
) {
  const [activeTab, setActiveTab] = useState<PresenceTab>(() => getActiveTab());
  const [allUsers, setAllUsers] = useState<PresenceUser[]>([]);

  useEffect(() => {
    if (typeof window === 'undefined') {
      return;
    }

    const syncActiveTab = () => {
      setActiveTab(getActiveTab());
    };

    syncActiveTab();
    window.addEventListener('hashchange', syncActiveTab);
    return () => {
      window.removeEventListener('hashchange', syncActiveTab);
    };
  }, []);

  const handleEvent = useCallback(
    ({ data, type }: { type: string; data: unknown }) => {
      if (type !== 'presence' || !data || typeof data !== 'object') {
        return;
      }

      const nextUsers = Array.isArray((data as { users?: unknown[] }).users)
        ? ((data as { users: unknown[] }).users.filter(isPresenceUser) as PresenceUser[])
        : [];

      setAllUsers(nextUsers);
    },
    [],
  );

  useSSE({
    enabled: Boolean(projectId),
    onEvent: handleEvent,
    url: projectId
      ? `/api/stream/presence?projectId=${encodeURIComponent(projectId)}&activeTab=${activeTab}`
      : '',
  });

  useEffect(() => {
    if (!projectId || typeof window === 'undefined') {
      return;
    }

    const sendHeartbeat = async () => {
      await fetch('/api/presence/heartbeat', {
        body: JSON.stringify({ activeTab, projectId }),
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
      }).catch(() => undefined);
    };

    void sendHeartbeat();
    const heartbeatInterval = window.setInterval(() => {
      void sendHeartbeat();
    }, 5_000);

    return () => {
      window.clearInterval(heartbeatInterval);
    };
  }, [activeTab, projectId]);

  const users = useMemo(
    () => allUsers.filter((user) => user.userId !== currentUser.id),
    [allUsers, currentUser.id],
  );

  return {
    allUsers,
    count: allUsers.length,
    users,
  };
}
