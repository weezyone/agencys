'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import type { LogEntry, WorkflowState, WorkflowStep } from '../types';

type ApiWorkflowStatus =
  | 'INITIALIZING'
  | 'RUNNING'
  | 'SUSPENDED'
  | 'COMPLETED'
  | 'FAILED'
  | 'EXPIRED';
type ApiStepStatus =
  | 'PENDING'
  | 'RUNNING'
  | 'COMPLETED'
  | 'FAILED'
  | 'RETRYING';

type WorkflowEvent = {
  type:
    | 'step_started'
    | 'step_completed'
    | 'step_failed'
    | 'workflow_completed'
    | 'workflow_failed'
    | 'log';
  stepName?: string;
  data?: unknown;
  message?: string;
  timestamp: number;
};

type WorkflowRecord = {
  id: string;
  projectId: string;
  status: ApiWorkflowStatus;
};

type WorkflowStepRecord = {
  id: string;
  stepName: string;
  status: ApiStepStatus;
  inputs: Record<string, unknown>;
  outputs?: Record<string, unknown> | null;
  retryCount: number;
  startedAt?: string | Date | null;
  completedAt?: string | Date | null;
};

function normalizeWorkflowStatus(
  status: ApiWorkflowStatus,
): WorkflowState['status'] {
  switch (status) {
    case 'COMPLETED':
      return 'completed';
    case 'FAILED':
    case 'EXPIRED':
      return 'failed';
    case 'SUSPENDED':
      return 'suspended';
    case 'RUNNING':
      return 'running';
    case 'INITIALIZING':
    default:
      return 'initializing';
  }
}

function normalizeStepStatus(status: ApiStepStatus): WorkflowStep['status'] {
  switch (status) {
    case 'RUNNING':
    case 'RETRYING':
      return 'running';
    case 'COMPLETED':
      return 'completed';
    case 'FAILED':
      return 'failed';
    case 'PENDING':
    default:
      return 'pending';
  }
}

function toDate(value?: string | Date | null) {
  return value ? new Date(value) : undefined;
}

function toLogEntries(events: WorkflowEvent[]): LogEntry[] {
  return events
    .filter((event) => event.type === 'log' || event.type === 'step_failed')
    .map((event) => ({
      level: event.type === 'step_failed' ? 'error' : 'info',
      message: event.message ?? event.stepName ?? 'Workflow event',
      timestamp: new Date(event.timestamp),
    }));
}

function buildWorkflowState(
  fallbackId: string,
  workflow: WorkflowRecord | null,
  steps: WorkflowStepRecord[],
  events: WorkflowEvent[],
): WorkflowState {
  const normalizedSteps = steps.map((step) => ({
    completedAt: toDate(step.completedAt),
    id: step.id,
    inputs: step.inputs ?? {},
    name: step.stepName,
    outputs: step.outputs ?? undefined,
    retryCount: step.retryCount ?? 0,
    startedAt: toDate(step.startedAt),
    status: normalizeStepStatus(step.status),
  }));
  const currentStepIndex = normalizedSteps.findIndex(
    (step) => step.status === 'running',
  );

  return {
    artifacts: [],
    currentStep:
      currentStepIndex >= 0 ? currentStepIndex + 1 : normalizedSteps.length,
    id: workflow?.id ?? fallbackId,
    logs: toLogEntries(events),
    projectId: workflow?.projectId ?? '',
    status: workflow
      ? normalizeWorkflowStatus(workflow.status)
      : 'initializing',
    steps: normalizedSteps,
  };
}

export function useWorkflow(workflowId?: string) {
  const [workflowRecord, setWorkflowRecord] = useState<WorkflowRecord | null>(
    null,
  );
  const [steps, setSteps] = useState<WorkflowStepRecord[]>([]);
  const [events, setEvents] = useState<WorkflowEvent[]>([]);

  const refresh = useCallback(async () => {
    if (!workflowId) {
      return;
    }

    const response = await fetch(`/api/workflow/${workflowId}`, {
      credentials: 'same-origin',
      headers: { Accept: 'application/json' },
    });

    if (!response.ok) {
      if (response.status === 404) {
        setWorkflowRecord(null);
        setSteps([]);
        setEvents([]);
      }
      return;
    }

    const payload = (await response.json()) as {
      workflow: WorkflowRecord;
      steps: WorkflowStepRecord[];
      recentEvents: WorkflowEvent[];
    };

    setWorkflowRecord(payload.workflow);
    setSteps(payload.steps ?? []);
    setEvents(payload.recentEvents ?? []);
  }, [workflowId]);

  useEffect(() => {
    void refresh();
    if (!workflowId) {
      return undefined;
    }

    const interval = window.setInterval(() => {
      void refresh();
    }, 2000);

    return () => window.clearInterval(interval);
  }, [refresh, workflowId]);

  const cancel = useCallback(async () => {
    if (!workflowId) {
      return;
    }

    await fetch(`/api/workflow/${workflowId}`, {
      credentials: 'same-origin',
      headers: { Accept: 'application/json' },
      method: 'DELETE',
    });
    await refresh();
  }, [refresh, workflowId]);

  const workflow = useMemo(
    () =>
      buildWorkflowState(
        workflowId ?? 'workflow-pending',
        workflowRecord,
        steps,
        events,
      ),
    [events, steps, workflowId, workflowRecord],
  );
  const isRunning =
    workflow.status === 'initializing' ||
    workflow.status === 'running' ||
    workflow.status === 'suspended';

  return {
    cancel,
    events,
    isRunning,
    steps: workflow.steps,
    workflow,
  };
}
