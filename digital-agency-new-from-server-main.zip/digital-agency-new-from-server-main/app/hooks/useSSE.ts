'use client';

import { useCallback, useEffect, useRef, useState } from 'react';

const DEFAULT_RECONNECT_DELAY_MS = 1_000;
const MAX_RECONNECT_DELAY_MS = 30_000;
const SSE_EVENT_TYPES = [
  'step_started',
  'step_completed',
  'step_failed',
  'log',
  'workflow_completed',
  'workflow_failed',
  'stdout',
  'stderr',
  'exit',
  'heartbeat',
  'timeout',
  'error',
  'notification',
  'presence',
] as const;

export interface SSEOptions {
  url: string;
  enabled?: boolean;
  onEvent?: (event: { type: string; data: unknown }) => void;
  onError?: (error: Error) => void;
  reconnectDelayMs?: number;
}

export interface SSEState {
  connected: boolean;
  error: string | null;
  lastEventId: string | null;
}

export interface WorkflowStreamEvent {
  id?: string;
  type: string;
  data: Record<string, unknown>;
}

export interface StreamLogEntry {
  id: string;
  type: 'stdout' | 'stderr' | 'exit';
  data?: string;
  exitCode?: number;
  timestamp?: number;
}

function parseEventData(rawData: string): unknown {
  try {
    return JSON.parse(rawData);
  } catch {
    return rawData;
  }
}

function buildStreamUrl(url: string, lastEventId: string | null) {
  if (!lastEventId) {
    return url;
  }

  const target = new URL(
    url,
    typeof window === 'undefined' ? 'http://localhost' : window.location.origin,
  );
  target.searchParams.set('lastEventId', lastEventId);
  return target.toString();
}

export function useSSE(options: SSEOptions): SSEState {
  const {
    enabled = true,
    onError,
    onEvent,
    reconnectDelayMs = DEFAULT_RECONNECT_DELAY_MS,
    url,
  } = options;
  const [state, setState] = useState<SSEState>({
    connected: false,
    error: null,
    lastEventId: null,
  });
  const eventSourceRef = useRef<EventSource | null>(null);
  const reconnectTimeoutRef = useRef<number | null>(null);
  const reconnectAttemptsRef = useRef(0);
  const lastEventIdRef = useRef<string | null>(null);
  const onEventRef = useRef(onEvent);
  const onErrorRef = useRef(onError);
  const disposedRef = useRef(false);

  useEffect(() => {
    onEventRef.current = onEvent;
    onErrorRef.current = onError;
  }, [onError, onEvent]);

  const clearReconnect = useCallback(() => {
    if (reconnectTimeoutRef.current != null) {
      window.clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }
  }, []);

  const closeSource = useCallback(() => {
    eventSourceRef.current?.close();
    eventSourceRef.current = null;
  }, []);

  useEffect(() => {
    if (
      !enabled ||
      typeof window === 'undefined' ||
      typeof EventSource === 'undefined' ||
      !url
    ) {
      clearReconnect();
      closeSource();
      setState((current) => ({ ...current, connected: false }));
      return;
    }

    disposedRef.current = false;

    const connect = () => {
      if (disposedRef.current) {
        return;
      }

      clearReconnect();
      closeSource();

      const source = new EventSource(
        buildStreamUrl(url, lastEventIdRef.current),
      );
      eventSourceRef.current = source;

      const handleMessage = (type: string) => (event: MessageEvent<string>) => {
        const data = parseEventData(event.data);
        if (event.lastEventId) {
          lastEventIdRef.current = event.lastEventId;
        }

        setState({
          connected: true,
          error: null,
          lastEventId: lastEventIdRef.current,
        });
        onEventRef.current?.({ data, type });
      };

      const listeners = SSE_EVENT_TYPES.map((type) => {
        const listener = handleMessage(type);
        source.addEventListener(type, listener as EventListener);
        return { listener, type };
      });

      source.onmessage = handleMessage('message');
      source.onopen = () => {
        reconnectAttemptsRef.current = 0;
        setState((current) => ({ ...current, connected: true, error: null }));
      };
      source.onerror = () => {
        if (disposedRef.current) {
          return;
        }

        closeSource();
        const nextDelay = Math.min(
          reconnectDelayMs * 2 ** reconnectAttemptsRef.current,
          MAX_RECONNECT_DELAY_MS,
        );
        reconnectAttemptsRef.current += 1;
        setState((current) => ({
          ...current,
          connected: false,
          error: 'Connection lost',
        }));
        const error = new Error('SSE connection lost');
        onErrorRef.current?.(error);
        reconnectTimeoutRef.current = window.setTimeout(connect, nextDelay);
      };

      return () => {
        for (const { listener, type } of listeners) {
          source.removeEventListener(type, listener as EventListener);
        }
      };
    };

    const cleanupListeners = connect();

    return () => {
      disposedRef.current = true;
      cleanupListeners?.();
      clearReconnect();
      closeSource();
    };
  }, [clearReconnect, closeSource, enabled, reconnectDelayMs, url]);

  return state;
}

export function useWorkflowStream(
  workflowId: string | null,
  options?: {
    onStepCompleted?: (stepName: string) => void;
    onWorkflowCompleted?: () => void;
    onLog?: (message: string, level: string) => void;
  },
) {
  const [events, setEvents] = useState<WorkflowStreamEvent[]>([]);

  useEffect(() => {
    setEvents([]);
  }, [workflowId]);

  const handleEvent = useCallback(
    ({ data, type }: { type: string; data: unknown }) => {
      if (!data || typeof data !== 'object' || type === 'heartbeat') {
        return;
      }

      const nextEvent: WorkflowStreamEvent = {
        data: data as Record<string, unknown>,
        id:
          typeof (data as { id?: unknown }).id === 'string'
            ? (data as { id: string }).id
            : undefined,
        type,
      };

      setEvents((current) => [...current, nextEvent].slice(-500));

      if (
        type === 'step_completed' &&
        typeof nextEvent.data.stepName === 'string'
      ) {
        options?.onStepCompleted?.(nextEvent.data.stepName);
      }
      if (type === 'workflow_completed') {
        options?.onWorkflowCompleted?.();
      }
      if (type === 'log' && typeof nextEvent.data.message === 'string') {
        options?.onLog?.(
          nextEvent.data.message,
          typeof nextEvent.data.level === 'string'
            ? nextEvent.data.level
            : 'info',
        );
      }
    },
    [options],
  );

  const state = useSSE({
    enabled: Boolean(workflowId),
    onEvent: handleEvent,
    url: workflowId ? `/api/stream/workflow/${workflowId}` : '',
  });

  return {
    connected: state.connected,
    error: state.error,
    events,
  };
}

export function useSandboxStream(sandboxId: string | null) {
  const [logs, setLogs] = useState<StreamLogEntry[]>([]);

  useEffect(() => {
    setLogs([]);
  }, [sandboxId]);

  const handleEvent = useCallback(
    ({ data, type }: { type: string; data: unknown }) => {
      if (!data || typeof data !== 'object' || type === 'heartbeat') {
        return;
      }

      if (type !== 'stdout' && type !== 'stderr' && type !== 'exit') {
        return;
      }

      const payload = data as {
        data?: unknown;
        exitCode?: unknown;
        timestamp?: unknown;
      };

      const entry: StreamLogEntry = {
        data: typeof payload.data === 'string' ? payload.data : undefined,
        exitCode:
          typeof payload.exitCode === 'number' ? payload.exitCode : undefined,
        id:
          typeof crypto !== 'undefined' && 'randomUUID' in crypto
            ? crypto.randomUUID()
            : `${type}-${typeof payload.timestamp === 'number' ? payload.timestamp : Date.now()}`,
        timestamp:
          typeof payload.timestamp === 'number' ? payload.timestamp : undefined,
        type,
      };

      setLogs((current) => [...current, entry].slice(-1_000));
    },
    [],
  );

  const state = useSSE({
    enabled: Boolean(sandboxId),
    onEvent: handleEvent,
    url: sandboxId ? `/api/stream/sandbox/${sandboxId}` : '',
  });

  return {
    connected: state.connected,
    error: state.error,
    logs,
  };
}
