import { useEffect, useMemo, useState } from 'react';

export interface FileTreeNode {
  id: string;
  name: string;
  path: string;
  type: 'file' | 'directory';
  children?: FileTreeNode[];
  changed?: boolean;
}

const defaultTree: FileTreeNode[] = [
  {
    id: 'app',
    name: 'app',
    path: 'app',
    type: 'directory',
    children: [
      {
        id: 'app-routes-index',
        name: '_index.tsx',
        path: 'app/routes/_index.tsx',
        type: 'file',
        changed: true,
      },
      {
        id: 'app-routes-workspace',
        name: 'workspace.$projectId.tsx',
        path: 'app/routes/workspace.$projectId.tsx',
        type: 'file',
      },
    ],
  },
  {
    id: 'api',
    name: 'api',
    path: 'api',
    type: 'directory',
    children: [
      {
        id: 'api-ai-task',
        name: 'task.ts',
        path: 'api/ai/task.ts',
        type: 'file',
        changed: true,
      },
    ],
  },
];

export function buildFileTree(
  paths: string[],
  changedPaths: string[] = [],
): FileTreeNode[] {
  const root: FileTreeNode[] = [];

  const findOrCreateDirectory = (
    nodes: FileTreeNode[],
    segment: string,
    path: string,
  ) => {
    let existing = nodes.find(
      (node) => node.path === path && node.type === 'directory',
    );
    if (!existing) {
      existing = {
        id: path,
        name: segment,
        path,
        type: 'directory',
        children: [],
      };
      nodes.push(existing);
    }
    return existing;
  };

  for (const rawPath of paths) {
    const normalizedPath = rawPath
      .replace(/^\/+/, '')
      .replace(/^vercel\/sandbox\/workspace\//, '')
      .replace(/^workspace\//, '');
    if (!normalizedPath) {
      continue;
    }

    const segments = normalizedPath.split('/').filter(Boolean);
    let current = root;
    let accumulatedPath = '';

    segments.forEach((segment, index) => {
      accumulatedPath = accumulatedPath
        ? `${accumulatedPath}/${segment}`
        : segment;
      const isLeaf = index === segments.length - 1;

      if (isLeaf) {
        if (!current.some((node) => node.path === accumulatedPath)) {
          current.push({
            changed: changedPaths.includes(accumulatedPath),
            id: accumulatedPath,
            name: segment,
            path: accumulatedPath,
            type: 'file',
          });
        }
        return;
      }

      const nextDirectory = findOrCreateDirectory(
        current,
        segment,
        accumulatedPath,
      );
      current = nextDirectory.children ?? [];
      nextDirectory.children = current;
    });
  }

  const sortNodes = (nodes: FileTreeNode[]): FileTreeNode[] =>
    nodes
      .sort((left, right) => {
        if (left.type !== right.type) {
          return left.type === 'directory' ? -1 : 1;
        }
        return left.name.localeCompare(right.name);
      })
      .map(
        (node): FileTreeNode => ({
          ...node,
          children: node.children ? sortNodes(node.children) : undefined,
        }),
      );

  return sortNodes(root);
}

function collectFirstFilePath(nodes: FileTreeNode[]): string {
  for (const node of nodes) {
    if (node.type === 'file') {
      return node.path;
    }
    if (node.children?.length) {
      const nested = collectFirstFilePath(node.children);
      if (nested) {
        return nested;
      }
    }
  }
  return '';
}

function collectExpanded(nodes: FileTreeNode[]): string[] {
  return nodes
    .filter((node) => node.type === 'directory')
    .map((node) => node.path);
}

export function useFileTree(initialTree: FileTreeNode[] = defaultTree) {
  const [selectedPath, setSelectedPath] = useState(
    collectFirstFilePath(initialTree),
  );
  const [selectedPaths, setSelectedPaths] = useState<string[]>([]);
  const [expandedPaths, setExpandedPaths] = useState<string[]>(
    collectExpanded(initialTree),
  );

  useEffect(() => {
    setSelectedPath((current) => current || collectFirstFilePath(initialTree));
    setExpandedPaths(collectExpanded(initialTree));
  }, [initialTree]);

  const flattened = useMemo(() => {
    const nodes: FileTreeNode[] = [];
    const walk = (tree: FileTreeNode[]) => {
      for (const node of tree) {
        nodes.push(node);
        if (node.children) {
          walk(node.children);
        }
      }
    };
    walk(initialTree);
    return nodes;
  }, [initialTree]);

  const toggleExpanded = (path: string) => {
    setExpandedPaths((current) =>
      current.includes(path)
        ? current.filter((entry) => entry !== path)
        : [...current, path],
    );
  };

  const toggleSelected = (path: string) => {
    setSelectedPaths((current) =>
      current.includes(path)
        ? current.filter((entry) => entry !== path)
        : [...current, path],
    );
  };

  return {
    expandedPaths,
    flattened,
    isExpanded: (path: string) => expandedPaths.includes(path),
    isSelected: (path: string) => selectedPaths.includes(path),
    selectedPath,
    selectedPaths,
    setSelectedPath,
    setSelectedPaths,
    toggleExpanded,
    toggleSelected,
    tree: initialTree,
  };
}
