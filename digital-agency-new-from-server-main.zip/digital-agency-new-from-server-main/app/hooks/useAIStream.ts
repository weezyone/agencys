'use client';

import { useCallback, useRef, useState } from 'react';

export interface AIStreamState {
  content: string;
  isStreaming: boolean;
  error: string | null;
  usage: { promptTokens: number; completionTokens: number } | null;
}

interface StartAIStreamConfig {
  provider: 'claude' | 'codex' | 'openrouter' | 'huggingface' | 'nvidia';
  prompt: string;
  contextFiles?: Array<{ path: string; content: string }>;
  sandboxId?: string;
  taskType?: 'generate' | 'refactor' | 'test' | 'debug';
}

const INITIAL_STATE: AIStreamState = {
  content: '',
  error: null,
  isStreaming: false,
  usage: null,
};

export function useAIStream() {
  const [state, setState] = useState<AIStreamState>(INITIAL_STATE);
  const abortRef = useRef<AbortController | null>(null);

  const stopStream = useCallback(() => {
    abortRef.current?.abort();
    abortRef.current = null;
    setState((current) => ({ ...current, isStreaming: false }));
  }, []);

  const reset = useCallback(() => {
    abortRef.current?.abort();
    abortRef.current = null;
    setState(INITIAL_STATE);
  }, []);

  const startStream = useCallback(
    async (config: StartAIStreamConfig) => {
      stopStream();
      const controller = new AbortController();
      abortRef.current = controller;
      setState({ ...INITIAL_STATE, isStreaming: true });

      try {
        const payload = { ...config, stream: !config.sandboxId };
        const response = await fetch(
          config.sandboxId ? '/api/ai/task' : '/api/ai/task?stream=true',
          {
            body: JSON.stringify(payload),
            headers: {
              'Content-Type': 'application/json',
            },
            method: 'POST',
            signal: controller.signal,
          },
        );

        if (!response.ok) {
          const errorPayload = (await response.json().catch(() => null)) as {
            error?: string;
          } | null;
          throw new Error(errorPayload?.error ?? 'Failed to start AI stream');
        }

        if (config.sandboxId) {
          const result = (await response.json()) as {
            result?: {
              content?: string;
              usage?: { promptTokens?: number; completionTokens?: number };
            };
          };

          setState({
            content: result.result?.content ?? '',
            error: null,
            isStreaming: false,
            usage: {
              completionTokens: result.result?.usage?.completionTokens ?? 0,
              promptTokens: result.result?.usage?.promptTokens ?? 0,
            },
          });
          return;
        }

        if (!response.body) {
          throw new Error('Streaming response body is unavailable');
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        const processChunk = (chunk: string) => {
          if (!chunk.trim()) {
            return false;
          }

          for (const line of chunk.split('\n')) {
            if (!line.startsWith('data:')) {
              continue;
            }

            const value = line.slice(5).trim();
            if (!value) {
              continue;
            }

            if (value === '[DONE]') {
              setState((current) => ({ ...current, isStreaming: false }));
              return true;
            }

            const event = JSON.parse(value) as
              | { type: 'token'; content: string }
              | {
                  type: 'complete';
                  usage?: { promptTokens?: number; completionTokens?: number };
                }
              | { type: 'error'; error?: string };

            if (event.type === 'token') {
              setState((current) => ({
                ...current,
                content: `${current.content}${event.content}`,
              }));
              continue;
            }

            if (event.type === 'complete') {
              setState((current) => ({
                ...current,
                isStreaming: false,
                usage: {
                  completionTokens: event.usage?.completionTokens ?? 0,
                  promptTokens: event.usage?.promptTokens ?? 0,
                },
              }));
              continue;
            }

            throw new Error(event.error ?? 'AI stream failed');
          }

          return false;
        };

        while (true) {
          const { done, value } = await reader.read();
          buffer += decoder.decode(value ?? new Uint8Array(), {
            stream: !done,
          });

          let separatorIndex = buffer.indexOf('\n\n');
          while (separatorIndex >= 0) {
            const chunk = buffer.slice(0, separatorIndex);
            buffer = buffer.slice(separatorIndex + 2);
            if (processChunk(chunk)) {
              abortRef.current = null;
              return;
            }
            separatorIndex = buffer.indexOf('\n\n');
          }

          if (done) {
            if (buffer) {
              processChunk(buffer);
            }
            break;
          }
        }

        setState((current) => ({ ...current, isStreaming: false }));
      } catch (error) {
        if (!controller.signal.aborted) {
          setState((current) => ({
            ...current,
            error:
              error instanceof Error
                ? error.message
                : 'Failed to stream AI response',
            isStreaming: false,
          }));
        }
      } finally {
        if (abortRef.current === controller) {
          abortRef.current = null;
        }
      }
    },
    [stopStream],
  );

  return { reset, startStream, state, stopStream };
}
