import type { Notification, NotificationPreference, Prisma } from '@prisma/client';
import {
  NotificationType,
  type NotificationType as NotificationTypeValue,
} from '~/types/notifications';
import { getBaseUrl } from './auth.server';
import { db } from './db.server';
import kv from './kv.server';

const LIVE_NOTIFICATIONS_TTL_SECONDS = 60 * 5;

type NotificationMetadata = Record<string, unknown>;
type PreferenceKey =
  | 'workflowComplete'
  | 'workflowFailed'
  | 'sandboxTimeout'
  | 'teamInvite'
  | 'artifactReady';

const DEFAULT_PREFERENCES = {
  workflowComplete: true,
  workflowFailed: true,
  sandboxTimeout: true,
  teamInvite: true,
  artifactReady: true,
  emailEnabled: false,
  webhookUrl: null,
} satisfies Pick<
  NotificationPreference,
  | 'workflowComplete'
  | 'workflowFailed'
  | 'sandboxTimeout'
  | 'teamInvite'
  | 'artifactReady'
  | 'emailEnabled'
  | 'webhookUrl'
>;

function liveNotificationsKey(userId: string) {
  return `notifications:live:${userId}`;
}

function unreadCountKey(userId: string) {
  return `notif:unread:${userId}`;
}

function normalizeMetadata(
  metadata?: NotificationMetadata,
): Prisma.InputJsonValue | Prisma.JsonNullValueInput {
  if (!metadata) {
    return {};
  }

  return JSON.parse(
    JSON.stringify(metadata, (_key, value) => {
      if (value instanceof Date) {
        return value.toISOString();
      }

      return value;
    }),
  ) as Prisma.InputJsonValue;
}

function toRecord(value: unknown): NotificationMetadata {
  if (value && typeof value === 'object' && !Array.isArray(value)) {
    return value as NotificationMetadata;
  }

  return {};
}

function toDate(value: unknown): Date {
  return value instanceof Date ? value : new Date(String(value));
}

function hydrateNotification(value: Notification | Record<string, unknown>): Notification {
  const notification = value as Notification & {
    createdAt: Date | string;
    readAt: Date | string | null;
  };

  return {
    ...notification,
    createdAt: toDate(notification.createdAt),
    readAt: notification.readAt ? toDate(notification.readAt) : null,
  };
}

function defaultPreferences(userId: string): NotificationPreference {
  return {
    id: '',
    userId,
    ...DEFAULT_PREFERENCES,
  };
}

async function readUnreadCountFromStore(userId: string) {
  const cached = await kv.get<number>(unreadCountKey(userId));
  if (typeof cached === 'number') {
    return cached;
  }

  const unreadCount = await db.notification.count({
    where: { readAt: null, userId },
  });
  await kv.set(unreadCountKey(userId), unreadCount);
  return unreadCount;
}

async function incrementUnreadCount(userId: string) {
  const cached = await kv.get<number>(unreadCountKey(userId));
  if (typeof cached === 'number') {
    await kv.set(unreadCountKey(userId), cached + 1);
    return;
  }

  const unreadCount = await db.notification.count({
    where: { readAt: null, userId },
  });
  await kv.set(unreadCountKey(userId), unreadCount);
}

async function syncUnreadCount(userId: string) {
  const unreadCount = await db.notification.count({
    where: { readAt: null, userId },
  });
  await kv.set(unreadCountKey(userId), unreadCount);
  return unreadCount;
}

async function queueDeliveries(params: {
  userId: string;
  notification: Notification;
  emailHtml?: string;
  emailSubject?: string;
}) {
  try {
    const preferences = await getPreferences(params.userId);

    if (preferences.emailEnabled && params.emailHtml && params.emailSubject) {
      const user = await db.user.findUnique({
        select: { email: true },
        where: { id: params.userId },
      });

      if (user?.email) {
        void sendEmailNotification({
          html: params.emailHtml,
          subject: params.emailSubject,
          to: user.email,
        }).catch(() => undefined);
      }
    }

    if (preferences.webhookUrl) {
      void deliverWebhook(preferences.webhookUrl, {
        body: params.notification.body,
        metadata: toRecord(params.notification.metadata),
        timestamp: params.notification.createdAt.toISOString(),
        title: params.notification.title,
        type: params.notification.type,
      }).catch(() => undefined);
    }
  } catch {
    // Notification delivery is best-effort.
  }
}

async function notifyIfEnabled(params: {
  userId: string;
  preferenceKey: PreferenceKey;
  type: NotificationTypeValue;
  title: string;
  body: string;
  metadata: NotificationMetadata;
  emailHtml?: string;
}) {
  const preferences = await getPreferences(params.userId);
  if (!preferences[params.preferenceKey]) {
    return;
  }

  const notification = await createNotification({
    body: params.body,
    metadata: params.metadata,
    title: params.title,
    type: params.type,
    userId: params.userId,
  });

  void queueDeliveries({
    emailHtml: params.emailHtml,
    emailSubject: params.title,
    notification,
    userId: params.userId,
  }).catch(() => undefined);
}

export async function createNotification(params: {
  userId: string;
  type: NotificationTypeValue;
  title: string;
  body: string;
  metadata?: Record<string, unknown>;
}): Promise<Notification> {
  const notification = await db.notification.create({
    data: {
      body: params.body,
      metadata: normalizeMetadata(params.metadata),
      title: params.title,
      type: params.type,
      userId: params.userId,
    },
  });

  void incrementUnreadCount(params.userId).catch(() => undefined);
  void pushLiveNotification(params.userId, notification).catch(() => undefined);

  return notification;
}

export async function notifyWorkflowComplete(
  userId: string,
  workflowId: string,
  projectName: string,
): Promise<void> {
  await notifyIfEnabled({
    body: `Workflow ${workflowId} for ${projectName} completed successfully.`,
    emailHtml: renderWorkflowCompleteEmail(projectName, workflowId),
    metadata: { projectName, workflowId },
    preferenceKey: 'workflowComplete',
    title: `Workflow complete: ${projectName}`,
    type: NotificationType.WORKFLOW_COMPLETE,
    userId,
  });
}

export async function notifyWorkflowFailed(
  userId: string,
  workflowId: string,
  projectName: string,
  failedStep: string,
): Promise<void> {
  await notifyIfEnabled({
    body: `Workflow ${workflowId} for ${projectName} failed at ${failedStep}.`,
    emailHtml: renderWorkflowFailedEmail(projectName, failedStep),
    metadata: { failedStep, projectName, workflowId },
    preferenceKey: 'workflowFailed',
    title: `Workflow failed: ${projectName}`,
    type: NotificationType.WORKFLOW_FAILED,
    userId,
  });
}

export async function notifySandboxTimeout(
  userId: string,
  sandboxId: string,
  projectName: string,
  percentUsed: number,
): Promise<void> {
  await notifyIfEnabled({
    body: `Sandbox ${sandboxId} for ${projectName} reached ${percentUsed}% usage and timed out.`,
    emailHtml: renderSimpleEmail('Sandbox timeout', [
      ['Project', projectName],
      ['Sandbox ID', sandboxId],
      ['Usage', `${percentUsed}%`],
    ]),
    metadata: { percentUsed, projectName, sandboxId },
    preferenceKey: 'sandboxTimeout',
    title: `Sandbox timeout: ${projectName}`,
    type: NotificationType.SANDBOX_TIMEOUT,
    userId,
  });
}

export async function notifyArtifactReady(
  userId: string,
  artifactId: string,
  artifactName: string,
  downloadUrl: string,
): Promise<void> {
  await notifyIfEnabled({
    body: `${artifactName} is ready to download.`,
    emailHtml: renderArtifactReadyEmail(artifactName, downloadUrl),
    metadata: { artifactId, artifactName, downloadUrl },
    preferenceKey: 'artifactReady',
    title: `Artifact ready: ${artifactName}`,
    type: NotificationType.ARTIFACT_READY,
    userId,
  });
}

export async function notifyTeamInvite(
  userId: string,
  teamName: string,
  inviterName: string,
  inviteToken: string,
): Promise<void> {
  const baseUrl = getBaseUrl();
  await notifyIfEnabled({
    body: `${inviterName} invited you to join ${teamName}.`,
    emailHtml: renderTeamInviteEmail(
      teamName,
      inviterName,
      inviteToken,
      baseUrl,
    ),
    metadata: { inviteToken, inviterName, teamName },
    preferenceKey: 'teamInvite',
    title: `Team invite: ${teamName}`,
    type: NotificationType.TEAM_INVITE,
    userId,
  });
}

export async function getUserNotifications(
  userId: string,
  options?: {
    limit?: number;
    offset?: number;
    unreadOnly?: boolean;
  },
): Promise<{ notifications: Notification[]; unreadCount: number; total: number }> {
  const limit = Math.min(Math.max(options?.limit ?? 20, 1), 100);
  const offset = Math.max(options?.offset ?? 0, 0);
  const unreadOnly = options?.unreadOnly ?? false;
  const where: Prisma.NotificationWhereInput = {
    userId,
    ...(unreadOnly ? { readAt: null } : {}),
  };

  const [notifications, total, unreadCount] = await Promise.all([
    db.notification.findMany({
      orderBy: { createdAt: 'desc' },
      skip: offset,
      take: limit,
      where,
    }),
    db.notification.count({ where }),
    readUnreadCountFromStore(userId),
  ]);

  return { notifications, total, unreadCount };
}

export async function markNotificationRead(
  notificationId: string,
  userId: string,
): Promise<void> {
  const result = await db.notification.updateMany({
    data: { readAt: new Date() },
    where: { id: notificationId, readAt: null, userId },
  });

  if (result.count > 0) {
    await syncUnreadCount(userId);
  }
}

export async function markAllRead(userId: string): Promise<void> {
  await db.notification.updateMany({
    data: { readAt: new Date() },
    where: { readAt: null, userId },
  });
  await kv.set(unreadCountKey(userId), 0);
}

export async function deleteNotification(
  notificationId: string,
  userId: string,
): Promise<void> {
  const existing = await db.notification.findFirst({
    select: { id: true, readAt: true },
    where: { id: notificationId, userId },
  });
  if (!existing) {
    return;
  }

  await db.notification.delete({ where: { id: notificationId } });
  if (!existing.readAt) {
    await syncUnreadCount(userId);
  }
}

export async function getPreferences(
  userId: string,
): Promise<NotificationPreference> {
  const preferences = await db.notificationPreference.findUnique({
    where: { userId },
  });

  return preferences ?? defaultPreferences(userId);
}

export async function updatePreferences(
  userId: string,
  prefs: Partial<NotificationPreference>,
): Promise<NotificationPreference> {
  const data = {
    ...(prefs.workflowComplete !== undefined
      ? { workflowComplete: prefs.workflowComplete }
      : {}),
    ...(prefs.workflowFailed !== undefined
      ? { workflowFailed: prefs.workflowFailed }
      : {}),
    ...(prefs.sandboxTimeout !== undefined
      ? { sandboxTimeout: prefs.sandboxTimeout }
      : {}),
    ...(prefs.teamInvite !== undefined ? { teamInvite: prefs.teamInvite } : {}),
    ...(prefs.artifactReady !== undefined
      ? { artifactReady: prefs.artifactReady }
      : {}),
    ...(prefs.emailEnabled !== undefined
      ? { emailEnabled: prefs.emailEnabled }
      : {}),
    ...(prefs.webhookUrl !== undefined ? { webhookUrl: prefs.webhookUrl } : {}),
  };

  return db.notificationPreference.upsert({
    create: {
      userId,
      ...DEFAULT_PREFERENCES,
      ...data,
    },
    update: data,
    where: { userId },
  });
}

export async function pushLiveNotification(
  userId: string,
  notification: Notification,
): Promise<void> {
  const key = liveNotificationsKey(userId);
  const existing = (await kv.get<Array<Record<string, unknown>>>(key)) ?? [];
  await kv.set(key, [...existing, notification].slice(-50), {
    ex: LIVE_NOTIFICATIONS_TTL_SECONDS,
  });
}

export async function drainLiveNotifications(
  userId: string,
): Promise<Notification[]> {
  const key = liveNotificationsKey(userId);
  const notifications = (await kv.get<Array<Record<string, unknown>>>(key)) ?? [];
  await kv.del(key);
  return notifications.map((notification) => hydrateNotification(notification));
}

export async function sendEmailNotification(params: {
  to: string;
  subject: string;
  html: string;
}): Promise<void> {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    return;
  }

  try {
    await fetch('https://api.resend.com/emails', {
      body: JSON.stringify({
        from:
          process.env.RESEND_FROM_EMAIL ??
          'Cloud-First AI Development Platform <notifications@example.com>',
        html: params.html,
        subject: params.subject,
        to: params.to,
      }),
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      method: 'POST',
    });
  } catch {
    // Email delivery is best-effort.
  }
}

export async function deliverWebhook(
  webhookUrl: string,
  payload: {
    type: string;
    title: string;
    body: string;
    metadata: Record<string, unknown>;
    timestamp: string;
  },
): Promise<void> {
  const body = JSON.stringify(payload);

  const send = async () => {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5_000);

    try {
      return await fetch(webhookUrl, {
        body,
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
        signal: controller.signal,
      });
    } finally {
      clearTimeout(timeout);
    }
  };

  try {
    const response = await send();
    if (response.status >= 500 && response.status <= 599) {
      try {
        await send();
      } catch {
        // Webhook delivery is best-effort.
      }
    }
  } catch {
    // Webhook delivery is best-effort.
  }
}

function escapeHtml(value: string) {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function renderSimpleEmail(title: string, rows: Array<[string, string]>) {
  const rowMarkup = rows
    .map(
      ([label, value]) => `
        <tr>
          <td style="padding:12px 16px;border-bottom:1px solid #e5e7eb;font-weight:600;width:180px;">${escapeHtml(label)}</td>
          <td style="padding:12px 16px;border-bottom:1px solid #e5e7eb;">${escapeHtml(value)}</td>
        </tr>`,
    )
    .join('');

  return `
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" style="width:100%;max-width:640px;border-collapse:collapse;font-family:Arial,sans-serif;background:#ffffff;border:1px solid #e5e7eb;">
      <tr>
        <td style="padding:20px 24px;background:#111827;color:#ffffff;font-size:20px;font-weight:700;">${escapeHtml(title)}</td>
      </tr>
      ${rowMarkup}
    </table>
  `.trim();
}

export function renderWorkflowCompleteEmail(
  projectName: string,
  workflowId: string,
): string {
  return renderSimpleEmail('Workflow complete', [
    ['Project', projectName],
    ['Workflow ID', workflowId],
    ['Status', 'Completed successfully'],
  ]);
}

export function renderWorkflowFailedEmail(
  projectName: string,
  failedStep: string,
): string {
  return renderSimpleEmail('Workflow failed', [
    ['Project', projectName],
    ['Failed step', failedStep],
    ['Status', 'Needs attention'],
  ]);
}

export function renderTeamInviteEmail(
  teamName: string,
  inviterName: string,
  inviteToken: string,
  baseUrl: string,
): string {
  const inviteUrl = `${baseUrl.replace(/\/$/, '')}/teams/invites/accept?token=${encodeURIComponent(inviteToken)}`;
  return `
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" style="width:100%;max-width:640px;border-collapse:collapse;font-family:Arial,sans-serif;background:#ffffff;border:1px solid #e5e7eb;">
      <tr>
        <td style="padding:20px 24px;background:#111827;color:#ffffff;font-size:20px;font-weight:700;">Team invite</td>
      </tr>
      <tr>
        <td style="padding:12px 16px;border-bottom:1px solid #e5e7eb;">${escapeHtml(inviterName)} invited you to join <strong>${escapeHtml(teamName)}</strong>.</td>
      </tr>
      <tr>
        <td style="padding:12px 16px;border-bottom:1px solid #e5e7eb;">Invite token: <code>${escapeHtml(inviteToken)}</code></td>
      </tr>
      <tr>
        <td style="padding:16px;"><a href="${escapeHtml(inviteUrl)}" style="display:inline-block;padding:10px 16px;background:#2563eb;color:#ffffff;text-decoration:none;border-radius:4px;">Accept invite</a></td>
      </tr>
    </table>
  `.trim();
}

export function renderArtifactReadyEmail(
  artifactName: string,
  downloadUrl: string,
): string {
  return `
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" style="width:100%;max-width:640px;border-collapse:collapse;font-family:Arial,sans-serif;background:#ffffff;border:1px solid #e5e7eb;">
      <tr>
        <td style="padding:20px 24px;background:#111827;color:#ffffff;font-size:20px;font-weight:700;">Artifact ready</td>
      </tr>
      <tr>
        <td style="padding:12px 16px;border-bottom:1px solid #e5e7eb;">${escapeHtml(artifactName)} is ready to download.</td>
      </tr>
      <tr>
        <td style="padding:16px;"><a href="${escapeHtml(downloadUrl)}" style="display:inline-block;padding:10px 16px;background:#2563eb;color:#ffffff;text-decoration:none;border-radius:4px;">Download artifact</a></td>
      </tr>
    </table>
  `.trim();
}
