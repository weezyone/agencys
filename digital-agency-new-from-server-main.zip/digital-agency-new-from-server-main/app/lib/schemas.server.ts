import { z } from 'zod';

const gitRepositoryAccessSchema = z.object({
  repositoryUrl: z.string().url(),
  accessToken: z.string().min(1),
  provider: z.enum(['github', 'gitlab']).optional(),
  baseUrl: z.string().url().optional(),
});

const gitAccessRefinement = (
  value: {
    projectId?: string;
    repositoryUrl?: string;
    accessToken?: string;
  },
  ctx: z.RefinementCtx,
) => {
  if (value.projectId || (value.repositoryUrl && value.accessToken)) {
    return;
  }

  ctx.addIssue({
    code: z.ZodIssueCode.custom,
    message: 'Provide projectId or repositoryUrl with accessToken',
    path: ['projectId'],
  });
};

export const createBranchSchema = z.object({
  projectId: z.string().uuid(),
  branchName: z
    .string()
    .regex(/^[a-zA-Z0-9-_/]+$/, 'Invalid branch name')
    .min(1)
    .max(100),
  baseBranch: z.string().optional(),
});

export const createCommitSchema = z.object({
  projectId: z.string().uuid(),
  message: z.string().min(5).max(200),
  files: z
    .array(z.object({ path: z.string().min(1), content: z.string() }))
    .min(1)
    .max(100),
  branch: z.string().min(1),
});

export const createPRSchema = z.object({
  projectId: z.string().uuid(),
  title: z.string().min(1).max(200),
  body: z.string().max(10000).optional(),
  head: z.string().min(1),
  base: z.string().optional(),
});

export const createArtifactSchema = z.object({
  projectId: z.string().uuid(),
  workflowId: z.string().uuid().optional(),
  name: z.string().min(1).max(200).default('archive.zip'),
  files: z
    .array(
      z.object({
        path: z.string().min(1).max(500),
        content: z.string(),
      }),
    )
    .min(1)
    .max(1000),
});

export const listArtifactsSchema = z.object({
  projectId: z.string().uuid(),
  limit: z.coerce.number().int().min(1).max(100).default(20),
  offset: z.coerce.number().int().min(0).default(0),
});

export const createBranchRequestSchema = z
  .object({
    projectId: z.string().uuid().optional(),
    branchName: createBranchSchema.shape.branchName,
    baseBranch: createBranchSchema.shape.baseBranch,
  })
  .merge(gitRepositoryAccessSchema.partial())
  .superRefine(gitAccessRefinement);

export const createCommitRequestSchema = z
  .object({
    projectId: z.string().uuid().optional(),
    message: createCommitSchema.shape.message,
    files: createCommitSchema.shape.files,
    branch: createCommitSchema.shape.branch,
  })
  .merge(gitRepositoryAccessSchema.partial())
  .superRefine(gitAccessRefinement);

export const createPRRequestSchema = z
  .object({
    projectId: z.string().uuid().optional(),
    title: createPRSchema.shape.title,
    body: createPRSchema.shape.body,
    head: createPRSchema.shape.head,
    base: createPRSchema.shape.base,
  })
  .merge(gitRepositoryAccessSchema.partial())
  .superRefine(gitAccessRefinement);

export const gitDiffQuerySchema = z
  .object({
    projectId: z.string().uuid().optional(),
    base: z.string().optional(),
    head: z.string().optional(),
    rawDiff: z.string().optional(),
  })
  .merge(gitRepositoryAccessSchema.partial())
  .superRefine((value, ctx) => {
    gitAccessRefinement(value, ctx);
    if (!value.rawDiff && (!value.base || !value.head)) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'Provide base and head when rawDiff is not supplied',
        path: ['base'],
      });
    }
  });

export const createSandboxSchema = z.object({
  projectId: z.string().uuid(),
  vcpus: z.number().int().min(1).max(8).default(2),
  timeoutMinutes: z.number().int().min(5).max(300).default(5),
  runtime: z.enum(['node22', 'python3.13']).default('node22'),
  ports: z.array(z.number().int().min(1).max(65535)).max(4).optional(),
  repositoryUrl: z.string().url().optional(),
  branch: z.string().optional(),
});

export const executeCommandSchema = z.object({
  command: z.string().min(1).max(2000),
  cwd: z.string().optional(),
  env: z.record(z.string()).optional(),
});

export const aiTaskSchema = z.object({
  sandboxId: z.string().optional(),
  provider: z.enum(['claude', 'codex', 'openrouter', 'huggingface', 'nvidia']),
  prompt: z.string().min(10).max(2000),
  contextFiles: z
    .array(
      z.object({
        path: z.string().min(1),
        content: z.string().max(50000),
      }),
    )
    .max(20)
    .optional(),
  stream: z.boolean().default(false),
  taskType: z
    .enum(['generate', 'refactor', 'test', 'debug'])
    .default('generate'),
});

export const startWorkflowSchema = z
  .object({
    projectId: z.string().uuid(),
    workflowType: z.enum(['cloud-task', 'git-commit']),
    task: z.string().min(10).max(2000).optional(),
    provider: z
      .enum(['claude', 'codex', 'openrouter', 'huggingface', 'nvidia'])
      .default('nvidia'),
    sandboxConfig: z
      .object({
        vcpus: z.number().int().min(1).max(8).default(2),
        timeoutMinutes: z.number().int().min(5).max(300).default(30),
        runtime: z.enum(['node22', 'python3.13']).default('node22'),
      })
      .optional(),
    repositoryUrl: z.string().url().optional(),
    branch: z.string().optional(),
    files: z
      .array(z.object({ path: z.string(), content: z.string() }))
      .optional(),
    commitMessage: z.string().min(5).max(200).optional(),
  })
  .superRefine((value, ctx) => {
    if (value.workflowType === 'cloud-task' && !value.task) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'Task is required for cloud-task workflows',
        path: ['task'],
      });
    }

    if (value.workflowType === 'git-commit') {
      if (!value.files?.length) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: 'Files are required for git-commit workflows',
          path: ['files'],
        });
      }

      if (!value.commitMessage) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: 'Commit message is required for git-commit workflows',
          path: ['commitMessage'],
        });
      }
    }
  });

export const saveApiKeySchema = z.object({
  provider: z.enum(['claude', 'codex', 'openrouter', 'huggingface', 'nvidia']),
  apiKey: z.string().min(10).max(200),
});

export const createTeamSchema = z.object({
  name: z.string().min(1).max(100),
  description: z.string().max(500).optional(),
});

export const inviteTeamMemberSchema = z.object({
  email: z.string().email(),
  role: z.enum(['COLLABORATOR', 'VIEWER']).default('COLLABORATOR'),
});

export const acceptInviteSchema = z.object({
  token: z.string().uuid(),
});

export const updateMemberRoleSchema = z.object({
  role: z.enum(['COLLABORATOR', 'VIEWER']),
});

export const updatePreferencesSchema = z.object({
  workflowComplete: z.boolean().optional(),
  workflowFailed: z.boolean().optional(),
  sandboxTimeout: z.boolean().optional(),
  teamInvite: z.boolean().optional(),
  artifactReady: z.boolean().optional(),
  emailEnabled: z.boolean().optional(),
  webhookUrl: z.string().url().optional().or(z.literal('')).transform((v) => v || null),
});

export const TEMPLATE_CATEGORIES = [
  'web-app',
  'api',
  'cli',
  'data',
  'bot',
  'library',
  'fullstack',
] as const;

const templateCategorySchema = z.enum(TEMPLATE_CATEGORIES);

export const createTemplateSchema = z.object({
  name: z.string().min(1).max(100),
  description: z.string().min(10).max(500),
  category: templateCategorySchema,
  tags: z.array(z.string().min(1).max(30)).max(10).default([]),
  repositoryUrl: z.string().url().optional(),
  sandboxConfig: z
    .object({
      vcpus: z.number().int().min(1).max(8).default(2),
      timeoutMinutes: z.number().int().min(5).max(300).default(30),
      runtime: z.enum(['node22', 'python3.13']).default('node22'),
    })
    .optional(),
  aiPrompt: z.string().max(2000).optional(),
  isPublic: z.boolean().default(true),
});

export const useTemplateSchema = z.object({
  projectName: z.string().min(1).max(100),
});

export const templateSearchSchema = z.object({
  category: templateCategorySchema.optional(),
  search: z.string().max(100).optional(),
  limit: z.coerce.number().int().min(1).max(100).default(20),
  offset: z.coerce.number().int().min(0).default(0),
});
