import { timingSafeEqual } from 'node:crypto';
import {
  PlanTier as PrismaPlanTier,
  type Subscription,
} from '@prisma/client';
import { db } from './db.server';

export const PLAN_LIMITS = {
  FREE: {
    sandboxHoursPerMonth: 10,
    aiTokensPerMonth: 100_000,
    projectsLimit: 3,
    maxVcpus: 2,
    maxTimeoutMinutes: 30,
  },
  PRO: {
    sandboxHoursPerMonth: 100,
    aiTokensPerMonth: 1_000_000,
    projectsLimit: 20,
    maxVcpus: 4,
    maxTimeoutMinutes: 120,
  },
  TEAM: {
    sandboxHoursPerMonth: 500,
    aiTokensPerMonth: 5_000_000,
    projectsLimit: 100,
    maxVcpus: 8,
    maxTimeoutMinutes: 300,
  },
} as const;

export type PlanTier = keyof typeof PLAN_LIMITS;

export interface UsageSummary {
  plan: PlanTier;
  sandboxHours: { used: number; limit: number; percent: number };
  aiTokens: { used: number; limit: number; percent: number };
  projects: { used: number; limit: number; percent: number };
  periodStart: Date;
  periodEnd: Date;
  isNearLimit: boolean;
  isOverLimit: boolean;
}

function addMonths(date: Date, months: number) {
  const next = new Date(date);
  next.setUTCMonth(next.getUTCMonth() + months);
  return next;
}

function toNumber(value: unknown) {
  if (typeof value === 'number') {
    return Number.isFinite(value) ? value : 0;
  }

  if (typeof value === 'bigint') {
    return Number(value);
  }

  if (typeof value === 'string') {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : 0;
  }

  if (value && typeof value === 'object' && 'toString' in value) {
    const parsed = Number(String(value));
    return Number.isFinite(parsed) ? parsed : 0;
  }

  return 0;
}

function toPlanTier(plan: PrismaPlanTier | PlanTier): PlanTier {
  return plan as PlanTier;
}

function getPlanLimitValues(plan: PlanTier) {
  const limits = PLAN_LIMITS[plan];
  return {
    aiTokensLimit: limits.aiTokensPerMonth,
    plan: plan as PrismaPlanTier,
    projectsLimit: limits.projectsLimit,
    sandboxHoursLimit: limits.sandboxHoursPerMonth,
  };
}

function getMetadataValue(metadata: unknown, key: string) {
  if (!metadata || typeof metadata !== 'object' || Array.isArray(metadata)) {
    return undefined;
  }

  return (metadata as Record<string, unknown>)[key];
}

function calculatePercent(used: number, limit: number) {
  if (limit <= 0) {
    return 0;
  }

  return (used / limit) * 100;
}

async function getUserCreatedAt(userId: string) {
  const user = await db.user.findUnique({
    select: { createdAt: true },
    where: { id: userId },
  });

  if (!user) {
    throw new Error('User not found');
  }

  return user.createdAt;
}

async function ensureCurrentBillingPeriod(
  subscription: Subscription,
): Promise<Subscription> {
  const now = new Date();
  let currentPeriodStart = new Date(subscription.currentPeriodStart);
  let currentPeriodEnd = new Date(subscription.currentPeriodEnd);
  let changed = false;

  if (currentPeriodEnd <= currentPeriodStart) {
    currentPeriodEnd = addMonths(currentPeriodStart, 1);
    changed = true;
  }

  while (now >= currentPeriodEnd) {
    currentPeriodStart = currentPeriodEnd;
    currentPeriodEnd = addMonths(currentPeriodEnd, 1);
    changed = true;
  }

  if (!changed) {
    return subscription;
  }

  return db.subscription.update({
    data: {
      currentPeriodEnd,
      currentPeriodStart,
    },
    where: { userId: subscription.userId },
  });
}

export async function getOrCreateSubscription(
  userId: string,
): Promise<Subscription> {
  const createdAt = await getUserCreatedAt(userId);

  return ensureCurrentBillingPeriod(
    await db.subscription.upsert({
      create: {
        currentPeriodEnd: addMonths(createdAt, 1),
        currentPeriodStart: createdAt,
        userId,
        ...getPlanLimitValues('FREE'),
      },
      update: {},
      where: { userId },
    }),
  );
}

export async function getUsageSummary(userId: string): Promise<UsageSummary> {
  const subscription = await getOrCreateSubscription(userId);
  const periodStart = new Date(subscription.currentPeriodStart);
  const periodEnd = new Date(subscription.currentPeriodEnd);

  const [events, projectsUsed] = await Promise.all([
    db.analyticsEvent.findMany({
      select: { eventType: true, metadata: true },
      where: {
        createdAt: {
          gte: periodStart,
          lt: periodEnd,
        },
        eventType: {
          in: ['sandbox.terminated', 'ai.request'],
        },
        userId,
      },
    }),
    db.project.count({ where: { userId } }),
  ]);

  let sandboxHoursUsed = 0;
  let aiTokensUsed = 0;

  for (const event of events) {
    if (event.eventType === 'sandbox.terminated') {
      sandboxHoursUsed +=
        toNumber(getMetadataValue(event.metadata, 'cpuSeconds')) / 3600;
      continue;
    }

    if (event.eventType === 'ai.request') {
      aiTokensUsed +=
        toNumber(getMetadataValue(event.metadata, 'promptTokens')) +
        toNumber(getMetadataValue(event.metadata, 'completionTokens'));
    }
  }

  const sandboxHoursPercent = calculatePercent(
    sandboxHoursUsed,
    subscription.sandboxHoursLimit,
  );
  const aiTokensPercent = calculatePercent(
    aiTokensUsed,
    subscription.aiTokensLimit,
  );
  const projectsPercent = calculatePercent(projectsUsed, subscription.projectsLimit);
  const isNearLimit = [sandboxHoursPercent, aiTokensPercent, projectsPercent].some(
    (percent) => percent > 80,
  );
  const isOverLimit = [sandboxHoursPercent, aiTokensPercent, projectsPercent].some(
    (percent) => percent >= 100,
  );

  return {
    aiTokens: {
      limit: subscription.aiTokensLimit,
      percent: aiTokensPercent,
      used: aiTokensUsed,
    },
    isNearLimit,
    isOverLimit,
    periodEnd,
    periodStart,
    plan: toPlanTier(subscription.plan),
    projects: {
      limit: subscription.projectsLimit,
      percent: projectsPercent,
      used: projectsUsed,
    },
    sandboxHours: {
      limit: subscription.sandboxHoursLimit,
      percent: sandboxHoursPercent,
      used: sandboxHoursUsed,
    },
  };
}

export async function canCreateSandbox(
  userId: string,
  vcpus: number,
  timeoutMinutes: number,
): Promise<{
  allowed: boolean;
  reason?: string;
}> {
  const usage = await getUsageSummary(userId);
  const limits = PLAN_LIMITS[usage.plan];

  if (vcpus > limits.maxVcpus) {
    return {
      allowed: false,
      reason: `${usage.plan} plan supports up to ${limits.maxVcpus} vCPUs per sandbox.`,
    };
  }

  if (timeoutMinutes > limits.maxTimeoutMinutes) {
    return {
      allowed: false,
      reason: `${usage.plan} plan supports sandbox timeouts up to ${limits.maxTimeoutMinutes} minutes.`,
    };
  }

  if (usage.sandboxHours.used >= usage.sandboxHours.limit) {
    return {
      allowed: false,
      reason: 'Sandbox hours quota exceeded for the current billing period.',
    };
  }

  return { allowed: true };
}

export async function canMakeAiRequest(
  userId: string,
  estimatedTokens = 0,
): Promise<{
  allowed: boolean;
  reason?: string;
}> {
  const usage = await getUsageSummary(userId);
  const projectedTokens = usage.aiTokens.used + Math.max(0, estimatedTokens);

  if (projectedTokens > usage.aiTokens.limit || usage.aiTokens.used >= usage.aiTokens.limit) {
    return {
      allowed: false,
      reason: 'AI token quota exceeded for the current billing period.',
    };
  }

  return { allowed: true };
}

export async function canCreateProject(userId: string): Promise<{
  allowed: boolean;
  reason?: string;
}> {
  const usage = await getUsageSummary(userId);

  if (usage.projects.used >= usage.projects.limit) {
    return {
      allowed: false,
      reason: `Project limit reached for the ${usage.plan} plan.`,
    };
  }

  return { allowed: true };
}

async function updatePlan(userId: string, newPlan: PlanTier) {
  await getOrCreateSubscription(userId);

  return db.subscription.update({
    data: {
      cancelAtPeriodEnd: false,
      ...getPlanLimitValues(newPlan),
    },
    where: { userId },
  });
}

export async function upgradePlan(userId: string, newPlan: PlanTier) {
  return updatePlan(userId, newPlan);
}

export async function downgradePlan(userId: string, newPlan: PlanTier) {
  return updatePlan(userId, newPlan);
}

export async function resetBillingPeriod(userId: string): Promise<void> {
  await getOrCreateSubscription(userId);
  const currentPeriodStart = new Date();

  await db.subscription.update({
    data: {
      currentPeriodEnd: addMonths(currentPeriodStart, 1),
      currentPeriodStart,
    },
    where: { userId },
  });
}

function isValidSignature(expected: string, received: string) {
  const expectedBuffer = Buffer.from(expected);
  const receivedBuffer = Buffer.from(received);

  if (expectedBuffer.length !== receivedBuffer.length) {
    return false;
  }

  return timingSafeEqual(expectedBuffer, receivedBuffer);
}

export async function handleStripeWebhook(
  body: string,
  signature: string,
): Promise<void> {
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  if (webhookSecret && !isValidSignature(webhookSecret, signature)) {
    throw new Error('Invalid Stripe webhook signature');
  }

  let eventType = 'unknown';

  try {
    const payload = JSON.parse(body) as { type?: string };
    if (typeof payload.type === 'string' && payload.type.trim()) {
      eventType = payload.type;
    }
  } catch {
    eventType = 'unknown';
  }

  switch (eventType) {
    case 'checkout.session.completed':
    case 'subscription.updated':
    case 'subscription.deleted':
    default:
      console.info(`[billing] Stripe webhook received: ${eventType}`);
  }
}
