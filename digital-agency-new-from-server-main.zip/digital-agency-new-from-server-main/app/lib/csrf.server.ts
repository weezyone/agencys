import crypto from 'node:crypto';

export function generateCsrfToken(): string {
  return crypto.randomBytes(32).toString('base64url');
}

export function validateCsrfToken(
  token: string,
  sessionToken: string,
): boolean {
  if (!token || !sessionToken) {
    return false;
  }

  const tokenBuffer = Buffer.from(token);
  const sessionBuffer = Buffer.from(sessionToken);

  if (tokenBuffer.length !== sessionBuffer.length) {
    return false;
  }

  return crypto.timingSafeEqual(tokenBuffer, sessionBuffer);
}
