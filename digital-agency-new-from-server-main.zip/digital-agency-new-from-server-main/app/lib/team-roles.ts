import type { TeamRole as PrismaTeamRole } from '@prisma/client';

export const TeamRole = {
  COLLABORATOR: 'COLLABORATOR',
  OWNER: 'OWNER',
  VIEWER: 'VIEWER',
} as const satisfies Record<PrismaTeamRole, PrismaTeamRole>;

export type TeamRole = PrismaTeamRole;
