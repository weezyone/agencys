import db from './db.server';
import { getBackoffDelay } from './rate-limit.server';

const GITHUB_API_BASE_URL = 'https://api.github.com';

type GitProvider = 'github' | 'gitlab';
type JsonObject = Record<string, unknown>;

type GitHubCompareResponse = {
  commits?: Array<{ sha?: string; commit?: { message?: string } }>;
  files?: Array<{
    filename?: string;
    status?: string;
    additions?: number;
    deletions?: number;
    patch?: string;
  }>;
};

type GitLabCompareResponse = {
  commits?: Array<{ id?: string; message?: string; title?: string }>;
  diffs?: Array<{
    new_path?: string;
    old_path?: string;
    diff?: string;
    new_file?: boolean;
    deleted_file?: boolean;
    renamed_file?: boolean;
  }>;
};

export interface RepoInfo {
  id: number;
  name: string;
  full_name: string;
  default_branch: string;
  private: boolean;
  html_url: string;
}

export interface Branch {
  name: string;
  commit: { sha: string };
}

export interface PullRequest {
  number: number;
  html_url: string;
  title: string;
  state: string;
  created_at: string;
}

export interface FileDiff {
  filename: string;
  status: 'added' | 'modified' | 'removed' | 'renamed';
  additions: number;
  deletions: number;
  patch?: string;
}

export interface CompareResult {
  commits: Array<{ sha: string; commit: { message: string } }>;
  files: FileDiff[];
}

export interface GitContext {
  provider: GitProvider;
  accessToken: string;
  repositoryUrl: string;
  owner: string;
  repo: string;
  defaultBranch: string;
  baseUrl?: string;
}

export class GitApiError extends Error {
  constructor(
    message: string,
    public status: number = 500,
    public details?: unknown,
  ) {
    super(message);
    this.name = 'GitApiError';
  }
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function encodePathSegment(path: string) {
  return path
    .split('/')
    .map((segment) => encodeURIComponent(segment))
    .join('/');
}

function getRepositoryOrigin(url: string): string | undefined {
  try {
    if (url.startsWith('git@')) {
      const match = url.match(/^git@([^:]+):/);
      return match ? `https://${match[1]}` : undefined;
    }

    return new URL(url).origin;
  } catch {
    return undefined;
  }
}

function normalizeFileStatus(status?: string): FileDiff['status'] {
  switch (status) {
    case 'added':
      return 'added';
    case 'removed':
    case 'deleted':
      return 'removed';
    case 'renamed':
      return 'renamed';
    default:
      return 'modified';
  }
}

function countPatchChanges(patch?: string) {
  if (!patch) {
    return { additions: 0, deletions: 0 };
  }

  return patch.split(/\r?\n/).reduce(
    (totals, line) => {
      if (line.startsWith('+') && !line.startsWith('+++')) {
        totals.additions += 1;
      } else if (line.startsWith('-') && !line.startsWith('---')) {
        totals.deletions += 1;
      }
      return totals;
    },
    { additions: 0, deletions: 0 },
  );
}

function readMessage(payload: unknown, fallback: string) {
  if (typeof payload === 'string' && payload.trim()) {
    return payload;
  }

  if (payload && typeof payload === 'object') {
    const record = payload as JsonObject;
    const message = record.message ?? record.error ?? record.error_description;
    if (typeof message === 'string' && message.trim()) {
      return message;
    }
  }

  return fallback;
}

async function readApiPayload(response: Response) {
  const contentType = response.headers.get('content-type') ?? '';

  if (response.status === 204) {
    return null;
  }

  if (contentType.includes('application/json')) {
    return response.json();
  }

  return response.text();
}

function normalizeGitHubRef(ref: string) {
  if (ref.startsWith('refs/')) {
    return ref.replace(/^refs\//, '');
  }

  if (ref.startsWith('heads/') || ref.startsWith('tags/')) {
    return ref;
  }

  return `heads/${ref}`;
}

function getProjectPath(owner: string, repo: string) {
  return encodeURIComponent(`${owner}/${repo}`);
}

function extractAccessToken(
  oauthTokens: unknown,
  provider: GitProvider,
): string | undefined {
  if (!oauthTokens) {
    return undefined;
  }

  if (typeof oauthTokens === 'string') {
    return oauthTokens;
  }

  if (typeof oauthTokens !== 'object') {
    return undefined;
  }

  const record = oauthTokens as JsonObject;
  const providerEntry = record[provider];

  if (typeof providerEntry === 'string') {
    return providerEntry;
  }

  if (providerEntry && typeof providerEntry === 'object') {
    const tokenRecord = providerEntry as JsonObject;
    const nestedToken = tokenRecord.accessToken ?? tokenRecord.token;
    if (typeof nestedToken === 'string' && nestedToken.trim()) {
      return nestedToken;
    }
  }

  const directToken =
    record[`${provider}AccessToken`] ?? record.accessToken ?? record.token;
  return typeof directToken === 'string' && directToken.trim()
    ? directToken
    : undefined;
}

export class GitHubClient {
  constructor(private accessToken: string) {}

  async getRepo(owner: string, repo: string): Promise<RepoInfo> {
    const data = await this.apiFetch<JsonObject>(`/repos/${owner}/${repo}`);
    return {
      id: Number(data.id),
      name: String(data.name ?? repo),
      full_name: String(data.full_name ?? `${owner}/${repo}`),
      default_branch: String(data.default_branch ?? 'main'),
      private: Boolean(data.private),
      html_url: String(data.html_url ?? `https://github.com/${owner}/${repo}`),
    };
  }

  async getBranches(owner: string, repo: string): Promise<Branch[]> {
    const data = await this.apiFetch<Array<JsonObject>>(
      `/repos/${owner}/${repo}/branches`,
    );
    return data.map((branch) => ({
      name: String(branch.name ?? ''),
      commit: {
        sha: String((branch.commit as JsonObject | undefined)?.sha ?? ''),
      },
    }));
  }

  async getFileContent(
    owner: string,
    repo: string,
    path: string,
    ref?: string,
  ): Promise<string> {
    const query = ref ? `?ref=${encodeURIComponent(ref)}` : '';
    const data = await this.apiFetch<JsonObject | JsonObject[]>(
      `/repos/${owner}/${repo}/contents/${encodePathSegment(path)}${query}`,
    );

    if (Array.isArray(data)) {
      throw new GitApiError('Requested path is a directory, not a file', 400);
    }

    if (typeof data.content === 'string' && data.encoding === 'base64') {
      return Buffer.from(data.content.replace(/\n/g, ''), 'base64').toString(
        'utf8',
      );
    }

    if (typeof data.content === 'string') {
      return data.content;
    }

    return '';
  }

  async createBranch(
    owner: string,
    repo: string,
    branchName: string,
    baseSha: string,
  ): Promise<Branch> {
    const data = await this.apiFetch<JsonObject>(
      `/repos/${owner}/${repo}/git/refs`,
      {
        method: 'POST',
        body: JSON.stringify({ ref: `refs/heads/${branchName}`, sha: baseSha }),
      },
    );

    return {
      name: branchName,
      commit: {
        sha: String((data.object as JsonObject | undefined)?.sha ?? baseSha),
      },
    };
  }

  async getRefSha(owner: string, repo: string, ref: string): Promise<string> {
    try {
      const data = await this.apiFetch<JsonObject>(
        `/repos/${owner}/${repo}/git/ref/${normalizeGitHubRef(ref)}`,
      );
      return String((data.object as JsonObject | undefined)?.sha ?? '');
    } catch (error) {
      if (!(error instanceof GitApiError) || error.status !== 404) {
        throw error;
      }

      const commit = await this.getCommit(owner, repo, ref);
      return commit.sha;
    }
  }

  async createOrUpdateFile(
    owner: string,
    repo: string,
    path: string,
    content: string,
    message: string,
    branch: string,
    sha?: string,
  ): Promise<{ commit: { sha: string; html_url: string } }> {
    const data = await this.apiFetch<JsonObject>(
      `/repos/${owner}/${repo}/contents/${encodePathSegment(path)}`,
      {
        method: 'PUT',
        body: JSON.stringify({
          message,
          content: Buffer.from(content, 'utf8').toString('base64'),
          branch,
          sha,
        }),
      },
    );

    const commit = (data.commit as JsonObject | undefined) ?? {};
    return {
      commit: {
        sha: String(commit.sha ?? ''),
        html_url: String(
          commit.html_url ??
            `https://github.com/${owner}/${repo}/commit/${commit.sha ?? ''}`,
        ),
      },
    };
  }

  async createPullRequest(
    owner: string,
    repo: string,
    title: string,
    body: string,
    head: string,
    base: string,
  ): Promise<PullRequest> {
    const data = await this.apiFetch<JsonObject>(
      `/repos/${owner}/${repo}/pulls`,
      {
        method: 'POST',
        body: JSON.stringify({ title, body, head, base }),
      },
    );

    return {
      number: Number(data.number),
      html_url: String(data.html_url ?? ''),
      title: String(data.title ?? title),
      state: String(data.state ?? 'open'),
      created_at: String(data.created_at ?? new Date().toISOString()),
    };
  }

  async getPullRequest(
    owner: string,
    repo: string,
    prNumber: number,
  ): Promise<PullRequest> {
    const data = await this.apiFetch<JsonObject>(
      `/repos/${owner}/${repo}/pulls/${prNumber}`,
    );
    return {
      number: Number(data.number),
      html_url: String(data.html_url ?? ''),
      title: String(data.title ?? ''),
      state: String(data.state ?? 'open'),
      created_at: String(data.created_at ?? new Date().toISOString()),
    };
  }

  async compareBranches(
    owner: string,
    repo: string,
    base: string,
    head: string,
  ): Promise<CompareResult> {
    const data = await this.apiFetch<GitHubCompareResponse>(
      `/repos/${owner}/${repo}/compare/${encodeURIComponent(base)}...${encodeURIComponent(head)}`,
    );

    return {
      commits: (data.commits ?? []).map((commit) => ({
        sha: String(commit.sha ?? ''),
        commit: { message: String(commit.commit?.message ?? '') },
      })),
      files: (data.files ?? []).map((file) => ({
        filename: String(file.filename ?? ''),
        status: normalizeFileStatus(file.status),
        additions: Number(file.additions ?? 0),
        deletions: Number(file.deletions ?? 0),
        patch: file.patch,
      })),
    };
  }

  async getCommit(
    owner: string,
    repo: string,
    ref: string,
  ): Promise<{ sha: string; treeSha: string; html_url: string }> {
    const data = await this.apiFetch<JsonObject>(
      `/repos/${owner}/${repo}/commits/${encodeURIComponent(ref)}`,
    );
    const commit = (data.commit as JsonObject | undefined) ?? {};
    const tree = (commit.tree as JsonObject | undefined) ?? {};

    return {
      sha: String(data.sha ?? ref),
      treeSha: String(tree.sha ?? ''),
      html_url: String(
        data.html_url ??
          `https://github.com/${owner}/${repo}/commit/${data.sha ?? ref}`,
      ),
    };
  }

  async createBlob(
    owner: string,
    repo: string,
    content: string,
  ): Promise<string> {
    const data = await this.apiFetch<JsonObject>(
      `/repos/${owner}/${repo}/git/blobs`,
      {
        method: 'POST',
        body: JSON.stringify({ content, encoding: 'utf-8' }),
      },
    );

    return String(data.sha ?? '');
  }

  async createTree(
    owner: string,
    repo: string,
    baseTreeSha: string,
    entries: Array<{ path: string; sha: string }>,
  ): Promise<string> {
    const data = await this.apiFetch<JsonObject>(
      `/repos/${owner}/${repo}/git/trees`,
      {
        method: 'POST',
        body: JSON.stringify({
          base_tree: baseTreeSha,
          tree: entries.map((entry) => ({
            path: entry.path,
            mode: '100644',
            type: 'blob',
            sha: entry.sha,
          })),
        }),
      },
    );

    return String(data.sha ?? '');
  }

  async createCommitObject(
    owner: string,
    repo: string,
    message: string,
    treeSha: string,
    parentSha: string,
  ): Promise<{ sha: string; html_url: string }> {
    const data = await this.apiFetch<JsonObject>(
      `/repos/${owner}/${repo}/git/commits`,
      {
        method: 'POST',
        body: JSON.stringify({ message, tree: treeSha, parents: [parentSha] }),
      },
    );

    return {
      sha: String(data.sha ?? ''),
      html_url: String(
        data.html_url ??
          `https://github.com/${owner}/${repo}/commit/${data.sha ?? ''}`,
      ),
    };
  }

  async updateBranchRef(
    owner: string,
    repo: string,
    branch: string,
    sha: string,
  ): Promise<void> {
    await this.apiFetch(
      `/repos/${owner}/${repo}/git/refs/heads/${encodePathSegment(branch)}`,
      {
        method: 'PATCH',
        body: JSON.stringify({ sha, force: false }),
      },
    );
  }

  private async apiFetch<T = unknown>(
    path: string,
    options: RequestInit = {},
  ): Promise<T> {
    for (let attempt = 0; attempt < 3; attempt += 1) {
      const response = await fetch(`${GITHUB_API_BASE_URL}${path}`, {
        ...options,
        headers: {
          Accept: 'application/vnd.github+json',
          Authorization: `Bearer ${this.accessToken}`,
          'Content-Type': 'application/json',
          'X-GitHub-Api-Version': '2022-11-28',
          ...(options.headers ?? {}),
        },
      });

      if (response.ok) {
        return (await readApiPayload(response)) as T;
      }

      const payload = await readApiPayload(response);
      const retryAfterSeconds = Number(
        response.headers.get('retry-after') ?? '0',
      );
      const remaining = response.headers.get('x-ratelimit-remaining');
      const resetAt = Number(response.headers.get('x-ratelimit-reset') ?? '0');
      const shouldRetry =
        (response.status === 403 || response.status === 429) && attempt < 2;

      if (
        shouldRetry &&
        (retryAfterSeconds > 0 || remaining === '0' || response.status === 429)
      ) {
        const delay =
          retryAfterSeconds > 0
            ? retryAfterSeconds * 1000
            : resetAt > 0
              ? Math.max(resetAt * 1000 - Date.now(), getBackoffDelay(attempt))
              : getBackoffDelay(attempt);
        await sleep(delay);
        continue;
      }

      throw new GitApiError(
        readMessage(payload, 'GitHub API request failed'),
        response.status,
        payload,
      );
    }

    throw new GitApiError('GitHub API request failed after retries', 503);
  }
}

export class GitLabClient {
  constructor(
    private accessToken: string,
    private baseUrl: string = 'https://gitlab.com',
  ) {}

  async getRepo(owner: string, repo: string): Promise<RepoInfo> {
    const data = await this.apiFetch<JsonObject>(
      `/projects/${getProjectPath(owner, repo)}`,
    );
    return {
      id: Number(data.id),
      name: String(data.name ?? repo),
      full_name: String(data.path_with_namespace ?? `${owner}/${repo}`),
      default_branch: String(data.default_branch ?? 'main'),
      private: String(data.visibility ?? 'private') !== 'public',
      html_url: String(data.web_url ?? `${this.baseUrl}/${owner}/${repo}`),
    };
  }

  async getBranches(owner: string, repo: string): Promise<Branch[]> {
    const data = await this.apiFetch<Array<JsonObject>>(
      `/projects/${getProjectPath(owner, repo)}/repository/branches`,
    );
    return data.map((branch) => ({
      name: String(branch.name ?? ''),
      commit: {
        sha: String((branch.commit as JsonObject | undefined)?.id ?? ''),
      },
    }));
  }

  async getFileContent(
    owner: string,
    repo: string,
    path: string,
    ref?: string,
  ): Promise<string> {
    const query = ref ? `?ref=${encodeURIComponent(ref)}` : '';
    return this.apiFetch<string>(
      `/projects/${getProjectPath(owner, repo)}/repository/files/${encodeURIComponent(path)}/raw${query}`,
      {
        headers: { Accept: 'text/plain' },
      },
    );
  }

  async createBranch(
    owner: string,
    repo: string,
    branchName: string,
    baseSha: string,
  ): Promise<Branch> {
    const data = await this.apiFetch<JsonObject>(
      `/projects/${getProjectPath(owner, repo)}/repository/branches?branch=${encodeURIComponent(branchName)}&ref=${encodeURIComponent(baseSha)}`,
      { method: 'POST' },
    );

    return {
      name: String(data.name ?? branchName),
      commit: {
        sha: String((data.commit as JsonObject | undefined)?.id ?? baseSha),
      },
    };
  }

  async getRefSha(owner: string, repo: string, ref: string): Promise<string> {
    try {
      const branch = await this.apiFetch<JsonObject>(
        `/projects/${getProjectPath(owner, repo)}/repository/branches/${encodeURIComponent(ref)}`,
      );
      return String((branch.commit as JsonObject | undefined)?.id ?? '');
    } catch (error) {
      if (!(error instanceof GitApiError) || error.status !== 404) {
        throw error;
      }

      const commit = await this.apiFetch<JsonObject>(
        `/projects/${getProjectPath(owner, repo)}/repository/commits/${encodeURIComponent(ref)}`,
      );
      return String(commit.id ?? ref);
    }
  }

  async createOrUpdateFile(
    owner: string,
    repo: string,
    path: string,
    content: string,
    message: string,
    branch: string,
    sha?: string,
  ): Promise<{ commit: { sha: string; html_url: string } }> {
    const method = sha ? 'PUT' : 'POST';
    await this.apiFetch<JsonObject>(
      `/projects/${getProjectPath(owner, repo)}/repository/files/${encodeURIComponent(path)}`,
      {
        method,
        body: JSON.stringify({ branch, content, commit_message: message }),
      },
    );

    const commitSha = await this.getRefSha(owner, repo, branch);
    return {
      commit: {
        sha: commitSha,
        html_url: `${this.baseUrl}/${owner}/${repo}/-/commit/${commitSha}`,
      },
    };
  }

  async createPullRequest(
    owner: string,
    repo: string,
    title: string,
    body: string,
    head: string,
    base: string,
  ): Promise<PullRequest> {
    const data = await this.apiFetch<JsonObject>(
      `/projects/${getProjectPath(owner, repo)}/merge_requests`,
      {
        method: 'POST',
        body: JSON.stringify({
          title,
          description: body,
          source_branch: head,
          target_branch: base,
        }),
      },
    );

    return {
      number: Number(data.iid),
      html_url: String(data.web_url ?? ''),
      title: String(data.title ?? title),
      state: String(data.state ?? 'opened'),
      created_at: String(data.created_at ?? new Date().toISOString()),
    };
  }

  async getPullRequest(
    owner: string,
    repo: string,
    prNumber: number,
  ): Promise<PullRequest> {
    const data = await this.apiFetch<JsonObject>(
      `/projects/${getProjectPath(owner, repo)}/merge_requests/${prNumber}`,
    );
    return {
      number: Number(data.iid),
      html_url: String(data.web_url ?? ''),
      title: String(data.title ?? ''),
      state: String(data.state ?? 'opened'),
      created_at: String(data.created_at ?? new Date().toISOString()),
    };
  }

  async compareBranches(
    owner: string,
    repo: string,
    base: string,
    head: string,
  ): Promise<CompareResult> {
    const data = await this.apiFetch<GitLabCompareResponse>(
      `/projects/${getProjectPath(owner, repo)}/repository/compare?from=${encodeURIComponent(base)}&to=${encodeURIComponent(head)}`,
    );

    return {
      commits: (data.commits ?? []).map((commit) => ({
        sha: String(commit.id ?? ''),
        commit: { message: String(commit.message ?? commit.title ?? '') },
      })),
      files: (data.diffs ?? []).map((diff) => {
        const counts = countPatchChanges(diff.diff);
        return {
          filename: String(diff.new_path ?? diff.old_path ?? ''),
          status: diff.renamed_file
            ? 'renamed'
            : diff.deleted_file
              ? 'removed'
              : diff.new_file
                ? 'added'
                : 'modified',
          additions: counts.additions,
          deletions: counts.deletions,
          patch: diff.diff,
        } satisfies FileDiff;
      }),
    };
  }

  async createCommit(
    owner: string,
    repo: string,
    message: string,
    branch: string,
    files: Array<{ path: string; content: string }>,
  ): Promise<{ sha: string; html_url: string }> {
    const actions = await Promise.all(
      files.map(async (file) => {
        try {
          await this.getFileContent(owner, repo, file.path, branch);
          return {
            action: 'update',
            file_path: file.path,
            content: file.content,
          };
        } catch (error) {
          if (error instanceof GitApiError && error.status === 404) {
            return {
              action: 'create',
              file_path: file.path,
              content: file.content,
            };
          }
          throw error;
        }
      }),
    );

    const data = await this.apiFetch<JsonObject>(
      `/projects/${getProjectPath(owner, repo)}/repository/commits`,
      {
        method: 'POST',
        body: JSON.stringify({ branch, commit_message: message, actions }),
      },
    );

    const sha = String(data.id ?? '');
    return {
      sha,
      html_url: String(
        data.web_url ?? `${this.baseUrl}/${owner}/${repo}/-/commit/${sha}`,
      ),
    };
  }

  private async apiFetch<T = unknown>(
    path: string,
    options: RequestInit = {},
  ): Promise<T> {
    const apiBaseUrl = `${this.baseUrl.replace(/\/$/, '')}/api/v4`;

    for (let attempt = 0; attempt < 3; attempt += 1) {
      const response = await fetch(`${apiBaseUrl}${path}`, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          'PRIVATE-TOKEN': this.accessToken,
          ...(options.headers ?? {}),
        },
      });

      if (response.ok) {
        return (await readApiPayload(response)) as T;
      }

      const payload = await readApiPayload(response);
      const retryAfterSeconds = Number(
        response.headers.get('retry-after') ?? '0',
      );
      const shouldRetry =
        (response.status === 403 || response.status === 429) && attempt < 2;

      if (shouldRetry) {
        await sleep(
          retryAfterSeconds > 0
            ? retryAfterSeconds * 1000
            : getBackoffDelay(attempt),
        );
        continue;
      }

      throw new GitApiError(
        readMessage(payload, 'GitLab API request failed'),
        response.status,
        payload,
      );
    }

    throw new GitApiError('GitLab API request failed after retries', 503);
  }
}

export function getGitClient(
  provider: GitProvider,
  accessToken: string,
  baseUrl?: string,
): GitHubClient | GitLabClient {
  return provider === 'github'
    ? new GitHubClient(accessToken)
    : new GitLabClient(accessToken, baseUrl);
}

export function parseRepoUrl(url: string): {
  owner: string;
  repo: string;
  provider: GitProvider;
} {
  const trimmed = url
    .trim()
    .replace(/\.git$/, '')
    .replace(/\/$/, '');
  let host = '';
  let path = '';

  if (trimmed.startsWith('git@')) {
    const match = trimmed.match(/^git@([^:]+):(.+)$/);
    if (!match) {
      throw new GitApiError('Unsupported repository URL format', 400);
    }
    host = match[1];
    path = match[2];
  } else {
    const parsed = new URL(trimmed);
    host = parsed.hostname;
    path = parsed.pathname.replace(/^\//, '');
  }

  const provider = host.includes('gitlab')
    ? 'gitlab'
    : host.includes('github')
      ? 'github'
      : null;
  if (!provider) {
    throw new GitApiError('Unsupported Git provider', 400);
  }

  const parts = path.split('/').filter(Boolean);
  if (parts.length < 2) {
    throw new GitApiError(
      'Repository URL must include owner and repository name',
      400,
    );
  }

  return {
    owner: parts.slice(0, -1).join('/'),
    repo: parts.at(-1) ?? '',
    provider,
  };
}

export async function resolveGitContext(input: {
  projectId?: string;
  repositoryUrl?: string;
  accessToken?: string;
  provider?: GitProvider;
  baseUrl?: string;
}): Promise<GitContext> {
  if (input.repositoryUrl && input.accessToken) {
    const parsed = parseRepoUrl(input.repositoryUrl);
    const provider = input.provider ?? parsed.provider;

    return {
      provider,
      accessToken: input.accessToken,
      repositoryUrl: input.repositoryUrl,
      owner: parsed.owner,
      repo: parsed.repo,
      defaultBranch: 'main',
      baseUrl:
        provider === 'gitlab'
          ? (input.baseUrl ?? getRepositoryOrigin(input.repositoryUrl))
          : undefined,
    };
  }

  if (!input.projectId) {
    throw new GitApiError(
      'Either projectId or repositoryUrl/accessToken is required',
      400,
    );
  }

  try {
    const project = await db.project.findUnique({
      where: { id: input.projectId },
      include: { user: true },
    });

    if (!project) {
      throw new GitApiError('Project not found', 404);
    }

    const settings = (project.settings ?? {}) as JsonObject;
    const gitIntegration = ((settings.gitIntegration as
      | JsonObject
      | undefined) ?? {}) as JsonObject;
    const repositoryUrl =
      input.repositoryUrl ??
      (typeof project.repositoryUrl === 'string' && project.repositoryUrl.trim()
        ? project.repositoryUrl
        : undefined) ??
      (typeof gitIntegration.repositoryUrl === 'string'
        ? gitIntegration.repositoryUrl
        : undefined);

    if (!repositoryUrl) {
      throw new GitApiError('Project is missing a repository URL', 400);
    }

    const parsed = parseRepoUrl(repositoryUrl);
    const provider =
      input.provider ??
      (gitIntegration.provider as GitProvider | undefined) ??
      parsed.provider;
    const accessToken =
      input.accessToken ??
      extractAccessToken(project.user.oauthTokens, provider);

    if (!accessToken) {
      throw new GitApiError('Git access token not found for project', 400);
    }

    const defaultBranch =
      (typeof gitIntegration.defaultBranch === 'string' &&
        gitIntegration.defaultBranch) ||
      project.branch ||
      'main';
    const configuredBaseUrl =
      typeof gitIntegration.baseUrl === 'string'
        ? gitIntegration.baseUrl
        : undefined;

    return {
      provider,
      accessToken,
      repositoryUrl,
      owner: parsed.owner,
      repo: parsed.repo,
      defaultBranch,
      baseUrl:
        provider === 'gitlab'
          ? (input.baseUrl ??
            configuredBaseUrl ??
            getRepositoryOrigin(repositoryUrl))
          : undefined,
    };
  } catch (error) {
    if (error instanceof GitApiError) {
      throw error;
    }

    throw new GitApiError(
      'Unable to load project Git configuration. Provide repositoryUrl and accessToken directly if the database is unavailable.',
      500,
      error,
    );
  }
}
