import crypto from 'node:crypto';
import kv from './kv.server';

const GITHUB_API_BASE_URL = 'https://api.github.com';
const GITHUB_API_VERSION = '2022-11-28';
const GITHUB_USER_AGENT = 'cloud-first-ai-development-platform';
const INSTALLATION_TOKEN_TTL_SECONDS = 55 * 60;

type JsonRecord = Record<string, unknown>;

function getRequiredEnv(name: string): string {
  const value = process.env[name]?.trim();
  if (!value) {
    throw new Error(`${name} is required for GitHub App integration.`);
  }
  return value;
}

function base64UrlEncode(input: string | Buffer): string {
  return Buffer.from(input)
    .toString('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
}

function normalizePrivateKey(rawKey: string): string {
  const normalized = rawKey.replace(/\\n/g, '\n').trim();
  if (normalized.includes('BEGIN')) {
    return normalized;
  }

  if (!/^[A-Za-z0-9+/=\s]+$/.test(normalized)) {
    return normalized;
  }

  try {
    const decoded = Buffer.from(normalized.replace(/\s+/g, ''), 'base64')
      .toString('utf8')
      .trim();
    return decoded.includes('BEGIN') ? decoded : normalized;
  } catch {
    return normalized;
  }
}

async function readGithubResponse<T>(response: Response): Promise<T> {
  const contentType = response.headers.get('content-type') ?? '';
  const payload = contentType.includes('application/json')
    ? ((await response.json()) as T | JsonRecord)
    : await response.text();

  if (!response.ok) {
    const message =
      typeof payload === 'string'
        ? payload
        : typeof (payload as JsonRecord).message === 'string'
          ? String((payload as JsonRecord).message)
          : `GitHub API request failed with status ${response.status}`;
    throw new Error(message);
  }

  return payload as T;
}

async function githubRequest<T>(
  path: string,
  options: RequestInit & { token: string },
): Promise<T> {
  const response = await fetch(`${GITHUB_API_BASE_URL}${path}`, {
    ...options,
    headers: {
      Accept: 'application/vnd.github+json',
      Authorization: `Bearer ${options.token}`,
      'Content-Type': 'application/json',
      'User-Agent': GITHUB_USER_AGENT,
      'X-GitHub-Api-Version': GITHUB_API_VERSION,
      ...(options.headers ?? {}),
    },
  });

  return readGithubResponse<T>(response);
}

export async function generateAppJwt(): Promise<string> {
  const appId = getRequiredEnv('GITHUB_APP_ID');
  const privateKey = normalizePrivateKey(getRequiredEnv('GITHUB_APP_PRIVATE_KEY'));
  const now = Math.floor(Date.now() / 1000);
  const header = base64UrlEncode(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
  const payload = base64UrlEncode(
    JSON.stringify({
      exp: now + 600,
      iat: now - 60,
      iss: appId,
    }),
  );
  const signer = crypto.createSign('RSA-SHA256');
  signer.update(`${header}.${payload}`);
  signer.end();
  const signature = signer
    .sign(privateKey, 'base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');

  return `${header}.${payload}.${signature}`;
}

export interface InstallationToken {
  token: string;
  expiresAt: string;
  installationId: number;
}

export async function getInstallationToken(
  installationId: number,
): Promise<InstallationToken> {
  const cacheKey = `github:install:${installationId}:token`;
  const cached = await kv.get<InstallationToken>(cacheKey);
  if (cached?.token) {
    return cached;
  }

  const appJwt = await generateAppJwt();
  const payload = await githubRequest<{ token: string; expires_at: string }>(
    `/app/installations/${installationId}/access_tokens`,
    {
      body: JSON.stringify({}),
      method: 'POST',
      token: appJwt,
    },
  );

  const token = {
    expiresAt: payload.expires_at,
    installationId,
    token: payload.token,
  } satisfies InstallationToken;

  await kv.set(cacheKey, token, { ex: INSTALLATION_TOKEN_TTL_SECONDS });
  return token;
}

export function validateWebhookSignature(
  payload: string,
  signature: string,
): boolean {
  const secret = getRequiredEnv('GITHUB_WEBHOOK_SECRET');
  if (!signature.startsWith('sha256=')) {
    return false;
  }

  const expected = `sha256=${crypto
    .createHmac('sha256', secret)
    .update(payload)
    .digest('hex')}`;
  const expectedBuffer = Buffer.from(expected);
  const receivedBuffer = Buffer.from(signature);

  if (expectedBuffer.length !== receivedBuffer.length) {
    return false;
  }

  return crypto.timingSafeEqual(expectedBuffer, receivedBuffer);
}

export type WebhookEvent =
  | {
      type: 'push';
      ref: string;
      commits: Array<{ id: string; message: string }>;
      installation: { id: number };
      repository: { full_name: string };
    }
  | {
      type: 'pull_request';
      action: string;
      pull_request: { number: number; head: { sha: string; ref: string } };
      installation: { id: number };
      repository: { full_name: string };
    }
  | {
      type: 'installation';
      action: 'created' | 'deleted';
      installation: { id: number; account: { login: string } };
    }
  | { type: 'check_run'; action: string; installation: { id: number } };

export function parseWebhookEvent(
  headers: Headers,
  body: string,
): WebhookEvent | null {
  const eventType = headers.get('X-GitHub-Event') ?? headers.get('x-github-event');
  if (!eventType) {
    return null;
  }

  let payload: JsonRecord;
  try {
    payload = JSON.parse(body) as JsonRecord;
  } catch {
    return null;
  }

  if (eventType === 'push') {
    const installationId = Number((payload.installation as JsonRecord | undefined)?.id);
    const fullName = (payload.repository as JsonRecord | undefined)?.full_name;
    if (!installationId || typeof fullName !== 'string' || typeof payload.ref !== 'string') {
      return null;
    }

    return {
      commits: Array.isArray(payload.commits)
        ? payload.commits.map((commit) => ({
            id: String((commit as JsonRecord).id ?? ''),
            message: String((commit as JsonRecord).message ?? ''),
          }))
        : [],
      installation: { id: installationId },
      ref: payload.ref,
      repository: { full_name: fullName },
      type: 'push',
    };
  }

  if (eventType === 'pull_request') {
    const installationId = Number((payload.installation as JsonRecord | undefined)?.id);
    const fullName = (payload.repository as JsonRecord | undefined)?.full_name;
    const pullRequest = payload.pull_request as JsonRecord | undefined;
    const head = pullRequest?.head as JsonRecord | undefined;
    if (
      !installationId ||
      typeof fullName !== 'string' ||
      typeof payload.action !== 'string' ||
      !pullRequest
    ) {
      return null;
    }

    return {
      action: payload.action,
      installation: { id: installationId },
      pull_request: {
        head: {
          ref: String(head?.ref ?? ''),
          sha: String(head?.sha ?? ''),
        },
        number: Number(pullRequest.number ?? 0),
      },
      repository: { full_name: fullName },
      type: 'pull_request',
    };
  }

  if (eventType === 'installation') {
    const installation = payload.installation as JsonRecord | undefined;
    const account = installation?.account as JsonRecord | undefined;
    if (
      (payload.action !== 'created' && payload.action !== 'deleted') ||
      !installation ||
      typeof account?.login !== 'string'
    ) {
      return null;
    }

    return {
      action: payload.action,
      installation: {
        account: { login: account.login },
        id: Number(installation.id ?? 0),
      },
      type: 'installation',
    };
  }

  if (eventType === 'check_run') {
    const installationId = Number((payload.installation as JsonRecord | undefined)?.id);
    if (!installationId || typeof payload.action !== 'string') {
      return null;
    }

    return {
      action: payload.action,
      installation: { id: installationId },
      type: 'check_run',
    };
  }

  return null;
}

export async function createCheckRun(params: {
  installationId: number;
  owner: string;
  repo: string;
  name: string;
  headSha: string;
  status: 'queued' | 'in_progress' | 'completed';
  conclusion?: 'success' | 'failure' | 'neutral' | 'cancelled';
  title: string;
  summary: string;
  detailsUrl?: string;
}): Promise<{ id: number }> {
  const installationToken = await getInstallationToken(params.installationId);
  const payload = await githubRequest<{ id: number }>(
    `/repos/${params.owner}/${params.repo}/check-runs`,
    {
      body: JSON.stringify({
        details_url: params.detailsUrl,
        head_sha: params.headSha,
        name: params.name,
        output: {
          summary: params.summary,
          title: params.title,
        },
        ...(params.conclusion ? { conclusion: params.conclusion } : {}),
        status: params.status,
      }),
      method: 'POST',
      token: installationToken.token,
    },
  );

  return { id: payload.id };
}

export async function updateCheckRun(params: {
  installationId: number;
  owner: string;
  repo: string;
  checkRunId: number;
  status: 'in_progress' | 'completed';
  conclusion?: 'success' | 'failure' | 'neutral';
  title: string;
  summary: string;
}): Promise<void> {
  const installationToken = await getInstallationToken(params.installationId);
  await githubRequest(
    `/repos/${params.owner}/${params.repo}/check-runs/${params.checkRunId}`,
    {
      body: JSON.stringify({
        ...(params.conclusion ? { conclusion: params.conclusion } : {}),
        completed_at:
          params.status === 'completed' ? new Date().toISOString() : undefined,
        output: {
          summary: params.summary,
          title: params.title,
        },
        status: params.status,
      }),
      method: 'PATCH',
      token: installationToken.token,
    },
  );
}

export interface AppInstallation {
  id: number;
  accountLogin: string;
  accountType: 'User' | 'Organization';
  repositorySelection: 'all' | 'selected';
  installedAt: string;
}

export async function listUserInstallations(
  accessToken: string,
): Promise<AppInstallation[]> {
  const payload = await githubRequest<{
    installations?: Array<{
      id: number;
      account?: { login?: string; type?: string };
      repository_selection?: 'all' | 'selected';
      created_at?: string;
      updated_at?: string;
    }>;
  }>('/user/installations', {
    method: 'GET',
    token: accessToken,
  });

  return (payload.installations ?? []).map((installation) => ({
    accountLogin: installation.account?.login ?? '',
    accountType:
      installation.account?.type === 'Organization' ? 'Organization' : 'User',
    id: installation.id,
    installedAt:
      installation.created_at ??
      installation.updated_at ??
      new Date().toISOString(),
    repositorySelection: installation.repository_selection ?? 'selected',
  }));
}

export async function getInstallationRepositories(
  installationId: number,
  accessToken: string,
): Promise<
  Array<{
    id: number;
    fullName: string;
    private: boolean;
    defaultBranch: string;
  }>
> {
  const payload = await githubRequest<{
    repositories?: Array<{
      id: number;
      full_name?: string;
      private?: boolean;
      default_branch?: string;
    }>;
  }>(`/user/installations/${installationId}/repositories`, {
    method: 'GET',
    token: accessToken,
  });

  return (payload.repositories ?? []).map((repository) => ({
    defaultBranch: repository.default_branch ?? 'main',
    fullName: repository.full_name ?? '',
    id: repository.id,
    private: Boolean(repository.private),
  }));
}
