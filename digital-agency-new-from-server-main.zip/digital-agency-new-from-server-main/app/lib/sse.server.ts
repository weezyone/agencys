import kv from './kv.server';
import { getSandboxLogs } from './sandbox.server';
import { sleep } from './utils';

export interface SSEEvent {
  id?: string;
  event?: string;
  data: unknown;
  retry?: number;
}

type WorkflowEventRecord = Record<string, unknown>;
type SandboxLogRecord = Awaited<ReturnType<typeof getSandboxLogs>>[number];

const TERMINAL_WORKFLOW_EVENTS = new Set([
  'workflow_completed',
  'workflow_failed',
]);
const KNOWN_WORKFLOW_EVENTS = new Set([
  'step_started',
  'step_completed',
  'step_failed',
  'log',
  'workflow_completed',
  'workflow_failed',
]);

export function createSSEResponse(
  stream: ReadableStream<Uint8Array>,
): Response {
  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
    },
  });
}

export function encodeSSEEvent(event: SSEEvent): string {
  let str = '';
  if (event.id) str += `id: ${event.id}\n`;
  if (event.event) str += `event: ${event.event}\n`;
  if (event.retry) str += `retry: ${event.retry}\n`;
  str += `data: ${JSON.stringify(event.data)}\n\n`;
  return str;
}

export function createSSEStream(
  generator: AsyncGenerator<SSEEvent>,
  signal?: AbortSignal,
): ReadableStream<Uint8Array> {
  const encoder = new TextEncoder();

  return new ReadableStream<Uint8Array>({
    async start(controller) {
      const iterator = generator[Symbol.asyncIterator]();
      let closed = false;
      let aborted = signal?.aborted ?? false;

      const closeController = () => {
        if (closed) {
          return;
        }

        closed = true;
        try {
          controller.close();
        } catch {
          // Stream is already closed.
        }
      };

      const handleAbort = () => {
        aborted = true;
        void iterator.return?.(undefined);
        closeController();
      };

      signal?.addEventListener('abort', handleAbort, { once: true });

      try {
        if (!aborted) {
          controller.enqueue(encoder.encode('retry: 3000\n\n'));
        }

        while (!aborted) {
          const result = await iterator.next();
          if (aborted || result.done) {
            break;
          }

          controller.enqueue(encoder.encode(encodeSSEEvent(result.value)));
        }
      } catch (error) {
        if (!aborted) {
          const errEvent = encodeSSEEvent({
            event: 'error',
            data: {
              message: error instanceof Error ? error.message : String(error),
            },
          });
          controller.enqueue(encoder.encode(errEvent));
        }
      } finally {
        signal?.removeEventListener('abort', handleAbort);
        closeController();
      }
    },
    cancel() {
      void generator.return?.(undefined);
    },
  });
}

function inferWorkflowEventName(record: WorkflowEventRecord): string {
  const explicitEvent = typeof record.event === 'string' ? record.event : null;
  if (explicitEvent && KNOWN_WORKFLOW_EVENTS.has(explicitEvent)) {
    return explicitEvent;
  }

  const type = typeof record.type === 'string' ? record.type : null;
  if (type && KNOWN_WORKFLOW_EVENTS.has(type)) {
    return type;
  }

  const status = typeof record.status === 'string' ? record.status : null;
  if (status === 'completed') {
    return 'workflow_completed';
  }
  if (status === 'failed') {
    return 'workflow_failed';
  }

  if (typeof record.message === 'string') {
    return 'log';
  }

  return explicitEvent ?? type ?? 'message';
}

function inferWorkflowEventData(record: WorkflowEventRecord): unknown {
  if ('data' in record && record.data !== undefined) {
    return record.data;
  }

  const { data: _data, event: _event, type: _type, ...rest } = record;
  return rest;
}

function isTerminalWorkflowEvent(event: SSEEvent): boolean {
  if (event.event && TERMINAL_WORKFLOW_EVENTS.has(event.event)) {
    return true;
  }

  if (!event.data || typeof event.data !== 'object') {
    return false;
  }

  const status = (event.data as { status?: unknown }).status;
  return status === 'completed' || status === 'failed';
}

function toSandboxSSEEvent(entry: SandboxLogRecord, id: number): SSEEvent {
  if (entry.type === 'exit') {
    const parsedExitCode = Number.parseInt(entry.data, 10);
    return {
      data: {
        exitCode: Number.isNaN(parsedExitCode) ? 0 : parsedExitCode,
        timestamp: entry.timestamp,
      },
      event: 'exit',
      id: String(id),
    };
  }

  return {
    data: {
      data: entry.data,
      timestamp: entry.timestamp,
    },
    event: entry.type === 'stderr' ? 'stderr' : 'stdout',
    id: String(id),
  };
}

export async function* pollWorkflowEvents(
  workflowId: string,
  lastEventIndex: number = 0,
  options?: { intervalMs?: number; timeoutMs?: number },
): AsyncGenerator<SSEEvent> {
  const { intervalMs = 500, timeoutMs = 300_000 } = options ?? {};
  const startTime = Date.now();
  let index = Math.max(0, lastEventIndex);

  while (Date.now() - startTime < timeoutMs) {
    const storedEvents = await kv.get<WorkflowEventRecord[]>(
      `workflow:${workflowId}:events`,
    );
    const events = Array.isArray(storedEvents) ? storedEvents : [];

    if (index < events.length) {
      const nextEvents = events.slice(index);

      for (const [offset, record] of nextEvents.entries()) {
        const event: SSEEvent = {
          data: inferWorkflowEventData(record),
          event: inferWorkflowEventName(record),
          id: String(index + offset + 1),
        };

        yield event;
        if (isTerminalWorkflowEvent(event)) {
          return;
        }
      }

      index = events.length;
    }

    await sleep(intervalMs);
  }

  yield {
    event: 'timeout',
    data: { message: 'Stream timeout after 5 minutes' },
  };
}

export async function* pollSandboxLogs(
  sandboxId: string,
  lastIndex: number = 0,
  options?: { intervalMs?: number; timeoutMs?: number },
): AsyncGenerator<SSEEvent> {
  const { intervalMs = 500, timeoutMs = 300_000 } = options ?? {};
  const startTime = Date.now();
  let index = Math.max(0, lastIndex);

  while (Date.now() - startTime < timeoutMs) {
    const logs = await getSandboxLogs(sandboxId);

    if (index < logs.length) {
      const nextLogs = logs.slice(index);

      for (const [offset, log] of nextLogs.entries()) {
        const event = toSandboxSSEEvent(log, index + offset + 1);
        yield event;
        if (event.event === 'exit') {
          return;
        }
      }

      index = logs.length;
    }

    await sleep(intervalMs);
  }

  yield {
    event: 'timeout',
    data: { message: 'Stream timeout after 5 minutes' },
  };
}

export async function* withHeartbeat(
  generator: AsyncGenerator<SSEEvent>,
  options?: { intervalMs?: number; signal?: AbortSignal },
): AsyncGenerator<SSEEvent> {
  const { intervalMs = 15_000, signal } = options ?? {};
  const iterator = generator[Symbol.asyncIterator]();
  let nextEvent = iterator.next();

  try {
    while (!signal?.aborted) {
      const result = await Promise.race([
        nextEvent.then((value) => ({ kind: 'event' as const, value })),
        sleep(intervalMs).then(() => ({ kind: 'heartbeat' as const })),
      ]);

      if (result.kind === 'heartbeat') {
        if (signal?.aborted) {
          return;
        }

        yield { event: 'heartbeat', data: { ts: Date.now() } };
        continue;
      }

      if (result.value.done) {
        return;
      }

      yield result.value.value;
      nextEvent = iterator.next();
    }
  } finally {
    await iterator.return?.(undefined);
  }
}
