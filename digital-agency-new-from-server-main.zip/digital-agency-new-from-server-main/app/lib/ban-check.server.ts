import { db } from './db.server';
import { kv } from './kv.server';

const BAN_CACHE_TTL_SECONDS = 60 * 5;
const BAN_CACHE_PREFIX = 'ban-status:';

function bannedResponse() {
  return Response.json(
    {
      error: 'account_banned',
      message: 'Your account has been suspended.',
    },
    { status: 403 },
  );
}

function getBanCacheKey(userId: string) {
  return `${BAN_CACHE_PREFIX}${userId}`;
}

export async function checkNotBanned(userId: string): Promise<void> {
  const cacheKey = getBanCacheKey(userId);
  const cached = await kv.get<boolean>(cacheKey);

  if (cached === true) {
    throw bannedResponse();
  }

  if (cached === false) {
    return;
  }

  const user = await db.user.findUnique({
    where: { id: userId },
    select: { isBanned: true },
  });
  const isBanned = Boolean(user?.isBanned);

  await kv.set(cacheKey, isBanned, { ex: BAN_CACHE_TTL_SECONDS });

  if (isBanned) {
    throw bannedResponse();
  }
}
