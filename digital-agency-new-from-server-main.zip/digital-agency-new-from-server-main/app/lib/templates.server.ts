import { Prisma, type Project, type ProjectTemplate } from '@prisma/client';
import { z } from 'zod';
import { createProject } from '~/lib/data.server';
import { db } from '~/lib/db.server';
import {
  createTemplateSchema,
  TEMPLATE_CATEGORIES,
} from '~/lib/schemas.server';
import type { SandboxConfig } from '~/lib/sandbox.server';

export interface TemplateFilters {
  category?: string;
  search?: string;
  isBuiltIn?: boolean;
  authorId?: string;
  limit?: number;
  offset?: number;
}

export type CreateTemplateInput = z.infer<typeof createTemplateSchema>;

interface PublishTemplateInput {
  name: string;
  description: string;
  category: string;
  tags: string[];
  aiPrompt?: string;
}

interface BuiltInTemplateDefinition {
  name: string;
  description: string;
  category: (typeof TEMPLATE_CATEGORIES)[number];
  tags: string[];
  repositoryUrl?: string;
  branch?: string;
  sandboxConfig: Pick<SandboxConfig, 'vcpus' | 'timeoutMinutes' | 'runtime'>;
  aiPrompt: string;
}

const DEFAULT_SANDBOX_CONFIG: Pick<
  SandboxConfig,
  'vcpus' | 'timeoutMinutes' | 'runtime'
> = {
  vcpus: 2,
  timeoutMinutes: 30,
  runtime: 'node22',
};

export const BUILT_IN_TEMPLATES: BuiltInTemplateDefinition[] = [
  {
    name: 'Next.js Full-Stack App',
    description:
      'Production-ready Next.js app with TypeScript, Tailwind CSS, and Prisma ORM',
    category: 'fullstack',
    tags: ['nextjs', 'typescript', 'tailwind', 'prisma', 'react'],
    repositoryUrl: 'https://github.com/vercel/next.js',
    branch: 'canary',
    sandboxConfig: { vcpus: 2, timeoutMinutes: 60, runtime: 'node22' },
    aiPrompt:
      'Set up a Next.js 15 app with App Router, TypeScript, Tailwind CSS v4, and Prisma with PostgreSQL. Create a simple CRUD dashboard.',
  },
  {
    name: 'Python FastAPI Service',
    description:
      'High-performance async Python API with FastAPI, Pydantic, and SQLAlchemy',
    category: 'api',
    tags: ['python', 'fastapi', 'async', 'pydantic', 'sqlalchemy'],
    sandboxConfig: { vcpus: 2, timeoutMinutes: 30, runtime: 'python3.13' },
    aiPrompt:
      'Create a FastAPI service with async endpoints, Pydantic models, SQLAlchemy with async support, and OpenAPI docs. Include health check and CRUD endpoints.',
  },
  {
    name: 'React Component Library',
    description:
      'Shareable React component library with Storybook, TypeScript, and Vitest',
    category: 'library',
    tags: ['react', 'typescript', 'storybook', 'vitest', 'components'],
    sandboxConfig: { vcpus: 2, timeoutMinutes: 45, runtime: 'node22' },
    aiPrompt:
      'Build a React component library with TypeScript. Create 5 core components (Button, Card, Modal, Input, Badge) with Storybook stories and Vitest tests.',
  },
  {
    name: 'Node.js CLI Tool',
    description:
      'Feature-rich CLI tool with Commander.js, colored output, and config management',
    category: 'cli',
    tags: ['nodejs', 'cli', 'commander', 'typescript'],
    sandboxConfig: { vcpus: 1, timeoutMinutes: 20, runtime: 'node22' },
    aiPrompt:
      'Build a Node.js CLI tool using Commander.js and TypeScript. Add colored output with chalk, config file support, and at least 3 useful commands.',
  },
  {
    name: 'SaaS Starter',
    description:
      'Complete SaaS boilerplate: auth, billing, dashboard, and team workspaces',
    category: 'fullstack',
    tags: ['saas', 'auth', 'billing', 'typescript', 'react'],
    sandboxConfig: { vcpus: 4, timeoutMinutes: 120, runtime: 'node22' },
    aiPrompt:
      'Build a SaaS starter with: user authentication (OAuth), subscription tiers, admin dashboard, team workspaces, and API key management.',
  },
  {
    name: 'Data Analysis Notebook',
    description:
      'Python data science environment with pandas, matplotlib, and Jupyter',
    category: 'data',
    tags: ['python', 'pandas', 'data-science', 'jupyter', 'matplotlib'],
    sandboxConfig: { vcpus: 2, timeoutMinutes: 60, runtime: 'python3.13' },
    aiPrompt:
      'Set up a Python data analysis environment. Install pandas, matplotlib, seaborn, scikit-learn. Create a sample analysis notebook with data loading, cleaning, visualization, and basic ML model.',
  },
  {
    name: 'REST API with Tests',
    description:
      'Express.js REST API with full test suite, OpenAPI docs, and rate limiting',
    category: 'api',
    tags: ['nodejs', 'express', 'rest', 'testing', 'openapi'],
    sandboxConfig: { vcpus: 2, timeoutMinutes: 30, runtime: 'node22' },
    aiPrompt:
      'Build an Express.js REST API with TypeScript. Include: OpenAPI/Swagger docs, request validation with Zod, rate limiting, Jest test suite with 80%+ coverage, and Docker support.',
  },
  {
    name: 'Discord Bot',
    description:
      'Discord.js bot with slash commands, embed messages, and database integration',
    category: 'bot',
    tags: ['discord', 'bot', 'nodejs', 'slash-commands'],
    sandboxConfig: { vcpus: 1, timeoutMinutes: 30, runtime: 'node22' },
    aiPrompt:
      'Build a Discord bot with discord.js v14. Add 5 slash commands, embed message support, a points/economy system stored in SQLite, and proper error handling.',
  },
];

function normalizeTags(tags: string[]) {
  return Array.from(
    new Set(tags.map((tag) => tag.trim().toLowerCase()).filter(Boolean)),
  );
}

export function isTemplateStorageUnavailable(error: unknown) {
  if (error instanceof Prisma.PrismaClientKnownRequestError) {
    return error.code === 'P2021';
  }

  return (
    error instanceof Error &&
    error.message.includes('project_templates') &&
    error.message.includes('does not exist')
  );
}

function toInputJson(value: unknown): Prisma.InputJsonValue {
  return JSON.parse(JSON.stringify(value ?? {})) as Prisma.InputJsonValue;
}

function templateVisibilityWhere(): Prisma.ProjectTemplateWhereInput {
  return { OR: [{ isBuiltIn: true }, { isPublic: true }] };
}

function getGitProvider(repositoryUrl?: string | null) {
  if (!repositoryUrl) {
    return 'github';
  }

  return repositoryUrl.includes('gitlab') ? 'gitlab' : 'github';
}

function toSandboxConfig(value: unknown): SandboxConfig {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    return { ...DEFAULT_SANDBOX_CONFIG };
  }

  const candidate = value as Record<string, unknown>;

  return {
    ...DEFAULT_SANDBOX_CONFIG,
    ...(typeof candidate.vcpus === 'number' ? { vcpus: candidate.vcpus } : {}),
    ...(typeof candidate.timeoutMinutes === 'number'
      ? { timeoutMinutes: candidate.timeoutMinutes }
      : {}),
    ...(candidate.runtime === 'python3.13'
      ? { runtime: 'python3.13' as const }
      : {}),
    ...(typeof candidate.memoryMb === 'number'
      ? { memoryMb: candidate.memoryMb }
      : {}),
    ...(Array.isArray(candidate.ports)
      ? {
          ports: candidate.ports.filter(
            (entry): entry is number => typeof entry === 'number',
          ),
        }
      : {}),
    ...(typeof candidate.repositoryUrl === 'string'
      ? { repositoryUrl: candidate.repositoryUrl }
      : {}),
    ...(typeof candidate.branch === 'string' ? { branch: candidate.branch } : {}),
  };
}

function projectSandboxConfig(project: Pick<Project, 'settings'>): SandboxConfig {
  if (
    project.settings &&
    typeof project.settings === 'object' &&
    !Array.isArray(project.settings) &&
    'sandboxConfig' in project.settings
  ) {
    return toSandboxConfig((project.settings as Record<string, unknown>).sandboxConfig);
  }

  return { ...DEFAULT_SANDBOX_CONFIG };
}

async function ensureBuiltInTemplatesSeeded() {
  const builtInCount = await db.projectTemplate.count({
    where: { isBuiltIn: true },
  });

  if (builtInCount === 0) {
    await seedBuiltInTemplates();
  }
}

export async function listTemplates(
  filters: TemplateFilters,
): Promise<{ templates: ProjectTemplate[]; total: number }> {
  await ensureBuiltInTemplatesSeeded();

  const whereClauses: Prisma.ProjectTemplateWhereInput[] = [];

  if (filters.authorId) {
    whereClauses.push({ authorId: filters.authorId });
  } else {
    whereClauses.push(templateVisibilityWhere());
  }

  if (filters.category) {
    whereClauses.push({ category: filters.category });
  }

  if (filters.isBuiltIn !== undefined) {
    whereClauses.push({ isBuiltIn: filters.isBuiltIn });
  }

  const search = filters.search?.trim();
  if (search) {
    whereClauses.push({
      OR: [
        { name: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
        { tags: { has: search.toLowerCase() } },
      ],
    });
  }

  const where = whereClauses.length > 0 ? { AND: whereClauses } : undefined;

  const [templates, total] = await Promise.all([
    db.projectTemplate.findMany({
      where,
      orderBy: [
        { isBuiltIn: 'desc' },
        { useCount: 'desc' },
        { createdAt: 'desc' },
      ],
      take: filters.limit ?? 20,
      skip: filters.offset ?? 0,
    }),
    db.projectTemplate.count({ where }),
  ]);

  return { templates, total };
}

export async function listTemplateCategories(): Promise<string[]> {
  await ensureBuiltInTemplatesSeeded();

  const categories = await db.projectTemplate.findMany({
    distinct: ['category'],
    orderBy: { category: 'asc' },
    select: { category: true },
    where: templateVisibilityWhere(),
  });

  return categories.map((entry) => entry.category);
}

export async function getTemplateById(
  id: string,
): Promise<ProjectTemplate | null> {
  await ensureBuiltInTemplatesSeeded();

  return db.projectTemplate.findFirst({
    where: {
      id,
      OR: [{ isBuiltIn: true }, { isPublic: true }],
    },
  });
}

export async function createTemplate(
  authorId: string,
  data: CreateTemplateInput,
): Promise<ProjectTemplate> {
  const parsedData = createTemplateSchema.parse(data);

  return db.projectTemplate.create({
    data: {
      name: parsedData.name,
      description: parsedData.description,
      category: parsedData.category,
      tags: normalizeTags(parsedData.tags),
      repositoryUrl: parsedData.repositoryUrl,
      sandboxConfig: toInputJson(
        parsedData.sandboxConfig ?? DEFAULT_SANDBOX_CONFIG,
      ),
      aiPrompt: parsedData.aiPrompt,
      authorId,
      isPublic: parsedData.isPublic,
      isBuiltIn: false,
    },
  });
}

export async function useTemplate(
  templateId: string,
  userId: string,
  projectName: string,
): Promise<{
  project: Project;
  template: ProjectTemplate;
  sandboxConfig: SandboxConfig;
  starterPrompt: string | null;
}> {
  await ensureBuiltInTemplatesSeeded();

  const template = await db.projectTemplate.findFirst({
    where: {
      id: templateId,
      OR: [{ isBuiltIn: true }, { isPublic: true }, { authorId: userId }],
    },
  });

  if (!template) {
    throw new Error('Template not found');
  }

  const sandboxConfig = toSandboxConfig(template.sandboxConfig);
  const project = await createProject(userId, {
    name: projectName,
    description: template.description,
    repositoryUrl: template.repositoryUrl ?? undefined,
    branch: template.branch,
    settings: {
      aiProvider: 'nvidia',
      gitIntegration: {
        defaultBranch: template.branch,
        provider: getGitProvider(template.repositoryUrl),
        repositoryUrl: template.repositoryUrl ?? undefined,
      },
      sandboxConfig,
      templateId: template.id,
      templateName: template.name,
      starterPrompt: template.aiPrompt ?? undefined,
    },
  });

  await incrementTemplateUseCount(template.id);

  return {
    project,
    template,
    sandboxConfig,
    starterPrompt: template.aiPrompt ?? null,
  };
}

export async function incrementTemplateUseCount(
  templateId: string,
): Promise<void> {
  await db.projectTemplate.update({
    where: { id: templateId },
    data: { useCount: { increment: 1 } },
  });
}

export async function publishProjectAsTemplate(
  projectId: string,
  userId: string,
  templateData: PublishTemplateInput,
): Promise<ProjectTemplate> {
  const project = await db.project.findFirst({
    where: { id: projectId, userId },
  });

  if (!project) {
    throw new Error('Project not found');
  }

  return db.projectTemplate.create({
    data: {
      name: templateData.name,
      description: templateData.description,
      category: templateData.category,
      tags: normalizeTags(templateData.tags),
      repositoryUrl: project.repositoryUrl,
      branch: project.branch,
      sandboxConfig: toInputJson(projectSandboxConfig(project)),
      aiPrompt: templateData.aiPrompt,
      authorId: userId,
      isPublic: true,
      isBuiltIn: false,
      longDescription: project.description,
    },
  });
}

export async function deleteTemplate(
  templateId: string,
  userId: string,
): Promise<void> {
  const template = await db.projectTemplate.findFirst({
    where: { id: templateId },
  });

  if (!template) {
    throw new Error('Template not found');
  }

  if (template.isBuiltIn) {
    throw new Error('Built-in templates cannot be deleted');
  }

  if (template.authorId !== userId) {
    throw new Error('Template not found');
  }

  await db.projectTemplate.delete({ where: { id: templateId } });
}

export async function seedBuiltInTemplates(): Promise<void> {
  for (const template of BUILT_IN_TEMPLATES) {
    const existingTemplate = await db.projectTemplate.findFirst({
      where: { name: template.name, isBuiltIn: true },
    });

    const data = {
      name: template.name,
      description: template.description,
      category: template.category,
      tags: normalizeTags(template.tags),
      repositoryUrl: template.repositoryUrl,
      branch: template.branch ?? 'main',
      sandboxConfig: toInputJson(template.sandboxConfig),
      aiPrompt: template.aiPrompt,
      isPublic: true,
      isBuiltIn: true,
      authorId: null,
    };

    if (existingTemplate) {
      await db.projectTemplate.update({
        where: { id: existingTemplate.id },
        data,
      });
      continue;
    }

    await db.projectTemplate.create({ data });
  }
}
