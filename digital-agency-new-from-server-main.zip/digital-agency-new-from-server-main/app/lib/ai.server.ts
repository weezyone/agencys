import { createAnthropic } from '@ai-sdk/anthropic';
import { createOpenAI } from '@ai-sdk/openai';
import { generateText, streamText } from 'ai';
import {
  createCipheriv,
  createDecipheriv,
  randomBytes,
  scryptSync,
} from 'node:crypto';
import { PROVIDER_DEFINITIONS, validateProviderConfig, type AIProvider } from './ai-providers';
import { checkRateLimit } from './rate-limit.server';
import { executeSandboxCommand } from './sandbox.server';

export interface AITaskConfig {
  provider: AIProvider;
  prompt: string;
  contextFiles?: Array<{ path: string; content: string }>;
  maxTokens?: number;
  temperature?: number;
  systemPrompt?: string;
}

export interface AITaskResult {
  provider: AIProvider;
  content: string;
  usage: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
  model: string;
  finishReason: string;
}

const RATE_LIMIT_REQUESTS = 5;
const RATE_LIMIT_WINDOW_SECONDS = 60;
const ENCRYPTION_SALT = 'cloud-first-ai-api-key';

function escapeXml(value: string) {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function escapeShellArg(value: string) {
  return `'${value.replace(/'/g, `'\\''`)}'`;
}

function getModelId(provider: AIProvider) {
  return PROVIDER_DEFINITIONS[provider].model;
}

function getProviderEnv(provider: AIProvider) {
  const { envKey } = PROVIDER_DEFINITIONS[provider];
  return { envKey, value: process.env[envKey] };
}

function normalizeUsage(usage?: {
  inputTokens?: number;
  outputTokens?: number;
  totalTokens?: number;
}) {
  return {
    completionTokens: usage?.outputTokens ?? 0,
    promptTokens: usage?.inputTokens ?? 0,
    totalTokens: usage?.totalTokens ?? 0,
  };
}

function getSystemPrompt(config: AITaskConfig) {
  return config.systemPrompt ?? buildCodingSystemPrompt(config.contextFiles);
}

function resolveModel(provider: AIProvider) {
  const definition = PROVIDER_DEFINITIONS[provider];
  const modelId = definition.model;
  const model =
    definition.kind === 'anthropic'
      ? getAnthropicClient()(modelId)
      : getOpenAICompatibleClient(provider)(modelId);
  return { model, modelId };
}

export function getAnthropicClient(): ReturnType<typeof createAnthropic> {
  return createAnthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
}

export function getOpenAIClient(): ReturnType<typeof createOpenAI> {
  return createOpenAI({ apiKey: process.env.OPENAI_API_KEY });
}

export function getOpenAICompatibleClient(
  provider: AIProvider,
): ReturnType<typeof createOpenAI> {
  const definition = PROVIDER_DEFINITIONS[provider];
  if (definition.kind !== 'openai-compatible') {
    throw new Error(`Provider ${provider} is not OpenAI-compatible`);
  }
  return createOpenAI({
    apiKey: process.env[definition.envKey],
    ...(definition.baseURL ? { baseURL: definition.baseURL } : {}),
  });
}

export function resolveProviderWithFallback(provider: AIProvider): {
  provider: AIProvider;
  fallbackFrom?: AIProvider;
} {
  // If the requested provider is unavailable, transparently fall back to a configured one.
  // Preferred fallback order: NVIDIA -> HuggingFace -> OpenRouter -> Codex -> Claude.
  const FALLBACK_ORDER: AIProvider[] = [
    'nvidia',
    'huggingface',
    'openrouter',
    'codex',
    'claude',
  ];

  if (validateProviderConfig(provider).valid) {
    return { provider };
  }

  for (const candidate of FALLBACK_ORDER) {
    if (candidate !== provider && validateProviderConfig(candidate).valid) {
      return { fallbackFrom: provider, provider: candidate };
    }
  }

  return { provider };
}

export async function generateAIResponse(
  config: AITaskConfig,
): Promise<AITaskResult> {
  const primary = resolveProviderWithFallback(config.provider);
  const tryProvider = async (provider: AIProvider): Promise<AITaskResult> => {
    const { model, modelId } = resolveModel(provider);
    const result = await generateText({
      maxOutputTokens: config.maxTokens,
      model,
      prompt: config.prompt,
      system: getSystemPrompt(config),
      temperature: config.temperature,
    });
    const usage = normalizeUsage(result.totalUsage ?? result.usage);
    return {
      content: result.text,
      finishReason: String(result.finishReason ?? 'stop'),
      model: result.response?.modelId ?? modelId,
      provider,
      usage,
    };
  };

  try {
    return await tryProvider(primary.provider);
  } catch (error) {
    // If NVIDIA failed and HuggingFace is available, retry there once.
    if (
      primary.provider === 'nvidia' &&
      validateProviderConfig('huggingface').valid
    ) {
      console.warn(
        '[ai] nvidia request failed, falling back to huggingface:',
        error instanceof Error ? error.message : error,
      );
      return tryProvider('huggingface');
    }
    throw error;
  }
}

export async function streamAIResponse(
  config: AITaskConfig,
): Promise<ReadableStream> {
  const primary = resolveProviderWithFallback(config.provider);

  const buildStream = (provider: AIProvider) => {
    const { model } = resolveModel(provider);
    return streamText({
      maxOutputTokens: config.maxTokens,
      model,
      prompt: config.prompt,
      system: getSystemPrompt(config),
      temperature: config.temperature,
    });
  };

  const result = buildStream(primary.provider);
  const encoder = new TextEncoder();

  return new ReadableStream({
    async start(controller) {
      const consume = async (
        stream: ReturnType<typeof buildStream>,
        allowFallback: boolean,
      ) => {
        let receivedAny = false;
        try {
          for await (const part of stream.fullStream) {
            if (part.type === 'text-delta' && part.text) {
              receivedAny = true;
              controller.enqueue(
                encoder.encode(
                  `data: ${JSON.stringify({ type: 'token', content: part.text })}\n\n`,
                ),
              );
            }
          }

          const usage = normalizeUsage(await stream.totalUsage);
          controller.enqueue(
            encoder.encode(
              `data: ${JSON.stringify({ type: 'complete', usage })}\n\n`,
            ),
          );
          controller.enqueue(encoder.encode('data: [DONE]\n\n'));
        } catch (error) {
          if (
            allowFallback &&
            !receivedAny &&
            primary.provider === 'nvidia' &&
            validateProviderConfig('huggingface').valid
          ) {
            console.warn(
              '[ai] nvidia stream failed, falling back to huggingface:',
              error instanceof Error ? error.message : error,
            );
            await consume(buildStream('huggingface'), false);
            return;
          }
          controller.enqueue(
            encoder.encode(
              `data: ${JSON.stringify({ type: 'error', error: error instanceof Error ? error.message : 'AI stream failed' })}\n\n`,
            ),
          );
          controller.enqueue(encoder.encode('data: [DONE]\n\n'));
        }
      };

      try {
        await consume(result, true);
      } finally {
        controller.close();
      }
    },
  });
}

export function buildCodingSystemPrompt(
  contextFiles?: Array<{ path: string; content: string }>,
): string {
  const basePrompt = [
    'You are a senior software engineer working inside the Cloud-First AI Development Platform.',
    'Produce accurate, production-ready code and explain important trade-offs briefly.',
    'Preserve existing behavior unless the prompt explicitly requests a change.',
    'When context files are provided, treat them as the current source of truth.',
  ].join(' ');

  if (!contextFiles?.length) {
    return basePrompt;
  }

  const contextBlock = contextFiles
    .map(
      (file) =>
        `<file path="${escapeXml(file.path)}">\n${escapeXml(file.content)}\n</file>`,
    )
    .join('\n');

  return `${basePrompt}\n\n<context_files>\n${contextBlock}\n</context_files>`;
}

export async function executeAgentInSandbox(
  sandboxId: string,
  provider: AIProvider,
  prompt: string,
  options?: { cwd?: string; env?: Record<string, string> },
): Promise<{ output: string; exitCode: number }> {
  if (provider !== 'claude' && provider !== 'codex') {
    throw new Error(
      `In-sandbox agent execution is not supported for provider "${provider}". Use the streaming/generate API instead.`,
    );
  }
  const command =
    provider === 'claude'
      ? `claude --print ${escapeShellArg(prompt)}`
      : `codex ${escapeShellArg(prompt)}`;
  const providerEnv = getProviderEnv(provider);
  const result = await executeSandboxCommand(sandboxId, command, {
    cwd: options?.cwd,
    env: {
      ...(providerEnv.value ? { [providerEnv.envKey]: providerEnv.value } : {}),
      ...options?.env,
    },
  });

  return {
    exitCode: result.exitCode,
    output: [result.stdout, result.stderr]
      .filter(Boolean)
      .join(result.stdout && result.stderr ? '\n' : ''),
  };
}

export function getRateLimitKey(userId: string, provider: AIProvider): string {
  return `ai-rate-limit:${userId}:${provider}`;
}

export async function checkProviderRateLimit(
  userId: string,
  provider: AIProvider,
): Promise<{ allowed: boolean; remaining: number; resetAt: Date }> {
  return checkRateLimit(
    getRateLimitKey(userId, provider),
    RATE_LIMIT_REQUESTS,
    RATE_LIMIT_WINDOW_SECONDS,
  );
}

function deriveEncryptionKey(secret: string) {
  return scryptSync(secret, ENCRYPTION_SALT, 32);
}

export function encryptApiKey(key: string, secret: string): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', deriveEncryptionKey(secret), iv);
  const encrypted = Buffer.concat([cipher.update(key, 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();

  return [
    iv.toString('base64'),
    authTag.toString('base64'),
    encrypted.toString('base64'),
  ].join('.');
}

export function decryptApiKey(encrypted: string, secret: string): string {
  const [ivPart, authTagPart, payloadPart] = encrypted.split('.');
  if (!ivPart || !authTagPart || !payloadPart) {
    throw new Error('Invalid encrypted API key format');
  }

  const decipher = createDecipheriv(
    'aes-256-gcm',
    deriveEncryptionKey(secret),
    Buffer.from(ivPart, 'base64'),
  );
  decipher.setAuthTag(Buffer.from(authTagPart, 'base64'));

  return Buffer.concat([
    decipher.update(Buffer.from(payloadPart, 'base64')),
    decipher.final(),
  ]).toString('utf8');
}

export { PROVIDER_DEFINITIONS, validateProviderConfig, type AIProvider } from './ai-providers';
