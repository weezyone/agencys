import { execFile } from 'node:child_process';
import { createHash, randomUUID } from 'node:crypto';
import { mkdir, rm, writeFile } from 'node:fs/promises';
import { dirname, join, posix } from 'node:path';
const DEFAULT_MAX_FILES = 1000;
const DEFAULT_MAX_SIZE_BYTES = 10 * 1024 * 1024;
const TEMP_ARCHIVE_ROOT = join(process.cwd(), 'build', 'archive-temp');

export interface FileEntry {
  path: string;
  content: string | Buffer;
}

export interface ArchiveMetadata {
  id: string;
  filename: string;
  fileCount: number;
  totalSizeBytes: number;
  checksum: string;
  createdAt: Date;
}

function ensureZipFilename(archiveName: string) {
  const trimmed = archiveName.trim() || 'archive.zip';
  const basename = posix.basename(trimmed).replace(/[^A-Za-z0-9._-]+/g, '-');
  return basename.toLowerCase().endsWith('.zip') ? basename : `${basename}.zip`;
}

function sanitizeArchivePath(inputPath: string) {
  const normalized = posix
    .normalize(inputPath.replace(/\\/g, '/').trim().replace(/^\/+/, ''))
    .replace(/^\.\//, '');

  if (
    !normalized ||
    normalized === '.' ||
    normalized === '..' ||
    normalized.startsWith('../') ||
    normalized.includes('/../')
  ) {
    throw new Error(`Invalid archive path: ${inputPath}`);
  }

  return normalized;
}

function getContentSize(content: string | Buffer) {
  return typeof content === 'string'
    ? Buffer.byteLength(content)
    : content.length;
}

function validateFileListWithOptions(
  files: FileEntry[],
  options: { maxFiles?: number; maxSizeBytes?: number } = {},
): { valid: boolean; error?: string } {
  const maxFiles = options.maxFiles ?? DEFAULT_MAX_FILES;
  const maxSizeBytes = options.maxSizeBytes ?? DEFAULT_MAX_SIZE_BYTES;

  if (files.length === 0) {
    return { valid: false, error: 'At least one file is required.' };
  }

  if (files.length > maxFiles) {
    return {
      valid: false,
      error: `Too many files. Maximum allowed is ${maxFiles}.`,
    };
  }

  let totalSizeBytes = 0;
  const seenPaths = new Set<string>();

  for (const file of files) {
    let sanitizedPath: string;
    try {
      sanitizedPath = sanitizeArchivePath(file.path);
    } catch (error) {
      return {
        valid: false,
        error: error instanceof Error ? error.message : 'Invalid archive path.',
      };
    }

    if (seenPaths.has(sanitizedPath)) {
      return {
        valid: false,
        error: `Duplicate archive path: ${sanitizedPath}`,
      };
    }
    seenPaths.add(sanitizedPath);

    totalSizeBytes += getContentSize(file.content);
    if (totalSizeBytes > maxSizeBytes) {
      return {
        valid: false,
        error: `Total file size exceeds ${maxSizeBytes} bytes.`,
      };
    }
  }

  return { valid: true };
}

async function runZipCommand(cwd: string, maxBuffer: number) {
  return new Promise<{ stdout: Buffer | string; stderr: Buffer | string }>(
    (resolve, reject) => {
      execFile(
        'zip',
        ['-q', '-r', '-', '.'],
        {
          cwd,
          encoding: 'buffer',
          maxBuffer,
        },
        (error, stdout, stderr) => {
          if (error) {
            reject(error);
            return;
          }

          resolve({ stderr, stdout });
        },
      );
    },
  );
}

async function prepareArchiveWorkspace(files: FileEntry[]) {
  const workspaceId = randomUUID();
  const workspaceDir = join(TEMP_ARCHIVE_ROOT, workspaceId);
  const inputDir = join(workspaceDir, 'input');

  await mkdir(inputDir, { recursive: true });

  for (const file of files) {
    const archivePath = sanitizeArchivePath(file.path);
    const filePath = join(inputDir, ...archivePath.split('/'));
    await mkdir(dirname(filePath), { recursive: true });
    await writeFile(filePath, file.content);
  }

  return { inputDir, workspaceDir };
}

export async function calculateChecksum(buffer: Buffer): Promise<string> {
  return createHash('sha256').update(buffer).digest('hex');
}

export function validateFileList(files: FileEntry[]): {
  valid: boolean;
  error?: string;
} {
  return validateFileListWithOptions(files);
}

export async function createZipArchive(
  files: FileEntry[],
  archiveName: string,
  options: { maxFiles?: number; maxSizeBytes?: number } = {},
): Promise<{ buffer: Buffer; metadata: ArchiveMetadata }> {
  const validation = validateFileListWithOptions(files, options);
  if (!validation.valid) {
    throw new Error(validation.error);
  }

  const createdAt = new Date();
  const id = randomUUID();
  const filename = ensureZipFilename(archiveName);
  const { inputDir, workspaceDir } = await prepareArchiveWorkspace(files);

  try {
    const maxSizeBytes = options.maxSizeBytes ?? DEFAULT_MAX_SIZE_BYTES;
    const { stdout } = await runZipCommand(
      inputDir,
      maxSizeBytes + 1024 * 1024,
    );
    const buffer = Buffer.isBuffer(stdout) ? stdout : Buffer.from(stdout);
    const checksum = await calculateChecksum(buffer);

    return {
      buffer,
      metadata: {
        checksum,
        createdAt,
        fileCount: files.length,
        filename,
        id,
        totalSizeBytes: buffer.length,
      },
    };
  } finally {
    await rm(workspaceDir, { force: true, recursive: true });
  }
}

export async function* createZipArchiveStream(
  files: FileEntry[],
  archiveName: string,
): AsyncGenerator<
  | { type: 'progress'; processed: number; total: number }
  | { type: 'complete'; buffer: Buffer; metadata: ArchiveMetadata }
  | { type: 'error'; message: string }
> {
  const validation = validateFileList(files);
  if (!validation.valid) {
    yield { type: 'error', message: validation.error ?? 'Invalid file list.' };
    return;
  }

  for (let index = 0; index < files.length; index += 1) {
    yield { type: 'progress', processed: index + 1, total: files.length };
  }

  try {
    const result = await createZipArchive(files, archiveName);
    yield { type: 'complete', ...result };
  } catch (error) {
    yield {
      type: 'error',
      message:
        error instanceof Error ? error.message : 'Failed to create archive.',
    };
  }
}
