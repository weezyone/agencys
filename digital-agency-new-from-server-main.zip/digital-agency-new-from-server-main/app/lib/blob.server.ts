import { mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const LOCAL_BLOB_ROOT = path.resolve(process.cwd(), 'build', 'artifacts');
const VERCEL_BLOB_API_URL =
  process.env.VERCEL_BLOB_API_URL ?? 'https://api.vercel.com';

function getBlobToken() {
  return process.env.BLOB_READ_WRITE_TOKEN;
}

function getLocalPath(pathname: string) {
  return path.join(LOCAL_BLOB_ROOT, pathname.replace(/^\/+/, ''));
}

function normalizeFilename(filename: string) {
  const trimmed = filename.trim();
  const safe = path.basename(trimmed || 'artifact.bin').replace(/\s+/g, '-');
  return `${crypto.randomUUID()}-${safe}`;
}

async function toBuffer(content: Buffer | Blob) {
  if (content instanceof Blob) {
    return Buffer.from(await content.arrayBuffer());
  }

  return content;
}

async function uploadToVercelBlob(
  filename: string,
  content: Buffer | Blob,
  contentType: string,
): Promise<{ url: string; pathname: string }> {
  const token = getBlobToken();

  if (!token) {
    throw new Error(
      'BLOB_READ_WRITE_TOKEN is required for Vercel Blob uploads.',
    );
  }

  const uploadUrlResponse = await fetch(
    `${VERCEL_BLOB_API_URL}/v1/blobs/upload-url`,
    {
      body: JSON.stringify({
        contentType,
        filename,
      }),
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      method: 'POST',
    },
  );

  if (!uploadUrlResponse.ok) {
    throw new Error(
      `Failed to create Vercel Blob upload URL (${uploadUrlResponse.status}).`,
    );
  }

  const uploadTarget = (await uploadUrlResponse.json()) as {
    pathname?: string;
    uploadUrl?: string;
    url?: string;
  };
  const targetUrl = uploadTarget.uploadUrl ?? uploadTarget.url;

  if (!targetUrl) {
    throw new Error(
      'Vercel Blob upload URL response did not include an upload target.',
    );
  }

  const uploadResponse = await fetch(targetUrl, {
    body: new Uint8Array(await toBuffer(content)),
    headers: {
      'Content-Type': contentType,
    },
    method: 'PUT',
  });

  if (!uploadResponse.ok) {
    throw new Error(
      `Failed to upload artifact to Vercel Blob (${uploadResponse.status}).`,
    );
  }

  let uploadedBlob: { pathname?: string; url?: string } | null = null;
  try {
    uploadedBlob = (await uploadResponse.json()) as {
      pathname?: string;
      url?: string;
    };
  } catch {
    uploadedBlob = null;
  }

  const url = uploadedBlob?.url ?? uploadTarget.url ?? targetUrl.split('?')[0];
  const pathname =
    uploadedBlob?.pathname ??
    uploadTarget.pathname ??
    new URL(url).pathname.replace(/^\/+/, '');

  return { pathname, url };
}

async function uploadToLocalBlob(
  filename: string,
  content: Buffer | Blob,
): Promise<{ url: string; pathname: string }> {
  const pathname = normalizeFilename(filename);
  const filePath = getLocalPath(pathname);

  await mkdir(path.dirname(filePath), { recursive: true });
  await writeFile(filePath, await toBuffer(content));

  return {
    pathname,
    url: pathToFileURL(filePath).toString(),
  };
}

export async function uploadFile(
  filename: string,
  content: Buffer | Blob,
  contentType: string,
): Promise<{ url: string; pathname: string }> {
  return getBlobToken()
    ? uploadToVercelBlob(filename, content, contentType)
    : uploadToLocalBlob(filename, content);
}

export async function deleteFile(url: string): Promise<void> {
  if (url.startsWith('file://')) {
    await rm(fileURLToPath(url), { force: true });
    return;
  }

  const token = getBlobToken();
  if (!token) {
    return;
  }

  const deleteResponse = await fetch(`${VERCEL_BLOB_API_URL}/v1/blobs`, {
    body: JSON.stringify({ url }),
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    method: 'DELETE',
  });

  if (!deleteResponse.ok) {
    throw new Error(
      `Failed to delete Vercel Blob artifact (${deleteResponse.status}).`,
    );
  }
}

export async function generateSignedUrl(
  pathname: string,
  expiresInSeconds: number,
): Promise<string> {
  if (!getBlobToken()) {
    const filePath = getLocalPath(pathname);
    await readFile(filePath);
    const fileUrl = pathToFileURL(filePath);
    fileUrl.searchParams.set(
      'expires',
      String(Date.now() + expiresInSeconds * 1000),
    );
    return fileUrl.toString();
  }

  const token = getBlobToken();
  const response = await fetch(`${VERCEL_BLOB_API_URL}/v1/blobs/signed-url`, {
    body: JSON.stringify({
      expiresIn: expiresInSeconds,
      pathname,
    }),
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    method: 'POST',
  });

  if (!response.ok) {
    throw new Error(
      `Failed to generate signed Vercel Blob URL (${response.status}).`,
    );
  }

  const payload = (await response.json()) as {
    signedUrl?: string;
    url?: string;
  };
  const signedUrl = payload.signedUrl ?? payload.url;

  if (!signedUrl) {
    throw new Error('Signed URL response did not include a URL.');
  }

  return signedUrl;
}
