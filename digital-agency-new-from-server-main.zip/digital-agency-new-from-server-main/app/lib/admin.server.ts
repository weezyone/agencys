import { randomUUID } from 'node:crypto';
import { AuditLog, Prisma, WorkflowStatus } from '@prisma/client';
import { estimateSandboxCostUsd } from './analytics.server';
import { db } from './db.server';
import { checkNotBanned } from './ban-check.server';
import { kv } from './kv.server';
import { getSession } from './session.server';

const ADMIN_SECRET_HEADER = 'X-Admin-Secret';
const BAN_CACHE_TTL_SECONDS = 60 * 5;
const IMPERSONATION_TTL_SECONDS = 60 * 60;
const CLAUDE_INPUT_TOKEN_RATE_USD = 0.003 / 1000;
const CLAUDE_OUTPUT_TOKEN_RATE_USD = 0.015 / 1000;
const CODEX_INPUT_TOKEN_RATE_USD = 0.0025 / 1000;
const CODEX_OUTPUT_TOKEN_RATE_USD = 0.01 / 1000;

export interface PlatformStats {
  totalUsers: number;
  newUsersLast7Days: number;
  totalProjects: number;
  activeWorkflows: number;
  totalSandboxes: number;
  failedWorkflowsLast24h: number;
  totalAiRequests: number;
  totalSandboxCpuHours: number;
  estimatedPlatformCostUsd: number;
  errorRate: number;
}

export interface AdminUser {
  id: string;
  name: string | null;
  email: string | null;
  provider: string;
  isAdmin: boolean;
  isBanned: boolean;
  createdAt: Date;
  projectCount: number;
  workflowCount: number;
  lastActiveAt: Date | null;
}

export interface SystemHealth {
  database: 'ok' | 'error';
  kv: 'ok' | 'error';
  dbLatencyMs: number;
  kvLatencyMs: number;
  uptime: number;
}

type PlatformStatsRow = {
  totalAiRequests: unknown;
  totalSandboxCpuSeconds: unknown;
  totalAiCostUsd: unknown;
};

type AdminUserRow = {
  id: string;
  name: string | null;
  email: string | null;
  provider: string;
  isAdmin: boolean;
  isBanned: boolean;
  createdAt: Date;
  projectCount: unknown;
  workflowCount: unknown;
  lastActiveAt: Date | null;
};

type AuditLogRow = {
  id: string;
  userId: string;
  tableName: string;
  operation: string;
  oldValues: Prisma.JsonValue | null;
  newValues: Prisma.JsonValue | null;
  createdAt: Date;
};

function forbiddenResponse() {
  return Response.json(
    { error: 'forbidden', message: 'Admin access required.' },
    { status: 403 },
  );
}

function badRequestResponse(message: string) {
  return Response.json({ error: 'bad_request', message }, { status: 400 });
}

function round(value: number, digits = 4) {
  const factor = 10 ** digits;
  return Math.round(value * factor) / factor;
}

function toNumber(value: unknown) {
  if (typeof value === 'number') {
    return Number.isFinite(value) ? value : 0;
  }

  if (typeof value === 'bigint') {
    return Number(value);
  }

  if (typeof value === 'string') {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : 0;
  }

  return 0;
}

function getBanCacheKey(userId: string) {
  return `ban-status:${userId}`;
}

function getSearchClause(search?: string) {
  if (!search?.trim()) {
    return Prisma.empty;
  }

  const pattern = `%${search.trim()}%`;
  return Prisma.sql`WHERE u.name ILIKE ${pattern} OR u.email ILIKE ${pattern}`;
}

function getAuditLogWhereClause(userId?: string, action?: string) {
  const clauses: Prisma.Sql[] = [];

  if (userId?.trim()) {
    const targetUserId = userId.trim();
    clauses.push(
      Prisma.sql`(
        al.user_id = ${targetUserId}
        OR COALESCE(al.new_values->>'targetId', '') = ${targetUserId}
        OR COALESCE(al.old_values->>'targetId', '') = ${targetUserId}
      )`,
    );
  }

  if (action?.trim()) {
    clauses.push(Prisma.sql`al.operation = ${action.trim()}`);
  }

  if (clauses.length === 0) {
    return Prisma.empty;
  }

  return Prisma.sql`WHERE ${Prisma.join(clauses, ' AND ')}`;
}

function normalizeAdminUser(row: AdminUserRow): AdminUser {
  return {
    createdAt: row.createdAt,
    email: row.email,
    id: row.id,
    isAdmin: Boolean(row.isAdmin),
    isBanned: Boolean(row.isBanned),
    lastActiveAt: row.lastActiveAt,
    name: row.name,
    projectCount: toNumber(row.projectCount),
    provider: row.provider,
    workflowCount: toNumber(row.workflowCount),
  };
}

function normalizeAuditLog(row: AuditLogRow): AuditLog {
  return {
    createdAt: row.createdAt,
    id: row.id,
    newValues: row.newValues,
    oldValues: row.oldValues,
    operation: row.operation,
    tableName: row.tableName,
    userId: row.userId,
  };
}

function resolveProvider(oauthTokens: unknown, passwordHash: string | null) {
  if (passwordHash) {
    return 'email';
  }

  if (oauthTokens && typeof oauthTokens === 'object' && !Array.isArray(oauthTokens)) {
    const tokens = oauthTokens as Record<string, unknown>;
    if (tokens.github) {
      return 'github';
    }
    if (tokens.gitlab) {
      return 'gitlab';
    }
  }

  return 'unknown';
}

async function createAdminAuditLog(
  adminId: string,
  operation: 'ban_user' | 'unban_user' | 'promote_admin' | 'revoke_admin' | 'impersonate',
  targetUserId: string,
  newValues?: Prisma.InputJsonValue,
  oldValues?: Prisma.InputJsonValue,
) {
  const actor = await db.user.findUnique({
    where: { id: adminId },
    select: { id: true },
  });

  const auditUserId = actor?.id ?? targetUserId;
  const mergedOldValues = {
    ...(oldValues && typeof oldValues === 'object' && !Array.isArray(oldValues)
      ? oldValues
      : {}),
    targetId: targetUserId,
  } satisfies Record<string, unknown>;
  const mergedNewValues = {
    ...(newValues && typeof newValues === 'object' && !Array.isArray(newValues)
      ? newValues
      : {}),
    performedByAdminId: adminId,
    targetId: targetUserId,
  } satisfies Record<string, unknown>;

  await db.auditLog.create({
    data: {
      newValues: mergedNewValues,
      oldValues: mergedOldValues,
      operation,
      tableName: 'users',
      userId: auditUserId,
    },
  });
}

export async function requireAdmin(
  request: Request,
): Promise<{ userId: string; isServiceAdmin: boolean }> {
  const adminSecret = request.headers.get(ADMIN_SECRET_HEADER);
  const configuredSecret = process.env.ADMIN_SECRET;

  if (configuredSecret && adminSecret === configuredSecret) {
    const session = await getSession(request);
    return {
      isServiceAdmin: true,
      userId: session?.userId ?? 'service-admin',
    };
  }

  const session = await getSession(request);
  if (!session) {
    throw forbiddenResponse();
  }

  await checkNotBanned(session.userId);

  const user = await db.user.findUnique({
    where: { id: session.userId },
    select: { isAdmin: true },
  });

  if (!user?.isAdmin) {
    throw forbiddenResponse();
  }

  return { isServiceAdmin: false, userId: session.userId };
}

export async function getPlatformStats(): Promise<PlatformStats> {
  const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);

  const [
    totalUsers,
    newUsersLast7Days,
    totalProjects,
    activeWorkflows,
    totalSandboxes,
    failedWorkflowsLast24h,
    totalWorkflows,
    failedWorkflowsTotal,
    [analytics],
  ] = await Promise.all([
    db.user.count(),
    db.user.count({ where: { createdAt: { gte: sevenDaysAgo } } }),
    db.project.count(),
    db.workflow.count({ where: { status: WorkflowStatus.RUNNING } }),
    db.sandbox.count(),
    db.workflow.count({
      where: {
        status: WorkflowStatus.FAILED,
        updatedAt: { gte: twentyFourHoursAgo },
      },
    }),
    db.workflow.count(),
    db.workflow.count({ where: { status: WorkflowStatus.FAILED } }),
    db.$queryRaw<PlatformStatsRow[]>(Prisma.sql`
      SELECT
        COUNT(*) FILTER (WHERE event_type = 'ai.request') AS "totalAiRequests",
        COALESCE(SUM(
          CASE
            WHEN event_type = 'sandbox.terminated'
              THEN COALESCE(NULLIF(metadata->>'cpuSeconds', '')::numeric, 0)
            ELSE 0
          END
        ), 0) AS "totalSandboxCpuSeconds",
        COALESCE(SUM(
          CASE
            WHEN event_type = 'ai.request' AND LOWER(COALESCE(metadata->>'provider', '')) = 'claude'
              THEN COALESCE(NULLIF(metadata->>'promptTokens', '')::numeric, 0) * ${CLAUDE_INPUT_TOKEN_RATE_USD}
                + COALESCE(NULLIF(metadata->>'completionTokens', '')::numeric, 0) * ${CLAUDE_OUTPUT_TOKEN_RATE_USD}
            WHEN event_type = 'ai.request'
              THEN COALESCE(NULLIF(metadata->>'promptTokens', '')::numeric, 0) * ${CODEX_INPUT_TOKEN_RATE_USD}
                + COALESCE(NULLIF(metadata->>'completionTokens', '')::numeric, 0) * ${CODEX_OUTPUT_TOKEN_RATE_USD}
            ELSE 0
          END
        ), 0) AS "totalAiCostUsd"
      FROM analytics_events
    `),
  ]);

  const totalSandboxCpuSeconds = toNumber(analytics?.totalSandboxCpuSeconds);
  const totalAiCostUsd = toNumber(analytics?.totalAiCostUsd);
  const errorRate = totalWorkflows
    ? round((failedWorkflowsTotal / totalWorkflows) * 100, 2)
    : 0;

  return {
    activeWorkflows,
    errorRate,
    estimatedPlatformCostUsd: round(
      estimateSandboxCostUsd(totalSandboxCpuSeconds) + totalAiCostUsd,
    ),
    failedWorkflowsLast24h,
    newUsersLast7Days,
    totalAiRequests: toNumber(analytics?.totalAiRequests),
    totalProjects,
    totalSandboxCpuHours: round(totalSandboxCpuSeconds / 3600),
    totalSandboxes,
    totalUsers,
  };
}

export async function listUsers(options: {
  search?: string;
  limit?: number;
  offset?: number;
  sortBy?: 'createdAt' | 'projectCount' | 'lastActive';
}): Promise<{ users: AdminUser[]; total: number }> {
  const limit = Math.max(1, Math.min(options.limit ?? 20, 100));
  const offset = Math.max(0, options.offset ?? 0);
  const searchClause = getSearchClause(options.search);
  const orderBy =
    options.sortBy === 'projectCount'
      ? Prisma.sql`"projectCount" DESC, u.created_at DESC`
      : options.sortBy === 'lastActive'
        ? Prisma.sql`"lastActiveAt" DESC NULLS LAST, u.created_at DESC`
        : Prisma.sql`u.created_at DESC`;

  const [rows, totals] = await Promise.all([
    db.$queryRaw<AdminUserRow[]>(Prisma.sql`
      SELECT
        u.id,
        u.name,
        u.email,
        CASE
          WHEN u.password_hash IS NOT NULL THEN 'email'
          WHEN u.oauth_tokens ? 'github' THEN 'github'
          WHEN u.oauth_tokens ? 'gitlab' THEN 'gitlab'
          ELSE 'unknown'
        END AS provider,
        u.is_admin AS "isAdmin",
        u.is_banned AS "isBanned",
        u.created_at AS "createdAt",
        COALESCE(project_counts.project_count, 0)::int AS "projectCount",
        COALESCE(workflow_counts.workflow_count, 0)::int AS "workflowCount",
        activity.last_active_at AS "lastActiveAt"
      FROM users u
      LEFT JOIN LATERAL (
        SELECT COUNT(*) AS project_count
        FROM projects p
        WHERE p.user_id = u.id
      ) project_counts ON true
      LEFT JOIN LATERAL (
        SELECT COUNT(*) AS workflow_count
        FROM projects p
        INNER JOIN workflows w ON w.project_id = p.id
        WHERE p.user_id = u.id
      ) workflow_counts ON true
      LEFT JOIN LATERAL (
        SELECT MAX(ae.created_at) AS last_active_at
        FROM analytics_events ae
        WHERE ae.user_id = u.id
      ) activity ON true
      ${searchClause}
      ORDER BY ${orderBy}
      LIMIT ${limit}
      OFFSET ${offset}
    `),
    db.$queryRaw<Array<{ total: unknown }>>(Prisma.sql`
      SELECT COUNT(*)::int AS total
      FROM users u
      ${searchClause}
    `),
  ]);

  return {
    total: toNumber(totals[0]?.total),
    users: rows.map(normalizeAdminUser),
  };
}

export async function getUserDetails(userId: string): Promise<
  AdminUser & {
    projects: Array<{ id: string; name: string; createdAt: Date }>;
    recentAuditLogs: AuditLog[];
  }
> {
  const user = await db.user.findUnique({
    where: { id: userId },
    select: {
      createdAt: true,
      email: true,
      id: true,
      isAdmin: true,
      isBanned: true,
      name: true,
      oauthTokens: true,
      passwordHash: true,
      projects: {
        orderBy: { createdAt: 'desc' },
        select: {
          createdAt: true,
          id: true,
          name: true,
        },
      },
    },
  });

  if (!user) {
    throw Response.json({ error: 'not_found', message: 'User not found.' }, { status: 404 });
  }

  const [workflowCount, lastActive, recentAuditRows] = await Promise.all([
    db.workflow.count({ where: { project: { userId } } }),
    db.analyticsEvent.findFirst({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      select: { createdAt: true },
    }),
    db.$queryRaw<AuditLogRow[]>(Prisma.sql`
      SELECT
        al.id,
        al.user_id AS "userId",
        al.table_name AS "tableName",
        al.operation,
        al.old_values AS "oldValues",
        al.new_values AS "newValues",
        al.created_at AS "createdAt"
      FROM audit_logs al
      WHERE al.table_name = 'users'
        AND (
          COALESCE(al.new_values->>'targetId', '') = ${userId}
          OR COALESCE(al.old_values->>'targetId', '') = ${userId}
          OR al.user_id = ${userId}
        )
      ORDER BY al.created_at DESC
      LIMIT 20
    `),
  ]);

  return {
    createdAt: user.createdAt,
    email: user.email,
    id: user.id,
    isAdmin: user.isAdmin,
    isBanned: user.isBanned,
    lastActiveAt: lastActive?.createdAt ?? null,
    name: user.name,
    projectCount: user.projects.length,
    projects: user.projects,
    provider: resolveProvider(user.oauthTokens, user.passwordHash),
    recentAuditLogs: recentAuditRows.map(normalizeAuditLog),
    workflowCount,
  };
}

export async function banUser(
  userId: string,
  adminId: string,
  reason: string,
): Promise<void> {
  if (!reason.trim()) {
    throw badRequestResponse('A ban reason is required.');
  }

  if (userId === adminId) {
    throw badRequestResponse('You cannot ban your own account.');
  }

  await db.user.update({
    where: { id: userId },
    data: { isBanned: true },
  });
  await kv.set(getBanCacheKey(userId), true, { ex: BAN_CACHE_TTL_SECONDS });
  await createAdminAuditLog(adminId, 'ban_user', userId, {
    isBanned: true,
    reason: reason.trim(),
  }, {
    isBanned: false,
  });
}

export async function unbanUser(userId: string, adminId: string): Promise<void> {
  await db.user.update({
    where: { id: userId },
    data: { isBanned: false },
  });
  await kv.set(getBanCacheKey(userId), false, { ex: BAN_CACHE_TTL_SECONDS });
  await createAdminAuditLog(adminId, 'unban_user', userId, {
    isBanned: false,
  }, {
    isBanned: true,
  });
}

export async function promoteToAdmin(
  userId: string,
  adminId: string,
): Promise<void> {
  await db.user.update({
    where: { id: userId },
    data: { isAdmin: true },
  });
  await createAdminAuditLog(adminId, 'promote_admin', userId, {
    isAdmin: true,
  }, {
    isAdmin: false,
  });
}

export async function revokeAdmin(userId: string, adminId: string): Promise<void> {
  if (userId === adminId) {
    throw badRequestResponse('You cannot revoke your own admin access.');
  }

  await db.user.update({
    where: { id: userId },
    data: { isAdmin: false },
  });
  await createAdminAuditLog(adminId, 'revoke_admin', userId, {
    isAdmin: false,
  }, {
    isAdmin: true,
  });
}

export async function createImpersonationToken(
  targetUserId: string,
  adminId: string,
): Promise<string> {
  const token = randomUUID();
  const expiresAt = new Date(Date.now() + IMPERSONATION_TTL_SECONDS * 1000).toISOString();

  await kv.set(
    `impersonate:${token}`,
    { adminId, expiresAt, targetUserId },
    { ex: IMPERSONATION_TTL_SECONDS },
  );
  await createAdminAuditLog(adminId, 'impersonate', targetUserId, {
    expiresAt,
    token,
  });

  return token;
}

export async function getAuditLogs(options: {
  userId?: string;
  action?: string;
  limit?: number;
  offset?: number;
}): Promise<{ logs: AuditLog[]; total: number }> {
  const limit = Math.max(1, Math.min(options.limit ?? 50, 100));
  const offset = Math.max(0, options.offset ?? 0);
  const whereClause = getAuditLogWhereClause(options.userId, options.action);

  const [rows, totals] = await Promise.all([
    db.$queryRaw<AuditLogRow[]>(Prisma.sql`
      SELECT
        al.id,
        al.user_id AS "userId",
        al.table_name AS "tableName",
        al.operation,
        al.old_values AS "oldValues",
        al.new_values AS "newValues",
        al.created_at AS "createdAt"
      FROM audit_logs al
      ${whereClause}
      ORDER BY al.created_at DESC
      LIMIT ${limit}
      OFFSET ${offset}
    `),
    db.$queryRaw<Array<{ total: unknown }>>(Prisma.sql`
      SELECT COUNT(*)::int AS total
      FROM audit_logs al
      ${whereClause}
    `),
  ]);

  return {
    logs: rows.map(normalizeAuditLog),
    total: toNumber(totals[0]?.total),
  };
}

export async function getSystemHealth(): Promise<SystemHealth> {
  let database: 'ok' | 'error' = 'ok';
  let kvStatus: 'ok' | 'error' = 'ok';

  const dbStart = Date.now();
  try {
    await db.$queryRaw(Prisma.sql`SELECT 1`);
  } catch {
    database = 'error';
  }
  const dbLatencyMs = Date.now() - dbStart;

  const kvStart = Date.now();
  const healthKey = `healthcheck:${randomUUID()}`;
  try {
    await kv.set(healthKey, { ok: true }, { ex: 60 });
    await kv.get(healthKey);
    await kv.del(healthKey);
  } catch {
    kvStatus = 'error';
  }
  const kvLatencyMs = Date.now() - kvStart;

  return {
    database,
    dbLatencyMs,
    kv: kvStatus,
    kvLatencyMs,
    uptime: process.uptime(),
  };
}
