import { Socket } from 'node:net';

const DEFAULT_POSTGRES_PORT = 5432;
const LOCAL_DATABASE_HOSTS = new Set(['localhost', '127.0.0.1', '::1', '[::1]']);
const LOCAL_DATABASE_CHECK_TIMEOUT_MS = 250;
const LOCAL_DATABASE_CACHE_TTL_MS = 2_000;

let localDatabaseAvailabilityCache:
  | { checkedAt: number; databaseUrl: string; reachable: boolean }
  | undefined;

function getConfiguredLocalDatabaseEndpoint(databaseUrl: string | undefined) {
  if (!databaseUrl) {
    return null;
  }

  try {
    const url = new URL(databaseUrl);
    if (!url.protocol.startsWith('postgres') || !LOCAL_DATABASE_HOSTS.has(url.hostname)) {
      return null;
    }

    const port = url.port ? Number(url.port) : DEFAULT_POSTGRES_PORT;
    if (!Number.isInteger(port) || port < 1 || port > 65_535) {
      return null;
    }

    return { host: url.hostname, port };
  } catch {
    return null;
  }
}

function canConnectToLocalDatabase(host: string, port: number) {
  return new Promise<boolean>((resolve) => {
    const socket = new Socket();
    let settled = false;

    const settle = (reachable: boolean) => {
      if (settled) {
        return;
      }
      settled = true;
      socket.removeAllListeners();
      socket.destroy();
      resolve(reachable);
    };

    socket.unref();
    socket.setTimeout(LOCAL_DATABASE_CHECK_TIMEOUT_MS);
    socket.once('connect', () => settle(true));
    socket.once('error', () => settle(false));
    socket.once('timeout', () => settle(false));
    socket.connect(port, host);
  });
}

export async function isConfiguredLocalDatabaseReachable(
  databaseUrl = process.env.DATABASE_URL,
) {
  const endpoint = getConfiguredLocalDatabaseEndpoint(databaseUrl);
  if (!databaseUrl || !endpoint) {
    return true;
  }

  const now = Date.now();
  if (
    localDatabaseAvailabilityCache?.databaseUrl === databaseUrl &&
    now - localDatabaseAvailabilityCache.checkedAt < LOCAL_DATABASE_CACHE_TTL_MS
  ) {
    return localDatabaseAvailabilityCache.reachable;
  }

  const reachable = await canConnectToLocalDatabase(endpoint.host, endpoint.port);
  localDatabaseAvailabilityCache = { checkedAt: now, databaseUrl, reachable };
  return reachable;
}