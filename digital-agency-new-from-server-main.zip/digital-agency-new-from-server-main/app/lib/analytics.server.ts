import { Prisma } from '@prisma/client';
import { db } from './db.server';
import kv from './kv.server';

export interface OverviewMetrics {
  totalWorkflows: number;
  successfulWorkflows: number;
  failedWorkflows: number;
  successRate: number;
  totalSandboxHours: number;
  totalAiTokens: number;
  estimatedCostUsd: number;
  activeProjectsCount: number;
  totalArtifacts: number;
}

export interface TimeSeriesPoint {
  date: string;
  value: number;
}

export interface AiUsageSummary {
  estimatedCostUsd: number;
  totalTokens: number;
}

const DAILY_COUNTER_TTL_SECONDS = 60 * 60 * 24 * 7;
const SANDBOX_CPU_SECOND_RATE_USD = 0.000024;
const CLAUDE_INPUT_TOKEN_RATE_USD = 0.003 / 1000;
const CLAUDE_OUTPUT_TOKEN_RATE_USD = 0.015 / 1000;
const CODEX_INPUT_TOKEN_RATE_USD = 0.0025 / 1000;
const CODEX_OUTPUT_TOKEN_RATE_USD = 0.01 / 1000;

function toSerializableMetadata(metadata?: Record<string, unknown>) {
  return JSON.parse(
    JSON.stringify(metadata ?? {}, (_key, value) => {
      if (typeof value === 'bigint') {
        return value.toString();
      }

      if (value instanceof Date) {
        return value.toISOString();
      }

      return value;
    }),
  ) as Record<string, unknown>;
}

function toNumber(value: unknown) {
  if (typeof value === 'number') {
    return Number.isFinite(value) ? value : 0;
  }

  if (typeof value === 'bigint') {
    return Number(value);
  }

  if (typeof value === 'string') {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : 0;
  }

  if (value && typeof value === 'object' && 'toString' in value) {
    const parsed = Number(String(value));
    return Number.isFinite(parsed) ? parsed : 0;
  }

  return 0;
}

function roundCurrency(value: number) {
  return Math.round(value * 10000) / 10000;
}

function toUtcDateString(value: Date) {
  return value.toISOString().slice(0, 10);
}

function getRangeStart(days: number) {
  const start = new Date();
  start.setUTCHours(0, 0, 0, 0);
  start.setUTCDate(start.getUTCDate() - Math.max(days - 1, 0));
  return start;
}

function buildDateSeries(days: number) {
  const start = getRangeStart(days);

  return Array.from({ length: days }, (_value, index) => {
    const current = new Date(start);
    current.setUTCDate(start.getUTCDate() + index);
    return toUtcDateString(current);
  });
}

function fillSeries(days: number, rows: Array<{ date: string; value: number }>) {
  const values = new Map(rows.map((row) => [row.date, row.value]));

  return buildDateSeries(days).map((date) => ({
    date,
    value: values.get(date) ?? 0,
  }));
}

function estimateAiCostUsd(provider: string, promptTokens: number, completionTokens: number) {
  const normalizedProvider = provider.trim().toLowerCase();
  const isClaude = normalizedProvider === 'claude';

  return (
    promptTokens * (isClaude ? CLAUDE_INPUT_TOKEN_RATE_USD : CODEX_INPUT_TOKEN_RATE_USD) +
    completionTokens * (isClaude ? CLAUDE_OUTPUT_TOKEN_RATE_USD : CODEX_OUTPUT_TOKEN_RATE_USD)
  );
}

async function recordRealtimeCounters(
  eventType: string,
  metadata: Record<string, unknown>,
) {
  const date = toUtcDateString(new Date());

  await incrementCounter(`analytics:events:${date}`);

  if (eventType === 'workflow.started') {
    await incrementCounter(`daily_workflows:${date}`);
  }

  if (eventType === 'ai.request') {
    const totalTokens =
      toNumber(metadata.promptTokens) + toNumber(metadata.completionTokens);
    if (totalTokens > 0) {
      await incrementCounter(`daily_ai_tokens:${date}`, totalTokens);
    }
  }

  if (eventType === 'sandbox.terminated') {
    const cpuSeconds = toNumber(metadata.cpuSeconds);
    if (cpuSeconds > 0) {
      await incrementCounter(`daily_sandbox_cpu_seconds:${date}`, cpuSeconds);
    }
  }
}

export async function incrementCounter(key: string, amount = 1): Promise<void> {
  const nextAmount = Number.isFinite(amount) ? amount : 0;
  if (nextAmount === 0) {
    return;
  }

  const currentValue = await kv.get<number>(key);
  await kv.set(key, toNumber(currentValue) + nextAmount, {
    ex: DAILY_COUNTER_TTL_SECONDS,
  });
}

export async function getCounter(key: string): Promise<number> {
  return toNumber(await kv.get<number>(key));
}

export async function trackEvent(
  userId: string,
  eventType: string,
  metadata?: Record<string, unknown>,
  projectId?: string,
): Promise<void> {
  try {
    if (!userId || !eventType) {
      return;
    }

    const payload = toSerializableMetadata(metadata);
    const resolvedProjectId =
      projectId ??
      (typeof payload.projectId === 'string' && payload.projectId.trim()
        ? payload.projectId.trim()
        : null);

    await db.$executeRaw(Prisma.sql`
      INSERT INTO analytics_events (user_id, project_id, event_type, metadata)
      VALUES (
        ${userId},
        ${resolvedProjectId},
        ${eventType},
        ${JSON.stringify(payload)}::jsonb
      )
    `);

    try {
      await recordRealtimeCounters(eventType, payload);
    } catch {
      // Ignore counter failures.
    }
  } catch {
    // Analytics are best-effort only.
  }
}

type OverviewRow = {
  active_projects_count: unknown;
  failed_workflows: unknown;
  successful_workflows: unknown;
  total_ai_cost_usd: unknown;
  total_ai_tokens: unknown;
  total_artifacts: unknown;
  total_sandbox_cpu_seconds: unknown;
  total_workflows: unknown;
};

export async function getOverviewMetrics(
  userId: string,
  days: number,
): Promise<OverviewMetrics> {
  const since = getRangeStart(days);
  const [row] = await db.$queryRaw<OverviewRow[]>(Prisma.sql`
    SELECT
      COUNT(*) FILTER (WHERE event_type = 'workflow.started') AS total_workflows,
      COUNT(*) FILTER (WHERE event_type = 'workflow.completed') AS successful_workflows,
      COUNT(*) FILTER (WHERE event_type = 'workflow.failed') AS failed_workflows,
      COALESCE(SUM(
        CASE
          WHEN event_type = 'sandbox.terminated'
            THEN COALESCE(NULLIF(metadata->>'cpuSeconds', '')::numeric, 0)
          ELSE 0
        END
      ), 0) AS total_sandbox_cpu_seconds,
      COALESCE(SUM(
        CASE
          WHEN event_type = 'ai.request'
            THEN COALESCE(NULLIF(metadata->>'promptTokens', '')::numeric, 0)
              + COALESCE(NULLIF(metadata->>'completionTokens', '')::numeric, 0)
          ELSE 0
        END
      ), 0) AS total_ai_tokens,
      COALESCE(SUM(
        CASE
          WHEN event_type = 'ai.request' AND LOWER(COALESCE(metadata->>'provider', '')) = 'claude'
            THEN COALESCE(NULLIF(metadata->>'promptTokens', '')::numeric, 0) * ${CLAUDE_INPUT_TOKEN_RATE_USD}
              + COALESCE(NULLIF(metadata->>'completionTokens', '')::numeric, 0) * ${CLAUDE_OUTPUT_TOKEN_RATE_USD}
          WHEN event_type = 'ai.request'
            THEN COALESCE(NULLIF(metadata->>'promptTokens', '')::numeric, 0) * ${CODEX_INPUT_TOKEN_RATE_USD}
              + COALESCE(NULLIF(metadata->>'completionTokens', '')::numeric, 0) * ${CODEX_OUTPUT_TOKEN_RATE_USD}
          ELSE 0
        END
      ), 0) AS total_ai_cost_usd,
      COUNT(DISTINCT project_id) FILTER (WHERE project_id IS NOT NULL) AS active_projects_count,
      COUNT(*) FILTER (WHERE event_type = 'artifact.created') AS total_artifacts
    FROM analytics_events
    WHERE user_id = ${userId}
      AND created_at >= ${since}
  `);

  const totalWorkflows = toNumber(row?.total_workflows);
  const successfulWorkflows = toNumber(row?.successful_workflows);
  const failedWorkflows = toNumber(row?.failed_workflows);
  const totalSandboxCpuSeconds = toNumber(row?.total_sandbox_cpu_seconds);
  const totalSandboxHours = totalSandboxCpuSeconds / 3600;
  const estimatedCostUsd =
    totalSandboxCpuSeconds * SANDBOX_CPU_SECOND_RATE_USD +
    toNumber(row?.total_ai_cost_usd);

  return {
    activeProjectsCount: toNumber(row?.active_projects_count),
    estimatedCostUsd: roundCurrency(estimatedCostUsd),
    failedWorkflows,
    successRate:
      totalWorkflows > 0 ? (successfulWorkflows / totalWorkflows) * 100 : 0,
    successfulWorkflows,
    totalAiTokens: toNumber(row?.total_ai_tokens),
    totalArtifacts: toNumber(row?.total_artifacts),
    totalSandboxHours,
    totalWorkflows,
  };
}

type WorkflowSeriesRow = {
  date: string;
  failed: unknown;
  successful: unknown;
  total: unknown;
};

export async function getWorkflowTimeSeries(userId: string, days: number) {
  const since = getRangeStart(days);
  const rows = await db.$queryRaw<WorkflowSeriesRow[]>(Prisma.sql`
    SELECT
      TO_CHAR(DATE_TRUNC('day', created_at AT TIME ZONE 'UTC'), 'YYYY-MM-DD') AS date,
      COUNT(*) FILTER (WHERE event_type = 'workflow.started') AS total,
      COUNT(*) FILTER (WHERE event_type = 'workflow.completed') AS successful,
      COUNT(*) FILTER (WHERE event_type = 'workflow.failed') AS failed
    FROM analytics_events
    WHERE user_id = ${userId}
      AND created_at >= ${since}
      AND event_type IN ('workflow.started', 'workflow.completed', 'workflow.failed')
    GROUP BY 1
    ORDER BY 1 ASC
  `);

  return {
    failed: fillSeries(
      days,
      rows.map((row) => ({ date: row.date, value: toNumber(row.failed) })),
    ),
    successful: fillSeries(
      days,
      rows.map((row) => ({ date: row.date, value: toNumber(row.successful) })),
    ),
    total: fillSeries(
      days,
      rows.map((row) => ({ date: row.date, value: toNumber(row.total) })),
    ),
  };
}

type AiSeriesRow = {
  claude: unknown;
  codex: unknown;
  date: string;
};

type AiUsageSummaryRow = {
  estimated_cost_usd: unknown;
  total_tokens: unknown;
};

export async function getAiUsageSummary(
  userId: string,
  days: number,
): Promise<AiUsageSummary> {
  const since = getRangeStart(days);
  const [row] = await db.$queryRaw<AiUsageSummaryRow[]>(Prisma.sql`
    SELECT
      COALESCE(SUM(
        CASE
          WHEN event_type = 'ai.request'
            THEN COALESCE(NULLIF(metadata->>'promptTokens', '')::numeric, 0)
              + COALESCE(NULLIF(metadata->>'completionTokens', '')::numeric, 0)
          ELSE 0
        END
      ), 0) AS total_tokens,
      COALESCE(SUM(
        CASE
          WHEN event_type = 'ai.request' AND LOWER(COALESCE(metadata->>'provider', '')) = 'claude'
            THEN COALESCE(NULLIF(metadata->>'promptTokens', '')::numeric, 0) * ${CLAUDE_INPUT_TOKEN_RATE_USD}
              + COALESCE(NULLIF(metadata->>'completionTokens', '')::numeric, 0) * ${CLAUDE_OUTPUT_TOKEN_RATE_USD}
          WHEN event_type = 'ai.request'
            THEN COALESCE(NULLIF(metadata->>'promptTokens', '')::numeric, 0) * ${CODEX_INPUT_TOKEN_RATE_USD}
              + COALESCE(NULLIF(metadata->>'completionTokens', '')::numeric, 0) * ${CODEX_OUTPUT_TOKEN_RATE_USD}
          ELSE 0
        END
      ), 0) AS estimated_cost_usd
    FROM analytics_events
    WHERE user_id = ${userId}
      AND created_at >= ${since}
      AND event_type = 'ai.request'
  `);

  return {
    estimatedCostUsd: roundCurrency(toNumber(row?.estimated_cost_usd)),
    totalTokens: toNumber(row?.total_tokens),
  };
}

export async function getAiUsageTimeSeries(userId: string, days: number) {
  const since = getRangeStart(days);
  const rows = await db.$queryRaw<AiSeriesRow[]>(Prisma.sql`
    SELECT
      TO_CHAR(DATE_TRUNC('day', created_at AT TIME ZONE 'UTC'), 'YYYY-MM-DD') AS date,
      COALESCE(SUM(
        CASE
          WHEN event_type = 'ai.request' AND LOWER(COALESCE(metadata->>'provider', '')) = 'claude'
            THEN COALESCE(NULLIF(metadata->>'promptTokens', '')::numeric, 0)
              + COALESCE(NULLIF(metadata->>'completionTokens', '')::numeric, 0)
          ELSE 0
        END
      ), 0) AS claude,
      COALESCE(SUM(
        CASE
          WHEN event_type = 'ai.request' AND LOWER(COALESCE(metadata->>'provider', '')) = 'codex'
            THEN COALESCE(NULLIF(metadata->>'promptTokens', '')::numeric, 0)
              + COALESCE(NULLIF(metadata->>'completionTokens', '')::numeric, 0)
          ELSE 0
        END
      ), 0) AS codex
    FROM analytics_events
    WHERE user_id = ${userId}
      AND created_at >= ${since}
      AND event_type = 'ai.request'
    GROUP BY 1
    ORDER BY 1 ASC
  `);

  return {
    claude: fillSeries(
      days,
      rows.map((row) => ({ date: row.date, value: toNumber(row.claude) })),
    ),
    codex: fillSeries(
      days,
      rows.map((row) => ({ date: row.date, value: toNumber(row.codex) })),
    ),
  };
}

type SandboxSeriesRow = {
  date: string;
  hours: unknown;
};

export async function getSandboxUtilization(userId: string, days: number) {
  const since = getRangeStart(days);
  const rows = await db.$queryRaw<SandboxSeriesRow[]>(Prisma.sql`
    SELECT
      TO_CHAR(DATE_TRUNC('day', created_at AT TIME ZONE 'UTC'), 'YYYY-MM-DD') AS date,
      COALESCE(SUM(
        CASE
          WHEN event_type = 'sandbox.terminated'
            THEN COALESCE(NULLIF(metadata->>'cpuSeconds', '')::numeric, 0) / 3600
          ELSE 0
        END
      ), 0) AS hours
    FROM analytics_events
    WHERE user_id = ${userId}
      AND created_at >= ${since}
      AND event_type = 'sandbox.terminated'
    GROUP BY 1
    ORDER BY 1 ASC
  `);

  return fillSeries(
    days,
    rows.map((row) => ({ date: row.date, value: toNumber(row.hours) })),
  );
}

type TopProjectRow = {
  eventCount: unknown;
  projectId: string;
  sandboxHours: unknown;
  workflowCount: unknown;
};

export async function getTopProjects(
  userId: string,
  days: number,
  limit = 5,
): Promise<
  Array<{
    projectId: string;
    eventCount: number;
    workflowCount: number;
    sandboxHours: number;
  }>
> {
  const since = getRangeStart(days);
  const rows = await db.$queryRaw<TopProjectRow[]>(Prisma.sql`
    SELECT
      project_id AS "projectId",
      COUNT(*) AS "eventCount",
      COUNT(*) FILTER (WHERE event_type = 'workflow.started') AS "workflowCount",
      COALESCE(SUM(
        CASE
          WHEN event_type = 'sandbox.terminated'
            THEN COALESCE(NULLIF(metadata->>'cpuSeconds', '')::numeric, 0) / 3600
          ELSE 0
        END
      ), 0) AS "sandboxHours"
    FROM analytics_events
    WHERE user_id = ${userId}
      AND created_at >= ${since}
      AND project_id IS NOT NULL
    GROUP BY project_id
    ORDER BY COUNT(*) DESC, project_id ASC
    LIMIT ${limit}
  `);

  return rows
    .map((row) => ({
      eventCount: toNumber(row.eventCount),
      projectId: row.projectId,
      sandboxHours: toNumber(row.sandboxHours),
      workflowCount: toNumber(row.workflowCount),
    }))
    .sort((left, right) => right.eventCount - left.eventCount);
}

type RecentErrorRow = {
  durationSeconds: unknown;
  failedStep: string | null;
  occurredAt: Date;
  projectId: string | null;
};

export async function getRecentErrors(userId: string, limit = 10) {
  const rows = await db.$queryRaw<RecentErrorRow[]>(Prisma.sql`
    SELECT
      project_id AS "projectId",
      metadata->>'failedStep' AS "failedStep",
      COALESCE(NULLIF(metadata->>'durationSeconds', '')::numeric, 0) AS "durationSeconds",
      created_at AS "occurredAt"
    FROM analytics_events
    WHERE user_id = ${userId}
      AND event_type = 'workflow.failed'
    ORDER BY created_at DESC
    LIMIT ${limit}
  `);

  return rows.map((row) => ({
    durationSeconds: toNumber(row.durationSeconds),
    failedStep: row.failedStep,
    occurredAt: new Date(row.occurredAt),
    projectId: row.projectId,
  }));
}

function csvEscape(value: string | number) {
  const stringValue = String(value);
  if (!/[",\n]/.test(stringValue)) {
    return stringValue;
  }

  return `"${stringValue.replace(/"/g, '""')}"`;
}

export function exportMetricsCsv(
  metrics: OverviewMetrics,
  timeSeries: TimeSeriesPoint[],
): string {
  const metricRows = [
    ['metric', 'value'],
    ['totalWorkflows', metrics.totalWorkflows],
    ['successfulWorkflows', metrics.successfulWorkflows],
    ['failedWorkflows', metrics.failedWorkflows],
    ['successRate', metrics.successRate],
    ['totalSandboxHours', metrics.totalSandboxHours],
    ['totalAiTokens', metrics.totalAiTokens],
    ['estimatedCostUsd', metrics.estimatedCostUsd],
    ['activeProjectsCount', metrics.activeProjectsCount],
    ['totalArtifacts', metrics.totalArtifacts],
  ];
  const seriesRows = [
    ['date', 'value'],
    ...timeSeries.map((point) => [point.date, point.value]),
  ];

  return [...metricRows, [], seriesRows[0], ...seriesRows.slice(1)]
    .map((row) => row.map((cell) => csvEscape(cell)).join(','))
    .join('\n');
}

export function estimateSandboxCostUsd(cpuSeconds: number) {
  return roundCurrency(cpuSeconds * SANDBOX_CPU_SECOND_RATE_USD);
}

export function estimateAiRequestCostUsd(
  provider: string,
  promptTokens: number,
  completionTokens: number,
) {
  return roundCurrency(
    estimateAiCostUsd(provider, promptTokens, completionTokens),
  );
}
