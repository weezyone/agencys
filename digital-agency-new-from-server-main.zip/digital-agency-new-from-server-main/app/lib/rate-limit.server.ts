import kv from './kv.server';

interface RateLimitState {
  count: number;
  resetAt: number;
}

export async function checkRateLimit(
  key: string,
  limit: number,
  windowSeconds: number,
): Promise<{ allowed: boolean; remaining: number; resetAt: Date }> {
  const now = Date.now();
  const existing = await kv.get<RateLimitState>(key);

  if (!existing || existing.resetAt <= now) {
    const resetAt = new Date(now + windowSeconds * 1000);
    await kv.set<RateLimitState>(key, { count: 1, resetAt: resetAt.getTime() });
    return {
      allowed: true,
      remaining: Math.max(limit - 1, 0),
      resetAt,
    };
  }

  if (existing.count >= limit) {
    return {
      allowed: false,
      remaining: 0,
      resetAt: new Date(existing.resetAt),
    };
  }

  const nextCount = existing.count + 1;
  await kv.set<RateLimitState>(key, { ...existing, count: nextCount });

  return {
    allowed: true,
    remaining: Math.max(limit - nextCount, 0),
    resetAt: new Date(existing.resetAt),
  };
}

export function getBackoffDelay(attempt: number, baseMs = 1000): number {
  return baseMs * 2 ** Math.max(attempt, 0);
}
