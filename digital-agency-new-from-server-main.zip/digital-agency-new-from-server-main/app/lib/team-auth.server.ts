import { db } from './db.server';
import { requireAuth, type SessionData } from './session.server';
import { TeamRole } from './team-roles';

const ROLE_RANK: Record<TeamRole, number> = {
  OWNER: 3,
  COLLABORATOR: 2,
  VIEWER: 1,
};

function hasRequiredRole(role: TeamRole, minRole: TeamRole) {
  return ROLE_RANK[role] >= ROLE_RANK[minRole];
}

export async function requireTeamRole(
  request: Request,
  teamId: string,
  minRole: 'OWNER' | 'COLLABORATOR' | 'VIEWER',
): Promise<{ user: SessionData; role: TeamRole }> {
  let user: SessionData;

  try {
    user = await requireAuth(request);
  } catch {
    throw Response.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const membership = await db.teamMember.findUnique({
    where: { teamId_userId: { teamId, userId: user.userId } },
  });

  if (!membership || !hasRequiredRole(membership.role, TeamRole[minRole])) {
    throw Response.json({ error: 'Forbidden' }, { status: 403 });
  }

  return { role: membership.role, user };
}

export function getPermissions(role: TeamRole) {
  return {
    canDelete: role === TeamRole.OWNER,
    canEdit: role === TeamRole.OWNER || role === TeamRole.COLLABORATOR,
    canInvite: role === TeamRole.OWNER || role === TeamRole.COLLABORATOR,
    canManageRoles: role === TeamRole.OWNER,
  };
}
