import { AsyncLocalStorage } from 'node:async_hooks';
import crypto from 'node:crypto';

const requestHeadersStore = new AsyncLocalStorage<Headers>();
const githubScopes = ['repo', 'user:email'];
const gitlabScopes = ['api', 'read_user'];

interface GitHubTokenResponse {
  access_token: string;
  token_type: string;
  scope: string;
  error?: string;
  error_description?: string;
}

interface GitLabTokenResponse {
  access_token: string;
  token_type: string;
  scope: string;
  expires_in?: number;
  error?: string;
  error_description?: string;
}

export function runWithRequestHeaders<T>(
  headers: Headers,
  callback: () => T,
): T {
  return requestHeadersStore.run(headers, callback);
}

export function getBaseUrl() {
  if (process.env.APP_URL) {
    return process.env.APP_URL;
  }

  if (process.env.VERCEL_URL) {
    return `https://${process.env.VERCEL_URL}`;
  }

  return 'http://localhost:3000';
}

function getGitHubCallbackUrl() {
  return `${getBaseUrl()}/auth/callback?provider=github`;
}

function getGitLabCallbackUrl() {
  return `${getBaseUrl()}/auth/callback?provider=gitlab`;
}

async function readJson<T>(response: Response): Promise<T> {
  const payload = (await response.json()) as T;
  if (!response.ok) {
    throw new Error(`OAuth request failed with status ${response.status}`);
  }

  return payload;
}

export function generateCodeVerifier(): string {
  return crypto.randomBytes(64).toString('base64url');
}

export function generateCodeChallenge(verifier: string): string {
  return crypto.createHash('sha256').update(verifier).digest('base64url');
}

export function generateState(): string {
  return crypto.randomBytes(32).toString('base64url');
}

export function getGitHubAuthUrl(state: string, codeVerifier: string): string {
  const params = new URLSearchParams({
    client_id: process.env.GITHUB_CLIENT_ID ?? '',
    redirect_uri: getGitHubCallbackUrl(),
    scope: githubScopes.join(' '),
    state,
    code_challenge: generateCodeChallenge(codeVerifier),
    code_challenge_method: 'S256',
  });

  return `https://github.com/login/oauth/authorize?${params.toString()}`;
}

export async function exchangeGitHubCode(
  code: string,
  codeVerifier: string,
): Promise<{
  accessToken: string;
  tokenType: string;
  scope: string;
}> {
  const body = new URLSearchParams({
    client_id: process.env.GITHUB_CLIENT_ID ?? '',
    code,
    code_verifier: codeVerifier,
    redirect_uri: getGitHubCallbackUrl(),
  });

  if (process.env.GITHUB_CLIENT_SECRET) {
    body.set('client_secret', process.env.GITHUB_CLIENT_SECRET);
  }

  const response = await fetch('https://github.com/login/oauth/access_token', {
    method: 'POST',
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body,
  });

  const payload = await readJson<GitHubTokenResponse>(response);
  if (payload.error) {
    throw new Error(payload.error_description ?? payload.error);
  }

  return {
    accessToken: payload.access_token,
    tokenType: payload.token_type,
    scope: payload.scope,
  };
}

export async function getGitHubUser(accessToken: string): Promise<{
  id: number;
  email: string;
  name: string;
  avatar_url: string;
  login: string;
}> {
  const response = await fetch('https://api.github.com/user', {
    headers: {
      Accept: 'application/vnd.github+json',
      Authorization: `Bearer ${accessToken}`,
      'User-Agent': 'cloud-first-ai-development-platform',
    },
  });

  const user = await readJson<{
    id: number;
    email: string | null;
    name: string | null;
    avatar_url: string;
    login: string;
  }>(response);

  let email = user.email;
  if (!email) {
    const emailResponse = await fetch('https://api.github.com/user/emails', {
      headers: {
        Accept: 'application/vnd.github+json',
        Authorization: `Bearer ${accessToken}`,
        'User-Agent': 'cloud-first-ai-development-platform',
      },
    });

    if (emailResponse.ok) {
      const emails = (await emailResponse.json()) as Array<{
        email: string;
        primary: boolean;
        verified: boolean;
      }>;
      email =
        emails.find((item) => item.primary && item.verified)?.email ??
        emails.find((item) => item.verified)?.email ??
        emails[0]?.email ??
        null;
    }
  }

  return {
    id: user.id,
    email: email ?? `${user.login}@users.noreply.github.com`,
    name: user.name ?? user.login,
    avatar_url: user.avatar_url,
    login: user.login,
  };
}

export function getGitLabAuthUrl(state: string, codeVerifier: string): string {
  const params = new URLSearchParams({
    client_id: process.env.GITLAB_CLIENT_ID ?? '',
    redirect_uri: getGitLabCallbackUrl(),
    response_type: 'code',
    scope: gitlabScopes.join(' '),
    state,
    code_challenge: generateCodeChallenge(codeVerifier),
    code_challenge_method: 'S256',
  });

  return `https://gitlab.com/oauth/authorize?${params.toString()}`;
}

export async function exchangeGitLabCode(
  code: string,
  codeVerifier: string,
): Promise<{
  accessToken: string;
  tokenType: string;
  scope: string;
  expiresIn?: number;
}> {
  const body = new URLSearchParams({
    client_id: process.env.GITLAB_CLIENT_ID ?? '',
    code,
    code_verifier: codeVerifier,
    grant_type: 'authorization_code',
    redirect_uri: getGitLabCallbackUrl(),
  });

  if (process.env.GITLAB_CLIENT_SECRET) {
    body.set('client_secret', process.env.GITLAB_CLIENT_SECRET);
  }

  const response = await fetch('https://gitlab.com/oauth/token', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body,
  });

  const payload = await readJson<GitLabTokenResponse>(response);
  if (payload.error) {
    throw new Error(payload.error_description ?? payload.error);
  }

  return {
    accessToken: payload.access_token,
    tokenType: payload.token_type,
    scope: payload.scope,
    expiresIn: payload.expires_in,
  };
}

export async function getGitLabUser(accessToken: string): Promise<{
  id: number;
  email: string;
  name: string;
  avatar_url: string;
  username: string;
}> {
  const response = await fetch('https://gitlab.com/api/v4/user', {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  const user = await readJson<{
    id: number;
    email?: string;
    name?: string;
    avatar_url?: string;
    username: string;
  }>(response);

  return {
    id: user.id,
    email: user.email ?? `${user.username}@users.noreply.gitlab.com`,
    name: user.name ?? user.username,
    avatar_url: user.avatar_url ?? '',
    username: user.username,
  };
}

export function getVercelOidcToken(): string | undefined {
  return (
    requestHeadersStore.getStore()?.get('x-vercel-oidc-token') ??
    process.env.VERCEL_OIDC_TOKEN ??
    process.env.OVERRIDE_VERCEL_OIDC_TOKEN
  );
}
