import { WorkflowStatus, StepStatus } from '@prisma/client';
import {
  defineWorkflow,
  executeWorkflow,
  type WorkflowContext,
  type WorkflowDefinition,
} from '@vercel/workflow';
import { trackEvent } from './analytics.server';
import { createZipArchive, type FileEntry } from './archive.server';
import {
  executeAgentInSandbox,
  generateAIResponse,
  type AIProvider,
} from './ai.server';
import { generateSignedUrl, uploadFile } from './blob.server';
import { db } from './db.server';
import {
  createArtifact,
  createWorkflowStep,
  updateStepStatus,
  updateWorkflowStatus,
} from './data.server';
import kv from './kv.server';
import {
  notifyWorkflowComplete,
  notifyWorkflowFailed,
} from './notifications.server';
import {
  createSandbox,
  executeSandboxCommand,
  terminateSandbox,
  writeSandboxFile,
  type SandboxConfig,
  type SandboxResult,
} from './sandbox.server';

const WORKFLOW_TTL_SECONDS = 60 * 60;
const WORKSPACE_DIR = '/vercel/sandbox/workspace';

type JsonRecord = Record<string, unknown>;

export interface WorkflowEvent {
  type:
    | 'step_started'
    | 'step_completed'
    | 'step_failed'
    | 'workflow_completed'
    | 'workflow_failed'
    | 'log';
  stepName?: string;
  data?: unknown;
  message?: string;
  timestamp: number;
}

export interface CloudTaskWorkflowInput {
  workflowId: string;
  projectId: string;
  userId: string;
  task: string;
  provider: AIProvider;
  sandboxConfig?: SandboxConfig;
  repositoryUrl?: string;
  branch?: string;
  contextFiles?: Array<{ path: string; content: string }>;
}

export interface GitCommitWorkflowInput {
  workflowId: string;
  projectId: string;
  userId: string;
  files: Array<{ path: string; content: string }>;
  commitMessage: string;
  sandboxConfig?: SandboxConfig;
  repositoryUrl?: string;
  branch?: string;
}

class WorkflowCancelledError extends Error {
  constructor(workflowId: string) {
    super(`Workflow ${workflowId} has been cancelled.`);
    this.name = 'WorkflowCancelledError';
  }
}

function workflowEventsKey(workflowId: string) {
  return `workflow:${workflowId}:events`;
}

function workflowCancelKey(workflowId: string) {
  return `workflow:${workflowId}:cancelled`;
}

function workflowStateKey(workflowId: string) {
  return `workflow:${workflowId}:state`;
}

function serializeError(error: unknown): JsonRecord {
  if (error instanceof Error) {
    return {
      message: error.message,
      name: error.name,
      ...(error.stack ? { stack: error.stack } : {}),
    };
  }

  return {
    message: typeof error === 'string' ? error : 'Unknown workflow error',
  };
}

function toJsonRecord(value: unknown): JsonRecord | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (value && typeof value === 'object' && !Array.isArray(value)) {
    return value as JsonRecord;
  }

  return { result: value };
}

function normalizeWorkflowStatus(
  status: WorkflowStatus,
): 'initializing' | 'running' | 'suspended' | 'completed' | 'failed' {
  switch (status) {
    case WorkflowStatus.COMPLETED:
      return 'completed';
    case WorkflowStatus.FAILED:
    case WorkflowStatus.EXPIRED:
      return 'failed';
    case WorkflowStatus.SUSPENDED:
      return 'suspended';
    case WorkflowStatus.RUNNING:
      return 'running';
    case WorkflowStatus.INITIALIZING:
    default:
      return 'initializing';
  }
}

function escapeShellArg(value: string) {
  return `'${value.replace(/'/g, `'\\''`)}'`;
}

function getDurationSeconds(startedAt: unknown) {
  if (typeof startedAt !== 'string' && !(startedAt instanceof Date)) {
    return 0;
  }

  const startTime = new Date(startedAt).getTime();
  if (Number.isNaN(startTime)) {
    return 0;
  }

  return Math.max(0, Math.round((Date.now() - startTime) / 1000));
}

function getStepCount(state: JsonRecord) {
  return typeof state.completedStepCount === 'number'
    ? state.completedStepCount
    : 0;
}

function toProjectId(state: JsonRecord) {
  return typeof state.projectId === 'string' ? state.projectId : undefined;
}

function toFailedStep(state: JsonRecord) {
  return typeof state.failedStep === 'string' ? state.failedStep : null;
}

function toSandboxTerminationMetrics(sandbox: SandboxResult) {
  const durationSeconds = Math.max(
    0,
    Math.round((Date.now() - sandbox.createdAt.getTime()) / 1000),
  );
  const vcpus = Math.max(1, sandbox.configuration.vcpus ?? 1);

  return {
    cpuSeconds: durationSeconds * vcpus,
    durationSeconds,
  };
}

async function getProjectName(projectId: string) {
  const project = await db.project.findUnique({
    select: { name: true },
    where: { id: projectId },
  });
  return project?.name ?? projectId;
}

function queueWorkflowCompleteNotification(
  userId: string,
  workflowId: string,
  projectId: string,
) {
  void (async () => {
    const projectName = await getProjectName(projectId);
    await notifyWorkflowComplete(userId, workflowId, projectName);
  })().catch(() => undefined);
}

function queueWorkflowFailedNotification(
  userId: string,
  workflowId: string,
  projectId: string,
  failedStep: string,
) {
  void (async () => {
    const projectName = await getProjectName(projectId);
    await notifyWorkflowFailed(userId, workflowId, projectName, failedStep);
  })().catch(() => undefined);
}

function toWorkspacePath(filePath: string) {
  const normalized = filePath.replace(/\\/g, '/').replace(/^\/+/, '');
  const safePath = normalized
    .split('/')
    .filter((segment) => segment && segment !== '.' && segment !== '..')
    .join('/');

  if (!safePath) {
    throw new Error(`Invalid workflow file path: ${filePath}`);
  }

  return `${WORKSPACE_DIR}/${safePath}`;
}

async function persistWorkflowState(workflowId: string, state: JsonRecord) {
  await kv.set(workflowStateKey(workflowId), state, {
    ex: WORKFLOW_TTL_SECONDS,
  });

  try {
    await updateWorkflowStatus(workflowId, WorkflowStatus.RUNNING, state);
  } catch (error) {
    if (
      !(error instanceof Error) ||
      !error.message.includes('Invalid workflow transition')
    ) {
      throw error;
    }
  }
}

async function emitLog(workflowId: string, message: string, data?: unknown) {
  await emitWorkflowEvent(workflowId, {
    data,
    message,
    timestamp: Date.now(),
    type: 'log',
  });
}

async function finalizeWorkflow(
  workflowId: string,
  userId: string,
  state: JsonRecord,
  status: WorkflowStatus,
  error?: unknown,
) {
  const nextState = {
    ...state,
    status: normalizeWorkflowStatus(status),
    ...(status === WorkflowStatus.COMPLETED
      ? { completedAt: new Date().toISOString() }
      : { failedAt: new Date().toISOString() }),
    ...(error !== undefined ? { error: serializeError(error) } : {}),
  };

  await kv.set(workflowStateKey(workflowId), nextState, {
    ex: WORKFLOW_TTL_SECONDS,
  });
  await updateWorkflowStatus(workflowId, status, nextState);
  await trackEvent(
    userId,
    status === WorkflowStatus.COMPLETED
      ? 'workflow.completed'
      : 'workflow.failed',
    status === WorkflowStatus.COMPLETED
      ? {
          durationSeconds: getDurationSeconds(state.startedAt),
          stepCount: getStepCount(nextState),
        }
      : {
          durationSeconds: getDurationSeconds(state.startedAt),
          failedStep: toFailedStep(nextState),
        },
    toProjectId(nextState),
  );
  await emitWorkflowEvent(workflowId, {
    data: error !== undefined ? serializeError(error) : nextState,
    message:
      status === WorkflowStatus.COMPLETED
        ? 'Workflow completed successfully.'
        : 'Workflow execution failed.',
    timestamp: Date.now(),
    type:
      status === WorkflowStatus.COMPLETED
        ? 'workflow_completed'
        : 'workflow_failed',
  });
}

async function runWorkflowStep<T>({
  workflowId,
  name,
  order,
  inputs,
  execute,
  checkCancellation = true,
  state,
}: {
  workflowId: string;
  name: string;
  order: number;
  inputs?: JsonRecord;
  execute: () => Promise<T>;
  checkCancellation?: boolean;
  state?: JsonRecord;
}) {
  if (checkCancellation) {
    await assertWorkflowNotCancelled(workflowId);
  }

  const stepRecord = await createWorkflowStep(workflowId, {
    inputs: inputs ?? {},
    retryCount: 0,
    status: StepStatus.RUNNING,
    stepName: name,
    stepOrder: order,
  });

  await emitWorkflowEvent(workflowId, {
    data: inputs,
    stepName: name,
    timestamp: Date.now(),
    type: 'step_started',
  });

  try {
    const result = await execute();
    const outputs = toJsonRecord(result);
    if (state) {
      state.completedStepCount = getStepCount(state) + 1;
      delete state.failedStep;
    }
    await updateStepStatus(stepRecord.id, StepStatus.COMPLETED, outputs);
    await emitWorkflowEvent(workflowId, {
      data: outputs,
      stepName: name,
      timestamp: Date.now(),
      type: 'step_completed',
    });
    return result;
  } catch (error) {
    const serializedError = serializeError(error);
    if (state) {
      state.failedStep = name;
    }
    await updateStepStatus(
      stepRecord.id,
      StepStatus.FAILED,
      undefined,
      serializedError,
    );
    await emitWorkflowEvent(workflowId, {
      data: serializedError,
      message: serializedError.message as string,
      stepName: name,
      timestamp: Date.now(),
      type: 'step_failed',
    });
    throw error;
  }
}

function buildCloudTaskArtifactFiles(
  input: CloudTaskWorkflowInput,
  state: JsonRecord,
): FileEntry[] {
  const report = {
    branch: input.branch,
    projectId: input.projectId,
    provider: input.provider,
    repositoryUrl: input.repositoryUrl,
    state,
    task: input.task,
    workflowId: input.workflowId,
  };

  const files: FileEntry[] = [
    {
      content: JSON.stringify(report, null, 2),
      path: 'workflow-report.json',
    },
  ];

  for (const file of input.contextFiles ?? []) {
    files.push({
      content: file.content,
      path: `context/${file.path.replace(/^\/+/, '')}`,
    });
  }

  return files;
}

async function collectWorkflowArtifact(
  workflowId: string,
  userId: string,
  projectId: string,
  archiveName: string,
  files: FileEntry[],
) {
  const { buffer, metadata } = await createZipArchive(files, archiveName);
  const upload = await uploadFile(metadata.filename, buffer, 'application/zip');
  const expiresAt = new Date(Date.now() + WORKFLOW_TTL_SECONDS * 1000);
  const downloadUrl = await generateSignedUrl(
    upload.pathname,
    WORKFLOW_TTL_SECONDS,
  );
  const artifact = await createArtifact({
    checksum: metadata.checksum,
    contentType: 'application/zip',
    downloadUrl,
    expiresAt,
    filePath: upload.pathname,
    fileSize: BigInt(metadata.totalSizeBytes),
    name: metadata.filename,
    projectId,
    workflowId,
  });
  await trackEvent(
    userId,
    'artifact.created',
    {
      fileCount: metadata.fileCount,
      sizeBytes: metadata.totalSizeBytes,
    },
    projectId,
  );

  return {
    artifactId: artifact.id,
    downloadUrl,
    name: artifact.name,
  };
}

async function cleanupSandboxStep(
  workflowId: string,
  userId: string,
  sandbox: SandboxResult | null,
  state: JsonRecord,
) {
  if (!sandbox || state.cleanupCompleted) {
    return;
  }

  await runWorkflowStep({
    checkCancellation: false,
    execute: async () => {
      await terminateSandbox(sandbox.sandboxId);
      state.cleanupCompleted = true;
      state.sandboxStatus = 'terminated';
      await persistWorkflowState(workflowId, state);
      await trackEvent(
        userId,
        'sandbox.terminated',
        toSandboxTerminationMetrics(sandbox),
        toProjectId(state),
      );
      await emitLog(workflowId, `Sandbox ${sandbox.sandboxId} terminated.`, {
        sandboxId: sandbox.sandboxId,
      });
      return { sandboxId: sandbox.sandboxId, terminated: true };
    },
    inputs: { sandboxId: sandbox.sandboxId },
    name: 'cleanup',
    order: 5,
    state,
    workflowId,
  });
}

export async function emitWorkflowEvent(
  workflowId: string,
  event: WorkflowEvent,
): Promise<void> {
  const key = workflowEventsKey(workflowId);
  const events = (await kv.get<WorkflowEvent[]>(key)) ?? [];
  const nextEvents = [...events, event].slice(-200);
  await kv.set(key, nextEvents, { ex: WORKFLOW_TTL_SECONDS });
}

export async function getWorkflowEvents(
  workflowId: string,
): Promise<Array<WorkflowEvent>> {
  return (await kv.get<WorkflowEvent[]>(workflowEventsKey(workflowId))) ?? [];
}

export async function isWorkflowCancelled(
  workflowId: string,
): Promise<boolean> {
  return (await kv.get<boolean>(workflowCancelKey(workflowId))) === true;
}

export async function assertWorkflowNotCancelled(
  workflowId: string,
): Promise<void> {
  if (await isWorkflowCancelled(workflowId)) {
    throw new WorkflowCancelledError(workflowId);
  }
}

export async function cancelWorkflow(workflowId: string): Promise<void> {
  await kv.set(workflowCancelKey(workflowId), true, {
    ex: WORKFLOW_TTL_SECONDS,
  });
  await emitWorkflowEvent(workflowId, {
    data: { cancelled: true },
    message: 'Workflow cancellation requested.',
    timestamp: Date.now(),
    type: 'workflow_failed',
  });
}

export const cloudTaskWorkflow = defineWorkflow({
  name: 'cloud-task',
  run: async (ctx: WorkflowContext) => {
    const input = ctx.metadata as unknown as CloudTaskWorkflowInput;
    const state: JsonRecord = {
      branch: input.branch,
      completedStepCount: 0,
      projectId: input.projectId,
      provider: input.provider,
      repositoryUrl: input.repositoryUrl,
      sandboxStatus: 'pending',
      startedAt: new Date().toISOString(),
      status: 'running',
      task: input.task,
      workflowType: 'cloud-task',
    };
    let sandbox: SandboxResult | null = null;
    let workflowError: unknown;

    await persistWorkflowState(input.workflowId, state);
    await emitLog(
      input.workflowId,
      'Workflow queued for cloud task execution.',
    );

    try {
      sandbox = await runWorkflowStep({
        execute: async () => {
          await emitLog(input.workflowId, 'Provisioning sandbox.');
          const provisionedSandbox = await createSandbox(input.projectId, {
            ...(input.sandboxConfig ?? {}),
            ...(input.branch ? { branch: input.branch } : {}),
            ...(input.repositoryUrl
              ? { repositoryUrl: input.repositoryUrl }
              : {}),
          });
          state.sandboxDomain = provisionedSandbox.domain;
          state.sandboxId = provisionedSandbox.sandboxId;
          state.sandboxStatus = provisionedSandbox.status;
          await persistWorkflowState(input.workflowId, state);
          await trackEvent(
            input.userId,
            'sandbox.created',
            {
              projectId: input.projectId,
              runtime: provisionedSandbox.configuration?.runtime,
              timeoutMinutes: provisionedSandbox.configuration?.timeoutMinutes,
              vcpus: provisionedSandbox.configuration?.vcpus,
            },
            input.projectId,
          );
          return provisionedSandbox;
        },
        inputs: {
          branch: input.branch,
          provider: input.provider,
          repositoryUrl: input.repositoryUrl,
          sandboxConfig: input.sandboxConfig ?? {},
        },
        name: 'provision-sandbox',
        order: 1,
        state,
        workflowId: input.workflowId,
      });
    } catch (error) {
      workflowError = error;
    }

    try {
      if (!workflowError && sandbox) {
        await runWorkflowStep({
          execute: async () => {
            await emitLog(
              input.workflowId,
              'Initializing AI tools inside the sandbox.',
            );
            await executeSandboxCommand(
              sandbox.sandboxId,
              `mkdir -p ${escapeShellArg(WORKSPACE_DIR)} && cd ${escapeShellArg(
                WORKSPACE_DIR,
              )} && (command -v claude || true) && (command -v codex || true)`,
            );

            const writtenFiles: string[] = [];
            for (const file of input.contextFiles ?? []) {
              const workspacePath = toWorkspacePath(file.path);
              await writeSandboxFile(
                sandbox.sandboxId,
                workspacePath,
                file.content,
              );
              writtenFiles.push(workspacePath);
            }

            const planningResult = await generateAIResponse({
              contextFiles: input.contextFiles,
              maxTokens: 800,
              prompt: `Create a concise implementation plan for this task.\n\nTask:\n${input.task}`,
              provider: input.provider,
              systemPrompt:
                'You are preparing a concise execution plan for a coding agent running inside a cloud sandbox. Return a short, actionable plan only.',
              temperature: 0.2,
            });

            state.plan = planningResult.content;
            state.contextFileCount = input.contextFiles?.length ?? 0;
            await persistWorkflowState(input.workflowId, state);

            return {
              contextFileCount: input.contextFiles?.length ?? 0,
              plan: planningResult.content,
              toolsReady: true,
              writtenFiles,
            };
          },
          inputs: {
            contextFileCount: input.contextFiles?.length ?? 0,
            provider: input.provider,
          },
          name: 'init-ai-tools',
          order: 2,
          state,
          workflowId: input.workflowId,
        });

        await runWorkflowStep({
          execute: async () => {
            await emitLog(
              input.workflowId,
              'Executing AI task inside the sandbox.',
            );
            const promptSections = [
              'You are working inside the Cloud-First AI Development Platform sandbox.',
              `Task:\n${input.task}`,
              typeof state.plan === 'string'
                ? `Execution plan:\n${state.plan}`
                : '',
              'Return a concise summary of the work completed and any files changed.',
            ].filter(Boolean);
            const executionResult = await executeAgentInSandbox(
              sandbox.sandboxId,
              input.provider,
              promptSections.join('\n\n'),
              { cwd: WORKSPACE_DIR },
            );

            if (executionResult.exitCode !== 0) {
              throw new Error(
                `AI task failed with exit code ${executionResult.exitCode}: ${executionResult.output}`,
              );
            }

            state.agentOutput = executionResult.output;
            state.agentExitCode = executionResult.exitCode;
            await persistWorkflowState(input.workflowId, state);

            return executionResult;
          },
          inputs: {
            provider: input.provider,
            task: input.task,
          },
          name: 'execute-ai-task',
          order: 3,
          state,
          workflowId: input.workflowId,
        });

        await runWorkflowStep({
          execute: async () => {
            await emitLog(input.workflowId, 'Collecting workflow artifacts.');
            const artifact = await collectWorkflowArtifact(
              input.workflowId,
              input.userId,
              input.projectId,
              `workflow-${input.workflowId}.zip`,
              buildCloudTaskArtifactFiles(input, state),
            );

            state.artifactId = artifact.artifactId;
            state.artifactName = artifact.name;
            await persistWorkflowState(input.workflowId, state);

            return artifact;
          },
          inputs: {
            contextFileCount: input.contextFiles?.length ?? 0,
          },
          name: 'collect-artifacts',
          order: 4,
          state,
          workflowId: input.workflowId,
        });
      }
    } catch (error) {
      workflowError = error;
    } finally {
      try {
        await cleanupSandboxStep(input.workflowId, input.userId, sandbox, state);
      } catch (cleanupError) {
        workflowError ??= cleanupError;
        await emitLog(
          input.workflowId,
          'Cleanup step failed.',
          serializeError(cleanupError),
        );
      }
    }

    if (workflowError) {
      await finalizeWorkflow(
        input.workflowId,
        input.userId,
        state,
        WorkflowStatus.FAILED,
        workflowError,
      );
      queueWorkflowFailedNotification(
        input.userId,
        input.workflowId,
        input.projectId,
        typeof state.failedStep === 'string' ? state.failedStep : 'Unknown step',
      );
      throw workflowError;
    }

    await finalizeWorkflow(
      input.workflowId,
      input.userId,
      state,
      WorkflowStatus.COMPLETED,
    );
    queueWorkflowCompleteNotification(
      input.userId,
      input.workflowId,
      input.projectId,
    );
    return { status: WorkflowStatus.COMPLETED, workflowId: input.workflowId };
  },
});

export const gitCommitWorkflow: WorkflowDefinition<{
  workflowId: string;
  status: WorkflowStatus;
}> = defineWorkflow({
  name: 'git-commit',
  run: async (ctx: WorkflowContext) => {
    const input = ctx.metadata as unknown as GitCommitWorkflowInput;
    const branchName =
      input.branch?.trim() || `workflow/${input.workflowId.slice(0, 8)}`;
    const state: JsonRecord = {
      branch: branchName,
      completedStepCount: 0,
      fileCount: input.files.length,
      projectId: input.projectId,
      repositoryUrl: input.repositoryUrl,
      startedAt: new Date().toISOString(),
      status: 'running',
      workflowType: 'git-commit',
    };
    let sandbox: SandboxResult | null = null;
    let workflowError: unknown;

    await persistWorkflowState(input.workflowId, state);

    try {
      sandbox = await createSandbox(input.projectId, {
        ...(input.sandboxConfig ?? {}),
        ...(input.repositoryUrl ? { repositoryUrl: input.repositoryUrl } : {}),
        branch: input.branch ?? 'main',
      });
      const activeSandbox = sandbox;
      state.sandboxId = activeSandbox.sandboxId;
      await persistWorkflowState(input.workflowId, state);
      await trackEvent(
        input.userId,
        'sandbox.created',
        {
          projectId: input.projectId,
          runtime: activeSandbox.configuration?.runtime,
          timeoutMinutes: activeSandbox.configuration?.timeoutMinutes,
          vcpus: activeSandbox.configuration?.vcpus,
        },
        input.projectId,
      );

      await runWorkflowStep({
        execute: async () => {
          const activeSandbox = sandbox;
          if (!activeSandbox) {
            throw new Error('Sandbox not available for branch creation.');
          }

          const command = [
            `mkdir -p ${escapeShellArg(WORKSPACE_DIR)}`,
            `cd ${escapeShellArg(WORKSPACE_DIR)}`,
            '[ -d .git ] || git init',
            `git config user.email ${escapeShellArg('copilot@local.dev')}`,
            `git config user.name ${escapeShellArg('GitHub Copilot')}`,
            `git rev-parse HEAD >/dev/null 2>&1 && git checkout -B ${escapeShellArg(branchName)} || git checkout --orphan ${escapeShellArg(branchName)}`,
          ].join(' && ');
          const result = await executeSandboxCommand(
            activeSandbox.sandboxId,
            command,
          );
          if (result.exitCode !== 0) {
            throw new Error(
              result.stderr || result.stdout || 'Unable to create branch.',
            );
          }

          state.branch = branchName;
          await persistWorkflowState(input.workflowId, state);
          return { branch: branchName };
        },
        inputs: { branch: branchName },
        name: 'create-branch',
        order: 1,
        state,
        workflowId: input.workflowId,
      });

      await runWorkflowStep({
        execute: async () => {
          const activeSandbox = sandbox;
          if (!activeSandbox) {
            throw new Error('Sandbox not available for staging files.');
          }

          for (const file of input.files) {
            await writeSandboxFile(
              activeSandbox.sandboxId,
              toWorkspacePath(file.path),
              file.content,
            );
          }
          const result = await executeSandboxCommand(
            activeSandbox.sandboxId,
            `cd ${escapeShellArg(WORKSPACE_DIR)} && git add --all`,
          );
          if (result.exitCode !== 0) {
            throw new Error(
              result.stderr || result.stdout || 'Unable to stage files.',
            );
          }

          return { files: input.files.map((file) => file.path) };
        },
        inputs: { fileCount: input.files.length },
        name: 'stage-files',
        order: 2,
        state,
        workflowId: input.workflowId,
      });

      await runWorkflowStep({
        execute: async () => {
          const activeSandbox = sandbox;
          if (!activeSandbox) {
            throw new Error('Sandbox not available for commit creation.');
          }

          const commitResult = await executeSandboxCommand(
            activeSandbox.sandboxId,
            `cd ${escapeShellArg(WORKSPACE_DIR)} && git commit --allow-empty -m ${escapeShellArg(
              input.commitMessage,
            )} && git rev-parse HEAD`,
          );
          if (commitResult.exitCode !== 0) {
            throw new Error(
              commitResult.stderr ||
                commitResult.stdout ||
                'Unable to create commit.',
            );
          }

          state.commitMessage = input.commitMessage;
          state.commitSha =
            commitResult.stdout.trim().split(/\r?\n/).pop() ?? '';
          await persistWorkflowState(input.workflowId, state);

          return {
            commitMessage: input.commitMessage,
            commitSha: state.commitSha,
          };
        },
        inputs: { commitMessage: input.commitMessage },
        name: 'create-commit',
        order: 3,
        state,
        workflowId: input.workflowId,
      });

      await runWorkflowStep({
        execute: async () => ({
          message:
            'Pull request creation is not configured for the local durable workflow engine.',
          skipped: true,
        }),
        inputs: { repositoryUrl: input.repositoryUrl },
        name: 'create-pr',
        order: 4,
        state,
        workflowId: input.workflowId,
      });
    } catch (error) {
      workflowError = error;
    } finally {
      try {
        await cleanupSandboxStep(input.workflowId, input.userId, sandbox, state);
      } catch (cleanupError) {
        workflowError ??= cleanupError;
      }
    }

    if (workflowError) {
      await finalizeWorkflow(
        input.workflowId,
        input.userId,
        state,
        WorkflowStatus.FAILED,
        workflowError,
      );
      queueWorkflowFailedNotification(
        input.userId,
        input.workflowId,
        input.projectId,
        typeof state.failedStep === 'string' ? state.failedStep : 'Unknown step',
      );
      throw workflowError;
    }

    await finalizeWorkflow(
      input.workflowId,
      input.userId,
      state,
      WorkflowStatus.COMPLETED,
    );
    queueWorkflowCompleteNotification(
      input.userId,
      input.workflowId,
      input.projectId,
    );
    return { status: WorkflowStatus.COMPLETED, workflowId: input.workflowId };
  },
});

export { defineStep, defineWorkflow, executeWorkflow } from '@vercel/workflow';
