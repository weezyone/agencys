import { Prisma, StepStatus, WorkflowStatus } from '@prisma/client';
import { z } from 'zod';
import { db } from '~/lib/db.server';

const jsonObjectSchema = z.record(z.string(), z.unknown());
const userIdSchema = z.string().trim().min(1, 'User ID is required.');
const projectIdSchema = z.string().trim().min(1, 'Project ID is required.');
const workflowIdSchema = z.string().trim().min(1, 'Workflow ID is required.');
const stepIdSchema = z.string().trim().min(1, 'Step ID is required.');
const artifactIdSchema = z.string().trim().min(1, 'Artifact ID is required.');
const sandboxRecordIdSchema = z
  .string()
  .trim()
  .min(1, 'Sandbox record ID is required.');
const sandboxIdSchema = z.string().trim().min(1, 'Sandbox ID is required.');

const createProjectInputSchema = z.object({
  branch: z.string().trim().min(1).max(255).default('main'),
  description: z
    .string()
    .trim()
    .max(5000)
    .nullish()
    .transform((value) => value ?? undefined),
  name: z.string().trim().min(1, 'Project name is required.').max(255),
  repositoryUrl: z
    .union([z.string().trim().url(), z.literal(''), z.null()])
    .optional()
    .transform((value) => (value ? value : undefined)),
  settings: jsonObjectSchema.default({}),
});

const updateProjectInputSchema = createProjectInputSchema
  .partial()
  .refine(
    (value) => Object.values(value).some((entry) => entry !== undefined),
    'At least one project field must be provided.',
  );

const createWorkflowInputSchema = z.object({
  currentState: jsonObjectSchema.default({}),
  definition: jsonObjectSchema.default({}),
  name: z.string().trim().min(1, 'Workflow name is required.').max(255),
  status: z.nativeEnum(WorkflowStatus).default(WorkflowStatus.INITIALIZING),
});

const createStepInputSchema = z.object({
  inputs: jsonObjectSchema.default({}),
  retryCount: z.number().int().min(0).default(0),
  status: z.nativeEnum(StepStatus).default(StepStatus.PENDING),
  stepName: z.string().trim().min(1, 'Step name is required.').max(255),
  stepOrder: z.number().int().min(0),
});

const createArtifactInputSchema = z.object({
  checksum: z.string().trim().min(1, 'Artifact checksum is required.').max(255),
  contentType: z
    .string()
    .trim()
    .min(1, 'Artifact content type is required.')
    .max(255),
  downloadUrl: z
    .union([z.string().trim().url(), z.literal(''), z.null()])
    .optional()
    .transform((value) => (value ? value : undefined)),
  expiresAt: z.coerce.date().optional(),
  filePath: z.string().trim().min(1, 'Artifact file path is required.'),
  fileSize: z.union([
    z.bigint(),
    z
      .number()
      .int()
      .min(0)
      .transform((value) => BigInt(value)),
  ]),
  name: z.string().trim().min(1, 'Artifact name is required.').max(255),
  projectId: projectIdSchema,
  workflowId: workflowIdSchema.optional(),
});

const createSandboxInputSchema = z.object({
  configuration: jsonObjectSchema.default({}),
  sandboxId: sandboxIdSchema.max(255),
  status: z.string().trim().min(1).max(64).default('provisioning'),
});

export type CreateProjectInput = z.infer<typeof createProjectInputSchema>;
export type UpdateProjectInput = z.infer<typeof updateProjectInputSchema>;
export type CreateWorkflowInput = z.infer<typeof createWorkflowInputSchema>;
export type CreateStepInput = z.infer<typeof createStepInputSchema>;
export type CreateArtifactInput = z.infer<typeof createArtifactInputSchema>;
export type CreateSandboxInput = z.infer<typeof createSandboxInputSchema>;

const workflowTransitions: Record<WorkflowStatus, WorkflowStatus[]> = {
  [WorkflowStatus.COMPLETED]: [],
  [WorkflowStatus.EXPIRED]: [],
  [WorkflowStatus.FAILED]: [],
  [WorkflowStatus.INITIALIZING]: [
    WorkflowStatus.RUNNING,
    WorkflowStatus.FAILED,
    WorkflowStatus.EXPIRED,
  ],
  [WorkflowStatus.RUNNING]: [
    WorkflowStatus.SUSPENDED,
    WorkflowStatus.COMPLETED,
    WorkflowStatus.FAILED,
    WorkflowStatus.EXPIRED,
  ],
  [WorkflowStatus.SUSPENDED]: [
    WorkflowStatus.RUNNING,
    WorkflowStatus.FAILED,
    WorkflowStatus.EXPIRED,
  ],
};

const stepTransitions: Record<StepStatus, StepStatus[]> = {
  [StepStatus.COMPLETED]: [],
  [StepStatus.FAILED]: [StepStatus.RETRYING],
  [StepStatus.PENDING]: [StepStatus.RUNNING, StepStatus.FAILED],
  [StepStatus.RETRYING]: [StepStatus.RUNNING, StepStatus.FAILED],
  [StepStatus.RUNNING]: [
    StepStatus.COMPLETED,
    StepStatus.FAILED,
    StepStatus.RETRYING,
  ],
};

const terminalWorkflowStatuses: WorkflowStatus[] = [
  WorkflowStatus.COMPLETED,
  WorkflowStatus.FAILED,
  WorkflowStatus.EXPIRED,
];
const terminalStepStatuses: StepStatus[] = [
  StepStatus.COMPLETED,
  StepStatus.FAILED,
];

function normalizeJson(
  value: unknown,
): Prisma.InputJsonValue | Prisma.JsonNullValueInput | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (value === null) {
    return Prisma.JsonNull;
  }

  return JSON.parse(
    JSON.stringify(value, (_key, entry) => {
      if (typeof entry === 'bigint') {
        return entry.toString();
      }

      if (entry instanceof Date) {
        return entry.toISOString();
      }

      return entry;
    }),
  ) as Prisma.InputJsonValue;
}

function handleDataError(context: string, error: unknown): never {
  if (error instanceof z.ZodError) {
    throw error;
  }

  if (error instanceof Prisma.PrismaClientKnownRequestError) {
    throw new Error(`${context}: ${error.message}`);
  }

  if (error instanceof Error) {
    throw new Error(`${context}: ${error.message}`);
  }

  throw new Error(`${context}: Unknown error`);
}

function assertWorkflowTransition(
  currentStatus: WorkflowStatus,
  nextStatus: WorkflowStatus,
) {
  if (currentStatus === nextStatus) {
    return;
  }

  if (!workflowTransitions[currentStatus].includes(nextStatus)) {
    throw new Error(
      `Invalid workflow transition from ${currentStatus} to ${nextStatus}.`,
    );
  }
}

function assertStepTransition(
  currentStatus: StepStatus,
  nextStatus: StepStatus,
) {
  if (currentStatus === nextStatus) {
    return;
  }

  if (!stepTransitions[currentStatus].includes(nextStatus)) {
    throw new Error(
      `Invalid step transition from ${currentStatus} to ${nextStatus}.`,
    );
  }
}

export async function getUserProjects(userId: string, limit = 20, offset = 0) {
  try {
    const parsedUserId = userIdSchema.parse(userId);
    const pagination = z
      .object({
        limit: z.number().int().min(1).max(100),
        offset: z.number().int().min(0),
      })
      .parse({ limit, offset });

    return await db.project.findMany({
      orderBy: { createdAt: 'desc' },
      skip: pagination.offset,
      take: pagination.limit,
      where: { userId: parsedUserId },
    });
  } catch (error) {
    return handleDataError('Failed to fetch projects', error);
  }
}

export async function getProjectById(projectId: string, userId: string) {
  try {
    return await db.project.findFirst({
      include: {
        artifacts: true,
        sandboxes: true,
        workflows: true,
      },
      where: {
        id: projectIdSchema.parse(projectId),
        userId: userIdSchema.parse(userId),
      },
    });
  } catch (error) {
    return handleDataError('Failed to fetch project', error);
  }
}

export async function createProject(userId: string, data: CreateProjectInput) {
  try {
    const parsedUserId = userIdSchema.parse(userId);
    const parsedData = createProjectInputSchema.parse(data);

    return await db.project.create({
      data: {
        branch: parsedData.branch,
        description: parsedData.description,
        name: parsedData.name,
        repositoryUrl: parsedData.repositoryUrl,
        settings: normalizeJson(parsedData.settings),
        userId: parsedUserId,
      },
    });
  } catch (error) {
    return handleDataError('Failed to create project', error);
  }
}

export async function updateProject(
  projectId: string,
  userId: string,
  data: UpdateProjectInput,
) {
  try {
    const parsedProjectId = projectIdSchema.parse(projectId);
    const parsedUserId = userIdSchema.parse(userId);
    const parsedData = updateProjectInputSchema.parse(data);
    const existingProject = await db.project.findFirst({
      where: { id: parsedProjectId, userId: parsedUserId },
    });

    if (!existingProject) {
      return null;
    }

    return await db.project.update({
      data: {
        branch: parsedData.branch,
        description: parsedData.description,
        name: parsedData.name,
        repositoryUrl: parsedData.repositoryUrl,
        settings: parsedData.settings
          ? normalizeJson(parsedData.settings)
          : undefined,
      },
      where: { id: parsedProjectId },
    });
  } catch (error) {
    return handleDataError('Failed to update project', error);
  }
}

export async function deleteProject(projectId: string, userId: string) {
  try {
    const existingProject = await db.project.findFirst({
      where: {
        id: projectIdSchema.parse(projectId),
        userId: userIdSchema.parse(userId),
      },
    });

    if (!existingProject) {
      return null;
    }

    return await db.project.delete({ where: { id: existingProject.id } });
  } catch (error) {
    return handleDataError('Failed to delete project', error);
  }
}

export async function createSandboxRecord(
  projectId: string,
  data: CreateSandboxInput,
) {
  try {
    const parsedProjectId = projectIdSchema.parse(projectId);
    const parsedData = createSandboxInputSchema.parse(data);

    return await db.sandbox.create({
      data: {
        configuration: normalizeJson(parsedData.configuration),
        projectId: parsedProjectId,
        sandboxId: parsedData.sandboxId,
        status: parsedData.status,
      },
    });
  } catch (error) {
    return handleDataError('Failed to create sandbox', error);
  }
}

export async function getSandboxById(sandboxRecordId: string, userId?: string) {
  try {
    return await db.sandbox.findFirst({
      include: { project: true },
      where: {
        id: sandboxRecordIdSchema.parse(sandboxRecordId),
        ...(userId ? { project: { userId: userIdSchema.parse(userId) } } : {}),
      },
    });
  } catch (error) {
    return handleDataError('Failed to fetch sandbox', error);
  }
}

export async function getSandboxBySandboxId(sandboxId: string) {
  try {
    return await db.sandbox.findFirst({
      include: { project: true },
      where: { sandboxId: sandboxIdSchema.parse(sandboxId) },
    });
  } catch (error) {
    return handleDataError('Failed to fetch sandbox by external ID', error);
  }
}

export async function updateSandboxRecordStatus(
  sandboxRecordId: string,
  status: string,
) {
  try {
    const parsedSandboxRecordId = sandboxRecordIdSchema.parse(sandboxRecordId);
    const existingSandbox = await db.sandbox.findUnique({
      where: { id: parsedSandboxRecordId },
    });

    if (!existingSandbox) {
      return null;
    }

    return await db.sandbox.update({
      data: {
        status: z.string().trim().min(1).max(64).parse(status),
      },
      where: { id: parsedSandboxRecordId },
    });
  } catch (error) {
    return handleDataError('Failed to update sandbox status', error);
  }
}

export async function updateSandboxStatusBySandboxId(
  sandboxId: string,
  status: string,
) {
  try {
    const parsedSandboxId = sandboxIdSchema.parse(sandboxId);
    const existingSandbox = await db.sandbox.findFirst({
      where: { sandboxId: parsedSandboxId },
    });

    if (!existingSandbox) {
      return null;
    }

    return await db.sandbox.update({
      data: {
        status: z.string().trim().min(1).max(64).parse(status),
      },
      where: { id: existingSandbox.id },
    });
  } catch (error) {
    return handleDataError(
      'Failed to update sandbox status by external ID',
      error,
    );
  }
}

export async function terminateSandboxRecord(sandboxRecordId: string) {
  try {
    const parsedSandboxRecordId = sandboxRecordIdSchema.parse(sandboxRecordId);
    const existingSandbox = await db.sandbox.findUnique({
      where: { id: parsedSandboxRecordId },
    });

    if (!existingSandbox) {
      return null;
    }

    return await db.sandbox.update({
      data: {
        status: 'terminated',
        terminatedAt: new Date(),
      },
      where: { id: parsedSandboxRecordId },
    });
  } catch (error) {
    return handleDataError('Failed to terminate sandbox record', error);
  }
}

export async function terminateSandboxBySandboxId(sandboxId: string) {
  try {
    const parsedSandboxId = sandboxIdSchema.parse(sandboxId);
    const existingSandbox = await db.sandbox.findFirst({
      where: { sandboxId: parsedSandboxId },
    });

    if (!existingSandbox) {
      return null;
    }

    return await db.sandbox.update({
      data: {
        status: 'terminated',
        terminatedAt: new Date(),
      },
      where: { id: existingSandbox.id },
    });
  } catch (error) {
    return handleDataError('Failed to terminate sandbox by external ID', error);
  }
}

export async function getProjectWorkflows(
  projectId: string,
  status?: WorkflowStatus,
) {
  try {
    return await db.workflow.findMany({
      include: { steps: { orderBy: { stepOrder: 'asc' } } },
      orderBy: { updatedAt: 'desc' },
      where: {
        projectId: projectIdSchema.parse(projectId),
        ...(status ? { status } : {}),
      },
    });
  } catch (error) {
    return handleDataError('Failed to fetch workflows', error);
  }
}

export async function getWorkflowById(workflowId: string) {
  try {
    return await db.workflow.findUnique({
      include: {
        artifacts: { orderBy: { createdAt: 'desc' } },
        project: true,
        steps: { orderBy: { stepOrder: 'asc' } },
      },
      where: { id: workflowIdSchema.parse(workflowId) },
    });
  } catch (error) {
    return handleDataError('Failed to fetch workflow', error);
  }
}

export async function createWorkflow(
  projectId: string,
  data: CreateWorkflowInput,
) {
  try {
    const parsedProjectId = projectIdSchema.parse(projectId);
    const parsedData = createWorkflowInputSchema.parse(data);
    const startedAt =
      parsedData.status === WorkflowStatus.RUNNING ? new Date() : undefined;
    const completedAt = terminalWorkflowStatuses.includes(parsedData.status)
      ? new Date()
      : undefined;

    return await db.workflow.create({
      data: {
        completedAt,
        currentState: normalizeJson(parsedData.currentState),
        definition: normalizeJson(parsedData.definition),
        name: parsedData.name,
        projectId: parsedProjectId,
        startedAt,
        status: parsedData.status,
      },
    });
  } catch (error) {
    return handleDataError('Failed to create workflow', error);
  }
}

export async function updateWorkflowStatus(
  workflowId: string,
  status: WorkflowStatus,
  state?: Record<string, unknown>,
) {
  try {
    const parsedWorkflowId = workflowIdSchema.parse(workflowId);
    const workflow = await db.workflow.findUnique({
      where: { id: parsedWorkflowId },
    });

    if (!workflow) {
      return null;
    }

    assertWorkflowTransition(workflow.status, status);

    const isTerminal = terminalWorkflowStatuses.includes(status);
    const data: Prisma.WorkflowUpdateInput = {
      completedAt: isTerminal ? new Date() : undefined,
      currentState: state ? normalizeJson(state) : undefined,
      startedAt:
        status === WorkflowStatus.RUNNING && !workflow.startedAt
          ? new Date()
          : undefined,
      status,
    };

    if (!isTerminal && status !== WorkflowStatus.RUNNING) {
      data.completedAt = null;
    }

    return await db.workflow.update({
      data,
      where: { id: parsedWorkflowId },
    });
  } catch (error) {
    return handleDataError('Failed to update workflow status', error);
  }
}

export async function createWorkflowStep(
  workflowId: string,
  data: CreateStepInput,
) {
  try {
    const parsedWorkflowId = workflowIdSchema.parse(workflowId);
    const parsedData = createStepInputSchema.parse(data);

    return await db.workflowStep.create({
      data: {
        inputs: normalizeJson(parsedData.inputs),
        retryCount: parsedData.retryCount,
        startedAt:
          parsedData.status === StepStatus.RUNNING ? new Date() : undefined,
        status: parsedData.status,
        stepName: parsedData.stepName,
        stepOrder: parsedData.stepOrder,
        workflowId: parsedWorkflowId,
      },
    });
  } catch (error) {
    return handleDataError('Failed to create workflow step', error);
  }
}

export async function updateStepStatus(
  stepId: string,
  status: StepStatus,
  outputs?: Record<string, unknown>,
  error?: unknown,
) {
  try {
    const parsedStepId = stepIdSchema.parse(stepId);
    const step = await db.workflowStep.findUnique({
      where: { id: parsedStepId },
    });

    if (!step) {
      return null;
    }

    assertStepTransition(step.status, status);

    return await db.workflowStep.update({
      data: {
        completedAt: terminalStepStatuses.includes(status)
          ? new Date()
          : undefined,
        errorDetails: error !== undefined ? normalizeJson(error) : undefined,
        outputs: outputs ? normalizeJson(outputs) : undefined,
        retryCount:
          status === StepStatus.RETRYING ? { increment: 1 } : undefined,
        startedAt:
          status === StepStatus.RUNNING && !step.startedAt
            ? new Date()
            : undefined,
        status,
      },
      where: { id: parsedStepId },
    });
  } catch (error) {
    return handleDataError('Failed to update workflow step status', error);
  }
}

export async function getProjectArtifacts(projectId: string) {
  try {
    return await db.artifact.findMany({
      orderBy: { createdAt: 'desc' },
      where: { projectId: projectIdSchema.parse(projectId) },
    });
  } catch (error) {
    return handleDataError('Failed to fetch artifacts', error);
  }
}

export async function createArtifact(data: CreateArtifactInput) {
  try {
    const parsedData = createArtifactInputSchema.parse(data);

    return await db.artifact.create({
      data: {
        checksum: parsedData.checksum,
        contentType: parsedData.contentType,
        downloadUrl: parsedData.downloadUrl,
        expiresAt: parsedData.expiresAt,
        filePath: parsedData.filePath,
        fileSize: parsedData.fileSize,
        name: parsedData.name,
        projectId: parsedData.projectId,
        workflowId: parsedData.workflowId,
      },
    });
  } catch (error) {
    return handleDataError('Failed to create artifact', error);
  }
}

export async function getArtifactById(artifactId: string) {
  try {
    return await db.artifact.findUnique({
      where: { id: artifactIdSchema.parse(artifactId) },
    });
  } catch (error) {
    return handleDataError('Failed to fetch artifact', error);
  }
}

export async function deleteExpiredArtifacts() {
  try {
    return await db.artifact.deleteMany({
      where: {
        expiresAt: {
          lt: new Date(),
          not: null,
        },
      },
    });
  } catch (error) {
    return handleDataError('Failed to delete expired artifacts', error);
  }
}

export async function createAuditLog(
  userId: string,
  tableName: string,
  operation: string,
  oldValues?: unknown,
  newValues?: unknown,
) {
  try {
    const parsedUserId = userIdSchema.parse(userId);
    const parsedTableName = z
      .string()
      .trim()
      .min(1, 'Table name is required.')
      .parse(tableName);
    const parsedOperation = z
      .string()
      .trim()
      .min(1, 'Operation is required.')
      .parse(operation);

    return await db.auditLog.create({
      data: {
        newValues: normalizeJson(newValues),
        oldValues: normalizeJson(oldValues),
        operation: parsedOperation,
        tableName: parsedTableName,
        userId: parsedUserId,
      },
    });
  } catch (error) {
    return handleDataError('Failed to create audit log', error);
  }
}
