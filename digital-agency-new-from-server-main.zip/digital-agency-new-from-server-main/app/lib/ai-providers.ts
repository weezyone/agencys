export type AIProvider = 'claude' | 'codex' | 'openrouter' | 'huggingface' | 'nvidia';

export interface ProviderDefinition {
  envKey: string;
  model: string;
  baseURL?: string;
  kind: 'anthropic' | 'openai-compatible';
}

export const PROVIDER_DEFINITIONS: Record<AIProvider, ProviderDefinition> = {
  claude: {
    envKey: 'ANTHROPIC_API_KEY',
    kind: 'anthropic',
    model: 'claude-3-5-sonnet-20241022',
  },
  codex: {
    envKey: 'OPENAI_API_KEY',
    kind: 'openai-compatible',
    model: 'gpt-4o',
  },
  huggingface: {
    baseURL: 'https://router.huggingface.co/v1',
    envKey: 'HUGGINGFACE_API_KEY',
    kind: 'openai-compatible',
    model: 'openai/gpt-oss-120b',
  },
  nvidia: {
    baseURL: 'https://integrate.api.nvidia.com/v1',
    envKey: 'NVIDIA_API_KEY',
    kind: 'openai-compatible',
    model: 'openai/gpt-oss-120b',
  },
  openrouter: {
    baseURL: 'https://openrouter.ai/api/v1',
    envKey: 'OPENROUTER_API_KEY',
    kind: 'openai-compatible',
    model: 'openai/gpt-oss-120b',
  },
};

export function validateProviderConfig(provider: AIProvider): { valid: boolean; error?: string } {
  const definition = PROVIDER_DEFINITIONS[provider];
  if (!definition) {
    return { error: `Unknown provider: ${provider}`, valid: false };
  }

  if (!process.env[definition.envKey]) {
    return { error: `${definition.envKey} not configured`, valid: false };
  }

  return { valid: true };
}
