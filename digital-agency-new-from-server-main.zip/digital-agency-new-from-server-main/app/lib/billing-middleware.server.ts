import {
  canCreateProject,
  canCreateSandbox,
  canMakeAiRequest,
  getUsageSummary,
} from './billing.server';

function buildQuotaExceededResponse(message: string, plan: string) {
  return Response.json(
    {
      error: 'quota_exceeded',
      message,
      plan,
      upgradeUrl: '/settings/billing',
    },
    { status: 402 },
  );
}

export async function requireSandboxQuota(
  userId: string,
  vcpus: number,
  timeoutMinutes: number,
): Promise<void> {
  const [result, usage] = await Promise.all([
    canCreateSandbox(userId, vcpus, timeoutMinutes),
    getUsageSummary(userId),
  ]);

  if (!result.allowed) {
    throw buildQuotaExceededResponse(
      result.reason ?? 'Sandbox quota exceeded.',
      usage.plan,
    );
  }
}

export async function requireAiQuota(userId: string): Promise<void> {
  const [result, usage] = await Promise.all([
    canMakeAiRequest(userId),
    getUsageSummary(userId),
  ]);

  if (!result.allowed) {
    throw buildQuotaExceededResponse(
      result.reason ?? 'AI quota exceeded.',
      usage.plan,
    );
  }
}

export async function requireProjectQuota(userId: string): Promise<void> {
  const [result, usage] = await Promise.all([
    canCreateProject(userId),
    getUsageSummary(userId),
  ]);

  if (!result.allowed) {
    throw buildQuotaExceededResponse(
      result.reason ?? 'Project quota exceeded.',
      usage.plan,
    );
  }
}
