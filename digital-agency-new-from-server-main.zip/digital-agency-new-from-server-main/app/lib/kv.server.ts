import { createClient } from 'redis';

export interface KVStore {
  get<T>(key: string): Promise<T | null>;
  set<T>(key: string, value: T, options?: { ex?: number }): Promise<void>;
  del(key: string): Promise<number>;
  hset(key: string, field: string, value: unknown): Promise<number>;
  hget<T>(key: string, field: string): Promise<T | null>;
  hgetall<T extends Record<string, unknown>>(key: string): Promise<T | null>;
  hdel(key: string, field: string): Promise<number>;
  expire(key: string, seconds: number): Promise<number>;
  keys(pattern: string): Promise<string[]>;
}

type MemoryValueEntry = {
  expiresAt: number | null;
  type: 'value';
  value: string;
};

type MemoryHashEntry = {
  expiresAt: number | null;
  type: 'hash';
  value: Map<string, string>;
};

type MemoryEntry = MemoryValueEntry | MemoryHashEntry;

function serialize(value: unknown) {
  return JSON.stringify(value ?? null);
}

function deserialize<T>(value: unknown): T | null {
  if (value == null) {
    return null;
  }

  if (typeof value !== 'string') {
    return value as T;
  }

  return JSON.parse(value) as T;
}

function patternToRegExp(pattern: string) {
  const escaped = pattern.replace(/[.+^${}()|[\]\\]/g, '\\$&');
  return new RegExp(`^${escaped.replace(/\*/g, '.*')}$`);
}

export function createInMemoryKVStore(): KVStore {
  const store = new Map<string, MemoryEntry>();

  const getEntry = (key: string): MemoryEntry | null => {
    const entry = store.get(key);
    if (!entry) {
      return null;
    }

    if (entry.expiresAt && entry.expiresAt <= Date.now()) {
      store.delete(key);
      return null;
    }

    return entry;
  };

  return {
    async get<T>(key: string) {
      const entry = getEntry(key);
      if (!entry || entry.type !== 'value') {
        return null;
      }

      return deserialize<T>(entry.value);
    },
    async set<T>(key: string, value: T, options?: { ex?: number }) {
      store.set(key, {
        expiresAt: options?.ex ? Date.now() + options.ex * 1000 : null,
        type: 'value',
        value: serialize(value),
      });
    },
    async del(key: string) {
      const existed = getEntry(key) ? 1 : 0;
      store.delete(key);
      return existed;
    },
    async hset(key: string, field: string, value: unknown) {
      const entry = getEntry(key);
      const hash =
        entry?.type === 'hash' ? entry.value : new Map<string, string>();
      const isNewField = hash.has(field) ? 0 : 1;

      hash.set(field, serialize(value));
      store.set(key, {
        expiresAt: entry?.expiresAt ?? null,
        type: 'hash',
        value: hash,
      });

      return isNewField;
    },
    async hget<T>(key: string, field: string) {
      const entry = getEntry(key);
      if (!entry || entry.type !== 'hash') {
        return null;
      }

      return deserialize<T>(entry.value.get(field));
    },
    async hgetall<T extends Record<string, unknown>>(key: string) {
      const entry = getEntry(key);
      if (!entry || entry.type !== 'hash') {
        return null;
      }

      return Object.fromEntries(
        Array.from(entry.value.entries()).map(([field, value]) => [
          field,
          deserialize(value),
        ]),
      ) as T;
    },
    async hdel(key: string, field: string) {
      const entry = getEntry(key);
      if (!entry || entry.type !== 'hash') {
        return 0;
      }

      const deleted = entry.value.delete(field) ? 1 : 0;
      if (entry.value.size === 0) {
        store.delete(key);
      }

      return deleted;
    },
    async expire(key: string, seconds: number) {
      const entry = getEntry(key);
      if (!entry) {
        return 0;
      }

      const nextEntry: MemoryEntry = {
        ...entry,
        expiresAt: Date.now() + seconds * 1000,
      };
      store.set(key, nextEntry);
      return 1;
    },
    async keys(pattern: string) {
      const matcher = patternToRegExp(pattern);
      return Array.from(store.keys()).filter((key) => {
        const entry = getEntry(key);
        return Boolean(entry) && matcher.test(key);
      });
    },
  };
}

function parseHashResult<T extends Record<string, unknown>>(
  value: unknown,
): T | null {
  if (value == null) {
    return null;
  }

  if (Array.isArray(value)) {
    const result: Record<string, unknown> = {};

    for (let index = 0; index < value.length; index += 2) {
      const field = value[index];
      const fieldValue = value[index + 1];
      if (typeof field === 'string') {
        result[field] = deserialize(fieldValue);
      }
    }

    return result as T;
  }

  if (typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>).map(
        ([field, fieldValue]) => [field, deserialize(fieldValue)],
      ),
    ) as T;
  }

  return null;
}

function createVercelKVStore(url: string, token?: string): KVStore {
  const baseUrl = url.replace(/\/+$/, '');

  const request = async <T>(
    command: string[],
    options: { body?: string; query?: URLSearchParams } = {},
  ): Promise<T> => {
    const endpoint = `${baseUrl}/${command.map((segment) => encodeURIComponent(segment)).join('/')}`;
    const target = options.query?.size
      ? `${endpoint}?${options.query.toString()}`
      : endpoint;
    const response = await fetch(target, {
      body: options.body,
      headers: {
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...(options.body ? { 'Content-Type': 'application/json' } : {}),
      },
      method: options.body ? 'POST' : 'GET',
    });
    const payload = (await response.json()) as { error?: string; result?: T };

    if (!response.ok || payload.error) {
      throw new Error(
        payload.error ?? `KV request failed with status ${response.status}`,
      );
    }

    return payload.result as T;
  };

  return {
    async get<T>(key: string) {
      const value = await request<unknown>(['get', key]);
      return deserialize<T>(value);
    },
    async set<T>(key: string, value: T, options?: { ex?: number }) {
      const query = new URLSearchParams();
      if (options?.ex) {
        query.set('EX', String(options.ex));
      }

      await request(['set', key], { body: serialize(value), query });
    },
    async del(key: string) {
      return request<number>(['del', key]);
    },
    async hset(key: string, field: string, value: unknown) {
      return request<number>(['hset', key, field], { body: serialize(value) });
    },
    async hget<T>(key: string, field: string) {
      const value = await request<unknown>(['hget', key, field]);
      return deserialize<T>(value);
    },
    async hgetall<T extends Record<string, unknown>>(key: string) {
      const value = await request<unknown>(['hgetall', key]);
      return parseHashResult<T>(value);
    },
    async hdel(key: string, field: string) {
      return request<number>(['hdel', key, field]);
    },
    async expire(key: string, seconds: number) {
      return request<number>(['expire', key, String(seconds)]);
    },
    async keys(pattern: string) {
      return request<string[]>(['keys', pattern]);
    },
  };
}

function createRedisKVStore(url: string): KVStore {
  const client = createClient({ url });
  let connectPromise: Promise<void> | null = null;

  const connect = async () => {
    if (client.isOpen) {
      return;
    }

    connectPromise ??= client.connect().then(
      () => undefined,
      (error) => {
        connectPromise = null;
        throw error;
      },
    );
    await connectPromise;
  };

  return {
    async get<T>(key: string) {
      await connect();
      return deserialize<T>(await client.get(key));
    },
    async set<T>(key: string, value: T, options?: { ex?: number }) {
      await connect();
      if (options?.ex) {
        await client.set(key, serialize(value), { EX: options.ex });
        return;
      }

      await client.set(key, serialize(value));
    },
    async del(key: string) {
      await connect();
      return client.del(key);
    },
    async hset(key: string, field: string, value: unknown) {
      await connect();
      return client.hSet(key, field, serialize(value));
    },
    async hget<T>(key: string, field: string) {
      await connect();
      return deserialize<T>(await client.hGet(key, field));
    },
    async hgetall<T extends Record<string, unknown>>(key: string) {
      await connect();
      return parseHashResult<T>(await client.hGetAll(key));
    },
    async hdel(key: string, field: string) {
      await connect();
      return client.hDel(key, field);
    },
    async expire(key: string, seconds: number) {
      await connect();
      return client.expire(key, seconds);
    },
    async keys(pattern: string) {
      await connect();
      return client.keys(pattern);
    },
  };
}

function shouldUseVercelKVStore(url?: string) {
  if (!url || process.env.NODE_ENV === 'test') {
    return false;
  }

  return !/your-kv\.vercel-storage\.com/i.test(url);
}

const kvRestApiUrl = process.env.KV_REST_API_URL;
const redisUrl = process.env.REDIS_URL;

export const kv: KVStore = redisUrl && process.env.NODE_ENV !== 'test'
  ? createRedisKVStore(redisUrl)
  : kvRestApiUrl && shouldUseVercelKVStore(kvRestApiUrl)
    ? createVercelKVStore(kvRestApiUrl, process.env.KV_REST_API_TOKEN)
    : createInMemoryKVStore();

export default kv;
