import type { Project, Team, TeamInvite, TeamMember } from '@prisma/client';
import { db } from './db.server';
import { TeamRole } from './team-roles';

const ROLE_RANK: Record<TeamRole, number> = {
  OWNER: 3,
  COLLABORATOR: 2,
  VIEWER: 1,
};

const INVITE_TTL_MS = 7 * 24 * 60 * 60 * 1000;

export class TeamError extends Error {
  constructor(
    message: string,
    public status: number,
  ) {
    super(message);
    this.name = 'TeamError';
  }
}

function hasRequiredRole(role: TeamRole, requiredRole: TeamRole) {
  return ROLE_RANK[role] >= ROLE_RANK[requiredRole];
}

async function requireMembership(teamId: string, userId: string) {
  const membership = await db.teamMember.findUnique({
    where: { teamId_userId: { teamId, userId } },
  });

  if (!membership) {
    throw new TeamError('Forbidden', 403);
  }

  return membership;
}

async function requireRole(
  teamId: string,
  userId: string,
  requiredRole: TeamRole,
) {
  const membership = await requireMembership(teamId, userId);

  if (!hasRequiredRole(membership.role, requiredRole)) {
    throw new TeamError('Forbidden', 403);
  }

  return membership;
}

async function countOwners(teamId: string) {
  return db.teamMember.count({ where: { role: TeamRole.OWNER, teamId } });
}

export interface TeamWithMembers extends Team {
  members: Array<
    TeamMember & {
      user: {
        id: string;
        name: string;
        email: string;
        avatarUrl: string | null;
      };
    }
  >;
  invites: TeamInvite[];
}

export interface TeamWithRole extends Team {
  role: TeamRole;
  memberCount: number;
}

export interface TeamInviteWithTeam extends TeamInvite {
  team: Team & {
    owner: {
      id: string;
      name: string;
      email: string;
    };
  };
}

export async function createTeam(
  ownerId: string,
  data: { name: string; description?: string },
): Promise<Team> {
  return db.team.create({
    data: {
      description: data.description,
      members: {
        create: {
          role: TeamRole.OWNER,
          userId: ownerId,
        },
      },
      name: data.name,
      ownerId,
    },
  });
}

export async function getTeamById(
  teamId: string,
): Promise<TeamWithMembers | null> {
  return db.team.findUnique({
    include: {
      invites: {
        orderBy: { createdAt: 'desc' },
        where: { expiresAt: { gt: new Date() } },
      },
      members: {
        include: {
          user: {
            select: {
              avatarUrl: true,
              email: true,
              id: true,
              name: true,
            },
          },
        },
        orderBy: { joinedAt: 'asc' },
      },
    },
    where: { id: teamId },
  }) as Promise<TeamWithMembers | null>;
}

export async function getUserTeams(userId: string): Promise<TeamWithRole[]> {
  const memberships = await db.teamMember.findMany({
    include: {
      team: {
        include: {
          _count: {
            select: {
              members: true,
            },
          },
        },
      },
    },
    orderBy: { joinedAt: 'desc' },
    where: { userId },
  });

  return memberships.map(({ role, team }) => ({
    ...team,
    memberCount: team._count.members,
    role,
  }));
}

export async function addTeamMember(
  teamId: string,
  userId: string,
  role: TeamRole,
): Promise<TeamMember> {
  return db.teamMember.create({
    data: {
      role,
      teamId,
      userId,
    },
  });
}

export async function removeTeamMember(
  teamId: string,
  userId: string,
  requesterId: string,
): Promise<void> {
  const requester = await requireRole(teamId, requesterId, TeamRole.COLLABORATOR);

  const member = await db.teamMember.findUnique({
    where: { teamId_userId: { teamId, userId } },
  });

  if (!member) {
    throw new TeamError('Member not found', 404);
  }

  if (member.role === TeamRole.OWNER) {
    if ((await countOwners(teamId)) <= 1) {
      throw new TeamError('Cannot remove the last owner', 400);
    }
    throw new TeamError('Owners must transfer ownership first', 400);
  }

  if (userId === requesterId) {
    throw new TeamError('You cannot remove yourself', 400);
  }

  if (
    requester.role !== TeamRole.OWNER &&
    member.role === TeamRole.COLLABORATOR
  ) {
    throw new TeamError('Forbidden', 403);
  }

  await db.teamMember.delete({
    where: { teamId_userId: { teamId, userId } },
  });
}

export async function updateMemberRole(
  teamId: string,
  userId: string,
  role: TeamRole,
  requesterId: string,
): Promise<TeamMember> {
  const requester = await requireRole(teamId, requesterId, TeamRole.COLLABORATOR);

  const member = await db.teamMember.findUnique({
    where: { teamId_userId: { teamId, userId } },
  });

  if (!member) {
    throw new TeamError('Member not found', 404);
  }

  if (member.role === TeamRole.OWNER || role === TeamRole.OWNER) {
    throw new TeamError('Owners must transfer ownership first', 400);
  }

  if (
    requester.role !== TeamRole.OWNER &&
    member.role === TeamRole.COLLABORATOR
  ) {
    throw new TeamError('Forbidden', 403);
  }

  return db.teamMember.update({
    data: { role },
    where: { teamId_userId: { teamId, userId } },
  });
}

export async function transferOwnership(
  teamId: string,
  newOwnerId: string,
  currentOwnerId: string,
): Promise<void> {
  const currentOwner = await requireRole(teamId, currentOwnerId, TeamRole.OWNER);
  const newOwner = await db.teamMember.findUnique({
    where: { teamId_userId: { teamId, userId: newOwnerId } },
  });

  if (!newOwner) {
    throw new TeamError('Member not found', 404);
  }

  if (currentOwner.userId === newOwnerId) {
    return;
  }

  await db.$transaction([
    db.team.update({
      data: { ownerId: newOwnerId },
      where: { id: teamId },
    }),
    db.teamMember.update({
      data: { role: TeamRole.OWNER },
      where: { teamId_userId: { teamId, userId: newOwnerId } },
    }),
    db.teamMember.update({
      data: { role: TeamRole.COLLABORATOR },
      where: { teamId_userId: { teamId, userId: currentOwnerId } },
    }),
  ]);
}

export async function createTeamInvite(
  teamId: string,
  email: string,
  role: TeamRole,
  requesterId: string,
): Promise<TeamInvite> {
  await requireRole(teamId, requesterId, TeamRole.COLLABORATOR);
  await deleteExpiredInvites();

  return db.teamInvite.create({
    data: {
      email: email.trim().toLowerCase(),
      expiresAt: new Date(Date.now() + INVITE_TTL_MS),
      role,
      teamId,
    },
  });
}

export async function getTeamInviteByToken(
  token: string,
): Promise<TeamInviteWithTeam | null> {
  const invite = await db.teamInvite.findUnique({
    include: {
      team: {
        include: {
          owner: {
            select: {
              email: true,
              id: true,
              name: true,
            },
          },
        },
      },
    },
    where: { token },
  });

  if (!invite) {
    return null;
  }

  if (invite.expiresAt <= new Date()) {
    await db.teamInvite.delete({ where: { id: invite.id } });
    return null;
  }

  return invite as TeamInviteWithTeam;
}

export async function acceptTeamInvite(
  token: string,
  userId: string,
): Promise<{ team: Team; role: TeamRole }> {
  const invite = await db.teamInvite.findUnique({
    include: { team: true },
    where: { token },
  });

  if (!invite) {
    throw new TeamError('Invite not found', 404);
  }

  if (invite.expiresAt <= new Date()) {
    await db.teamInvite.delete({ where: { id: invite.id } });
    throw new TeamError('Invite expired', 400);
  }

  const user = await db.user.findUnique({
    select: { email: true, id: true },
    where: { id: userId },
  });

  if (!user) {
    throw new TeamError('User not found', 404);
  }

  if (user.email.trim().toLowerCase() !== invite.email.trim().toLowerCase()) {
    throw new TeamError('Invite email does not match user', 403);
  }

  const existingMember = await db.teamMember.findUnique({
    where: { teamId_userId: { teamId: invite.teamId, userId } },
  });

  if (existingMember) {
    await db.teamInvite.delete({ where: { id: invite.id } });
    return { role: existingMember.role, team: invite.team };
  }

  await db.$transaction([
    db.teamMember.create({
      data: {
        role: invite.role,
        teamId: invite.teamId,
        userId,
      },
    }),
    db.teamInvite.delete({ where: { id: invite.id } }),
  ]);

  return { role: invite.role, team: invite.team };
}

export async function deleteExpiredInvites(): Promise<void> {
  await db.teamInvite.deleteMany({
    where: { expiresAt: { lte: new Date() } },
  });
}

export async function checkTeamPermission(
  teamId: string,
  userId: string,
  requiredRole: 'OWNER' | 'COLLABORATOR' | 'VIEWER',
): Promise<boolean> {
  const membership = await db.teamMember.findUnique({
    where: { teamId_userId: { teamId, userId } },
  });

  if (!membership) {
    return false;
  }

  return hasRequiredRole(membership.role, TeamRole[requiredRole]);
}

export async function getTeamProjects(
  teamId: string,
  userId: string,
): Promise<Project[]> {
  const team = await db.team.findUnique({ where: { id: teamId } });
  if (!team) {
    throw new TeamError('Team not found', 404);
  }

  const canView = await checkTeamPermission(teamId, userId, 'VIEWER');
  if (!canView) {
    throw new TeamError('Forbidden', 403);
  }

  return db.project.findMany({
    orderBy: { createdAt: 'desc' },
    where: { teamId },
  });
}
