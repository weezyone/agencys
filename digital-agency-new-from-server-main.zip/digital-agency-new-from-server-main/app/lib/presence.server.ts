import kv from './kv.server';

export type PresenceTab = 'ai' | 'git' | 'files' | 'downloads' | 'logs';

export interface PresenceUser {
  userId: string;
  name: string;
  color: string;
  activeTab: PresenceTab;
  lastSeen: number;
  cursor?: { x: number; y: number } | null;
}

const PRESENCE_COLORS = [
  '#6366f1',
  '#ec4899',
  '#14b8a6',
  '#f59e0b',
  '#10b981',
  '#ef4444',
  '#8b5cf6',
  '#06b6d4',
] as const;
const PRESENCE_TTL_SECONDS = 30;
const PRESENCE_UPDATE_TTL_SECONDS = 5;
const PRESENCE_STALE_MS = 15_000;

function getPresenceKey(projectId: string) {
  return `presence:${projectId}`;
}

function getPresenceUpdatesKey(projectId: string) {
  return `presence:updates:${projectId}`;
}

function parsePresenceUser(value: unknown): PresenceUser | null {
  if (typeof value === 'string') {
    try {
      return parsePresenceUser(JSON.parse(value));
    } catch {
      return null;
    }
  }

  if (!value || typeof value !== 'object') {
    return null;
  }

  const candidate = value as Partial<PresenceUser>;
  if (
    typeof candidate.userId !== 'string' ||
    typeof candidate.name !== 'string' ||
    typeof candidate.color !== 'string' ||
    typeof candidate.activeTab !== 'string' ||
    typeof candidate.lastSeen !== 'number'
  ) {
    return null;
  }

  return {
    activeTab: candidate.activeTab as PresenceTab,
    color: candidate.color,
    cursor:
      candidate.cursor &&
      typeof candidate.cursor === 'object' &&
      typeof candidate.cursor.x === 'number' &&
      typeof candidate.cursor.y === 'number'
        ? candidate.cursor
        : null,
    lastSeen: candidate.lastSeen,
    name: candidate.name,
    userId: candidate.userId,
  };
}

export function getUserColor(userId: string): string {
  const sum = Array.from(userId).reduce(
    (total, character) => total + character.charCodeAt(0),
    0,
  );

  return PRESENCE_COLORS[sum % PRESENCE_COLORS.length];
}

export async function heartbeat(
  projectId: string,
  user: PresenceUser,
): Promise<void> {
  const nextUser: PresenceUser = {
    ...user,
    activeTab: user.activeTab ?? 'ai',
    color: getUserColor(user.userId),
    cursor: user.cursor ?? null,
    lastSeen: user.lastSeen ?? Date.now(),
  };

  await kv.hset(
    getPresenceKey(projectId),
    nextUser.userId,
    JSON.stringify(nextUser),
  );
  await kv.expire(getPresenceKey(projectId), PRESENCE_TTL_SECONDS);
}

export async function getPresence(projectId: string): Promise<PresenceUser[]> {
  const entries =
    (await kv.hgetall<Record<string, unknown>>(getPresenceKey(projectId))) ?? {};
  const staleThreshold = Date.now() - PRESENCE_STALE_MS;

  return Object.values(entries)
    .map((entry) => parsePresenceUser(entry))
    .filter((entry): entry is PresenceUser => {
      if (!entry) {
        return false;
      }

      return entry.lastSeen >= staleThreshold;
    })
    .sort((left, right) => right.lastSeen - left.lastSeen);
}

export async function leavePresence(
  projectId: string,
  userId: string,
): Promise<void> {
  await kv.hdel(getPresenceKey(projectId), userId);
}

export async function publishPresenceUpdate(projectId: string): Promise<void> {
  const users = await getPresence(projectId);
  await kv.set(
    getPresenceUpdatesKey(projectId),
    JSON.stringify(users),
    { ex: PRESENCE_UPDATE_TTL_SECONDS },
  );
}
