export function apiRoute(
  handler: (request: Request) => Promise<Response> | Response,
) {
  return ({ request }: { request: Request }) => handler(request);
}
