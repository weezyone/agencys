import { Sandbox } from '@vercel/sandbox';
import { posix as pathPosix } from 'node:path';
import {
  createSandboxRecord,
  getSandboxBySandboxId,
  terminateSandboxBySandboxId,
  updateSandboxStatusBySandboxId,
} from './data.server';
import kv from './kv.server';

export interface SandboxConfig {
  vcpus?: number;
  memoryMb?: number;
  timeoutMinutes?: number;
  runtime?: 'node22' | 'python3.13';
  ports?: number[];
  repositoryUrl?: string;
  branch?: string;
}

export interface SandboxResult {
  id: string;
  sandboxId: string;
  domain: string;
  status: 'provisioning' | 'ready' | 'running' | 'terminated' | 'failed';
  configuration: SandboxConfig;
  createdAt: Date;
}

type SandboxStatus = SandboxResult['status'];
type SandboxLogEntry = { type: string; data: string; timestamp: number };
type SandboxCommandChunk = { type: 'stdout' | 'stderr'; data: string };
type SandboxCommandResult = {
  stdout: string;
  stderr: string;
  exitCode: number;
};

type SandboxCacheRecord = {
  id?: string;
  projectId?: string;
  sandboxId: string;
  domain: string;
  status: SandboxStatus;
  configuration: SandboxConfig;
  createdAt: string;
  mock?: boolean;
};

export type SandboxCommandExecution = {
  stream: AsyncGenerator<SandboxCommandChunk>;
  completed: Promise<SandboxCommandResult>;
};

const SANDBOX_INFO_TTL_SECONDS = 60 * 60;
const SANDBOX_LOG_TTL_SECONDS = 60 * 60;
const SANDBOX_LOG_LIMIT = 200;
const MOCK_FILES_TTL_SECONDS = 60 * 60;
const DEFAULT_PORTS = [3000];
const DEFAULT_WORKSPACE_DIR = '/vercel/sandbox/workspace';

function isMockSandboxMode() {
  return !process.env.VERCEL_TOKEN && process.env.NODE_ENV !== 'production';
}

function normalizeSandboxStatus(status: string): SandboxStatus {
  switch (status) {
    case 'ready':
      return 'ready';
    case 'running':
      return 'running';
    case 'terminated':
    case 'stopped':
    case 'stopping':
    case 'aborted':
      return 'terminated';
    case 'failed':
      return 'failed';
    case 'pending':
    case 'snapshotting':
    default:
      return 'provisioning';
  }
}

function normalizeConfig(
  config: SandboxConfig,
): Required<
  Pick<SandboxConfig, 'vcpus' | 'memoryMb' | 'timeoutMinutes' | 'runtime'>
> &
  SandboxConfig {
  const vcpus = config.vcpus ?? 2;
  const timeoutMinutes = config.timeoutMinutes ?? 5;

  return {
    ...config,
    memoryMb: config.memoryMb ?? vcpus * 2048,
    runtime: config.runtime ?? 'node22',
    timeoutMinutes,
    vcpus,
  };
}

function sandboxInfoKey(sandboxId: string) {
  return `sandbox:${sandboxId}:info`;
}

function sandboxLogsKey(sandboxId: string) {
  return `sandbox:${sandboxId}:logs`;
}

function sandboxFilesKey(sandboxId: string) {
  return `sandbox:${sandboxId}:files`;
}

function buildMockDomain(sandboxId: string) {
  return `https://${sandboxId}.sandbox.local`;
}

function toCacheRecord(
  result: SandboxResult,
  projectId?: string,
  mock?: boolean,
): SandboxCacheRecord {
  return {
    configuration: result.configuration,
    createdAt: result.createdAt.toISOString(),
    domain: result.domain,
    id: result.id,
    mock,
    projectId,
    sandboxId: result.sandboxId,
    status: result.status,
  };
}

function cacheToResult(cache: SandboxCacheRecord): SandboxResult {
  return {
    configuration: cache.configuration,
    createdAt: new Date(cache.createdAt),
    domain: cache.domain,
    id: cache.id ?? cache.sandboxId,
    sandboxId: cache.sandboxId,
    status: cache.status,
  };
}

async function cacheSandboxInfo(record: SandboxCacheRecord) {
  await kv.set(sandboxInfoKey(record.sandboxId), record, {
    ex: SANDBOX_INFO_TTL_SECONDS,
  });
}

async function getCachedSandboxInfo(sandboxId: string) {
  return kv.get<SandboxCacheRecord>(sandboxInfoKey(sandboxId));
}

function escapeShellArg(value: string) {
  return `'${value.replace(/'/g, `'\\''`)}'`;
}

function withAccessToken(repositoryUrl: string, accessToken?: string) {
  if (!accessToken) {
    return repositoryUrl;
  }

  try {
    const parsed = new URL(repositoryUrl);
    if (parsed.protocol !== 'https:') {
      return repositoryUrl;
    }

    parsed.username = parsed.hostname.includes('github.com')
      ? 'x-access-token'
      : 'oauth2';
    parsed.password = accessToken;
    return parsed.toString();
  } catch {
    return repositoryUrl;
  }
}

async function getSandboxHandle(sandboxId: string) {
  return Sandbox.get({ sandboxId });
}

async function getMockFiles(sandboxId: string) {
  return (
    (await kv.get<Record<string, string>>(sandboxFilesKey(sandboxId))) ?? {}
  );
}

async function setMockFiles(sandboxId: string, files: Record<string, string>) {
  await kv.set(sandboxFilesKey(sandboxId), files, {
    ex: MOCK_FILES_TTL_SECONDS,
  });
}

async function createMockSandbox(
  projectId: string,
  configuration: SandboxConfig,
) {
  const sandboxId = `mock-sandbox-${crypto.randomUUID()}`;
  const createdAt = new Date();
  const domain = buildMockDomain(sandboxId);
  const record = await createSandboxRecord(projectId, {
    configuration: configuration as Record<string, unknown>,
    sandboxId,
    status: 'ready',
  });

  const result: SandboxResult = {
    configuration,
    createdAt: record.createdAt,
    domain,
    id: record.id,
    sandboxId,
    status: 'ready',
  };

  await cacheSandboxInfo(toCacheRecord(result, projectId, true));
  await appendSandboxLog(sandboxId, {
    data: 'Sandbox created in mock mode.',
    timestamp: createdAt.getTime(),
    type: 'system',
  });

  if (configuration.repositoryUrl) {
    await initSandboxFromGit(
      sandboxId,
      configuration.repositoryUrl,
      configuration.branch ?? 'main',
    );
  }

  return result;
}

async function getRealSandboxDomain(
  sandbox: Awaited<ReturnType<typeof getSandboxHandle>>,
  ports?: number[],
) {
  const preferredPort = ports?.[0] ?? sandbox.routes[0]?.port;
  if (preferredPort) {
    try {
      return sandbox.domain(preferredPort);
    } catch {
      return (
        sandbox.routes.find((route) => route.port === preferredPort)?.url ??
        sandbox.routes[0]?.url ??
        ''
      );
    }
  }

  return sandbox.routes[0]?.url ?? '';
}

async function createRealSandbox(
  projectId: string,
  configuration: SandboxConfig,
) {
  const sandbox = await Sandbox.create({
    ports: configuration.ports ?? DEFAULT_PORTS,
    resources: { vcpus: configuration.vcpus! },
    runtime: configuration.runtime,
    timeout: configuration.timeoutMinutes! * 60 * 1000,
  });

  const domain = await getRealSandboxDomain(sandbox, configuration.ports);
  const record = await createSandboxRecord(projectId, {
    configuration: configuration as Record<string, unknown>,
    sandboxId: sandbox.sandboxId,
    status: 'provisioning',
  });

  const provisioned: SandboxResult = {
    configuration,
    createdAt: record.createdAt,
    domain,
    id: record.id,
    sandboxId: sandbox.sandboxId,
    status: 'provisioning',
  };

  await cacheSandboxInfo(toCacheRecord(provisioned, projectId));
  await appendSandboxLog(sandbox.sandboxId, {
    data: 'Sandbox created. Installing AI tools.',
    timestamp: Date.now(),
    type: 'system',
  });

  await executeSandboxCommand(
    sandbox.sandboxId,
    'npm install -g @anthropic-ai/claude-code 2>/dev/null || true\nnpm install -g openai 2>/dev/null || true',
  );

  if (configuration.repositoryUrl) {
    await initSandboxFromGit(
      sandbox.sandboxId,
      configuration.repositoryUrl,
      configuration.branch ?? 'main',
    );
  }

  await updateSandboxStatusBySandboxId(sandbox.sandboxId, 'ready');
  const readyResult: SandboxResult = { ...provisioned, status: 'ready' };
  await cacheSandboxInfo(toCacheRecord(readyResult, projectId));
  await appendSandboxLog(sandbox.sandboxId, {
    data: 'Sandbox ready.',
    timestamp: Date.now(),
    type: 'system',
  });

  return readyResult;
}

export async function createSandbox(
  projectId: string,
  config: SandboxConfig,
): Promise<SandboxResult> {
  const configuration = normalizeConfig(config);

  try {
    if (isMockSandboxMode()) {
      return await createMockSandbox(projectId, configuration);
    }

    return await createRealSandbox(projectId, configuration);
  } catch (error) {
    if (isMockSandboxMode()) {
      return createMockSandbox(projectId, configuration);
    }

    const message =
      error instanceof Error ? error.message : 'Unknown sandbox creation error';
    throw new Error(`Failed to create sandbox: ${message}`);
  }
}

export async function getSandboxStatus(
  sandboxId: string,
): Promise<{ status: string; domain?: string }> {
  const cached = await getCachedSandboxInfo(sandboxId);

  if (cached?.mock || isMockSandboxMode()) {
    return {
      domain: cached?.domain ?? buildMockDomain(sandboxId),
      status: cached?.status ?? 'ready',
    };
  }

  try {
    const sandbox = await getSandboxHandle(sandboxId);
    const status = normalizeSandboxStatus(sandbox.status);
    const domain = await getRealSandboxDomain(
      sandbox,
      cached?.configuration.ports,
    );
    const record: SandboxCacheRecord = {
      configuration: cached?.configuration ?? normalizeConfig({}),
      createdAt: cached?.createdAt ?? sandbox.createdAt.toISOString(),
      domain,
      id: cached?.id,
      mock: false,
      projectId: cached?.projectId,
      sandboxId,
      status,
    };

    await cacheSandboxInfo(record);
    await updateSandboxStatusBySandboxId(sandboxId, status);

    return { domain, status };
  } catch (error) {
    if (cached) {
      return { domain: cached.domain, status: cached.status };
    }

    const message =
      error instanceof Error ? error.message : 'Unknown sandbox status error';
    throw new Error(`Failed to get sandbox status: ${message}`);
  }
}

function createMockCommandExecution(
  sandboxId: string,
  command: string,
): SandboxCommandExecution {
  let consumed = false;
  const stdout = `Mock sandbox executed command: ${command}\n`;

  return {
    completed: Promise.resolve({ exitCode: 0, stderr: '', stdout }),
    stream: (async function* () {
      if (consumed) {
        return;
      }

      consumed = true;
      await appendSandboxLog(sandboxId, {
        data: stdout,
        timestamp: Date.now(),
        type: 'stdout',
      });
      yield { data: stdout, type: 'stdout' };
    })(),
  };
}

export async function runSandboxCommandStream(
  sandboxId: string,
  command: string,
  options?: { cwd?: string; env?: Record<string, string> },
): Promise<SandboxCommandExecution> {
  const cached = await getCachedSandboxInfo(sandboxId);
  if (cached?.mock || isMockSandboxMode()) {
    return createMockCommandExecution(sandboxId, command);
  }

  const sandbox = await getSandboxHandle(sandboxId);
  const runningCommand = await sandbox.runCommand({
    args: ['-lc', command],
    cmd: 'sh',
    cwd: options?.cwd,
    detached: true,
    env: options?.env,
  });

  let stdout = '';
  let stderr = '';
  let streamCompleted = false;
  let markComplete!: () => void;
  const streamCompletePromise = new Promise<void>((resolve) => {
    markComplete = resolve;
  });

  const stream = (async function* () {
    try {
      for await (const log of runningCommand.logs()) {
        const nextChunk: SandboxCommandChunk = {
          data: log.data,
          type: log.stream,
        };

        if (log.stream === 'stdout') {
          stdout += log.data;
        } else {
          stderr += log.data;
        }

        await appendSandboxLog(sandboxId, {
          data: log.data,
          timestamp: Date.now(),
          type: log.stream,
        });
        yield nextChunk;
      }
    } finally {
      if (!streamCompleted) {
        streamCompleted = true;
        markComplete();
      }
    }
  })();

  const completed = (async () => {
    await streamCompletePromise;
    const finished = await runningCommand.wait();
    await appendSandboxLog(sandboxId, {
      data: String(finished.exitCode),
      timestamp: Date.now(),
      type: 'exit',
    });

    return {
      exitCode: finished.exitCode,
      stderr,
      stdout,
    };
  })();

  return { completed, stream };
}

export async function executeSandboxCommand(
  sandboxId: string,
  command: string,
  options?: { cwd?: string; env?: Record<string, string> },
): Promise<SandboxCommandResult> {
  const execution = await runSandboxCommandStream(sandboxId, command, options);

  for await (const _chunk of execution.stream) {
    // Command output is buffered in the execution result.
  }

  return execution.completed;
}

export async function* streamSandboxCommand(
  sandboxId: string,
  command: string,
  options?: { cwd?: string; env?: Record<string, string> },
): AsyncGenerator<SandboxCommandChunk> {
  const execution = await runSandboxCommandStream(sandboxId, command, options);

  for await (const chunk of execution.stream) {
    yield chunk;
  }

  await execution.completed;
}

export async function terminateSandbox(sandboxId: string): Promise<void> {
  const cached = await getCachedSandboxInfo(sandboxId);

  if (!(cached?.mock || isMockSandboxMode())) {
    const sandbox = await getSandboxHandle(sandboxId);
    await sandbox.stop({ blocking: true });
  }

  await terminateSandboxBySandboxId(sandboxId);
  const nextCache: SandboxCacheRecord = {
    configuration: cached?.configuration ?? normalizeConfig({}),
    createdAt: cached?.createdAt ?? new Date().toISOString(),
    domain: cached?.domain ?? '',
    id: cached?.id,
    mock: cached?.mock ?? isMockSandboxMode(),
    projectId: cached?.projectId,
    sandboxId,
    status: 'terminated',
  };
  await cacheSandboxInfo(nextCache);
  await appendSandboxLog(sandboxId, {
    data: 'Sandbox terminated.',
    timestamp: Date.now(),
    type: 'system',
  });
}

export async function writeSandboxFile(
  sandboxId: string,
  path: string,
  content: string,
): Promise<void> {
  const cached = await getCachedSandboxInfo(sandboxId);
  if (cached?.mock || isMockSandboxMode()) {
    const files = await getMockFiles(sandboxId);
    files[path] = content;
    await setMockFiles(sandboxId, files);
    await appendSandboxLog(sandboxId, {
      data: `Wrote file ${path}`,
      timestamp: Date.now(),
      type: 'filesystem',
    });
    return;
  }

  const sandbox = await getSandboxHandle(sandboxId);
  const directory = pathPosix.dirname(path);
  if (directory && directory !== '.' && directory !== '/') {
    await sandbox.fs.mkdir(directory, { recursive: true });
  }
  await sandbox.fs.writeFile(path, content, 'utf8');
}

export async function readSandboxFile(
  sandboxId: string,
  path: string,
): Promise<string> {
  const cached = await getCachedSandboxInfo(sandboxId);
  if (cached?.mock || isMockSandboxMode()) {
    const files = await getMockFiles(sandboxId);
    return files[path] ?? '';
  }

  const sandbox = await getSandboxHandle(sandboxId);
  return sandbox.fs.readFile(path, 'utf8');
}

export async function listSandboxFiles(
  sandboxId: string,
  dirPath: string,
): Promise<string[]> {
  const cached = await getCachedSandboxInfo(sandboxId);
  if (cached?.mock || isMockSandboxMode()) {
    const files = await getMockFiles(sandboxId);
    const normalizedDir = dirPath.endsWith('/') ? dirPath : `${dirPath}/`;
    return Object.keys(files)
      .filter(
        (filePath) =>
          filePath === dirPath || filePath.startsWith(normalizedDir),
      )
      .map((filePath) => filePath.slice(normalizedDir.length))
      .filter(Boolean);
  }

  const sandbox = await getSandboxHandle(sandboxId);
  return sandbox.fs.readdir(dirPath);
}

export async function initSandboxFromGit(
  sandboxId: string,
  repositoryUrl: string,
  branch: string,
  accessToken?: string,
): Promise<void> {
  const cached = await getCachedSandboxInfo(sandboxId);
  const sanitizedUrl = withAccessToken(repositoryUrl, accessToken);

  if (cached?.mock || isMockSandboxMode()) {
    const files = await getMockFiles(sandboxId);
    files[`${DEFAULT_WORKSPACE_DIR}/.gitrepo`] = JSON.stringify({
      branch,
      repositoryUrl,
    });
    await setMockFiles(sandboxId, files);
    await appendSandboxLog(sandboxId, {
      data: `Initialized mock repository from ${repositoryUrl}@${branch}`,
      timestamp: Date.now(),
      type: 'git',
    });
    return;
  }

  await executeSandboxCommand(
    sandboxId,
    [
      `rm -rf ${escapeShellArg(DEFAULT_WORKSPACE_DIR)}`,
      `git clone --branch ${escapeShellArg(branch)} --single-branch ${escapeShellArg(sanitizedUrl)} ${escapeShellArg(DEFAULT_WORKSPACE_DIR)}`,
    ].join(' && '),
  );
}

export async function appendSandboxLog(
  sandboxId: string,
  entry: SandboxLogEntry,
): Promise<void> {
  const key = sandboxLogsKey(sandboxId);
  const existingLogs = (await kv.get<SandboxLogEntry[]>(key)) ?? [];
  const nextLogs = [...existingLogs, entry].slice(-SANDBOX_LOG_LIMIT);
  await kv.set(key, nextLogs, { ex: SANDBOX_LOG_TTL_SECONDS });
}

export async function getSandboxLogs(
  sandboxId: string,
): Promise<SandboxLogEntry[]> {
  return (await kv.get<SandboxLogEntry[]>(sandboxLogsKey(sandboxId))) ?? [];
}

export async function getSandboxResultBySandboxId(
  sandboxId: string,
): Promise<SandboxResult | null> {
  const cached = await getCachedSandboxInfo(sandboxId);
  if (cached) {
    return cacheToResult(cached);
  }

  const record = await getSandboxBySandboxId(sandboxId);
  if (!record) {
    return null;
  }

  const configuration = (record.configuration ?? {}) as SandboxConfig;
  const domain = '';
  const result: SandboxResult = {
    configuration,
    createdAt: record.createdAt,
    domain,
    id: record.id,
    sandboxId: record.sandboxId,
    status: normalizeSandboxStatus(record.status),
  };
  await cacheSandboxInfo(toCacheRecord(result, record.projectId));
  return result;
}
