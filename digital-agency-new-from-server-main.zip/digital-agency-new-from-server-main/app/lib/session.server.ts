import { createCookieSessionStorage, redirect } from 'react-router';
import { trackEvent } from './analytics.server';
import { checkNotBanned } from './ban-check.server';

export type AuthProviderId = 'github' | 'gitlab' | 'email';

export interface SessionData {
  userId: string;
  email: string;
  name: string;
  avatarUrl?: string;
  accessToken: string;
  provider: AuthProviderId;
  expiresAt: number;
}

interface SessionCookieData extends Partial<SessionData> {
  oauthState?: string;
  pkceCodeVerifier?: string;
  redirectTo?: string;
  csrfToken?: string;
  githubAppInstallationId?: string;
  githubAppOauthToken?: string;
}

export const sessionStorage = createCookieSessionStorage<SessionCookieData>({
  cookie: {
    name: '__cdp_session',
    httpOnly: true,
    path: '/',
    sameSite: 'lax',
    secrets: [process.env.SESSION_SECRET || 'dev-secret-change-in-production'],
    secure: process.env.NODE_ENV === 'production',
    maxAge: 60 * 60 * 24,
  },
});

function toSessionData(raw: SessionCookieData): SessionData | null {
  if (
    typeof raw.userId !== 'string' ||
    typeof raw.email !== 'string' ||
    typeof raw.name !== 'string' ||
    typeof raw.accessToken !== 'string' ||
    (raw.provider !== 'github' &&
      raw.provider !== 'gitlab' &&
      raw.provider !== 'email') ||
    typeof raw.expiresAt !== 'number' ||
    raw.expiresAt <= Date.now()
  ) {
    return null;
  }

  return {
    userId: raw.userId,
    email: raw.email,
    name: raw.name,
    avatarUrl: typeof raw.avatarUrl === 'string' ? raw.avatarUrl : undefined,
    accessToken: raw.accessToken,
    provider: raw.provider,
    expiresAt: raw.expiresAt,
  };
}

export async function getSession(
  request: Request,
): Promise<SessionData | null> {
  const session = await sessionStorage.getSession(
    request.headers.get('Cookie'),
  );

  return toSessionData({
    userId: session.get('userId'),
    email: session.get('email'),
    name: session.get('name'),
    avatarUrl: session.get('avatarUrl'),
    accessToken: session.get('accessToken'),
    provider: session.get('provider'),
    expiresAt: session.get('expiresAt'),
  });
}

export async function requireAuth(request: Request): Promise<SessionData> {
  const user = await getSession(request);
  if (user) {
    await checkNotBanned(user.userId);
    return user;
  }

  const url = new URL(request.url);
  const redirectTo = `${url.pathname}${url.search}`;
  throw redirect(`/auth/login?redirectTo=${encodeURIComponent(redirectTo)}`);
}

export async function getOptionalAuth(
  request: Request,
): Promise<SessionData | null> {
  return getSession(request);
}

export async function createUserSession(
  userData: SessionData,
  redirectTo: string,
) {
  const session = await sessionStorage.getSession();

  session.set('userId', userData.userId);
  session.set('email', userData.email);
  session.set('name', userData.name);
  if (userData.avatarUrl) {
    session.set('avatarUrl', userData.avatarUrl);
  } else {
    session.unset('avatarUrl');
  }
  session.set('accessToken', userData.accessToken);
  session.set('provider', userData.provider);
  session.set('expiresAt', userData.expiresAt);

  if (userData.provider === 'github' || userData.provider === 'gitlab') {
    void trackEvent(userData.userId, 'user.session', {
      provider: userData.provider,
    });
  }

  return redirect(redirectTo, {
    headers: {
      'Set-Cookie': await sessionStorage.commitSession(session),
    },
  });
}

export async function destroySession(
  request: Request,
  redirectTo: string = '/',
) {
  const session = await sessionStorage.getSession(
    request.headers.get('Cookie'),
  );

  return redirect(redirectTo, {
    headers: {
      'Set-Cookie': await sessionStorage.destroySession(session),
    },
  });
}
