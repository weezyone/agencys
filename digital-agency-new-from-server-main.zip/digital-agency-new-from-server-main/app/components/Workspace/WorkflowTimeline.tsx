'use client';

import { useMemo } from 'react';
import { useWorkflowStream } from '~/hooks/useSSE';
import { useWorkflow } from '~/hooks/useWorkflow';
import type { WorkflowStep } from '~/types';
import { Button, Card, StatusIndicator } from '~/components/ui';
import { cn } from '~/lib/utils';

interface WorkflowTimelineProps {
  workflowId?: string;
  initialSteps?: WorkflowStep[];
}

function getDuration(step: WorkflowStep) {
  if (!step.startedAt) {
    return '—';
  }
  const start = new Date(step.startedAt).getTime();
  const end = step.completedAt
    ? new Date(step.completedAt).getTime()
    : Date.now();
  return `${Math.max(1, Math.round((end - start) / 1000))}s`;
}

function StepStateIcon({ status }: { status: WorkflowStep['status'] }) {
  if (status === 'completed')
    return <span className="text-emerald-400">✓</span>;
  if (status === 'failed') return <span className="text-red-400">✕</span>;
  if (status === 'running')
    return (
      <span className="h-4 w-4 animate-spin rounded-full border-2 border-amber-400 border-t-transparent" />
    );
  return <span className="text-gray-500">•</span>;
}

export function WorkflowTimeline({
  initialSteps,
  workflowId,
}: WorkflowTimelineProps) {
  const workflowState = useWorkflow(initialSteps ? undefined : workflowId);
  const stream = useWorkflowStream(initialSteps ? null : (workflowId ?? null));
  const steps = initialSteps ?? workflowState.steps;
  const completedCount = steps.filter(
    (step) => step.status === 'completed',
  ).length;
  const progress = steps.length
    ? Math.round((completedCount / steps.length) * 100)
    : 0;
  const overallStatus = useMemo(() => {
    if (steps.some((step) => step.status === 'failed')) return 'error';
    if (steps.some((step) => step.status === 'running')) return 'running';
    if (completedCount === steps.length && steps.length > 0) return 'connected';
    return 'idle';
  }, [completedCount, steps]);

  return (
    <Card
      actions={
        <StatusIndicator
          label={stream.connected ? 'Live stream' : 'Polling'}
          status={stream.connected ? overallStatus : 'idle'}
        />
      }
      description="Step-by-step workflow execution across the current project."
      title="Workflow timeline"
    >
      <div className="mb-4 space-y-2">
        <div className="flex items-center justify-between text-xs text-gray-400">
          <span>Overall progress</span>
          <span>{progress}%</span>
        </div>
        <div className="h-2 rounded-full bg-gray-800">
          <div
            className="h-2 rounded-full bg-indigo-500 transition-all"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {steps.length === 0 ? (
        <div className="rounded-xl border border-dashed border-gray-800 px-6 py-10 text-center text-sm text-gray-400">
          No workflow steps yet.
        </div>
      ) : (
        <ol className="space-y-3">
          {steps.map((step) => (
            <li
              key={step.id}
              className="rounded-xl border border-gray-800 bg-gray-800/40 p-4"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="min-w-0">
                  <div className="flex items-center gap-3">
                    <StepStateIcon status={step.status} />
                    <p className="text-sm font-medium text-gray-100">
                      {step.name}
                    </p>
                  </div>
                  <p className="mt-2 text-xs text-gray-400">
                    Duration: {getDuration(step)}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span
                    className={cn(
                      'rounded-full px-2.5 py-1 text-xs font-medium capitalize',
                      step.status === 'completed' &&
                        'bg-emerald-500/10 text-emerald-200',
                      step.status === 'failed' && 'bg-red-500/10 text-red-200',
                      step.status === 'running' &&
                        'bg-amber-500/10 text-amber-200',
                      step.status === 'pending' && 'bg-gray-800 text-gray-300',
                    )}
                  >
                    {step.status}
                  </span>
                  {step.status === 'failed' ? (
                    <Button
                      onClick={() => window.location.reload()}
                      size="sm"
                      variant="secondary"
                    >
                      Retry
                    </Button>
                  ) : null}
                </div>
              </div>
            </li>
          ))}
        </ol>
      )}
    </Card>
  );
}
