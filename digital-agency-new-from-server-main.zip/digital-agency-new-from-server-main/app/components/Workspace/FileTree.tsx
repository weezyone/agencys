'use client';

import { useEffect, useMemo, useState } from 'react';
import {
  buildFileTree,
  useFileTree,
  type FileTreeNode,
} from '~/hooks/useFileTree';
import { Button, Card } from '~/components/ui';
import { cn } from '~/lib/utils';

interface FileTreeProps {
  sandboxId?: string;
  onSelectionChange?: (paths: string[]) => void;
  changedPaths?: string[];
}

const extensionIcons: Record<string, string> = {
  js: '🟨',
  json: '🟫',
  md: '📝',
  py: '🐍',
  ts: '🔷',
  tsx: '⚛️',
};

function getIcon(name: string, type: FileTreeNode['type']) {
  if (type === 'directory') {
    return '📁';
  }
  const extension = name.split('.').pop()?.toLowerCase() ?? '';
  return extensionIcons[extension] ?? '📄';
}

function TreeRow({
  depth = 0,
  isExpanded,
  isSelected,
  node,
  onSelect,
  resolveExpanded,
  resolveSelected,
  toggleExpanded,
  toggleSelected,
}: {
  node: FileTreeNode;
  depth?: number;
  isExpanded: boolean;
  isSelected: boolean;
  onSelect: (path: string) => void;
  resolveExpanded: (path: string) => boolean;
  resolveSelected: (path: string) => boolean;
  toggleExpanded: (path: string) => void;
  toggleSelected: (path: string) => void;
}) {
  return (
    <li>
      <div
        className={cn(
          'flex items-center gap-2 rounded-lg px-2 py-2 text-sm text-gray-200 transition hover:bg-gray-800/70',
          isSelected && 'bg-gray-800 text-white',
        )}
        style={{ paddingLeft: `${depth * 14 + 8}px` }}
      >
        {node.type === 'directory' ? (
          <button
            className="text-xs text-gray-400"
            onClick={() => toggleExpanded(node.path)}
            type="button"
          >
            {isExpanded ? '▾' : '▸'}
          </button>
        ) : (
          <input
            checked={isSelected}
            onChange={() => toggleSelected(node.path)}
            type="checkbox"
          />
        )}
        <button
          className="flex min-w-0 flex-1 items-center gap-2 text-left"
          onClick={() =>
            node.type === 'directory'
              ? toggleExpanded(node.path)
              : onSelect(node.path)
          }
          type="button"
        >
          <span>{getIcon(node.name, node.type)}</span>
          <span className="truncate">{node.name}</span>
          {node.changed ? (
            <span
              className="h-2 w-2 rounded-full bg-amber-500"
              title="Changed file"
            />
          ) : null}
        </button>
      </div>
      {node.type === 'directory' && isExpanded && node.children?.length ? (
        <ul className="space-y-1">
          {node.children.map((child) => (
            <TreeRow
              depth={depth + 1}
              isExpanded={resolveExpanded(child.path)}
              isSelected={resolveSelected(child.path)}
              key={child.path}
              node={child}
              onSelect={onSelect}
              resolveExpanded={resolveExpanded}
              resolveSelected={resolveSelected}
              toggleExpanded={toggleExpanded}
              toggleSelected={toggleSelected}
            />
          ))}
        </ul>
      ) : null}
    </li>
  );
}

export function FileTree({
  changedPaths = [],
  onSelectionChange,
  sandboxId,
}: FileTreeProps) {
  const [nodes, setNodes] = useState<FileTreeNode[]>([]);
  const [loading, setLoading] = useState(Boolean(sandboxId));
  const [error, setError] = useState<string | null>(null);
  const tree = useFileTree(nodes.length > 0 ? nodes : undefined);

  useEffect(() => {
    onSelectionChange?.(tree.selectedPaths);
  }, [onSelectionChange, tree.selectedPaths]);

  useEffect(() => {
    if (!sandboxId) {
      return;
    }

    let active = true;
    const loadTree = async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await fetch(
          `/api/sandbox/${sandboxId}/files?path=/vercel/sandbox/workspace`,
        );
        const payload = (await response.json()) as {
          error?: string;
          files?: string[];
        };
        if (!response.ok) {
          throw new Error(payload.error ?? 'Unable to load files');
        }
        if (active) {
          const resolvedPaths = payload.files?.length
            ? payload.files
            : ['src/index.ts', 'src/agent.ts', 'README.md'];
          setNodes(
            buildFileTree(
              resolvedPaths,
              changedPaths.length ? changedPaths : resolvedPaths.slice(0, 1),
            ),
          );
        }
      } catch (nextError) {
        if (active) {
          setError(
            nextError instanceof Error
              ? nextError.message
              : 'Unable to load files',
          );
        }
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    };

    void loadTree();
    return () => {
      active = false;
    };
  }, [changedPaths, sandboxId]);

  const activeNodes = useMemo(
    () => (nodes.length > 0 ? nodes : tree.tree),
    [nodes, tree.tree],
  );
  const resolveSelected = (path: string) =>
    tree.isSelected(path) || tree.selectedPath === path;

  const handleDownload = async () => {
    if (tree.selectedPaths.length === 0) {
      return;
    }

    const payload: Record<string, string> = {};
    if (sandboxId) {
      for (const path of tree.selectedPaths) {
        const response = await fetch(
          `/api/sandbox/${sandboxId}/files?path=${encodeURIComponent(`/vercel/sandbox/workspace/${path}`)}&read=true`,
        );
        const content = (await response.json()) as { content?: string };
        payload[path] = content.content ?? '';
      }
    } else {
      tree.selectedPaths.forEach((path) => {
        payload[path] = '// file export placeholder';
      });
    }

    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = 'selected-files.json';
    anchor.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Card
      actions={
        <Button
          disabled={tree.selectedPaths.length === 0}
          onClick={handleDownload}
          size="sm"
          variant="secondary"
        >
          Download Selected
        </Button>
      }
      description="Browse the current sandbox workspace and prepare exports."
      title="File browser"
    >
      {loading ? (
        <div className="animate-pulse rounded-xl border border-gray-800 bg-gray-800/40 px-4 py-10 text-sm text-gray-500">
          Loading file tree…
        </div>
      ) : null}
      {error ? (
        <div className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-200">
          {error}
        </div>
      ) : null}
      {!loading ? (
        <ul className="space-y-1">
          {activeNodes.map((node) => (
            <TreeRow
              isExpanded={tree.isExpanded(node.path)}
              isSelected={resolveSelected(node.path)}
              key={node.path}
              node={node}
              onSelect={tree.setSelectedPath}
              resolveExpanded={tree.isExpanded}
              resolveSelected={resolveSelected}
              toggleExpanded={tree.toggleExpanded}
              toggleSelected={tree.toggleSelected}
            />
          ))}
        </ul>
      ) : null}
    </Card>
  );
}
