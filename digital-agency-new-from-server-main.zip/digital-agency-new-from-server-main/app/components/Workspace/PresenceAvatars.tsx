'use client';

import { usePresence } from '~/hooks/usePresence';

interface PresenceAvatarsProps {
  projectId: string;
  currentUser: { id: string; name: string };
}

function getInitial(name: string) {
  return name.trim().charAt(0).toUpperCase() || '?';
}

export function PresenceAvatars({
  projectId,
  currentUser,
}: PresenceAvatarsProps) {
  const { count, users } = usePresence(projectId, currentUser);

  if (count <= 1 || users.length === 0) {
    return null;
  }

  const visibleUsers = users.slice(0, 4);
  const overflow = Math.max(0, users.length - visibleUsers.length);

  return (
    <div className="flex items-center justify-end" data-testid="presence-avatars">
      {visibleUsers.map((user, index) => (
        <div
          key={user.userId}
          className={`group relative flex transition-all duration-200 ${index > 0 ? '-ml-2' : ''}`}
        >
          <div
            className="flex h-8 w-8 items-center justify-center rounded-full border-2 border-gray-900 text-xs font-semibold text-white shadow transition-opacity duration-200"
            data-testid={`presence-avatar-${user.userId}`}
            style={{ backgroundColor: user.color }}
          >
            {getInitial(user.name)}
          </div>
          <div className="pointer-events-none absolute left-1/2 top-full z-10 mt-2 hidden -translate-x-1/2 whitespace-nowrap rounded-md border border-gray-700 bg-gray-900 px-2 py-1 text-xs text-gray-100 shadow-lg group-hover:block">
            {user.name} active on {user.activeTab} tab
          </div>
        </div>
      ))}
      {overflow > 0 ? (
        <div className="-ml-2 flex h-8 min-w-8 items-center justify-center rounded-full border-2 border-gray-900 bg-gray-800 px-2 text-xs font-semibold text-gray-100 shadow">
          +{overflow}
        </div>
      ) : null}
    </div>
  );
}
