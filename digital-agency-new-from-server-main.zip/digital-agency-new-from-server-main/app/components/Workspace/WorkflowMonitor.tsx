'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import type { WorkflowStep } from '~/types';
import { Card } from '~/components/ui';
import { WorkflowTimeline } from '~/components/Workspace/WorkflowTimeline';
import { formatRelativeTime } from '~/lib/utils';

interface WorkflowRunSummary {
  id: string;
  name: string;
  status: string;
  updatedAt: string;
}

interface WorkflowMonitorProps {
  activeWorkflowId?: string;
  projectId: string;
  recentRuns?: WorkflowRunSummary[];
  sandboxId?: string;
}

interface WorkflowPayload {
  recentEvents?: Array<{
    data?: Record<string, unknown>;
    message?: string;
    timestamp?: number;
    type?: string;
  }>;
  steps?: Array<{
    completedAt?: string | Date | null;
    id: string;
    outputs?: Record<string, unknown> | null;
    retryCount?: number;
    startedAt?: string | Date | null;
    status: string;
    stepName?: string;
  }>;
  workflow?: { id: string; status: string };
}

export function WorkflowMonitor({
  activeWorkflowId,
  projectId: _projectId,
  recentRuns = [],
  sandboxId,
}: WorkflowMonitorProps) {
  const [payload, setPayload] = useState<WorkflowPayload | null>(null);
  const [error, setError] = useState('');
  const [resourceUsage, setResourceUsage] = useState<{
    cpu?: number;
    memoryMb?: number;
    status?: string;
  }>({});

  const loadWorkflow = useCallback(async () => {
    if (!activeWorkflowId) {
      return;
    }

    try {
      const response = await fetch(`/api/workflow/${activeWorkflowId}`);
      const data = (await response.json()) as WorkflowPayload & {
        error?: string;
      };
      if (!response.ok) {
        throw new Error(data.error ?? 'Unable to load workflow');
      }
      setPayload(data);
      setError('');
    } catch (loadError) {
      setError(
        loadError instanceof Error
          ? loadError.message
          : 'Unable to load workflow',
      );
    }
  }, [activeWorkflowId]);

  useEffect(() => {
    if (!activeWorkflowId) {
      return;
    }

    void loadWorkflow();
    const timer = window.setInterval(() => {
      void loadWorkflow();
    }, 5000);
    return () => window.clearInterval(timer);
  }, [activeWorkflowId, loadWorkflow]);

  useEffect(() => {
    if (!sandboxId) {
      return;
    }

    let active = true;
    const loadSandbox = async () => {
      try {
        const response = await fetch(`/api/sandbox/${sandboxId}`);
        const data = (await response.json()) as {
          configuration?: { memoryMb?: number; vcpus?: number };
          status?: string;
        };
        if (response.ok && active) {
          setResourceUsage({
            cpu: data.configuration?.vcpus,
            memoryMb: data.configuration?.memoryMb,
            status: data.status,
          });
        }
      } catch {
        // Silent resource fallback.
      }
    };

    void loadSandbox();
    return () => {
      active = false;
    };
  }, [sandboxId]);

  const normalizedSteps = useMemo<WorkflowStep[]>(
    () =>
      (payload?.steps ?? []).map((step) => ({
        completedAt: step.completedAt ? new Date(step.completedAt) : undefined,
        id: step.id,
        inputs: {},
        name: step.stepName ?? 'Workflow step',
        outputs: step.outputs ?? undefined,
        retryCount: step.retryCount ?? 0,
        startedAt: step.startedAt ? new Date(step.startedAt) : undefined,
        status:
          step.status.toLowerCase() === 'completed'
            ? 'completed'
            : step.status.toLowerCase() === 'failed'
              ? 'failed'
              : step.status.toLowerCase() === 'running' ||
                  step.status.toLowerCase() === 'retrying'
                ? 'running'
                : 'pending',
      })),
    [payload?.steps],
  );
  const failedStep = normalizedSteps.find((step) => step.status === 'failed');

  const handleCancel = async () => {
    if (!activeWorkflowId) {
      return;
    }
    await fetch(`/api/workflow/${activeWorkflowId}`, { method: 'DELETE' });
    await loadWorkflow();
  };

  return (
    <Card
      title="Workflow monitor"
      description="Keep an eye on the active workflow, failures, retries, and recent runs."
    >
      <div className="space-y-4">
        {activeWorkflowId ? (
          <WorkflowTimeline workflowId={activeWorkflowId} />
        ) : (
          <div className="text-sm text-gray-500">No active workflow.</div>
        )}

        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => void loadWorkflow()}
            className="rounded-lg border border-gray-700 bg-gray-900 px-3 py-2 text-sm text-gray-100"
          >
            Retry Failed Step
          </button>
          <button
            type="button"
            onClick={() => void handleCancel()}
            className="rounded-lg border border-red-500/50 bg-red-950/30 px-3 py-2 text-sm text-red-200"
          >
            Cancel Workflow
          </button>
        </div>

        {failedStep ? (
          <details className="rounded-xl border border-red-500/40 bg-red-950/20 p-4">
            <summary className="cursor-pointer text-sm font-medium text-red-200">
              Error details: {failedStep.name}
            </summary>
            <pre className="mt-3 overflow-auto whitespace-pre-wrap text-xs text-red-100">
              {JSON.stringify(
                failedStep.outputs ?? { message: 'No stack trace available.' },
                null,
                2,
              )}
            </pre>
          </details>
        ) : null}

        {error ? (
          <div className="rounded-lg border border-red-500 bg-red-950/30 px-3 py-2 text-sm text-red-200">
            {error}
          </div>
        ) : null}

        <div className="rounded-xl border border-gray-800 bg-gray-950 p-4">
          <div className="mb-2 text-xs uppercase tracking-wide text-gray-500">
            Recent workflow runs
          </div>
          {recentRuns.length > 0 ? (
            <div className="space-y-2">
              {recentRuns.slice(0, 5).map((run) => (
                <div
                  key={run.id}
                  className="flex items-center justify-between rounded-lg border border-gray-800 px-3 py-2 text-sm text-gray-300"
                >
                  <div>
                    <div>{run.name}</div>
                    <div className="text-xs text-gray-500">
                      {formatRelativeTime(new Date(run.updatedAt))}
                    </div>
                  </div>
                  <span
                    className={
                      run.status === 'failed'
                        ? 'text-red-300'
                        : run.status === 'completed'
                          ? 'text-emerald-300'
                          : 'text-sky-300'
                    }
                  >
                    {run.status}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-sm text-gray-500">
              No historical workflows yet.
            </div>
          )}
        </div>

        <div className="rounded-xl border border-gray-800 bg-gray-950 p-4 text-sm text-gray-300">
          <div className="mb-2 text-xs uppercase tracking-wide text-gray-500">
            Resource usage
          </div>
          <div>Sandbox status: {resourceUsage.status ?? 'Unavailable'}</div>
          <div className="mt-1">CPU: {resourceUsage.cpu ?? '—'} vCPU</div>
          <div className="mt-1">Memory: {resourceUsage.memoryMb ?? '—'} MB</div>
        </div>
      </div>
    </Card>
  );
}
