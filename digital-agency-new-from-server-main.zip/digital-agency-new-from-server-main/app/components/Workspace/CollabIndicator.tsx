'use client';

interface CollabIndicatorProps {
  count: number;
}

export function CollabIndicator({ count }: CollabIndicatorProps) {
  if (count <= 1) {
    return null;
  }

  return (
    <div className="inline-flex items-center gap-2 text-sm text-emerald-300">
      <span aria-hidden="true">🟢</span>
      <span>{count} online</span>
    </div>
  );
}
