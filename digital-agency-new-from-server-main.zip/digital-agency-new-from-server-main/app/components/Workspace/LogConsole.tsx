'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { useSandboxStream, useWorkflowStream } from '../../hooks/useSSE';
import { cn } from '../../lib/utils';
import { Button, Card, CardContent, CardHeader, CardTitle } from '../ui';

interface LogConsoleProps {
  sandboxId?: string;
  workflowId?: string;
  className?: string;
}

type ConsoleEntry = {
  id: string;
  level: 'stdout' | 'stderr' | 'info' | 'warn' | 'error';
  message: string;
  timestamp: number;
};

const ROW_HEIGHT = 24;
const OVERSCAN = 8;
const colorMap: Record<ConsoleEntry['level'], string> = {
  error: 'text-rose-300',
  info: 'text-sky-300',
  stderr: 'text-rose-300',
  stdout: 'text-gray-100',
  warn: 'text-amber-300',
};

function formatTimestamp(timestamp: number) {
  return new Date(timestamp).toLocaleTimeString();
}

function stringifyValue(value: unknown) {
  if (typeof value === 'string') {
    return value;
  }

  try {
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}

export function LogConsole({
  className,
  sandboxId,
  workflowId,
}: LogConsoleProps) {
  const [clearCount, setClearCount] = useState(0);
  const [scrollTop, setScrollTop] = useState(0);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const sandboxStream = useSandboxStream(sandboxId ?? null);
  const workflowStream = useWorkflowStream(workflowId ?? null);
  const activeState = sandboxId ? sandboxStream : workflowStream;

  const entries = useMemo<ConsoleEntry[]>(() => {
    if (sandboxId) {
      return sandboxStream.logs.map((log) => ({
        id: log.id,
        level:
          log.type === 'stderr'
            ? 'stderr'
            : log.type === 'exit'
              ? 'info'
              : 'stdout',
        message:
          log.type === 'exit'
            ? `Process exited with code ${log.exitCode ?? 0}`
            : (log.data ?? ''),
        timestamp: log.timestamp ?? Date.now(),
      }));
    }

    return workflowStream.events.flatMap((event, index) => {
      const timestamp =
        typeof event.data.timestamp === 'number'
          ? event.data.timestamp
          : Date.now();

      switch (event.type) {
        case 'log':
          return {
            id: event.id ?? `${event.type}-${index}`,
            level:
              event.data.level === 'warn'
                ? 'warn'
                : event.data.level === 'error'
                  ? 'error'
                  : 'info',
            message:
              typeof event.data.message === 'string'
                ? event.data.message
                : stringifyValue(event.data),
            timestamp,
          };
        case 'step_started':
          return {
            id: event.id ?? `${event.type}-${index}`,
            level: 'info',
            message: `Started ${String(event.data.stepName ?? 'workflow step')}`,
            timestamp,
          };
        case 'step_completed':
          return {
            id: event.id ?? `${event.type}-${index}`,
            level: 'info',
            message: `Completed ${String(event.data.stepName ?? 'workflow step')}`,
            timestamp,
          };
        case 'step_failed':
          return {
            id: event.id ?? `${event.type}-${index}`,
            level: 'error',
            message: `Failed ${String(event.data.stepName ?? 'workflow step')}: ${stringifyValue(event.data.error ?? 'Unknown error')}`,
            timestamp,
          };
        case 'workflow_completed':
          return {
            id: event.id ?? `${event.type}-${index}`,
            level: 'info',
            message: `Workflow ${String(event.data.workflowId ?? workflowId ?? '')} completed`,
            timestamp,
          };
        case 'workflow_failed':
          return {
            id: event.id ?? `${event.type}-${index}`,
            level: 'error',
            message: `Workflow ${String(event.data.workflowId ?? workflowId ?? '')} failed: ${stringifyValue(event.data.error ?? 'Unknown error')}`,
            timestamp,
          };
        default:
          return [];
      }
    });
  }, [sandboxId, sandboxStream.logs, workflowId, workflowStream.events]);

  useEffect(() => {
    setClearCount(0);
  }, [sandboxId, workflowId]);

  const visibleLogs = entries.slice(clearCount);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) {
      return;
    }

    const nearBottom =
      container.scrollHeight - container.scrollTop - container.clientHeight <
      ROW_HEIGHT * 3;
    if (nearBottom) {
      container.scrollTop = container.scrollHeight;
      setScrollTop(container.scrollTop);
    }
  }, [visibleLogs.length]);

  const visibleCount = 24;
  const startIndex = Math.max(0, Math.floor(scrollTop / ROW_HEIGHT) - OVERSCAN);
  const endIndex = Math.min(
    visibleLogs.length,
    startIndex + visibleCount + OVERSCAN * 2,
  );
  const windowedEntries = visibleLogs.slice(startIndex, endIndex);
  const paddingTop = startIndex * ROW_HEIGHT;
  const paddingBottom = Math.max(
    0,
    (visibleLogs.length - endIndex) * ROW_HEIGHT,
  );

  const handleCopy = async () => {
    if (typeof navigator === 'undefined' || !navigator.clipboard) {
      return;
    }

    await navigator.clipboard.writeText(
      visibleLogs
        .map(
          (entry) =>
            `[${formatTimestamp(entry.timestamp)}] ${entry.level.toUpperCase()} ${entry.message}`,
        )
        .join('\n'),
    );
  };

  return (
    <Card className={cn('min-h-[24rem]', className)}>
      <CardHeader>
        <div className="flex items-center gap-3">
          <CardTitle>Execution log</CardTitle>
          <span className="inline-flex items-center gap-2 text-xs text-gray-400">
            <span
              className={cn(
                'h-2.5 w-2.5 rounded-full',
                activeState.connected ? 'bg-emerald-400' : 'bg-rose-400',
              )}
            />
            {activeState.connected ? 'Connected' : 'Disconnected'}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={handleCopy} type="button" variant="ghost">
            Copy
          </Button>
          <Button
            onClick={() => setClearCount(entries.length)}
            type="button"
            variant="ghost"
          >
            Clear
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between text-xs text-gray-500">
          <span>{visibleLogs.length} entries</span>
          {activeState.error ? (
            <span className="text-rose-300">{activeState.error}</span>
          ) : null}
        </div>
        <div
          className="mt-3 h-80 overflow-y-auto rounded-xl border border-gray-800 bg-black/70 p-3 font-mono text-xs"
          onScroll={(event) => setScrollTop(event.currentTarget.scrollTop)}
          ref={containerRef}
        >
          {visibleLogs.length === 0 ? (
            <div className="text-gray-500">Waiting for stream output…</div>
          ) : (
            <div style={{ paddingBottom, paddingTop }}>
              {windowedEntries.map((entry) => (
                <div
                  key={entry.id}
                  className="grid min-h-6 grid-cols-[88px_64px_1fr] gap-3 leading-6"
                >
                  <span className="text-gray-500">
                    {formatTimestamp(entry.timestamp)}
                  </span>
                  <span className={cn('uppercase', colorMap[entry.level])}>
                    {entry.level}
                  </span>
                  <span
                    className={cn(
                      'whitespace-pre-wrap break-words',
                      colorMap[entry.level],
                    )}
                  >
                    {entry.message}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
