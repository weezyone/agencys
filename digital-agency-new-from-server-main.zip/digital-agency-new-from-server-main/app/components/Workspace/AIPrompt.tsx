'use client';

import type { FormEvent } from 'react';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useAIStream } from '~/hooks/useAIStream';
import { Button, Card } from '~/components/ui';
import { cn } from '~/lib/utils';

interface AIPromptProps {
  projectId: string;
  sandboxId?: string;
  onTaskComplete?: (content: string) => void;
}

const taskTypes = ['generate', 'refactor', 'test', 'debug'] as const;
const providerOptions = [
  'nvidia',
  'huggingface',
  'openrouter',
  'claude',
  'codex',
] as const;
type ProviderOption = (typeof providerOptions)[number];

export function AIPrompt({
  onTaskComplete,
  projectId: _projectId,
  sandboxId,
}: AIPromptProps) {
  const [prompt, setPrompt] = useState('');
  const [provider, setProvider] = useState<ProviderOption>('nvidia');
  const [taskType, setTaskType] =
    useState<(typeof taskTypes)[number]>('generate');
  const [runInSandbox, setRunInSandbox] = useState(Boolean(sandboxId));
  const { startStream, state, stopStream } = useAIStream();
  const lastCompletedRef = useRef('');

  const promptError = useMemo(() => {
    if (prompt.length === 0) {
      return 'Describe the AI task you want to run.';
    }
    if (prompt.length < 10) {
      return 'Prompt must be at least 10 characters.';
    }
    if (prompt.length > 2000) {
      return 'Prompt must be 2000 characters or fewer.';
    }
    return null;
  }, [prompt]);

  useEffect(() => {
    if (
      !state.isStreaming &&
      !state.error &&
      state.content &&
      state.content !== lastCompletedRef.current
    ) {
      lastCompletedRef.current = state.content;
      onTaskComplete?.(state.content);
    }
  }, [onTaskComplete, state.content, state.error, state.isStreaming]);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (promptError) {
      return;
    }

    await startStream({
      prompt,
      provider,
      sandboxId: runInSandbox ? sandboxId : undefined,
      taskType,
    });
  };

  return (
    <Card
      description="Stream code-generation output directly into the workspace."
      title="AI task prompt"
    >
      <form className="space-y-4" onSubmit={handleSubmit}>
        <label className="block space-y-2 text-sm text-gray-200">
          <span>Prompt</span>
          <textarea
            className={cn(
              'min-h-36 w-full rounded-xl border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100 outline-none focus:border-indigo-500',
              promptError && prompt.length > 0 && 'border-red-500',
            )}
            maxLength={2000}
            minLength={10}
            onChange={(event) => setPrompt(event.target.value)}
            placeholder="Ask the AI to generate, refactor, test, or debug your project."
            value={prompt}
          />
          <div className="flex items-center justify-between text-xs text-gray-400">
            <span>{promptError ?? 'Prompt looks good.'}</span>
            <span>{prompt.length}/2000</span>
          </div>
        </label>

        <div className="grid gap-4 lg:grid-cols-2">
          <fieldset className="space-y-2">
            <legend className="text-sm font-medium text-gray-200">
              Provider
            </legend>
            <div className="grid gap-2 sm:grid-cols-2">
              {providerOptions.map((option) => (
                <label
                  key={option}
                  className={cn(
                    'rounded-lg border px-3 py-3 capitalize',
                    provider === option
                      ? 'border-indigo-500 bg-indigo-500/10 text-white'
                      : 'border-gray-800 bg-gray-950 text-gray-300',
                  )}
                >
                  <input
                    checked={provider === option}
                    className="sr-only"
                    onChange={() => setProvider(option)}
                    type="radio"
                    value={option}
                  />
                  {option}
                </label>
              ))}
            </div>
          </fieldset>

          <fieldset className="space-y-2">
            <legend className="text-sm font-medium text-gray-200">
              Task type
            </legend>
            <div className="flex flex-wrap gap-2">
              {taskTypes.map((option) => (
                <button
                  key={option}
                  className={cn(
                    'rounded-lg border px-3 py-2 text-sm capitalize transition',
                    taskType === option
                      ? 'border-indigo-500 bg-indigo-500/10 text-white'
                      : 'border-gray-800 bg-gray-950 text-gray-300 hover:border-gray-700',
                  )}
                  onClick={() => setTaskType(option)}
                  type="button"
                >
                  {option}
                </button>
              ))}
            </div>
          </fieldset>
        </div>

        <label className="flex items-center gap-3 rounded-lg border border-gray-800 bg-gray-800/40 px-3 py-3 text-sm text-gray-200">
          <input
            checked={runInSandbox}
            disabled={!sandboxId}
            onChange={(event) => setRunInSandbox(event.target.checked)}
            type="checkbox"
          />
          <span>Run in Sandbox</span>
          {!sandboxId ? (
            <span className="text-xs text-gray-500">No sandbox attached</span>
          ) : null}
        </label>

        <div className="flex items-center gap-3">
          <Button
            disabled={Boolean(promptError) || state.isStreaming}
            type="submit"
          >
            Submit task
          </Button>
          {state.isStreaming ? (
            <Button onClick={stopStream} type="button" variant="danger">
              Stop
            </Button>
          ) : null}
          {state.usage ? (
            <span className="text-xs text-gray-400">
              {state.usage.promptTokens} prompt / {state.usage.completionTokens}{' '}
              completion tokens
            </span>
          ) : null}
        </div>

        <div className="rounded-xl border border-gray-800 bg-gray-950 p-4">
          <div className="mb-2 flex items-center justify-between">
            <h3 className="text-sm font-medium text-gray-100">
              Streaming output
            </h3>
            <span className="text-xs text-gray-500">
              {state.isStreaming ? 'Streaming…' : 'Idle'}
            </span>
          </div>
          {state.error ? (
            <div className="mb-3 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-200">
              {state.error}
            </div>
          ) : null}
          <pre className="min-h-40 whitespace-pre-wrap break-words text-sm text-gray-200">
            {state.content || 'Output will appear here as tokens arrive.'}
          </pre>
        </div>
      </form>
    </Card>
  );
}
