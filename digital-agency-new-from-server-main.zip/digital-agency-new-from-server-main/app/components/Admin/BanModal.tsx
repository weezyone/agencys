'use client';

import { useEffect, useMemo, useState } from 'react';
import { useToast } from '~/components/Notifications/ToastContainer';
import { Button } from '~/components/ui/Button';
import { Modal } from '~/components/ui/Modal';
import { AdminApiError, requestAdminJson } from './admin-utils';

interface BanModalProps {
  userId: string;
  userName: string;
  isOpen: boolean;
  onClose: () => void;
  onBanned?: () => void;
}

export function BanModal({
  userId,
  userName,
  isOpen,
  onClose,
  onBanned,
}: BanModalProps) {
  const [reason, setReason] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { addToast } = useToast();
  const canSubmit = useMemo(() => reason.trim().length > 0, [reason]);

  useEffect(() => {
    if (!isOpen) {
      setReason('');
      setError(null);
      setIsSubmitting(false);
    }
  }, [isOpen]);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!canSubmit) {
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      await requestAdminJson<{ success: boolean }>(`/api/admin/users/${userId}/ban`, {
        body: JSON.stringify({ reason: reason.trim() }),
        method: 'POST',
      });
      addToast({
        message: `${userName} was banned successfully.`,
        title: 'User banned',
        type: 'success',
      });
      onBanned?.();
      onClose();
    } catch (nextError) {
      const message =
        nextError instanceof AdminApiError
          ? nextError.message
          : 'Unable to ban user';
      setError(message);
      addToast({
        message,
        title: 'Ban failed',
        type: 'error',
      });
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <Modal onClose={onClose} open={isOpen} title="Confirm user ban">
      <form className="space-y-4" onSubmit={handleSubmit}>
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 p-4">
          <p className="text-sm font-medium text-red-200">{userName}</p>
          <p className="mt-2 text-sm text-red-100">
            This will immediately block the user from all platform access.
          </p>
        </div>

        <label className="block space-y-2 text-sm text-gray-200">
          <span>Ban reason</span>
          <textarea
            autoFocus
            className="min-h-28 w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100 outline-none focus:border-red-500"
            onChange={(event) => setReason(event.target.value)}
            placeholder="Describe why this user is being banned"
            value={reason}
          />
        </label>

        {error ? (
          <p className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-200">
            {error}
          </p>
        ) : null}

        <div className="flex items-center justify-end gap-3">
          <Button onClick={onClose} type="button" variant="ghost">
            Cancel
          </Button>
          <Button disabled={!canSubmit} loading={isSubmitting} type="submit" variant="danger">
            Confirm Ban
          </Button>
        </div>
      </form>
    </Modal>
  );
}
