'use client';

import { Card } from '~/components/ui/Card';
import type { SystemHealth } from './admin-utils';
import { formatUptime } from './admin-utils';

interface SystemHealthCardProps {
  health: SystemHealth;
}

function HealthRow({
  label,
  latency,
  status,
}: {
  label: string;
  latency: number;
  status: 'ok' | 'error';
}) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-xl border border-gray-700 bg-gray-900/70 px-4 py-3">
      <div className="flex items-center gap-3">
        <span
          aria-hidden="true"
          className={`h-2.5 w-2.5 rounded-full ${status === 'ok' ? 'bg-emerald-400' : 'bg-red-400'}`}
          data-testid={`${label.toLowerCase().replace(/\s+/g, '-')}-indicator`}
        />
        <div>
          <p className="text-sm font-medium text-gray-100">{label}</p>
          <p className={`text-xs ${status === 'ok' ? 'text-emerald-300' : 'text-red-300'}`}>
            {status === 'ok' ? 'OK' : 'ERROR'}
          </p>
        </div>
      </div>
      <span className="font-mono text-sm text-gray-300">{latency}ms</span>
    </div>
  );
}

export function SystemHealthCard({ health }: SystemHealthCardProps) {
  return (
    <Card
      className="border-gray-700 bg-gray-800"
      description="Real-time infrastructure checks"
      title="System Health"
    >
      <div className="space-y-3">
        <HealthRow label="Database" latency={health.dbLatencyMs} status={health.database} />
        <HealthRow label="KV Store" latency={health.kvLatencyMs} status={health.kv} />
        <div className="rounded-xl border border-gray-700 bg-gray-900/70 px-4 py-3">
          <p className="text-sm font-medium text-gray-100">Uptime</p>
          <p className="mt-1 text-sm text-gray-300">{formatUptime(health.uptime)}</p>
        </div>
      </div>
    </Card>
  );
}
