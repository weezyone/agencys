'use client';

import { Card } from '~/components/ui/Card';
import type { PlatformStats } from './admin-utils';

interface StatsGridProps {
  stats: PlatformStats;
}

interface StatCard {
  key: string;
  icon: string;
  iconClassName: string;
  label: string;
  renderMeta: (stats: PlatformStats) => string;
  renderMetaClassName?: (stats: PlatformStats) => string;
  renderValue: (stats: PlatformStats) => string;
  renderValueClassName?: (stats: PlatformStats) => string;
}

const statCards: StatCard[] = [
  {
    key: 'totalUsers',
    icon: '👥',
    iconClassName: 'bg-sky-500/15 text-sky-300',
    label: 'Total Users',
    renderMeta: (stats: PlatformStats) => `+${stats.newUsersLast7Days} this week`,
    renderValue: (stats: PlatformStats) => stats.totalUsers.toLocaleString(),
  },
  {
    key: 'activeWorkflows',
    icon: '⚡',
    iconClassName: 'bg-emerald-500/15 text-emerald-300',
    label: 'Active Workflows',
    renderMeta: (stats: PlatformStats) =>
      stats.activeWorkflows > 0 ? '● Processing' : '● Idle',
    renderMetaClassName: (stats: PlatformStats) =>
      stats.activeWorkflows > 0 ? 'text-emerald-300' : 'text-gray-400',
    renderValue: (stats: PlatformStats) => stats.activeWorkflows.toLocaleString(),
  },
  {
    key: 'totalProjects',
    icon: '📁',
    iconClassName: 'bg-violet-500/15 text-violet-300',
    label: 'Total Projects',
    renderMeta: () => 'Across all workspaces',
    renderValue: (stats: PlatformStats) => stats.totalProjects.toLocaleString(),
  },
  {
    key: 'errorRate',
    icon: '🚨',
    iconClassName: 'bg-rose-500/15 text-rose-300',
    label: 'Error Rate',
    renderMeta: (stats: PlatformStats) =>
      stats.errorRate > 10 ? 'Elevated failures' : 'Healthy trend',
    renderMetaClassName: (stats: PlatformStats) =>
      stats.errorRate > 10 ? 'text-red-300' : 'text-gray-400',
    renderValue: (stats: PlatformStats) => `${stats.errorRate.toFixed(1)}%`,
    renderValueClassName: (stats: PlatformStats) =>
      stats.errorRate > 10 ? 'text-red-300' : 'text-gray-100',
  },
  {
    key: 'estimatedPlatformCostUsd',
    icon: '💸',
    iconClassName: 'bg-amber-500/15 text-amber-300',
    label: 'Est. Platform Cost',
    renderMeta: () => 'Sandbox + AI usage',
    renderValue: (stats: PlatformStats) =>
      `$${stats.estimatedPlatformCostUsd.toFixed(2)}`,
  },
  {
    key: 'totalSandboxCpuHours',
    icon: '🖥️',
    iconClassName: 'bg-cyan-500/15 text-cyan-300',
    label: 'Sandbox CPU Hours',
    renderMeta: () => 'Total consumed compute',
    renderValue: (stats: PlatformStats) => `${stats.totalSandboxCpuHours.toFixed(1)}h`,
  },
];

export function StatsGrid({ stats }: StatsGridProps) {
  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
      {statCards.map((card) => (
        <Card
          key={card.key}
          className="rounded-xl border-gray-700 bg-gray-800 p-6"
          data-testid={`stat-card-${card.key}`}
        >
          <div className="flex items-start justify-between gap-4">
            <div className="space-y-3">
              <p className="text-sm font-medium text-gray-400">{card.label}</p>
              <p
                className={`text-3xl font-semibold tracking-tight ${card.renderValueClassName?.(stats) ?? 'text-gray-100'}`}
              >
                {card.renderValue(stats)}
              </p>
              <p
                className={`text-sm ${card.renderMetaClassName?.(stats) ?? 'text-gray-400'}`}
              >
                {card.renderMeta(stats)}
              </p>
            </div>
            <div
              aria-hidden="true"
              className={`flex h-12 w-12 items-center justify-center rounded-2xl text-xl ${card.iconClassName}`}
            >
              {card.icon}
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}
