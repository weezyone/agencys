'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { useToast } from '~/components/Notifications/ToastContainer';
import { Badge } from '~/components/ui/Badge';
import { Button } from '~/components/ui/Button';
import {
  type AdminUserDetail,
  type SerializedAdminUser,
  AdminApiError,
  formatJoinedDate,
  formatProvider,
  requestAdminJson,
} from './admin-utils';
import { BanModal } from './BanModal';
import { UserDetailPanel } from './UserDetailPanel';

interface UserTableProps {
  initialUsers: SerializedAdminUser[];
  total: number;
}

const PAGE_SIZE = 20;

function SkeletonRows() {
  return (
    <tbody>
      {Array.from({ length: 5 }).map((_, index) => (
        <tr key={index} className="border-t border-gray-800">
          <td className="px-4 py-4" colSpan={7}>
            <div className="h-12 animate-pulse rounded-xl bg-gray-800/80" />
          </td>
        </tr>
      ))}
    </tbody>
  );
}

export function UserTable({ initialUsers, total }: UserTableProps) {
  const [users, setUsers] = useState(initialUsers);
  const [totalUsers, setTotalUsers] = useState(total);
  const [page, setPage] = useState(0);
  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [banTarget, setBanTarget] = useState<SerializedAdminUser | null>(null);
  const { addToast } = useToast();
  const skipInitialFetchRef = useRef(true);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      setDebouncedSearch(search.trim());
    }, 300);

    return () => window.clearTimeout(timer);
  }, [search]);

  useEffect(() => {
    setPage(0);
  }, [debouncedSearch]);

  const loadUsers = useCallback(
    async (nextPage: number, nextSearch: string) => {
      setIsLoading(true);
      try {
        const params = new URLSearchParams({
          limit: String(PAGE_SIZE),
          offset: String(nextPage * PAGE_SIZE),
        });
        if (nextSearch) {
          params.set('search', nextSearch);
        }

        const payload = await requestAdminJson<{
          total: number;
          users: SerializedAdminUser[];
        }>(`/api/admin/users?${params.toString()}`);
        setUsers(payload.users);
        setTotalUsers(payload.total);
        setError(null);
      } catch (nextError) {
        setError(nextError instanceof AdminApiError ? nextError.message : 'Unable to load users');
      } finally {
        setIsLoading(false);
      }
    },
    [],
  );

  useEffect(() => {
    if (skipInitialFetchRef.current) {
      skipInitialFetchRef.current = false;
      return;
    }

    void loadUsers(page, debouncedSearch);
  }, [debouncedSearch, loadUsers, page]);

  async function handleAction(url: string, successTitle: string, successMessage: string) {
    try {
      await requestAdminJson<{ success: boolean }>(url, { method: 'POST' });
      addToast({ message: successMessage, title: successTitle, type: 'success' });
      await loadUsers(page, debouncedSearch);
    } catch (nextError) {
      addToast({
        message: nextError instanceof AdminApiError ? nextError.message : 'Unable to update user',
        title: 'Request failed',
        type: 'error',
      });
    }
  }

  function updateSelectedUser(user: AdminUserDetail) {
    setUsers((current) =>
      current.map((item) =>
        item.id === user.id
          ? {
              ...item,
              createdAt: user.createdAt,
              email: user.email,
              isAdmin: user.isAdmin,
              isBanned: user.isBanned,
              lastActiveAt: user.lastActiveAt,
              name: user.name,
              projectCount: user.projectCount,
              provider: user.provider,
              workflowCount: user.workflowCount,
            }
          : item,
      ),
    );
  }

  const totalPages = Math.max(1, Math.ceil(totalUsers / PAGE_SIZE));

  return (
    <div className="overflow-hidden rounded-2xl border border-gray-800 bg-gray-900">
      <div className="flex flex-col gap-4 border-b border-gray-800 px-5 py-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h2 className="text-xl font-semibold text-gray-100">Users</h2>
          <p className="mt-1 text-sm text-gray-400">Manage access, roles, and status for platform members.</p>
        </div>
        <input
          className="w-full rounded-xl border border-gray-700 bg-gray-800 px-3 py-2 text-sm text-gray-100 outline-none transition focus:border-indigo-500 lg:max-w-xs"
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Search users..."
          type="search"
          value={search}
        />
      </div>

      {error ? (
        <div className="border-b border-gray-800 px-5 py-3 text-sm text-red-300">{error}</div>
      ) : null}

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-800 text-left text-sm">
          <thead className="bg-gray-800/80 text-gray-300">
            <tr>
              <th className="px-4 py-3 font-medium">Name/Email</th>
              <th className="px-4 py-3 font-medium">Provider</th>
              <th className="px-4 py-3 font-medium">Projects</th>
              <th className="px-4 py-3 font-medium">Role</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium">Joined</th>
              <th className="px-4 py-3 font-medium">Actions</th>
            </tr>
          </thead>
          {isLoading ? (
            <SkeletonRows />
          ) : (
            <tbody>
              {users.length === 0 ? (
                <tr>
                  <td className="px-4 py-10 text-center text-gray-400" colSpan={7}>
                    No users matched your search.
                  </td>
                </tr>
              ) : (
                users.map((user) => (
                  <tr key={user.id} className="border-t border-gray-800 align-top">
                    <td className="px-4 py-4">
                      <div className="space-y-1">
                        <p className="font-medium text-gray-100">{user.name ?? 'Unnamed user'}</p>
                        <p className="text-xs text-gray-400">{user.email ?? user.id}</p>
                      </div>
                    </td>
                    <td className="px-4 py-4 text-gray-300">{formatProvider(user.provider)}</td>
                    <td className="px-4 py-4 text-gray-300">{user.projectCount}</td>
                    <td className="px-4 py-4">
                      <Badge
                        className={user.isAdmin ? 'border-purple-500/30 bg-purple-500/10 text-purple-200' : ''}
                        variant="default"
                      >
                        {user.isAdmin ? 'Admin' : 'User'}
                      </Badge>
                    </td>
                    <td className="px-4 py-4">
                      <Badge variant={user.isBanned ? 'error' : 'success'}>
                        {user.isBanned ? 'Banned' : 'Active'}
                      </Badge>
                    </td>
                    <td className="px-4 py-4 text-gray-300">{formatJoinedDate(user.createdAt)}</td>
                    <td className="px-4 py-4">
                      <div className="flex flex-wrap gap-2">
                        {user.isBanned ? (
                          <Button
                            onClick={() =>
                              void handleAction(
                                `/api/admin/users/${user.id}/unban`,
                                'User unbanned',
                                `${user.name ?? user.email ?? user.id} can access the platform again.`,
                              )
                            }
                            size="sm"
                            variant="secondary"
                          >
                            Unban
                          </Button>
                        ) : (
                          <Button
                            onClick={() => setBanTarget(user)}
                            size="sm"
                            variant="danger"
                          >
                            Ban
                          </Button>
                        )}
                        {!user.isAdmin ? (
                          <Button
                            onClick={() =>
                              void handleAction(
                                `/api/admin/users/${user.id}/promote`,
                                'Admin granted',
                                `${user.name ?? user.email ?? user.id} is now an admin.`,
                              )
                            }
                            size="sm"
                            variant="secondary"
                          >
                            Promote
                          </Button>
                        ) : null}
                        <Button
                          onClick={() => setSelectedUserId(user.id)}
                          size="sm"
                          variant="ghost"
                        >
                          View Details
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          )}
        </table>
      </div>

      <div className="flex items-center justify-between border-t border-gray-800 px-5 py-4 text-sm text-gray-400">
        <p>
          Page {page + 1} of {totalPages} • {totalUsers.toLocaleString()} users
        </p>
        <div className="flex gap-2">
          <Button
            disabled={page === 0 || isLoading}
            onClick={() => setPage((current) => Math.max(0, current - 1))}
            size="sm"
            variant="ghost"
          >
            Prev
          </Button>
          <Button
            disabled={page + 1 >= totalPages || isLoading}
            onClick={() => setPage((current) => current + 1)}
            size="sm"
            variant="ghost"
          >
            Next
          </Button>
        </div>
      </div>

      {selectedUserId ? (
        <UserDetailPanel
          onClose={() => setSelectedUserId(null)}
          onUserUpdated={updateSelectedUser}
          userId={selectedUserId}
        />
      ) : null}

      {banTarget ? (
        <BanModal
          isOpen
          onBanned={() => {
            void loadUsers(page, debouncedSearch);
            if (selectedUserId === banTarget.id) {
              setSelectedUserId(banTarget.id);
            }
          }}
          onClose={() => setBanTarget(null)}
          userId={banTarget.id}
          userName={banTarget.name ?? banTarget.email ?? banTarget.id}
        />
      ) : null}
    </div>
  );
}
