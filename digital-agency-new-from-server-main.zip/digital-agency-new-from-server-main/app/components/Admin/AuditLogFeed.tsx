'use client';

import { useCallback, useEffect, useState } from 'react';
import { Card } from '~/components/ui/Card';
import {
  type SerializedAuditLog,
  AdminApiError,
  describeAuditLog,
  getAuditDotClass,
  requestAdminJson,
} from './admin-utils';
import { formatRelativeTime } from '~/lib/utils';

interface AuditLogFeedProps {
  limit?: number;
}

export function AuditLogFeed({ limit = 8 }: AuditLogFeedProps) {
  const [logs, setLogs] = useState<SerializedAuditLog[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadLogs = useCallback(async () => {
    try {
      const payload = await requestAdminJson<{
        logs: SerializedAuditLog[];
        total: number;
      }>(`/api/admin/audit-logs?limit=${limit}`);
      setLogs(payload.logs);
      setError(null);
    } catch (nextError) {
      setError(
        nextError instanceof AdminApiError ? nextError.message : 'Unable to load audit activity',
      );
    } finally {
      setIsLoading(false);
    }
  }, [limit]);

  useEffect(() => {
    void loadLogs();
    const timer = window.setInterval(() => {
      void loadLogs();
    }, 30000);

    return () => window.clearInterval(timer);
  }, [loadLogs]);

  return (
    <Card
      className="border-gray-700 bg-gray-800"
      description="Auto-refreshes every 30 seconds"
      title="Recent Audit Activity"
    >
      {isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, index) => (
            <div
              key={index}
              className="animate-pulse rounded-xl border border-gray-700 bg-gray-900/70 px-4 py-4"
            />
          ))}
        </div>
      ) : error ? (
        <div className="rounded-xl border border-gray-700 bg-gray-900/70 px-4 py-6 text-sm text-gray-300">
          {error}
        </div>
      ) : logs.length === 0 ? (
        <div className="rounded-xl border border-gray-700 bg-gray-900/70 px-4 py-6 text-sm text-gray-400">
          No audit entries yet.
        </div>
      ) : (
        <div className="space-y-3">
          {logs.map((log) => (
            <div
              key={log.id}
              className="flex items-start gap-3 rounded-xl border border-gray-700 bg-gray-900/70 px-4 py-3"
            >
              <span
                aria-hidden="true"
                className={`mt-1 h-2.5 w-2.5 rounded-full ${getAuditDotClass(log.operation)}`}
                data-testid={`audit-dot-${log.operation}`}
              />
              <div className="min-w-0 flex-1">
                <p className="text-sm text-gray-100">{describeAuditLog(log)}</p>
                <p className="mt-1 text-xs text-gray-400">
                  {formatRelativeTime(new Date(log.createdAt))}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}
