import type { PlatformStats, SystemHealth } from '~/lib/admin.server';
import { formatDate, formatRelativeTime } from '~/lib/utils';

export type { PlatformStats, SystemHealth };

export interface SerializedAdminUser {
  id: string;
  name: string | null;
  email: string | null;
  provider: string;
  isAdmin: boolean;
  isBanned: boolean;
  createdAt: string;
  projectCount: number;
  workflowCount: number;
  lastActiveAt: string | null;
}

export interface SerializedAuditLog {
  id: string;
  userId: string;
  tableName: string;
  operation: string;
  oldValues: unknown;
  newValues: unknown;
  createdAt: string;
}

export interface AdminUserDetail extends SerializedAdminUser {
  projects: Array<{ id: string; name: string; createdAt: string }>;
  recentAuditLogs: SerializedAuditLog[];
}

export class AdminApiError extends Error {
  constructor(
    message: string,
    public readonly status: number,
  ) {
    super(message);
    this.name = 'AdminApiError';
  }
}

export async function requestAdminJson<T>(
  input: string,
  init?: RequestInit,
): Promise<T> {
  const headers = new Headers(init?.headers);
  if (init?.body && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }

  const response = await fetch(input, {
    ...init,
    headers,
  });
  const payload = (await response.json().catch(() => null)) as
    | { error?: string; message?: string }
    | T
    | null;

  if (!response.ok) {
    const message =
      response.status === 403
        ? 'Access denied'
        : (payload as { error?: string; message?: string } | null)?.message ??
          (payload as { error?: string; message?: string } | null)?.error ??
          'Request failed';
    throw new AdminApiError(message, response.status);
  }

  return payload as T;
}

export function formatProvider(provider: string) {
  return provider.charAt(0).toUpperCase() + provider.slice(1);
}

export function formatJoinedDate(value: string) {
  return formatDate(new Date(value));
}

export function formatLastActive(value: string | null) {
  if (!value) {
    return 'Never';
  }

  return formatRelativeTime(new Date(value));
}

export function formatUptime(uptime: number) {
  const days = Math.floor(uptime / 86400);
  const hours = Math.floor((uptime % 86400) / 3600);
  return `${days} days ${hours} hours`;
}

function readTargetId(log: SerializedAuditLog) {
  const newValues =
    log.newValues && typeof log.newValues === 'object'
      ? (log.newValues as Record<string, unknown>)
      : null;
  const oldValues =
    log.oldValues && typeof log.oldValues === 'object'
      ? (log.oldValues as Record<string, unknown>)
      : null;

  return (newValues?.targetId as string | undefined) ??
    (oldValues?.targetId as string | undefined) ??
    log.userId;
}

export function describeAuditLog(log: SerializedAuditLog) {
  const targetId = readTargetId(log);

  switch (log.operation) {
    case 'ban_user':
      return `Admin banned user ${targetId}`;
    case 'unban_user':
      return `Admin unbanned user ${targetId}`;
    case 'promote_admin':
      return `Admin promoted user ${targetId} to admin`;
    case 'revoke_admin':
      return `Admin revoked admin access for ${targetId}`;
    case 'impersonate':
      return `Admin impersonated user ${targetId}`;
    default:
      return `${log.operation.replace(/_/g, ' ')} • ${targetId}`;
  }
}

export function getAuditDotClass(operation: string) {
  switch (operation) {
    case 'ban_user':
      return 'bg-red-400';
    case 'unban_user':
      return 'bg-emerald-400';
    case 'promote_admin':
      return 'bg-purple-400';
    case 'revoke_admin':
      return 'bg-orange-400';
    case 'impersonate':
      return 'bg-amber-400';
    default:
      return 'bg-gray-500';
  }
}
