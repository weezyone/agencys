'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { useToast } from '~/components/Notifications/ToastContainer';
import { Badge } from '~/components/ui/Badge';
import { Button } from '~/components/ui/Button';
import { Card } from '~/components/ui/Card';
import {
  type AdminUserDetail,
  AdminApiError,
  describeAuditLog,
  formatJoinedDate,
  formatLastActive,
  formatProvider,
  requestAdminJson,
} from './admin-utils';
import { BanModal } from './BanModal';

interface UserDetailPanelProps {
  userId: string;
  onClose: () => void;
  initialUser?: AdminUserDetail;
  mode?: 'drawer' | 'inline';
  onUserUpdated?: (user: AdminUserDetail) => void;
}

function DetailItem({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-xl border border-gray-700 bg-gray-900/70 p-4">
      <p className="text-xs uppercase tracking-wide text-gray-500">{label}</p>
      <p className="mt-2 text-sm text-gray-100">{value}</p>
    </div>
  );
}

export function UserDetailPanel({
  userId,
  onClose,
  initialUser,
  mode = 'drawer',
  onUserUpdated,
}: UserDetailPanelProps) {
  const [user, setUser] = useState<AdminUserDetail | null>(initialUser ?? null);
  const [isLoading, setIsLoading] = useState(!initialUser || initialUser.id !== userId);
  const [error, setError] = useState<string | null>(null);
  const [isMutating, setIsMutating] = useState(false);
  const [banModalOpen, setBanModalOpen] = useState(false);
  const { addToast } = useToast();

  const loadUser = useCallback(async () => {
    setIsLoading(true);
    try {
      const payload = await requestAdminJson<{ user: AdminUserDetail }>(`/api/admin/users/${userId}`);
      setUser(payload.user);
      setError(null);
      onUserUpdated?.(payload.user);
    } catch (nextError) {
      setError(nextError instanceof AdminApiError ? nextError.message : 'Unable to load user details');
    } finally {
      setIsLoading(false);
    }
  }, [onUserUpdated, userId]);

  useEffect(() => {
    if (initialUser?.id === userId) {
      setUser(initialUser);
      setIsLoading(false);
      setError(null);
      return;
    }

    void loadUser();
  }, [initialUser, loadUser, userId]);

  const canPromote = Boolean(user && !user.isAdmin);
  const canRevoke = Boolean(user?.isAdmin);
  const panelTitle = useMemo(() => user?.name ?? user?.email ?? 'User details', [user]);

  async function handleMutation(url: string, successTitle: string, successMessage: string) {
    setIsMutating(true);
    try {
      await requestAdminJson<{ success: boolean }>(url, { method: 'POST' });
      addToast({
        message: successMessage,
        title: successTitle,
        type: 'success',
      });
      await loadUser();
    } catch (nextError) {
      addToast({
        message: nextError instanceof AdminApiError ? nextError.message : 'Action failed',
        title: 'Request failed',
        type: 'error',
      });
    } finally {
      setIsMutating(false);
    }
  }

  const content = (
    <>
      <div className="flex items-start justify-between gap-4 border-b border-gray-800 px-5 py-4">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-gray-500">Admin User View</p>
          <h2 className="mt-2 text-xl font-semibold text-gray-100">{panelTitle}</h2>
          {user?.email ? <p className="mt-1 text-sm text-gray-400">{user.email}</p> : null}
        </div>
        {mode === 'drawer' ? (
          <button
            aria-label="Close details"
            className="rounded-lg p-2 text-gray-400 transition hover:bg-gray-800 hover:text-white"
            onClick={onClose}
            type="button"
          >
            ✕
          </button>
        ) : null}
      </div>

      <div className="space-y-6 px-5 py-5">
        {isLoading ? (
          <div className="space-y-3">
            {Array.from({ length: 4 }).map((_, index) => (
              <div
                key={index}
                className="h-20 animate-pulse rounded-xl border border-gray-700 bg-gray-800/70"
              />
            ))}
          </div>
        ) : error ? (
          <div className="rounded-xl border border-gray-700 bg-gray-900/70 px-4 py-6 text-sm text-gray-300">
            {error}
          </div>
        ) : user ? (
          <>
            <div className="flex flex-wrap items-center gap-2">
              <Badge
                className={user.isAdmin ? 'border-purple-500/30 bg-purple-500/10 text-purple-200' : ''}
                variant="default"
              >
                {user.isAdmin ? 'Admin' : 'User'}
              </Badge>
              <Badge variant={user.isBanned ? 'error' : 'success'}>
                {user.isBanned ? 'Banned' : 'Active'}
              </Badge>
              <Badge className="border-gray-700 bg-gray-900 text-gray-300" variant="default">
                {formatProvider(user.provider)}
              </Badge>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <DetailItem label="Joined" value={formatJoinedDate(user.createdAt)} />
              <DetailItem label="Last active" value={formatLastActive(user.lastActiveAt)} />
              <DetailItem label="Projects" value={user.projectCount.toLocaleString()} />
              <DetailItem label="Workflows" value={user.workflowCount.toLocaleString()} />
            </div>

            <div className="flex flex-wrap gap-3">
              {user.isBanned ? (
                <Button
                  loading={isMutating}
                  onClick={() =>
                    void handleMutation(
                      `/api/admin/users/${user.id}/unban`,
                      'User unbanned',
                      `${user.name ?? user.email ?? user.id} can access the platform again.`,
                    )
                  }
                  variant="secondary"
                >
                  Unban User
                </Button>
              ) : (
                <Button onClick={() => setBanModalOpen(true)} variant="danger">
                  Ban User
                </Button>
              )}
              {canPromote ? (
                <Button
                  loading={isMutating}
                  onClick={() =>
                    void handleMutation(
                      `/api/admin/users/${user.id}/promote`,
                      'Admin granted',
                      `${user.name ?? user.email ?? user.id} is now an admin.`,
                    )
                  }
                  variant="primary"
                >
                  Promote to Admin
                </Button>
              ) : null}
              {canRevoke ? (
                <Button
                  loading={isMutating}
                  onClick={() =>
                    void handleMutation(
                      `/api/admin/users/${user.id}/revoke`,
                      'Admin revoked',
                      `${user.name ?? user.email ?? user.id} no longer has admin access.`,
                    )
                  }
                  variant="secondary"
                >
                  Revoke Admin
                </Button>
              ) : null}
            </div>

            <Card className="border-gray-700 bg-gray-800" title="Recent Projects">
              <div className="space-y-3">
                {user.projects.length === 0 ? (
                  <p className="text-sm text-gray-400">No recent projects found.</p>
                ) : (
                  user.projects.slice(0, 6).map((project) => (
                    <div
                      key={project.id}
                      className="flex items-center justify-between gap-3 rounded-xl border border-gray-700 bg-gray-900/70 px-4 py-3"
                    >
                      <div>
                        <p className="text-sm font-medium text-gray-100">{project.name}</p>
                        <p className="mt-1 text-xs text-gray-500">{project.id}</p>
                      </div>
                      <span className="text-xs text-gray-400">{formatJoinedDate(project.createdAt)}</span>
                    </div>
                  ))
                )}
              </div>
            </Card>

            <Card className="border-gray-700 bg-gray-800" title="Recent Audit Log Entries">
              <div className="space-y-3">
                {user.recentAuditLogs.length === 0 ? (
                  <p className="text-sm text-gray-400">No audit events for this user.</p>
                ) : (
                  user.recentAuditLogs.map((log) => (
                    <div
                      key={log.id}
                      className="rounded-xl border border-gray-700 bg-gray-900/70 px-4 py-3"
                    >
                      <p className="text-sm text-gray-100">{describeAuditLog(log)}</p>
                      <p className="mt-1 text-xs text-gray-400">{formatLastActive(log.createdAt)}</p>
                    </div>
                  ))
                )}
              </div>
            </Card>
          </>
        ) : null}
      </div>

      {user ? (
        <BanModal
          isOpen={banModalOpen}
          onBanned={() => {
            void loadUser();
          }}
          onClose={() => setBanModalOpen(false)}
          userId={user.id}
          userName={user.name ?? user.email ?? user.id}
        />
      ) : null}
    </>
  );

  if (mode === 'inline') {
    return <div className="overflow-hidden rounded-2xl border border-gray-700 bg-gray-900">{content}</div>;
  }

  return (
    <div className="fixed inset-0 z-40 flex justify-end bg-black/40">
      <button
        aria-label="Close details overlay"
        className="flex-1 cursor-default"
        onClick={onClose}
        type="button"
      />
      <aside className="h-full w-full max-w-2xl overflow-y-auto border-l border-gray-800 bg-gray-900 shadow-2xl shadow-black/40">
        {content}
      </aside>
    </div>
  );
}
