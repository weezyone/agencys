import type { HTMLAttributes, PropsWithChildren } from 'react';
import { cn } from '~/lib/utils';

export type BadgeVariant = 'default' | 'success' | 'warning' | 'error' | 'info';

const variantClasses: Record<BadgeVariant, string> = {
  default: 'border-gray-700 bg-gray-800 text-gray-200',
  success: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-200',
  warning: 'border-amber-500/30 bg-amber-500/10 text-amber-200',
  error: 'border-red-500/30 bg-red-500/10 text-red-200',
  info: 'border-sky-500/30 bg-sky-500/10 text-sky-200',
};

interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  variant?: BadgeVariant;
}

export function workflowStatusToBadgeVariant(
  status?: string | null,
): BadgeVariant {
  switch ((status ?? '').toLowerCase()) {
    case 'completed':
      return 'success';
    case 'failed':
    case 'expired':
      return 'error';
    case 'running':
    case 'suspended':
      return 'warning';
    case 'initializing':
    case 'pending':
      return 'info';
    default:
      return 'default';
  }
}

export function Badge({
  children,
  className,
  variant = 'default',
  ...props
}: PropsWithChildren<BadgeProps>) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-medium capitalize',
        variantClasses[variant],
        className,
      )}
      {...props}
    >
      {children}
    </span>
  );
}
