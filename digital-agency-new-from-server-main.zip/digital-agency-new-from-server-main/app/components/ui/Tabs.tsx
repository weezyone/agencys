'use client';

import { cn } from '~/lib/utils';

interface TabItem {
  icon?: string;
  id: string;
  label: string;
}

interface TabsProps {
  activeTab: string;
  onTabChange: (tabId: string) => void;
  tabs: TabItem[];
}

export function Tabs({ activeTab, onTabChange, tabs }: TabsProps) {
  return (
    <div className="border-b border-gray-800">
      <div className="flex flex-wrap gap-4">
        {tabs.map((tab) => {
          const isActive = tab.id === activeTab;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => onTabChange(tab.id)}
              className={cn(
                'relative inline-flex items-center gap-2 px-1 py-3 text-sm font-medium transition',
                isActive ? 'text-sky-300' : 'text-gray-400 hover:text-gray-200',
              )}
            >
              {tab.icon ? <span>{tab.icon}</span> : null}
              <span>{tab.label}</span>
              <span
                className={cn(
                  'absolute inset-x-0 -bottom-px h-0.5 rounded-full transition',
                  isActive ? 'bg-sky-400' : 'bg-transparent',
                )}
              />
            </button>
          );
        })}
      </div>
    </div>
  );
}
