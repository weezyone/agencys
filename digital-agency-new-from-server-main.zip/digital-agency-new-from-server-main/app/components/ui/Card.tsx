import type { HTMLAttributes, PropsWithChildren, ReactNode } from 'react';
import { cn } from '~/lib/utils';

interface CardProps extends Omit<HTMLAttributes<HTMLDivElement>, 'title'> {
  title?: ReactNode;
  description?: ReactNode;
  actions?: ReactNode;
}

export function Card({
  actions,
  children,
  className,
  description,
  title,
  ...props
}: PropsWithChildren<CardProps>) {
  return (
    <div
      className={cn(
        'rounded-xl border border-gray-800 bg-gray-900 p-5 shadow-lg shadow-black/20',
        className,
      )}
      {...props}
    >
      {title || description || actions ? (
        <div className="mb-4 flex items-start justify-between gap-4">
          <div className="min-w-0 space-y-1">
            {title ? (
              <h2 className="text-lg font-semibold text-gray-100">{title}</h2>
            ) : null}
            {description ? (
              <p className="text-sm text-gray-400">{description}</p>
            ) : null}
          </div>
          {actions ? <div className="shrink-0">{actions}</div> : null}
        </div>
      ) : null}
      {children}
    </div>
  );
}

export function CardHeader({
  children,
  className,
  ...props
}: PropsWithChildren<HTMLAttributes<HTMLDivElement>>) {
  return (
    <div
      className={cn('mb-4 flex items-start justify-between gap-3', className)}
      {...props}
    >
      {children}
    </div>
  );
}

export function CardTitle({
  children,
  className,
  ...props
}: PropsWithChildren<HTMLAttributes<HTMLHeadingElement>>) {
  return (
    <h2
      className={cn('text-lg font-semibold text-gray-100', className)}
      {...props}
    >
      {children}
    </h2>
  );
}

export function CardContent({
  children,
  className,
  ...props
}: PropsWithChildren<HTMLAttributes<HTMLDivElement>>) {
  return (
    <div
      className={cn('space-y-4 text-sm text-gray-200', className)}
      {...props}
    >
      {children}
    </div>
  );
}
