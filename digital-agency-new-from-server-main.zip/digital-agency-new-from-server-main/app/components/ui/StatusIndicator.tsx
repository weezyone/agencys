import { cn } from '~/lib/utils';

export type IndicatorStatus = 'connected' | 'running' | 'error' | 'idle';

interface StatusIndicatorProps {
  status: IndicatorStatus;
  label?: string;
}

const statusClasses: Record<IndicatorStatus, string> = {
  connected: 'bg-emerald-500',
  running: 'bg-amber-500 animate-pulse',
  error: 'bg-red-500',
  idle: 'bg-gray-500',
};

export function StatusIndicator({ label, status }: StatusIndicatorProps) {
  return (
    <span className="inline-flex items-center gap-2 text-sm text-gray-300">
      <span className={cn('h-2.5 w-2.5 rounded-full', statusClasses[status])} />
      {label ? <span>{label}</span> : null}
    </span>
  );
}
