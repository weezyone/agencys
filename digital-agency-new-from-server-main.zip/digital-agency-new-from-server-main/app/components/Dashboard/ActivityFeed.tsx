import { Link } from 'react-router';
import { Badge, Card } from '~/components/ui';
import { formatRelativeTime } from '~/lib/utils';
import { workflowStatusToBadgeVariant } from '../ui/Badge';

interface ActivityItem {
  type: 'workflow' | 'commit' | 'artifact';
  description: string;
  timestamp: string | Date;
  status?: string;
}

interface ActivityFeedProps {
  activities: ActivityItem[];
}

const icons: Record<ActivityItem['type'], string> = {
  workflow: '⚙️',
  commit: '🧬',
  artifact: '📦',
};

export function ActivityFeed({ activities }: ActivityFeedProps) {
  const items = activities.slice(0, 10);

  return (
    <Card
      actions={
        <Link
          className="text-sm text-indigo-300 transition hover:text-indigo-200"
          to="/?activity=all"
        >
          View all
        </Link>
      }
      description="Recent workflow, repository, and artifact activity."
      title="Activity feed"
    >
      {items.length === 0 ? (
        <div className="rounded-xl border border-dashed border-gray-800 px-6 py-12 text-center text-sm text-gray-400">
          No recent activity.
        </div>
      ) : (
        <ol className="space-y-3">
          {items.map((activity, index) => (
            <li
              key={`${activity.description}-${index}`}
              className="flex items-start gap-4 rounded-xl border border-gray-800 bg-gray-800/40 p-4"
            >
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gray-950 text-lg">
                {icons[activity.type]}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-sm font-medium text-gray-100">
                    {activity.description}
                  </span>
                  {activity.status ? (
                    <Badge
                      variant={workflowStatusToBadgeVariant(activity.status)}
                    >
                      {activity.status}
                    </Badge>
                  ) : null}
                </div>
                <p className="mt-1 text-xs text-gray-400">
                  {formatRelativeTime(new Date(activity.timestamp))}
                </p>
              </div>
            </li>
          ))}
        </ol>
      )}
    </Card>
  );
}
