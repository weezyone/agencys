'use client';

import type { FormEvent } from 'react';
import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router';
import { Badge, Button, Card } from '~/components/ui';
import { formatRelativeTime } from '~/lib/utils';
import type { ProjectSettings } from '~/types';
import { workflowStatusToBadgeVariant } from '../ui/Badge';

const providerOptions = [
  'nvidia',
  'huggingface',
  'openrouter',
  'claude',
  'codex',
] as const;
type ProviderOption = (typeof providerOptions)[number];

interface ProjectSummary {
  id: string;
  name: string;
  description?: string;
  repositoryUrl?: string;
  branch: string;
  settings: ProjectSettings;
  createdAt: string | Date;
  updatedAt: string | Date;
  lastActivityAt?: string | Date;
  lastWorkflowStatus?: string;
}

interface ProjectGridProps {
  projects: ProjectSummary[];
}

function NewTaskModal({
  onClose,
  project,
}: {
  project: ProjectSummary;
  onClose: () => void;
}) {
  const navigate = useNavigate();
  const [task, setTask] = useState('');
  const [provider, setProvider] = useState<ProviderOption>('nvidia');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const disabled = task.trim().length < 10 || submitting;

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitting(true);
    setError(null);

    try {
      const response = await fetch('/api/workflow/start', {
        body: JSON.stringify({
          projectId: project.id,
          provider,
          task,
          workflowType: 'cloud-task',
        }),
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
      });
      const payload = (await response.json().catch(() => null)) as {
        error?: string;
      } | null;
      if (!response.ok) {
        throw new Error(payload?.error ?? 'Unable to start task');
      }
      navigate(`/workspace/${project.id}`);
    } catch (nextError) {
      setError(
        nextError instanceof Error ? nextError.message : 'Unable to start task',
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
      <Card
        className="w-full max-w-xl"
        description="Launch a cloud-task workflow from the dashboard."
        title={`Start task for ${project.name}`}
      >
        <form className="space-y-4" onSubmit={handleSubmit}>
          <label className="block space-y-2 text-sm text-gray-200">
            <span>Task prompt</span>
            <textarea
              className="min-h-32 w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100 outline-none focus:border-indigo-500"
              onChange={(event) => setTask(event.target.value)}
              placeholder="Describe the coding task to run in the workspace."
              value={task}
            />
          </label>
          <div className="grid gap-2 sm:grid-cols-2">
            {providerOptions.map((option) => (
              <label
                key={option}
                className={`rounded-lg border px-3 py-3 capitalize ${provider === option ? 'border-indigo-500 bg-indigo-500/10 text-white' : 'border-gray-800 bg-gray-950 text-gray-300'}`}
              >
                <input
                  checked={provider === option}
                  className="sr-only"
                  onChange={() => setProvider(option)}
                  type="radio"
                  value={option}
                />
                {option}
              </label>
            ))}
          </div>
          {error ? (
            <div className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-200">
              {error}
            </div>
          ) : null}
          <div className="flex items-center justify-end gap-3">
            <Button onClick={onClose} type="button" variant="ghost">
              Close
            </Button>
            <Button disabled={disabled} loading={submitting} type="submit">
              Start task
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}

export function ProjectGrid({ projects }: ProjectGridProps) {
  const navigate = useNavigate();
  const [activeProject, setActiveProject] = useState<ProjectSummary | null>(
    null,
  );
  const sortedProjects = useMemo(() => [...projects], [projects]);

  if (sortedProjects.length === 0) {
    return (
      <Card
        description="Create a project to start provisioning sandboxes and workflows."
        title="Projects"
      >
        <div className="rounded-xl border border-dashed border-gray-800 px-6 py-12 text-center text-sm text-gray-400">
          No projects yet.
        </div>
      </Card>
    );
  }

  return (
    <>
      <section className="grid gap-4 lg:grid-cols-2 xl:grid-cols-3">
        {sortedProjects.map((project) => {
          const lastActivity = new Date(
            project.lastActivityAt ?? project.updatedAt,
          );
          return (
            <Card
              key={project.id}
              actions={
                <Badge
                  variant={workflowStatusToBadgeVariant(
                    project.lastWorkflowStatus,
                  )}
                >
                  {project.lastWorkflowStatus ?? 'idle'}
                </Badge>
              }
              description={
                project.description ?? 'No description provided yet.'
              }
              title={project.name}
            >
              <div className="space-y-4">
                <div className="space-y-2 text-sm text-gray-400">
                  <div className="flex items-center justify-between gap-3">
                    <span>Branch</span>
                    <span className="text-gray-100">{project.branch}</span>
                  </div>
                  <div className="flex items-center justify-between gap-3">
                    <span>Last activity</span>
                    <span className="text-gray-100">
                      {formatRelativeTime(lastActivity)}
                    </span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    className="flex-1"
                    onClick={() => navigate(`/workspace/${project.id}`)}
                    variant="primary"
                  >
                    Open Workspace
                  </Button>
                  <Button
                    className="flex-1"
                    onClick={() => setActiveProject(project)}
                    variant="secondary"
                  >
                    Start New Task
                  </Button>
                </div>
              </div>
            </Card>
          );
        })}
      </section>
      {activeProject ? (
        <NewTaskModal
          onClose={() => setActiveProject(null)}
          project={activeProject}
        />
      ) : null}
    </>
  );
}
