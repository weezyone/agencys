'use client';

import type { FormEvent } from 'react';
import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router';
import { z } from 'zod';
import { Button, Card } from '~/components/ui';
import { cn } from '~/lib/utils';

const providerOptions = [
  'nvidia',
  'huggingface',
  'openrouter',
  'claude',
  'codex',
] as const;

const newProjectSchema = z.object({
  branch: z
    .string()
    .trim()
    .min(1, 'Branch is required.')
    .max(255)
    .default('main'),
  description: z
    .string()
    .trim()
    .max(500, 'Description is too long.')
    .optional(),
  name: z.string().trim().min(1, 'Project name is required.').max(255),
  repositoryUrl: z
    .union([
      z.string().trim().url('Enter a valid repository URL.'),
      z.literal(''),
    ])
    .optional(),
  provider: z.enum(providerOptions),
});

type FormValues = z.infer<typeof newProjectSchema>;

interface NewProjectModalProps {
  open: boolean;
  onClose: () => void;
  onCreated?: (projectId: string) => void;
}

const initialValues: FormValues = {
  branch: 'main',
  description: '',
  name: '',
  provider: 'nvidia',
  repositoryUrl: '',
};

export function NewProjectModal({
  onClose,
  onCreated,
  open,
}: NewProjectModalProps) {
  const navigate = useNavigate();
  const [values, setValues] = useState<FormValues>(initialValues);
  const [errors, setErrors] = useState<
    Partial<Record<keyof FormValues, string>>
  >({});
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const canSubmit = useMemo(
    () => values.name.trim().length > 0 && !submitting,
    [submitting, values.name],
  );

  if (!open) {
    return null;
  }

  const updateValue = <K extends keyof FormValues>(
    key: K,
    value: FormValues[K],
  ) => {
    setValues((current) => ({ ...current, [key]: value }));
    setErrors((current) => ({ ...current, [key]: undefined }));
    setSubmitError(null);
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const parsed = newProjectSchema.safeParse(values);

    if (!parsed.success) {
      const fieldErrors = parsed.error.flatten().fieldErrors;
      setErrors({
        branch: fieldErrors.branch?.[0],
        description: fieldErrors.description?.[0],
        name: fieldErrors.name?.[0],
        provider: fieldErrors.provider?.[0],
        repositoryUrl: fieldErrors.repositoryUrl?.[0],
      });
      return;
    }

    setSubmitting(true);
    setSubmitError(null);

    try {
      const response = await fetch('/api/projects/create', {
        body: JSON.stringify({
          branch: parsed.data.branch,
          description: parsed.data.description || undefined,
          name: parsed.data.name,
          repositoryUrl: parsed.data.repositoryUrl || undefined,
          settings: {
            aiProvider: parsed.data.provider,
            gitIntegration: {
              defaultBranch: parsed.data.branch,
              provider: 'github',
              repositoryUrl: parsed.data.repositoryUrl || undefined,
            },
            sandboxConfig: {
              memoryMb: 4096,
              runtime: 'node22',
              timeoutMinutes: 30,
              vcpus: 2,
            },
          },
        }),
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
      });

      const payload = (await response.json().catch(() => null)) as {
        error?: string;
        project?: { id: string };
      } | null;
      if (!response.ok || !payload?.project?.id) {
        throw new Error(payload?.error ?? 'Unable to create project');
      }

      onCreated?.(payload.project.id);
      onClose();
      navigate(`/workspace/${payload.project.id}`);
    } catch (error) {
      setSubmitError(
        error instanceof Error ? error.message : 'Unable to create project',
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
      <Card
        className="w-full max-w-2xl"
        description="Provision a workspace and link the repository defaults."
        title="Create new project"
      >
        <form className="space-y-4" onSubmit={handleSubmit}>
          <div className="grid gap-4 md:grid-cols-2">
            <label className="space-y-2 text-sm text-gray-200">
              <span>Project name</span>
              <input
                className={cn(
                  'w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100 outline-none focus:border-indigo-500',
                  errors.name && 'border-red-500',
                )}
                onChange={(event) => updateValue('name', event.target.value)}
                placeholder="AI platform workspace"
                value={values.name}
              />
              {errors.name ? (
                <span className="text-xs text-red-300">{errors.name}</span>
              ) : null}
            </label>
            <label className="space-y-2 text-sm text-gray-200">
              <span>Branch</span>
              <input
                className={cn(
                  'w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100 outline-none focus:border-indigo-500',
                  errors.branch && 'border-red-500',
                )}
                onChange={(event) => updateValue('branch', event.target.value)}
                value={values.branch}
              />
              {errors.branch ? (
                <span className="text-xs text-red-300">{errors.branch}</span>
              ) : null}
            </label>
          </div>

          <label className="block space-y-2 text-sm text-gray-200">
            <span>Description</span>
            <textarea
              className={cn(
                'min-h-24 w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100 outline-none focus:border-indigo-500',
                errors.description && 'border-red-500',
              )}
              onChange={(event) =>
                updateValue('description', event.target.value)
              }
              placeholder="What will this workspace automate?"
              value={values.description ?? ''}
            />
            {errors.description ? (
              <span className="text-xs text-red-300">{errors.description}</span>
            ) : null}
          </label>

          <label className="block space-y-2 text-sm text-gray-200">
            <span>Repository URL</span>
            <input
              className={cn(
                'w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100 outline-none focus:border-indigo-500',
                errors.repositoryUrl && 'border-red-500',
              )}
              onChange={(event) =>
                updateValue('repositoryUrl', event.target.value)
              }
              placeholder="https://github.com/org/repo"
              value={values.repositoryUrl ?? ''}
            />
            {errors.repositoryUrl ? (
              <span className="text-xs text-red-300">
                {errors.repositoryUrl}
              </span>
            ) : null}
          </label>

          <fieldset className="space-y-2 text-sm text-gray-200">
            <legend>AI provider</legend>
            <div className="grid gap-2 sm:grid-cols-3">
              {providerOptions.map((option) => (
                <label
                  key={option}
                  className={cn(
                    'rounded-lg border border-gray-800 px-3 py-3 capitalize transition',
                    values.provider === option
                      ? 'border-indigo-500 bg-indigo-500/10 text-white'
                      : 'bg-gray-950 text-gray-300',
                  )}
                >
                  <input
                    checked={values.provider === option}
                    className="sr-only"
                    name="provider"
                    onChange={() => updateValue('provider', option)}
                    type="radio"
                    value={option}
                  />
                  {option}
                </label>
              ))}
            </div>
            {errors.provider ? (
              <span className="text-xs text-red-300">{errors.provider}</span>
            ) : null}
          </fieldset>

          {submitError ? (
            <div className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-200">
              {submitError}
            </div>
          ) : null}

          <div className="flex items-center justify-end gap-3">
            <Button onClick={onClose} type="button" variant="ghost">
              Cancel
            </Button>
            <Button disabled={!canSubmit} loading={submitting} type="submit">
              Create project
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
