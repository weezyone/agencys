'use client';

import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router';
import { Card } from '~/components/ui';
import { NewProjectModal } from './NewProjectModal';

const actions = [
  {
    description: 'Create a workspace with AI and sandbox defaults.',
    icon: '✨',
    key: 'new-project',
    label: 'New Project',
  },
  {
    description: 'Connect a repository and import code from GitHub.',
    icon: '🐙',
    key: 'import-github',
    label: 'Import from GitHub',
  },
  {
    description: 'Browse starter templates for common workflows.',
    icon: '🧩',
    key: 'templates',
    label: 'Browse Templates',
  },
] as const;

export function QuickActions() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const [modalOpen, setModalOpen] = useState(false);

  useEffect(() => {
    if (searchParams.get('newProject') === '1') {
      setModalOpen(true);
    }
  }, [searchParams]);

  const closeModal = () => {
    setModalOpen(false);
    const next = new URLSearchParams(searchParams);
    next.delete('newProject');
    setSearchParams(next, { replace: true });
  };

  const handleAction = (key: (typeof actions)[number]['key']) => {
    if (key === 'new-project') {
      setModalOpen(true);
      return;
    }
    if (key === 'import-github') {
      navigate('/auth/login');
      return;
    }
  };

  return (
    <>
      <Card
        title="Quick actions"
        description="Jump into the next workspace action in one click."
      >
        <div className="grid gap-3 md:grid-cols-3">
          {actions.map((action) => (
            <button
              key={action.key}
              className="rounded-xl border border-gray-800 bg-gray-800/40 p-4 text-left transition hover:border-gray-700 hover:bg-gray-800"
              onClick={() => handleAction(action.key)}
              type="button"
            >
              <div className="mb-4 text-2xl">{action.icon}</div>
              <h3 className="text-sm font-semibold text-gray-100">
                {action.label}
              </h3>
              <p className="mt-1 text-sm text-gray-400">{action.description}</p>
              <div className="mt-4">
                <span className="inline-flex h-9 items-center justify-center rounded-lg bg-gray-800 px-3 text-xs font-medium text-gray-100">
                  {action.key === 'templates' ? 'Coming soon' : 'Open'}
                </span>
              </div>
            </button>
          ))}
        </div>
      </Card>
      <NewProjectModal onClose={closeModal} open={modalOpen} />
    </>
  );
}
