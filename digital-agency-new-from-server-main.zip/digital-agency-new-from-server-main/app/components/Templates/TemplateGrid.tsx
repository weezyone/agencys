'use client';

import type { ProjectTemplate } from '@prisma/client';
import { TemplateCard } from './TemplateCard';

interface TemplateGridProps {
  templates: ProjectTemplate[];
  onUseTemplate?: (template: ProjectTemplate) => void;
  loading?: boolean;
}

function TemplateGridSkeleton() {
  return (
    <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
      {Array.from({ length: 6 }).map((_, index) => (
        <div
          key={index}
          className="animate-pulse rounded-2xl border border-gray-800 bg-gray-900 p-5"
        >
          <div className="mb-4 h-5 w-24 rounded-full bg-gray-800" />
          <div className="mb-3 h-6 w-2/3 rounded bg-gray-800" />
          <div className="mb-2 h-4 w-full rounded bg-gray-800" />
          <div className="mb-5 h-4 w-5/6 rounded bg-gray-800" />
          <div className="mb-5 flex gap-2">
            <div className="h-6 w-16 rounded-full bg-gray-800" />
            <div className="h-6 w-16 rounded-full bg-gray-800" />
            <div className="h-6 w-16 rounded-full bg-gray-800" />
          </div>
          <div className="h-10 w-full rounded-lg bg-gray-800" />
        </div>
      ))}
    </div>
  );
}

export function TemplateGrid({
  loading = false,
  onUseTemplate,
  templates,
}: TemplateGridProps) {
  if (loading) {
    return <TemplateGridSkeleton />;
  }

  if (templates.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed border-gray-700 bg-gray-900 px-6 py-16 text-center">
        <div className="mb-4 text-5xl" aria-hidden="true">
          🔭
        </div>
        <h3 className="text-lg font-semibold text-gray-100">No templates found</h3>
        <p className="mt-2 text-sm text-gray-400">
          Try a different search or category
        </p>
      </div>
    );
  }

  return (
    <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
      {templates.map((template) => (
        <TemplateCard
          key={template.id}
          onUseTemplate={onUseTemplate}
          template={template}
        />
      ))}
    </div>
  );
}
