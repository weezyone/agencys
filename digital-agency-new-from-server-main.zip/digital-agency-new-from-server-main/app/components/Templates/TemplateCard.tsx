'use client';

import type { ProjectTemplate } from '@prisma/client';
import { useState, type KeyboardEvent } from 'react';
import { useNavigate } from 'react-router';
import { Badge, Button, Card } from '~/components/ui';
import { getTemplateCategoryMeta, formatCategoryLabel } from './template-utils';
import { UseTemplateModal } from './UseTemplateModal';

interface TemplateCardProps {
  template: ProjectTemplate;
  onUseTemplate?: (template: ProjectTemplate) => void;
}

export function TemplateCard({ template, onUseTemplate }: TemplateCardProps) {
  const navigate = useNavigate();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const categoryMeta = getTemplateCategoryMeta(template.category);

  const openTemplate = () => navigate(`/templates/${template.id}`);
  const openUseTemplate = () => {
    if (onUseTemplate) {
      onUseTemplate(template);
      return;
    }

    setIsModalOpen(true);
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      openTemplate();
    }
  };

  return (
    <>
      <Card
        className="cursor-pointer rounded-2xl border-gray-800 bg-gray-900 transition hover:border-indigo-500 hover:ring-1 hover:ring-indigo-500"
        onClick={openTemplate}
        onKeyDown={handleKeyDown}
        role="button"
        tabIndex={0}
      >
        <div className="flex h-full flex-col gap-4">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-2">
              <span aria-hidden="true" className="text-2xl">
                {categoryMeta.icon}
              </span>
              <Badge className={categoryMeta.badgeClass} variant="default">
                {formatCategoryLabel(template.category)}
              </Badge>
            </div>
            {template.isBuiltIn ? (
              <Badge
                className="border-gray-500/30 bg-gray-500/10 text-gray-200"
                variant="default"
              >
                Built-in
              </Badge>
            ) : null}
          </div>

          <div className="space-y-2">
            <h3 className="text-xl font-semibold text-gray-100">{template.name}</h3>
            <p
              className="text-sm text-gray-400"
              style={{
                WebkitBoxOrient: 'vertical',
                WebkitLineClamp: 2,
                display: '-webkit-box',
                overflow: 'hidden',
              }}
            >
              {template.description}
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            {template.tags.slice(0, 3).map((tag) => (
              <Badge key={tag} className="text-gray-300" variant="default">
                {tag}
              </Badge>
            ))}
          </div>

          <div className="mt-auto flex items-center justify-between gap-3 pt-2">
            <span className="text-sm text-gray-400">Used {template.useCount} times</span>
            <Button
              onClick={(event) => {
                event.stopPropagation();
                openUseTemplate();
              }}
              size="sm"
            >
              Use Template
            </Button>
          </div>
        </div>
      </Card>
      {!onUseTemplate ? (
        <UseTemplateModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          template={template}
        />
      ) : null}
    </>
  );
}
