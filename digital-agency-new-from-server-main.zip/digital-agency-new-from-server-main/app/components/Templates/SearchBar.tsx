'use client';

import { useEffect, useState } from 'react';
import { cn } from '~/lib/utils';

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}

export function SearchBar({
  onChange,
  placeholder = 'Search templates',
  value,
}: SearchBarProps) {
  const [inputValue, setInputValue] = useState(value);

  useEffect(() => {
    setInputValue(value);
  }, [value]);

  useEffect(() => {
    const timeoutId = window.setTimeout(() => {
      if (inputValue !== value) {
        onChange(inputValue);
      }
    }, 300);

    return () => window.clearTimeout(timeoutId);
  }, [inputValue, onChange, value]);

  return (
    <div className="flex items-center gap-3 rounded-xl border border-gray-700 bg-gray-800 px-4 py-3 focus-within:border-indigo-500">
      <span aria-hidden="true" className="text-gray-400">
        🔍
      </span>
      <input
        className={cn(
          'w-full bg-transparent text-sm text-gray-100 outline-none placeholder:text-gray-500',
        )}
        onChange={(event) => setInputValue(event.target.value)}
        placeholder={placeholder}
        type="search"
        value={inputValue}
      />
      {inputValue ? (
        <button
          aria-label="Clear search"
          className="text-lg leading-none text-gray-400 transition hover:text-white"
          onClick={() => setInputValue('')}
          type="button"
        >
          ×
        </button>
      ) : null}
    </div>
  );
}
