'use client';

import { cn } from '~/lib/utils';
import { formatCategoryLabel, getTemplateCategoryMeta } from './template-utils';

interface CategoryFilterProps {
  categories: string[];
  selected?: string;
  onChange: (cat: string | undefined) => void;
}

export function CategoryFilter({
  categories,
  onChange,
  selected,
}: CategoryFilterProps) {
  const sortedCategories = [...categories].sort((left, right) =>
    left.localeCompare(right),
  );

  return (
    <div className="flex gap-2 overflow-x-auto pb-2">
      <button
        type="button"
        className={cn(
          'rounded-full px-3 py-2 text-sm font-medium transition whitespace-nowrap',
          !selected
            ? 'bg-indigo-600 text-white'
            : 'bg-gray-800 text-gray-400 hover:bg-gray-700',
        )}
        onClick={() => onChange(undefined)}
      >
        All
      </button>
      {sortedCategories.map((category) => {
        const isActive = selected === category;
        const meta = getTemplateCategoryMeta(category);

        return (
          <button
            key={category}
            type="button"
            className={cn(
              'rounded-full px-3 py-2 text-sm font-medium transition whitespace-nowrap',
              isActive
                ? 'bg-indigo-600 text-white'
                : 'bg-gray-800 text-gray-400 hover:bg-gray-700',
            )}
            onClick={() => onChange(isActive ? undefined : category)}
          >
            <span className="mr-2" aria-hidden="true">
              {meta.icon}
            </span>
            {formatCategoryLabel(category)}
          </button>
        );
      })}
    </div>
  );
}
