'use client';

import type { FormEvent } from 'react';
import { useEffect, useMemo, useState } from 'react';
import { Button, Modal } from '~/components/ui';
import { cn } from '~/lib/utils';
import { templateCategories } from './template-utils';

interface PublishTemplateModalProps {
  projectId: string;
  isOpen: boolean;
  onClose: () => void;
}

const initialValues = {
  aiPrompt: '',
  category: 'fullstack',
  description: '',
  isPublic: true,
  name: '',
  tags: '',
};

export function PublishTemplateModal({
  isOpen,
  onClose,
  projectId,
}: PublishTemplateModalProps) {
  const [values, setValues] = useState(initialValues);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!isOpen) {
      return;
    }

    setValues(initialValues);
    setError(null);
    setSuccessMessage(null);
    setSubmitting(false);
  }, [isOpen]);

  const canSubmit = useMemo(
    () =>
      values.name.trim().length > 0 &&
      values.description.trim().length >= 10 &&
      !submitting,
    [submitting, values.description, values.name],
  );

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!canSubmit) {
      return;
    }

    setSubmitting(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const response = await fetch(`/api/templates/${projectId}/publish`, {
        body: JSON.stringify({
          aiPrompt: values.aiPrompt || undefined,
          category: values.category,
          description: values.description,
          isPublic: values.isPublic,
          name: values.name,
          tags: values.tags
            .split(',')
            .map((tag) => tag.trim())
            .filter(Boolean),
        }),
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
      });
      const payload = (await response.json().catch(() => null)) as {
        error?: string;
      } | null;

      if (!response.ok) {
        throw new Error(payload?.error ?? 'Unable to publish template');
      }

      setSuccessMessage('Published! Your template is now live.');
    } catch (nextError) {
      setError(
        nextError instanceof Error ? nextError.message : 'Unable to publish template',
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal onClose={onClose} open={isOpen} title="Publish template">
      <form className="space-y-4" onSubmit={handleSubmit}>
        <label className="block space-y-2 text-sm text-gray-200">
          <span>Name</span>
          <input
            className="w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100 outline-none focus:border-indigo-500"
            onChange={(event) =>
              setValues((current) => ({ ...current, name: event.target.value }))
            }
            value={values.name}
          />
        </label>

        <label className="block space-y-2 text-sm text-gray-200">
          <span>Description</span>
          <textarea
            className={cn(
              'min-h-28 w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100 outline-none focus:border-indigo-500',
              values.description && values.description.trim().length < 10 && 'border-red-500',
            )}
            onChange={(event) =>
              setValues((current) => ({ ...current, description: event.target.value }))
            }
            value={values.description}
          />
          <span className="text-xs text-gray-500">Minimum 10 characters.</span>
        </label>

        <label className="block space-y-2 text-sm text-gray-200">
          <span>Category</span>
          <select
            className="w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100 outline-none focus:border-indigo-500"
            onChange={(event) =>
              setValues((current) => ({ ...current, category: event.target.value }))
            }
            value={values.category}
          >
            {templateCategories.map((category) => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </select>
        </label>

        <label className="block space-y-2 text-sm text-gray-200">
          <span>Tags</span>
          <input
            className="w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100 outline-none focus:border-indigo-500"
            onChange={(event) =>
              setValues((current) => ({ ...current, tags: event.target.value }))
            }
            placeholder="react, tailwind, starter"
            value={values.tags}
          />
        </label>

        <label className="block space-y-2 text-sm text-gray-200">
          <span>AI Prompt</span>
          <textarea
            className="min-h-24 w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100 outline-none focus:border-indigo-500"
            onChange={(event) =>
              setValues((current) => ({ ...current, aiPrompt: event.target.value }))
            }
            value={values.aiPrompt}
          />
        </label>

        <label className="flex items-center gap-3 text-sm text-gray-200">
          <input
            checked={values.isPublic}
            className="h-4 w-4 rounded border-gray-700 bg-gray-950 text-indigo-600 focus:ring-indigo-500"
            onChange={(event) =>
              setValues((current) => ({ ...current, isPublic: event.target.checked }))
            }
            type="checkbox"
          />
          Public template
        </label>

        {error ? (
          <div className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-200">
            {error}
          </div>
        ) : null}

        {successMessage ? (
          <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 text-sm text-emerald-200">
            {successMessage}
          </div>
        ) : null}

        <div className="flex items-center justify-end gap-3">
          <Button onClick={onClose} type="button" variant="ghost">
            Cancel
          </Button>
          <Button disabled={!canSubmit} loading={submitting} type="submit">
            Publish Template
          </Button>
        </div>
      </form>
    </Modal>
  );
}
