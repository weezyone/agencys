'use client';

import type { ProjectTemplate } from '@prisma/client';
import type { FormEvent } from 'react';
import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router';
import { Button, Modal } from '~/components/ui';
import { getTemplateSandboxConfig } from './template-utils';

interface UseTemplateModalProps {
  template: ProjectTemplate;
  isOpen: boolean;
  onClose: () => void;
}

export function UseTemplateModal({
  isOpen,
  onClose,
  template,
}: UseTemplateModalProps) {
  const navigate = useNavigate();
  const [projectName, setProjectName] = useState(template.name);
  const [expandedPrompt, setExpandedPrompt] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const sandboxConfig = useMemo(
    () => getTemplateSandboxConfig(template.sandboxConfig),
    [template.sandboxConfig],
  );

  useEffect(() => {
    if (!isOpen) {
      return;
    }

    setProjectName(template.name);
    setExpandedPrompt(false);
    setSubmitting(false);
    setError(null);
    setSuccessMessage(null);
  }, [isOpen, template.name]);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitting(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const response = await fetch(`/api/templates/${template.id}/use`, {
        body: JSON.stringify({ projectName }),
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
      });
      const payload = (await response.json().catch(() => null)) as {
        error?: string;
        project?: { id?: string };
      } | null;

      if (response.status === 401) {
        navigate('/auth/github');
        return;
      }

      if (!response.ok || !payload?.project?.id) {
        throw new Error(payload?.error ?? 'Unable to create project');
      }

      setSuccessMessage('✓ Project created! Setting up your workspace...');
      window.setTimeout(() => {
        navigate(`/workspace/${payload.project?.id}`);
      }, 1500);
    } catch (nextError) {
      setError(
        nextError instanceof Error ? nextError.message : 'Unable to create project',
      );
    } finally {
      setSubmitting(false);
    }
  };

  const promptPreview = template.aiPrompt?.trim();
  const showExpand = (promptPreview?.length ?? 0) > 240;
  const visiblePrompt =
    promptPreview && !expandedPrompt && showExpand
      ? `${promptPreview.slice(0, 240)}...`
      : promptPreview;

  return (
    <Modal onClose={onClose} open={isOpen} title={`Use ${template.name}`}>
      <form className="space-y-4" onSubmit={handleSubmit}>
        <label className="block space-y-2 text-sm text-gray-200">
          <span>Project Name</span>
          <input
            className="w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100 outline-none focus:border-indigo-500"
            onChange={(event) => setProjectName(event.target.value)}
            value={projectName}
          />
        </label>

        <div className="rounded-xl border border-gray-800 bg-gray-950 p-4 text-sm text-gray-300">
          <p className="mb-2 font-medium text-gray-100">Sandbox Config</p>
          <p>
            Runtime: {sandboxConfig.runtime} | vCPUs: {sandboxConfig.vcpus} | Timeout:{' '}
            {sandboxConfig.timeoutMinutes}m
          </p>
        </div>

        {promptPreview ? (
          <div className="rounded-xl border border-gray-800 bg-gray-950 p-4 text-sm text-gray-300">
            <div className="mb-2 flex items-center justify-between gap-3">
              <p className="font-medium text-gray-100">AI Starter Prompt</p>
              {showExpand ? (
                <button
                  className="text-xs text-indigo-300 hover:text-indigo-200"
                  onClick={() => setExpandedPrompt((current) => !current)}
                  type="button"
                >
                  {expandedPrompt ? 'Show less' : 'Show more'}
                </button>
              ) : null}
            </div>
            <p className="whitespace-pre-wrap text-gray-400">{visiblePrompt}</p>
          </div>
        ) : null}

        {error ? (
          <div className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-200">
            {error}
          </div>
        ) : null}

        {successMessage ? (
          <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 text-sm text-emerald-200">
            {successMessage}
          </div>
        ) : null}

        <div className="flex items-center justify-end gap-3">
          <Button onClick={onClose} type="button" variant="ghost">
            Cancel
          </Button>
          <Button
            disabled={!projectName.trim() || !!successMessage}
            loading={submitting}
            type="submit"
          >
            Create Project →
          </Button>
        </div>
      </form>
    </Modal>
  );
}
