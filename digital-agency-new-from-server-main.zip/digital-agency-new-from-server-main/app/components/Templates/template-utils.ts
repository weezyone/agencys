export const templateCategories = [
  'fullstack',
  'api',
  'cli',
  'data',
  'bot',
  'library',
  'web-app',
] as const;

export type TemplateCategory = (typeof templateCategories)[number];

export const categoryMeta: Record<
  TemplateCategory,
  { badgeClass: string; icon: string }
> = {
  fullstack: {
    badgeClass: 'border-purple-500/30 bg-purple-500/10 text-purple-200',
    icon: '🏗️',
  },
  api: {
    badgeClass: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-200',
    icon: '⚡',
  },
  cli: {
    badgeClass: 'border-amber-500/30 bg-amber-500/10 text-amber-200',
    icon: '💻',
  },
  data: {
    badgeClass: 'border-sky-500/30 bg-sky-500/10 text-sky-200',
    icon: '📊',
  },
  bot: {
    badgeClass: 'border-orange-500/30 bg-orange-500/10 text-orange-200',
    icon: '🤖',
  },
  library: {
    badgeClass: 'border-indigo-500/30 bg-indigo-500/10 text-indigo-200',
    icon: '📦',
  },
  'web-app': {
    badgeClass: 'border-cyan-500/30 bg-cyan-500/10 text-cyan-200',
    icon: '🌐',
  },
};

export function formatCategoryLabel(category: string) {
  return category.replace(/-/g, ' ').replace(/\b\w/g, (char) => char.toUpperCase());
}

export function getTemplateCategoryMeta(category: string) {
  return categoryMeta[category as TemplateCategory] ?? {
    badgeClass: 'border-gray-700 bg-gray-800 text-gray-200',
    icon: '📁',
  };
}

export interface TemplateSandboxConfig {
  runtime: string;
  timeoutMinutes: number;
  vcpus: number;
}

export function getTemplateSandboxConfig(value: unknown): TemplateSandboxConfig {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    return { runtime: 'node22', timeoutMinutes: 30, vcpus: 2 };
  }

  const config = value as Record<string, unknown>;

  return {
    runtime: typeof config.runtime === 'string' ? config.runtime : 'node22',
    timeoutMinutes:
      typeof config.timeoutMinutes === 'number' ? config.timeoutMinutes : 30,
    vcpus: typeof config.vcpus === 'number' ? config.vcpus : 2,
  };
}
