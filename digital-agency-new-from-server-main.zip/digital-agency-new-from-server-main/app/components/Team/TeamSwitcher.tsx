'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { Button } from '~/components/ui/Button';
import { CreateTeamModal } from './CreateTeamModal';

interface Team {
  id: string;
  name: string;
}

interface TeamSwitcherProps {
  teams?: Team[];
  currentTeamId?: string;
  onSwitch?: (teamId: string) => void;
}

const STORAGE_KEY = 'activeTeamId';

export function TeamSwitcher({
  teams,
  currentTeamId,
  onSwitch,
}: TeamSwitcherProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [teamList, setTeamList] = useState<Team[]>(teams ?? []);
  const [activeTeamId, setActiveTeamId] = useState<string | undefined>(
    currentTeamId,
  );
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (teams) {
      setTeamList(teams);
    }
  }, [teams]);

  useEffect(() => {
    const storedTeamId = window.localStorage.getItem(STORAGE_KEY) ?? undefined;
    const nextTeamId = storedTeamId ?? currentTeamId ?? teams?.[0]?.id;
    if (nextTeamId) {
      setActiveTeamId(nextTeamId);
    }
  }, [currentTeamId, teams]);

  useEffect(() => {
    if (!activeTeamId) {
      return;
    }
    window.localStorage.setItem(STORAGE_KEY, activeTeamId);
  }, [activeTeamId]);

  useEffect(() => {
    if (teams !== undefined) {
      return;
    }

    let cancelled = false;
    const loadTeams = async () => {
      for (const url of ['/api/teams/list', '/api/teams']) {
        try {
          const response = await fetch(url);
          const payload = (await response.json().catch(() => null)) as
            | { teams?: Team[] }
            | null;
          if (!response.ok || !payload?.teams) {
            continue;
          }
          if (!cancelled) {
            setTeamList(payload.teams);
          }
          return;
        } catch {
          continue;
        }
      }
    };

    void loadTeams();
    return () => {
      cancelled = true;
    };
  }, [teams]);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (!wrapperRef.current?.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const currentTeam = useMemo(() => {
    if (!teamList.length) {
      return null;
    }
    return (
      teamList.find((team) => team.id === activeTeamId) ??
      teamList.find((team) => team.id === currentTeamId) ??
      teamList[0]
    );
  }, [activeTeamId, currentTeamId, teamList]);

  function handleSwitch(teamId: string) {
    setActiveTeamId(teamId);
    setIsOpen(false);
    onSwitch?.(teamId);
  }

  function handleCreated(team: Team) {
    setTeamList((current) => [...current, team]);
    handleSwitch(team.id);
  }

  return (
    <div className="relative" ref={wrapperRef}>
      <button
        aria-expanded={isOpen}
        aria-haspopup="menu"
        className="flex min-w-40 items-center justify-between gap-3 rounded-xl border border-gray-800 bg-gray-900 px-3 py-2 text-left text-sm text-gray-100 transition hover:border-gray-700 hover:bg-gray-800"
        onClick={() => setIsOpen((open) => !open)}
        type="button"
      >
        <span className="truncate">{currentTeam?.name ?? 'Personal'}</span>
        <span className="text-xs text-gray-400">▾</span>
      </button>

      {isOpen ? (
        <div
          className="absolute left-0 top-full z-20 mt-2 w-64 rounded-xl border border-gray-800 bg-gray-900 p-2 shadow-2xl shadow-black/40"
          role="menu"
        >
          <div className="space-y-1">
            {teamList.map((team) => (
              <button
                className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm text-gray-200 transition hover:bg-gray-800"
                key={team.id}
                onClick={() => handleSwitch(team.id)}
                role="menuitem"
                type="button"
              >
                <span className="truncate">{team.name}</span>
                {team.id === currentTeam?.id ? (
                  <span className="text-xs text-indigo-300">Active</span>
                ) : null}
              </button>
            ))}
            {!teamList.length ? (
              <div className="rounded-lg px-3 py-2 text-sm text-gray-400">
                Personal workspace active.
              </div>
            ) : null}
          </div>
          <div className="mt-2 border-t border-gray-800 pt-2">
            <Button
              className="w-full justify-center"
              onClick={() => {
                setIsOpen(false);
                setIsCreating(true);
              }}
              size="sm"
              variant="secondary"
            >
              Create New Team
            </Button>
          </div>
        </div>
      ) : null}

      <CreateTeamModal
        isOpen={isCreating}
        onClose={() => setIsCreating(false)}
        onCreated={handleCreated}
      />
    </div>
  );
}
