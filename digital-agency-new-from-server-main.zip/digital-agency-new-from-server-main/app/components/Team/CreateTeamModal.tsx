'use client';

import { useEffect, useMemo, useState } from 'react';
import { Button } from '~/components/ui/Button';
import { Modal } from '~/components/ui/Modal';

interface Team {
  id: string;
  name: string;
}

interface CreateTeamModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreated?: (team: Team) => void;
}

export function CreateTeamModal({
  isOpen,
  onClose,
  onCreated,
}: CreateTeamModalProps) {
  const [name, setName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const isValid = useMemo(() => {
    const trimmed = name.trim();
    return trimmed.length >= 2 && trimmed.length <= 50;
  }, [name]);

  useEffect(() => {
    if (!isOpen) {
      setName('');
      setError(null);
      setSubmitting(false);
    }
  }, [isOpen]);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!isValid) {
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      const response = await fetch('/api/teams/create', {
        body: JSON.stringify({ name: name.trim() }),
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
      });
      const payload = (await response.json().catch(() => null)) as
        | { error?: string; team?: Team }
        | null;

      if (!response.ok || !payload?.team) {
        throw new Error(payload?.error ?? 'Unable to create team.');
      }

      onCreated?.(payload.team);
      onClose();
    } catch (submitError) {
      setError(
        submitError instanceof Error
          ? submitError.message
          : 'Unable to create team.',
      );
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal onClose={onClose} open={isOpen} title="Create a new team">
      <form className="space-y-4" onSubmit={handleSubmit}>
        <label className="block space-y-2 text-sm text-gray-200">
          <span>Team name</span>
          <input
            autoFocus
            className="w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100 outline-none transition focus:border-indigo-500"
            maxLength={50}
            onChange={(event) => setName(event.target.value)}
            placeholder="Platform Engineering"
            value={name}
          />
        </label>

        <p className="text-xs text-gray-400">
          Names must be between 2 and 50 characters.
        </p>

        {error ? (
          <p className="rounded-lg border border-red-500/40 bg-red-500/10 px-3 py-2 text-sm text-red-200">
            {error}
          </p>
        ) : null}

        <div className="flex justify-end gap-3">
          <Button onClick={onClose} type="button" variant="ghost">
            Cancel
          </Button>
          <Button disabled={!isValid} loading={submitting} type="submit">
            {submitting ? 'Creating team...' : 'Create team'}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
