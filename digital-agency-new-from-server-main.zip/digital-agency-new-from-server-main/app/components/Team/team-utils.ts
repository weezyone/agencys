import { formatDate } from '~/lib/utils';

export type TeamUiRole = 'owner' | 'admin' | 'member';

export function normalizeTeamRole(role?: string | null): TeamUiRole {
  switch ((role ?? '').toLowerCase()) {
    case 'owner':
      return 'owner';
    case 'admin':
    case 'collaborator':
      return 'admin';
    default:
      return 'member';
  }
}

export function teamRoleLabel(role?: string | null) {
  return normalizeTeamRole(role);
}

export function toApiTeamRole(role: Exclude<TeamUiRole, 'owner'>) {
  return role === 'admin' ? 'COLLABORATOR' : 'VIEWER';
}

export function teamRoleClasses(role?: string | null) {
  switch (normalizeTeamRole(role)) {
    case 'owner':
      return 'border-amber-500/30 bg-amber-500/10 text-amber-200';
    case 'admin':
      return 'border-blue-500/30 bg-blue-500/10 text-blue-200';
    default:
      return 'border-gray-700 bg-gray-800 text-gray-200';
  }
}

export function canManageTeamMembers(role?: string | null) {
  return normalizeTeamRole(role) !== 'member';
}

export function getInitials(name?: string | null, email?: string | null) {
  const source = name?.trim() || email?.trim() || 'P';
  return source
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join('');
}

export function formatTeamDate(value: string | Date) {
  const date = value instanceof Date ? value : new Date(value);
  return Number.isNaN(date.getTime()) ? '—' : formatDate(date);
}
