'use client';

import { useState } from 'react';
import { Badge } from '~/components/ui/Badge';
import { Button } from '~/components/ui/Button';
import {
  canManageTeamMembers,
  formatTeamDate,
  getInitials,
  normalizeTeamRole,
  teamRoleClasses,
  teamRoleLabel,
  toApiTeamRole,
} from './team-utils';

interface TeamUser {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string | null;
}

interface Member {
  id: string;
  role: string;
  joinedAt: string | Date;
  user: TeamUser;
}

interface MemberRowProps {
  member: Member;
  currentUserId: string;
  currentUserRole: string;
  teamId: string;
  onRemoved?: (userId: string) => void;
}

export function MemberRow({
  member,
  currentUserId,
  currentUserRole,
  teamId,
  onRemoved,
}: MemberRowProps) {
  const [currentRole, setCurrentRole] = useState(teamRoleLabel(member.role));
  const [loadingAction, setLoadingAction] = useState<
    'remove' | 'role' | null
  >(null);
  const [error, setError] = useState<string | null>(null);

  const viewerRole = normalizeTeamRole(currentUserRole);
  const memberRole = normalizeTeamRole(currentRole);
  const canManage = canManageTeamMembers(viewerRole);
  const canChangeRole = canManage && memberRole !== 'owner';
  const canRemove =
    canManage &&
    memberRole !== 'owner' &&
    member.user.id !== currentUserId;

  async function handleRoleChange(nextRole: 'admin' | 'member') {
    const previousRole = currentRole;
    setCurrentRole(nextRole);
    setLoadingAction('role');
    setError(null);

    try {
      const response = await fetch(
        `/api/teams/${teamId}/members/${member.user.id}/role`,
        {
          body: JSON.stringify({ role: toApiTeamRole(nextRole) }),
          headers: { 'Content-Type': 'application/json' },
          method: 'PUT',
        },
      );
      const payload = (await response.json().catch(() => null)) as
        | { error?: string; member?: { role?: string } }
        | null;

      if (!response.ok) {
        throw new Error(payload?.error ?? 'Unable to update role.');
      }

      setCurrentRole(teamRoleLabel(payload?.member?.role ?? nextRole));
    } catch (updateError) {
      setCurrentRole(previousRole);
      setError(
        updateError instanceof Error
          ? updateError.message
          : 'Unable to update role.',
      );
    } finally {
      setLoadingAction(null);
    }
  }

  async function handleRemove() {
    setLoadingAction('remove');
    setError(null);

    try {
      const response = await fetch(
        `/api/teams/${teamId}/members?userId=${member.user.id}`,
        { method: 'DELETE' },
      );
      const payload = (await response.json().catch(() => null)) as
        | { error?: string }
        | null;

      if (!response.ok) {
        throw new Error(payload?.error ?? 'Unable to remove member.');
      }

      onRemoved?.(member.user.id);
    } catch (removeError) {
      setError(
        removeError instanceof Error
          ? removeError.message
          : 'Unable to remove member.',
      );
    } finally {
      setLoadingAction(null);
    }
  }

  return (
    <tr className="border-b border-gray-800 last:border-b-0">
      <td className="px-4 py-4">
        <div className="flex items-center gap-3">
          {member.user.avatarUrl ? (
            <img
              alt={member.user.name}
              className="h-10 w-10 rounded-full border border-gray-700 object-cover"
              src={member.user.avatarUrl}
            />
          ) : (
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-indigo-600/20 text-sm font-semibold text-indigo-200">
              {getInitials(member.user.name, member.user.email)}
            </div>
          )}
          <div>
            <p className="font-medium text-gray-100">{member.user.name}</p>
            <p className="text-sm text-gray-400">{member.user.email}</p>
          </div>
        </div>
      </td>
      <td className="px-4 py-4 align-top">
        <Badge
          className={teamRoleClasses(currentRole)}
          data-testid={`role-badge-${member.user.id}`}
        >
          {teamRoleLabel(currentRole)}
        </Badge>
      </td>
      <td className="px-4 py-4 text-sm text-gray-300">
        {formatTeamDate(member.joinedAt)}
      </td>
      <td className="px-4 py-4">
        <div className="flex flex-col items-end gap-2">
          {canChangeRole ? (
            <select
              aria-label={`Change role for ${member.user.name}`}
              className="min-w-28 rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-sm text-gray-100 outline-none transition focus:border-indigo-500 disabled:opacity-50"
              disabled={loadingAction !== null}
              onChange={(event) =>
                void handleRoleChange(
                  event.target.value as 'admin' | 'member',
                )
              }
              value={teamRoleLabel(currentRole)}
            >
              <option value="admin">Admin</option>
              <option value="member">Member</option>
            </select>
          ) : null}
          {canRemove ? (
            <Button
              loading={loadingAction === 'remove'}
              onClick={() => void handleRemove()}
              size="sm"
              variant="ghost"
            >
              {loadingAction === 'remove' ? 'Removing...' : 'Remove'}
            </Button>
          ) : null}
          {loadingAction === 'role' ? (
            <span className="text-xs text-gray-400">Updating role...</span>
          ) : null}
          {error ? <p className="text-xs text-red-300">{error}</p> : null}
        </div>
      </td>
    </tr>
  );
}
