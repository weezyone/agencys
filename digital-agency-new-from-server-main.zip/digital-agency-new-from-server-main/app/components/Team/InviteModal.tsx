'use client';

import { useEffect, useMemo, useState } from 'react';
import { Button } from '~/components/ui/Button';
import { Modal } from '~/components/ui/Modal';
import { toApiTeamRole } from './team-utils';

interface InviteModalProps {
  isOpen: boolean;
  onClose: () => void;
  teamId: string;
  onInvited?: () => void;
}

export function InviteModal({
  isOpen,
  onClose,
  teamId,
  onInvited,
}: InviteModalProps) {
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<'member' | 'admin'>('member');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const emailIsValid = useMemo(
    () => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim()),
    [email],
  );

  useEffect(() => {
    if (!isOpen) {
      setEmail('');
      setRole('member');
      setError(null);
      setSuccess(null);
      setSubmitting(false);
    }
  }, [isOpen]);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!emailIsValid) {
      return;
    }

    setSubmitting(true);
    setError(null);
    setSuccess(null);

    try {
      const response = await fetch(`/api/teams/${teamId}/invite`, {
        body: JSON.stringify({
          email: email.trim(),
          role: toApiTeamRole(role),
        }),
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
      });
      const payload = (await response.json().catch(() => null)) as
        | { error?: string }
        | null;

      if (!response.ok) {
        throw new Error(payload?.error ?? 'Unable to send invite.');
      }

      setSuccess(`Invitation sent to ${email.trim()}`);
      setEmail('');
      setRole('member');
      onInvited?.();
    } catch (submitError) {
      setError(
        submitError instanceof Error
          ? submitError.message
          : 'Unable to send invite.',
      );
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal onClose={onClose} open={isOpen} title="Invite team member">
      <form className="space-y-4" onSubmit={handleSubmit}>
        <label className="block space-y-2 text-sm text-gray-200">
          <span>Email address</span>
          <input
            autoFocus
            className="w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100 outline-none transition focus:border-indigo-500"
            onChange={(event) => setEmail(event.target.value)}
            placeholder="teammate@example.com"
            type="email"
            value={email}
          />
        </label>

        <label className="block space-y-2 text-sm text-gray-200">
          <span>Role</span>
          <select
            className="w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100 outline-none transition focus:border-indigo-500"
            onChange={(event) =>
              setRole(event.target.value as 'member' | 'admin')
            }
            value={role}
          >
            <option value="member">Member</option>
            <option value="admin">Admin</option>
          </select>
        </label>

        {success ? (
          <p className="rounded-lg border border-emerald-500/40 bg-emerald-500/10 px-3 py-2 text-sm text-emerald-200">
            {success}
          </p>
        ) : null}

        {error ? (
          <p className="rounded-lg border border-red-500/40 bg-red-500/10 px-3 py-2 text-sm text-red-200">
            {error}
          </p>
        ) : null}

        <div className="flex justify-end gap-3">
          <Button onClick={onClose} type="button" variant="ghost">
            Cancel
          </Button>
          <Button
            disabled={!emailIsValid}
            loading={submitting}
            type="submit"
          >
            {submitting ? 'Sending invite...' : 'Send invite'}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
