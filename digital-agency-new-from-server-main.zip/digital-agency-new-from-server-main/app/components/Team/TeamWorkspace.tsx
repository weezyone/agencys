'use client';

import { useEffect, useMemo, useState } from 'react';
import { Form, useNavigation } from 'react-router';
import { InviteModal } from '~/components/Team/InviteModal';
import { CreateTeamModal } from '~/components/Team/CreateTeamModal';
import { MemberRow } from '~/components/Team/MemberRow';
import { Badge } from '~/components/ui/Badge';
import { Button } from '~/components/ui/Button';
import { Card } from '~/components/ui/Card';
import { formatTeamDate, teamRoleLabel } from './team-utils';

interface TeamUser {
  userId: string;
  name: string;
  email: string;
  avatarUrl?: string;
}

interface TeamSummary {
  id: string;
  name: string;
  role: string;
  memberCount: number;
}

interface TeamMember {
  id: string;
  role: string;
  joinedAt: string;
  user: {
    id: string;
    name: string;
    email: string;
    avatarUrl?: string | null;
  };
}

interface TeamDetails {
  id: string;
  name: string;
  createdAt: string;
  members: TeamMember[];
}

interface TeamWorkspaceProps {
  user: TeamUser;
  teams: TeamSummary[];
  team: TeamDetails | null;
  currentUserRole?: string;
  actionError?: string;
}

export function TeamWorkspace({
  user,
  teams,
  team,
  currentUserRole,
  actionError,
}: TeamWorkspaceProps) {
  const navigation = useNavigation();
  const [inviteOpen, setInviteOpen] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [members, setMembers] = useState(team?.members ?? []);

  useEffect(() => {
    setMembers(team?.members ?? []);
  }, [team]);

  const currentIntent = navigation.formData?.get('intent');
  const isDeleting = navigation.state === 'submitting' && currentIntent === 'delete-team';
  const isTransferring =
    navigation.state === 'submitting' && currentIntent === 'transfer-ownership';
  const selectableOwners = useMemo(
    () => members.filter((member) => teamRoleLabel(member.role) !== 'owner'),
    [members],
  );
  const selectedTeamSummary = team
    ? teams.find((entry) => entry.id === team.id)
    : null;

  function handleRemoved(userId: string) {
    setMembers((current) =>
      current.filter((member) => member.user.id !== userId),
    );
  }

  function handleCreated(createdTeam: { id: string }) {
    window.location.assign(`/settings/team?teamId=${createdTeam.id}`);
  }

  if (!team) {
    return (
      <>
        <Card
          description="Create a shared workspace to invite teammates and manage access."
          title="No team workspace yet"
        >
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <p className="max-w-2xl text-sm text-gray-300">
              Teams unlock shared project ownership, role-based access, and
              collaborative workflows.
            </p>
            <Button onClick={() => setCreateOpen(true)}>Create Team</Button>
          </div>
        </Card>
        <CreateTeamModal
          isOpen={createOpen}
          onClose={() => setCreateOpen(false)}
          onCreated={handleCreated}
        />
      </>
    );
  }

  return (
    <>
      {actionError ? (
        <div className="rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-200">
          {actionError}
        </div>
      ) : null}

      <Card
        actions={
          currentUserRole && teamRoleLabel(currentUserRole) !== 'member' ? (
            <Button onClick={() => setInviteOpen(true)} size="sm">
              Invite Member
            </Button>
          ) : null
        }
        description="Manage membership, roles, and team ownership from one place."
        title="Current team"
      >
        <div className="grid gap-4 sm:grid-cols-3">
          <div className="rounded-xl border border-gray-800 bg-gray-800/60 p-4">
            <p className="text-xs uppercase tracking-wide text-gray-400">
              Team name
            </p>
            <p className="mt-2 text-lg font-semibold text-gray-100">{team.name}</p>
          </div>
          <div className="rounded-xl border border-gray-800 bg-gray-800/60 p-4">
            <p className="text-xs uppercase tracking-wide text-gray-400">
              Created
            </p>
            <p className="mt-2 text-lg font-semibold text-gray-100">
              {formatTeamDate(team.createdAt)}
            </p>
          </div>
          <div className="rounded-xl border border-gray-800 bg-gray-800/60 p-4">
            <p className="text-xs uppercase tracking-wide text-gray-400">
              Members
            </p>
            <p className="mt-2 text-lg font-semibold text-gray-100">
              {members.length || selectedTeamSummary?.memberCount || 0}
            </p>
          </div>
        </div>
        <div className="mt-4 flex flex-wrap items-center gap-3 text-sm text-gray-300">
          <span>Your access:</span>
          <Badge className="border-indigo-500/30 bg-indigo-500/10 text-indigo-200">
            {teamRoleLabel(currentUserRole)}
          </Badge>
        </div>
      </Card>

      <Card title="Members" description="People with access to this workspace.">
        <div className="overflow-x-auto">
          <table className="min-w-full border-separate border-spacing-0">
            <thead>
              <tr className="text-left text-xs uppercase tracking-wide text-gray-400">
                <th className="px-4 py-3 font-medium">Member</th>
                <th className="px-4 py-3 font-medium">Role</th>
                <th className="px-4 py-3 font-medium">Joined</th>
                <th className="px-4 py-3 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {members.map((member) => (
                <MemberRow
                  currentUserId={user.userId}
                  currentUserRole={currentUserRole ?? 'member'}
                  key={member.id}
                  member={member}
                  onRemoved={handleRemoved}
                  teamId={team.id}
                />
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {teamRoleLabel(currentUserRole) === 'owner' ? (
        <Card
          description="Choose a new owner before stepping back from the workspace."
          title="Transfer Ownership"
        >
          <Form className="flex flex-col gap-4 lg:flex-row lg:items-end" method="post">
            <input name="intent" type="hidden" value="transfer-ownership" />
            <input name="teamId" type="hidden" value={team.id} />
            <label className="flex-1 space-y-2 text-sm text-gray-200">
              <span>New owner</span>
              <select
                className="w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100"
                defaultValue={selectableOwners[0]?.user.id ?? ''}
                disabled={!selectableOwners.length || isTransferring}
                name="newOwnerId"
              >
                {selectableOwners.map((member) => (
                  <option key={member.id} value={member.user.id}>
                    {member.user.name} ({teamRoleLabel(member.role)})
                  </option>
                ))}
              </select>
            </label>
            <Button
              disabled={!selectableOwners.length}
              loading={isTransferring}
              type="submit"
            >
              {isTransferring ? 'Transferring...' : 'Transfer ownership'}
            </Button>
          </Form>
        </Card>
      ) : null}

      {teamRoleLabel(currentUserRole) === 'owner' ? (
        <Card
          className="border-red-500/20"
          description="Deleting a team permanently removes its shared membership and projects."
          title="Danger zone"
        >
          <Form
            className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between"
            method="post"
            onSubmit={(event) => {
              if (
                !window.confirm(
                  `Delete ${team.name}? This action cannot be undone.`,
                )
              ) {
                event.preventDefault();
              }
            }}
          >
            <div className="text-sm text-gray-300">
              Delete this workspace and revoke all current invitations.
            </div>
            <input name="intent" type="hidden" value="delete-team" />
            <input name="teamId" type="hidden" value={team.id} />
            <Button loading={isDeleting} type="submit" variant="danger">
              {isDeleting ? 'Deleting team...' : 'Delete Team'}
            </Button>
          </Form>
        </Card>
      ) : null}

      <InviteModal
        isOpen={inviteOpen}
        onClose={() => setInviteOpen(false)}
        onInvited={() => undefined}
        teamId={team.id}
      />
    </>
  );
}
