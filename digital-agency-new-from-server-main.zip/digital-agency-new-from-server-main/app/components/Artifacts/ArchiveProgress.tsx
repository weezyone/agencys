'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { Card } from '~/components/ui';
import { cn, formatDate } from '~/lib/utils';

interface ArchiveProgressProps {
  artifactId?: string;
  onDownloadReady?: (url: string) => void;
}

interface ArtifactPayload {
  artifact?: {
    createdAt: string | Date;
    expiresAt?: string | Date;
    fileSize: number;
    id: string;
    name: string;
  };
  downloadUrl?: string;
  error?: string;
}

export function ArchiveProgress({
  artifactId,
  onDownloadReady,
}: ArchiveProgressProps) {
  const [progress, setProgress] = useState(artifactId ? 25 : 0);
  const [error, setError] = useState('');
  const [downloadUrl, setDownloadUrl] = useState('');
  const [artifact, setArtifact] = useState<ArtifactPayload['artifact']>();
  const [isPolling, setIsPolling] = useState(Boolean(artifactId));

  const loadArtifact = useCallback(async () => {
    if (!artifactId) {
      return;
    }

    try {
      const response = await fetch(`/api/artifacts/${artifactId}`);
      const payload = (await response.json()) as ArtifactPayload;
      if (!response.ok) {
        throw new Error(payload.error ?? 'Unable to load archive progress');
      }
      setArtifact(payload.artifact);
      setDownloadUrl(payload.downloadUrl ?? '');
      setProgress(100);
      setIsPolling(false);
      if (payload.downloadUrl) {
        onDownloadReady?.(payload.downloadUrl);
      }
    } catch (pollError) {
      setError(
        pollError instanceof Error
          ? pollError.message
          : 'Unable to load archive progress',
      );
      setIsPolling(false);
    }
  }, [artifactId, onDownloadReady]);

  useEffect(() => {
    if (!artifactId) {
      return;
    }

    let active = true;
    setProgress(35);
    const poll = async () => {
      if (!active) {
        return;
      }
      setProgress((current) => Math.min(current + 20, 85));
      await loadArtifact();
    };

    const timer = window.setTimeout(() => {
      void poll();
    }, 800);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [artifactId, loadArtifact]);

  const sizeLabel = useMemo(() => {
    if (!artifact?.fileSize) return '—';
    if (artifact.fileSize < 1024) return `${artifact.fileSize} B`;
    if (artifact.fileSize < 1024 * 1024)
      return `${(artifact.fileSize / 1024).toFixed(1)} KB`;
    return `${(artifact.fileSize / (1024 * 1024)).toFixed(1)} MB`;
  }, [artifact?.fileSize]);

  return (
    <Card
      title="Archive progress"
      description="Track compression status and download the finished artifact."
    >
      <div className="space-y-4">
        {artifactId ? (
          <>
            <div className="flex items-center justify-between text-sm text-gray-300">
              <span
                className={cn(
                  isPolling
                    ? 'text-sky-300'
                    : downloadUrl
                      ? 'text-emerald-300'
                      : 'text-red-300',
                )}
              >
                {isPolling
                  ? 'Compressing...'
                  : downloadUrl
                    ? 'Archive ready'
                    : 'Archive failed'}
              </span>
              <span>{progress}%</span>
            </div>
            <div className="h-3 overflow-hidden rounded-full bg-gray-800">
              <div
                className={cn(
                  'h-full rounded-full transition-all',
                  isPolling
                    ? 'animate-pulse bg-sky-500'
                    : downloadUrl
                      ? 'bg-emerald-500'
                      : 'bg-red-500',
                )}
                style={{ width: `${progress}%` }}
              />
            </div>
          </>
        ) : (
          <div className="rounded-xl border border-dashed border-gray-800 bg-gray-950 px-4 py-8 text-center text-sm text-gray-500">
            Create an archive to start tracking progress.
          </div>
        )}

        {artifact ? (
          <div className="rounded-xl border border-gray-800 bg-gray-950 p-4 text-sm text-gray-300">
            <div>{artifact.name}</div>
            <div className="mt-1 text-xs text-gray-500">{sizeLabel}</div>
            {artifact.expiresAt ? (
              <div className="mt-1 text-xs text-gray-500">
                Expires {formatDate(new Date(artifact.expiresAt))}
              </div>
            ) : null}
          </div>
        ) : null}

        {error ? (
          <div className="space-y-3">
            <div className="rounded-lg border border-red-500 bg-red-950/30 px-3 py-2 text-sm text-red-200">
              {error}
            </div>
            <button
              type="button"
              onClick={() => void loadArtifact()}
              className="rounded-lg border border-gray-700 bg-gray-900 px-4 py-2 text-sm text-gray-100"
            >
              Retry
            </button>
          </div>
        ) : null}

        {downloadUrl ? (
          <a
            href={downloadUrl}
            target="_blank"
            rel="noreferrer"
            className="inline-flex w-full items-center justify-center rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-emerald-500"
          >
            Download archive
          </a>
        ) : null}
      </div>
    </Card>
  );
}
