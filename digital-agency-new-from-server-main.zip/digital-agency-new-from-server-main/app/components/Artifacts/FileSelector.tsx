'use client';

import { useEffect, useMemo, useState } from 'react';
import { Card } from '~/components/ui';
import { cn } from '~/lib/utils';

interface FileRecord {
  path: string;
  size?: number;
}

interface FileSelectorProps {
  files?: FileRecord[];
  maxFiles?: number;
  maxSizeMb?: number;
  onArchiveCreated?: (artifactId: string) => void;
  onSelectionChange?: (paths: string[]) => void;
  projectId?: string;
  sandboxId?: string;
}

interface TreeNode {
  children: Map<string, TreeNode>;
  path: string;
  size?: number;
  type: 'directory' | 'file';
}

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function buildTree(files: FileRecord[]) {
  const root: TreeNode = { children: new Map(), path: '', type: 'directory' };

  for (const file of files) {
    const parts = file.path.split('/').filter(Boolean);
    let current = root;
    parts.forEach((part, index) => {
      const nextPath = current.path ? `${current.path}/${part}` : part;
      if (!current.children.has(part)) {
        current.children.set(part, {
          children: new Map(),
          path: nextPath,
          size: index === parts.length - 1 ? file.size : undefined,
          type: index === parts.length - 1 ? 'file' : 'directory',
        });
      }
      current = current.children.get(part)!;
    });
  }

  return root;
}

function TreeItem({
  expanded,
  node,
  selected,
  toggleExpand,
  toggleSelect,
}: {
  expanded: Record<string, boolean>;
  node: TreeNode;
  selected: string[];
  toggleExpand: (path: string) => void;
  toggleSelect: (path: string) => void;
}) {
  const isFile = node.type === 'file';
  const name = node.path.split('/').pop() || node.path;
  const isExpanded = expanded[node.path] ?? true;

  return (
    <li>
      <div className="flex items-center gap-2 rounded-lg px-2 py-2 text-sm text-gray-200 hover:bg-gray-900">
        {isFile ? (
          <input
            type="checkbox"
            checked={selected.includes(node.path)}
            onChange={() => toggleSelect(node.path)}
          />
        ) : (
          <button
            type="button"
            onClick={() => toggleExpand(node.path)}
            className="text-xs text-gray-500"
          >
            {isExpanded ? '▾' : '▸'}
          </button>
        )}
        <span
          className={cn(
            'font-mono',
            isFile ? 'text-gray-100' : 'text-gray-300',
          )}
        >
          {name}
        </span>
        {isFile && node.size ? (
          <span className="ml-auto text-xs text-gray-500">
            {formatBytes(node.size)}
          </span>
        ) : null}
      </div>
      {!isFile && isExpanded ? (
        <ul className="ml-4 border-l border-gray-800 pl-3">
          {[...node.children.values()].map((child) => (
            <TreeItem
              key={child.path}
              expanded={expanded}
              node={child}
              selected={selected}
              toggleExpand={toggleExpand}
              toggleSelect={toggleSelect}
            />
          ))}
        </ul>
      ) : null}
    </li>
  );
}

export function FileSelector({
  files = [],
  maxFiles = 1000,
  maxSizeMb = 10,
  onArchiveCreated,
  onSelectionChange,
  projectId,
  sandboxId,
}: FileSelectorProps) {
  const [availableFiles, setAvailableFiles] = useState<FileRecord[]>(files);
  const [selectedPaths, setSelectedPaths] = useState<string[]>(
    files.map((file) => file.path),
  );
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [isCreating, setIsCreating] = useState(false);

  useEffect(() => {
    setAvailableFiles(files);
    setSelectedPaths(files.map((file) => file.path));
  }, [files]);

  useEffect(() => {
    onSelectionChange?.(selectedPaths);
  }, [onSelectionChange, selectedPaths]);

  useEffect(() => {
    if (!sandboxId || files.length > 0) {
      return;
    }

    let active = true;
    const loadFiles = async () => {
      setIsLoading(true);
      try {
        const response = await fetch(
          `/api/sandbox/${sandboxId}/files?path=/vercel/sandbox/workspace`,
        );
        const payload = (await response.json()) as {
          error?: string;
          files?: string[];
        };
        if (!response.ok) {
          throw new Error(payload.error ?? 'Unable to load sandbox files');
        }
        if (active) {
          const nextFiles = (payload.files ?? []).map((path) => ({
            path: path.replace(/^\/+/, ''),
          }));
          setAvailableFiles(nextFiles);
          setSelectedPaths(nextFiles.map((file) => file.path));
        }
      } catch (loadError) {
        if (active) {
          setError(
            loadError instanceof Error
              ? loadError.message
              : 'Unable to load sandbox files',
          );
        }
      } finally {
        if (active) {
          setIsLoading(false);
        }
      }
    };

    void loadFiles();
    return () => {
      active = false;
    };
  }, [files.length, sandboxId]);

  const totalSizeBytes = useMemo(
    () =>
      availableFiles
        .filter((file) => selectedPaths.includes(file.path))
        .reduce((sum, file) => sum + (file.size ?? 0), 0),
    [availableFiles, selectedPaths],
  );
  const tooManyFiles = selectedPaths.length > maxFiles;
  const tooLarge = totalSizeBytes > maxSizeMb * 1024 * 1024;
  const treeRoot = useMemo(() => buildTree(availableFiles), [availableFiles]);

  const toggleSelect = (path: string) => {
    setSelectedPaths((current) =>
      current.includes(path)
        ? current.filter((entry) => entry !== path)
        : [...current, path],
    );
  };

  const handleCreateArchive = async () => {
    if (!projectId || selectedPaths.length === 0) {
      return;
    }

    setIsCreating(true);
    setError('');
    try {
      const response = await fetch('/api/artifacts/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(
          sandboxId
            ? {
                name: `workspace-${projectId.slice(0, 8)}.zip`,
                paths: selectedPaths,
                projectId,
                sandboxId,
              }
            : {
                files: availableFiles
                  .filter((file) => selectedPaths.includes(file.path))
                  .map((file) => ({ content: '', path: file.path })),
                name: `workspace-${projectId.slice(0, 8)}.zip`,
                projectId,
              },
        ),
      });
      const payload = (await response.json()) as {
        artifact?: { id: string };
        error?: string;
      };
      if (!response.ok || !payload.artifact?.id) {
        throw new Error(payload.error ?? 'Unable to create archive');
      }
      onArchiveCreated?.(payload.artifact.id);
    } catch (createError) {
      setError(
        createError instanceof Error
          ? createError.message
          : 'Unable to create archive',
      );
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <Card
      title="Archive file selection"
      description="Pick the files you want to package into a downloadable artifact."
    >
      <div className="space-y-4">
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() =>
              setSelectedPaths(availableFiles.map((file) => file.path))
            }
            className="rounded-lg border border-gray-700 bg-gray-900 px-3 py-2 text-sm text-gray-100"
          >
            Select all
          </button>
          <button
            type="button"
            onClick={() => setSelectedPaths([])}
            className="rounded-lg border border-gray-700 bg-gray-900 px-3 py-2 text-sm text-gray-100"
          >
            Deselect all
          </button>
          <div className="ml-auto text-sm text-gray-400">
            {selectedPaths.length} files · {formatBytes(totalSizeBytes)}
          </div>
        </div>

        {isLoading ? (
          <div className="animate-pulse space-y-2">
            {[1, 2, 3, 4].map((item) => (
              <div key={item} className="h-9 rounded-lg bg-gray-800" />
            ))}
          </div>
        ) : availableFiles.length > 0 ? (
          <div className="rounded-xl border border-gray-800 bg-gray-950 p-3">
            <ul className="space-y-1">
              {[...treeRoot.children.values()].map((node) => (
                <TreeItem
                  key={node.path}
                  expanded={expanded}
                  node={node}
                  selected={selectedPaths}
                  toggleExpand={(path) =>
                    setExpanded((current) => ({
                      ...current,
                      [path]: !(current[path] ?? true),
                    }))
                  }
                  toggleSelect={toggleSelect}
                />
              ))}
            </ul>
          </div>
        ) : (
          <div className="rounded-xl border border-dashed border-gray-800 bg-gray-950 px-4 py-8 text-center text-sm text-gray-500">
            No files available for archive creation.
          </div>
        )}

        {tooManyFiles || tooLarge ? (
          <div className="rounded-lg border border-red-500 bg-red-950/30 px-3 py-2 text-sm text-red-200">
            {tooManyFiles ? `Selection exceeds ${maxFiles} files.` : null}
            {tooManyFiles && tooLarge ? ' ' : null}
            {tooLarge ? `Selection exceeds ${maxSizeMb} MB.` : null}
          </div>
        ) : null}

        {error ? (
          <div className="rounded-lg border border-red-500 bg-red-950/30 px-3 py-2 text-sm text-red-200">
            {error}
          </div>
        ) : null}

        <button
          type="button"
          onClick={handleCreateArchive}
          disabled={
            isCreating ||
            selectedPaths.length === 0 ||
            tooManyFiles ||
            tooLarge ||
            !projectId
          }
          className={cn(
            'w-full rounded-lg px-4 py-2 text-sm font-medium text-white transition',
            isCreating ||
              selectedPaths.length === 0 ||
              tooManyFiles ||
              tooLarge ||
              !projectId
              ? 'cursor-not-allowed bg-gray-800'
              : 'bg-sky-600 hover:bg-sky-500',
          )}
        >
          {isCreating ? 'Creating archive...' : 'Create Archive'}
        </button>
      </div>
    </Card>
  );
}
