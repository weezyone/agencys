'use client';

import { useCallback, useEffect, useState } from 'react';
import { Card } from '~/components/ui';
import { formatDate } from '~/lib/utils';

interface ArtifactRecord {
  createdAt: string | Date;
  downloadUrl?: string;
  expiresAt?: string | Date;
  fileSize: number;
  id: string;
  name: string;
}

interface DownloadCenterProps {
  projectId: string;
}

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function DownloadCenter({ projectId }: DownloadCenterProps) {
  const [artifacts, setArtifacts] = useState<ArtifactRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  const loadArtifacts = useCallback(async () => {
    try {
      const response = await fetch(
        `/api/artifacts?projectId=${encodeURIComponent(projectId)}`,
      );
      const payload = (await response.json()) as {
        artifacts?: ArtifactRecord[];
        error?: string;
      };
      if (!response.ok) {
        throw new Error(payload.error ?? 'Unable to load downloads');
      }
      setArtifacts(payload.artifacts ?? []);
      setError('');
    } catch (loadError) {
      setError(
        loadError instanceof Error
          ? loadError.message
          : 'Unable to load downloads',
      );
    } finally {
      setIsLoading(false);
    }
  }, [projectId]);

  useEffect(() => {
    void loadArtifacts();
    const timer = window.setInterval(() => {
      void loadArtifacts();
    }, 30_000);
    return () => window.clearInterval(timer);
  }, [loadArtifacts]);

  const handleDelete = async (artifactId: string) => {
    if (
      typeof window !== 'undefined' &&
      !window.confirm('Delete this artifact?')
    ) {
      return;
    }

    const response = await fetch(`/api/artifacts/${artifactId}`, {
      method: 'DELETE',
    });
    if (response.ok) {
      await loadArtifacts();
    }
  };

  const handleDownload = async (artifact: ArtifactRecord) => {
    const expired = artifact.expiresAt
      ? new Date(artifact.expiresAt) < new Date()
      : false;
    const url =
      expired || !artifact.downloadUrl
        ? await fetch(`/api/artifacts/${artifact.id}`).then(
            async (response) => {
              const payload = (await response.json()) as {
                downloadUrl?: string;
                error?: string;
              };
              if (!response.ok) {
                throw new Error(
                  payload.error ?? 'Unable to refresh download URL',
                );
              }
              return payload.downloadUrl ?? '';
            },
          )
        : artifact.downloadUrl;

    if (url) {
      window.open(url, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <Card
      title="Download center"
      description="Review generated archives and pull fresh signed URLs when needed."
    >
      <div className="space-y-4">
        {error ? (
          <div className="rounded-lg border border-red-500 bg-red-950/30 px-3 py-2 text-sm text-red-200">
            {error}
          </div>
        ) : null}

        {isLoading ? (
          <div className="animate-pulse space-y-3">
            {[1, 2, 3].map((item) => (
              <div key={item} className="h-16 rounded-xl bg-gray-800" />
            ))}
          </div>
        ) : artifacts.length === 0 ? (
          <div className="rounded-xl border border-dashed border-gray-800 bg-gray-950 px-4 py-10 text-center text-sm text-gray-500">
            No artifacts found for this project.
          </div>
        ) : (
          <div className="space-y-3">
            {artifacts.map((artifact) => {
              const expired = artifact.expiresAt
                ? new Date(artifact.expiresAt) < new Date()
                : false;
              return (
                <div
                  key={artifact.id}
                  className="rounded-xl border border-gray-800 bg-gray-950 p-4"
                >
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <div className="text-sm font-medium text-gray-100">
                        {artifact.name}
                      </div>
                      <div className="mt-1 text-xs text-gray-500">
                        {formatBytes(artifact.fileSize)} · Created{' '}
                        {formatDate(new Date(artifact.createdAt))}
                      </div>
                    </div>
                    <span
                      className={
                        expired
                          ? 'text-xs text-red-300'
                          : 'text-xs text-emerald-300'
                      }
                    >
                      {expired ? 'Expired' : 'Ready'}
                    </span>
                  </div>

                  <div className="mt-4 flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => void handleDownload(artifact)}
                      className="rounded-lg bg-sky-600 px-3 py-2 text-sm text-white transition hover:bg-sky-500"
                    >
                      {expired ? 'Re-download' : 'Download'}
                    </button>
                    <button
                      type="button"
                      onClick={() => void handleDelete(artifact.id)}
                      className="rounded-lg border border-red-500/50 bg-red-950/30 px-3 py-2 text-sm text-red-200 transition hover:bg-red-950/50"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </Card>
  );
}
