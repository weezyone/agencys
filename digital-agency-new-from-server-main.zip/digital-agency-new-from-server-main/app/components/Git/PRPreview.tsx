'use client';

import { useEffect, useMemo, useState } from 'react';
import { Card } from '~/components/ui';
import { cn, generateBranchName } from '~/lib/utils';
import type { FileDiff } from '~/lib/git.server';

interface PRPreviewProps {
  projectId: string;
  head: string;
  onCreated?: (prUrl: string) => void;
}

interface DiffSummary {
  files: FileDiff[];
  totalAdditions: number;
  totalDeletions: number;
}

export function PRPreview({ projectId, head, onCreated }: PRPreviewProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [baseBranch, setBaseBranch] = useState('main');
  const [isLoadingSummary, setIsLoadingSummary] = useState(false);
  const [summary, setSummary] = useState<DiffSummary | null>(null);
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [prUrl, setPrUrl] = useState('');

  useEffect(() => {
    if (!head) {
      return;
    }

    setTitle(
      (current) =>
        current ||
        head
          .replace(/[-_/]+/g, ' ')
          .replace(/\b\w/g, (char) => char.toUpperCase()),
    );
    setDescription(
      (current) =>
        current ||
        `## Summary\n- Promote ${head} into ${baseBranch}\n- Review the generated commit changes before merging`,
    );
  }, [baseBranch, head]);

  useEffect(() => {
    if (!projectId || !head || !baseBranch) {
      return;
    }

    let active = true;
    const loadSummary = async () => {
      setIsLoadingSummary(true);
      try {
        const response = await fetch(
          `/api/git/diff?projectId=${encodeURIComponent(projectId)}&base=${encodeURIComponent(baseBranch)}&head=${encodeURIComponent(head)}`,
          { headers: { Accept: 'application/json' } },
        );
        const payload = (await response.json()) as DiffSummary & {
          error?: string;
        };
        if (!response.ok) {
          throw new Error(
            payload.error ?? 'Unable to load pull request summary',
          );
        }
        if (active) {
          setSummary(payload);
          setError('');
        }
      } catch (fetchError) {
        if (active) {
          setSummary(null);
          setError(
            fetchError instanceof Error
              ? fetchError.message
              : 'Unable to load pull request summary',
          );
        }
      } finally {
        if (active) {
          setIsLoadingSummary(false);
        }
      }
    };

    void loadSummary();
    return () => {
      active = false;
    };
  }, [baseBranch, head, projectId]);

  const helperTitle = useMemo(
    () => `pr/${generateBranchName(head || 'changes')}`,
    [head],
  );

  const handleCreatePr = async () => {
    setIsSubmitting(true);
    setError('');

    try {
      const response = await fetch('/api/git/pr', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          base: baseBranch,
          body: description,
          head,
          projectId,
          title: title.trim() || helperTitle,
        }),
      });
      const payload = (await response.json()) as {
        error?: string;
        pr?: { html_url?: string };
      };
      if (!response.ok) {
        throw new Error(payload.error ?? 'Unable to create pull request');
      }

      const nextUrl = payload.pr?.html_url ?? '';
      setPrUrl(nextUrl);
      onCreated?.(nextUrl);
    } catch (submitError) {
      setError(
        submitError instanceof Error
          ? submitError.message
          : 'Unable to create pull request',
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card
      title="Pull request preview"
      description="Prepare the final merge request for your commit branch."
    >
      <div className="space-y-4">
        <div>
          <label className="mb-2 block text-xs font-medium uppercase tracking-wide text-gray-400">
            Title
          </label>
          <input
            value={title}
            onChange={(event) => setTitle(event.target.value)}
            placeholder={helperTitle}
            className="w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-sm text-gray-100 outline-none focus:border-sky-500"
          />
        </div>

        <div>
          <label className="mb-2 block text-xs font-medium uppercase tracking-wide text-gray-400">
            Description
          </label>
          <textarea
            value={description}
            onChange={(event) => setDescription(event.target.value)}
            rows={5}
            className="w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-sm text-gray-100 outline-none focus:border-sky-500"
          />
        </div>

        <div>
          <label className="mb-2 block text-xs font-medium uppercase tracking-wide text-gray-400">
            Base branch
          </label>
          <select
            value={baseBranch}
            onChange={(event) => setBaseBranch(event.target.value)}
            className="w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-sm text-gray-100 outline-none focus:border-sky-500"
          >
            {['main', 'develop', 'release'].map((branch) => (
              <option key={branch} value={branch}>
                {branch}
              </option>
            ))}
          </select>
        </div>

        <div className="rounded-xl border border-gray-800 bg-gray-950 p-4 text-sm text-gray-300">
          <div className="mb-2 text-xs uppercase tracking-wide text-gray-500">
            Diff summary
          </div>
          {isLoadingSummary ? (
            <div className="animate-pulse space-y-2">
              <div className="h-3 w-32 rounded bg-gray-800" />
              <div className="h-3 w-48 rounded bg-gray-800" />
            </div>
          ) : (
            <>
              <p>
                {summary?.files.length ?? 0} files changed ·{' '}
                <span className="text-emerald-300">
                  +{summary?.totalAdditions ?? 0}
                </span>{' '}
                <span className="text-red-300">
                  -{summary?.totalDeletions ?? 0}
                </span>
              </p>
              <p className="mt-1 text-xs text-gray-500">
                Head branch: {head || 'Not selected yet'}
              </p>
            </>
          )}
        </div>

        {error ? (
          <div className="rounded-lg border border-red-500 bg-red-950/30 px-3 py-2 text-sm text-red-200">
            {error}
          </div>
        ) : null}

        {prUrl ? (
          <a
            href={prUrl}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 text-sm text-sky-300 underline"
          >
            Open pull request
          </a>
        ) : null}

        <button
          type="button"
          onClick={handleCreatePr}
          disabled={!head || isSubmitting}
          className={cn(
            'w-full rounded-lg px-4 py-2 text-sm font-medium text-white transition',
            !head || isSubmitting
              ? 'cursor-not-allowed bg-gray-800'
              : 'bg-sky-600 hover:bg-sky-500',
          )}
        >
          {isSubmitting ? 'Creating Pull Request...' : 'Create Pull Request'}
        </button>
      </div>
    </Card>
  );
}
