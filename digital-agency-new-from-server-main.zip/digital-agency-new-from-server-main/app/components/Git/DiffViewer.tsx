'use client';

import { useEffect, useMemo, useState } from 'react';
import type { FileDiff } from '~/lib/git.server';
import { cn } from '~/lib/utils';
import { Card } from '~/components/ui';

interface ParsedLine {
  content: string;
  newLineNumber?: number;
  oldLineNumber?: number;
  type: 'added' | 'context' | 'hunk' | 'removed';
}

interface ParsedFileDiff extends FileDiff {
  lines: ParsedLine[];
}

interface DiffViewerProps {
  files?: FileDiff[];
  isLoading?: boolean;
  loading?: boolean;
}

function parsePatch(patch?: string): ParsedLine[] {
  if (!patch) {
    return [];
  }

  const parsed: ParsedLine[] = [];
  let oldLineNumber = 0;
  let newLineNumber = 0;

  for (const line of patch.split(/\r?\n/)) {
    if (!line) {
      continue;
    }

    if (line.startsWith('@@')) {
      const match = line.match(/@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@/);
      if (match) {
        oldLineNumber = Number(match[1]);
        newLineNumber = Number(match[2]);
      }
      parsed.push({ content: line, type: 'hunk' });
      continue;
    }

    if (line.startsWith('+') && !line.startsWith('+++')) {
      parsed.push({ content: line, newLineNumber, type: 'added' });
      newLineNumber += 1;
      continue;
    }

    if (line.startsWith('-') && !line.startsWith('---')) {
      parsed.push({ content: line, oldLineNumber, type: 'removed' });
      oldLineNumber += 1;
      continue;
    }

    if (line.startsWith(' ')) {
      parsed.push({
        content: line,
        newLineNumber,
        oldLineNumber,
        type: 'context',
      });
      newLineNumber += 1;
      oldLineNumber += 1;
    }
  }

  return parsed;
}

function buildPreviewPatch(filename: string) {
  return [
    '@@ -0,0 +1,2 @@',
    `+// Preview for ${filename}`,
    '+// Generated from the selected workspace file',
  ].join('\n');
}

function getStatusTone(status: string) {
  switch (status) {
    case 'added':
      return 'text-emerald-300';
    case 'removed':
      return 'text-red-300';
    case 'renamed':
      return 'text-amber-300';
    default:
      return 'text-sky-300';
  }
}

export function DiffViewer({
  files = [],
  isLoading,
  loading,
}: DiffViewerProps) {
  const resolvedLoading = isLoading ?? loading ?? false;
  const parsedFiles = useMemo<ParsedFileDiff[]>(
    () =>
      files.map((file) => ({
        ...file,
        lines: parsePatch(file.patch ?? buildPreviewPatch(file.filename)),
      })),
    [files],
  );
  const [expandedFiles, setExpandedFiles] = useState<Record<string, boolean>>(
    {},
  );
  const [selectedFile, setSelectedFile] = useState(
    parsedFiles[0]?.filename ?? '',
  );

  useEffect(() => {
    setSelectedFile((current) => current || parsedFiles[0]?.filename || '');
    setExpandedFiles((current) => {
      const next = { ...current };
      for (const file of parsedFiles) {
        if (!(file.filename in next)) {
          next[file.filename] = true;
        }
      }
      return next;
    });
  }, [parsedFiles]);

  const totals = useMemo(
    () => ({
      additions: parsedFiles.reduce((sum, file) => sum + file.additions, 0),
      deletions: parsedFiles.reduce((sum, file) => sum + file.deletions, 0),
    }),
    [parsedFiles],
  );

  if (resolvedLoading) {
    return (
      <Card title="Diff viewer" description="Loading git changes...">
        <div className="animate-pulse space-y-3">
          {[1, 2, 3].map((item) => (
            <div
              key={item}
              className="rounded-xl border border-gray-800 bg-gray-950 p-4"
            >
              <div className="mb-3 h-4 w-48 rounded bg-gray-800" />
              <div className="space-y-2">
                {[1, 2, 3].map((line) => (
                  <div key={line} className="h-3 rounded bg-gray-800" />
                ))}
              </div>
            </div>
          ))}
        </div>
      </Card>
    );
  }

  if (parsedFiles.length === 0) {
    return (
      <Card
        title="Diff viewer"
        description="Review file-level changes before you commit."
      >
        <div className="rounded-xl border border-dashed border-gray-800 bg-gray-950 px-4 py-10 text-center text-sm text-gray-400">
          No files selected for diff preview.
        </div>
      </Card>
    );
  }

  return (
    <Card
      title="Diff viewer"
      description={
        <span className="text-xs text-gray-400">
          {parsedFiles.length} files changed ·{' '}
          <span className="text-emerald-300">+{totals.additions}</span>{' '}
          <span className="text-red-300">-{totals.deletions}</span>
        </span>
      }
    >
      <div className="grid gap-4 lg:grid-cols-[260px_minmax(0,1fr)]">
        <aside className="rounded-xl border border-gray-800 bg-gray-950 p-2">
          <div className="mb-2 px-2 text-xs uppercase tracking-wide text-gray-500">
            Changed files
          </div>
          <div className="space-y-1">
            {parsedFiles.map((file) => (
              <button
                key={file.filename}
                type="button"
                onClick={() => setSelectedFile(file.filename)}
                className={cn(
                  'flex w-full items-center justify-between rounded-lg border px-3 py-2 text-left transition',
                  selectedFile === file.filename
                    ? 'border-sky-500/40 bg-sky-500/10 text-white'
                    : 'border-transparent bg-gray-950 text-gray-300 hover:border-gray-800 hover:bg-gray-900',
                )}
              >
                <div className="min-w-0">
                  <div className="truncate font-mono text-sm">
                    {file.filename}
                  </div>
                  <div
                    className={cn(
                      'text-xs capitalize',
                      getStatusTone(file.status),
                    )}
                  >
                    {file.status}
                  </div>
                </div>
                <div className="ml-3 flex shrink-0 gap-2 text-xs">
                  <span className="text-emerald-300">+{file.additions}</span>
                  <span className="text-red-300">-{file.deletions}</span>
                </div>
              </button>
            ))}
          </div>
        </aside>

        <div className="space-y-4">
          {parsedFiles.map((file) => {
            const isExpanded = expandedFiles[file.filename] ?? true;
            return (
              <section
                key={file.filename}
                id={`diff-${file.filename.replace(/[^a-zA-Z0-9_-]/g, '-')}`}
                className={cn(
                  'overflow-hidden rounded-xl border bg-gray-950',
                  selectedFile === file.filename
                    ? 'border-sky-500/40'
                    : 'border-gray-800',
                )}
              >
                <button
                  type="button"
                  onClick={() => {
                    setSelectedFile(file.filename);
                    setExpandedFiles((current) => ({
                      ...current,
                      [file.filename]: !isExpanded,
                    }));
                  }}
                  className="flex w-full items-center justify-between border-b border-gray-800 bg-gray-900 px-4 py-3 text-left"
                >
                  <div>
                    <div className="font-mono text-sm text-gray-100">
                      {file.filename}
                    </div>
                    <div className="mt-1 text-xs text-gray-400">
                      <span className="text-emerald-300">
                        +{file.additions}
                      </span>{' '}
                      <span className="text-red-300">-{file.deletions}</span>
                    </div>
                  </div>
                  <span className="text-xs text-gray-400">
                    {isExpanded ? 'Collapse' : 'Expand'}
                  </span>
                </button>

                {isExpanded ? (
                  <div className="max-h-[32rem] overflow-auto">
                    {file.lines.length > 0 ? (
                      file.lines.map((line, index) => (
                        <div
                          key={`${file.filename}-${index}`}
                          className={cn(
                            'grid grid-cols-[72px_72px_minmax(0,1fr)] font-mono text-xs',
                            line.type === 'added' &&
                              'bg-emerald-950 text-emerald-300',
                            line.type === 'removed' &&
                              'bg-red-950 text-red-300',
                            line.type === 'context' && 'text-gray-300',
                            line.type === 'hunk' && 'bg-gray-900 text-sky-300',
                          )}
                        >
                          <span className="border-r border-gray-900/60 px-3 py-1 text-right text-gray-500">
                            {line.type === 'removed' || line.type === 'context'
                              ? (line.oldLineNumber ?? '')
                              : ''}
                          </span>
                          <span className="border-r border-gray-900/60 px-3 py-1 text-right text-gray-500">
                            {line.type === 'added' || line.type === 'context'
                              ? (line.newLineNumber ?? '')
                              : ''}
                          </span>
                          <span className="whitespace-pre-wrap break-all px-3 py-1">
                            {line.content}
                          </span>
                        </div>
                      ))
                    ) : (
                      <div className="px-4 py-6 text-sm text-gray-500">
                        No patch content available for this file.
                      </div>
                    )}
                  </div>
                ) : null}
              </section>
            );
          })}
        </div>
      </div>
    </Card>
  );
}
