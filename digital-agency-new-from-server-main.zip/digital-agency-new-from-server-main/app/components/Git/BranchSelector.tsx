'use client';

import { useEffect, useMemo, useState } from 'react';
import { cn } from '~/lib/utils';

const BRANCH_PATTERN = /^[a-zA-Z0-9-_/]+$/;

interface BranchSelectorProps {
  value: string;
  onChange: (branch: string) => void;
  projectId: string;
  branches?: string[];
}

export function BranchSelector({
  value,
  onChange,
  projectId,
  branches,
}: BranchSelectorProps) {
  const storageKey = `git-branches:${projectId}`;
  const [options, setOptions] = useState<string[]>(
    branches ?? ['main', 'develop', 'release'],
  );
  const [isCreating, setIsCreating] = useState(false);
  const [draft, setDraft] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (branches?.length) {
      setOptions(branches);
      return;
    }

    if (typeof window === 'undefined') {
      return;
    }

    const stored = window.localStorage.getItem(storageKey);
    if (!stored) {
      return;
    }

    try {
      const parsed = JSON.parse(stored) as string[];
      if (Array.isArray(parsed) && parsed.length > 0) {
        setOptions(Array.from(new Set([...parsed, 'main'])));
      }
    } catch {
      // Ignore corrupt local storage values.
    }
  }, [branches, storageKey]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(storageKey, JSON.stringify(options));
    }
  }, [options, storageKey]);

  const sortedOptions = useMemo(
    () =>
      Array.from(new Set(options)).sort((left, right) =>
        left.localeCompare(right),
      ),
    [options],
  );

  const handleCreate = () => {
    const branchName = draft.trim();
    if (!branchName) {
      setError('Branch name is required.');
      return;
    }
    if (!BRANCH_PATTERN.test(branchName)) {
      setError('Branch names may only include letters, numbers, -, _, and /.');
      return;
    }

    setOptions((current) => Array.from(new Set([...current, branchName])));
    onChange(branchName);
    setDraft('');
    setError('');
    setIsCreating(false);
  };

  return (
    <div className="space-y-3">
      <label
        htmlFor="branch-selector"
        className="block text-xs font-medium uppercase tracking-wide text-gray-400"
      >
        Branch
      </label>
      <div className="flex gap-2">
        <select
          id="branch-selector"
          value={value}
          onChange={(event) => onChange(event.target.value)}
          className="flex-1 rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-sm text-gray-100 outline-none focus:border-sky-500"
        >
          {sortedOptions.map((branch) => (
            <option key={branch} value={branch}>
              {branch}
            </option>
          ))}
          {!sortedOptions.includes(value) && value ? (
            <option value={value}>{value}</option>
          ) : null}
        </select>
        <button
          type="button"
          onClick={() => {
            setIsCreating((current) => !current);
            setError('');
          }}
          className="rounded-lg border border-gray-700 bg-gray-900 px-3 py-2 text-sm text-gray-100 transition hover:bg-gray-800"
        >
          {isCreating ? 'Cancel' : 'Create new branch'}
        </button>
      </div>

      {isCreating ? (
        <div className="rounded-xl border border-gray-800 bg-gray-950 p-4">
          <div className="flex gap-2">
            <input
              value={draft}
              onChange={(event) => setDraft(event.target.value)}
              placeholder="feature/git-artifacts-ui"
              className={cn(
                'flex-1 rounded-lg border bg-gray-900 px-3 py-2 text-sm text-gray-100 outline-none',
                error
                  ? 'border-red-500'
                  : 'border-gray-700 focus:border-sky-500',
              )}
            />
            <button
              type="button"
              onClick={handleCreate}
              className="rounded-lg bg-sky-600 px-3 py-2 text-sm font-medium text-white transition hover:bg-sky-500"
            >
              Add branch
            </button>
          </div>
          {error ? <p className="mt-2 text-xs text-red-300">{error}</p> : null}
        </div>
      ) : null}
    </div>
  );
}
