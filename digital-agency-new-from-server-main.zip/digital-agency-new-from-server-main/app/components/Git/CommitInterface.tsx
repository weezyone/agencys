'use client';

import { useEffect, useMemo, useState } from 'react';
import { BranchSelector } from '~/components/Git/BranchSelector';
import { DiffViewer } from '~/components/Git/DiffViewer';
import { PRPreview } from '~/components/Git/PRPreview';
import { Card } from '~/components/ui';
import type { FileDiff } from '~/lib/git.server';
import { cn, generateBranchName } from '~/lib/utils';

type Step = 1 | 2 | 3 | 4;

type ChangedFile = { content: string; path: string };

type CommitResult = { prUrl?: string; sha: string };

interface CommitInterfaceProps {
  changedFiles?: ChangedFile[];
  onSuccess?: (result: CommitResult) => void;
  projectId: string;
  sandboxId?: string;
}

const BRANCH_PATTERN = /^[a-zA-Z0-9-_/]+$/;

function toPreviewDiff(files: ChangedFile[]): FileDiff[] {
  return files.map((file) => {
    const contentLines = file.content.split(/\r?\n/);
    return {
      additions: contentLines.filter((line) => line.length > 0).length,
      deletions: 0,
      filename: file.path,
      patch: [
        '@@ -0,0 +1,' + Math.max(contentLines.length, 1) + ' @@',
        ...contentLines.map((line) => `+${line || ' '}`),
      ].join('\n'),
      status: 'modified',
    } satisfies FileDiff;
  });
}

export function CommitInterface({
  changedFiles = [],
  onSuccess,
  projectId,
}: CommitInterfaceProps) {
  const [step, setStep] = useState<Step>(1);
  const [selectedPaths, setSelectedPaths] = useState<string[]>(
    changedFiles.map((file) => file.path),
  );
  const [commitMessage, setCommitMessage] = useState('');
  const [branchName, setBranchName] = useState('main');
  const [createPr, setCreatePr] = useState(false);
  const [errors, setErrors] = useState<{
    branch?: string;
    commit?: string;
    form?: string;
  }>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [result, setResult] = useState<CommitResult | null>(null);
  const [branchTouched, setBranchTouched] = useState(false);

  useEffect(() => {
    setSelectedPaths(changedFiles.map((file) => file.path));
  }, [changedFiles]);

  useEffect(() => {
    if (!branchTouched && commitMessage.trim()) {
      setBranchName(
        `feature/${generateBranchName(commitMessage.trim())}`.replace(
          /\/$/,
          '',
        ),
      );
    }
  }, [branchTouched, commitMessage]);

  const selectedFiles = useMemo(
    () => changedFiles.filter((file) => selectedPaths.includes(file.path)),
    [changedFiles, selectedPaths],
  );
  const previewFiles = useMemo(
    () => toPreviewDiff(selectedFiles),
    [selectedFiles],
  );

  const toggleFile = (path: string) => {
    setSelectedPaths((current) =>
      current.includes(path)
        ? current.filter((entry) => entry !== path)
        : [...current, path],
    );
  };

  const validateStepThree = () => {
    const nextErrors: typeof errors = {};
    const trimmedMessage = commitMessage.trim();
    const trimmedBranch = branchName.trim();

    if (trimmedMessage.length < 5 || trimmedMessage.length > 200) {
      nextErrors.commit =
        'Commit message must be between 5 and 200 characters.';
    }
    if (!BRANCH_PATTERN.test(trimmedBranch)) {
      nextErrors.branch =
        'Branch name may only include letters, numbers, -, _, and /.';
    }

    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleAdvance = () => {
    if (step === 1) {
      if (selectedFiles.length === 0) {
        setErrors({ form: 'Select at least one file before continuing.' });
        return;
      }
      setErrors({});
      setStep(2);
      return;
    }

    if (step === 2) {
      setStep(3);
      return;
    }

    if (step === 3 && validateStepThree()) {
      setStep(4);
    }
  };

  const handleBack = () => {
    setErrors({});
    setStep((current) => (current > 1 ? ((current - 1) as Step) : current));
  };

  const handleSubmit = async () => {
    if (!validateStepThree()) {
      setStep(3);
      return;
    }

    setIsSubmitting(true);
    setErrors({});

    try {
      const knownBranches = ['main', 'develop', 'release'];
      if (!knownBranches.includes(branchName.trim())) {
        const branchResponse = await fetch('/api/git/branch', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            baseBranch: 'main',
            branchName: branchName.trim(),
            projectId,
          }),
        });
        const branchPayload = (await branchResponse.json()) as {
          error?: string;
        };
        if (!branchResponse.ok && branchResponse.status !== 409) {
          throw new Error(branchPayload.error ?? 'Unable to create branch');
        }
      }

      const commitResponse = await fetch('/api/git/commit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          branch: branchName.trim(),
          files: selectedFiles,
          message: commitMessage.trim(),
          projectId,
        }),
      });
      const commitPayload = (await commitResponse.json()) as {
        error?: string;
        sha?: string;
      };
      if (!commitResponse.ok || !commitPayload.sha) {
        throw new Error(commitPayload.error ?? 'Unable to create commit');
      }

      let prUrl: string | undefined;
      if (createPr) {
        const prResponse = await fetch('/api/git/pr', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            base: 'main',
            head: branchName.trim(),
            projectId,
            title: commitMessage.trim(),
          }),
        });
        const prPayload = (await prResponse.json()) as {
          error?: string;
          pr?: { html_url?: string };
        };
        if (!prResponse.ok) {
          throw new Error(prPayload.error ?? 'Unable to create pull request');
        }
        prUrl = prPayload.pr?.html_url;
      }

      const nextResult = { prUrl, sha: commitPayload.sha };
      setResult(nextResult);
      onSuccess?.(nextResult);
    } catch (submitError) {
      setErrors({
        form:
          submitError instanceof Error
            ? submitError.message
            : 'Unable to create commit',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const stepLabels = [
    'Select files',
    'Review diff',
    'Commit details',
    'Confirm',
  ];

  return (
    <Card
      title="Commit workflow"
      description="Stage files, review diffs, and publish a commit without leaving the workspace."
    >
      <div className="space-y-5">
        <div className="grid gap-2 sm:grid-cols-4">
          {stepLabels.map((label, index) => {
            const currentStep = (index + 1) as Step;
            return (
              <div
                key={label}
                className={cn(
                  'rounded-xl border px-3 py-2 text-sm',
                  step === currentStep
                    ? 'border-sky-500/40 bg-sky-500/10 text-sky-200'
                    : step > currentStep
                      ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-200'
                      : 'border-gray-800 bg-gray-950 text-gray-400',
                )}
              >
                <div className="text-xs uppercase tracking-wide">
                  Step {currentStep}
                </div>
                <div className="mt-1 font-medium">{label}</div>
              </div>
            );
          })}
        </div>

        {step === 1 ? (
          <div className="space-y-3">
            <div className="rounded-xl border border-gray-800 bg-gray-950 p-4">
              <div className="mb-3 text-xs uppercase tracking-wide text-gray-500">
                Changed files
              </div>
              <div className="space-y-2">
                {changedFiles.length > 0 ? (
                  changedFiles.map((file) => (
                    <label
                      key={file.path}
                      className="flex items-center gap-3 rounded-lg border border-gray-800 px-3 py-2 text-sm text-gray-200"
                    >
                      <input
                        type="checkbox"
                        checked={selectedPaths.includes(file.path)}
                        onChange={() => toggleFile(file.path)}
                      />
                      <span className="font-mono">{file.path}</span>
                    </label>
                  ))
                ) : (
                  <div className="rounded-lg border border-dashed border-gray-800 px-4 py-8 text-sm text-gray-500">
                    No changed files available yet.
                  </div>
                )}
              </div>
            </div>
            {errors.form ? (
              <p className="text-sm text-red-300">{errors.form}</p>
            ) : null}
          </div>
        ) : null}

        {step === 2 ? <DiffViewer files={previewFiles} /> : null}

        {step === 3 ? (
          <div className="space-y-4">
            <div>
              <label className="mb-2 block text-xs font-medium uppercase tracking-wide text-gray-400">
                Commit message
              </label>
              <textarea
                value={commitMessage}
                onChange={(event) => setCommitMessage(event.target.value)}
                rows={4}
                placeholder="Describe the Git integration UI changes"
                className={cn(
                  'w-full rounded-lg border bg-gray-950 px-3 py-2 text-sm text-gray-100 outline-none',
                  errors.commit
                    ? 'border-red-500'
                    : 'border-gray-700 focus:border-sky-500',
                )}
              />
              {errors.commit ? (
                <p className="mt-2 text-xs text-red-300">{errors.commit}</p>
              ) : null}
            </div>

            <BranchSelector
              value={branchName}
              onChange={(value) => {
                setBranchTouched(true);
                setBranchName(value);
              }}
              projectId={projectId}
            />
            {errors.branch ? (
              <p className="text-xs text-red-300">{errors.branch}</p>
            ) : null}

            <label className="flex items-center gap-3 rounded-lg border border-gray-800 bg-gray-950 px-3 py-2 text-sm text-gray-200">
              <input
                type="checkbox"
                checked={createPr}
                onChange={(event) => setCreatePr(event.target.checked)}
              />
              Create PR after commit
            </label>
          </div>
        ) : null}

        {step === 4 ? (
          <div className="space-y-4">
            <div className="rounded-xl border border-gray-800 bg-gray-950 p-4 text-sm text-gray-300">
              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <div className="text-xs uppercase tracking-wide text-gray-500">
                    Branch
                  </div>
                  <div className="mt-1 font-mono text-gray-100">
                    {branchName}
                  </div>
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wide text-gray-500">
                    Files
                  </div>
                  <div className="mt-1 text-gray-100">
                    {selectedFiles.length} selected
                  </div>
                </div>
              </div>
              <div className="mt-4">
                <div className="text-xs uppercase tracking-wide text-gray-500">
                  Commit message
                </div>
                <div className="mt-1 text-gray-100">
                  {commitMessage || 'Add a commit message'}
                </div>
              </div>
            </div>

            {createPr ? (
              <PRPreview head={branchName} projectId={projectId} />
            ) : null}
            {errors.form ? (
              <div className="rounded-lg border border-red-500 bg-red-950/30 px-3 py-2 text-sm text-red-200">
                {errors.form}
              </div>
            ) : null}

            {result ? (
              <div className="rounded-xl border border-emerald-500/40 bg-emerald-950/20 p-4">
                <div className="text-sm font-medium text-emerald-200">
                  Commit created successfully
                </div>
                <a
                  href={`https://github.com/commit/${result.sha}`}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-2 block font-mono text-sm text-sky-300 underline"
                >
                  {result.sha}
                </a>
                {result.prUrl ? (
                  <a
                    href={result.prUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="mt-2 block text-sm text-sky-300 underline"
                  >
                    Open pull request
                  </a>
                ) : null}
              </div>
            ) : (
              <button
                type="button"
                onClick={handleSubmit}
                disabled={isSubmitting}
                className={cn(
                  'w-full rounded-lg px-4 py-2 text-sm font-medium text-white transition',
                  isSubmitting
                    ? 'cursor-not-allowed bg-gray-800'
                    : 'bg-emerald-600 hover:bg-emerald-500',
                )}
              >
                {isSubmitting ? 'Creating commit...' : 'Create commit'}
              </button>
            )}
          </div>
        ) : null}

        <div className="flex items-center justify-between">
          <button
            type="button"
            onClick={handleBack}
            disabled={step === 1 || isSubmitting}
            className="rounded-lg border border-gray-700 bg-gray-900 px-4 py-2 text-sm text-gray-200 transition hover:bg-gray-800 disabled:cursor-not-allowed disabled:opacity-50"
          >
            Back
          </button>
          {step < 4 ? (
            <button
              type="button"
              onClick={handleAdvance}
              className="rounded-lg bg-sky-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-sky-500"
            >
              {step === 3 ? 'Continue' : 'Next'}
            </button>
          ) : null}
        </div>
      </div>
    </Card>
  );
}
