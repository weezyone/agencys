'use client';

import { useNavigate } from 'react-router';
import { cn } from '~/lib/utils';
import {
  formatNotificationRelativeTime,
  getNotificationDestination,
  type Notification,
  type NotificationType,
} from '~/types/notifications';

interface NotificationItemProps {
  notification: Notification;
  onMarkRead: (id: string) => void | Promise<void>;
}

const TYPE_STYLES: Record<
  NotificationType,
  { icon: string; iconLabel: string; className: string }
> = {
  ARTIFACT_READY: {
    className: 'bg-indigo-500/15 text-indigo-200',
    icon: '📦',
    iconLabel: 'Artifact ready',
  },
  SANDBOX_TIMEOUT: {
    className: 'bg-amber-500/15 text-amber-200',
    icon: '⏱',
    iconLabel: 'Sandbox timeout',
  },
  SYSTEM: {
    className: 'bg-slate-500/15 text-slate-200',
    icon: 'ℹ',
    iconLabel: 'System notification',
  },
  TEAM_INVITE: {
    className: 'bg-sky-500/15 text-sky-200',
    icon: '👥',
    iconLabel: 'Team invite',
  },
  WORKFLOW_COMPLETE: {
    className: 'bg-emerald-500/15 text-emerald-200',
    icon: '✓',
    iconLabel: 'Workflow complete',
  },
  WORKFLOW_FAILED: {
    className: 'bg-red-500/15 text-red-200',
    icon: '✗',
    iconLabel: 'Workflow failed',
  },
};

export function NotificationItem({ notification, onMarkRead }: NotificationItemProps) {
  const navigate = useNavigate();
  const destination = getNotificationDestination(notification);
  const icon = TYPE_STYLES[notification.type] ?? TYPE_STYLES.SYSTEM;
  const isUnread = notification.readAt == null;

  const handleClick = () => {
    void onMarkRead(notification.id);

    if (!destination) {
      return;
    }

    if (destination.type === 'internal') {
      navigate(destination.to);
      return;
    }

    window.location.assign(destination.to);
  };

  return (
    <button
      className={cn(
        'flex w-full items-start gap-3 border-l-2 px-4 py-3 text-left transition hover:bg-gray-700/50',
        isUnread
          ? 'border-indigo-500 bg-gray-800/80'
          : 'border-transparent bg-gray-800/40',
      )}
      data-testid={`notification-item-${notification.id}`}
      onClick={handleClick}
      type="button"
    >
      <span
        aria-label={icon.iconLabel}
        className={cn(
          'mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-sm font-semibold',
          icon.className,
        )}
      >
        {icon.icon}
      </span>
      <span className="min-w-0 flex-1 space-y-1">
        <span className="block text-sm font-medium text-gray-100">
          {notification.title}
        </span>
        <span className="block text-sm text-gray-300">{notification.body}</span>
      </span>
      <span className="shrink-0 text-xs text-gray-400">
        {formatNotificationRelativeTime(notification.createdAt)}
      </span>
    </button>
  );
}
