'use client';

import { useEffect, useRef, useState } from 'react';
import { useNotifications } from '~/hooks/useNotifications';
import { NotificationDropdown } from './NotificationDropdown';

function formatBadgeCount(count: number) {
  return count > 9 ? '9+' : String(count);
}

export function NotificationBell() {
  const { isLoading, markAllRead, markRead, notifications, unreadCount } =
    useNotifications();
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!open) {
      return;
    }

    const handlePointerDown = (event: MouseEvent) => {
      if (!containerRef.current?.contains(event.target as Node)) {
        setOpen(false);
      }
    };

    document.addEventListener('mousedown', handlePointerDown);
    return () => {
      document.removeEventListener('mousedown', handlePointerDown);
    };
  }, [open]);

  return (
    <div className="relative" ref={containerRef}>
      <button
        aria-expanded={open}
        aria-label="Notifications"
        className="relative inline-flex h-10 w-10 items-center justify-center rounded-full border border-gray-800 bg-gray-900 text-gray-200 transition hover:bg-gray-800 hover:text-white"
        data-testid="notification-bell"
        onClick={() => setOpen((current) => !current)}
        type="button"
      >
        <svg
          aria-hidden="true"
          className="h-5 w-5"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.8"
          viewBox="0 0 24 24"
        >
          <path
            d="M15 17h5l-1.4-1.4a2 2 0 0 1-.6-1.4V11a6 6 0 1 0-12 0v3.2a2 2 0 0 1-.6 1.4L4 17h5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path d="M10 17a2 2 0 0 0 4 0" strokeLinecap="round" />
        </svg>
        {!isLoading && unreadCount > 0 ? (
          <span
            className="absolute -right-1 -top-1 inline-flex min-h-5 min-w-5 items-center justify-center rounded-full bg-red-500 px-1 text-[10px] font-semibold leading-none text-white"
            data-testid="notification-badge"
          >
            {formatBadgeCount(unreadCount)}
          </span>
        ) : null}
      </button>

      {open ? (
        <NotificationDropdown
          notifications={notifications}
          onClose={() => setOpen(false)}
          onMarkAllRead={markAllRead}
          onMarkRead={markRead}
          unreadCount={unreadCount}
        />
      ) : null}
    </div>
  );
}
