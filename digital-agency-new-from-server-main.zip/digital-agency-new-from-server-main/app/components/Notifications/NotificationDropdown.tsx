'use client';

import { Link } from 'react-router';
import { Button, Card } from '~/components/ui';
import type { Notification } from '~/types/notifications';
import { NotificationItem } from './NotificationItem';

interface NotificationDropdownProps {
  notifications: Notification[];
  unreadCount: number;
  onMarkRead: (id: string) => void | Promise<void>;
  onMarkAllRead: () => void | Promise<void>;
  onClose: () => void;
}

export function NotificationDropdown({
  notifications,
  unreadCount,
  onMarkRead,
  onMarkAllRead,
  onClose,
}: NotificationDropdownProps) {
  return (
    <Card
      className="absolute right-0 top-full z-50 mt-3 w-[380px] overflow-hidden border-gray-800 bg-gray-900 p-0 shadow-xl shadow-black/40"
      data-testid="notification-dropdown"
    >
      <div className="flex items-center justify-between border-b border-gray-800 px-4 py-3">
        <div>
          <h2 className="text-sm font-semibold text-gray-100">Notifications</h2>
          <p className="text-xs text-gray-400">{unreadCount} unread</p>
        </div>
        <Button
          className="px-0 text-xs text-gray-400 hover:bg-transparent hover:text-gray-200"
          disabled={unreadCount === 0}
          onClick={() => void onMarkAllRead()}
          size="sm"
          variant="ghost"
        >
          Mark all read
        </Button>
      </div>

      {notifications.length > 0 ? (
        <div className="max-h-[400px] overflow-y-auto">
          {notifications.map((notification) => (
            <NotificationItem
              key={notification.id}
              notification={notification}
              onMarkRead={onMarkRead}
            />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center gap-3 px-6 py-10 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gray-800 text-gray-300">
            <svg
              aria-hidden="true"
              className="h-6 w-6"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              viewBox="0 0 24 24"
            >
              <path
                d="M15 17h5l-1.4-1.4a2 2 0 0 1-.6-1.4V11a6 6 0 1 0-12 0v3.2a2 2 0 0 1-.6 1.4L4 17h5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path d="M10 17a2 2 0 0 0 4 0" strokeLinecap="round" />
            </svg>
          </div>
          <div className="space-y-1">
            <p className="text-sm font-medium text-gray-100">You're all caught up!</p>
            <p className="text-sm text-gray-400">
              New activity will appear here in real time.
            </p>
          </div>
        </div>
      )}

      <div className="border-t border-gray-800 px-4 py-3 text-right">
        <Link
          className="text-sm font-medium text-indigo-300 transition hover:text-indigo-200"
          onClick={onClose}
          to="/settings/notifications"
        >
          View all
        </Link>
      </div>
    </Card>
  );
}
