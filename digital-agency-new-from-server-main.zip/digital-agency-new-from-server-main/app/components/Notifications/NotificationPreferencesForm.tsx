'use client';

import { useState } from 'react';
import { useToast } from '~/components/Notifications/ToastContainer';
import { Button, Card } from '~/components/ui';
import type { NotificationPreferences } from '~/types/notifications';

interface NotificationPreferencesFormProps {
  email: string;
  initialPreferences: NotificationPreferences;
}

interface ToggleOption {
  key: keyof Pick<
    NotificationPreferences,
    | 'workflowComplete'
    | 'workflowFailed'
    | 'sandboxTimeout'
    | 'teamInvite'
    | 'artifactReady'
  >;
  label: string;
  description: string;
}

const IN_APP_OPTIONS: ToggleOption[] = [
  {
    description: 'When a workflow finishes successfully',
    key: 'workflowComplete',
    label: 'Workflow Complete',
  },
  {
    description: 'When a workflow step fails',
    key: 'workflowFailed',
    label: 'Workflow Failed',
  },
  {
    description: 'When sandbox approaches its time limit',
    key: 'sandboxTimeout',
    label: 'Sandbox Timeout',
  },
  {
    description: 'When someone invites you to a team',
    key: 'teamInvite',
    label: 'Team Invite',
  },
  {
    description: 'When a file archive is ready to download',
    key: 'artifactReady',
    label: 'Artifact Ready',
  },
];

function ToggleRow({
  checked,
  description,
  label,
  onChange,
}: {
  checked: boolean;
  description: string;
  label: string;
  onChange: (checked: boolean) => void;
}) {
  return (
    <label className="flex items-start justify-between gap-4 rounded-xl border border-gray-800 bg-gray-800/40 px-4 py-3">
      <span className="space-y-1">
        <span className="block text-sm font-medium text-gray-100">{label}</span>
        <span className="block text-sm text-gray-400">{description}</span>
      </span>
      <input
        checked={checked}
        className="mt-1 h-4 w-4 rounded border-gray-700 bg-gray-950 text-indigo-500 focus:ring-indigo-500"
        onChange={(event) => onChange(event.target.checked)}
        type="checkbox"
      />
    </label>
  );
}

export function NotificationPreferencesForm({
  email,
  initialPreferences,
}: NotificationPreferencesFormProps) {
  const [preferences, setPreferences] =
    useState<NotificationPreferences>(initialPreferences);
  const [isSaving, setIsSaving] = useState(false);
  const [isTestingWebhook, setIsTestingWebhook] = useState(false);
  const { addToast } = useToast();

  const updatePreference = <K extends keyof NotificationPreferences>(
    key: K,
    value: NotificationPreferences[K],
  ) => {
    setPreferences((current) => ({ ...current, [key]: value }));
  };

  const savePreferences = async () => {
    setIsSaving(true);

    try {
      const response = await fetch('/api/notifications/preferences', {
        body: JSON.stringify(preferences),
        headers: { 'Content-Type': 'application/json' },
        method: 'PUT',
      });
      const payload = (await response.json().catch(() => null)) as
        | { error?: string; preferences?: NotificationPreferences }
        | null;

      if (!response.ok) {
        throw new Error(payload?.error ?? 'Unable to save preferences');
      }

      if (payload?.preferences) {
        setPreferences(payload.preferences);
      }

      addToast({
        message: 'Your notification settings were updated.',
        title: 'Preferences saved',
        type: 'success',
      });
    } catch (error) {
      addToast({
        message: error instanceof Error ? error.message : 'Unable to save preferences',
        title: 'Save failed',
        type: 'error',
      });
    } finally {
      setIsSaving(false);
    }
  };

  const testWebhook = async () => {
    if (!preferences.webhookUrl) {
      addToast({
        message: 'Add a webhook URL before sending a test.',
        title: 'Webhook URL required',
        type: 'warning',
      });
      return;
    }

    setIsTestingWebhook(true);

    try {
      const response = await fetch('/api/notifications/preferences', {
        body: JSON.stringify({ test: true, webhookUrl: preferences.webhookUrl }),
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
      });
      const payload = (await response.json().catch(() => null)) as { error?: string } | null;

      if (!response.ok) {
        throw new Error(payload?.error ?? 'Unable to test webhook');
      }

      addToast({
        message: 'A test payload was sent to your webhook endpoint.',
        title: 'Webhook test sent',
        type: 'success',
      });
    } catch (error) {
      addToast({
        message: error instanceof Error ? error.message : 'Unable to test webhook',
        title: 'Webhook test failed',
        type: 'error',
      });
    } finally {
      setIsTestingWebhook(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-semibold text-gray-100">Notification Settings</h1>
        <p className="text-sm text-gray-400">
          Choose how you want to stay up to date on workflow progress, sandboxes,
          and team activity.
        </p>
      </div>

      <Card title="In-App Notifications" description="Manage live alerts inside the platform.">
        <div className="space-y-3">
          {IN_APP_OPTIONS.map((option) => (
            <ToggleRow
              checked={preferences[option.key]}
              description={option.description}
              key={option.key}
              label={option.label}
              onChange={(checked) => updatePreference(option.key, checked)}
            />
          ))}
        </div>
      </Card>

      <Card title="Email Notifications" description="Use email for high-signal updates.">
        <div className="space-y-4">
          <ToggleRow
            checked={preferences.emailEnabled}
            description="Receive notification summaries by email"
            label="Enable email notifications"
            onChange={(checked) => updatePreference('emailEnabled', checked)}
          />
          {preferences.emailEnabled ? (
            <label className="block space-y-2 text-sm text-gray-200">
              <span>Email address</span>
              <input
                className="w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100"
                readOnly
                type="email"
                value={email}
              />
            </label>
          ) : null}
        </div>
      </Card>

      <Card title="Webhook" description="Send notifications to an external system.">
        <div className="space-y-4">
          <label className="block space-y-2 text-sm text-gray-200">
            <span>Webhook URL</span>
            <input
              className="w-full rounded-lg border border-gray-700 bg-gray-950 px-3 py-2 text-gray-100"
              onChange={(event) => updatePreference('webhookUrl', event.target.value || null)}
              placeholder="https://example.com/hooks/notifications"
              type="url"
              value={preferences.webhookUrl ?? ''}
            />
          </label>
          <div className="flex flex-wrap gap-3">
            <Button
              loading={isTestingWebhook}
              onClick={testWebhook}
              variant="secondary"
            >
              Test Webhook
            </Button>
            <Button loading={isSaving} onClick={savePreferences}>
              Save Preferences
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
