'use client';

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type PropsWithChildren,
} from 'react';
import { cn } from '~/lib/utils';

export interface Toast {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message?: string;
}

interface ToastContextValue {
  addToast: (toast: Omit<Toast, 'id'>) => void;
  removeToast: (id: string) => void;
  toasts: Toast[];
}

const ToastContext = createContext<ToastContextValue | null>(null);
const TOAST_DURATION_MS = 4_000;

const TOAST_STYLES: Record<
  Toast['type'],
  { border: string; icon: string; iconClassName: string }
> = {
  error: {
    border: 'border-red-500',
    icon: '✕',
    iconClassName: 'bg-red-500/15 text-red-200',
  },
  info: {
    border: 'border-sky-500',
    icon: 'ℹ',
    iconClassName: 'bg-sky-500/15 text-sky-200',
  },
  success: {
    border: 'border-emerald-500',
    icon: '✓',
    iconClassName: 'bg-emerald-500/15 text-emerald-200',
  },
  warning: {
    border: 'border-amber-500',
    icon: '⚠',
    iconClassName: 'bg-amber-500/15 text-amber-200',
  },
};

function createToastId() {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
    return crypto.randomUUID();
  }

  return `toast-${Date.now()}`;
}

export function ToastProvider({ children }: PropsWithChildren) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const timeoutsRef = useRef(new Map<string, number>());

  const removeToast = useCallback((id: string) => {
    const timeout = timeoutsRef.current.get(id);
    if (timeout != null) {
      window.clearTimeout(timeout);
      timeoutsRef.current.delete(id);
    }

    setToasts((current) => current.filter((toast) => toast.id !== id));
  }, []);

  const addToast = useCallback(
    (toast: Omit<Toast, 'id'>) => {
      const id = createToastId();
      setToasts((current) => [...current, { ...toast, id }]);
      const timeout = window.setTimeout(() => {
        removeToast(id);
      }, TOAST_DURATION_MS);
      timeoutsRef.current.set(id, timeout);
    },
    [removeToast],
  );

  useEffect(() => {
    return () => {
      for (const timeout of timeoutsRef.current.values()) {
        window.clearTimeout(timeout);
      }
      timeoutsRef.current.clear();
    };
  }, []);

  const value = useMemo(
    () => ({ addToast, removeToast, toasts }),
    [addToast, removeToast, toasts],
  );

  return <ToastContext.Provider value={value}>{children}</ToastContext.Provider>;
}

export function useToast() {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error('useToast must be used within a ToastProvider');
  }

  return context;
}

export function ToastContainer() {
  const { removeToast, toasts } = useToast();

  return (
    <div className="fixed bottom-4 right-4 z-50 flex w-full max-w-sm flex-col gap-3">
      {toasts.map((toast) => {
        const style = TOAST_STYLES[toast.type];

        return (
          <div
            className={cn(
              'pointer-events-auto transform rounded-xl border border-gray-800 border-l-4 bg-gray-900 p-4 shadow-xl shadow-black/40 transition-all duration-300 translate-x-0',
              style.border,
            )}
            data-testid={`toast-${toast.type}`}
            key={toast.id}
          >
            <div className="flex items-start gap-3">
              <span
                className={cn(
                  'flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-sm font-semibold',
                  style.iconClassName,
                )}
              >
                {style.icon}
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold text-gray-100">{toast.title}</p>
                {toast.message ? (
                  <p className="mt-1 text-sm text-gray-300">{toast.message}</p>
                ) : null}
              </div>
              <button
                aria-label="Dismiss notification"
                className="text-gray-400 transition hover:text-gray-200"
                onClick={() => removeToast(toast.id)}
                type="button"
              >
                ×
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}
