'use client';

import { Badge } from '~/components/ui/Badge';
import { Button } from '~/components/ui/Button';
import { Card } from '~/components/ui/Card';
import type { BillingPlan } from './billing-config';
import { PLAN_DETAILS, formatResetDate } from './billing-config';

interface CurrentPlanCardProps {
  plan: BillingPlan;
  periodEnd: Date | string;
  onUpgrade?: () => void;
}

export function CurrentPlanCard({ plan, periodEnd, onUpgrade }: CurrentPlanCardProps) {
  const details = PLAN_DETAILS[plan];

  return (
    <Card>
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-gray-700 bg-gray-800 text-2xl">
              {details.icon}
            </div>
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-xl font-semibold text-gray-100">{plan} Plan</h2>
                <Badge className={details.badgeClassName}>{plan}</Badge>
              </div>
              <p className="text-sm text-gray-400">{formatResetDate(periodEnd)}</p>
            </div>
          </div>
          <p className="text-sm text-gray-400">
            Stripe not configured — upgrades are instant for demo.
          </p>
        </div>

        {plan !== 'TEAM' ? (
          <Button onClick={onUpgrade}>{plan === 'FREE' ? 'Upgrade Plan' : 'Upgrade to TEAM'}</Button>
        ) : null}
      </div>
    </Card>
  );
}
