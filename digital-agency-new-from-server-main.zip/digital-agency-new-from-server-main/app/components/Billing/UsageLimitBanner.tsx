'use client';

import { useEffect, useMemo, useState } from 'react';
import type { BillingUsageSummary } from './billing-config';
import { UpgradeModal } from './UpgradeModal';

interface UsageLimitBannerProps {
  usage?: BillingUsageSummary | null;
}

const DISMISS_KEY = 'billing-limit-banner-dismissed';

export function UsageLimitBanner({ usage }: UsageLimitBannerProps) {
  const [dismissed, setDismissed] = useState(false);
  const [isUpgradeOpen, setIsUpgradeOpen] = useState(false);
  const [fetchedUsage, setFetchedUsage] = useState<BillingUsageSummary | null>(null);

  useEffect(() => {
    setDismissed(window.localStorage.getItem(DISMISS_KEY) === 'true');
  }, []);

  useEffect(() => {
    if (usage !== undefined) {
      setFetchedUsage(usage);
      return;
    }

    let cancelled = false;

    void (async () => {
      try {
        const response = await fetch('/api/billing/usage');
        if (response.status === 401 || !response.ok) {
          if (!cancelled) {
            setFetchedUsage(null);
          }
          return;
        }

        const payload = (await response.json()) as { usage?: BillingUsageSummary };
        if (!cancelled) {
          setFetchedUsage(payload.usage ?? null);
        }
      } catch {
        if (!cancelled) {
          setFetchedUsage(null);
        }
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [usage]);

  const activeUsage = usage === undefined ? fetchedUsage : usage;
  const severity = useMemo(() => {
    if (!activeUsage) {
      return null;
    }

    if (activeUsage.isOverLimit) {
      return 'over';
    }

    if (activeUsage.isNearLimit) {
      return 'near';
    }

    return null;
  }, [activeUsage]);

  if (!activeUsage || !severity || dismissed) {
    return null;
  }

  const isOver = severity === 'over';

  return (
    <>
      <div
        className={isOver
          ? 'sticky top-0 z-30 w-full border-t border-red-500/30 bg-red-500/10'
          : 'sticky top-0 z-30 w-full border-t border-amber-500/30 bg-amber-500/10'}
      >
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3">
          <p className={isOver ? 'text-sm text-red-100' : 'text-sm text-amber-100'}>
            {isOver
              ? "🚫 You've reached your plan limits. New sandboxes and AI requests are paused."
              : "⚠️ You're approaching your plan limits. Upgrade to avoid interruptions."}
          </p>
          <div className="flex items-center gap-3">
            <button
              className={isOver ? 'text-sm font-medium text-red-100 hover:text-white' : 'text-sm font-medium text-amber-100 hover:text-white'}
              onClick={() => setIsUpgradeOpen(true)}
              type="button"
            >
              {isOver ? 'Upgrade Now →' : 'Upgrade Plan →'}
            </button>
            <button
              aria-label="Dismiss billing banner"
              className="text-lg leading-none text-gray-300 hover:text-white"
              onClick={() => {
                window.localStorage.setItem(DISMISS_KEY, 'true');
                setDismissed(true);
              }}
              type="button"
            >
              ×
            </button>
          </div>
        </div>
      </div>

      <UpgradeModal
        currentPlan={activeUsage.plan}
        isOpen={isUpgradeOpen}
        onClose={() => setIsUpgradeOpen(false)}
        onUpgraded={() => {
          window.localStorage.removeItem(DISMISS_KEY);
          setDismissed(false);
          if (usage === undefined) {
            void fetch('/api/billing/usage')
              .then(async (response) => {
                if (!response.ok) {
                  return null;
                }
                const payload = (await response.json()) as { usage?: BillingUsageSummary };
                return payload.usage ?? null;
              })
              .then((nextUsage) => {
                if (nextUsage) {
                  setFetchedUsage(nextUsage);
                }
              })
              .catch(() => undefined);
          }
        }}
      />
    </>
  );
}
