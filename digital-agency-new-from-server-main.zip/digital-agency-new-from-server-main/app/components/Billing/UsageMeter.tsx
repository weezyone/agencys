'use client';

import { cn } from '~/lib/utils';
import {
  clampUsagePercent,
  formatUsageValue,
  getRoundedPercent,
  getUsageMeterColorClass,
} from './billing-config';

interface UsageMeterProps {
  label: string;
  used: number;
  limit: number;
  percent: number;
  unit: 'hours' | 'tokens' | 'projects';
  formatValue?: (value: number) => string;
}

function toTestId(label: string) {
  return label.toLowerCase().replace(/[^a-z0-9]+/g, '-');
}

export function UsageMeter({
  label,
  used,
  limit,
  percent,
  unit,
  formatValue,
}: UsageMeterProps) {
  const formattedValue = formatValue ?? ((value: number) => formatUsageValue(value, unit));
  const roundedPercent = getRoundedPercent(percent);
  const clampedPercent = clampUsagePercent(percent);
  const isOverLimit = percent >= 100;

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between gap-4 text-sm">
        <span className="font-medium text-gray-100">{label}</span>
        <span className="text-gray-400">
          {formattedValue(used)} / {formattedValue(limit)}
        </span>
      </div>
      <div className="flex items-center gap-3">
        <div className="h-2 flex-1 overflow-hidden rounded-full bg-gray-700">
          <div
            aria-label={`${label} usage`}
            className={cn('h-full rounded-full transition-all', getUsageMeterColorClass(percent))}
            data-testid={`usage-meter-fill-${toTestId(label)}`}
            style={{ width: `${clampedPercent}%` }}
          />
        </div>
        <span className="w-12 text-right text-sm text-gray-300">{roundedPercent}%</span>
      </div>
      {isOverLimit ? (
        <p className="text-sm text-red-300">Limit reached — upgrade to continue</p>
      ) : null}
    </div>
  );
}
