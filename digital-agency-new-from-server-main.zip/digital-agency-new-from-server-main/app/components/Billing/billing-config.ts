export type BillingPlan = 'FREE' | 'PRO' | 'TEAM';

export interface BillingUsageSummary {
  plan: BillingPlan;
  sandboxHours: { used: number; limit: number; percent: number };
  aiTokens: { used: number; limit: number; percent: number };
  projects: { used: number; limit: number; percent: number };
  periodStart: Date | string;
  periodEnd: Date | string;
  isNearLimit: boolean;
  isOverLimit: boolean;
}

export const PLAN_ORDER: BillingPlan[] = ['FREE', 'PRO', 'TEAM'];

export const PLAN_DETAILS: Record<
  BillingPlan,
  {
    badgeClassName: string;
    buttonLabel: string;
    icon: string;
    maxTimeout: string;
    maxVcpus: string;
    price: string;
    projects: string;
    sandboxHours: string;
    tokens: string;
  }
> = {
  FREE: {
    badgeClassName: 'border-gray-700 bg-gray-800 text-gray-200',
    buttonLabel: 'Current plan',
    icon: '⚡',
    maxTimeout: '30min',
    maxVcpus: '2',
    price: '$0/mo',
    projects: '3',
    sandboxHours: '10/mo',
    tokens: '100K/mo',
  },
  PRO: {
    badgeClassName: 'border-indigo-500/30 bg-indigo-500/10 text-indigo-200',
    buttonLabel: 'Upgrade to PRO',
    icon: '🚀',
    maxTimeout: '2hr',
    maxVcpus: '4',
    price: '$29/mo',
    projects: '20',
    sandboxHours: '100/mo',
    tokens: '1M/mo',
  },
  TEAM: {
    badgeClassName: 'border-amber-500/30 bg-amber-500/10 text-amber-200',
    buttonLabel: 'Upgrade to TEAM',
    icon: '🏢',
    maxTimeout: '5hr',
    maxVcpus: '8',
    price: '$99/mo',
    projects: '100',
    sandboxHours: '500/mo',
    tokens: '5M/mo',
  },
};

export const PLAN_COMPARISON_ROWS = [
  { key: 'price', label: 'Price' },
  { key: 'sandboxHours', label: 'Sandbox hrs' },
  { key: 'tokens', label: 'AI tokens' },
  { key: 'projects', label: 'Projects' },
  { key: 'maxVcpus', label: 'Max vCPUs' },
  { key: 'maxTimeout', label: 'Max timeout' },
] as const;

export function formatCompactNumber(value: number): string {
  if (value >= 1_000_000) {
    return `${stripTrailingZero((value / 1_000_000).toFixed(value % 1_000_000 === 0 ? 0 : 1))}M`;
  }

  if (value >= 1_000) {
    return `${stripTrailingZero((value / 1_000).toFixed(value % 1_000 === 0 ? 0 : 1))}K`;
  }

  return String(value);
}

export function formatHours(value: number): string {
  return `${stripTrailingZero(value.toFixed(value % 1 === 0 ? 0 : 1))}h`;
}

export function formatUsageValue(value: number, unit: 'hours' | 'tokens' | 'projects') {
  if (unit === 'hours') {
    return formatHours(value);
  }

  if (unit === 'tokens') {
    return formatCompactNumber(value);
  }

  return String(value);
}

export function formatResetDate(value: Date | string): string {
  const date = value instanceof Date ? value : new Date(value);
  return `Resets on ${new Intl.DateTimeFormat('en-US', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(date)}`;
}

export function getUsageMeterColorClass(percent: number): string {
  if (percent >= 100) {
    return 'bg-red-500 animate-pulse';
  }

  if (percent > 80) {
    return 'bg-orange-500';
  }

  if (percent > 60) {
    return 'bg-yellow-500';
  }

  return 'bg-indigo-500';
}

export function getRoundedPercent(percent: number): number {
  return Math.round(percent);
}

export function clampUsagePercent(percent: number): number {
  return Math.max(0, Math.min(percent, 100));
}

export function canUpgrade(currentPlan: BillingPlan, targetPlan: BillingPlan): boolean {
  return PLAN_ORDER.indexOf(targetPlan) > PLAN_ORDER.indexOf(currentPlan);
}

function stripTrailingZero(value: string) {
  return value.replace(/\.0$/, '');
}
