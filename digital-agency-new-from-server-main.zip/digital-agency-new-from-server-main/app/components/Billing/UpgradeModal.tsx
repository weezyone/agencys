'use client';

import { Modal } from '~/components/ui/Modal';
import type { BillingPlan } from './billing-config';
import { PlanComparisonTable } from './PlanComparisonTable';

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentPlan: BillingPlan;
  onUpgraded?: () => void;
}

export function UpgradeModal({
  isOpen,
  onClose,
  currentPlan,
  onUpgraded,
}: UpgradeModalProps) {
  return (
    <Modal onClose={onClose} open={isOpen} title="Upgrade your plan">
      <PlanComparisonTable
        currentPlan={currentPlan}
        onUpgraded={() => {
          onUpgraded?.();
          onClose();
        }}
        showDemoNote
      />
    </Modal>
  );
}
