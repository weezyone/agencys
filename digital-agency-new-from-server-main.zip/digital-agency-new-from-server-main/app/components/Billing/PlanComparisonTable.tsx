'use client';

import { useState } from 'react';
import { useToast } from '~/components/Notifications/ToastContainer';
import { Badge } from '~/components/ui/Badge';
import { Button } from '~/components/ui/Button';
import { cn } from '~/lib/utils';
import type { BillingPlan } from './billing-config';
import {
  PLAN_COMPARISON_ROWS,
  PLAN_DETAILS,
  PLAN_ORDER,
  canUpgrade,
} from './billing-config';

interface PlanComparisonTableProps {
  currentPlan: BillingPlan;
  onUpgraded?: () => void;
  showDemoNote?: boolean;
}

export function PlanComparisonTable({
  currentPlan,
  onUpgraded,
  showDemoNote = false,
}: PlanComparisonTableProps) {
  const { addToast } = useToast();
  const [upgradingPlan, setUpgradingPlan] = useState<BillingPlan | null>(null);

  async function handleUpgrade(plan: BillingPlan) {
    if (!canUpgrade(currentPlan, plan)) {
      return;
    }

    setUpgradingPlan(plan);

    try {
      const response = await fetch('/api/billing/upgrade', {
        body: JSON.stringify({ plan }),
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
      });
      const payload = (await response.json().catch(() => null)) as
        | { error?: string; message?: string; note?: string }
        | null;

      if (!response.ok) {
        throw new Error(payload?.error ?? 'Unable to upgrade plan.');
      }

      addToast({
        message: payload?.note ?? 'Your new limits are available now.',
        title: payload?.message ?? `Plan upgraded to ${plan}`,
        type: 'success',
      });
      onUpgraded?.();
    } catch (error) {
      addToast({
        message: error instanceof Error ? error.message : 'Unable to upgrade plan.',
        title: 'Upgrade failed',
        type: 'error',
      });
    } finally {
      setUpgradingPlan(null);
    }
  }

  return (
    <div className="space-y-4">
      <div className="overflow-x-auto rounded-2xl border border-gray-800">
        <table className="min-w-full border-separate border-spacing-0 bg-gray-900 text-sm text-gray-200">
          <thead>
            <tr>
              <th className="border-b border-gray-800 bg-gray-900 px-4 py-4 text-left text-gray-400">
                
              </th>
              {PLAN_ORDER.map((plan) => {
                const details = PLAN_DETAILS[plan];
                const isCurrent = currentPlan === plan;

                return (
                  <th
                    className={cn(
                      'border-b border-l border-gray-800 bg-gray-900 px-4 py-4 text-center align-top',
                      isCurrent && 'border-indigo-500 bg-indigo-500/5',
                    )}
                    data-testid={`plan-column-${plan}`}
                    key={plan}
                  >
                    <div className="flex items-center justify-center gap-2">
                      <span aria-hidden="true" className="text-2xl">
                        {details.icon}
                      </span>
                      <span className="text-lg font-semibold text-gray-100">{plan}</span>
                    </div>
                    <div className="mt-2 h-7">
                      {isCurrent ? (
                        <Badge className="border-indigo-500/30 bg-indigo-500/10 text-indigo-200">
                          Current plan
                        </Badge>
                      ) : null}
                    </div>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {PLAN_COMPARISON_ROWS.map((row) => (
              <tr key={row.key}>
                <th className="border-b border-gray-800 bg-gray-900 px-4 py-3 text-left font-medium text-gray-400">
                  {row.label}
                </th>
                {PLAN_ORDER.map((plan) => {
                  const isCurrent = currentPlan === plan;

                  return (
                    <td
                      className={cn(
                        'border-b border-l border-gray-800 px-4 py-3 text-center',
                        isCurrent && 'border-indigo-500 bg-indigo-500/5',
                      )}
                      key={`${plan}-${row.key}`}
                    >
                      {PLAN_DETAILS[plan][row.key]}
                    </td>
                  );
                })}
              </tr>
            ))}
            <tr>
              <th className="bg-gray-900 px-4 py-4 text-left font-medium text-gray-400">
                Action
              </th>
              {PLAN_ORDER.map((plan) => {
                const details = PLAN_DETAILS[plan];
                const isCurrent = currentPlan === plan;
                const isUpgradeable = canUpgrade(currentPlan, plan);

                return (
                  <td
                    className={cn(
                      'border-l border-gray-800 px-4 py-4 text-center',
                      isCurrent && 'border-indigo-500 bg-indigo-500/5',
                    )}
                    key={`${plan}-action`}
                  >
                    {isCurrent ? (
                      <Button className="w-full" disabled variant="secondary">
                        Current plan
                      </Button>
                    ) : isUpgradeable ? (
                      <Button
                        className="w-full"
                        loading={upgradingPlan === plan}
                        onClick={() => void handleUpgrade(plan)}
                      >
                        {details.buttonLabel}
                      </Button>
                    ) : (
                      <Button className="w-full" disabled variant="ghost">
                        Not available
                      </Button>
                    )}
                  </td>
                );
              })}
            </tr>
          </tbody>
        </table>
      </div>

      {showDemoNote ? (
        <p className="text-sm text-gray-400">
          Demo mode: upgrades take effect immediately. No payment required.
        </p>
      ) : null}
    </div>
  );
}
