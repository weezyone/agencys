'use client';

import { useState } from 'react';
import { Button } from '~/components/ui/Button';

interface ExportButtonProps {
  days: number;
}

export function ExportButton({ days }: ExportButtonProps) {
  const [loading, setLoading] = useState(false);

  async function handleDownload() {
    setLoading(true);

    try {
      const response = await fetch(`/api/analytics/export?days=${days}&format=csv`);
      if (!response.ok) {
        throw new Error('Unable to export analytics');
      }

      const blob = await response.blob();
      const downloadUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = `analytics-${days}-days.csv`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(downloadUrl);
    } finally {
      setLoading(false);
    }
  }

  return (
    <Button loading={loading} onClick={handleDownload} size="sm" variant="secondary">
      Export CSV
    </Button>
  );
}
