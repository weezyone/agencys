import type { TimeSeriesPoint } from '~/lib/analytics.server';

export const SVG_WIDTH = 600;
export const SVG_HEIGHT = 200;
const PADDING = { top: 16, right: 16, bottom: 32, left: 48 };

export interface ChartPoint {
  x: number;
  y: number;
  point: TimeSeriesPoint;
}

export function formatChartValue(value: number): string {
  if (value >= 1_000_000) {
    return `${(value / 1_000_000).toFixed(1).replace(/\.0$/, '')}M`;
  }

  if (value >= 1_000) {
    return `${(value / 1_000).toFixed(value >= 10_000 ? 0 : 1).replace(/\.0$/, '')}K`;
  }

  return value % 1 === 0 ? `${value}` : value.toFixed(1);
}

export function getChartFrame() {
  return {
    ...PADDING,
    height: SVG_HEIGHT - PADDING.top - PADDING.bottom,
    width: SVG_WIDTH - PADDING.left - PADDING.right,
  };
}

export function getYAxisTicks(maxValue: number, formatY: (value: number) => string) {
  return Array.from({ length: 4 }, (_, index) => {
    const fraction = index / 3;
    const value = maxValue * (1 - fraction);
    const frame = getChartFrame();

    return {
      label: formatY(value),
      value,
      y: frame.top + fraction * frame.height,
    };
  });
}

export function getChartPoints(data: TimeSeriesPoint[], maxValue: number): ChartPoint[] {
  const frame = getChartFrame();

  return data.map((point, index) => ({
    point,
    x:
      data.length === 1
        ? frame.left + frame.width / 2
        : frame.left + (index / (data.length - 1)) * frame.width,
    y: frame.top + frame.height - (point.value / maxValue) * frame.height,
  }));
}

export function getSmoothPath(points: ChartPoint[]) {
  if (points.length === 0) {
    return '';
  }

  if (points.length === 1) {
    return `M ${points[0].x} ${points[0].y}`;
  }

  let path = `M ${points[0].x} ${points[0].y}`;

  for (let index = 0; index < points.length - 1; index += 1) {
    const current = points[index];
    const next = points[index + 1];
    const midX = (current.x + next.x) / 2;
    const midY = (current.y + next.y) / 2;

    path += ` Q ${current.x} ${current.y} ${midX} ${midY}`;
  }

  const lastPoint = points[points.length - 1];
  path += ` T ${lastPoint.x} ${lastPoint.y}`;

  return path;
}

export function getLabelPoints(data: TimeSeriesPoint[]) {
  const step = Math.max(1, Math.ceil(data.length / 6));
  const points = getChartPoints(data, 1);

  return points.filter((_, index) => index % step === 0 || index === points.length - 1);
}
