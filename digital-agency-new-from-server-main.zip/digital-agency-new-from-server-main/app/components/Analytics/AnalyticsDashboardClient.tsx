'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { DateRangePicker, type Period } from '~/components/Analytics/DateRangePicker';
import { ExportButton } from '~/components/Analytics/ExportButton';
import { LineChart } from '~/components/Analytics/LineChart';
import { MultiLineChart } from '~/components/Analytics/MultiLineChart';
import { OverviewCards } from '~/components/Analytics/OverviewCards';
import { RecentErrorsList } from '~/components/Analytics/RecentErrorsList';
import { TopProjectsTable } from '~/components/Analytics/TopProjectsTable';
import { Card } from '~/components/ui/Card';
import type { OverviewMetrics, TimeSeriesPoint } from '~/lib/analytics.server';

interface WorkflowSeries {
  total: TimeSeriesPoint[];
  successful: TimeSeriesPoint[];
  failed: TimeSeriesPoint[];
}

interface AiUsageSeries {
  claude: TimeSeriesPoint[];
  codex: TimeSeriesPoint[];
}

interface TopProject {
  projectId: string;
  eventCount: number;
  workflowCount: number;
  sandboxHours: number;
}

interface RecentError {
  projectId: string | null;
  failedStep: string | null;
  durationSeconds: number;
  occurredAt: string;
}

interface AnalyticsDashboardClientProps {
  initialOverview: OverviewMetrics;
  initialWorkflowSeries: WorkflowSeries;
  userId: string;
}

const EMPTY_AI_SERIES: AiUsageSeries = { claude: [], codex: [] };

function Skeleton({ className }: { className: string }) {
  return <div aria-hidden="true" className={`animate-pulse rounded-xl bg-gray-800 ${className}`} />;
}

async function fetchJson<T>(url: string) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Request failed: ${url}`);
  }

  return response.json() as Promise<T>;
}

export function AnalyticsDashboardClient({
  initialOverview,
  initialWorkflowSeries,
  userId: _userId,
}: AnalyticsDashboardClientProps) {
  const [period, setPeriod] = useState<Period>(30);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isBootstrapping, setIsBootstrapping] = useState(true);
  const [overview, setOverview] = useState(initialOverview);
  const [workflowSeries, setWorkflowSeries] = useState(initialWorkflowSeries);
  const [aiSeries, setAiSeries] = useState<AiUsageSeries>(EMPTY_AI_SERIES);
  const [sandboxUtilization, setSandboxUtilization] = useState<TimeSeriesPoint[]>([]);
  const [topProjects, setTopProjects] = useState<TopProject[]>([]);
  const [recentErrors, setRecentErrors] = useState<RecentError[]>([]);
  const requestIdRef = useRef(0);

  const loadAnalytics = useCallback(async (days: Period, options?: { bootstrap?: boolean }) => {
    const requestId = requestIdRef.current + 1;
    requestIdRef.current = requestId;

    if (options?.bootstrap) {
      setIsBootstrapping(true);
    } else {
      setIsRefreshing(true);
    }

    try {
      const [overviewResponse, workflowResponse, aiUsageResponse, sandboxResponse] = await Promise.all([
        fetchJson<{ metrics: OverviewMetrics }>(`/api/analytics/overview?days=${days}`),
        fetchJson<{
          timeSeries: WorkflowSeries;
          topProjects: TopProject[];
          recentErrors: RecentError[];
        }>(`/api/analytics/workflows?days=${days}`),
        fetchJson<{ timeSeries: AiUsageSeries }>(`/api/analytics/ai-usage?days=${days}`),
        fetchJson<{ utilization: TimeSeriesPoint[] }>(`/api/analytics/sandboxes?days=${days}`),
      ]);

      if (requestId !== requestIdRef.current) {
        return;
      }

      setOverview(overviewResponse.metrics);
      setWorkflowSeries(workflowResponse.timeSeries);
      setTopProjects(workflowResponse.topProjects);
      setRecentErrors(workflowResponse.recentErrors);
      setAiSeries(aiUsageResponse.timeSeries);
      setSandboxUtilization(sandboxResponse.utilization);
    } catch {
      // Preserve the last successful payload.
    } finally {
      if (requestId == requestIdRef.current) {
        setIsBootstrapping(false);
        setIsRefreshing(false);
      }
    }
  }, []);

  useEffect(() => {
    void loadAnalytics(30, { bootstrap: true });
  }, [loadAnalytics]);

  function handlePeriodChange(days: Period) {
    setPeriod(days);
    void loadAnalytics(days);
  }

  const showSkeletons = isRefreshing;
  const showSupplementalSkeletons = isBootstrapping && !showSkeletons;

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100">
      <main className="mx-auto max-w-7xl space-y-6 px-4 py-8 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h1 className="text-3xl font-semibold tracking-tight text-gray-100">Analytics</h1>
            <p className="mt-1 text-sm text-gray-400">Monitor workflow health, AI consumption, sandbox usage, and project activity.</p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <DateRangePicker onChange={handlePeriodChange} value={period} />
            <ExportButton days={period} />
          </div>
        </div>

        {showSkeletons ? (
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
            {Array.from({ length: 6 }).map((_, index) => (
              <Skeleton key={index} className="h-40" />
            ))}
          </div>
        ) : (
          <OverviewCards metrics={overview} />
        )}

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <Card className="border-gray-700 bg-gray-800" title="Workflow Activity">
            {showSkeletons ? (
              <Skeleton className="h-[240px] w-full" />
            ) : (
              <MultiLineChart
                series={[
                  { color: '#6366f1', data: workflowSeries.total, label: 'Total' },
                  { color: '#10b981', data: workflowSeries.successful, label: 'Successful' },
                  { color: '#ef4444', data: workflowSeries.failed, label: 'Failed' },
                ]}
              />
            )}
          </Card>

          <Card className="border-gray-700 bg-gray-800" title="AI Token Usage">
            {showSkeletons || showSupplementalSkeletons ? (
              <Skeleton className="h-[240px] w-full" />
            ) : (
              <MultiLineChart
                series={[
                  { color: '#f59e0b', data: aiSeries.claude, label: 'Claude' },
                  { color: '#3b82f6', data: aiSeries.codex, label: 'Codex' },
                ]}
              />
            )}
          </Card>
        </div>

        <Card className="border-gray-700 bg-gray-800" title="Sandbox Utilization (hours/day)">
          {showSkeletons || showSupplementalSkeletons ? (
            <Skeleton className="h-[240px] w-full" />
          ) : (
            <LineChart data={sandboxUtilization} formatY={(value) => `${value.toFixed(1)}h`} label="Hours / day" />
          )}
        </Card>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <Card className="border-gray-700 bg-gray-800" title="Top Projects">
            {showSkeletons || showSupplementalSkeletons ? <Skeleton className="h-[260px] w-full" /> : <TopProjectsTable projects={topProjects} />}
          </Card>
          <Card className="border-gray-700 bg-gray-800" title="Recent Errors">
            {showSkeletons || showSupplementalSkeletons ? <Skeleton className="h-[260px] w-full" /> : <RecentErrorsList errors={recentErrors} />}
          </Card>
        </div>
      </main>
    </div>
  );
}
