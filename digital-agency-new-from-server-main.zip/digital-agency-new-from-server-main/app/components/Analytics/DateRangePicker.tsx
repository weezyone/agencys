'use client';

export type Period = 7 | 30 | 90;

interface DateRangePickerProps {
  value: Period;
  onChange: (days: Period) => void;
}

const OPTIONS: Period[] = [7, 30, 90];

export function DateRangePicker({ onChange, value }: DateRangePickerProps) {
  return (
    <div className="flex items-center gap-2 rounded-xl border border-gray-700 bg-gray-900 p-1">
      {OPTIONS.map((option) => {
        const active = option === value;

        return (
          <button
            key={option}
            aria-pressed={active}
            className={active
              ? 'rounded-lg bg-indigo-600 px-3 py-2 text-sm font-medium text-white transition-colors'
              : 'rounded-lg bg-gray-800 px-3 py-2 text-sm font-medium text-gray-400 transition-colors hover:bg-gray-700 hover:text-gray-100'}
            onClick={() => onChange(option)}
            type="button"
          >
            {option} days
          </button>
        );
      })}
    </div>
  );
}
