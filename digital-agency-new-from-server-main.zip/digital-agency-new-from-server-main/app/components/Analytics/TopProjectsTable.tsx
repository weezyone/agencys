'use client';

interface TopProject {
  projectId: string;
  eventCount: number;
  workflowCount: number;
  sandboxHours: number;
}

interface TopProjectsTableProps {
  projects: TopProject[];
}

function truncateProjectId(projectId: string) {
  return projectId.length > 18
    ? `${projectId.slice(0, 8)}…${projectId.slice(-4)}`
    : projectId;
}

export function TopProjectsTable({ projects }: TopProjectsTableProps) {
  if (projects.length === 0) {
    return <p className="py-8 text-center text-sm text-gray-400">No project activity yet</p>;
  }

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full text-left text-sm text-gray-200">
        <thead>
          <tr className="border-b border-gray-700 text-xs uppercase tracking-wide text-gray-400">
            <th className="pb-3 font-medium">Project ID</th>
            <th className="pb-3 text-right font-medium">Events</th>
            <th className="pb-3 text-right font-medium">Workflows</th>
            <th className="pb-3 text-right font-medium">Sandbox Hours</th>
          </tr>
        </thead>
        <tbody>
          {projects.map((project) => (
            <tr key={project.projectId} className="border-b border-gray-800 last:border-b-0">
              <td className="py-3 font-mono text-xs text-gray-300">{truncateProjectId(project.projectId)}</td>
              <td className="py-3 text-right">{project.eventCount}</td>
              <td className="py-3 text-right">{project.workflowCount}</td>
              <td className="py-3 text-right">{project.sandboxHours.toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
