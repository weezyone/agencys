'use client';

import type { TimeSeriesPoint } from '~/lib/analytics.server';
import {
  SVG_HEIGHT,
  SVG_WIDTH,
  formatChartValue,
  getChartFrame,
  getChartPoints,
  getLabelPoints,
  getSmoothPath,
  getYAxisTicks,
} from './chart-utils';

interface LineChartProps {
  data: TimeSeriesPoint[];
  color?: string;
  height?: number;
  showGrid?: boolean;
  showDots?: boolean;
  label?: string;
  formatY?: (value: number) => string;
}

export function LineChart({
  color = '#6366f1',
  data,
  formatY = formatChartValue,
  height = 200,
  label,
  showDots = false,
  showGrid = true,
}: LineChartProps) {
  if (data.length === 0) {
    return (
      <div className="flex h-[200px] items-center justify-center rounded-xl border border-dashed border-gray-700 bg-gray-900 text-sm text-gray-400" style={{ height }}>
        No data for this period
      </div>
    );
  }

  const frame = getChartFrame();
  const maxValue = Math.max(...data.map((item) => item.value), 1);
  const points = getChartPoints(data, maxValue);
  const path = getSmoothPath(points);
  const areaPath = `${path} L ${points[points.length - 1].x} ${frame.top + frame.height} L ${points[0].x} ${frame.top + frame.height} Z`;
  const yTicks = getYAxisTicks(maxValue, formatY);
  const labelPoints = getLabelPoints(data);

  return (
    <div className="space-y-3">
      {label ? <p className="text-sm text-gray-400">{label}</p> : null}
      <svg
        aria-label={label ?? 'Line chart'}
        className="w-full"
        preserveAspectRatio="xMidYMid meet"
        role="img"
        style={{ height }}
        viewBox={`0 0 ${SVG_WIDTH} ${SVG_HEIGHT}`}
      >
        {showGrid
          ? yTicks.map((tick) => (
              <g key={tick.label}>
                <line
                  stroke="#374151"
                  strokeDasharray="4 4"
                  x1={frame.left}
                  x2={frame.left + frame.width}
                  y1={tick.y}
                  y2={tick.y}
                />
                <text fill="#9ca3af" fontSize="10" textAnchor="end" x={frame.left - 8} y={tick.y + 4}>
                  {tick.label}
                </text>
              </g>
            ))
          : null}

        <line stroke="#4b5563" x1={frame.left} x2={frame.left + frame.width} y1={frame.top + frame.height} y2={frame.top + frame.height} />
        <line stroke="#4b5563" x1={frame.left} x2={frame.left} y1={frame.top} y2={frame.top + frame.height} />

        <path d={areaPath} fill={color} fillOpacity="0.14" />
        <path d={path} fill="none" stroke={color} strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" />

        {points.map((chartPoint) => (
          <circle
            key={`${chartPoint.point.date}-${chartPoint.point.value}`}
            cx={chartPoint.x}
            cy={chartPoint.y}
            fill={showDots ? color : 'transparent'}
            r={showDots ? 4 : 10}
            stroke={showDots ? '#111827' : 'transparent'}
            strokeWidth={showDots ? 2 : 0}
          >
            <title>{`${chartPoint.point.date}: ${formatY(chartPoint.point.value)}`}</title>
          </circle>
        ))}

        {labelPoints.map((chartPoint) => (
          <text
            key={`label-${chartPoint.point.date}`}
            fill="#9ca3af"
            fontSize="10"
            textAnchor="middle"
            x={chartPoint.x}
            y={frame.top + frame.height + 18}
          >
            {chartPoint.point.date.slice(5)}
          </text>
        ))}
      </svg>
    </div>
  );
}
