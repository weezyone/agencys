'use client';

import type { TimeSeriesPoint } from '~/lib/analytics.server';
import {
  SVG_HEIGHT,
  SVG_WIDTH,
  formatChartValue,
  getChartFrame,
  getChartPoints,
  getLabelPoints,
  getSmoothPath,
  getYAxisTicks,
} from './chart-utils';

interface MultiLineChartProps {
  series: Array<{ label: string; data: TimeSeriesPoint[]; color: string }>;
  height?: number;
  showLegend?: boolean;
}

export function MultiLineChart({
  height = 200,
  series,
  showLegend = true,
}: MultiLineChartProps) {
  const combinedValues = series.flatMap((item) => item.data.map((point) => point.value));

  if (series.length === 0 || combinedValues.length === 0 || series.every((item) => item.data.length === 0)) {
    return (
      <div className="flex h-[200px] items-center justify-center rounded-xl border border-dashed border-gray-700 bg-gray-900 text-sm text-gray-400" style={{ height }}>
        No data for this period
      </div>
    );
  }

  const frame = getChartFrame();
  const maxValue = Math.max(...combinedValues, 1);
  const yTicks = getYAxisTicks(maxValue, formatChartValue);
  const primarySeries = series.find((item) => item.data.length > 0)?.data ?? [];
  const labelPoints = getLabelPoints(primarySeries);

  return (
    <div className="space-y-3">
      {showLegend ? (
        <div className="flex flex-wrap gap-4 text-xs text-gray-400">
          {series.map((item) => (
            <div key={item.label} className="flex items-center gap-2">
              <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: item.color }} />
              <span>{item.label}</span>
            </div>
          ))}
        </div>
      ) : null}

      <svg
        aria-label="Multi-line chart"
        className="w-full"
        preserveAspectRatio="xMidYMid meet"
        role="img"
        style={{ height }}
        viewBox={`0 0 ${SVG_WIDTH} ${SVG_HEIGHT}`}
      >
        {yTicks.map((tick) => (
          <g key={tick.label}>
            <line
              stroke="#374151"
              strokeDasharray="4 4"
              x1={frame.left}
              x2={frame.left + frame.width}
              y1={tick.y}
              y2={tick.y}
            />
            <text fill="#9ca3af" fontSize="10" textAnchor="end" x={frame.left - 8} y={tick.y + 4}>
              {tick.label}
            </text>
          </g>
        ))}

        <line stroke="#4b5563" x1={frame.left} x2={frame.left + frame.width} y1={frame.top + frame.height} y2={frame.top + frame.height} />
        <line stroke="#4b5563" x1={frame.left} x2={frame.left} y1={frame.top} y2={frame.top + frame.height} />

        {series.map((item) => {
          const points = getChartPoints(item.data, maxValue);
          const path = getSmoothPath(points);

          return (
            <path
              key={item.label}
              d={path}
              fill="none"
              stroke={item.color}
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="3"
            >
              <title>{item.label}</title>
            </path>
          );
        })}

        {series.flatMap((item) =>
          getChartPoints(item.data, maxValue).map((chartPoint) => (
            <circle
              key={`${item.label}-${chartPoint.point.date}`}
              cx={chartPoint.x}
              cy={chartPoint.y}
              fill="transparent"
              r="9"
            >
              <title>{`${item.label} — ${chartPoint.point.date}: ${formatChartValue(chartPoint.point.value)}`}</title>
            </circle>
          )),
        )}

        {labelPoints.map((chartPoint) => (
          <text
            key={`label-${chartPoint.point.date}`}
            fill="#9ca3af"
            fontSize="10"
            textAnchor="middle"
            x={chartPoint.x}
            y={frame.top + frame.height + 18}
          >
            {chartPoint.point.date.slice(5)}
          </text>
        ))}
      </svg>
    </div>
  );
}
