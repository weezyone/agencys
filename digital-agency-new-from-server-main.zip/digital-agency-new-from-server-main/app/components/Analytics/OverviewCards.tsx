'use client';

import { Badge } from '~/components/ui/Badge';
import { Card } from '~/components/ui/Card';
import type { OverviewMetrics } from '~/lib/analytics.server';

interface OverviewCardsProps {
  metrics: OverviewMetrics;
}

type Trend = 'up' | 'down';

export function formatNumber(value: number): string {
  if (value >= 1_000_000) {
    return `${(value / 1_000_000).toFixed(1).replace(/\.0$/, '')}M`;
  }

  if (value >= 1_000) {
    return `${(value / 1_000).toFixed(value >= 10_000 ? 0 : 1).replace(/\.0$/, '')}K`;
  }

  return `${Math.round(value)}`;
}

export function formatCost(value: number): string {
  return `$${value.toFixed(2)}`;
}

export function formatHours(value: number): string {
  return `${value.toFixed(2)}h`;
}

function TrendIcon({ direction }: { direction: Trend }) {
  const rotation = direction === 'up' ? '-rotate-45' : 'rotate-45';
  const tone = direction === 'up' ? 'text-emerald-400' : 'text-red-400';

  return (
    <span className={`inline-flex h-8 w-8 items-center justify-center rounded-full bg-gray-800 ${tone}`}>
      <svg
        aria-hidden="true"
        className={`h-4 w-4 transform ${rotation}`}
        fill="none"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="2"
        viewBox="0 0 24 24"
      >
        <path d="M5 12h14" />
        <path d="m12 5 7 7-7 7" />
      </svg>
    </span>
  );
}

function MetricCard({
  badge,
  label,
  secondary,
  trend,
  value,
}: {
  badge?: { label: string; variant: 'success' | 'error' | 'warning' | 'default' };
  label: string;
  secondary: string;
  trend: Trend;
  value: string;
}) {
  return (
    <Card className="border-gray-700 bg-gray-800">
      <div className="flex items-start justify-between gap-4">
        <div className="space-y-3">
          <p className="text-sm font-medium text-gray-400">{label}</p>
          <p className="text-3xl font-semibold tracking-tight text-gray-100">{value}</p>
          <p className="text-sm text-gray-400">{secondary}</p>
          {badge ? <Badge variant={badge.variant}>{badge.label}</Badge> : null}
        </div>
        <TrendIcon direction={trend} />
      </div>
    </Card>
  );
}

export function OverviewCards({ metrics }: OverviewCardsProps) {
  const successBadge: {
    label: string;
    variant: 'success' | 'error';
  } = {
    label: `${metrics.successRate.toFixed(1)}% success`,
    variant: metrics.successRate > 80 ? 'success' : 'error',
  };

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
      <MetricCard
        badge={successBadge}
        label="Workflows"
        secondary={`${formatNumber(metrics.successfulWorkflows)} completed this period`}
        trend={metrics.successRate > 80 ? 'up' : 'down'}
        value={formatNumber(metrics.totalWorkflows)}
      />
      <MetricCard
        label="Sandbox Hours"
        secondary="this period"
        trend={metrics.totalSandboxHours > 0 ? 'up' : 'down'}
        value={formatHours(metrics.totalSandboxHours)}
      />
      <MetricCard
        label="AI Tokens"
        secondary="Claude / Codex mix"
        trend={metrics.totalAiTokens > 0 ? 'up' : 'down'}
        value={formatNumber(metrics.totalAiTokens)}
      />
      <MetricCard
        label="Est. Cost"
        secondary="approximate"
        trend={metrics.estimatedCostUsd > 0 ? 'up' : 'down'}
        value={formatCost(metrics.estimatedCostUsd)}
      />
      <MetricCard
        label="Active Projects"
        secondary="active during this period"
        trend={metrics.activeProjectsCount > 0 ? 'up' : 'down'}
        value={formatNumber(metrics.activeProjectsCount)}
      />
      <MetricCard
        badge={successBadge}
        label="Artifacts"
        secondary="generated successfully"
        trend={metrics.totalArtifacts > 0 ? 'up' : 'down'}
        value={formatNumber(metrics.totalArtifacts)}
      />
    </div>
  );
}
