'use client';

import { Badge } from '~/components/ui/Badge';

interface RecentError {
  projectId: string | null;
  failedStep: string | null;
  durationSeconds: number;
  occurredAt: Date | string;
}

interface RecentErrorsListProps {
  errors: RecentError[];
}

function formatTimeAgo(value: Date | string) {
  const date = value instanceof Date ? value : new Date(value);
  const diffMinutes = Math.max(0, Math.round((Date.now() - date.getTime()) / 60_000));

  if (diffMinutes < 1) {
    return 'just now';
  }

  if (diffMinutes < 60) {
    return `${diffMinutes}m ago`;
  }

  const diffHours = Math.round(diffMinutes / 60);
  if (diffHours < 24) {
    return `${diffHours}h ago`;
  }

  return `${Math.round(diffHours / 24)}d ago`;
}

export function RecentErrorsList({ errors }: RecentErrorsListProps) {
  if (errors.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center gap-3 py-8 text-center">
        <svg
          aria-label="No recent errors"
          className="h-8 w-8 text-emerald-400"
          fill="none"
          stroke="currentColor"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2"
          viewBox="0 0 24 24"
        >
          <path d="M9 12.75 11.25 15 15 9.75" />
          <circle cx="12" cy="12" r="9" />
        </svg>
        <p className="text-sm text-gray-300">No recent errors</p>
      </div>
    );
  }

  return (
    <ul className="space-y-3">
      {errors.map((error, index) => (
        <li key={`${error.projectId ?? 'unknown'}-${index}`} className="flex items-start gap-3 rounded-xl border border-gray-800 bg-gray-900 px-4 py-3">
          <span aria-hidden="true" className="mt-1.5 h-2.5 w-2.5 rounded-full bg-red-500" />
          <div className="min-w-0 flex-1 space-y-2">
            <p className="text-sm text-gray-100">
              workflow failed at {error.failedStep ?? 'unknown step'}
            </p>
            <div className="flex flex-wrap items-center gap-2 text-xs text-gray-400">
              {error.projectId ? <Badge className="font-mono normal-case" variant="error">{error.projectId.slice(0, 8)}</Badge> : null}
              <span>{formatTimeAgo(error.occurredAt)}</span>
              <span>{Math.round(error.durationSeconds)}s duration</span>
            </div>
          </div>
        </li>
      ))}
    </ul>
  );
}
