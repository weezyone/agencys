'use client';

import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router';
import {
  Badge,
  Button,
  Card,
  StatusIndicator,
  workflowStatusToBadgeVariant,
} from '~/components/ui';
import { cn, formatRelativeTime } from '~/lib/utils';

interface ProviderStatus {
  id: string;
  name: string;
  available: boolean;
}

interface WorkflowHistoryItem {
  id: string;
  name: string;
  status: string;
  updatedAt: string;
}

interface SidebarProps {
  projectId: string;
  projectName: string;
  recentWorkflows?: WorkflowHistoryItem[];
  onToggleFileTree?: () => void;
}

export function Sidebar({
  onToggleFileTree,
  projectId,
  projectName,
  recentWorkflows = [],
}: SidebarProps) {
  const [providers, setProviders] = useState<ProviderStatus[]>([]);
  const [loadingProviders, setLoadingProviders] = useState(true);

  useEffect(() => {
    let active = true;

    const loadProviders = async () => {
      try {
        const response = await fetch('/api/ai/providers');
        const payload = (await response.json()) as {
          providers?: ProviderStatus[];
        };
        if (active) {
          setProviders(payload.providers ?? []);
        }
      } catch {
        if (active) {
          setProviders([]);
        }
      } finally {
        if (active) {
          setLoadingProviders(false);
        }
      }
    };

    void loadProviders();
    return () => {
      active = false;
    };
  }, []);

  const workflowItems = useMemo(
    () => recentWorkflows.slice(0, 5),
    [recentWorkflows],
  );

  return (
    <Card
      className="w-full lg:sticky lg:top-6 lg:max-w-sm lg:self-start"
      title={projectName}
      description={`Project ID: ${projectId}`}
    >
      <div className="space-y-6">
        <div className="space-y-3">
          <Button
            className="w-full"
            onClick={onToggleFileTree}
            variant="secondary"
          >
            Toggle File Tree
          </Button>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <Link
              className="rounded-lg border border-gray-800 bg-gray-800/50 px-3 py-2 text-center text-gray-200 transition hover:border-gray-700"
              to={`/workspace/${projectId}`}
            >
              Workspace
            </Link>
            <Link
              className="rounded-lg border border-gray-800 bg-gray-800/50 px-3 py-2 text-center text-gray-200 transition hover:border-gray-700"
              to="/"
            >
              Dashboard
            </Link>
          </div>
        </div>

        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-gray-100">
              Workflow history
            </h3>
            <Badge variant="default">Last 5</Badge>
          </div>
          {workflowItems.length === 0 ? (
            <div className="rounded-lg border border-dashed border-gray-800 px-3 py-4 text-sm text-gray-400">
              No recent workflows yet.
            </div>
          ) : (
            <ul className="space-y-2">
              {workflowItems.map((workflow) => (
                <li
                  key={workflow.id}
                  className="rounded-lg border border-gray-800 bg-gray-800/50 p-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium text-gray-100">
                        {workflow.name}
                      </p>
                      <p className="mt-1 text-xs text-gray-400">
                        {formatRelativeTime(new Date(workflow.updatedAt))}
                      </p>
                    </div>
                    <Badge
                      variant={workflowStatusToBadgeVariant(workflow.status)}
                    >
                      {workflow.status}
                    </Badge>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-gray-100">
              AI providers
            </h3>
            {loadingProviders ? (
              <span className="text-xs text-gray-500">Loading…</span>
            ) : null}
          </div>
          <div className="space-y-2">
            {providers.length === 0 && !loadingProviders ? (
              <div className="rounded-lg border border-dashed border-gray-800 px-3 py-4 text-sm text-gray-400">
                Provider status unavailable.
              </div>
            ) : null}
            {providers.map((provider) => (
              <div
                key={provider.id}
                className={cn(
                  'flex items-center justify-between rounded-lg border border-gray-800 px-3 py-2',
                  provider.available ? 'bg-gray-800/40' : 'bg-gray-900',
                )}
              >
                <span className="text-sm text-gray-200">{provider.name}</span>
                <StatusIndicator
                  label={provider.available ? 'Connected' : 'Missing key'}
                  status={provider.available ? 'connected' : 'error'}
                />
              </div>
            ))}
          </div>
        </section>
      </div>
    </Card>
  );
}
