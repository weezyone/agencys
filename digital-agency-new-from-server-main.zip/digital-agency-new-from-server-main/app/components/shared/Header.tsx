import { Form, Link } from 'react-router';
import { UsageLimitBanner } from '~/components/Billing/UsageLimitBanner';
import { NotificationBell } from '~/components/Notifications/NotificationBell';
import { TeamSwitcher } from '~/components/Team/TeamSwitcher';
import { Button } from '~/components/ui';

interface HeaderUser {
  name: string;
  email: string;
  avatarUrl?: string;
}

interface HeaderTeam {
  id: string;
  name: string;
}

interface HeaderProps {
  user?: HeaderUser | null;
  teams?: HeaderTeam[];
  currentTeamId?: string;
}

function getInitials(name: string) {
  return name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join('');
}

export function Header({ user, teams, currentTeamId }: HeaderProps) {
  return (
    <header className="border-b border-gray-800 bg-gray-950/95 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-4">
        <div className="flex items-center gap-6">
          <Link className="flex items-center gap-3" to="/">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-600/20 text-lg text-indigo-300">
              ☁️
            </div>
            <div>
              <p className="text-sm font-semibold text-gray-100">
                Cloud Dev Platform
              </p>
              <p className="text-xs text-gray-400">
                Cloud-first AI development
              </p>
            </div>
          </Link>
          {user ? (
            <TeamSwitcher currentTeamId={currentTeamId} teams={teams} />
          ) : null}
          <nav className="hidden items-center gap-2 md:flex">
            <Link
              className="rounded-lg px-3 py-2 text-sm text-gray-300 transition hover:bg-gray-800 hover:text-white"
              to="/"
            >
              Dashboard
            </Link>
            <Link
              className="rounded-lg px-3 py-2 text-sm text-gray-300 transition hover:bg-gray-800 hover:text-white"
              to="/settings"
            >
              Settings
            </Link>
          </nav>
        </div>

        <div className="flex items-center gap-3">
          <Link to={user ? '/?newProject=1' : '/auth/login'}>
            <Button size="sm" variant="secondary">
              New Project
            </Button>
          </Link>
          {user ? (
            <div className="flex items-center gap-3">
              <NotificationBell />
              {user.avatarUrl ? (
                <img
                  alt={user.name}
                  className="h-10 w-10 rounded-full border border-gray-800 object-cover"
                  src={user.avatarUrl}
                />
              ) : (
                <div className="flex h-10 w-10 items-center justify-center rounded-full border border-gray-800 bg-gray-900 text-sm font-semibold text-indigo-200">
                  {getInitials(user.name)}
                </div>
              )}
              <div className="hidden text-right sm:block">
                <p className="text-sm font-medium text-gray-100">{user.name}</p>
                <p className="text-xs text-gray-400">{user.email}</p>
              </div>
              <Form action="/auth/logout" method="post">
                <Button size="sm" type="submit" variant="ghost">
                  Logout
                </Button>
              </Form>
            </div>
          ) : (
            <Link to="/auth/login">
              <Button data-testid="login-btn" size="sm">
                Login
              </Button>
            </Link>
          )}
        </div>
      </div>
      {user ? <UsageLimitBanner /> : null}
    </header>
  );
}
