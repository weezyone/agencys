import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import {
  createUserSession,
  getSession,
  type SessionData,
} from '../lib/session.server';
import {
  generateCodeChallenge,
  generateCodeVerifier,
  generateState,
} from '../lib/auth.server';

const dbMock = vi.hoisted(() => ({
  userCreate: vi.fn(),
  userFindUnique: vi.fn(),
}));

const databaseAvailabilityMock = vi.hoisted(() => ({
  isConfiguredLocalDatabaseReachable: vi.fn(),
}));

vi.mock('~/lib/db.server', () => ({
  db: {
    user: {
      create: dbMock.userCreate,
      findUnique: dbMock.userFindUnique,
    },
  },
  default: {
    user: {
      create: dbMock.userCreate,
      findUnique: dbMock.userFindUnique,
    },
  },
}));

vi.mock('~/lib/database-availability.server', () => databaseAvailabilityMock);

const authLoginRoute = await import('../routes/auth.login');

const originalDatabaseUrl = process.env.DATABASE_URL;
const originalNodeEnv = process.env.NODE_ENV;

function restoreEnv() {
  if (originalDatabaseUrl === undefined) {
    delete process.env.DATABASE_URL;
  } else {
    process.env.DATABASE_URL = originalDatabaseUrl;
  }

  if (originalNodeEnv === undefined) {
    delete process.env.NODE_ENV;
  } else {
    process.env.NODE_ENV = originalNodeEnv;
  }
}

function createLoginRequest() {
  const body = new URLSearchParams();
  body.set('email', 'dev@example.com');
  body.set('password', 'password123');
  body.set('redirectTo', '/dashboard');

  return new Request('http://localhost/auth/login', {
    body,
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    method: 'POST',
  });
}

function createDatabaseUnavailableError() {
  return Object.assign(
    new Error("Can't reach database server at `localhost:5432`"),
    {
      errorCode: 'P1001',
      name: 'PrismaClientInitializationError',
    },
  );
}

function createMissingUsersTableError() {
  return Object.assign(
    new Error('The table `public.users` does not exist in the current database.'),
    {
      code: 'P2021',
      name: 'PrismaClientKnownRequestError',
    },
  );
}

beforeEach(() => {
  vi.clearAllMocks();
  restoreEnv();
  databaseAvailabilityMock.isConfiguredLocalDatabaseReachable.mockResolvedValue(
    true,
  );
});

afterEach(() => {
  restoreEnv();
});

describe('PKCE utilities', () => {
  it('generateCodeVerifier produces a valid verifier length', () => {
    const verifier = generateCodeVerifier();

    expect(verifier.length).toBeGreaterThanOrEqual(43);
    expect(verifier.length).toBeLessThanOrEqual(128);
    expect(verifier).toMatch(/^[A-Za-z0-9_-]+$/);
  });

  it('generateCodeChallenge returns a base64url sha256 hash', () => {
    const verifier = 'dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk';

    expect(generateCodeChallenge(verifier)).toBe(
      'E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM',
    );
  });

  it('generateState returns a non-empty random string', () => {
    const first = generateState();
    const second = generateState();

    expect(first).toBeTruthy();
    expect(second).toBeTruthy();
    expect(first).not.toBe(second);
  });
});

describe('session storage', () => {
  it('getSession returns null for a missing cookie', async () => {
    const request = new Request('http://localhost/');

    await expect(getSession(request)).resolves.toBeNull();
  });

  it('serializes and deserializes session data', async () => {
    const userData: SessionData = {
      userId: 'user-123',
      email: 'user@example.com',
      name: 'Example User',
      avatarUrl: 'https://example.com/avatar.png',
      accessToken: 'secret-token',
      provider: 'github',
      expiresAt: Date.now() + 60_000,
    };

    const response = await createUserSession(userData, '/dashboard');
    const setCookie = response.headers.get('Set-Cookie');

    expect(setCookie).toBeTruthy();

    const request = new Request('http://localhost/dashboard', {
      headers: {
        Cookie: setCookie!.split(';')[0],
      },
    });

    await expect(getSession(request)).resolves.toEqual(userData);
  });
});

describe('login action database availability', () => {
  it('falls back to local auth in development when the configured database is unreachable', async () => {
    process.env.DATABASE_URL = 'postgresql://copilot:copilot@localhost:5432/copilot';
    process.env.NODE_ENV = 'development';
    databaseAvailabilityMock.isConfiguredLocalDatabaseReachable.mockResolvedValue(
      false,
    );

    const response = await authLoginRoute.action({
      request: createLoginRequest(),
    } as never);

    expect(response.status).toBe(302);
    expect(response.headers.get('Location')).toBe('/dashboard');
    expect(response.headers.get('Set-Cookie')).toContain('__cdp_session');
    expect(dbMock.userFindUnique).not.toHaveBeenCalled();
  });

  it('returns a 503 in production when the configured database is unreachable', async () => {
    process.env.DATABASE_URL = 'postgresql://copilot:copilot@localhost:5432/copilot';
    process.env.NODE_ENV = 'production';
    databaseAvailabilityMock.isConfiguredLocalDatabaseReachable.mockResolvedValue(
      false,
    );

    const response = await authLoginRoute.action({
      request: createLoginRequest(),
    } as never);

    await expect(response.json()).resolves.toEqual({
      error: 'Database is currently unavailable. Please try again later.',
    });
    expect(response.status).toBe(503);
    expect(dbMock.userFindUnique).not.toHaveBeenCalled();
  });

  it('returns a 503 when Prisma reports an unreachable hosted database', async () => {
    process.env.DATABASE_URL = 'postgresql://copilot.example.com/copilot';
    process.env.NODE_ENV = 'production';
    dbMock.userFindUnique.mockRejectedValue(createDatabaseUnavailableError());

    const response = await authLoginRoute.action({
      request: createLoginRequest(),
    } as never);

    await expect(response.json()).resolves.toEqual({
      error: 'Database is currently unavailable. Please try again later.',
    });
    expect(response.status).toBe(503);
    expect(dbMock.userFindUnique).toHaveBeenCalledTimes(1);
  });

  it('falls back to local auth in development when the users table is missing', async () => {
    process.env.DATABASE_URL = 'postgresql://copilot.example.com/copilot';
    process.env.NODE_ENV = 'development';
    dbMock.userFindUnique.mockRejectedValue(createMissingUsersTableError());

    const response = await authLoginRoute.action({
      request: createLoginRequest(),
    } as never);

    expect(response.status).toBe(302);
    expect(response.headers.get('Location')).toBe('/dashboard');
    expect(response.headers.get('Set-Cookie')).toContain('__cdp_session');
    expect(dbMock.userFindUnique).toHaveBeenCalledTimes(1);
  });

  it('returns a 503 in production when the users table is missing', async () => {
    process.env.DATABASE_URL = 'postgresql://copilot.example.com/copilot';
    process.env.NODE_ENV = 'production';
    dbMock.userFindUnique.mockRejectedValue(createMissingUsersTableError());

    const response = await authLoginRoute.action({
      request: createLoginRequest(),
    } as never);

    await expect(response.json()).resolves.toEqual({
      error: 'Database is currently unavailable. Please try again later.',
    });
    expect(response.status).toBe(503);
    expect(dbMock.userFindUnique).toHaveBeenCalledTimes(1);
  });
});
