import { beforeEach, describe, expect, it, vi } from 'vitest';

const userCountMock = vi.fn();
const projectCountMock = vi.fn();
const workflowCountMock = vi.fn();
const sandboxCountMock = vi.fn();
const userFindUniqueMock = vi.fn();
const userUpdateMock = vi.fn();
const analyticsEventFindFirstMock = vi.fn();
const auditLogCreateMock = vi.fn();
const queryRawMock = vi.fn();
const kvGetMock = vi.fn();
const kvSetMock = vi.fn();
const kvDelMock = vi.fn();
const getSessionMock = vi.fn();

vi.mock('../lib/db.server', () => ({
  db: {
    $queryRaw: queryRawMock,
    analyticsEvent: {
      findFirst: analyticsEventFindFirstMock,
    },
    auditLog: {
      create: auditLogCreateMock,
    },
    project: {
      count: projectCountMock,
    },
    sandbox: {
      count: sandboxCountMock,
    },
    user: {
      count: userCountMock,
      findUnique: userFindUniqueMock,
      update: userUpdateMock,
    },
    workflow: {
      count: workflowCountMock,
    },
  },
  default: {
    $queryRaw: queryRawMock,
    analyticsEvent: {
      findFirst: analyticsEventFindFirstMock,
    },
    auditLog: {
      create: auditLogCreateMock,
    },
    project: {
      count: projectCountMock,
    },
    sandbox: {
      count: sandboxCountMock,
    },
    user: {
      count: userCountMock,
      findUnique: userFindUniqueMock,
      update: userUpdateMock,
    },
    workflow: {
      count: workflowCountMock,
    },
  },
}));

vi.mock('../lib/kv.server', () => ({
  default: {
    del: kvDelMock,
    get: kvGetMock,
    set: kvSetMock,
  },
  kv: {
    del: kvDelMock,
    get: kvGetMock,
    set: kvSetMock,
  },
}));

vi.mock('../lib/session.server', () => ({
  getSession: getSessionMock,
}));

const adminModule = await import('../lib/admin.server');
const banCheckModule = await import('../lib/ban-check.server');

beforeEach(() => {
  vi.clearAllMocks();
  delete process.env.ADMIN_SECRET;

  userCountMock
    .mockResolvedValueOnce(25)
    .mockResolvedValueOnce(7);
  projectCountMock.mockResolvedValue(11);
  workflowCountMock
    .mockResolvedValueOnce(3)
    .mockResolvedValueOnce(2)
    .mockResolvedValueOnce(10)
    .mockResolvedValueOnce(4);
  sandboxCountMock.mockResolvedValue(8);
  userFindUniqueMock.mockResolvedValue({ id: 'admin-1', isAdmin: true, isBanned: false });
  userUpdateMock.mockResolvedValue(undefined);
  analyticsEventFindFirstMock.mockResolvedValue(null);
  auditLogCreateMock.mockResolvedValue(undefined);
  queryRawMock
    .mockResolvedValueOnce([
      {
        totalAiCostUsd: 1.5,
        totalAiRequests: 9,
        totalSandboxCpuSeconds: 7200,
      },
    ])
    .mockResolvedValueOnce([{ ok: 1 }])
    .mockResolvedValueOnce([
      {
        createdAt: new Date('2025-01-01T00:00:00.000Z'),
        id: 'log-1',
        newValues: null,
        oldValues: null,
        operation: 'ban_user',
        tableName: 'users',
        userId: 'admin-1',
      },
    ])
    .mockResolvedValueOnce([{ total: 1 }]);
  kvGetMock.mockResolvedValue(null);
  kvSetMock.mockResolvedValue(undefined);
  kvDelMock.mockResolvedValue(1);
  getSessionMock.mockResolvedValue(null);
});

describe('requireAdmin', () => {
  it('throws 403 when no session and no ADMIN_SECRET header', async () => {
    await expect(
      adminModule.requireAdmin(new Request('http://localhost/api/admin/stats')),
    ).rejects.toMatchObject({ status: 403 });
  });

  it('passes when X-Admin-Secret matches ADMIN_SECRET', async () => {
    process.env.ADMIN_SECRET = 'top-secret';

    await expect(
      adminModule.requireAdmin(
        new Request('http://localhost/api/admin/stats', {
          headers: { 'X-Admin-Secret': 'top-secret' },
        }),
      ),
    ).resolves.toEqual({ isServiceAdmin: true, userId: 'service-admin' });
  });
});

describe('getPlatformStats', () => {
  it('returns the expected shape', async () => {
    const stats = await adminModule.getPlatformStats();

    expect(stats).toEqual(
      expect.objectContaining({
        activeWorkflows: expect.any(Number),
        errorRate: expect.any(Number),
        estimatedPlatformCostUsd: expect.any(Number),
        failedWorkflowsLast24h: expect.any(Number),
        newUsersLast7Days: expect.any(Number),
        totalAiRequests: expect.any(Number),
        totalProjects: expect.any(Number),
        totalSandboxCpuHours: expect.any(Number),
        totalSandboxes: expect.any(Number),
        totalUsers: expect.any(Number),
      }),
    );
  });
});

describe('getSystemHealth', () => {
  it('returns database and kv health fields', async () => {
    const health = await adminModule.getSystemHealth();

    expect(health).toEqual(
      expect.objectContaining({
        database: expect.stringMatching(/ok|error/),
        kv: expect.stringMatching(/ok|error/),
      }),
    );
  });
});

describe('user mutations', () => {
  it('banUser sets isBanned to true and creates an audit log', async () => {
    await adminModule.banUser('user-1', 'admin-1', 'abuse');

    expect(userUpdateMock).toHaveBeenCalledWith({
      data: { isBanned: true },
      where: { id: 'user-1' },
    });
    expect(auditLogCreateMock).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ operation: 'ban_user' }),
      }),
    );
  });

  it('unbanUser sets isBanned to false', async () => {
    await adminModule.unbanUser('user-1', 'admin-1');

    expect(userUpdateMock).toHaveBeenCalledWith({
      data: { isBanned: false },
      where: { id: 'user-1' },
    });
  });

  it('promoteToAdmin sets isAdmin to true', async () => {
    await adminModule.promoteToAdmin('user-1', 'admin-1');

    expect(userUpdateMock).toHaveBeenCalledWith({
      data: { isAdmin: true },
      where: { id: 'user-1' },
    });
  });
});

describe('createImpersonationToken', () => {
  it('stores the token in KV with a TTL', async () => {
    const token = await adminModule.createImpersonationToken('user-1', 'admin-1');

    expect(token).toBeTruthy();
    expect(kvSetMock).toHaveBeenCalledWith(
      `impersonate:${token}`,
      expect.objectContaining({ adminId: 'admin-1', targetUserId: 'user-1' }),
      { ex: 60 * 60 },
    );
  });
});

describe('getAuditLogs', () => {
  it('passes pagination through to the database query', async () => {
    await adminModule.getAuditLogs({ action: 'ban_user', limit: 25, offset: 10, userId: 'user-1' });

    expect(queryRawMock).toHaveBeenCalledTimes(2);
  });
});

describe('checkNotBanned', () => {
  it('throws 403 when a user is banned', async () => {
    userFindUniqueMock.mockResolvedValueOnce({ isBanned: true });

    await expect(banCheckModule.checkNotBanned('user-1')).rejects.toMatchObject({
      status: 403,
    });
  });
});
