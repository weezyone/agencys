import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { CreateTeamModal } from '~/components/Team/CreateTeamModal';
import { InviteModal } from '~/components/Team/InviteModal';
import { MemberRow } from '~/components/Team/MemberRow';
import { TeamSwitcher } from '~/components/Team/TeamSwitcher';

afterEach(() => {
  vi.restoreAllMocks();
  window.localStorage.clear();
});

describe('InviteModal', () => {
  it('renders form fields when open', () => {
    render(
      <InviteModal isOpen onClose={vi.fn()} teamId="team-1" />,
    );

    expect(screen.getByLabelText(/Email address/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Role/i)).toBeInTheDocument();
  });

  it('closes without submitting when Cancel is clicked', async () => {
    const onClose = vi.fn();
    const fetchSpy = vi.spyOn(global, 'fetch');
    render(<InviteModal isOpen onClose={onClose} teamId="team-1" />);

    await userEvent.click(screen.getByRole('button', { name: 'Cancel' }));

    expect(onClose).toHaveBeenCalledTimes(1);
    expect(fetchSpy).not.toHaveBeenCalled();
  });
});

describe('CreateTeamModal', () => {
  it('validates empty team name by disabling submit', () => {
    render(<CreateTeamModal isOpen onClose={vi.fn()} />);

    expect(
      screen.getByRole('button', { name: 'Create team' }),
    ).toBeDisabled();
  });
});

describe('MemberRow', () => {
  const member = {
    id: 'member-1',
    joinedAt: '2025-01-01T00:00:00.000Z',
    role: 'OWNER',
    user: {
      avatarUrl: null,
      email: 'owner@example.com',
      id: 'user-1',
      name: 'Owner User',
    },
  };

  it('shows role badge with the correct color class', () => {
    render(
      <table>
        <tbody>
          <MemberRow
            currentUserId="user-2"
            currentUserRole="OWNER"
            member={member}
            teamId="team-1"
          />
        </tbody>
      </table>,
    );

    expect(screen.getByTestId('role-badge-user-1')).toHaveClass(
      'text-amber-200',
    );
  });

  it('hides remove button when viewer is member role', () => {
    render(
      <table>
        <tbody>
          <MemberRow
            currentUserId="user-2"
            currentUserRole="VIEWER"
            member={{ ...member, role: 'VIEWER' }}
            teamId="team-1"
          />
        </tbody>
      </table>,
    );

    expect(
      screen.queryByRole('button', { name: 'Remove' }),
    ).not.toBeInTheDocument();
  });
});

describe('TeamSwitcher', () => {
  it('renders Personal when no teams provided', () => {
    render(<TeamSwitcher teams={[]} />);
    expect(screen.getByRole('button', { name: /Personal/i })).toBeInTheDocument();
  });
});
