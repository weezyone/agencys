import { beforeEach, describe, expect, it, vi } from 'vitest';

const queryRawMock = vi.fn();
const executeRawMock = vi.fn();
const kvGetMock = vi.fn();
const kvSetMock = vi.fn();
const requireAuthMock = vi.fn();
const getOverviewMetricsRouteMock = vi.fn();

vi.mock('../lib/db.server', () => ({
  db: {
    $executeRaw: executeRawMock,
    $queryRaw: queryRawMock,
  },
  default: {
    $executeRaw: executeRawMock,
    $queryRaw: queryRawMock,
  },
}));

vi.mock('../lib/kv.server', () => ({
  default: {
    get: kvGetMock,
    set: kvSetMock,
  },
  kv: {
    get: kvGetMock,
    set: kvSetMock,
  },
}));

vi.mock('~/lib/session.server', () => ({
  requireAuth: requireAuthMock,
}));

vi.mock('~/lib/analytics.server', async () => {
  const actual = await vi.importActual<typeof import('../lib/analytics.server')>(
    '../lib/analytics.server',
  );

  return {
    ...actual,
    getOverviewMetrics: getOverviewMetricsRouteMock,
  };
});

const analyticsModule = await vi.importActual<typeof import('../lib/analytics.server')>(
  '../lib/analytics.server',
);
const analyticsOverviewApi = await import('../../api/analytics/overview');

beforeEach(() => {
  vi.clearAllMocks();
  executeRawMock.mockResolvedValue(1);
  queryRawMock.mockResolvedValue([]);
  kvGetMock.mockResolvedValue(null);
  kvSetMock.mockResolvedValue(undefined);
  requireAuthMock.mockResolvedValue({ userId: 'user-1' });
  getOverviewMetricsRouteMock.mockResolvedValue({
    activeProjectsCount: 0,
    estimatedCostUsd: 0,
    failedWorkflows: 0,
    successRate: 0,
    successfulWorkflows: 0,
    totalAiTokens: 0,
    totalArtifacts: 0,
    totalSandboxHours: 0,
    totalWorkflows: 0,
  });
});

describe('trackEvent', () => {
  it('never throws when the database is unavailable', async () => {
    executeRawMock.mockRejectedValue(new Error('db unavailable'));

    await expect(
      analyticsModule.trackEvent('user-1', 'workflow.started', {
        workflowType: 'cloud-task',
      }),
    ).resolves.toBeUndefined();
  });
});

describe('exportMetricsCsv', () => {
  it('returns CSV headers and rows', () => {
    const csv = analyticsModule.exportMetricsCsv(
      {
        activeProjectsCount: 1,
        estimatedCostUsd: 1.25,
        failedWorkflows: 1,
        successRate: 75,
        successfulWorkflows: 3,
        totalAiTokens: 500,
        totalArtifacts: 2,
        totalSandboxHours: 4,
        totalWorkflows: 4,
      },
      [{ date: '2025-01-01', value: 4 }],
    );

    expect(csv).toContain('metric,value');
    expect(csv).toContain('date,value');
    expect(csv).toContain('totalWorkflows,4');
    expect(csv).toContain('2025-01-01,4');
  });
});

describe('getOverviewMetrics', () => {
  it('returns zeros when there are no events', async () => {
    queryRawMock.mockResolvedValue([
      {
        active_projects_count: 0,
        failed_workflows: 0,
        successful_workflows: 0,
        total_ai_cost_usd: 0,
        total_ai_tokens: 0,
        total_artifacts: 0,
        total_sandbox_cpu_seconds: 0,
        total_workflows: 0,
      },
    ]);

    await expect(analyticsModule.getOverviewMetrics('user-1', 30)).resolves.toEqual(
      {
        activeProjectsCount: 0,
        estimatedCostUsd: 0,
        failedWorkflows: 0,
        successRate: 0,
        successfulWorkflows: 0,
        totalAiTokens: 0,
        totalArtifacts: 0,
        totalSandboxHours: 0,
        totalWorkflows: 0,
      },
    );
  });

  it('calculates sandbox cost from cpu seconds', async () => {
    queryRawMock.mockResolvedValue([
      {
        active_projects_count: 0,
        failed_workflows: 0,
        successful_workflows: 0,
        total_ai_cost_usd: 0,
        total_ai_tokens: 0,
        total_artifacts: 0,
        total_sandbox_cpu_seconds: 3600,
        total_workflows: 0,
      },
    ]);

    const metrics = await analyticsModule.getOverviewMetrics('user-1', 30);

    expect(metrics.totalSandboxHours).toBe(1);
    expect(metrics.estimatedCostUsd).toBe(0.0864);
  });
});

describe('time series helpers', () => {
  it('generates the requested number of daily workflow points', async () => {
    const today = new Date().toISOString().slice(0, 10);
    queryRawMock.mockResolvedValue([
      { date: today, failed: 1, successful: 1, total: 2 },
    ]);

    const result = await analyticsModule.getWorkflowTimeSeries('user-1', 7);

    expect(result.total).toHaveLength(7);
    expect(result.successful).toHaveLength(7);
    expect(result.failed).toHaveLength(7);
  });
});

describe('getTopProjects', () => {
  it('returns projects sorted by event count descending', async () => {
    queryRawMock.mockResolvedValue([
      { eventCount: 1, projectId: 'project-b', sandboxHours: 0, workflowCount: 0 },
      { eventCount: 3, projectId: 'project-a', sandboxHours: 1.5, workflowCount: 2 },
    ]);

    const result = await analyticsModule.getTopProjects('user-1', 30);

    expect(result.map((project) => project.projectId)).toEqual([
      'project-a',
      'project-b',
    ]);
  });
});

describe('analytics overview API', () => {
  it('rejects days values above 90', async () => {
    const response = await analyticsOverviewApi.default(
      new Request('http://localhost/api/analytics/overview?days=91'),
    );

    expect(response.status).toBe(400);
    expect(getOverviewMetricsRouteMock).not.toHaveBeenCalled();
    await expect(response.json()).resolves.toMatchObject({
      error: expect.stringContaining('Invalid days value'),
    });
  });
});
