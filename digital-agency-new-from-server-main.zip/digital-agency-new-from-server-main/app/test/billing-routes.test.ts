import { beforeEach, describe, expect, it, vi } from 'vitest';

const sessionMock = vi.hoisted(() => ({
  requireAuth: vi.fn(),
}));

const billingMock = vi.hoisted(() => ({
  getUsageSummary: vi.fn(),
  handleStripeWebhook: vi.fn(),
  upgradePlan: vi.fn(),
}));

vi.mock('~/lib/session.server', () => sessionMock);
vi.mock('~/lib/billing.server', () => billingMock);

const usageRoute = await import('../routes/api.billing.usage');
const upgradeRoute = await import('../routes/api.billing.upgrade');
const webhookRoute = await import('../routes/api.billing.webhook');

const testSession = {
  accessToken: 'token',
  email: 'user@example.com',
  expiresAt: Date.now() + 60_000,
  name: 'Test User',
  provider: 'email' as const,
  userId: 'user-1',
};

beforeEach(() => {
  vi.clearAllMocks();
  sessionMock.requireAuth.mockResolvedValue(testSession);
});

describe('billing API routes', () => {
  it('returns usage for an authenticated user', async () => {
    const usage = { plan: 'FREE', isOverLimit: false };
    billingMock.getUsageSummary.mockResolvedValue(usage);

    const response = await usageRoute.loader({
      request: new Request('http://localhost/api/billing/usage'),
    });

    await expect(response.json()).resolves.toEqual({ usage });
    expect(response.status).toBe(200);
    expect(billingMock.getUsageSummary).toHaveBeenCalledWith('user-1');
  });

  it('rejects unsupported usage methods', async () => {
    const response = await usageRoute.action({
      request: new Request('http://localhost/api/billing/usage', {
        method: 'POST',
      }),
    });

    await expect(response.json()).resolves.toMatchObject({
      error: 'Method not allowed',
    });
    expect(response.status).toBe(405);
  });

  it('upgrades a valid plan request', async () => {
    const subscription = { id: 'subscription-1', plan: 'PRO' };
    billingMock.upgradePlan.mockResolvedValue(subscription);

    const response = await upgradeRoute.action({
      request: new Request('http://localhost/api/billing/upgrade', {
        body: JSON.stringify({ plan: 'PRO' }),
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
      }),
    });

    await expect(response.json()).resolves.toMatchObject({
      checkoutUrl: null,
      subscription,
    });
    expect(response.status).toBe(200);
    expect(billingMock.upgradePlan).toHaveBeenCalledWith('user-1', 'PRO');
  });

  it('accepts Stripe webhook posts', async () => {
    const response = await webhookRoute.action({
      request: new Request('http://localhost/api/billing/webhook', {
        body: JSON.stringify({ type: 'subscription.updated' }),
        headers: { 'stripe-signature': 'test-signature' },
        method: 'POST',
      }),
    });

    await expect(response.json()).resolves.toEqual({ received: true });
    expect(response.status).toBe(200);
    expect(billingMock.handleStripeWebhook).toHaveBeenCalledWith(
      JSON.stringify({ type: 'subscription.updated' }),
      'test-signature',
    );
  });
});
