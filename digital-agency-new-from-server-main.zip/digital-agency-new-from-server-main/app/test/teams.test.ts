import { beforeEach, describe, expect, it, vi } from 'vitest';
import { TeamRole } from '@prisma/client';
import {
  acceptInviteSchema,
  createTeamSchema,
  inviteTeamMemberSchema,
} from '../lib/schemas.server';

const transactionMock = vi.fn();
const teamMemberFindUnique = vi.fn();
const teamMemberCount = vi.fn();
const teamMemberDelete = vi.fn();
const teamInviteFindUnique = vi.fn();
const teamInviteDelete = vi.fn();
const teamInviteDeleteMany = vi.fn();
const userFindUnique = vi.fn();
const requireAuthMock = vi.fn();

const dbMock = {
  $transaction: transactionMock,
  project: {
    findMany: vi.fn(),
  },
  team: {
    create: vi.fn(),
    findUnique: vi.fn(),
    update: vi.fn(),
  },
  teamInvite: {
    create: vi.fn(),
    delete: teamInviteDelete,
    deleteMany: teamInviteDeleteMany,
    findUnique: teamInviteFindUnique,
  },
  teamMember: {
    count: teamMemberCount,
    create: vi.fn(),
    delete: teamMemberDelete,
    findMany: vi.fn(),
    findUnique: teamMemberFindUnique,
    update: vi.fn(),
  },
  user: {
    findUnique: userFindUnique,
  },
};

vi.mock('../lib/db.server', () => ({
  db: dbMock,
  default: dbMock,
}));

vi.mock('../lib/session.server', () => ({
  requireAuth: requireAuthMock,
}));

const teamsModule = await import('../lib/teams.server');
const teamAuthModule = await import('../lib/team-auth.server');

beforeEach(() => {
  vi.clearAllMocks();
  transactionMock.mockImplementation(async (operations) => Promise.all(operations));
});

describe('team schemas', () => {
  it('createTeamSchema validates name length', () => {
    expect(createTeamSchema.safeParse({ name: '' }).success).toBe(false);
    expect(
      createTeamSchema.safeParse({ name: 'a'.repeat(100) }).success,
    ).toBe(true);
    expect(
      createTeamSchema.safeParse({ name: 'a'.repeat(101) }).success,
    ).toBe(false);
  });

  it('inviteTeamMemberSchema rejects invalid email', () => {
    expect(
      inviteTeamMemberSchema.safeParse({ email: 'invalid-email' }).success,
    ).toBe(false);
  });

  it('acceptInviteSchema rejects non-uuid token', () => {
    expect(acceptInviteSchema.safeParse({ token: 'not-a-uuid' }).success).toBe(
      false,
    );
  });
});

describe('getPermissions', () => {
  it('returns correct booleans for each role', () => {
    expect(teamAuthModule.getPermissions(TeamRole.OWNER)).toEqual({
      canDelete: true,
      canEdit: true,
      canInvite: true,
      canManageRoles: true,
    });
    expect(teamAuthModule.getPermissions(TeamRole.COLLABORATOR)).toEqual({
      canDelete: false,
      canEdit: true,
      canInvite: true,
      canManageRoles: false,
    });
    expect(teamAuthModule.getPermissions(TeamRole.VIEWER)).toEqual({
      canDelete: false,
      canEdit: false,
      canInvite: false,
      canManageRoles: false,
    });
  });
});

describe('checkTeamPermission', () => {
  it('gives owners full access and viewers read-only access', async () => {
    teamMemberFindUnique.mockResolvedValueOnce({ role: TeamRole.OWNER });
    await expect(
      teamsModule.checkTeamPermission('team-1', 'user-1', 'OWNER'),
    ).resolves.toBe(true);

    teamMemberFindUnique.mockResolvedValueOnce({ role: TeamRole.OWNER });
    await expect(
      teamsModule.checkTeamPermission('team-1', 'user-1', 'COLLABORATOR'),
    ).resolves.toBe(true);

    teamMemberFindUnique.mockResolvedValueOnce({ role: TeamRole.OWNER });
    await expect(
      teamsModule.checkTeamPermission('team-1', 'user-1', 'VIEWER'),
    ).resolves.toBe(true);

    teamMemberFindUnique.mockResolvedValueOnce({ role: TeamRole.VIEWER });
    await expect(
      teamsModule.checkTeamPermission('team-1', 'user-2', 'OWNER'),
    ).resolves.toBe(false);

    teamMemberFindUnique.mockResolvedValueOnce({ role: TeamRole.VIEWER });
    await expect(
      teamsModule.checkTeamPermission('team-1', 'user-2', 'COLLABORATOR'),
    ).resolves.toBe(false);

    teamMemberFindUnique.mockResolvedValueOnce({ role: TeamRole.VIEWER });
    await expect(
      teamsModule.checkTeamPermission('team-1', 'user-2', 'VIEWER'),
    ).resolves.toBe(true);
  });
});

describe('team invites', () => {
  it('rejects expired invites', async () => {
    teamInviteFindUnique.mockResolvedValue({
      expiresAt: new Date(Date.now() - 60_000),
      id: 'invite-1',
      role: TeamRole.VIEWER,
      team: {
        createdAt: new Date(),
        description: null,
        id: 'team-1',
        name: 'Platform',
        ownerId: 'owner-1',
        updatedAt: new Date(),
      },
      teamId: 'team-1',
      token: '550e8400-e29b-41d4-a716-446655440000',
    });

    await expect(
      teamsModule.acceptTeamInvite(
        '550e8400-e29b-41d4-a716-446655440000',
        'user-1',
      ),
    ).rejects.toThrow('Invite expired');
    expect(teamInviteDelete).toHaveBeenCalledWith({
      where: { id: 'invite-1' },
    });
  });

  it('returns null for expired invite lookup', async () => {
    teamInviteFindUnique.mockResolvedValue({
      expiresAt: new Date(Date.now() - 60_000),
      id: 'invite-2',
      team: {
        owner: { email: 'owner@example.com', id: 'owner-1', name: 'Owner' },
      },
      token: '660e8400-e29b-41d4-a716-446655440000',
    });

    await expect(
      teamsModule.getTeamInviteByToken('660e8400-e29b-41d4-a716-446655440000'),
    ).resolves.toBeNull();
  });
});

describe('removeTeamMember', () => {
  it('prevents removing the last owner', async () => {
    teamMemberFindUnique
      .mockResolvedValueOnce({
        role: TeamRole.OWNER,
        teamId: 'team-1',
        userId: 'owner-1',
      })
      .mockResolvedValueOnce({
        role: TeamRole.OWNER,
        teamId: 'team-1',
        userId: 'owner-1',
      });
    teamMemberCount.mockResolvedValue(1);

    await expect(
      teamsModule.removeTeamMember('team-1', 'owner-1', 'owner-1'),
    ).rejects.toThrow('Cannot remove the last owner');
    expect(teamMemberDelete).not.toHaveBeenCalled();
  });
});
