import { renderHook } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import {
  createSSEResponse,
  encodeSSEEvent,
  pollWorkflowEvents,
  withHeartbeat,
} from '../lib/sse.server';
import { useSSE, useWorkflowStream } from '../hooks/useSSE';

class MockEventSource {
  static instances: MockEventSource[] = [];

  onerror: ((event: Event) => void) | null = null;
  onmessage: ((event: MessageEvent<string>) => void) | null = null;
  onopen: ((event: Event) => void) | null = null;
  readonly url: string;
  private listeners = new Map<string, Set<EventListener>>();

  constructor(url: string) {
    this.url = url;
    MockEventSource.instances.push(this);
  }

  addEventListener(type: string, listener: EventListener) {
    const listeners = this.listeners.get(type) ?? new Set<EventListener>();
    listeners.add(listener);
    this.listeners.set(type, listeners);
  }

  removeEventListener(type: string, listener: EventListener) {
    this.listeners.get(type)?.delete(listener);
  }

  close() {}
}

describe('SSE utilities', () => {
  beforeEach(() => {
    vi.useRealTimers();
    MockEventSource.instances = [];
    vi.stubGlobal('EventSource', MockEventSource);
  });

  afterEach(() => {
    vi.unstubAllGlobals();
    vi.useRealTimers();
  });

  it('encodeSSEEvent formats correctly', () => {
    expect(
      encodeSSEEvent({
        data: { ok: true },
        event: 'log',
        id: '7',
      }),
    ).toBe('id: 7\nevent: log\ndata: {"ok":true}\n\n');
  });

  it('encodeSSEEvent double-newline terminated', () => {
    expect(encodeSSEEvent({ data: 'done' }).endsWith('\n\n')).toBe(true);
  });

  it('encodeSSEEvent handles JSON data correctly', () => {
    expect(encodeSSEEvent({ data: { nested: ['a', 1, true] } })).toContain(
      'data: {"nested":["a",1,true]}',
    );
  });

  it('createSSEResponse sets correct Content-Type header', () => {
    const response = createSSEResponse(new ReadableStream<Uint8Array>());
    expect(response.headers.get('Content-Type')).toBe('text/event-stream');
  });

  it('createSSEResponse sets Cache-Control header with no-cache', () => {
    const response = createSSEResponse(new ReadableStream<Uint8Array>());
    expect(response.headers.get('Cache-Control')).toContain('no-cache');
  });

  it('useSSE initializes with disconnected state', () => {
    const { result } = renderHook(() =>
      useSSE({ url: '/api/stream/workflow/test' }),
    );
    expect(result.current).toEqual({
      connected: false,
      error: null,
      lastEventId: null,
    });
    expect(MockEventSource.instances).toHaveLength(1);
  });

  it('useWorkflowStream starts with empty events array', () => {
    const { result } = renderHook(() => useWorkflowStream('workflow-1'));
    expect(result.current.events).toEqual([]);
    expect(result.current.connected).toBe(false);
    expect(result.current.error).toBe(null);
  });

  it('pollWorkflowEvents yields timeout event after timeout', async () => {
    vi.useFakeTimers();
    const iterator = pollWorkflowEvents(
      `workflow-timeout-${crypto.randomUUID()}`,
      0,
      {
        intervalMs: 10,
        timeoutMs: 20,
      },
    );

    const nextValue = iterator.next();
    await vi.advanceTimersByTimeAsync(25);

    await expect(nextValue).resolves.toEqual({
      done: false,
      value: {
        data: { message: 'Stream timeout after 5 minutes' },
        event: 'timeout',
      },
    });
  });

  it('heartbeat is sent at correct interval', async () => {
    vi.useFakeTimers();
    const iterator = withHeartbeat(
      (async function* () {
        await new Promise((resolve) => setTimeout(resolve, 40_000));
      })(),
      { intervalMs: 15_000 },
    );

    const firstBeat = iterator.next();
    await vi.advanceTimersByTimeAsync(15_000);
    await expect(firstBeat).resolves.toMatchObject({
      done: false,
      value: {
        data: { ts: expect.any(Number) },
        event: 'heartbeat',
      },
    });

    const secondBeat = iterator.next();
    await vi.advanceTimersByTimeAsync(15_000);
    await expect(secondBeat).resolves.toMatchObject({
      done: false,
      value: {
        data: { ts: expect.any(Number) },
        event: 'heartbeat',
      },
    });
  });
});
