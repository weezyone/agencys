import { beforeEach, describe, expect, it, vi } from 'vitest';
import {
  createArtifactSchema,
  listArtifactsSchema,
} from '../lib/schemas.server';

const execFileMock = vi.fn();
const requireAuthMock = vi.fn();
const getProjectByIdMock = vi.fn();
const createArtifactRecordMock = vi.fn();
const getArtifactByIdMock = vi.fn();
const uploadFileMock = vi.fn();
const generateSignedUrlMock = vi.fn();
const deleteFileMock = vi.fn();
const artifactUpdateMock = vi.fn();
const artifactDeleteMock = vi.fn();
const artifactFindManyMock = vi.fn();
const artifactCountMock = vi.fn();

vi.mock('node:child_process', () => ({
  default: { execFile: execFileMock },
  execFile: execFileMock,
}));

vi.mock('~/lib/session.server', () => ({
  requireAuth: requireAuthMock,
}));

vi.mock('~/lib/data.server', () => ({
  createArtifact: createArtifactRecordMock,
  deleteExpiredArtifacts: vi.fn(),
  getArtifactById: getArtifactByIdMock,
  getProjectById: getProjectByIdMock,
}));

vi.mock('~/lib/blob.server', () => ({
  deleteFile: deleteFileMock,
  generateSignedUrl: generateSignedUrlMock,
  uploadFile: uploadFileMock,
}));

vi.mock('~/lib/db.server', () => ({
  db: {
    artifact: {
      count: artifactCountMock,
      delete: artifactDeleteMock,
      findMany: artifactFindManyMock,
      update: artifactUpdateMock,
    },
  },
}));

const archiveModule = await import('../lib/archive.server');
const createArtifactApi = await import('../../api/artifacts/create');
const artifactByIdApi = await import('../../api/artifacts/[id]');

beforeEach(() => {
  vi.clearAllMocks();
  execFileMock.mockImplementation((_file, _args, _options, callback) => {
    callback?.(null, Buffer.from('PK\u0003\u0004mock-zip'), Buffer.alloc(0));
    return undefined;
  });
  requireAuthMock.mockResolvedValue({ userId: 'user-1' });
  getProjectByIdMock.mockResolvedValue({
    id: '11111111-1111-1111-1111-111111111111',
    userId: 'user-1',
  });
});

describe('validateFileList', () => {
  it('rejects more than 1000 files', () => {
    const files = Array.from({ length: 1001 }, (_, index) => ({
      path: `file-${index}.txt`,
      content: 'x',
    }));

    expect(archiveModule.validateFileList(files)).toEqual({
      error: 'Too many files. Maximum allowed is 1000.',
      valid: false,
    });
  });

  it('rejects file lists larger than 10MB', () => {
    const files = [
      { path: 'large.txt', content: 'a'.repeat(10 * 1024 * 1024 + 1) },
    ];

    expect(archiveModule.validateFileList(files)).toEqual({
      error: 'Total file size exceeds 10485760 bytes.',
      valid: false,
    });
  });
});

describe('calculateChecksum', () => {
  it('returns a stable sha256 hash', async () => {
    const first = await archiveModule.calculateChecksum(
      Buffer.from('artifact-buffer'),
    );
    const second = await archiveModule.calculateChecksum(
      Buffer.from('artifact-buffer'),
    );

    expect(first).toBe(second);
    expect(first).toMatch(/^[a-f0-9]{64}$/);
  });
});

describe('artifact schemas', () => {
  it('createArtifactSchema rejects an empty files array', () => {
    const parsed = createArtifactSchema.safeParse({
      projectId: '11111111-1111-1111-1111-111111111111',
      files: [],
    });

    expect(parsed.success).toBe(false);
  });

  it('listArtifactsSchema coerces pagination query params', () => {
    const parsed = listArtifactsSchema.parse({
      projectId: '11111111-1111-1111-1111-111111111111',
      limit: '10',
      offset: '5',
    });

    expect(parsed).toEqual({
      projectId: '11111111-1111-1111-1111-111111111111',
      limit: 10,
      offset: 5,
    });
  });
});

describe('createZipArchive', () => {
  it('creates a zip buffer for multiple files', async () => {
    const result = await archiveModule.createZipArchive(
      [
        { path: 'README.md', content: '# Hello' },
        { path: 'src/index.ts', content: 'export const answer = 42;' },
        {
          path: 'src/utils.ts',
          content: 'export const sum = (a: number, b: number) => a + b;',
        },
      ],
      'bundle',
    );

    expect(result.buffer.equals(Buffer.from('PK\u0003\u0004mock-zip'))).toBe(
      true,
    );
    expect(result.metadata.filename).toBe('bundle.zip');
    expect(result.metadata.fileCount).toBe(3);
    expect(result.metadata.totalSizeBytes).toBe(result.buffer.length);
    expect(execFileMock).toHaveBeenCalledWith(
      'zip',
      ['-q', '-r', '-', '.'],
      expect.objectContaining({ cwd: expect.any(String) }),
      expect.any(Function),
    );
  });
});

describe('artifact create API', () => {
  it('returns 400 when projectId is missing', async () => {
    const response = await createArtifactApi.default(
      new Request('http://localhost/api/artifacts/create', {
        body: JSON.stringify({
          files: [{ path: 'README.md', content: 'hello' }],
        }),
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
      }),
    );

    expect(response.status).toBe(400);
    await expect(response.json()).resolves.toMatchObject({
      error: 'Invalid artifact request',
    });
  });
});

describe('artifact GET API', () => {
  it('regenerates a signed URL when the current one is expired', async () => {
    getArtifactByIdMock.mockResolvedValue({
      checksum: 'checksum',
      contentType: 'application/zip',
      createdAt: new Date('2024-01-01T00:00:00.000Z'),
      downloadUrl: 'https://blob.example.com/archive.zip?old=1',
      expiresAt: new Date(Date.now() - 1_000),
      filePath: 'artifacts/archive.zip',
      fileSize: BigInt(128),
      id: 'artifact-1',
      name: 'archive.zip',
      projectId: '11111111-1111-1111-1111-111111111111',
      workflowId: null,
    });
    generateSignedUrlMock.mockResolvedValue(
      'https://blob.example.com/archive.zip?new=1',
    );
    artifactUpdateMock.mockImplementation(async ({ data, where }) => ({
      checksum: 'checksum',
      contentType: 'application/zip',
      createdAt: new Date('2024-01-01T00:00:00.000Z'),
      downloadUrl: data.downloadUrl,
      expiresAt: data.expiresAt,
      filePath: 'artifacts/archive.zip',
      fileSize: BigInt(128),
      id: where.id,
      name: 'archive.zip',
      projectId: '11111111-1111-1111-1111-111111111111',
      workflowId: null,
    }));

    const response = await artifactByIdApi.default(
      new Request('http://localhost/api/artifacts/artifact-1'),
    );
    const payload = await response.json();

    expect(response.status).toBe(200);
    expect(generateSignedUrlMock).toHaveBeenCalledWith(
      'artifacts/archive.zip',
      3600,
    );
    expect(artifactUpdateMock).toHaveBeenCalledWith({
      data: expect.objectContaining({
        downloadUrl: 'https://blob.example.com/archive.zip?new=1',
        expiresAt: expect.any(Date),
      }),
      where: { id: 'artifact-1' },
    });
    expect(payload).toMatchObject({
      downloadUrl: 'https://blob.example.com/archive.zip?new=1',
      artifact: {
        fileSize: 128,
        id: 'artifact-1',
      },
    });
  });
});
