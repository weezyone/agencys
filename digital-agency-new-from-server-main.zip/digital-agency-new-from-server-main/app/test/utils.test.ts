import { afterEach, describe, expect, it, vi } from 'vitest';
import {
  formatRelativeTime,
  generateBranchName,
  withRetry,
} from '../lib/utils';

afterEach(() => {
  vi.restoreAllMocks();
  vi.useRealTimers();
});

describe('generateBranchName', () => {
  it('creates a safe branch slug', () => {
    expect(generateBranchName('Ship Workspace MVP!')).toBe(
      'ship-workspace-mvp',
    );
  });

  it('removes invalid characters and truncates long names', () => {
    expect(generateBranchName('Release 🚀 '.repeat(10))).toMatch(
      /^[a-z0-9-]{1,50}$/,
    );
    expect(generateBranchName('Release 🚀 '.repeat(10))).toHaveLength(50);
  });
});

describe('formatRelativeTime', () => {
  it('formats recent times', () => {
    expect(formatRelativeTime(new Date())).toBe('just now');
  });

  it('formats older times in hours and days', () => {
    expect(formatRelativeTime(new Date(Date.now() - 2 * 60 * 60 * 1000))).toBe(
      '2h ago',
    );
    expect(
      formatRelativeTime(new Date(Date.now() - 3 * 24 * 60 * 60 * 1000)),
    ).toBe('3d ago');
  });
});

describe('withRetry', () => {
  it('retries until success', async () => {
    vi.useFakeTimers();
    vi.spyOn(Math, 'random').mockReturnValue(0);

    let attempts = 0;
    const promise = withRetry(
      async () => {
        attempts += 1;
        if (attempts < 2) {
          throw new Error('retry');
        }
        return 'ok';
      },
      2,
      5,
    );

    await vi.runAllTimersAsync();

    await expect(promise).resolves.toBe('ok');
    expect(attempts).toBe(2);
  });

  it('throws after exhausting retries', async () => {
    vi.useFakeTimers();
    vi.spyOn(Math, 'random').mockReturnValue(0);

    const fn = vi.fn().mockRejectedValue(new Error('still failing'));
    const promise = withRetry(fn, 2, 5);
    const assertion = expect(promise).rejects.toThrow('still failing');

    await vi.runAllTimersAsync();

    await assertion;
    expect(fn).toHaveBeenCalledTimes(3);
  });
});
