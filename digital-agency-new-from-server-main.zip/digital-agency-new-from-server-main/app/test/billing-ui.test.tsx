import type { ReactNode } from 'react';
import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { ToastProvider } from '~/components/Notifications/ToastContainer';
import { CurrentPlanCard } from '~/components/Billing/CurrentPlanCard';
import { UpgradeModal } from '~/components/Billing/UpgradeModal';
import { UsageLimitBanner } from '~/components/Billing/UsageLimitBanner';
import { UsageMeter } from '~/components/Billing/UsageMeter';
import type { BillingUsageSummary } from '~/components/Billing/billing-config';

function renderWithToast(element: ReactNode) {
  return render(<ToastProvider>{element}</ToastProvider>);
}

const baseUsage: BillingUsageSummary = {
  aiTokens: { limit: 100_000, percent: 50, used: 50_000 },
  isNearLimit: false,
  isOverLimit: false,
  periodEnd: new Date('2025-01-15T00:00:00.000Z').toISOString(),
  periodStart: new Date('2025-01-01T00:00:00.000Z').toISOString(),
  plan: 'FREE',
  projects: { limit: 3, percent: 33, used: 1 },
  sandboxHours: { limit: 10, percent: 50, used: 5 },
};

describe('UsageMeter', () => {
  it('renders correct percentage bar width', () => {
    render(
      <UsageMeter label="Sandbox Hours" limit={10} percent={50} unit="hours" used={5} />,
    );

    expect(screen.getByTestId('usage-meter-fill-sandbox-hours')).toHaveStyle({
      width: '50%',
    });
  });

  it('applies red color class when percent >= 100', () => {
    render(
      <UsageMeter label="AI Tokens" limit={100} percent={100} unit="tokens" used={100} />,
    );

    expect(screen.getByTestId('usage-meter-fill-ai-tokens')).toHaveClass('bg-red-500');
  });

  it('applies yellow color class when percent is 70', () => {
    render(
      <UsageMeter label="Projects" limit={10} percent={70} unit="projects" used={7} />,
    );

    expect(screen.getByTestId('usage-meter-fill-projects')).toHaveClass('bg-yellow-500');
  });

  it('applies indigo color class when percent is 50', () => {
    render(
      <UsageMeter label="Projects" limit={10} percent={50} unit="projects" used={5} />,
    );

    expect(screen.getByTestId('usage-meter-fill-projects')).toHaveClass('bg-indigo-500');
  });

  it('shows Limit reached warning when over 100%', () => {
    render(
      <UsageMeter label="Projects" limit={10} percent={120} unit="projects" used={12} />,
    );

    expect(screen.getByText(/limit reached/i)).toBeInTheDocument();
  });
});

describe('CurrentPlanCard', () => {
  it('renders PRO badge with correct color class', () => {
    render(<CurrentPlanCard periodEnd={baseUsage.periodEnd} plan="PRO" />);

    expect(screen.getByText('PRO')).toHaveClass('text-indigo-200');
  });

  it('hides upgrade button when plan is TEAM', () => {
    render(<CurrentPlanCard periodEnd={baseUsage.periodEnd} plan="TEAM" />);

    expect(screen.queryByRole('button', { name: /upgrade/i })).not.toBeInTheDocument();
  });
});

describe('UpgradeModal', () => {
  it('renders all three plan columns', () => {
    renderWithToast(
      <UpgradeModal currentPlan="FREE" isOpen onClose={() => {}} />,
    );

    expect(screen.getByTestId('plan-column-FREE')).toBeInTheDocument();
    expect(screen.getByTestId('plan-column-PRO')).toBeInTheDocument();
    expect(screen.getByTestId('plan-column-TEAM')).toBeInTheDocument();
  });

  it('highlights current plan column', () => {
    renderWithToast(
      <UpgradeModal currentPlan="PRO" isOpen onClose={() => {}} />,
    );

    expect(screen.getByTestId('plan-column-PRO')).toHaveClass('border-indigo-500');
  });
});

describe('UsageLimitBanner', () => {
  it('renders nothing when usage is null', () => {
    const { container } = render(<UsageLimitBanner usage={null} />);
    expect(container).toBeEmptyDOMElement();
  });

  it('renders yellow warning when isNearLimit=true', () => {
    render(
      <UsageLimitBanner usage={{ ...baseUsage, isNearLimit: true, sandboxHours: { ...baseUsage.sandboxHours, percent: 85 } }} />,
    );

    expect(screen.getByText(/approaching your plan limits/i)).toBeInTheDocument();
  });

  it('renders red banner when isOverLimit=true', () => {
    render(
      <UsageLimitBanner usage={{ ...baseUsage, isOverLimit: true, aiTokens: { ...baseUsage.aiTokens, percent: 100 } }} />,
    );

    expect(screen.getByText(/reached your plan limits/i)).toBeInTheDocument();
  });
});
