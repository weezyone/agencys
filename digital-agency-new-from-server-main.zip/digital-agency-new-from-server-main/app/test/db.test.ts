import { beforeEach, describe, expect, it, vi } from 'vitest';
import { WorkflowStatus } from '@prisma/client';
import { createInMemoryKVStore } from '../lib/kv.server';

const projectFindMany = vi.fn();
const projectCreate = vi.fn();
const projectFindFirst = vi.fn();
const projectUpdate = vi.fn();
const projectDelete = vi.fn();
const workflowFindUnique = vi.fn();
const workflowUpdate = vi.fn();
const workflowFindMany = vi.fn();
const workflowCreate = vi.fn();
const workflowStepCreate = vi.fn();
const workflowStepFindUnique = vi.fn();
const workflowStepUpdate = vi.fn();
const artifactFindMany = vi.fn();
const artifactCreate = vi.fn();
const artifactFindUnique = vi.fn();
const artifactDeleteMany = vi.fn();
const auditLogCreate = vi.fn();

vi.mock('~/lib/db.server', () => ({
  db: {
    artifact: {
      create: artifactCreate,
      deleteMany: artifactDeleteMany,
      findMany: artifactFindMany,
      findUnique: artifactFindUnique,
    },
    auditLog: {
      create: auditLogCreate,
    },
    project: {
      create: projectCreate,
      delete: projectDelete,
      findFirst: projectFindFirst,
      findMany: projectFindMany,
      update: projectUpdate,
    },
    workflow: {
      create: workflowCreate,
      findMany: workflowFindMany,
      findUnique: workflowFindUnique,
      update: workflowUpdate,
    },
    workflowStep: {
      create: workflowStepCreate,
      findUnique: workflowStepFindUnique,
      update: workflowStepUpdate,
    },
  },
  default: {
    artifact: {
      create: artifactCreate,
      deleteMany: artifactDeleteMany,
      findMany: artifactFindMany,
      findUnique: artifactFindUnique,
    },
    auditLog: {
      create: auditLogCreate,
    },
    project: {
      create: projectCreate,
      delete: projectDelete,
      findFirst: projectFindFirst,
      findMany: projectFindMany,
      update: projectUpdate,
    },
    workflow: {
      create: workflowCreate,
      findMany: workflowFindMany,
      findUnique: workflowFindUnique,
      update: workflowUpdate,
    },
    workflowStep: {
      create: workflowStepCreate,
      findUnique: workflowStepFindUnique,
      update: workflowStepUpdate,
    },
  },
}));

const dataModule = await import('../lib/data.server');

beforeEach(() => {
  vi.clearAllMocks();
});

describe('getUserProjects', () => {
  it('returns projects ordered by newest first', async () => {
    const projects = [{ id: 'project-1', userId: 'user-1', name: 'Platform' }];
    projectFindMany.mockResolvedValue(projects);

    const result = await dataModule.getUserProjects('user-1', 10, 5);

    expect(projectFindMany).toHaveBeenCalledWith({
      orderBy: { createdAt: 'desc' },
      skip: 5,
      take: 10,
      where: { userId: 'user-1' },
    });
    expect(result).toEqual(projects);
  });
});

describe('createProject', () => {
  it('validates project input before writing', async () => {
    await expect(
      dataModule.createProject('user-1', {
        name: '',
      } as never),
    ).rejects.toThrow();

    expect(projectCreate).not.toHaveBeenCalled();
  });
});

describe('updateWorkflowStatus', () => {
  it('updates a workflow when the transition is valid', async () => {
    workflowFindUnique.mockResolvedValue({
      currentState: {},
      id: 'workflow-1',
      startedAt: null,
      status: WorkflowStatus.INITIALIZING,
    });
    workflowUpdate.mockResolvedValue({
      id: 'workflow-1',
      status: WorkflowStatus.RUNNING,
    });

    const result = await dataModule.updateWorkflowStatus(
      'workflow-1',
      WorkflowStatus.RUNNING,
      { step: 'boot' },
    );

    expect(workflowUpdate).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          currentState: { step: 'boot' },
          status: WorkflowStatus.RUNNING,
        }),
        where: { id: 'workflow-1' },
      }),
    );
    expect(result).toEqual({
      id: 'workflow-1',
      status: WorkflowStatus.RUNNING,
    });
  });

  it('rejects invalid workflow transitions', async () => {
    workflowFindUnique.mockResolvedValue({
      currentState: {},
      id: 'workflow-1',
      startedAt: new Date(),
      status: WorkflowStatus.COMPLETED,
    });

    await expect(
      dataModule.updateWorkflowStatus('workflow-1', WorkflowStatus.RUNNING),
    ).rejects.toThrow(/Invalid workflow transition/);
    expect(workflowUpdate).not.toHaveBeenCalled();
  });
});

describe('in-memory kv store', () => {
  it('supports ttl expiration', async () => {
    vi.useFakeTimers();

    try {
      const kv = createInMemoryKVStore();
      await kv.set('session:user-1', { id: 'session-1' }, { ex: 1 });

      expect(await kv.get<{ id: string }>('session:user-1')).toEqual({
        id: 'session-1',
      });

      vi.advanceTimersByTime(1001);

      expect(await kv.get('session:user-1')).toBeNull();
    } finally {
      vi.useRealTimers();
    }
  });
});
