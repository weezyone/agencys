import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { WorkflowStatus } from '@prisma/client';
import { defineStep } from '@vercel/workflow';
import { startWorkflowSchema } from '../lib/schemas.server';
import kv from '../lib/kv.server';

const createArtifactMock = vi.fn();
const createWorkflowStepMock = vi.fn();
const updateStepStatusMock = vi.fn();
const updateWorkflowStatusMock = vi.fn();
const createSandboxMock = vi.fn();
const executeSandboxCommandMock = vi.fn();
const terminateSandboxMock = vi.fn();
const writeSandboxFileMock = vi.fn();
const generateAIResponseMock = vi.fn();
const executeAgentInSandboxMock = vi.fn();
const createZipArchiveMock = vi.fn();
const uploadFileMock = vi.fn();
const generateSignedUrlMock = vi.fn();

vi.mock('../lib/data.server', () => ({
  createArtifact: createArtifactMock,
  createWorkflowStep: createWorkflowStepMock,
  updateStepStatus: updateStepStatusMock,
  updateWorkflowStatus: updateWorkflowStatusMock,
}));

vi.mock('../lib/sandbox.server', () => ({
  createSandbox: createSandboxMock,
  executeSandboxCommand: executeSandboxCommandMock,
  terminateSandbox: terminateSandboxMock,
  writeSandboxFile: writeSandboxFileMock,
}));

vi.mock('../lib/ai.server', () => ({
  executeAgentInSandbox: executeAgentInSandboxMock,
  generateAIResponse: generateAIResponseMock,
}));

vi.mock('../lib/archive.server', () => ({
  createZipArchive: createZipArchiveMock,
}));

vi.mock('../lib/blob.server', () => ({
  generateSignedUrl: generateSignedUrlMock,
  uploadFile: uploadFileMock,
}));

vi.mock('../lib/notifications.server', () => ({
  notifyWorkflowComplete: vi.fn().mockResolvedValue(undefined),
  notifyWorkflowFailed: vi.fn().mockResolvedValue(undefined),
}));

const workflowModule = await import('../lib/workflow.server');

beforeEach(() => {
  vi.clearAllMocks();
  createWorkflowStepMock.mockImplementation(
    async (
      _workflowId: string,
      data: { stepName: string; stepOrder: number },
    ) => ({
      id: `${data.stepName}-${data.stepOrder}`,
    }),
  );
  updateStepStatusMock.mockResolvedValue(undefined);
  updateWorkflowStatusMock.mockResolvedValue(undefined);
  createSandboxMock.mockResolvedValue({
    createdAt: new Date('2025-01-01T00:00:00.000Z'),
    domain: 'https://sandbox.local',
    id: 'sandbox-record-1',
    sandboxId: 'sandbox-1',
    status: 'ready',
  });
  executeSandboxCommandMock.mockResolvedValue({
    exitCode: 0,
    stderr: '',
    stdout: 'ok',
  });
  terminateSandboxMock.mockResolvedValue(undefined);
  writeSandboxFileMock.mockResolvedValue(undefined);
  generateAIResponseMock.mockResolvedValue({
    content: 'Plan the work.',
    finishReason: 'stop',
    model: 'mock-model',
    provider: 'claude',
    usage: { completionTokens: 1, promptTokens: 1, totalTokens: 2 },
  });
  executeAgentInSandboxMock.mockResolvedValue({ exitCode: 0, output: 'done' });
  createZipArchiveMock.mockResolvedValue({
    buffer: Buffer.from('zip'),
    metadata: {
      checksum: 'checksum',
      createdAt: new Date('2025-01-01T00:00:00.000Z'),
      fileCount: 1,
      filename: 'workflow.zip',
      id: 'archive-1',
      totalSizeBytes: 3,
    },
  });
  uploadFileMock.mockResolvedValue({
    pathname: 'workflow.zip',
    url: 'file:///workflow.zip',
  });
  generateSignedUrlMock.mockResolvedValue('file:///workflow.zip?expires=1');
  createArtifactMock.mockResolvedValue({
    id: 'artifact-1',
    name: 'workflow.zip',
  });
});

afterEach(async () => {
  vi.useRealTimers();
});

describe('defineStep', () => {
  it('retries on failure with exponential backoff', async () => {
    vi.useFakeTimers();
    const setTimeoutSpy = vi.spyOn(globalThis, 'setTimeout');
    const step = defineStep(
      { maxRetries: 2, name: 'retry-step', retryDelayMs: 1000 },
      vi
        .fn()
        .mockRejectedValueOnce(new Error('first'))
        .mockRejectedValueOnce(new Error('second'))
        .mockResolvedValue('ok'),
    );

    const promise = step();
    await vi.runAllTimersAsync();

    await expect(promise).resolves.toBe('ok');
    expect(setTimeoutSpy.mock.calls.map((call) => Number(call[1]))).toEqual([
      1000, 2000,
    ]);
  });

  it('throws after max retries are exceeded', async () => {
    vi.useFakeTimers();
    const error = new Error('still failing');
    const step = defineStep(
      { maxRetries: 1, name: 'failing-step', retryDelayMs: 250 },
      vi.fn().mockRejectedValue(error),
    );

    const assertion = expect(step()).rejects.toThrow('still failing');
    await vi.runAllTimersAsync();

    await assertion;
  });

  it('returns the result on success', async () => {
    const step = defineStep(
      { name: 'successful-step' },
      vi.fn().mockResolvedValue({ ok: true }),
    );

    await expect(step()).resolves.toEqual({ ok: true });
  });
});

describe('workflow events', () => {
  it('stores events in kv', async () => {
    const workflowId = crypto.randomUUID();
    const event = {
      message: 'step started',
      timestamp: Date.now(),
      type: 'log' as const,
    };

    await workflowModule.emitWorkflowEvent(workflowId, event);

    expect(await kv.get(`workflow:${workflowId}:events`)).toEqual([event]);
  });

  it('returns stored events', async () => {
    const workflowId = crypto.randomUUID();
    const event = {
      stepName: 'collect-artifacts',
      timestamp: Date.now(),
      type: 'step_completed' as const,
    };

    await workflowModule.emitWorkflowEvent(workflowId, event);

    await expect(workflowModule.getWorkflowEvents(workflowId)).resolves.toEqual(
      [event],
    );
  });
});

describe('startWorkflowSchema', () => {
  it('validates required fields', () => {
    const parsed = startWorkflowSchema.safeParse({
      projectId: '550e8400-e29b-41d4-a716-446655440000',
      provider: 'claude',
      task: 'Implement a durable workflow orchestration engine.',
      workflowType: 'cloud-task',
    });

    expect(parsed.success).toBe(true);
  });

  it('rejects invalid project ids', () => {
    expect(
      startWorkflowSchema.safeParse({
        projectId: 'not-a-uuid',
        task: 'Implement a durable workflow orchestration engine.',
        workflowType: 'cloud-task',
      }).success,
    ).toBe(false);
  });
});

describe('workflow cancellation', () => {
  it('sets the cancelled flag in kv', async () => {
    const workflowId = crypto.randomUUID();

    await workflowModule.cancelWorkflow(workflowId);

    await expect(
      kv.get<boolean>(`workflow:${workflowId}:cancelled`),
    ).resolves.toBe(true);
  });

  it('stops executing the next step when cancelled', async () => {
    const workflowId = crypto.randomUUID();
    createSandboxMock.mockImplementation(async () => {
      await workflowModule.cancelWorkflow(workflowId);
      return {
        createdAt: new Date('2025-01-01T00:00:00.000Z'),
        domain: 'https://sandbox.local',
        id: 'sandbox-record-1',
        sandboxId: 'sandbox-1',
        status: 'ready',
      };
    });

    await expect(
      workflowModule.cloudTaskWorkflow.run({
        metadata: {
          projectId: '550e8400-e29b-41d4-a716-446655440000',
          provider: 'claude',
          task: 'Implement durable workflow orchestration.',
          userId: 'user-1',
          workflowId,
        },
        projectId: '550e8400-e29b-41d4-a716-446655440000',
        workflowId,
      }),
    ).rejects.toThrow(/cancelled/i);

    expect(generateAIResponseMock).not.toHaveBeenCalled();
    expect(executeAgentInSandboxMock).not.toHaveBeenCalled();
    expect(updateWorkflowStatusMock).toHaveBeenCalledWith(
      workflowId,
      WorkflowStatus.FAILED,
      expect.objectContaining({ status: 'failed' }),
    );
  });
});
