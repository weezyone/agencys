import type { ReactElement } from 'react';
import { render, renderHook, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { NotificationBell } from '~/components/Notifications/NotificationBell';
import { NotificationDropdown } from '~/components/Notifications/NotificationDropdown';
import { NotificationItem } from '~/components/Notifications/NotificationItem';
import {
  ToastContainer,
  ToastProvider,
  useToast,
} from '~/components/Notifications/ToastContainer';
import { useNotifications } from '~/hooks/useNotifications';
import type { Notification } from '~/types/notifications';

class MockEventSource {
  static instances: MockEventSource[] = [];

  onerror: ((event: Event) => void) | null = null;
  onmessage: ((event: MessageEvent<string>) => void) | null = null;
  onopen: ((event: Event) => void) | null = null;
  readonly url: string;

  constructor(url: string) {
    this.url = url;
    MockEventSource.instances.push(this);
  }

  addEventListener() {}
  removeEventListener() {}
  close() {}
}

function renderWithRouter(element: ReactElement) {
  return render(<MemoryRouter>{element}</MemoryRouter>);
}

function createNotification(overrides: Partial<Notification> = {}): Notification {
  return {
    body: 'Workflow finished successfully.',
    createdAt: new Date().toISOString(),
    id: 'notification-1',
    metadata: {},
    readAt: null,
    title: 'Workflow update',
    type: 'WORKFLOW_COMPLETE',
    userId: 'user-1',
    ...overrides,
  };
}

function ToastHarness() {
  const { addToast } = useToast();

  return (
    <button
      onClick={() =>
        addToast({
          message: 'Everything is saved.',
          title: 'Saved',
          type: 'success',
        })
      }
      type="button"
    >
      Add toast
    </button>
  );
}

beforeEach(() => {
  MockEventSource.instances = [];
  vi.stubGlobal('EventSource', MockEventSource);
  vi.stubGlobal(
    'fetch',
    vi.fn().mockResolvedValue({
      json: async () => ({ notifications: [], unreadCount: 0 }),
      ok: true,
      status: 200,
    }),
  );
});

afterEach(() => {
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

describe('NotificationItem', () => {
  it('renders correct icon for WORKFLOW_COMPLETE type', () => {
    renderWithRouter(
      <NotificationItem notification={createNotification()} onMarkRead={vi.fn()} />,
    );
    expect(screen.getByText('✓')).toBeInTheDocument();
  });

  it('renders correct icon for WORKFLOW_FAILED type', () => {
    renderWithRouter(
      <NotificationItem
        notification={createNotification({ type: 'WORKFLOW_FAILED' })}
        onMarkRead={vi.fn()}
      />,
    );
    expect(screen.getByText('✗')).toBeInTheDocument();
  });

  it('applies unread styling when readAt is null', () => {
    renderWithRouter(
      <NotificationItem notification={createNotification()} onMarkRead={vi.fn()} />,
    );
    expect(screen.getByTestId('notification-item-notification-1')).toHaveClass(
      'border-indigo-500',
    );
  });

  it('applies read styling when readAt is set', () => {
    renderWithRouter(
      <NotificationItem
        notification={createNotification({ readAt: new Date().toISOString() })}
        onMarkRead={vi.fn()}
      />,
    );
    expect(screen.getByTestId('notification-item-notification-1')).toHaveClass(
      'border-transparent',
    );
  });
});

describe('NotificationDropdown', () => {
  it('shows empty state when notifications array is empty', () => {
    renderWithRouter(
      <NotificationDropdown
        notifications={[]}
        onClose={vi.fn()}
        onMarkAllRead={vi.fn()}
        onMarkRead={vi.fn()}
        unreadCount={0}
      />,
    );

    expect(screen.getByText("You're all caught up!")).toBeInTheDocument();
  });

  it('renders Mark all read button', () => {
    renderWithRouter(
      <NotificationDropdown
        notifications={[createNotification()]}
        onClose={vi.fn()}
        onMarkAllRead={vi.fn()}
        onMarkRead={vi.fn()}
        unreadCount={1}
      />,
    );

    expect(
      screen.getByRole('button', { name: /mark all read/i }),
    ).toBeInTheDocument();
  });
});

describe('ToastContainer and useToast', () => {
  it('adding a toast renders it', async () => {
    render(
      <ToastProvider>
        <ToastHarness />
        <ToastContainer />
      </ToastProvider>,
    );

    await userEvent.click(screen.getByRole('button', { name: /add toast/i }));

    expect(screen.getByText('Saved')).toBeInTheDocument();
  });

  it('renders success variant with correct color class', async () => {
    render(
      <ToastProvider>
        <ToastHarness />
        <ToastContainer />
      </ToastProvider>,
    );

    await userEvent.click(screen.getByRole('button', { name: /add toast/i }));

    expect(screen.getByTestId('toast-success')).toHaveClass('border-emerald-500');
  });
});

describe('useNotifications', () => {
  it('calls initial fetch on mount', async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      json: async () => ({ notifications: [], unreadCount: 0 }),
      ok: false,
      status: 401,
    });
    vi.stubGlobal('fetch', fetchMock);

    renderHook(() => useNotifications());

    await waitFor(() => {
      expect(fetchMock).toHaveBeenCalledWith('/api/notifications');
    });
  });
});

describe('NotificationBell', () => {
  it('renders badge when unreadCount > 0', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue({
        json: async () => ({
          notifications: [createNotification()],
          unreadCount: 3,
        }),
        ok: true,
        status: 200,
      }),
    );

    renderWithRouter(<NotificationBell />);

    await waitFor(() => {
      expect(screen.getByTestId('notification-badge')).toHaveTextContent('3');
    });
  });
});
