import { describe, expect, it } from 'vitest';
import {
  parseDiff,
  generatePRDescription,
  validateBranchName,
} from '../lib/diff.server';
import { parseRepoUrl } from '../lib/git.server';
import { checkRateLimit } from '../lib/rate-limit.server';
import { createCommitSchema } from '../lib/schemas.server';

describe('parseRepoUrl', () => {
  it('extracts owner and repo from GitHub URLs', () => {
    expect(parseRepoUrl('https://github.com/octocat/hello-world.git')).toEqual({
      owner: 'octocat',
      repo: 'hello-world',
      provider: 'github',
    });
  });

  it('extracts namespace and repo from GitLab URLs', () => {
    expect(parseRepoUrl('https://gitlab.com/group/subgroup/project')).toEqual({
      owner: 'group/subgroup',
      repo: 'project',
      provider: 'gitlab',
    });
  });
});

describe('validateBranchName', () => {
  it('accepts valid branch names', () => {
    expect(validateBranchName('feature/git-api')).toEqual({ valid: true });
  });

  it('rejects invalid branch names', () => {
    expect(validateBranchName('feature git api').valid).toBe(false);
  });
});

describe('generatePRDescription', () => {
  it('returns a non-empty description', () => {
    expect(
      generatePRDescription([{ message: 'Add API endpoint' }]).length,
    ).toBeGreaterThan(0);
  });
});

describe('parseDiff', () => {
  it('parses unified diff output', () => {
    const diff = `diff --git a/app.ts b/app.ts
index 1111111..2222222 100644
--- a/app.ts
+++ b/app.ts
@@ -1,2 +1,3 @@
 const value = 1;
-console.log(value);
+console.log(value + 1);
+console.log('done');`;

    expect(parseDiff(diff)).toEqual([
      {
        filename: 'app.ts',
        status: 'modified',
        additions: 2,
        deletions: 1,
        patch: diff,
      },
    ]);
  });
});

describe('checkRateLimit', () => {
  it('allows requests until the limit is exceeded', async () => {
    const key = `git-test-${crypto.randomUUID()}`;

    const first = await checkRateLimit(key, 2, 60);
    const second = await checkRateLimit(key, 2, 60);
    const third = await checkRateLimit(key, 2, 60);

    expect(first.allowed).toBe(true);
    expect(second.allowed).toBe(true);
    expect(third.allowed).toBe(false);
    expect(third.remaining).toBe(0);
  });
});

describe('createCommitSchema', () => {
  it('validates commit payloads', () => {
    const valid = createCommitSchema.safeParse({
      projectId: '550e8400-e29b-41d4-a716-446655440000',
      message: 'Add git integration',
      files: [{ path: 'src/index.ts', content: 'export {};' }],
      branch: 'feature/git-api',
    });

    const invalid = createCommitSchema.safeParse({
      projectId: 'not-a-uuid',
      message: 'bad',
      files: [],
      branch: '',
    });

    expect(valid.success).toBe(true);
    expect(invalid.success).toBe(false);
  });
});
