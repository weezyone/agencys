import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { ArchiveProgress } from '~/components/Artifacts/ArchiveProgress';
import { DownloadCenter } from '~/components/Artifacts/DownloadCenter';
import { FileSelector } from '~/components/Artifacts/FileSelector';
import { CommitInterface } from '~/components/Git/CommitInterface';
import { DiffViewer } from '~/components/Git/DiffViewer';
import { Modal } from '~/components/ui/Modal';
import { Tabs } from '~/components/ui/Tabs';

afterEach(() => {
  vi.restoreAllMocks();
});

describe('DiffViewer', () => {
  it('renders file list with addition and deletion counts', () => {
    render(
      <DiffViewer
        files={[
          {
            additions: 3,
            deletions: 1,
            filename: 'src/app.ts',
            patch: '@@ -1,1 +1,3 @@\n-line\n+line\n+two\n+three',
            status: 'modified',
          },
        ]}
      />,
    );

    expect(screen.getAllByText('src/app.ts')[0]).toBeInTheDocument();
    expect(screen.getAllByText('+3')[0]).toBeInTheDocument();
    expect(screen.getAllByText('-1')[0]).toBeInTheDocument();
  });

  it('shows empty state when no files', () => {
    render(<DiffViewer files={[]} />);
    expect(
      screen.getByText(/No files selected for diff preview/i),
    ).toBeInTheDocument();
  });
});

describe('CommitInterface', () => {
  const changedFiles = [
    { content: 'export const ui = true;', path: 'app/components/ui.ts' },
  ];

  it('shows validation error for short commit message', async () => {
    render(
      <CommitInterface
        changedFiles={changedFiles}
        projectId="11111111-1111-4111-8111-111111111111"
      />,
    );
    await userEvent.click(screen.getByRole('button', { name: /Next/i }));
    await userEvent.click(screen.getByRole('button', { name: /Next/i }));
    await userEvent.type(
      screen.getByPlaceholderText(/Describe the Git integration UI changes/i),
      'hey',
    );
    await userEvent.click(screen.getByRole('button', { name: /Continue/i }));
    expect(
      screen.getByText(/Commit message must be between 5 and 200 characters/i),
    ).toBeInTheDocument();
  });

  it('shows validation error for invalid branch name', async () => {
    render(
      <CommitInterface
        changedFiles={changedFiles}
        projectId="11111111-1111-4111-8111-111111111111"
      />,
    );
    await userEvent.click(screen.getByRole('button', { name: /Next/i }));
    await userEvent.click(screen.getByRole('button', { name: /Next/i }));
    await userEvent.type(
      screen.getByPlaceholderText(/Describe the Git integration UI changes/i),
      'valid commit message',
    );
    const branchSelect = screen.getByLabelText(/Branch/i, {
      selector: 'select',
    });
    fireEvent.change(branchSelect, { target: { value: 'bad name!' } });
    await userEvent.click(
      screen.getByRole('button', { name: /Create new branch/i }),
    );
    await userEvent.type(
      screen.getByPlaceholderText(/feature\/git-artifacts-ui/i),
      'bad name!',
    );
    await userEvent.click(screen.getByRole('button', { name: /Add branch/i }));
    expect(
      screen.getByText(/Branch names may only include/i),
    ).toBeInTheDocument();
  });
});

describe('FileSelector', () => {
  it('shows warning when more than 1000 files are selected', () => {
    render(
      <FileSelector
        files={Array.from({ length: 1001 }, (_, index) => ({
          path: `src/file-${index}.ts`,
          size: 10,
        }))}
        projectId="11111111-1111-4111-8111-111111111111"
      />,
    );

    expect(
      screen.getByText(/Selection exceeds 1000 files/i),
    ).toBeInTheDocument();
  });
});

describe('DownloadCenter', () => {
  it('renders empty state', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue({
        json: async () => ({ artifacts: [] }),
        ok: true,
      }),
    );

    render(<DownloadCenter projectId="11111111-1111-4111-8111-111111111111" />);
    await waitFor(() =>
      expect(
        screen.getByText(/No artifacts found for this project/i),
      ).toBeInTheDocument(),
    );
  });
});

describe('ArchiveProgress', () => {
  it('shows progress bar when artifactId is provided', () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue({
        json: async () => ({
          artifact: {
            createdAt: new Date().toISOString(),
            fileSize: 1200,
            id: 'artifact-1',
            name: 'bundle.zip',
          },
          downloadUrl: 'https://example.com/bundle.zip',
        }),
        ok: true,
      }),
    );

    render(<ArchiveProgress artifactId="artifact-1" />);
    expect(screen.getByText(/Compressing/i)).toBeInTheDocument();
  });
});

describe('Modal', () => {
  it('calls onClose when backdrop is clicked', async () => {
    const onClose = vi.fn();
    render(
      <Modal onClose={onClose} open title="Test modal">
        Modal content
      </Modal>,
    );

    await userEvent.click(screen.getByRole('presentation'));
    expect(onClose).toHaveBeenCalledTimes(1);
  });
});

describe('Tabs', () => {
  it('highlights the active tab', () => {
    render(
      <Tabs
        activeTab="git"
        onTabChange={vi.fn()}
        tabs={[
          { id: 'ai', label: 'AI Task' },
          { id: 'git', label: 'Git' },
        ]}
      />,
    );

    expect(screen.getByRole('button', { name: /Git/i })).toHaveClass(
      'text-sky-300',
    );
  });
});
