import { afterEach, describe, expect, it, vi } from 'vitest';
import { calculateChecksum } from '../lib/archive.server';
import { checkRateLimit } from '../lib/rate-limit.server';
import { appendSandboxLog, getSandboxLogs } from '../lib/sandbox.server';
import { encodeSSEEvent } from '../lib/sse.server';
import { generateBranchName, withRetry } from '../lib/utils';
import { emitWorkflowEvent, getWorkflowEvents } from '../lib/workflow.server';

function parseEncodedEvent(payload: string) {
  const lines = payload.trim().split('\n');
  const parsed: {
    id?: string;
    event?: string;
    retry?: number;
    data?: unknown;
  } = {};

  for (const line of lines) {
    const [key, ...rest] = line.split(': ');
    const value = rest.join(': ');
    if (key === 'data') {
      parsed.data = JSON.parse(value);
    } else if (key === 'retry') {
      parsed.retry = Number(value);
    } else if (key === 'id' || key === 'event') {
      parsed[key] = value;
    }
  }

  return parsed;
}

afterEach(() => {
  vi.restoreAllMocks();
  vi.useRealTimers();
});

describe('integration flows', () => {
  it('round-trips workflow events through KV storage', async () => {
    const workflowId = `workflow-${crypto.randomUUID()}`;
    const event = {
      message: 'Workflow started',
      timestamp: Date.now(),
      type: 'log' as const,
    };

    await emitWorkflowEvent(workflowId, event);

    await expect(getWorkflowEvents(workflowId)).resolves.toEqual([event]);
  });

  it('round-trips sandbox logs through KV storage', async () => {
    const sandboxId = `sandbox-${crypto.randomUUID()}`;
    const entry = {
      data: 'command output',
      timestamp: Date.now(),
      type: 'stdout' as const,
    };

    await appendSandboxLog(sandboxId, entry);

    await expect(getSandboxLogs(sandboxId)).resolves.toEqual([entry]);
  });

  it('round-trips SSE encoding and parsing', () => {
    const encoded = encodeSSEEvent({
      data: { step: 'build', status: 'running' },
      event: 'workflow',
      id: 'evt-1',
      retry: 3000,
    });

    expect(parseEncodedEvent(encoded)).toEqual({
      data: { step: 'build', status: 'running' },
      event: 'workflow',
      id: 'evt-1',
      retry: 3000,
    });
  });

  it('allows requests until the rate limit is exceeded', async () => {
    const key = `integration-rate-limit-${crypto.randomUUID()}`;

    const first = await checkRateLimit(key, 2, 60);
    const second = await checkRateLimit(key, 2, 60);
    const third = await checkRateLimit(key, 2, 60);

    expect(first.allowed).toBe(true);
    expect(second.allowed).toBe(true);
    expect(third.allowed).toBe(false);
  });

  it('generates a valid branch name', () => {
    const branch = generateBranchName('Finalize production-ready release 🚀');

    expect(branch).toMatch(/^[a-z0-9-]+$/);
    expect(branch.length).toBeLessThanOrEqual(50);
  });

  it('retries the expected number of times', async () => {
    vi.useFakeTimers();
    vi.spyOn(Math, 'random').mockReturnValue(0);

    const fn = vi
      .fn<() => Promise<string>>()
      .mockRejectedValueOnce(new Error('first'))
      .mockRejectedValueOnce(new Error('second'))
      .mockResolvedValue('ok');

    const promise = withRetry(fn, 2, 5);
    await vi.runAllTimersAsync();

    await expect(promise).resolves.toBe('ok');
    expect(fn).toHaveBeenCalledTimes(3);
  });

  it('calculates deterministic checksums', async () => {
    const first = await calculateChecksum(
      Buffer.from('deterministic-artifact'),
    );
    const second = await calculateChecksum(
      Buffer.from('deterministic-artifact'),
    );

    expect(first).toBe(second);
    expect(first).toMatch(/^[a-f0-9]{64}$/);
  });
});
