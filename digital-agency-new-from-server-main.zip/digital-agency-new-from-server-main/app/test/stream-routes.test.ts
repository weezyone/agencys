import { beforeEach, describe, expect, it, vi } from 'vitest';

const sessionMock = vi.hoisted(() => ({
  requireAuth: vi.fn(),
}));

vi.mock('~/lib/session.server', () => sessionMock);

const presenceRoute = await import('../routes/api.stream.presence');
const sandboxRoute = await import('../routes/api.stream.sandbox.$id');
const workflowRoute = await import('../routes/api.stream.workflow.$id');

const testSession = {
  accessToken: 'token',
  email: 'user@example.com',
  expiresAt: Date.now() + 60_000,
  name: 'Test User',
  provider: 'email' as const,
  userId: 'user-1',
};

beforeEach(() => {
  vi.clearAllMocks();
  sessionMock.requireAuth.mockResolvedValue(testSession);
});

describe('stream API routes', () => {
  it('returns unauthorized for unauthenticated presence streams', async () => {
    sessionMock.requireAuth.mockRejectedValue(new Response(null, { status: 302 }));

    const response = await presenceRoute.loader({
      request: new Request('http://localhost/api/stream/presence?projectId=project-1'),
    });

    await expect(response.json()).resolves.toEqual({ error: 'Unauthorized' });
    expect(response.status).toBe(401);
  });

  it('validates presence stream project IDs before opening SSE', async () => {
    const response = await presenceRoute.loader({
      request: new Request('http://localhost/api/stream/presence'),
    });

    await expect(response.json()).resolves.toEqual({
      error: 'Project ID is required',
    });
    expect(response.status).toBe(400);
  });

  it('returns unauthorized for unauthenticated sandbox streams', async () => {
    sessionMock.requireAuth.mockRejectedValue(new Response(null, { status: 302 }));

    const response = await sandboxRoute.loader({
      request: new Request('http://localhost/api/stream/sandbox/sandbox-1'),
    });

    await expect(response.json()).resolves.toEqual({ error: 'Unauthorized' });
    expect(response.status).toBe(401);
  });

  it('returns unauthorized for unauthenticated workflow streams', async () => {
    sessionMock.requireAuth.mockRejectedValue(new Response(null, { status: 302 }));

    const response = await workflowRoute.loader({
      request: new Request('http://localhost/api/stream/workflow/workflow-1'),
    });

    await expect(response.json()).resolves.toEqual({ error: 'Unauthorized' });
    expect(response.status).toBe(401);
  });
});
