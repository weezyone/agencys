import { beforeEach, describe, expect, it, vi } from 'vitest';
import { updatePreferencesSchema } from '../lib/schemas.server';

const notificationCreateMock = vi.fn();
const notificationFindManyMock = vi.fn();
const notificationCountMock = vi.fn();
const notificationUpdateManyMock = vi.fn();
const notificationFindFirstMock = vi.fn();
const notificationDeleteMock = vi.fn();
const notificationPreferenceFindUniqueMock = vi.fn();
const notificationPreferenceUpsertMock = vi.fn();
const userFindUniqueMock = vi.fn();

vi.mock('../lib/db.server', () => ({
  db: {
    notification: {
      count: notificationCountMock,
      create: notificationCreateMock,
      delete: notificationDeleteMock,
      findFirst: notificationFindFirstMock,
      findMany: notificationFindManyMock,
      updateMany: notificationUpdateManyMock,
    },
    notificationPreference: {
      findUnique: notificationPreferenceFindUniqueMock,
      upsert: notificationPreferenceUpsertMock,
    },
    user: {
      findUnique: userFindUniqueMock,
    },
  },
}));

vi.mock('../lib/kv.server', async () => {
  const actual = await vi.importActual<typeof import('../lib/kv.server')>(
    '../lib/kv.server',
  );

  return {
    ...actual,
    default: actual.createInMemoryKVStore(),
  };
});

const notificationsModule = await import('../lib/notifications.server');
const {
  deliverWebhook,
  drainLiveNotifications,
  getPreferences,
  markAllRead,
  pushLiveNotification,
  renderTeamInviteEmail,
  renderWorkflowCompleteEmail,
  sendEmailNotification,
} = notificationsModule;

beforeEach(() => {
  vi.clearAllMocks();
  notificationCountMock.mockResolvedValue(0);
  notificationPreferenceFindUniqueMock.mockResolvedValue(null);
  notificationUpdateManyMock.mockResolvedValue({ count: 2 });
});

describe('renderWorkflowCompleteEmail', () => {
  it('returns non-empty HTML containing project name', () => {
    const html = renderWorkflowCompleteEmail('Alpha', 'workflow-1');
    expect(html.length).toBeGreaterThan(0);
    expect(html).toContain('Alpha');
  });
});

describe('renderTeamInviteEmail', () => {
  it('contains invite token', () => {
    const html = renderTeamInviteEmail(
      'Platform Team',
      'Alex',
      'invite-token-123',
      'https://app.example.com',
    );
    expect(html).toContain('invite-token-123');
  });
});

describe('deliverWebhook', () => {
  it('posts the expected JSON payload', async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValue(new Response(null, { status: 200 }));
    vi.stubGlobal('fetch', fetchMock);

    await deliverWebhook('https://hooks.example.com', {
      body: 'Body text',
      metadata: { workflowId: 'wf-1' },
      timestamp: '2025-01-01T00:00:00.000Z',
      title: 'Workflow complete',
      type: 'WORKFLOW_COMPLETE',
    });

    expect(fetchMock).toHaveBeenCalledWith(
      'https://hooks.example.com',
      expect.objectContaining({
        body: JSON.stringify({
          body: 'Body text',
          metadata: { workflowId: 'wf-1' },
          timestamp: '2025-01-01T00:00:00.000Z',
          title: 'Workflow complete',
          type: 'WORKFLOW_COMPLETE',
        }),
        method: 'POST',
      }),
    );
  });
});

describe('sendEmailNotification', () => {
  it('silently skips when RESEND_API_KEY is not configured', async () => {
    const fetchMock = vi.fn();
    vi.stubGlobal('fetch', fetchMock);
    delete process.env.RESEND_API_KEY;

    await sendEmailNotification({
      html: '<p>Hello</p>',
      subject: 'Test',
      to: 'user@example.com',
    });

    expect(fetchMock).not.toHaveBeenCalled();
  });
});

describe('pushLiveNotification + drainLiveNotifications', () => {
  it('round-trips notifications via the in-memory KV store', async () => {
    const notification = {
      body: 'Body',
      createdAt: new Date('2025-01-01T00:00:00.000Z'),
      id: 'notification-1',
      metadata: {},
      readAt: null,
      title: 'Title',
      type: 'SYSTEM',
      userId: 'user-1',
    };

    await pushLiveNotification('user-1', notification as never);
    const drained = await drainLiveNotifications('user-1');

    expect(drained).toHaveLength(1);
    expect(drained[0]).toMatchObject({ id: 'notification-1', title: 'Title' });
    expect(drained[0].createdAt).toBeInstanceOf(Date);
  });
});

describe('markAllRead', () => {
  it('uses the expected database query', async () => {
    await markAllRead('user-1');

    expect(notificationUpdateManyMock).toHaveBeenCalledWith({
      data: { readAt: expect.any(Date) },
      where: { readAt: null, userId: 'user-1' },
    });
  });
});

describe('updatePreferencesSchema', () => {
  it('transforms an empty webhookUrl string to null', () => {
    const parsed = updatePreferencesSchema.parse({ webhookUrl: '' });
    expect(parsed.webhookUrl).toBeNull();
  });
});

describe('getPreferences', () => {
  it('returns defaults for a new user with no record', async () => {
    notificationPreferenceFindUniqueMock.mockResolvedValueOnce(null);

    await expect(getPreferences('user-1')).resolves.toMatchObject({
      artifactReady: true,
      emailEnabled: false,
      sandboxTimeout: true,
      teamInvite: true,
      userId: 'user-1',
      webhookUrl: null,
      workflowComplete: true,
      workflowFailed: true,
    });
  });
});
