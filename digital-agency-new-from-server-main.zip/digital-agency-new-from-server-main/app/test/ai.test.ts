import { beforeEach, describe, expect, it, vi } from 'vitest';
import { aiTaskSchema, saveApiKeySchema } from '../lib/schemas.server';

const anthropicProviderMock = vi.fn((modelId: string) => ({
  modelId,
  provider: 'claude',
}));
const openAIProviderMock = vi.fn((modelId: string) => ({
  modelId,
  provider: 'codex',
}));
const createAnthropicMock = vi.fn(() => anthropicProviderMock);
const createOpenAIMock = vi.fn(() => openAIProviderMock);
const generateTextMock = vi.fn();
const streamTextMock = vi.fn();

vi.mock('@ai-sdk/anthropic', () => ({
  createAnthropic: createAnthropicMock,
}));

vi.mock('@ai-sdk/openai', () => ({
  createOpenAI: createOpenAIMock,
}));

vi.mock('ai', () => ({
  generateText: generateTextMock,
  streamText: streamTextMock,
}));

const aiModule = await import('../lib/ai.server');

beforeEach(() => {
  vi.clearAllMocks();
  delete process.env.ANTHROPIC_API_KEY;
  delete process.env.OPENAI_API_KEY;
  generateTextMock.mockResolvedValue({
    finishReason: 'stop',
    response: { modelId: 'mock-model' },
    text: 'Generated response',
    usage: {
      inputTokens: 10,
      outputTokens: 5,
      totalTokens: 15,
    },
  });
  streamTextMock.mockReturnValue({
    fullStream: (async function* () {
      yield { text: 'chunk', type: 'text-delta' };
    })(),
    totalUsage: Promise.resolve({
      inputTokens: 1,
      outputTokens: 1,
      totalTokens: 2,
    }),
  });
});

describe('buildCodingSystemPrompt', () => {
  it('includes context file content when provided', () => {
    const prompt = aiModule.buildCodingSystemPrompt([
      { content: 'export const value = 1;', path: 'src/example.ts' },
    ]);

    expect(prompt).toContain('src/example.ts');
    expect(prompt).toContain('export const value = 1;');
    expect(prompt).toContain('<context_files>');
  });

  it('returns a non-empty string without context', () => {
    expect(aiModule.buildCodingSystemPrompt()).toMatch(/\S/);
  });
});

describe('validateProviderConfig', () => {
  it('returns invalid when env key is missing', () => {
    expect(aiModule.validateProviderConfig('claude')).toEqual({
      error: 'ANTHROPIC_API_KEY not configured',
      valid: false,
    });
  });

  it('returns valid when env key is set', () => {
    process.env.ANTHROPIC_API_KEY = 'anthropic-test-key';

    expect(aiModule.validateProviderConfig('claude')).toEqual({ valid: true });
  });
});

describe('getRateLimitKey', () => {
  it('returns a consistent string for the same user and provider', () => {
    expect(aiModule.getRateLimitKey('user-1', 'claude')).toBe(
      aiModule.getRateLimitKey('user-1', 'claude'),
    );
  });
});

describe('aiTaskSchema', () => {
  it('rejects prompts under 10 chars', () => {
    expect(
      aiTaskSchema.safeParse({ prompt: 'too short', provider: 'claude' })
        .success,
    ).toBe(false);
  });

  it('rejects prompts over 2000 chars', () => {
    expect(
      aiTaskSchema.safeParse({
        prompt: 'x'.repeat(2001),
        provider: 'codex',
      }).success,
    ).toBe(false);
  });
});

describe('API key encryption', () => {
  it('round-trips encrypted API keys', () => {
    const encrypted = aiModule.encryptApiKey(
      'secret-api-key-value',
      'session-secret',
    );

    expect(aiModule.decryptApiKey(encrypted, 'session-secret')).toBe(
      'secret-api-key-value',
    );
  });
});

describe('saveApiKeySchema', () => {
  it('rejects short keys', () => {
    expect(
      saveApiKeySchema.safeParse({ apiKey: 'short', provider: 'claude' })
        .success,
    ).toBe(false);
  });
});

describe('generateAIResponse', () => {
  it('uses the Claude model for claude provider', async () => {
    process.env.ANTHROPIC_API_KEY = 'anthropic-test-key';

    await aiModule.generateAIResponse({
      provider: 'claude',
      prompt: 'Generate a testable coding response.',
    });

    expect(generateTextMock).toHaveBeenCalledWith(
      expect.objectContaining({
        model: expect.objectContaining({
          modelId: 'claude-3-5-sonnet-20241022',
        }),
      }),
    );
  });

  it('uses the OpenAI model for codex provider', async () => {
    process.env.OPENAI_API_KEY = 'openai-test-key';

    await aiModule.generateAIResponse({
      provider: 'codex',
      prompt: 'Generate a second coding response.',
    });

    expect(generateTextMock).toHaveBeenCalledWith(
      expect.objectContaining({
        model: expect.objectContaining({ modelId: 'gpt-4o' }),
      }),
    );
  });
});
