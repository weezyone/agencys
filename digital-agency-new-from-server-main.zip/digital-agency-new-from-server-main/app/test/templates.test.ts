import { beforeEach, describe, expect, it, vi } from 'vitest';
import {
  createTemplateSchema,
  TEMPLATE_CATEGORIES,
  templateSearchSchema,
  useTemplateSchema,
} from '../lib/schemas.server';

const projectTemplateCountMock = vi.fn();
const projectTemplateFindManyMock = vi.fn();
const projectTemplateFindFirstMock = vi.fn();
const projectTemplateCreateMock = vi.fn();
const projectTemplateUpdateMock = vi.fn();
const projectTemplateDeleteMock = vi.fn();
const projectFindFirstMock = vi.fn();
const createProjectMock = vi.fn();

vi.mock('~/lib/db.server', () => ({
  db: {
    project: {
      findFirst: projectFindFirstMock,
    },
    projectTemplate: {
      count: projectTemplateCountMock,
      create: projectTemplateCreateMock,
      delete: projectTemplateDeleteMock,
      findFirst: projectTemplateFindFirstMock,
      findMany: projectTemplateFindManyMock,
      update: projectTemplateUpdateMock,
    },
  },
}));

vi.mock('~/lib/data.server', () => ({
  createProject: createProjectMock,
}));

const templatesModule = await import('../lib/templates.server');

beforeEach(() => {
  vi.clearAllMocks();
  projectTemplateCountMock.mockImplementation(
    async (args?: { where?: { isBuiltIn?: boolean } }) =>
      args?.where?.isBuiltIn ? 1 : 3,
  );
  projectTemplateFindManyMock.mockResolvedValue([]);
});

describe('createTemplateSchema', () => {
  it('validates category enum (rejects unknown category)', () => {
    const result = createTemplateSchema.safeParse({
      name: 'Template',
      description: 'This is a valid description.',
      category: 'unknown-category',
      tags: [],
    });

    expect(result.success).toBe(false);
  });
});

describe('useTemplateSchema', () => {
  it('rejects empty project name', () => {
    expect(useTemplateSchema.safeParse({ projectName: '' }).success).toBe(false);
  });
});

describe('templateSearchSchema', () => {
  it('coerces string numbers', () => {
    const result = templateSearchSchema.parse({ limit: '10', offset: '5' });

    expect(result.limit).toBe(10);
    expect(result.offset).toBe(5);
  });

  it('accepts all valid category values', () => {
    for (const category of TEMPLATE_CATEGORIES) {
      expect(templateSearchSchema.safeParse({ category }).success).toBe(true);
    }
  });
});

describe('listTemplates', () => {
  it('applies search filter to name, description, and tags', async () => {
    await templatesModule.listTemplates({ search: 'React' });

    expect(projectTemplateFindManyMock).toHaveBeenCalledWith(
      expect.objectContaining({
        where: {
          AND: expect.arrayContaining([
            expect.objectContaining({
              OR: expect.arrayContaining([
                { name: { contains: 'React', mode: 'insensitive' } },
                { description: { contains: 'React', mode: 'insensitive' } },
                { tags: { has: 'react' } },
              ]),
            }),
          ]),
        },
      }),
    );
  });

  it('applies category filter', async () => {
    await templatesModule.listTemplates({ category: 'api' });

    expect(projectTemplateFindManyMock).toHaveBeenCalledWith(
      expect.objectContaining({
        where: {
          AND: expect.arrayContaining([{ category: 'api' }]),
        },
      }),
    );
  });
});

describe('incrementTemplateUseCount', () => {
  it('updates use count', async () => {
    await templatesModule.incrementTemplateUseCount('template-1');

    expect(projectTemplateUpdateMock).toHaveBeenCalledWith({
      where: { id: 'template-1' },
      data: { useCount: { increment: 1 } },
    });
  });
});

describe('BUILT_IN_TEMPLATES', () => {
  it('has exactly 8 entries', () => {
    expect(templatesModule.BUILT_IN_TEMPLATES).toHaveLength(8);
  });

  it('each built-in template has required fields', () => {
    for (const template of templatesModule.BUILT_IN_TEMPLATES) {
      expect(template.name).toBeTruthy();
      expect(template.description).toBeTruthy();
      expect(template.category).toBeTruthy();
      expect(template.sandboxConfig).toBeDefined();
    }
  });
});

describe('useTemplate', () => {
  it('creates project and increments count', async () => {
    const template = {
      id: 'template-1',
      name: 'Template One',
      description: 'A useful template',
      longDescription: null,
      category: 'api',
      tags: ['api'],
      repositoryUrl: 'https://github.com/example/repo',
      branch: 'main',
      sandboxConfig: { vcpus: 2, timeoutMinutes: 30, runtime: 'node22' },
      aiPrompt: 'Build an API',
      authorId: null,
      isPublic: true,
      isBuiltIn: true,
      useCount: 0,
      previewImageUrl: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    const project = {
      id: 'project-1',
      userId: 'user-1',
      name: 'My Project',
      description: 'A useful template',
      repositoryUrl: 'https://github.com/example/repo',
      branch: 'main',
      settings: {},
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    projectTemplateFindFirstMock.mockResolvedValue(template);
    createProjectMock.mockResolvedValue(project);

    const result = await templatesModule.useTemplate(
      'template-1',
      'user-1',
      'My Project',
    );

    expect(createProjectMock).toHaveBeenCalledWith(
      'user-1',
      expect.objectContaining({
        name: 'My Project',
        description: template.description,
        repositoryUrl: template.repositoryUrl,
        branch: template.branch,
      }),
    );
    expect(projectTemplateUpdateMock).toHaveBeenCalledWith({
      where: { id: 'template-1' },
      data: { useCount: { increment: 1 } },
    });
    expect(result).toEqual({
      project,
      template,
      sandboxConfig: {
        vcpus: 2,
        timeoutMinutes: 30,
        runtime: 'node22',
      },
      starterPrompt: 'Build an API',
    });
  });
});
