import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import { DateRangePicker } from '~/components/Analytics/DateRangePicker';
import { ExportButton } from '~/components/Analytics/ExportButton';
import { LineChart } from '~/components/Analytics/LineChart';
import { OverviewCards } from '~/components/Analytics/OverviewCards';
import { RecentErrorsList } from '~/components/Analytics/RecentErrorsList';
import { TopProjectsTable } from '~/components/Analytics/TopProjectsTable';
import type { OverviewMetrics } from '~/lib/analytics.server';

const metrics: OverviewMetrics = {
  activeProjectsCount: 12,
  estimatedCostUsd: 48.23,
  failedWorkflows: 15,
  successRate: 88.2,
  successfulWorkflows: 105,
  totalAiTokens: 1_200_000,
  totalArtifacts: 87,
  totalSandboxHours: 14.125,
  totalWorkflows: 120,
};

describe('DateRangePicker', () => {
  it('renders 3 buttons (7, 30, 90 days)', () => {
    render(<DateRangePicker onChange={() => {}} value={30} />);

    expect(screen.getByRole('button', { name: '7 days' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '30 days' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '90 days' })).toBeInTheDocument();
  });

  it('calls onChange with the correct value on click', () => {
    const onChange = vi.fn();
    render(<DateRangePicker onChange={onChange} value={30} />);

    fireEvent.click(screen.getByRole('button', { name: '90 days' }));
    expect(onChange).toHaveBeenCalledWith(90);
  });
});

describe('OverviewCards', () => {
  it('renders all 6 metric cards', () => {
    render(<OverviewCards metrics={metrics} />);

    expect(screen.getByText('Workflows')).toBeInTheDocument();
    expect(screen.getByText('Sandbox Hours')).toBeInTheDocument();
    expect(screen.getByText('AI Tokens')).toBeInTheDocument();
    expect(screen.getByText('Est. Cost')).toBeInTheDocument();
    expect(screen.getByText('Active Projects')).toBeInTheDocument();
    expect(screen.getByText('Artifacts')).toBeInTheDocument();
  });

  it('formats large token numbers', () => {
    render(<OverviewCards metrics={metrics} />);
    expect(screen.getByText('1.2M')).toBeInTheDocument();
  });
});

describe('LineChart', () => {
  it('renders an SVG element', () => {
    const { container } = render(
      <LineChart
        data={[
          { date: '2025-01-01', value: 10 },
          { date: '2025-01-02', value: 20 },
        ]}
      />,
    );

    expect(container.querySelector('svg')).toBeInTheDocument();
  });

  it('shows empty state when data is empty array', () => {
    render(<LineChart data={[]} />);
    expect(screen.getByText('No data for this period')).toBeInTheDocument();
  });
});

describe('ExportButton', () => {
  it('renders with correct label', () => {
    render(<ExportButton days={30} />);
    expect(screen.getByRole('button', { name: /export csv/i })).toBeInTheDocument();
  });
});

describe('TopProjectsTable', () => {
  it('shows empty state when projects is empty', () => {
    render(<TopProjectsTable projects={[]} />);
    expect(screen.getByText('No project activity yet')).toBeInTheDocument();
  });
});

describe('RecentErrorsList', () => {
  it('shows green checkmark when errors is empty', () => {
    const { container } = render(<RecentErrorsList errors={[]} />);

    expect(screen.getByText('No recent errors')).toBeInTheDocument();
    expect(container.querySelector('svg[aria-label="No recent errors"]')).toBeInTheDocument();
  });
});
