import { beforeEach, describe, expect, it, vi } from 'vitest';
import { PlanTier as PrismaPlanTier, type Subscription } from '@prisma/client';

const userFindUniqueMock = vi.fn();
const subscriptionUpsertMock = vi.fn();
const subscriptionUpdateMock = vi.fn();
const analyticsEventFindManyMock = vi.fn();
const projectCountMock = vi.fn();

vi.mock('../lib/db.server', () => ({
  db: {
    analyticsEvent: {
      findMany: analyticsEventFindManyMock,
    },
    project: {
      count: projectCountMock,
    },
    subscription: {
      update: subscriptionUpdateMock,
      upsert: subscriptionUpsertMock,
    },
    user: {
      findUnique: userFindUniqueMock,
    },
  },
  default: {
    analyticsEvent: {
      findMany: analyticsEventFindManyMock,
    },
    project: {
      count: projectCountMock,
    },
    subscription: {
      update: subscriptionUpdateMock,
      upsert: subscriptionUpsertMock,
    },
    user: {
      findUnique: userFindUniqueMock,
    },
  },
}));

const billingModule = await import('../lib/billing.server');
const billingMiddleware = await import('../lib/billing-middleware.server');

function buildSubscription(
  overrides: Partial<Subscription> = {},
): Subscription {
  return {
    aiTokensLimit: 100_000,
    cancelAtPeriodEnd: false,
    createdAt: new Date('2025-01-01T00:00:00.000Z'),
    currentPeriodEnd: new Date('2099-02-01T00:00:00.000Z'),
    currentPeriodStart: new Date('2099-01-01T00:00:00.000Z'),
    id: 'subscription-1',
    plan: PrismaPlanTier.FREE,
    projectsLimit: 3,
    sandboxHoursLimit: 10,
    stripeCustomerId: null,
    stripeSubId: null,
    updatedAt: new Date('2025-01-01T00:00:00.000Z'),
    userId: 'user-1',
    ...overrides,
  };
}

let currentSubscription = buildSubscription();

beforeEach(() => {
  vi.clearAllMocks();
  currentSubscription = buildSubscription();

  userFindUniqueMock.mockResolvedValue({
    createdAt: new Date('2025-01-01T00:00:00.000Z'),
  });
  subscriptionUpsertMock.mockImplementation(async ({ create }: { create: Partial<Subscription> }) => {
    currentSubscription = buildSubscription(create);
    return currentSubscription;
  });
  subscriptionUpdateMock.mockImplementation(async ({ data }: { data: Partial<Subscription> }) => {
    currentSubscription = buildSubscription({
      ...currentSubscription,
      ...data,
    });
    return currentSubscription;
  });
  analyticsEventFindManyMock.mockResolvedValue([]);
  projectCountMock.mockResolvedValue(1);
});

describe('PLAN_LIMITS', () => {
  it('FREE sandbox hours default to 10', () => {
    expect(billingModule.PLAN_LIMITS.FREE.sandboxHoursPerMonth).toBe(10);
  });

  it('PRO ai tokens default to 1,000,000', () => {
    expect(billingModule.PLAN_LIMITS.PRO.aiTokensPerMonth).toBe(1_000_000);
  });
});

describe('getOrCreateSubscription', () => {
  it('creates a FREE tier subscription for a new user', async () => {
    const subscription = await billingModule.getOrCreateSubscription('user-1');

    expect(subscription.plan).toBe(PrismaPlanTier.FREE);
    expect(subscription.sandboxHoursLimit).toBe(10);
    expect(subscription.aiTokensLimit).toBe(100_000);
    expect(subscription.projectsLimit).toBe(3);
    expect(subscriptionUpsertMock).toHaveBeenCalledWith(
      expect.objectContaining({
        create: expect.objectContaining({
          plan: PrismaPlanTier.FREE,
          userId: 'user-1',
        }),
        where: { userId: 'user-1' },
      }),
    );
  });
});

describe('canCreateSandbox', () => {
  it('returns not allowed when vcpus exceeds plan max', async () => {
    const result = await billingModule.canCreateSandbox('user-1', 3, 30);

    expect(result).toMatchObject({ allowed: false });
    expect(result.reason).toContain('2 vCPUs');
  });

  it('returns allowed within plan limits', async () => {
    const result = await billingModule.canCreateSandbox('user-1', 2, 30);

    expect(result).toEqual({ allowed: true });
  });
});

describe('getUsageSummary', () => {
  it('returns the expected usage structure', async () => {
    analyticsEventFindManyMock.mockResolvedValue([
      { eventType: 'sandbox.terminated', metadata: { cpuSeconds: 18_000 } },
      {
        eventType: 'ai.request',
        metadata: { completionTokens: 200, promptTokens: 300 },
      },
    ]);
    projectCountMock.mockResolvedValue(2);

    const usage = await billingModule.getUsageSummary('user-1');

    expect(usage).toMatchObject({
      aiTokens: {
        limit: 100_000,
        used: 500,
      },
      plan: 'FREE',
      projects: {
        limit: 3,
        used: 2,
      },
      sandboxHours: {
        limit: 10,
        used: 5,
      },
    });
    expect(usage.periodStart).toBeInstanceOf(Date);
    expect(usage.periodEnd).toBeInstanceOf(Date);
    expect(usage.sandboxHours.percent).toBeCloseTo(50);
    expect(usage.aiTokens.percent).toBeCloseTo(0.5);
    expect(usage.projects.percent).toBeCloseTo((2 / 3) * 100);
  });

  it('calculates percent correctly', async () => {
    analyticsEventFindManyMock.mockResolvedValue([
      { eventType: 'sandbox.terminated', metadata: { cpuSeconds: 18_000 } },
    ]);

    const usage = await billingModule.getUsageSummary('user-1');

    expect(usage.sandboxHours.percent).toBeCloseTo(50);
  });

  it('marks isOverLimit when any metric reaches 100 percent', async () => {
    analyticsEventFindManyMock.mockResolvedValue([
      {
        eventType: 'ai.request',
        metadata: { completionTokens: 60_000, promptTokens: 40_000 },
      },
    ]);

    const usage = await billingModule.getUsageSummary('user-1');

    expect(usage.aiTokens.percent).toBe(100);
    expect(usage.isOverLimit).toBe(true);
  });
});

describe('upgradePlan', () => {
  it('sets PRO limits correctly', async () => {
    const subscription = await billingModule.upgradePlan('user-1', 'PRO');

    expect(subscription.plan).toBe(PrismaPlanTier.PRO);
    expect(subscription.sandboxHoursLimit).toBe(100);
    expect(subscription.aiTokensLimit).toBe(1_000_000);
    expect(subscription.projectsLimit).toBe(20);
  });
});

describe('requireSandboxQuota', () => {
  it('throws 402 when over quota', async () => {
    analyticsEventFindManyMock.mockResolvedValue([
      { eventType: 'sandbox.terminated', metadata: { cpuSeconds: 36_000 } },
    ]);

    const response = (await billingMiddleware
      .requireSandboxQuota('user-1', 2, 30)
      .catch((error) => error)) as Response;

    expect(response).toBeInstanceOf(Response);
    expect(response.status).toBe(402);
    await expect(response.json()).resolves.toMatchObject({
      error: 'quota_exceeded',
      plan: 'FREE',
      upgradeUrl: '/settings/billing',
    });
  });
});
