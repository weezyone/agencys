import { beforeEach, describe, expect, it, vi } from 'vitest';

const requireAuthMock = vi.fn();
const getSessionMock = vi.fn();
const getProjectByIdMock = vi.fn();
const createSandboxMock = vi.fn();
const createArtifactMock = vi.fn();
const buildCodingSystemPromptMock = vi.fn(() => 'system prompt');
const checkProviderRateLimitMock = vi.fn();
const executeAgentInSandboxMock = vi.fn();
const generateAIResponseMock = vi.fn();
const streamAIResponseMock = vi.fn();
const validateProviderConfigMock = vi.fn();
const checkRateLimitMock = vi.fn();
const resolveGitContextMock = vi.fn();
const getGitClientMock = vi.fn();
const createWorkflowMock = vi.fn();
const executeWorkflowMock = vi.fn();
const requireSandboxQuotaMock = vi.fn();
const requireAiQuotaMock = vi.fn();
const requireProjectQuotaMock = vi.fn();

class MockGitApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public details?: unknown,
  ) {
    super(message);
  }
}

class MockGitHubClient {}
class MockGitLabClient {}

const sessionModuleMock = {
  getSession: getSessionMock,
  requireAuth: requireAuthMock,
};
const dataModuleMock = {
  createArtifact: createArtifactMock,
  createWorkflow: createWorkflowMock,
  getProjectById: getProjectByIdMock,
};

vi.mock('~/lib/session.server', () => sessionModuleMock);
vi.mock('../../app/lib/session.server', () => sessionModuleMock);
vi.mock('~/lib/data.server', () => dataModuleMock);
vi.mock('../../app/lib/data.server', () => dataModuleMock);
vi.mock('../../app/lib/sandbox.server', () => ({
  createSandbox: createSandboxMock,
}));
vi.mock('~/lib/ai.server', () => ({
  buildCodingSystemPrompt: buildCodingSystemPromptMock,
  checkProviderRateLimit: checkProviderRateLimitMock,
  executeAgentInSandbox: executeAgentInSandboxMock,
  generateAIResponse: generateAIResponseMock,
  streamAIResponse: streamAIResponseMock,
  validateProviderConfig: validateProviderConfigMock,
}));
vi.mock('~/lib/billing-middleware.server', () => ({
  requireAiQuota: requireAiQuotaMock,
  requireProjectQuota: requireProjectQuotaMock,
  requireSandboxQuota: requireSandboxQuotaMock,
}));
vi.mock('~/lib/ai-providers', () => ({
  PROVIDER_DEFINITIONS: {
    claude: { envKey: 'ANTHROPIC_API_KEY', kind: 'anthropic', model: 'claude-3-5-sonnet-20241022' },
    codex: { envKey: 'OPENAI_API_KEY', kind: 'openai-compatible', model: 'gpt-4o' },
    huggingface: { envKey: 'HUGGINGFACE_API_KEY', kind: 'openai-compatible', model: 'openai/gpt-oss-120b' },
    nvidia: { envKey: 'NVIDIA_API_KEY', kind: 'openai-compatible', model: 'openai/gpt-oss-120b' },
    openrouter: { envKey: 'OPENROUTER_API_KEY', kind: 'openai-compatible', model: 'openai/gpt-oss-120b' },
  },
  validateProviderConfig: validateProviderConfigMock,
}));
vi.mock('../../app/lib/rate-limit.server', () => ({
  checkRateLimit: checkRateLimitMock,
}));
vi.mock('../../app/lib/git.server', () => ({
  GitApiError: MockGitApiError,
  GitHubClient: MockGitHubClient,
  GitLabClient: MockGitLabClient,
  getGitClient: getGitClientMock,
  resolveGitContext: resolveGitContextMock,
}));
vi.mock('~/lib/workflow.server', () => ({
  cloudTaskWorkflow: { name: 'cloud-task' },
  gitCommitWorkflow: { name: 'git-commit' },
}));
vi.mock('@vercel/workflow', () => ({
  executeWorkflow: executeWorkflowMock,
}));

const sandboxCreateApi = await import('../../api/sandbox/create');
const aiTaskApi = await import('../../api/ai/task');
const aiProvidersRoute = await import('../routes/api.ai.providers');
const gitCommitApi = await import('../../api/git/commit');
const artifactCreateApi = await import('../../api/artifacts/create');
const workflowStartApi = await import('../../api/workflow/start');

const testUser = {
  accessToken: 'token',
  email: 'user@example.com',
  expiresAt: Date.now() + 60_000,
  name: 'Test User',
  provider: 'github' as const,
  userId: 'user-1',
};

beforeEach(() => {
  vi.clearAllMocks();
  requireAuthMock.mockResolvedValue(testUser);
  getSessionMock.mockResolvedValue(testUser);
  getProjectByIdMock.mockResolvedValue({
    id: '550e8400-e29b-41d4-a716-446655440000',
    userId: testUser.userId,
  });
  createSandboxMock.mockResolvedValue({
    id: 'sandbox-record-1',
    sandboxId: 'sandbox-1',
    status: 'ready',
  });
  createArtifactMock.mockResolvedValue({ id: 'artifact-1' });
  checkProviderRateLimitMock.mockResolvedValue({
    allowed: true,
    remaining: 4,
    resetAt: new Date('2025-01-01T00:00:00.000Z'),
  });
  validateProviderConfigMock.mockReturnValue({ valid: true });
  generateAIResponseMock.mockResolvedValue({ content: 'done' });
  streamAIResponseMock.mockResolvedValue(new ReadableStream());
  executeAgentInSandboxMock.mockResolvedValue({ exitCode: 0, output: 'done' });
  resolveGitContextMock.mockResolvedValue({ provider: 'github' });
  checkRateLimitMock.mockResolvedValue({
    allowed: true,
    remaining: 1,
    resetAt: new Date('2025-01-01T00:00:00.000Z'),
  });
  createWorkflowMock.mockResolvedValue({ id: 'workflow-1' });
  executeWorkflowMock.mockResolvedValue(undefined);
  requireSandboxQuotaMock.mockResolvedValue(undefined);
  requireAiQuotaMock.mockResolvedValue(undefined);
  requireProjectQuotaMock.mockResolvedValue(undefined);
});

describe('sandbox create handler', () => {
  it('returns 401 when authentication fails', async () => {
    requireAuthMock.mockRejectedValue(new Response(null, { status: 302 }));

    const response = await sandboxCreateApi.default(
      new Request('http://localhost/api/sandbox/create', {
        body: JSON.stringify({
          projectId: '550e8400-e29b-41d4-a716-446655440000',
        }),
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
      }),
    );

    expect(response.status).toBe(401);
  });

  it('returns 400 for invalid payloads', async () => {
    const response = await sandboxCreateApi.default(
      new Request('http://localhost/api/sandbox/create', {
        body: JSON.stringify({ projectId: 'not-a-uuid' }),
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
      }),
    );

    expect(response.status).toBe(400);
    await expect(response.json()).resolves.toMatchObject({
      error: 'Invalid sandbox payload',
    });
  });
});

describe('AI handlers', () => {
  it('returns provider availability JSON', async () => {
    validateProviderConfigMock.mockImplementation((provider) => ({
      valid: provider === 'claude',
    }));

    const response = await aiProvidersRoute.loader({
      request: new Request('http://localhost/api/ai/providers'),
    });
    const payload = await response.json();

    expect(response.status).toBe(200);
    expect(payload.providers).toHaveLength(5);
    expect(payload.providers).toEqual([
      expect.objectContaining({ id: 'claude', available: true }),
      expect.objectContaining({ id: 'codex', available: false }),
      expect.objectContaining({ id: 'huggingface', available: false }),
      expect.objectContaining({ id: 'nvidia', available: false }),
      expect.objectContaining({ id: 'openrouter', available: false }),
    ]);
  });

  it('returns 400 when the prompt is too short', async () => {
    const response = await aiTaskApi.default(
      new Request('http://localhost/api/ai/task', {
        body: JSON.stringify({ prompt: 'short', provider: 'claude' }),
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
      }),
    );

    expect(response.status).toBe(400);
    await expect(response.json()).resolves.toMatchObject({
      error: 'Invalid AI task payload',
    });
  });

  it('returns 429 when the provider rate limit is exceeded', async () => {
    checkProviderRateLimitMock.mockResolvedValue({
      allowed: false,
      remaining: 0,
      resetAt: new Date('2025-01-01T00:00:00.000Z'),
    });

    const response = await aiTaskApi.default(
      new Request('http://localhost/api/ai/task', {
        body: JSON.stringify({
          prompt: 'Generate a full integration test suite.',
          provider: 'claude',
        }),
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
      }),
    );

    expect(response.status).toBe(429);
    await expect(response.json()).resolves.toMatchObject({
      error: 'Rate limit exceeded',
    });
  });
});

describe('git commit handler', () => {
  it('returns 400 for a short commit message', async () => {
    const response = await gitCommitApi.default(
      new Request('http://localhost/api/git/commit', {
        body: JSON.stringify({
          branch: 'main',
          files: [{ content: 'export {};', path: 'src/index.ts' }],
          message: 'bad',
          projectId: '550e8400-e29b-41d4-a716-446655440000',
        }),
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
      }),
    );

    expect(response.status).toBe(400);
    await expect(response.json()).resolves.toMatchObject({
      error: 'Invalid commit request',
    });
  });

  it('returns 400 for an empty files array', async () => {
    const response = await gitCommitApi.default(
      new Request('http://localhost/api/git/commit', {
        body: JSON.stringify({
          branch: 'main',
          files: [],
          message: 'Ship complete test coverage',
          projectId: '550e8400-e29b-41d4-a716-446655440000',
        }),
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
      }),
    );

    expect(response.status).toBe(400);
    await expect(response.json()).resolves.toMatchObject({
      error: 'Invalid commit request',
    });
  });

  it('returns 429 when the commit rate limit is exceeded', async () => {
    checkRateLimitMock.mockResolvedValue({
      allowed: false,
      remaining: 0,
      resetAt: new Date('2025-01-01T00:00:00.000Z'),
    });

    const response = await gitCommitApi.default(
      new Request('http://localhost/api/git/commit', {
        body: JSON.stringify({
          branch: 'main',
          files: [{ content: 'export {};', path: 'src/index.ts' }],
          message: 'Ship complete test coverage',
          projectId: '550e8400-e29b-41d4-a716-446655440000',
        }),
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
      }),
    );

    expect(response.status).toBe(429);
    await expect(response.json()).resolves.toMatchObject({
      error: expect.stringContaining('Rate limit exceeded'),
    });
  });
});

describe('artifact create handler', () => {
  it('returns 400 when the file count exceeds the limit', async () => {
    const response = await artifactCreateApi.default(
      new Request('http://localhost/api/artifacts/create', {
        body: JSON.stringify({
          files: Array.from({ length: 1001 }, (_, index) => ({
            content: 'x',
            path: `src/file-${index}.ts`,
          })),
          projectId: '550e8400-e29b-41d4-a716-446655440000',
        }),
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
      }),
    );

    expect(response.status).toBe(400);
    await expect(response.json()).resolves.toMatchObject({
      error: 'Invalid artifact request',
    });
  });
});

describe('workflow start handler', () => {
  it('returns 400 when workflowType is invalid', async () => {
    const response = await workflowStartApi.default(
      new Request('http://localhost/api/workflow/start', {
        body: JSON.stringify({
          projectId: '550e8400-e29b-41d4-a716-446655440000',
          task: 'Start a workflow with an invalid type.',
          workflowType: 'bad-workflow',
        }),
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
      }),
    );

    expect(response.status).toBe(400);
    await expect(response.json()).resolves.toMatchObject({
      error: 'Invalid workflow payload',
    });
  });
});
