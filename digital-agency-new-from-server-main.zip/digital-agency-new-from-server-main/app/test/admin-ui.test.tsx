import type { ReactElement } from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { AuditLogFeed } from '~/components/Admin/AuditLogFeed';
import { BanModal } from '~/components/Admin/BanModal';
import { StatsGrid } from '~/components/Admin/StatsGrid';
import { SystemHealthCard } from '~/components/Admin/SystemHealthCard';
import { UserTable } from '~/components/Admin/UserTable';
import { ToastProvider } from '~/components/Notifications/ToastContainer';
import type { PlatformStats } from '~/lib/admin.server';

const stats: PlatformStats = {
  activeWorkflows: 18,
  errorRate: 4.2,
  estimatedPlatformCostUsd: 321.45,
  failedWorkflowsLast24h: 3,
  newUsersLast7Days: 12,
  totalAiRequests: 1200,
  totalProjects: 84,
  totalSandboxCpuHours: 42.6,
  totalSandboxes: 25,
  totalUsers: 120,
};

const users = [
  {
    createdAt: '2025-01-01T00:00:00.000Z',
    email: 'admin@example.com',
    id: 'user-1',
    isAdmin: true,
    isBanned: false,
    lastActiveAt: '2025-01-02T00:00:00.000Z',
    name: 'Admin User',
    projectCount: 4,
    provider: 'github',
    workflowCount: 12,
  },
  {
    createdAt: '2025-01-03T00:00:00.000Z',
    email: 'banned@example.com',
    id: 'user-2',
    isAdmin: false,
    isBanned: true,
    lastActiveAt: null,
    name: 'Banned User',
    projectCount: 1,
    provider: 'email',
    workflowCount: 2,
  },
];

function renderWithToast(ui: ReactElement) {
  return render(<ToastProvider>{ui}</ToastProvider>);
}

afterEach(() => {
  vi.restoreAllMocks();
});

describe('StatsGrid', () => {
  it('renders 6 stat cards', () => {
    render(<StatsGrid stats={stats} />);

    expect(screen.getAllByTestId(/stat-card-/)).toHaveLength(6);
  });

  it('shows red error rate when errorRate > 10', () => {
    render(<StatsGrid stats={{ ...stats, errorRate: 12.4 }} />);

    expect(screen.getByText('12.4%')).toHaveClass('text-red-300');
  });
});

describe('SystemHealthCard', () => {
  it('shows green indicator for ok status', () => {
    render(
      <SystemHealthCard
        health={{
          database: 'ok',
          dbLatencyMs: 18,
          kv: 'ok',
          kvLatencyMs: 9,
          uptime: 90061,
        }}
      />,
    );

    expect(screen.getByTestId('database-indicator')).toHaveClass('bg-emerald-400');
  });

  it('shows red indicator for error status', () => {
    render(
      <SystemHealthCard
        health={{
          database: 'error',
          dbLatencyMs: 18,
          kv: 'ok',
          kvLatencyMs: 9,
          uptime: 90061,
        }}
      />,
    );

    expect(screen.getByTestId('database-indicator')).toHaveClass('bg-red-400');
  });

  it('formats uptime correctly', () => {
    render(
      <SystemHealthCard
        health={{
          database: 'ok',
          dbLatencyMs: 18,
          kv: 'ok',
          kvLatencyMs: 9,
          uptime: 90061,
        }}
      />,
    );

    expect(screen.getByText('1 days 1 hours')).toBeInTheDocument();
  });
});

describe('UserTable', () => {
  it('renders column headers', () => {
    renderWithToast(<UserTable initialUsers={users} total={users.length} />);

    expect(screen.getByText('Name/Email')).toBeInTheDocument();
    expect(screen.getByText('Provider')).toBeInTheDocument();
    expect(screen.getByText('Projects')).toBeInTheDocument();
    expect(screen.getByText('Role')).toBeInTheDocument();
    expect(screen.getByText('Status')).toBeInTheDocument();
    expect(screen.getByText('Joined')).toBeInTheDocument();
    expect(screen.getByText('Actions')).toBeInTheDocument();
  });

  it('shows banned badge for banned users', () => {
    renderWithToast(<UserTable initialUsers={users} total={users.length} />);

    expect(screen.getByText('Banned')).toBeInTheDocument();
  });

  it('shows admin badge for admin users', () => {
    renderWithToast(<UserTable initialUsers={users} total={users.length} />);

    expect(screen.getByText('Admin')).toBeInTheDocument();
  });
});

describe('AuditLogFeed', () => {
  it('renders entries with the correct action color', async () => {
    vi.spyOn(global, 'fetch').mockResolvedValue({
      json: async () => ({
        logs: [
          {
            createdAt: new Date(Date.now() - 120000).toISOString(),
            id: 'log-1',
            newValues: { targetId: 'user-2' },
            oldValues: null,
            operation: 'ban_user',
            tableName: 'users',
            userId: 'admin-1',
          },
        ],
        total: 1,
      }),
      ok: true,
      status: 200,
    } as Response);

    renderWithToast(<AuditLogFeed limit={5} />);

    await waitFor(() => {
      expect(screen.getByText(/Admin banned user user-2/i)).toBeInTheDocument();
    });

    expect(screen.getByTestId('audit-dot-ban_user')).toHaveClass('bg-red-400');
  });
});

describe('BanModal', () => {
  it('disables submit when reason is empty', () => {
    renderWithToast(
      <BanModal isOpen onClose={vi.fn()} userId="user-1" userName="Example User" />,
    );

    expect(screen.getByRole('button', { name: 'Confirm Ban' })).toBeDisabled();
  });

  it('enables submit when reason is filled', async () => {
    renderWithToast(
      <BanModal isOpen onClose={vi.fn()} userId="user-1" userName="Example User" />,
    );

    await userEvent.type(screen.getByLabelText('Ban reason'), 'Abusive behavior');

    expect(screen.getByRole('button', { name: 'Confirm Ban' })).toBeEnabled();
  });
});
