import React from 'react';
import { act, render, renderHook, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { CollabIndicator } from '~/components/Workspace/CollabIndicator';
import { PresenceAvatars } from '~/components/Workspace/PresenceAvatars';
import { usePresence } from '~/hooks/usePresence';
import kv from '~/lib/kv.server';
import {
  getPresence,
  getUserColor,
  heartbeat,
  publishPresenceUpdate,
  type PresenceUser,
} from '~/lib/presence.server';

class MockEventSource {
  static instances: MockEventSource[] = [];

  onerror: ((event: Event) => void) | null = null;
  onmessage: ((event: MessageEvent<string>) => void) | null = null;
  onopen: ((event: Event) => void) | null = null;
  readonly url: string;
  private listeners = new Map<string, Set<EventListener>>();

  constructor(url: string) {
    this.url = url;
    MockEventSource.instances.push(this);
  }

  addEventListener(type: string, listener: EventListener) {
    const listeners = this.listeners.get(type) ?? new Set<EventListener>();
    listeners.add(listener);
    this.listeners.set(type, listeners);
  }

  removeEventListener(type: string, listener: EventListener) {
    this.listeners.get(type)?.delete(listener);
  }

  close() {}

  emit(type: string, data: unknown) {
    const event = {
      data: JSON.stringify(data),
      lastEventId: '',
    } as MessageEvent<string>;

    for (const listener of this.listeners.get(type) ?? []) {
      listener(event);
    }
  }
}

async function clearPresenceKeys() {
  const keys = await kv.keys('presence:*');
  await Promise.all(keys.map((key) => kv.del(key)));
}

function createPresenceUser(overrides: Partial<PresenceUser> = {}): PresenceUser {
  return {
    activeTab: 'ai',
    color: getUserColor('user-1'),
    cursor: null,
    lastSeen: Date.now(),
    name: 'Alice',
    userId: 'user-1',
    ...overrides,
  };
}

beforeEach(async () => {
  MockEventSource.instances = [];
  vi.useRealTimers();
  await clearPresenceKeys();
  vi.stubGlobal('EventSource', MockEventSource);
  vi.stubGlobal(
    'fetch',
    vi.fn().mockResolvedValue({
      json: async () => ({ users: [] }),
      ok: true,
      status: 200,
    }),
  );
});

afterEach(async () => {
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  vi.useRealTimers();
  await clearPresenceKeys();
});

describe('presence server utilities', () => {
  it('getUserColor returns a hex color string', () => {
    expect(getUserColor('user-1')).toMatch(/^#/);
  });

  it('getUserColor is deterministic for the same user id', () => {
    expect(getUserColor('user-1')).toBe(getUserColor('user-1'));
  });

  it('getUserColor returns different colors for different user ids', () => {
    expect(getUserColor('alpha')).not.toBe(getUserColor('beta'));
  });

  it('getPresence filters out stale users', async () => {
    const projectId = 'project-stale';
    await kv.hset(
      `presence:${projectId}`,
      'stale-user',
      JSON.stringify(
        createPresenceUser({
          lastSeen: Date.now() - 20_000,
          name: 'Stale User',
          userId: 'stale-user',
        }),
      ),
    );
    await kv.hset(
      `presence:${projectId}`,
      'fresh-user',
      JSON.stringify(
        createPresenceUser({
          lastSeen: Date.now(),
          name: 'Fresh User',
          userId: 'fresh-user',
        }),
      ),
    );

    await expect(getPresence(projectId)).resolves.toEqual([
      expect.objectContaining({ userId: 'fresh-user' }),
    ]);
  });

  it('getPresence includes recent users', async () => {
    const projectId = 'project-recent';
    await heartbeat(
      projectId,
      createPresenceUser({
        name: 'Recent User',
        userId: 'recent-user',
      }),
    );

    await expect(getPresence(projectId)).resolves.toEqual([
      expect.objectContaining({ userId: 'recent-user' }),
    ]);
  });

  it('heartbeat updates kv with the expected key format', async () => {
    const projectId = 'project-heartbeat';
    await heartbeat(projectId, createPresenceUser());

    const stored = await kv.hget<string>(`presence:${projectId}`, 'user-1');
    expect(typeof stored).toBe('string');
    expect(JSON.parse(stored ?? '{}')).toMatchObject({ userId: 'user-1' });
  });

  it('publishPresenceUpdate stores presence JSON in kv', async () => {
    const projectId = 'project-publish';
    await heartbeat(projectId, createPresenceUser());
    await publishPresenceUpdate(projectId);

    const stored = await kv.get<string>(`presence:updates:${projectId}`);
    expect(JSON.parse(stored ?? '[]')).toEqual([
      expect.objectContaining({ userId: 'user-1' }),
    ]);
  });
});

describe('PresenceAvatars', () => {
  it('renders nothing when only one user is active', async () => {
    render(
      React.createElement(
        MemoryRouter,
        null,
        React.createElement(PresenceAvatars, {
          currentUser: { id: 'user-1', name: 'Alice' },
          projectId: 'project-1',
        }),
      ),
    );

    await act(async () => {
      MockEventSource.instances[0]?.emit('presence', {
        count: 1,
        users: [createPresenceUser()],
      });
    });

    await waitFor(() => {
      expect(screen.queryByTestId('presence-avatars')).not.toBeInTheDocument();
    });
  });

  it('renders an avatar for each active collaborator beyond self', async () => {
    render(
      React.createElement(
        MemoryRouter,
        null,
        React.createElement(PresenceAvatars, {
          currentUser: { id: 'user-1', name: 'Alice' },
          projectId: 'project-1',
        }),
      ),
    );

    await act(async () => {
      MockEventSource.instances[0]?.emit('presence', {
        count: 3,
        users: [
          createPresenceUser(),
          createPresenceUser({
            activeTab: 'files',
            color: getUserColor('user-2'),
            name: 'Bob',
            userId: 'user-2',
          }),
          createPresenceUser({
            activeTab: 'logs',
            color: getUserColor('user-3'),
            name: 'Cara',
            userId: 'user-3',
          }),
        ],
      });
    });

    await waitFor(() => {
      expect(screen.getByTestId('presence-avatar-user-2')).toBeInTheDocument();
      expect(screen.getByTestId('presence-avatar-user-3')).toBeInTheDocument();
    });
  });
});

describe('usePresence', () => {
  it('sends a heartbeat on mount', async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      json: async () => ({ users: [] }),
      ok: true,
      status: 200,
    });
    vi.stubGlobal('fetch', fetchMock);

    renderHook(() =>
      usePresence('project-hook', { id: 'user-1', name: 'Alice' }),
    );

    await waitFor(() => {
      expect(fetchMock).toHaveBeenCalledWith(
        '/api/presence/heartbeat',
        expect.objectContaining({
          method: 'POST',
        }),
      );
    });
  });
});

describe('CollabIndicator', () => {
  it('renders count when more than one collaborator is online', () => {
    render(React.createElement(CollabIndicator, { count: 3 }));
    expect(screen.getByText('3 online')).toBeInTheDocument();
  });
});
