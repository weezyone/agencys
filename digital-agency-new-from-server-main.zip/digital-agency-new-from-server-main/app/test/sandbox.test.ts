import { beforeEach, describe, expect, it, vi } from 'vitest';
import {
  createSandboxSchema,
  executeCommandSchema,
} from '../lib/schemas.server';

const sandboxCreate = vi.fn();
const sandboxGet = vi.fn();
const createSandboxRecord = vi.fn();
const getSandboxBySandboxId = vi.fn();
const terminateSandboxBySandboxId = vi.fn();
const updateSandboxStatusBySandboxId = vi.fn();

vi.mock('@vercel/sandbox', () => ({
  Sandbox: {
    create: sandboxCreate,
    get: sandboxGet,
  },
}));

vi.mock('../lib/data.server', () => ({
  createSandboxRecord,
  getSandboxBySandboxId,
  terminateSandboxBySandboxId,
  updateSandboxStatusBySandboxId,
}));

const sandboxModule = await import('../lib/sandbox.server');

beforeEach(() => {
  vi.clearAllMocks();
  delete process.env.VERCEL_TOKEN;
  process.env.NODE_ENV = 'development';
  createSandboxRecord.mockImplementation(
    async (
      projectId: string,
      data: {
        sandboxId: string;
        status: string;
        configuration: Record<string, unknown>;
      },
    ) => ({
      createdAt: new Date('2025-01-01T00:00:00.000Z'),
      id: 'sandbox-record-1',
      projectId,
      sandboxId: data.sandboxId,
      status: data.status,
    }),
  );
  getSandboxBySandboxId.mockResolvedValue(null);
  terminateSandboxBySandboxId.mockResolvedValue(null);
  updateSandboxStatusBySandboxId.mockResolvedValue(null);
});

describe('createSandboxSchema', () => {
  it('accepts vcpu values from 1 to 8', () => {
    expect(
      createSandboxSchema.safeParse({
        projectId: crypto.randomUUID(),
        vcpus: 1,
      }).success,
    ).toBe(true);
    expect(
      createSandboxSchema.safeParse({
        projectId: crypto.randomUUID(),
        vcpus: 8,
      }).success,
    ).toBe(true);
  });

  it('rejects vcpu values outside the allowed range', () => {
    expect(
      createSandboxSchema.safeParse({
        projectId: crypto.randomUUID(),
        vcpus: 0,
      }).success,
    ).toBe(false);
    expect(
      createSandboxSchema.safeParse({
        projectId: crypto.randomUUID(),
        vcpus: 9,
      }).success,
    ).toBe(false);
  });
});

describe('executeCommandSchema', () => {
  it('rejects an empty command', () => {
    expect(executeCommandSchema.safeParse({ command: '' }).success).toBe(false);
  });
});

describe('sandbox logs', () => {
  it('returns an empty array when no logs exist', async () => {
    await expect(
      sandboxModule.getSandboxLogs(`sandbox-${crypto.randomUUID()}`),
    ).resolves.toEqual([]);
  });

  it('stores and retrieves log entries', async () => {
    const sandboxId = `sandbox-${crypto.randomUUID()}`;
    const entry = { data: 'hello', timestamp: Date.now(), type: 'stdout' };

    await sandboxModule.appendSandboxLog(sandboxId, entry);

    await expect(sandboxModule.getSandboxLogs(sandboxId)).resolves.toEqual([
      entry,
    ]);
  });
});

describe('createSandbox', () => {
  it('falls back gracefully when VERCEL_TOKEN is missing', async () => {
    const result = await sandboxModule.createSandbox(crypto.randomUUID(), {
      runtime: 'node22',
      vcpus: 2,
    });

    expect(sandboxCreate).not.toHaveBeenCalled();
    expect(createSandboxRecord).toHaveBeenCalledWith(
      expect.any(String),
      expect.objectContaining({
        sandboxId: expect.stringMatching(/^mock-sandbox-/),
        status: 'ready',
      }),
    );
    expect(result).toMatchObject({
      domain: expect.stringContaining('.sandbox.local'),
      id: 'sandbox-record-1',
      sandboxId: expect.stringMatching(/^mock-sandbox-/),
      status: 'ready',
    });
  });
});
