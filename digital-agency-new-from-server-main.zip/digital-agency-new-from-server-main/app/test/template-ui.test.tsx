import type { ProjectTemplate } from '@prisma/client';
import type { ReactElement } from 'react';
import { act, fireEvent, render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { CategoryFilter } from '~/components/Templates/CategoryFilter';
import { PublishTemplateModal } from '~/components/Templates/PublishTemplateModal';
import { SearchBar } from '~/components/Templates/SearchBar';
import { TemplateCard } from '~/components/Templates/TemplateCard';
import { TemplateGrid } from '~/components/Templates/TemplateGrid';
import { UseTemplateModal } from '~/components/Templates/UseTemplateModal';

function renderWithRouter(element: ReactElement) {
  return render(<MemoryRouter>{element}</MemoryRouter>);
}

const baseTemplate: ProjectTemplate = {
  aiPrompt: 'Build something useful with this template and ship it fast.',
  authorId: null,
  branch: 'main',
  category: 'fullstack',
  createdAt: new Date('2025-01-01T00:00:00Z'),
  description: 'Production-ready starter for your next project.',
  id: 'template-1',
  isBuiltIn: true,
  isPublic: true,
  longDescription: null,
  name: 'Starter Kit',
  previewImageUrl: null,
  repositoryUrl: 'https://github.com/example/repo',
  sandboxConfig: { runtime: 'node22', timeoutMinutes: 30, vcpus: 2 },
  tags: ['react', 'tailwind', 'prisma'],
  updatedAt: new Date('2025-01-02T00:00:00Z'),
  useCount: 42,
};

describe('TemplateCard', () => {
  it('renders template name and description', () => {
    renderWithRouter(<TemplateCard template={baseTemplate} />);

    expect(screen.getByText('Starter Kit')).toBeInTheDocument();
    expect(
      screen.getByText('Production-ready starter for your next project.'),
    ).toBeInTheDocument();
  });

  it('shows correct category icon for fullstack', () => {
    renderWithRouter(<TemplateCard template={baseTemplate} />);

    expect(screen.getByText('🏗️')).toBeInTheDocument();
  });

  it('shows correct category icon for api', () => {
    renderWithRouter(
      <TemplateCard template={{ ...baseTemplate, category: 'api', id: 'template-2' }} />,
    );

    expect(screen.getByText('⚡')).toBeInTheDocument();
  });
});

describe('CategoryFilter', () => {
  it('renders All plus provided categories', () => {
    render(
      <CategoryFilter categories={['api', 'fullstack']} onChange={vi.fn()} />,
    );

    expect(screen.getByRole('button', { name: 'All' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /api/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /fullstack/i })).toBeInTheDocument();
  });

  it('calls onChange with undefined when All clicked', () => {
    const onChange = vi.fn();
    render(
      <CategoryFilter
        categories={['api', 'fullstack']}
        onChange={onChange}
        selected="api"
      />,
    );

    fireEvent.click(screen.getByRole('button', { name: 'All' }));
    expect(onChange).toHaveBeenCalledWith(undefined);
  });
});

describe('SearchBar', () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('calls onChange after debounce delay', () => {
    const onChange = vi.fn();
    render(<SearchBar onChange={onChange} value="" />);

    fireEvent.change(screen.getByRole('searchbox'), {
      target: { value: 'api starter' },
    });

    expect(onChange).not.toHaveBeenCalled();

    act(() => {
      vi.advanceTimersByTime(300);
    });

    expect(onChange).toHaveBeenCalledWith('api starter');
  });
});

describe('TemplateGrid', () => {
  it('shows empty state when templates array is empty', () => {
    renderWithRouter(<TemplateGrid templates={[]} />);

    expect(screen.getByText('No templates found')).toBeInTheDocument();
    expect(
      screen.getByText('Try a different search or category'),
    ).toBeInTheDocument();
  });
});

describe('UseTemplateModal', () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('renders form with pre-filled project name', async () => {
    renderWithRouter(
      <UseTemplateModal isOpen onClose={vi.fn()} template={baseTemplate} />,
    );

    expect(await screen.findByDisplayValue('Starter Kit')).toBeInTheDocument();
  });

  it('shows loading state during form submission', async () => {
    vi.stubGlobal('fetch', vi.fn(() => new Promise(() => {})));

    renderWithRouter(
      <UseTemplateModal isOpen onClose={vi.fn()} template={baseTemplate} />,
    );

    fireEvent.click(await screen.findByRole('button', { name: /Create Project/i }));

    expect(screen.getByRole('button', { name: /Create Project/i })).toHaveAttribute(
      'aria-busy',
      'true',
    );
  });
});

describe('PublishTemplateModal', () => {
  it('disables submit when description too short', async () => {
    render(
      <PublishTemplateModal isOpen onClose={vi.fn()} projectId="project-1" />,
    );

    fireEvent.change(await screen.findByLabelText('Name'), {
      target: { value: 'My Template' },
    });
    fireEvent.change(screen.getAllByRole('textbox')[1], {
      target: { value: 'Too short' },
    });

    expect(screen.getByRole('button', { name: 'Publish Template' })).toBeDisabled();
  });
});
