import crypto from 'node:crypto';
import { beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('../lib/kv.server', async () => {
  const actual = await vi.importActual<typeof import('../lib/kv.server')>(
    '../lib/kv.server',
  );

  return {
    ...actual,
    default: actual.createInMemoryKVStore(),
  };
});

const githubAppModule = await import('../lib/github-app.server');
const { createCheckRun, parseWebhookEvent, validateWebhookSignature } =
  githubAppModule;
const { generateAppManifest } = await import('../../api/github/app-manifest');

beforeEach(() => {
  vi.restoreAllMocks();
  const { privateKey } = crypto.generateKeyPairSync('rsa', {
    modulusLength: 2048,
  });

  process.env.GITHUB_WEBHOOK_SECRET = 'webhook-secret';
  process.env.GITHUB_APP_ID = '123';
  process.env.GITHUB_APP_PRIVATE_KEY = Buffer.from(
    privateKey.export({ format: 'pem', type: 'pkcs1' }).toString(),
  ).toString('base64');
  delete process.env.GITHUB_APP_SLUG;
});

describe('validateWebhookSignature', () => {
  it('returns true for a valid HMAC', () => {
    const payload = JSON.stringify({ hello: 'world' });
    const signature = `sha256=${crypto
      .createHmac('sha256', 'webhook-secret')
      .update(payload)
      .digest('hex')}`;

    expect(validateWebhookSignature(payload, signature)).toBe(true);
  });

  it('returns false for a tampered payload', () => {
    const originalPayload = JSON.stringify({ hello: 'world' });
    const tamperedPayload = JSON.stringify({ hello: 'tampered' });
    const signature = `sha256=${crypto
      .createHmac('sha256', 'webhook-secret')
      .update(originalPayload)
      .digest('hex')}`;

    expect(validateWebhookSignature(tamperedPayload, signature)).toBe(false);
  });

  it('returns false for the wrong secret', () => {
    const payload = JSON.stringify({ hello: 'world' });
    const signature = `sha256=${crypto
      .createHmac('sha256', 'different-secret')
      .update(payload)
      .digest('hex')}`;

    expect(validateWebhookSignature(payload, signature)).toBe(false);
  });
});

describe('parseWebhookEvent', () => {
  it('returns a push event with the correct shape', () => {
    const headers = new Headers({ 'X-GitHub-Event': 'push' });
    const body = JSON.stringify({
      commits: [{ id: 'abc123', message: 'Ship it' }],
      installation: { id: 7 },
      ref: 'refs/heads/main',
      repository: { full_name: 'octo/repo' },
    });

    expect(parseWebhookEvent(headers, body)).toEqual({
      commits: [{ id: 'abc123', message: 'Ship it' }],
      installation: { id: 7 },
      ref: 'refs/heads/main',
      repository: { full_name: 'octo/repo' },
      type: 'push',
    });
  });

  it('returns a pull_request event with the correct shape', () => {
    const headers = new Headers({ 'X-GitHub-Event': 'pull_request' });
    const body = JSON.stringify({
      action: 'opened',
      installation: { id: 11 },
      pull_request: {
        head: { ref: 'feature/test', sha: 'def456' },
        number: 42,
      },
      repository: { full_name: 'octo/repo' },
    });

    expect(parseWebhookEvent(headers, body)).toEqual({
      action: 'opened',
      installation: { id: 11 },
      pull_request: {
        head: { ref: 'feature/test', sha: 'def456' },
        number: 42,
      },
      repository: { full_name: 'octo/repo' },
      type: 'pull_request',
    });
  });

  it('returns null for an unknown event type', () => {
    const headers = new Headers({ 'X-GitHub-Event': 'issues' });
    const body = JSON.stringify({ action: 'opened' });

    expect(parseWebhookEvent(headers, body)).toBeNull();
  });
});

describe('generateAppManifest', () => {
  it('returns the required keys', () => {
    expect(generateAppManifest('https://example.com')).toEqual(
      expect.objectContaining({
        events: expect.any(Array),
        name: 'Cloud Platform Dev',
        permissions: expect.any(Object),
        url: 'https://example.com',
        webhook_url: 'https://example.com/api/github/webhook',
      }),
    );
  });

  it("webhook_url ends with '/api/github/webhook'", () => {
    const manifest = generateAppManifest('https://example.com') as {
      webhook_url: string;
    };

    expect(manifest.webhook_url.endsWith('/api/github/webhook')).toBe(true);
  });

  it("permissions includes checks: 'write'", () => {
    const manifest = generateAppManifest('https://example.com') as {
      permissions: { checks?: string };
    };

    expect(manifest.permissions.checks).toBe('write');
  });
});

describe('createCheckRun', () => {
  it('calls the GitHub API with the installation bearer token', async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            expires_at: '2025-01-01T00:00:00.000Z',
            token: 'installation-token',
          }),
          {
            headers: { 'Content-Type': 'application/json' },
            status: 201,
          },
        ),
      )
      .mockResolvedValueOnce(
        new Response(JSON.stringify({ id: 99 }), {
          headers: { 'Content-Type': 'application/json' },
          status: 201,
        }),
      );
    vi.stubGlobal('fetch', fetchMock);

    await expect(
      createCheckRun({
        headSha: 'abc123',
        installationId: 314,
        name: 'Cloud Platform / AI Code Review',
        owner: 'octo',
        repo: 'repo',
        status: 'queued',
        summary: 'Queued',
        title: 'Queued',
      }),
    ).resolves.toEqual({ id: 99 });

    expect(fetchMock).toHaveBeenNthCalledWith(
      2,
      'https://api.github.com/repos/octo/repo/check-runs',
      expect.objectContaining({
        headers: expect.objectContaining({
          Authorization: 'Bearer installation-token',
        }),
        method: 'POST',
      }),
    );
  });
});
