import type { ReactElement } from 'react';
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router';
import { describe, expect, it } from 'vitest';
import { ActivityFeed } from '~/components/Dashboard/ActivityFeed';
import { ProjectGrid } from '~/components/Dashboard/ProjectGrid';
import { Badge } from '~/components/ui/Badge';
import { Button } from '~/components/ui/Button';
import { StatusIndicator } from '~/components/ui/StatusIndicator';
import { AIPrompt } from '~/components/Workspace/AIPrompt';
import { WorkflowTimeline } from '~/components/Workspace/WorkflowTimeline';
import type { Project, WorkflowStep } from '~/types';

function renderWithRouter(element: ReactElement) {
  return render(<MemoryRouter>{element}</MemoryRouter>);
}

const sampleProject: Project & { lastWorkflowStatus?: string } = {
  branch: 'main',
  createdAt: new Date('2025-01-01T00:00:00Z'),
  description: 'Demo project',
  id: '11111111-1111-4111-8111-111111111111',
  lastWorkflowStatus: 'completed',
  name: 'Alpha Project',
  repositoryUrl: 'https://github.com/example/alpha',
  settings: {
    aiProvider: 'nvidia',
    gitIntegration: {
      defaultBranch: 'main',
      provider: 'github',
      repositoryUrl: 'https://github.com/example/alpha',
    },
    sandboxConfig: {
      memoryMb: 4096,
      runtime: 'node22',
      timeoutMinutes: 30,
      vcpus: 2,
    },
  },
  updatedAt: new Date(),
};

const steps: WorkflowStep[] = [
  { id: '1', inputs: {}, name: 'Plan', retryCount: 0, status: 'completed' },
  { id: '2', inputs: {}, name: 'Implement', retryCount: 0, status: 'running' },
  { id: '3', inputs: {}, name: 'Verify', retryCount: 0, status: 'failed' },
];

describe('Button', () => {
  it('renders with correct text and variant classes', () => {
    render(<Button variant="primary">Launch</Button>);
    expect(screen.getByRole('button', { name: 'Launch' })).toHaveClass(
      'bg-indigo-600',
    );
  });
});

describe('Badge', () => {
  it('shows the success color', () => {
    render(<Badge variant="success">ready</Badge>);
    expect(screen.getByText('ready')).toHaveClass('text-emerald-200');
  });

  it('shows the error color', () => {
    render(<Badge variant="error">failed</Badge>);
    expect(screen.getByText('failed')).toHaveClass('text-red-200');
  });
});

describe('StatusIndicator', () => {
  it('shows the provided label', () => {
    render(<StatusIndicator label="Connected" status="connected" />);
    expect(screen.getByText('Connected')).toBeInTheDocument();
  });
});

describe('ProjectGrid', () => {
  it('renders empty state when no projects', () => {
    renderWithRouter(<ProjectGrid projects={[]} />);
    expect(screen.getByText('No projects yet.')).toBeInTheDocument();
  });

  it('renders project cards with correct names', () => {
    renderWithRouter(
      <ProjectGrid
        projects={[
          sampleProject,
          {
            ...sampleProject,
            id: '22222222-2222-4222-8222-222222222222',
            name: 'Beta Project',
          },
        ]}
      />,
    );
    expect(screen.getByText('Alpha Project')).toBeInTheDocument();
    expect(screen.getByText('Beta Project')).toBeInTheDocument();
  });
});

describe('ActivityFeed', () => {
  it('renders empty state', () => {
    renderWithRouter(<ActivityFeed activities={[]} />);
    expect(screen.getByText('No recent activity.')).toBeInTheDocument();
  });
});

describe('AIPrompt', () => {
  it('disables submit when prompt is too short', () => {
    render(<AIPrompt projectId="11111111-1111-4111-8111-111111111111" />);
    expect(screen.getByRole('button', { name: 'Submit task' })).toBeDisabled();
  });
});

describe('WorkflowTimeline', () => {
  it('renders step statuses correctly', () => {
    render(<WorkflowTimeline initialSteps={steps} />);
    expect(screen.getByText('completed')).toBeInTheDocument();
    expect(screen.getByText('running')).toBeInTheDocument();
    expect(screen.getByText('failed')).toBeInTheDocument();
  });
});
