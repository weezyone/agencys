import { afterEach, describe, expect, it, vi } from 'vitest';

const originalRedisUrl = process.env.REDIS_URL;
const originalNodeEnv = process.env.NODE_ENV;

function restoreEnv() {
  if (originalRedisUrl === undefined) {
    delete process.env.REDIS_URL;
  } else {
    process.env.REDIS_URL = originalRedisUrl;
  }

  if (originalNodeEnv === undefined) {
    delete process.env.NODE_ENV;
  } else {
    process.env.NODE_ENV = originalNodeEnv;
  }
}

afterEach(() => {
  restoreEnv();
  vi.doUnmock('redis');
  vi.resetModules();
});

describe('Redis KV store', () => {
  it('uses REDIS_URL when configured outside tests', async () => {
    process.env.REDIS_URL = 'redis://localhost:6379';
    process.env.NODE_ENV = 'development';

    const client = {
      isOpen: false,
      connect: vi.fn(async () => {
        client.isOpen = true;
      }),
      del: vi.fn(),
      expire: vi.fn(),
      get: vi.fn(async () => '{"ok":true}'),
      hDel: vi.fn(),
      hGet: vi.fn(),
      hGetAll: vi.fn(),
      hSet: vi.fn(),
      keys: vi.fn(),
      set: vi.fn(),
    };
    const createClient = vi.fn(() => client);

    vi.doMock('redis', () => ({ createClient }));
    vi.resetModules();

    const { kv } = await import('../lib/kv.server');

    await kv.set('example', { ok: true }, { ex: 30 });
    await expect(kv.get<{ ok: boolean }>('example')).resolves.toEqual({ ok: true });

    expect(createClient).toHaveBeenCalledWith({ url: 'redis://localhost:6379' });
    expect(client.connect).toHaveBeenCalledTimes(1);
    expect(client.set).toHaveBeenCalledWith('example', '{"ok":true}', { EX: 30 });
    expect(client.get).toHaveBeenCalledWith('example');
  });
});
