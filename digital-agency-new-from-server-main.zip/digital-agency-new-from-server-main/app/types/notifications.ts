export const NotificationType = {
  ARTIFACT_READY: 'ARTIFACT_READY',
  SANDBOX_TIMEOUT: 'SANDBOX_TIMEOUT',
  SYSTEM: 'SYSTEM',
  TEAM_INVITE: 'TEAM_INVITE',
  WORKFLOW_COMPLETE: 'WORKFLOW_COMPLETE',
  WORKFLOW_FAILED: 'WORKFLOW_FAILED',
} as const;

export const notificationTypes = Object.values(NotificationType);

export type NotificationType =
  (typeof NotificationType)[keyof typeof NotificationType];

export interface Notification {
  id: string;
  userId: string;
  type: NotificationType;
  title: string;
  body: string;
  metadata: Record<string, unknown>;
  readAt: string | null;
  createdAt: string;
}

export interface NotificationPreferences {
  id?: string;
  userId?: string;
  workflowComplete: boolean;
  workflowFailed: boolean;
  sandboxTimeout: boolean;
  teamInvite: boolean;
  artifactReady: boolean;
  emailEnabled: boolean;
  webhookUrl: string | null;
}

export function normalizeNotification(value: unknown): Notification | null {
  if (!value || typeof value !== 'object') {
    return null;
  }

  const raw = value as Record<string, unknown>;
  if (
    typeof raw.id !== 'string' ||
    typeof raw.userId !== 'string' ||
    typeof raw.title !== 'string' ||
    typeof raw.body !== 'string' ||
    typeof raw.createdAt !== 'string' ||
    typeof raw.type !== 'string' ||
    !notificationTypes.includes(raw.type as NotificationType)
  ) {
    return null;
  }

  return {
    body: raw.body,
    createdAt: raw.createdAt,
    id: raw.id,
    metadata:
      raw.metadata && typeof raw.metadata === 'object' && !Array.isArray(raw.metadata)
        ? (raw.metadata as Record<string, unknown>)
        : {},
    readAt: typeof raw.readAt === 'string' ? raw.readAt : null,
    title: raw.title,
    type: raw.type as NotificationType,
    userId: raw.userId,
  };
}

export function formatNotificationRelativeTime(value: Date | string): string {
  const date = value instanceof Date ? value : new Date(value);
  const diffMs = Date.now() - date.getTime();
  const diffMinutes = Math.floor(diffMs / 60_000);
  const diffHours = Math.floor(diffMinutes / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffMinutes < 1) {
    return 'just now';
  }

  if (diffMinutes < 60) {
    return `${diffMinutes} minute${diffMinutes === 1 ? '' : 's'} ago`;
  }

  if (diffHours < 24) {
    return `${diffHours} hour${diffHours === 1 ? '' : 's'} ago`;
  }

  return `${diffDays} day${diffDays === 1 ? '' : 's'} ago`;
}

export function getNotificationDestination(notification: Notification):
  | { type: 'internal'; to: string }
  | { type: 'external'; to: string }
  | null {
  const metadata = notification.metadata;

  if (typeof metadata.projectId === 'string') {
    return { to: `/workspace/${metadata.projectId}`, type: 'internal' };
  }

  if (typeof metadata.downloadUrl === 'string' && metadata.downloadUrl.length > 0) {
    return { to: metadata.downloadUrl, type: 'external' };
  }

  return null;
}
