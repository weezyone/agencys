export interface GitBranch {
  name: string;
  sha?: string;
  protected?: boolean;
}

export interface GitCommit {
  sha: string;
  message: string;
  author: string;
  authoredAt: Date;
}

export interface PullRequestPreview {
  id: string;
  title: string;
  branch: string;
  status: 'draft' | 'open' | 'merged';
  url?: string;
}
