export interface Project {
  id: string;
  name: string;
  description?: string;
  repositoryUrl?: string;
  branch: string;
  settings: ProjectSettings;
  createdAt: Date;
  updatedAt: Date;
}

export interface ProjectSettings {
  aiProvider:
    | 'claude'
    | 'codex'
    | 'openrouter'
    | 'huggingface'
    | 'nvidia'
    | 'both';
  sandboxConfig: SandboxConfiguration;
  gitIntegration: GitIntegrationSettings;
}

export interface SandboxConfiguration {
  vcpus: number;
  memoryMb: number;
  timeoutMinutes: number;
  runtime: 'node22' | 'python3.13';
}

export interface GitIntegrationSettings {
  provider: 'github' | 'gitlab';
  repositoryUrl?: string;
  defaultBranch: string;
}

export interface WorkflowState {
  id: string;
  projectId: string;
  status: 'initializing' | 'running' | 'suspended' | 'completed' | 'failed';
  currentStep: number;
  steps: WorkflowStep[];
  artifacts: ArtifactManifest[];
  logs: LogEntry[];
}

export interface WorkflowStep {
  id: string;
  name: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  inputs: Record<string, unknown>;
  outputs?: Record<string, unknown>;
  startedAt?: Date;
  completedAt?: Date;
  retryCount: number;
}

export interface ArtifactManifest {
  id: string;
  name: string;
  filePath: string;
  fileSize: number;
  checksum: string;
  downloadUrl?: string;
  expiresAt?: Date;
  createdAt: Date;
}

export interface LogEntry {
  timestamp: Date;
  level: 'debug' | 'info' | 'warn' | 'error';
  message: string;
  workflowId?: string;
  sandboxId?: string;
}

export interface SandboxInfo {
  id: string;
  sandboxId: string;
  status: 'provisioning' | 'ready' | 'running' | 'terminated' | 'failed';
  domain?: string;
  configuration: SandboxConfiguration;
  createdAt: Date;
}

export * from './sandbox';
export * from './workflow';
export * from './git';
