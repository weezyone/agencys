import type {
  ArtifactManifest,
  LogEntry,
  WorkflowState,
  WorkflowStep,
} from './index';

export interface WorkflowDefinition {
  id: string;
  name: string;
  description: string;
  steps: WorkflowStep[];
}

export interface WorkflowSummary extends Pick<
  WorkflowState,
  'id' | 'projectId' | 'status'
> {
  name: string;
  lastUpdatedAt: Date;
}

export interface WorkflowEvent {
  id: string;
  workflowId: string;
  type: 'status-change' | 'log' | 'artifact';
  createdAt: Date;
  payload: WorkflowStep | LogEntry | ArtifactManifest;
}
