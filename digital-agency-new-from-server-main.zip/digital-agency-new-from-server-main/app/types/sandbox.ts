import type { SandboxConfiguration, SandboxInfo } from './index';

export interface SandboxFileNode {
  id: string;
  name: string;
  path: string;
  type: 'file' | 'directory';
  children?: SandboxFileNode[];
}

export interface SandboxCommand {
  id: string;
  command: string;
  status: 'queued' | 'running' | 'completed' | 'failed';
  startedAt?: Date;
  completedAt?: Date;
}

export type SandboxRuntime = SandboxConfiguration['runtime'];
export type SandboxSnapshot = Pick<
  SandboxInfo,
  'id' | 'sandboxId' | 'status' | 'domain'
>;
