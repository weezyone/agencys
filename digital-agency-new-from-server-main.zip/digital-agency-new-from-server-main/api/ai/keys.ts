import { encryptApiKey } from '~/lib/ai.server';
import kv from '~/lib/kv.server';
import { saveApiKeySchema } from '~/lib/schemas.server';
import { requireAuth } from '~/lib/session.server';

const SESSION_SECRET =
  process.env.SESSION_SECRET || 'dev-secret-change-in-production';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

async function authenticate(request: Request) {
  try {
    return await requireAuth(request);
  } catch {
    return null;
  }
}

export default async function handler(request: Request) {
  if (request.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  const session = await authenticate(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  const payload = await request.json().catch(() => ({}));
  const parsed = saveApiKeySchema.safeParse(payload);
  if (!parsed.success) {
    return errorResponse(
      'Invalid API key payload',
      400,
      parsed.error.flatten(),
    );
  }

  await kv.set(
    `user:${session.userId}:apikey:${parsed.data.provider}`,
    encryptApiKey(parsed.data.apiKey, SESSION_SECRET),
  );

  return Response.json({ success: true });
}
