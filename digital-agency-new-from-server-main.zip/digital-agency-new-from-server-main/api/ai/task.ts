import {
  buildCodingSystemPrompt,
  checkProviderRateLimit,
  executeAgentInSandbox,
  generateAIResponse,
  PROVIDER_DEFINITIONS,
  streamAIResponse,
  validateProviderConfig,
  type AIProvider,
} from '~/lib/ai.server';
import { trackEvent } from '~/lib/analytics.server';
import { requireAiQuota } from '~/lib/billing-middleware.server';
import { aiTaskSchema } from '~/lib/schemas.server';
import { requireAuth } from '~/lib/session.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

async function authenticate(request: Request) {
  try {
    return await requireAuth(request);
  } catch {
    return null;
  }
}

function buildTaskSystemPrompt(
  taskType: 'generate' | 'refactor' | 'test' | 'debug',
  contextFiles?: Array<{ path: string; content: string }>,
) {
  const basePrompt = buildCodingSystemPrompt(contextFiles);
  const taskInstructions: Record<typeof taskType, string> = {
    debug:
      'Focus on identifying the root cause, proposing the safest fix, and calling out verification steps.',
    generate:
      'Focus on producing complete implementation details that are ready to apply.',
    refactor:
      'Focus on preserving behavior while improving structure, clarity, and maintainability.',
    test: 'Focus on reliable automated tests, edge cases, and reproducible verification steps.',
  };

  return `${basePrompt}\n\nTask type: ${taskType}. ${taskInstructions[taskType]}`;
}

function getProviderModel(provider: AIProvider) {
  return PROVIDER_DEFINITIONS[provider].model;
}

function buildAiAnalyticsMetadata(
  provider: AIProvider,
  model: string,
  taskType: 'generate' | 'refactor' | 'test' | 'debug',
  usage: { promptTokens?: number; completionTokens?: number },
) {
  return {
    completionTokens: usage.completionTokens ?? 0,
    model,
    promptTokens: usage.promptTokens ?? 0,
    provider,
    taskType,
  };
}

function trackStreamedAiRequest(
  stream: ReadableStream,
  analytics: {
    provider: AIProvider;
    taskType: 'generate' | 'refactor' | 'test' | 'debug';
    userId: string;
  },
) {
  const reader = stream.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let tracked = false;

  return new ReadableStream({
    async cancel(reason) {
      await reader.cancel(reason);
    },
    async start(controller) {
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) {
            break;
          }

          if (!value) {
            continue;
          }

          controller.enqueue(value);
          buffer += decoder.decode(value, { stream: true });

          let boundaryIndex = buffer.indexOf('\n\n');
          while (boundaryIndex >= 0) {
            const eventChunk = buffer.slice(0, boundaryIndex);
            buffer = buffer.slice(boundaryIndex + 2);

            for (const line of eventChunk.split('\n')) {
              if (!line.startsWith('data: ')) {
                continue;
              }

              const rawPayload = line.slice(6).trim();
              if (!rawPayload || rawPayload === '[DONE]') {
                continue;
              }

              try {
                const payload = JSON.parse(rawPayload) as {
                  type?: string;
                  usage?: { completionTokens?: number; promptTokens?: number };
                };
                if (payload.type === 'complete' && !tracked) {
                  tracked = true;
                  void trackEvent(
                    analytics.userId,
                    'ai.request',
                    buildAiAnalyticsMetadata(
                      analytics.provider,
                      getProviderModel(analytics.provider),
                      analytics.taskType,
                      payload.usage ?? {},
                    ),
                  );
                }
              } catch {
                // Ignore malformed SSE payloads.
              }
            }

            boundaryIndex = buffer.indexOf('\n\n');
          }
        }
      } finally {
        controller.close();
        reader.releaseLock();
      }
    },
  });
}

export default async function handler(request: Request) {
  if (request.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  const session = await authenticate(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  const payload = await request.json().catch(() => ({}));
  const parsed = aiTaskSchema.safeParse(payload);
  if (!parsed.success) {
    return errorResponse(
      'Invalid AI task payload',
      400,
      parsed.error.flatten(),
    );
  }

  try {
    await requireAiQuota(session.userId);
  } catch (error) {
    if (error instanceof Response) {
      return error;
    }

    return errorResponse(
      'Unable to process AI task',
      500,
      error instanceof Error ? error.message : undefined,
    );
  }

  const rateLimit = await checkProviderRateLimit(
    session.userId,
    parsed.data.provider,
  );
  if (!rateLimit.allowed) {
    return errorResponse('Rate limit exceeded', 429, {
      remaining: rateLimit.remaining,
      resetAt: rateLimit.resetAt.toISOString(),
    });
  }

  const providerConfig = validateProviderConfig(parsed.data.provider);
  if (!providerConfig.valid) {
    return errorResponse(
      providerConfig.error ?? 'Provider is not configured',
      503,
    );
  }

  const url = new URL(request.url);
  const shouldStream =
    parsed.data.stream || url.searchParams.get('stream') === 'true';
  const systemPrompt = buildTaskSystemPrompt(
    parsed.data.taskType,
    parsed.data.contextFiles,
  );

  try {
    if (parsed.data.sandboxId) {
      const sandboxResult = await executeAgentInSandbox(
        parsed.data.sandboxId,
        parsed.data.provider,
        parsed.data.prompt,
      );
      const result = {
        content: sandboxResult.output,
        finishReason: sandboxResult.exitCode === 0 ? 'stop' : 'error',
        model: getProviderModel(parsed.data.provider),
        provider: parsed.data.provider,
        usage: {
          completionTokens: 0,
          promptTokens: 0,
          totalTokens: 0,
        },
      };
      void trackEvent(
        session.userId,
        'ai.request',
        buildAiAnalyticsMetadata(
          parsed.data.provider,
          result.model,
          parsed.data.taskType,
          result.usage,
        ),
      );

      return Response.json({
        exitCode: sandboxResult.exitCode,
        result,
      });
    }

    if (shouldStream) {
      const stream = await streamAIResponse({
        contextFiles: parsed.data.contextFiles,
        prompt: parsed.data.prompt,
        provider: parsed.data.provider,
        systemPrompt,
      });

      return new Response(
        trackStreamedAiRequest(stream, {
          provider: parsed.data.provider,
          taskType: parsed.data.taskType,
          userId: session.userId,
        }),
        {
        headers: {
          'Cache-Control': 'no-cache',
          Connection: 'keep-alive',
          'Content-Type': 'text/event-stream',
        },
      });
    }

    const result = await generateAIResponse({
      contextFiles: parsed.data.contextFiles,
      prompt: parsed.data.prompt,
      provider: parsed.data.provider,
      systemPrompt,
    });

    void trackEvent(
      session.userId,
      'ai.request',
      buildAiAnalyticsMetadata(
        parsed.data.provider,
        result.model,
        parsed.data.taskType,
        result.usage,
      ),
    );

    return Response.json({ result });
  } catch (error) {
    return errorResponse(
      'Unable to process AI task',
      500,
      error instanceof Error ? error.message : undefined,
    );
  }
}
