import { createTemplate as createTemplateRecord } from '../../app/lib/templates.server';
import { createTemplateSchema } from '../../app/lib/schemas.server';
import { requireAuth } from '../../app/lib/session.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

async function requireApiAuth(request: Request) {
  try {
    return await requireAuth(request);
  } catch (error) {
    if (error instanceof Response) {
      return null;
    }

    throw error;
  }
}

export default async function handler(request: Request) {
  if (request.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  const session = await requireApiAuth(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  const payload = await request.json().catch(() => ({}));
  const parsed = createTemplateSchema.safeParse(payload);
  if (!parsed.success) {
    return errorResponse('Invalid template payload', 400, parsed.error.flatten());
  }

  try {
    const template = await createTemplateRecord(session.userId, parsed.data);
    return Response.json({ template });
  } catch (error) {
    return errorResponse(
      'Unable to create template',
      500,
      error instanceof Error ? error.message : undefined,
    );
  }
}
