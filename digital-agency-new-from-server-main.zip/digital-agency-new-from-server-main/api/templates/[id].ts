import { getTemplateById } from '../../app/lib/templates.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

function getTemplateId(request: Request) {
  return new URL(request.url).pathname.split('/').filter(Boolean).pop() ?? '';
}

export default async function handler(request: Request) {
  if (request.method !== 'GET') {
    return errorResponse('Method not allowed', 405);
  }

  const templateId = getTemplateId(request);
  if (!templateId) {
    return errorResponse('Template not found', 404);
  }

  try {
    const template = await getTemplateById(templateId);
    if (!template) {
      return errorResponse('Template not found', 404);
    }

    return Response.json({ template });
  } catch (error) {
    return errorResponse(
      'Unable to fetch template',
      500,
      error instanceof Error ? error.message : undefined,
    );
  }
}
