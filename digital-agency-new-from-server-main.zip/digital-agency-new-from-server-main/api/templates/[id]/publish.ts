import { createTemplateSchema } from '../../../app/lib/schemas.server';
import { publishProjectAsTemplate } from '../../../app/lib/templates.server';
import { requireAuth } from '../../../app/lib/session.server';

const publishTemplateSchema = createTemplateSchema.pick({
  name: true,
  description: true,
  category: true,
  tags: true,
  aiPrompt: true,
});

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

async function requireApiAuth(request: Request) {
  try {
    return await requireAuth(request);
  } catch (error) {
    if (error instanceof Response) {
      return null;
    }

    throw error;
  }
}

function getProjectId(request: Request) {
  const segments = new URL(request.url).pathname.split('/').filter(Boolean);
  return segments.at(-2) ?? '';
}

export default async function handler(request: Request) {
  if (request.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  const session = await requireApiAuth(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  const projectId = getProjectId(request);
  if (!projectId) {
    return errorResponse('Project not found', 404);
  }

  const payload = await request.json().catch(() => ({}));
  const parsed = publishTemplateSchema.safeParse(payload);
  if (!parsed.success) {
    return errorResponse('Invalid template payload', 400, parsed.error.flatten());
  }

  try {
    const template = await publishProjectAsTemplate(
      projectId,
      session.userId,
      parsed.data,
    );
    return Response.json({ template });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unable to publish template';
    return errorResponse(message, message === 'Project not found' ? 404 : 500);
  }
}
