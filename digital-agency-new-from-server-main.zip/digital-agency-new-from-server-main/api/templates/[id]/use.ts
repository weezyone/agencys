import { useTemplate as useTemplateById } from '../../../app/lib/templates.server';
import { useTemplateSchema } from '../../../app/lib/schemas.server';
import { requireAuth } from '../../../app/lib/session.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

async function requireApiAuth(request: Request) {
  try {
    return await requireAuth(request);
  } catch (error) {
    if (error instanceof Response) {
      return null;
    }

    throw error;
  }
}

function getTemplateId(request: Request) {
  const segments = new URL(request.url).pathname.split('/').filter(Boolean);
  return segments.at(-2) ?? '';
}

export default async function handler(request: Request) {
  if (request.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  const session = await requireApiAuth(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  const templateId = getTemplateId(request);
  if (!templateId) {
    return errorResponse('Template not found', 404);
  }

  const payload = await request.json().catch(() => ({}));
  const parsed = useTemplateSchema.safeParse(payload);
  if (!parsed.success) {
    return errorResponse('Invalid template usage payload', 400, parsed.error.flatten());
  }

  try {
    const result = await useTemplateById(
      templateId,
      session.userId,
      parsed.data.projectName,
    );
    return Response.json(result);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unable to use template';
    return errorResponse(message, message === 'Template not found' ? 404 : 500);
  }
}
