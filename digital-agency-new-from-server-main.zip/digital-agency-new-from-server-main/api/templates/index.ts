import {
  isTemplateStorageUnavailable,
  listTemplateCategories,
  listTemplates,
} from '../../app/lib/templates.server';
import { templateSearchSchema } from '../../app/lib/schemas.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

export default async function handler(request: Request) {
  if (request.method !== 'GET') {
    return errorResponse('Method not allowed', 405);
  }

  const url = new URL(request.url);
  const parsed = templateSearchSchema.safeParse({
    category: url.searchParams.get('category') ?? undefined,
    search: url.searchParams.get('search') ?? undefined,
    limit: url.searchParams.get('limit') ?? undefined,
    offset: url.searchParams.get('offset') ?? undefined,
  });

  if (!parsed.success) {
    return errorResponse('Invalid query parameters', 400, parsed.error.flatten());
  }

  try {
    const [{ templates, total }, categories] = await Promise.all([
      listTemplates(parsed.data),
      listTemplateCategories(),
    ]);

    return Response.json({ templates, total, categories });
  } catch (error) {
    if (isTemplateStorageUnavailable(error)) {
      return Response.json({ categories: [], templates: [], total: 0 });
    }

    return errorResponse(
      'Unable to list templates',
      500,
      error instanceof Error ? error.message : undefined,
    );
  }
}
