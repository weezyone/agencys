import {
  BUILT_IN_TEMPLATES,
  seedBuiltInTemplates,
} from '../../app/lib/templates.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

export default async function handler(request: Request) {
  if (request.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  const adminSecret = request.headers.get('ADMIN_SECRET');
  if (!process.env.ADMIN_SECRET || adminSecret !== process.env.ADMIN_SECRET) {
    return errorResponse('Forbidden', 403);
  }

  try {
    await seedBuiltInTemplates();
    return Response.json({ seeded: BUILT_IN_TEMPLATES.length });
  } catch (error) {
    return errorResponse(
      'Unable to seed templates',
      500,
      error instanceof Error ? error.message : undefined,
    );
  }
}
