import { z } from 'zod';
import {
  getPresence,
  getUserColor,
  heartbeat,
  publishPresenceUpdate,
  type PresenceTab,
} from '../../app/lib/presence.server';
import { requireAuth } from '../../app/lib/session.server';

const heartbeatSchema = z.object({
  activeTab: z.enum(['ai', 'git', 'files', 'downloads', 'logs']).optional(),
  cursor: z
    .object({
      x: z.number(),
      y: z.number(),
    })
    .nullable()
    .optional(),
  projectId: z.string().min(1),
});

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

async function authenticate(request: Request) {
  try {
    return await requireAuth(request);
  } catch {
    return null;
  }
}

export default async function handler(request: Request) {
  if (request.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  const session = await authenticate(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  const payload = await request.json().catch(() => ({}));
  const parsed = heartbeatSchema.safeParse(payload);
  if (!parsed.success) {
    return errorResponse('Invalid presence payload', 400, parsed.error.flatten());
  }

  const activeTab = (parsed.data.activeTab ?? 'ai') as PresenceTab;
  await heartbeat(parsed.data.projectId, {
    activeTab,
    color: getUserColor(session.userId),
    cursor: parsed.data.cursor ?? null,
    lastSeen: Date.now(),
    name: session.name,
    userId: session.userId,
  });
  await publishPresenceUpdate(parsed.data.projectId);

  return Response.json({ users: await getPresence(parsed.data.projectId) });
}
