import type { AuditLog, Prisma } from '@prisma/client';

export function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

export function handleAdminError(error: unknown, fallbackMessage: string) {
  if (error instanceof Response) {
    return error;
  }

  return errorResponse(
    fallbackMessage,
    500,
    error instanceof Error ? error.message : undefined,
  );
}

export function parseInteger(value: string | null, fallback: number, minimum = 0) {
  const parsed = Number(value ?? '');
  if (!Number.isFinite(parsed)) {
    return fallback;
  }

  return Math.max(minimum, Math.trunc(parsed));
}

export function parseUserIdFromPath(request: Request) {
  const parts = new URL(request.url).pathname.split('/').filter(Boolean);
  const usersIndex = parts.indexOf('users');
  return usersIndex >= 0 ? parts[usersIndex + 1] ?? '' : '';
}

export async function parseJsonBody<T>(request: Request): Promise<T> {
  return request.json().catch(() => ({} as T));
}

export function serializeAuditLog(log: AuditLog) {
  return {
    ...log,
    createdAt: log.createdAt.toISOString(),
  } satisfies Prisma.JsonObject;
}

export function serializeAdminUser<T extends { createdAt: Date; lastActiveAt: Date | null }>(
  user: T,
) {
  return {
    ...user,
    createdAt: user.createdAt.toISOString(),
    lastActiveAt: user.lastActiveAt?.toISOString() ?? null,
  };
}
