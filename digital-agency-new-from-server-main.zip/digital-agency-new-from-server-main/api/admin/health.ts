import { getSystemHealth, requireAdmin } from '~/lib/admin.server';
import { errorResponse, handleAdminError } from './_shared';

export default async function handler(request: Request) {
  if (request.method !== 'GET') {
    return errorResponse('Method not allowed', 405);
  }

  try {
    await requireAdmin(request);
    return Response.json({ health: await getSystemHealth() });
  } catch (error) {
    return handleAdminError(error, 'Unable to load system health');
  }
}
