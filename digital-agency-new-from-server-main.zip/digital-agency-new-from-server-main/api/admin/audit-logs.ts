import { getAuditLogs, requireAdmin } from '~/lib/admin.server';
import { errorResponse, handleAdminError, parseInteger, serializeAuditLog } from './_shared';

export default async function handler(request: Request) {
  if (request.method !== 'GET') {
    return errorResponse('Method not allowed', 405);
  }

  try {
    await requireAdmin(request);

    const url = new URL(request.url);
    const result = await getAuditLogs({
      action: url.searchParams.get('action') ?? undefined,
      limit: parseInteger(url.searchParams.get('limit'), 50, 1),
      offset: parseInteger(url.searchParams.get('offset'), 0, 0),
      userId: url.searchParams.get('userId') ?? undefined,
    });

    return Response.json({
      logs: result.logs.map(serializeAuditLog),
      total: result.total,
    });
  } catch (error) {
    return handleAdminError(error, 'Unable to load audit logs');
  }
}
