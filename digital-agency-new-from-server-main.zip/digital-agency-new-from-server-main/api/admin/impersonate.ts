import { createImpersonationToken, requireAdmin } from '~/lib/admin.server';
import { errorResponse, handleAdminError, parseJsonBody } from './_shared';

export default async function handler(request: Request) {
  if (request.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  const body = await parseJsonBody<{ userId?: string }>(request);
  if (!body.userId?.trim()) {
    return errorResponse('userId is required', 400);
  }

  try {
    const admin = await requireAdmin(request);
    const token = await createImpersonationToken(body.userId, admin.userId);
    return Response.json({
      expiresAt: new Date(Date.now() + 60 * 60 * 1000).toISOString(),
      token,
    });
  } catch (error) {
    return handleAdminError(error, 'Unable to create impersonation token');
  }
}
