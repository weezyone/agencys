import { getPlatformStats, requireAdmin } from '~/lib/admin.server';
import { errorResponse, handleAdminError } from './_shared';

export default async function handler(request: Request) {
  if (request.method !== 'GET') {
    return errorResponse('Method not allowed', 405);
  }

  try {
    await requireAdmin(request);
    const stats = await getPlatformStats();
    return Response.json({ generatedAt: new Date().toISOString(), stats });
  } catch (error) {
    return handleAdminError(error, 'Unable to load admin stats');
  }
}
