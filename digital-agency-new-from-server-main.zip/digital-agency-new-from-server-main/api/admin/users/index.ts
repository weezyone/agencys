import { listUsers, requireAdmin } from '~/lib/admin.server';
import { errorResponse, handleAdminError, parseInteger, serializeAdminUser } from '../_shared';

export default async function handler(request: Request) {
  if (request.method !== 'GET') {
    return errorResponse('Method not allowed', 405);
  }

  try {
    await requireAdmin(request);

    const url = new URL(request.url);
    const sortBy = url.searchParams.get('sortBy');
    const parsedSortBy =
      sortBy === 'projectCount' || sortBy === 'lastActive' || sortBy === 'createdAt'
        ? sortBy
        : 'createdAt';

    const result = await listUsers({
      limit: parseInteger(url.searchParams.get('limit'), 20, 1),
      offset: parseInteger(url.searchParams.get('offset'), 0, 0),
      search: url.searchParams.get('search') ?? undefined,
      sortBy: parsedSortBy,
    });

    return Response.json({
      total: result.total,
      users: result.users.map(serializeAdminUser),
    });
  } catch (error) {
    return handleAdminError(error, 'Unable to list users');
  }
}
