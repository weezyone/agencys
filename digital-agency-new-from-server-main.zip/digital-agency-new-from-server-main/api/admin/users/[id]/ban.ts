import { banUser, requireAdmin } from '~/lib/admin.server';
import { errorResponse, handleAdminError, parseJsonBody, parseUserIdFromPath } from '../../_shared';

export default async function handler(request: Request) {
  if (request.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  const targetUserId = parseUserIdFromPath(request);
  if (!targetUserId) {
    return errorResponse('User not found', 404);
  }

  const body = await parseJsonBody<{ reason?: string }>(request);
  if (!body.reason?.trim()) {
    return errorResponse('Reason is required', 400);
  }

  try {
    const admin = await requireAdmin(request);
    await banUser(targetUserId, admin.userId, body.reason);
    return Response.json({ success: true });
  } catch (error) {
    return handleAdminError(error, 'Unable to ban user');
  }
}
