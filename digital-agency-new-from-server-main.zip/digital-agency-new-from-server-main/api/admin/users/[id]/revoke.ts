import { requireAdmin, revokeAdmin } from '~/lib/admin.server';
import { errorResponse, handleAdminError, parseUserIdFromPath } from '../../_shared';

export default async function handler(request: Request) {
  if (request.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  const targetUserId = parseUserIdFromPath(request);
  if (!targetUserId) {
    return errorResponse('User not found', 404);
  }

  try {
    const admin = await requireAdmin(request);
    await revokeAdmin(targetUserId, admin.userId);
    return Response.json({ success: true });
  } catch (error) {
    return handleAdminError(error, 'Unable to revoke admin access');
  }
}
