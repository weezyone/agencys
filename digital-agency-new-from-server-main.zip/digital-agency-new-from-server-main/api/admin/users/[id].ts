import { getUserDetails, requireAdmin } from '~/lib/admin.server';
import { errorResponse, handleAdminError, parseUserIdFromPath, serializeAdminUser, serializeAuditLog } from '../_shared';

export default async function handler(request: Request) {
  if (request.method !== 'GET') {
    return errorResponse('Method not allowed', 405);
  }

  const userId = parseUserIdFromPath(request);
  if (!userId) {
    return errorResponse('User not found', 404);
  }

  try {
    await requireAdmin(request);
    const user = await getUserDetails(userId);
    return Response.json({
      user: {
        ...serializeAdminUser(user),
        projects: user.projects.map((project) => ({
          ...project,
          createdAt: project.createdAt.toISOString(),
        })),
        recentAuditLogs: user.recentAuditLogs.map(serializeAuditLog),
      },
    });
  } catch (error) {
    return handleAdminError(error, 'Unable to load user details');
  }
}
