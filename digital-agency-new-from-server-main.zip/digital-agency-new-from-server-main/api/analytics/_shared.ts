import { requireAuth } from '~/lib/session.server';

const ALLOWED_DAYS = new Set([7, 30, 90]);

export function errorResponse(message: string, status: number) {
  return Response.json({ error: message }, { status });
}

export async function authenticate(request: Request) {
  try {
    return await requireAuth(request);
  } catch {
    return null;
  }
}

export function parseDays(request: Request) {
  const raw = new URL(request.url).searchParams.get('days');
  if (!raw) {
    return 30;
  }

  const days = Number(raw);
  if (!Number.isInteger(days) || !ALLOWED_DAYS.has(days)) {
    throw errorResponse('Invalid days value. Expected 7, 30, or 90.', 400);
  }

  return days;
}
