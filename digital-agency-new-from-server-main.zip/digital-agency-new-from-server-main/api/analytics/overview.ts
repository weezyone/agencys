import { getOverviewMetrics } from '~/lib/analytics.server';
import { authenticate, errorResponse, parseDays } from './_shared';

export default async function handler(request: Request) {
  if (request.method !== 'GET') {
    return errorResponse('Method not allowed', 405);
  }

  const session = await authenticate(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  try {
    const days = parseDays(request);
    const metrics = await getOverviewMetrics(session.userId, days);

    return Response.json({
      costEstimate: 'approximate',
      generatedAt: new Date().toISOString(),
      metrics,
    });
  } catch (error) {
    if (error instanceof Response) {
      return error;
    }

    return errorResponse('Unable to load analytics overview', 500);
  }
}
