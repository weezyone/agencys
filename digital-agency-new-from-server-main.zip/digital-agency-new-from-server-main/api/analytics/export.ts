import {
  exportMetricsCsv,
  getOverviewMetrics,
  getWorkflowTimeSeries,
} from '~/lib/analytics.server';
import { authenticate, errorResponse, parseDays } from './_shared';

export default async function handler(request: Request) {
  if (request.method !== 'GET') {
    return errorResponse('Method not allowed', 405);
  }

  const session = await authenticate(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  try {
    const url = new URL(request.url);
    const days = parseDays(request);
    const format = url.searchParams.get('format') ?? 'csv';

    if (format !== 'csv') {
      return errorResponse('Invalid export format. Expected csv.', 400);
    }

    const [metrics, workflowSeries] = await Promise.all([
      getOverviewMetrics(session.userId, days),
      getWorkflowTimeSeries(session.userId, days),
    ]);
    const csv = exportMetricsCsv(metrics, workflowSeries.total);
    const date = new Date().toISOString().slice(0, 10);

    return new Response(csv, {
      headers: {
        'Content-Disposition': `attachment; filename="analytics-${date}.csv"`,
        'Content-Type': 'text/csv; charset=utf-8',
      },
      status: 200,
    });
  } catch (error) {
    if (error instanceof Response) {
      return error;
    }

    return errorResponse('Unable to export analytics', 500);
  }
}
