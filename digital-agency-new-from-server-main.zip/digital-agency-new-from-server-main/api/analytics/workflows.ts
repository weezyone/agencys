import {
  getRecentErrors,
  getTopProjects,
  getWorkflowTimeSeries,
} from '~/lib/analytics.server';
import { authenticate, errorResponse, parseDays } from './_shared';

export default async function handler(request: Request) {
  if (request.method !== 'GET') {
    return errorResponse('Method not allowed', 405);
  }

  const session = await authenticate(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  try {
    const days = parseDays(request);
    const [recentErrors, timeSeries, topProjects] = await Promise.all([
      getRecentErrors(session.userId),
      getWorkflowTimeSeries(session.userId, days),
      getTopProjects(session.userId, days),
    ]);

    return Response.json({ recentErrors, timeSeries, topProjects });
  } catch (error) {
    if (error instanceof Response) {
      return error;
    }

    return errorResponse('Unable to load workflow analytics', 500);
  }
}
