import {
  getAiUsageSummary,
  getAiUsageTimeSeries,
} from '~/lib/analytics.server';
import { authenticate, errorResponse, parseDays } from './_shared';

export default async function handler(request: Request) {
  if (request.method !== 'GET') {
    return errorResponse('Method not allowed', 405);
  }

  const session = await authenticate(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  try {
    const days = parseDays(request);
    const [summary, timeSeries] = await Promise.all([
      getAiUsageSummary(session.userId, days),
      getAiUsageTimeSeries(session.userId, days),
    ]);

    return Response.json({
      estimatedCost: summary.estimatedCostUsd,
      estimatedCostNote: 'Approximate AI cost estimate based on provider list pricing.',
      timeSeries,
      totalTokens: summary.totalTokens,
    });
  } catch (error) {
    if (error instanceof Response) {
      return error;
    }

    return errorResponse('Unable to load AI usage analytics', 500);
  }
}
