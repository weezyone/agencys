import {
  estimateSandboxCostUsd,
  getOverviewMetrics,
  getSandboxUtilization,
} from '~/lib/analytics.server';
import { authenticate, errorResponse, parseDays } from './_shared';

export default async function handler(request: Request) {
  if (request.method !== 'GET') {
    return errorResponse('Method not allowed', 405);
  }

  const session = await authenticate(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  try {
    const days = parseDays(request);
    const [metrics, utilization] = await Promise.all([
      getOverviewMetrics(session.userId, days),
      getSandboxUtilization(session.userId, days),
    ]);

    return Response.json({
      estimatedCost: estimateSandboxCostUsd(metrics.totalSandboxHours * 3600),
      estimatedCostNote: 'Approximate sandbox cost estimate based on Fluid Compute CPU pricing.',
      totalHours: metrics.totalSandboxHours,
      utilization,
    });
  } catch (error) {
    if (error instanceof Response) {
      return error;
    }

    return errorResponse('Unable to load sandbox analytics', 500);
  }
}
