import { trackEvent } from '~/lib/analytics.server';
import { deleteFile, generateSignedUrl } from '~/lib/blob.server';
import { db } from '~/lib/db.server';
import { getArtifactById, getProjectById } from '~/lib/data.server';
import { requireAuth } from '~/lib/session.server';

const SIGNED_URL_TTL_SECONDS = 3600;
const UNAUTHORIZED_RESPONSE = Response.json(
  { error: 'Unauthorized' },
  { status: 401 },
);

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

function serializeArtifact(artifact: {
  id: string;
  projectId: string;
  workflowId: string | null;
  name: string;
  filePath: string;
  contentType: string;
  fileSize: bigint;
  checksum: string;
  downloadUrl: string | null;
  expiresAt: Date | null;
  createdAt: Date;
}) {
  return {
    ...artifact,
    downloadUrl: artifact.downloadUrl ?? undefined,
    expiresAt: artifact.expiresAt ?? undefined,
    fileSize: Number(artifact.fileSize),
    workflowId: artifact.workflowId ?? undefined,
  };
}

function toBlobUrl(url: string) {
  const parsed = new URL(url);
  parsed.hash = '';
  parsed.search = '';
  return parsed.toString();
}

async function authenticate(request: Request) {
  try {
    return await requireAuth(request);
  } catch {
    return null;
  }
}

async function loadAuthorizedArtifact(artifactId: string, userId: string) {
  const artifact = await getArtifactById(artifactId);
  if (!artifact) {
    return null;
  }

  const project = await getProjectById(artifact.projectId, userId);
  if (!project) {
    return null;
  }

  return artifact;
}

export default async function handler(request: Request) {
  const session = await authenticate(request);
  if (!session) {
    return UNAUTHORIZED_RESPONSE;
  }

  const artifactId = new URL(request.url).pathname.split('/').pop() ?? '';
  if (!artifactId) {
    return errorResponse('Artifact not found', 404);
  }

  const artifact = await loadAuthorizedArtifact(artifactId, session.userId);
  if (!artifact) {
    return errorResponse('Artifact not found', 404);
  }

  if (request.method === 'GET') {
    try {
      const shouldRefresh =
        !artifact.downloadUrl ||
        (artifact.expiresAt !== null && artifact.expiresAt < new Date());
      let currentArtifact = artifact;
      let downloadUrl = artifact.downloadUrl ?? '';

      if (shouldRefresh) {
        downloadUrl = await generateSignedUrl(
          artifact.filePath,
          SIGNED_URL_TTL_SECONDS,
        );
        currentArtifact = await db.artifact.update({
          data: {
            downloadUrl,
            expiresAt: new Date(Date.now() + SIGNED_URL_TTL_SECONDS * 1000),
          },
          where: { id: artifact.id },
        });
      }

      void trackEvent(
        session.userId,
        'artifact.downloaded',
        { artifactId: currentArtifact.id },
        currentArtifact.projectId,
      );

      return Response.json({
        artifact: serializeArtifact(currentArtifact),
        downloadUrl: downloadUrl || currentArtifact.downloadUrl,
      });
    } catch (error) {
      return errorResponse(
        'Unable to fetch artifact',
        500,
        error instanceof Error ? error.message : undefined,
      );
    }
  }

  if (request.method === 'DELETE') {
    try {
      const deletionSource =
        artifact.downloadUrl ??
        (await generateSignedUrl(artifact.filePath, 60));
      await deleteFile(toBlobUrl(deletionSource));
      await db.artifact.delete({ where: { id: artifact.id } });
      return Response.json({ success: true });
    } catch (error) {
      return errorResponse(
        'Unable to delete artifact',
        500,
        error instanceof Error ? error.message : undefined,
      );
    }
  }

  return errorResponse('Method not allowed', 405);
}
