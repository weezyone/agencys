import { db } from '~/lib/db.server';
import { deleteExpiredArtifacts, getProjectById } from '~/lib/data.server';
import { listArtifactsSchema } from '~/lib/schemas.server';
import { requireAuth } from '~/lib/session.server';

const UNAUTHORIZED_RESPONSE = Response.json(
  { error: 'Unauthorized' },
  { status: 401 },
);

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

function serializeArtifact(artifact: {
  id: string;
  projectId: string;
  workflowId: string | null;
  name: string;
  filePath: string;
  contentType: string;
  fileSize: bigint;
  checksum: string;
  downloadUrl: string | null;
  expiresAt: Date | null;
  createdAt: Date;
}) {
  return {
    ...artifact,
    downloadUrl: artifact.downloadUrl ?? undefined,
    expiresAt: artifact.expiresAt ?? undefined,
    fileSize: Number(artifact.fileSize),
    workflowId: artifact.workflowId ?? undefined,
  };
}

async function authenticate(request: Request) {
  try {
    return await requireAuth(request);
  } catch {
    return null;
  }
}

export default async function handler(request: Request) {
  if (request.method !== 'GET') {
    return errorResponse('Method not allowed', 405);
  }

  const session = await authenticate(request);
  if (!session) {
    return UNAUTHORIZED_RESPONSE;
  }

  const parsed = listArtifactsSchema.safeParse(
    Object.fromEntries(new URL(request.url).searchParams),
  );
  if (!parsed.success) {
    return errorResponse('Invalid artifact query', 400, parsed.error.flatten());
  }

  const project = await getProjectById(parsed.data.projectId, session.userId);
  if (!project) {
    return errorResponse('Project not found', 404);
  }

  void deleteExpiredArtifacts().catch(() => undefined);

  try {
    const [artifacts, total] = await Promise.all([
      db.artifact.findMany({
        orderBy: { createdAt: 'desc' },
        skip: parsed.data.offset,
        take: parsed.data.limit,
        where: { projectId: parsed.data.projectId },
      }),
      db.artifact.count({ where: { projectId: parsed.data.projectId } }),
    ]);

    return Response.json({
      artifacts: artifacts.map(serializeArtifact),
      total,
    });
  } catch {
    return errorResponse('Unable to list artifacts', 500);
  }
}
