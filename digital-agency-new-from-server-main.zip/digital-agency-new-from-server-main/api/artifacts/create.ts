import { Sandbox } from '@vercel/sandbox';
import { z } from 'zod';
import {
  createZipArchive,
  type FileEntry,
  validateFileList,
} from '~/lib/archive.server';
import { trackEvent } from '~/lib/analytics.server';
import { generateSignedUrl, uploadFile } from '~/lib/blob.server';
import { createArtifact, getProjectById } from '~/lib/data.server';
import { notifyArtifactReady } from '~/lib/notifications.server';
import { createArtifactSchema } from '~/lib/schemas.server';
import { requireAuth } from '~/lib/session.server';

const SIGNED_URL_TTL_SECONDS = 3600;
const UNAUTHORIZED_RESPONSE = Response.json(
  { error: 'Unauthorized' },
  { status: 401 },
);

const createSandboxArtifactSchema = z.object({
  projectId: z.string().uuid(),
  workflowId: z.string().uuid().optional(),
  name: z.string().min(1).max(200).default('archive.zip'),
  sandboxId: z.string().min(1),
  paths: z.array(z.string().min(1).max(500)).min(1).max(1000),
});

const createArtifactRequestSchema = z.union([
  createArtifactSchema,
  createSandboxArtifactSchema,
]);

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

function serializeArtifact(artifact: {
  id: string;
  projectId: string;
  workflowId: string | null;
  name: string;
  filePath: string;
  contentType: string;
  fileSize: bigint;
  checksum: string;
  downloadUrl: string | null;
  expiresAt: Date | null;
  createdAt: Date;
}) {
  return {
    ...artifact,
    downloadUrl: artifact.downloadUrl ?? undefined,
    expiresAt: artifact.expiresAt ?? undefined,
    fileSize: Number(artifact.fileSize),
    workflowId: artifact.workflowId ?? undefined,
  };
}

async function authenticate(request: Request) {
  try {
    return await requireAuth(request);
  } catch {
    return null;
  }
}

async function resolveFiles(
  payload: z.infer<typeof createArtifactRequestSchema>,
): Promise<FileEntry[]> {
  if ('files' in payload) {
    return payload.files;
  }

  const sandbox = await Sandbox.get({ sandboxId: payload.sandboxId });
  return Promise.all(
    payload.paths.map(async (filePath) => ({
      content: await sandbox.fs.readFile(filePath),
      path: filePath.replace(/^\/+/, ''),
    })),
  );
}

export default async function handler(request: Request) {
  if (request.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  const session = await authenticate(request);
  if (!session) {
    return UNAUTHORIZED_RESPONSE;
  }

  const payload = await request.json().catch(() => ({}));
  const parsed = createArtifactRequestSchema.safeParse(payload);
  if (!parsed.success) {
    return errorResponse(
      'Invalid artifact request',
      400,
      parsed.error.flatten(),
    );
  }

  const project = await getProjectById(parsed.data.projectId, session.userId);
  if (!project) {
    return errorResponse('Project not found', 404);
  }

  try {
    const files = await resolveFiles(parsed.data);
    const validation = validateFileList(files);
    if (!validation.valid) {
      return errorResponse(
        validation.error ?? 'Invalid artifact file list',
        400,
      );
    }

    const { buffer, metadata } = await createZipArchive(
      files,
      parsed.data.name,
    );
    const upload = await uploadFile(
      metadata.filename,
      buffer,
      'application/zip',
    );
    const downloadUrl = await generateSignedUrl(
      upload.pathname,
      SIGNED_URL_TTL_SECONDS,
    );
    const expiresAt = new Date(Date.now() + SIGNED_URL_TTL_SECONDS * 1000);
    const artifact = await createArtifact({
      checksum: metadata.checksum,
      contentType: 'application/zip',
      downloadUrl,
      expiresAt,
      filePath: upload.pathname,
      fileSize: BigInt(metadata.totalSizeBytes),
      name: metadata.filename,
      projectId: parsed.data.projectId,
      workflowId: parsed.data.workflowId,
    });

    void trackEvent(
      session.userId,
      'artifact.created',
      {
        fileCount: metadata.fileCount,
        sizeBytes: metadata.totalSizeBytes,
      },
      parsed.data.projectId,
    );
    void notifyArtifactReady(
      session.userId,
      artifact.id,
      artifact.name,
      downloadUrl,
    ).catch(() => undefined);

    return Response.json({ artifact: serializeArtifact(artifact) });
  } catch (error) {
    return errorResponse(
      'Unable to create artifact',
      500,
      error instanceof Error ? error.message : undefined,
    );
  }
}
