import { WorkflowStatus } from '@prisma/client';
import { executeWorkflow } from '@vercel/workflow';
import { trackEvent } from '~/lib/analytics.server';
import { createWorkflow, getProjectById } from '~/lib/data.server';
import { startWorkflowSchema } from '~/lib/schemas.server';
import { requireAuth } from '~/lib/session.server';
import { cloudTaskWorkflow, gitCommitWorkflow } from '~/lib/workflow.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

async function authenticate(request: Request) {
  try {
    return await requireAuth(request);
  } catch {
    return null;
  }
}

export default async function handler(request: Request) {
  if (request.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  const session = await authenticate(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  const payload = await request.json().catch(() => ({}));
  const parsed = startWorkflowSchema.safeParse(payload);
  if (!parsed.success) {
    return errorResponse(
      'Invalid workflow payload',
      400,
      parsed.error.flatten(),
    );
  }

  const project = await getProjectById(parsed.data.projectId, session.userId);
  if (!project) {
    return errorResponse('Project not found', 404);
  }

  try {
    const workflow = await createWorkflow(project.id, {
      currentState: {
        requestedAt: new Date().toISOString(),
        requestedBy: session.userId,
        workflowType: parsed.data.workflowType,
      },
      definition: parsed.data,
      name:
        parsed.data.workflowType === 'cloud-task'
          ? 'Cloud Task Workflow'
          : 'Git Commit Workflow',
      status: WorkflowStatus.INITIALIZING,
    });

    const sharedInput = {
      branch: parsed.data.branch ?? project.branch,
      projectId: project.id,
      repositoryUrl:
        parsed.data.repositoryUrl ?? project.repositoryUrl ?? undefined,
      sandboxConfig: parsed.data.sandboxConfig,
      userId: session.userId,
      workflowId: workflow.id,
    };

    const definition =
      parsed.data.workflowType === 'cloud-task'
        ? cloudTaskWorkflow
        : gitCommitWorkflow;
    const metadata =
      parsed.data.workflowType === 'cloud-task'
        ? {
            ...sharedInput,
            contextFiles: [],
            provider: parsed.data.provider,
            task: parsed.data.task!,
          }
        : {
            ...sharedInput,
            commitMessage: parsed.data.commitMessage!,
            files: parsed.data.files ?? [],
          };

    await executeWorkflow(definition, {
      metadata,
      projectId: project.id,
      workflowId: workflow.id,
    });

    void trackEvent(
      session.userId,
      'workflow.started',
      {
        projectId: project.id,
        workflowType: parsed.data.workflowType,
      },
      project.id,
    );

    return Response.json({
      status: WorkflowStatus.INITIALIZING,
      workflowId: workflow.id,
    });
  } catch (error) {
    return errorResponse(
      'Unable to start workflow',
      500,
      error instanceof Error ? error.message : undefined,
    );
  }
}
