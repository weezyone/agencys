import { WorkflowStatus } from '@prisma/client';
import { getWorkflowById, updateWorkflowStatus } from '~/lib/data.server';
import { requireAuth } from '~/lib/session.server';
import {
  cancelWorkflow,
  emitWorkflowEvent,
  getWorkflowEvents,
} from '~/lib/workflow.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

async function authenticate(request: Request) {
  try {
    return await requireAuth(request);
  } catch {
    return null;
  }
}

function isTerminalStatus(status: WorkflowStatus) {
  return (
    status === WorkflowStatus.COMPLETED ||
    status === WorkflowStatus.EXPIRED ||
    status === WorkflowStatus.FAILED
  );
}

export default async function handler(request: Request) {
  const session = await authenticate(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  const workflowId = new URL(request.url).pathname.split('/').pop() ?? '';
  if (!workflowId) {
    return errorResponse('Workflow not found', 404);
  }

  const workflowRecord = await getWorkflowById(workflowId);
  if (!workflowRecord || workflowRecord.project.userId !== session.userId) {
    return errorResponse('Workflow not found', 404);
  }

  if (request.method === 'GET') {
    const {
      artifacts: _artifacts,
      project: _project,
      steps,
      ...workflow
    } = workflowRecord;
    const recentEvents = await getWorkflowEvents(workflowId);

    return Response.json({ recentEvents, steps, workflow });
  }

  if (request.method === 'DELETE') {
    try {
      await cancelWorkflow(workflowId);
      if (!isTerminalStatus(workflowRecord.status)) {
        await updateWorkflowStatus(workflowId, WorkflowStatus.FAILED, {
          cancelled: true,
          cancelledAt: new Date().toISOString(),
        });
      }
      await emitWorkflowEvent(workflowId, {
        data: { cancelled: true },
        message: 'Workflow cancelled by user.',
        timestamp: Date.now(),
        type: 'workflow_failed',
      });

      return Response.json({
        cancelled: true,
        status: WorkflowStatus.FAILED,
        workflowId,
      });
    } catch (error) {
      return errorResponse(
        'Unable to cancel workflow',
        500,
        error instanceof Error ? error.message : undefined,
      );
    }
  }

  return errorResponse('Method not allowed', 405);
}
