import { parseDiff } from '../../app/lib/diff.server';
import {
  GitApiError,
  getGitClient,
  resolveGitContext,
} from '../../app/lib/git.server';
import { checkRateLimit } from '../../app/lib/rate-limit.server';
import { gitDiffQuerySchema } from '../../app/lib/schemas.server';
import { getSession } from '../../app/lib/session.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

export default async function handler(request: Request) {
  if (request.method !== 'GET') {
    return errorResponse('Method not allowed', 405);
  }

  const session = await getSession(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  const url = new URL(request.url);
  const parsed = gitDiffQuerySchema.safeParse(
    Object.fromEntries(url.searchParams.entries()),
  );

  if (!parsed.success) {
    return errorResponse('Invalid diff request', 400, parsed.error.flatten());
  }

  try {
    if (parsed.data.rawDiff) {
      const files = parseDiff(parsed.data.rawDiff);
      return Response.json({
        files,
        totalAdditions: files.reduce((sum, file) => sum + file.additions, 0),
        totalDeletions: files.reduce((sum, file) => sum + file.deletions, 0),
      });
    }

    const context = await resolveGitContext(parsed.data);
    const rateLimit = await checkRateLimit(
      `${session.userId}:${context.provider}:diff`,
      5000,
      3600,
    );
    if (!rateLimit.allowed) {
      return errorResponse(
        `Rate limit exceeded. Try again after ${rateLimit.resetAt.toISOString()}.`,
        429,
      );
    }

    const client = getGitClient(
      context.provider,
      context.accessToken,
      context.baseUrl,
    );
    const result = await client.compareBranches(
      context.owner,
      context.repo,
      parsed.data.base!,
      parsed.data.head!,
    );
    const totalAdditions = result.files.reduce(
      (sum, file) => sum + file.additions,
      0,
    );
    const totalDeletions = result.files.reduce(
      (sum, file) => sum + file.deletions,
      0,
    );

    return Response.json({
      files: result.files,
      totalAdditions,
      totalDeletions,
    });
  } catch (error) {
    if (error instanceof GitApiError) {
      return errorResponse(error.message, error.status, error.details);
    }

    return errorResponse('Unable to generate diff', 500);
  }
}
