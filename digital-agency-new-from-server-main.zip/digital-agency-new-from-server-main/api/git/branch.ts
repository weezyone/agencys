import { validateBranchName } from '../../app/lib/diff.server';
import {
  GitApiError,
  getGitClient,
  resolveGitContext,
} from '../../app/lib/git.server';
import { checkRateLimit } from '../../app/lib/rate-limit.server';
import { createBranchRequestSchema } from '../../app/lib/schemas.server';
import { getSession } from '../../app/lib/session.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

function buildBranchUrl(
  repositoryUrl: string,
  branchName: string,
  provider: 'github' | 'gitlab',
) {
  const baseUrl = repositoryUrl.replace(/\.git$/, '').replace(/\/$/, '');
  const encodedBranch = branchName.split('/').map(encodeURIComponent).join('/');
  return provider === 'gitlab'
    ? `${baseUrl}/-/tree/${encodedBranch}`
    : `${baseUrl}/tree/${encodedBranch}`;
}

export default async function handler(request: Request) {
  if (request.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  const session = await getSession(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  const payload = await request.json().catch(() => ({}));
  const parsed = createBranchRequestSchema.safeParse(payload);

  if (!parsed.success) {
    return errorResponse('Invalid branch request', 400, parsed.error.flatten());
  }

  const validation = validateBranchName(parsed.data.branchName);
  if (!validation.valid) {
    return errorResponse(validation.error ?? 'Invalid branch name', 400);
  }

  try {
    const context = await resolveGitContext(parsed.data);
    const rateLimit = await checkRateLimit(
      `${session.userId}:${context.provider}:branch`,
      5000,
      3600,
    );
    if (!rateLimit.allowed) {
      return errorResponse(
        `Rate limit exceeded. Try again after ${rateLimit.resetAt.toISOString()}.`,
        429,
      );
    }

    const client = getGitClient(
      context.provider,
      context.accessToken,
      context.baseUrl,
    );
    const baseBranch = parsed.data.baseBranch ?? context.defaultBranch;
    const baseSha = await client.getRefSha(
      context.owner,
      context.repo,
      baseBranch,
    );
    const branch = await client.createBranch(
      context.owner,
      context.repo,
      parsed.data.branchName,
      baseSha,
    );

    return Response.json({
      branch,
      url: buildBranchUrl(context.repositoryUrl, branch.name, context.provider),
    });
  } catch (error) {
    if (error instanceof GitApiError) {
      const lowerMessage = error.message.toLowerCase();
      if (
        error.status === 422 ||
        (error.status === 400 && lowerMessage.includes('already exists'))
      ) {
        return errorResponse('Branch already exists', 409, error.details);
      }

      return errorResponse(error.message, error.status, error.details);
    }

    return errorResponse('Unable to create branch', 500);
  }
}
