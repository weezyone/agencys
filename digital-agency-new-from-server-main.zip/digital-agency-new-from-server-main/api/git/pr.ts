import { generatePRDescription } from '../../app/lib/diff.server';
import {
  GitApiError,
  getGitClient,
  resolveGitContext,
} from '../../app/lib/git.server';
import { trackEvent } from '../../app/lib/analytics.server';
import { checkRateLimit } from '../../app/lib/rate-limit.server';
import { createPRRequestSchema } from '../../app/lib/schemas.server';
import { getSession } from '../../app/lib/session.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

export default async function handler(request: Request) {
  if (request.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  const session = await getSession(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  const payload = await request.json().catch(() => ({}));
  const parsed = createPRRequestSchema.safeParse(payload);

  if (!parsed.success) {
    return errorResponse(
      'Invalid pull request payload',
      400,
      parsed.error.flatten(),
    );
  }

  try {
    const context = await resolveGitContext(parsed.data);
    const rateLimit = await checkRateLimit(
      `${session.userId}:${context.provider}:pr`,
      5000,
      3600,
    );
    if (!rateLimit.allowed) {
      return errorResponse(
        `Rate limit exceeded. Try again after ${rateLimit.resetAt.toISOString()}.`,
        429,
      );
    }

    const client = getGitClient(
      context.provider,
      context.accessToken,
      context.baseUrl,
    );
    const repo = await client.getRepo(context.owner, context.repo);
    const base =
      parsed.data.base ?? repo.default_branch ?? context.defaultBranch;
    const prBody = parsed.data.body?.trim()
      ? parsed.data.body
      : generatePRDescription(
          (
            await client.compareBranches(
              context.owner,
              context.repo,
              base,
              parsed.data.head,
            )
          ).commits.map((commit) => ({
            message: commit.commit.message,
          })),
        );

    const pr = await client.createPullRequest(
      context.owner,
      context.repo,
      parsed.data.title,
      prBody,
      parsed.data.head,
      base,
    );

    void trackEvent(
      session.userId,
      'git.pr_created',
      { projectId: parsed.data.projectId },
      parsed.data.projectId,
    );

    return Response.json({ pr });
  } catch (error) {
    if (error instanceof GitApiError) {
      return errorResponse(error.message, error.status, error.details);
    }

    return errorResponse('Unable to create pull request', 500);
  }
}
