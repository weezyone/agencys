import {
  GitApiError,
  GitHubClient,
  GitLabClient,
  getGitClient,
  resolveGitContext,
} from '../../app/lib/git.server';
import { trackEvent } from '../../app/lib/analytics.server';
import { checkRateLimit } from '../../app/lib/rate-limit.server';
import { createCommitRequestSchema } from '../../app/lib/schemas.server';
import { getSession } from '../../app/lib/session.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

export default async function handler(request: Request) {
  if (request.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  const session = await getSession(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  const payload = await request.json().catch(() => ({}));
  const parsed = createCommitRequestSchema.safeParse(payload);

  if (!parsed.success) {
    return errorResponse('Invalid commit request', 400, parsed.error.flatten());
  }

  try {
    const context = await resolveGitContext(parsed.data);
    const rateLimit = await checkRateLimit(
      `${session.userId}:${context.provider}:commit`,
      5000,
      3600,
    );
    if (!rateLimit.allowed) {
      return errorResponse(
        `Rate limit exceeded. Try again after ${rateLimit.resetAt.toISOString()}.`,
        429,
      );
    }

    const client = getGitClient(
      context.provider,
      context.accessToken,
      context.baseUrl,
    );
    await client.getRefSha(context.owner, context.repo, parsed.data.branch);

    if (client instanceof GitHubClient) {
      const baseCommit = await client.getCommit(
        context.owner,
        context.repo,
        parsed.data.branch,
      );
      const treeEntries = await Promise.all(
        parsed.data.files.map(async (file) => ({
          path: file.path,
          sha: await client.createBlob(
            context.owner,
            context.repo,
            file.content,
          ),
        })),
      );
      const treeSha = await client.createTree(
        context.owner,
        context.repo,
        baseCommit.treeSha,
        treeEntries,
      );
      const commit = await client.createCommitObject(
        context.owner,
        context.repo,
        parsed.data.message,
        treeSha,
        baseCommit.sha,
      );
      await client.updateBranchRef(
        context.owner,
        context.repo,
        parsed.data.branch,
        commit.sha,
      );

      void trackEvent(
        session.userId,
        'git.commit',
        {
          fileCount: parsed.data.files.length,
          projectId: parsed.data.projectId,
        },
        parsed.data.projectId,
      );

      return Response.json({
        sha: commit.sha,
        url: commit.html_url,
        branch: parsed.data.branch,
      });
    }

    if (client instanceof GitLabClient) {
      const commit = await client.createCommit(
        context.owner,
        context.repo,
        parsed.data.message,
        parsed.data.branch,
        parsed.data.files,
      );

      void trackEvent(
        session.userId,
        'git.commit',
        {
          fileCount: parsed.data.files.length,
          projectId: parsed.data.projectId,
        },
        parsed.data.projectId,
      );

      return Response.json({
        sha: commit.sha,
        url: commit.html_url,
        branch: parsed.data.branch,
      });
    }

    return errorResponse('Unsupported Git provider', 400);
  } catch (error) {
    if (error instanceof GitApiError) {
      return errorResponse(error.message, error.status, error.details);
    }

    return errorResponse('Unable to create commit', 500);
  }
}
