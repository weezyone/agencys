import kv from '../../app/lib/kv.server';
import { listUserInstallations } from '../../app/lib/github-app.server';
import { requireAuth } from '../../app/lib/session.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

export default async function handler(request: Request) {
  if (request.method !== 'GET') {
    return errorResponse('Method not allowed', 405);
  }

  let session;
  try {
    session = await requireAuth(request);
  } catch {
    return errorResponse('Unauthorized', 401);
  }

  const cachedOauth = await kv.get<{ accessToken?: string }>(
    `github:user:${session.userId}:oauth`,
  );
  const accessToken =
    session.provider === 'github' ? session.accessToken : cachedOauth?.accessToken;
  const appInstallUrl = `https://github.com/apps/${process.env.GITHUB_APP_SLUG ?? 'cloud-platform-dev'}/installations/new`;

  if (!accessToken) {
    return Response.json({ appInstallUrl, installations: [] });
  }

  try {
    const installations = await listUserInstallations(accessToken);
    return Response.json({ appInstallUrl, installations });
  } catch (error) {
    return errorResponse(
      'Unable to load GitHub App installations',
      500,
      error instanceof Error ? error.message : undefined,
    );
  }
}
