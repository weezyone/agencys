export function generateAppManifest(baseUrl: string): object {
  const normalizedBaseUrl = baseUrl.replace(/\/$/, '');
  const webhookUrl = `${normalizedBaseUrl}/api/github/webhook`;
  const callbackUrl = `${normalizedBaseUrl}/api/github/app-callback`;
  const events = ['push', 'pull_request', 'check_run'];
  const permissions = {
    checks: 'write',
    contents: 'read',
    pull_requests: 'read',
  };

  return {
    callback_urls: [callbackUrl],
    default_events: events,
    default_permissions: permissions,
    events,
    hook_attributes: {
      url: webhookUrl,
    },
    name: 'Cloud Platform Dev',
    permissions,
    request_oauth_on_install: true,
    url: normalizedBaseUrl,
    webhook_url: webhookUrl,
  };
}

export default async function handler(request: Request) {
  if (request.method !== 'GET') {
    return Response.json({ error: 'Method not allowed' }, { status: 405 });
  }

  const baseUrl = new URL(request.url).origin;
  return Response.json(generateAppManifest(baseUrl));
}
