import kv from '../../app/lib/kv.server';
import { sessionStorage } from '../../app/lib/session.server';

function getRequiredEnv(name: string): string {
  const value = process.env[name]?.trim();
  if (!value) {
    throw new Error(`${name} is required for GitHub App integration.`);
  }
  return value;
}

async function exchangeAppCode(code: string) {
  const body = new URLSearchParams({
    client_id: getRequiredEnv('GITHUB_APP_CLIENT_ID'),
    client_secret: getRequiredEnv('GITHUB_APP_CLIENT_SECRET'),
    code,
  });

  const response = await fetch('https://github.com/login/oauth/access_token', {
    body,
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    method: 'POST',
  });
  const payload = (await response.json()) as {
    access_token?: string;
    error?: string;
    error_description?: string;
    scope?: string;
    token_type?: string;
  };

  if (!response.ok || payload.error || !payload.access_token) {
    throw new Error(payload.error_description ?? payload.error ?? 'Unable to exchange GitHub App OAuth code.');
  }

  return {
    accessToken: payload.access_token,
    scope: payload.scope ?? '',
    tokenType: payload.token_type ?? 'bearer',
  };
}

export default async function handler(request: Request) {
  if (request.method !== 'GET') {
    return Response.json({ error: 'Method not allowed' }, { status: 405 });
  }

  const url = new URL(request.url);
  const installationId = Number(url.searchParams.get('installation_id'));
  if (!installationId) {
    return Response.json({ error: 'installation_id is required' }, { status: 400 });
  }

  const session = await sessionStorage.getSession(request.headers.get('Cookie'));
  const userId = session.get('userId');
  const setupAction = url.searchParams.get('setup_action');
  const code = url.searchParams.get('code');

  session.set('githubAppInstallationId', String(installationId));

  if (typeof userId === 'string' && userId) {
    await kv.set(`github:user:${userId}:installation`, { installationId }, { ex: 60 * 60 * 24 * 30 });
  }

  if (setupAction === 'install' && code) {
    const token = await exchangeAppCode(code);
    session.set('githubAppOauthToken', token.accessToken);

    if (typeof userId === 'string' && userId) {
      await kv.set(`github:user:${userId}:oauth`, token, { ex: 60 * 60 * 24 });
    }
  }

  return new Response(null, {
    headers: {
      Location: '/?githubAppInstalled=true',
      'Set-Cookie': await sessionStorage.commitSession(session),
    },
    status: 302,
  });
}
