import { trackEvent } from '../../app/lib/analytics.server';
import { getProjectById } from '../../app/lib/data.server';
import { createSandboxSchema } from '../../app/lib/schemas.server';
import { requireAuth } from '../../app/lib/session.server';
import { createSandbox } from '../../app/lib/sandbox.server';
import { requireSandboxQuota } from '~/lib/billing-middleware.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

async function requireApiAuth(request: Request) {
  try {
    return await requireAuth(request);
  } catch (error) {
    if (error instanceof Response) {
      return null;
    }

    throw error;
  }
}

export default async function handler(request: Request) {
  if (request.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  const session = await requireApiAuth(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  const payload = await request.json().catch(() => ({}));
  const parsed = createSandboxSchema.safeParse(payload);
  if (!parsed.success) {
    return errorResponse(
      'Invalid sandbox payload',
      400,
      parsed.error.flatten(),
    );
  }

  const project = await getProjectById(parsed.data.projectId, session.userId);
  if (!project) {
    return errorResponse('Project not found', 404);
  }

  try {
    await requireSandboxQuota(
      session.userId,
      parsed.data.vcpus,
      parsed.data.timeoutMinutes,
    );
    const { projectId, ...config } = parsed.data;
    const sandbox = await createSandbox(projectId, config);
    void trackEvent(
      session.userId,
      'sandbox.created',
      {
        projectId,
        runtime: sandbox.configuration?.runtime,
        timeoutMinutes: sandbox.configuration?.timeoutMinutes,
        vcpus: sandbox.configuration?.vcpus,
      },
      projectId,
    );

    return Response.json(sandbox);
  } catch (error) {
    if (error instanceof Response) {
      return error;
    }

    return errorResponse(
      error instanceof Error ? error.message : 'Unable to create sandbox',
      500,
    );
  }
}
