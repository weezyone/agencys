import { getSandboxById } from '../../app/lib/data.server';
import { requireAuth } from '../../app/lib/session.server';
import {
  getSandboxStatus,
  terminateSandbox,
} from '../../app/lib/sandbox.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

async function requireApiAuth(request: Request) {
  try {
    return await requireAuth(request);
  } catch (error) {
    if (error instanceof Response) {
      return null;
    }

    throw error;
  }
}

function getSandboxRecordId(request: Request) {
  return new URL(request.url).pathname.split('/').filter(Boolean).pop() ?? '';
}

export default async function handler(request: Request) {
  const session = await requireApiAuth(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  const sandboxRecord = await getSandboxById(
    getSandboxRecordId(request),
    session.userId,
  );
  if (!sandboxRecord) {
    return errorResponse('Sandbox not found', 404);
  }

  if (request.method === 'GET') {
    try {
      const status = await getSandboxStatus(sandboxRecord.sandboxId);
      return Response.json({
        configuration: sandboxRecord.configuration,
        createdAt: sandboxRecord.createdAt,
        domain: status.domain ?? '',
        id: sandboxRecord.id,
        sandboxId: sandboxRecord.sandboxId,
        status: status.status,
        terminatedAt: sandboxRecord.terminatedAt,
      });
    } catch (error) {
      return errorResponse(
        error instanceof Error
          ? error.message
          : 'Unable to fetch sandbox status',
        500,
      );
    }
  }

  if (request.method === 'DELETE') {
    try {
      await terminateSandbox(sandboxRecord.sandboxId);
      return Response.json({
        id: sandboxRecord.id,
        sandboxId: sandboxRecord.sandboxId,
        status: 'terminated',
      });
    } catch (error) {
      return errorResponse(
        error instanceof Error ? error.message : 'Unable to terminate sandbox',
        500,
      );
    }
  }

  return errorResponse('Method not allowed', 405);
}
