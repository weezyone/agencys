import { z } from 'zod';
import { getSandboxById } from '../../../app/lib/data.server';
import { requireAuth } from '../../../app/lib/session.server';
import {
  listSandboxFiles,
  readSandboxFile,
  writeSandboxFile,
} from '../../../app/lib/sandbox.server';

const writeSandboxFileSchema = z.object({
  content: z.string(),
  path: z.string().min(1),
});

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

async function requireApiAuth(request: Request) {
  try {
    return await requireAuth(request);
  } catch (error) {
    if (error instanceof Response) {
      return null;
    }

    throw error;
  }
}

function getSandboxRecordId(request: Request) {
  const segments = new URL(request.url).pathname.split('/').filter(Boolean);
  return segments.at(-2) ?? '';
}

export default async function handler(request: Request) {
  const session = await requireApiAuth(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  const sandboxRecord = await getSandboxById(
    getSandboxRecordId(request),
    session.userId,
  );
  if (!sandboxRecord) {
    return errorResponse('Sandbox not found', 404);
  }

  if (request.method === 'GET') {
    const url = new URL(request.url);
    const path = url.searchParams.get('path');
    const read = url.searchParams.get('read') === 'true';

    if (!path) {
      return errorResponse('Path is required', 400);
    }

    try {
      if (read) {
        const content = await readSandboxFile(sandboxRecord.sandboxId, path);
        return Response.json({ content, path });
      }

      const files = await listSandboxFiles(sandboxRecord.sandboxId, path);
      return Response.json({ files, path });
    } catch (error) {
      return errorResponse(
        error instanceof Error
          ? error.message
          : 'Unable to access sandbox files',
        500,
      );
    }
  }

  if (request.method === 'POST') {
    const payload = await request.json().catch(() => ({}));
    const parsed = writeSandboxFileSchema.safeParse(payload);
    if (!parsed.success) {
      return errorResponse('Invalid file payload', 400, parsed.error.flatten());
    }

    try {
      await writeSandboxFile(
        sandboxRecord.sandboxId,
        parsed.data.path,
        parsed.data.content,
      );
      return Response.json({ ok: true, path: parsed.data.path });
    } catch (error) {
      return errorResponse(
        error instanceof Error ? error.message : 'Unable to write sandbox file',
        500,
      );
    }
  }

  return errorResponse('Method not allowed', 405);
}
