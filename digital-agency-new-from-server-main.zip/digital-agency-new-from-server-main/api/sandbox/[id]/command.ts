import { getSandboxById } from '../../../app/lib/data.server';
import { executeCommandSchema } from '../../../app/lib/schemas.server';
import { requireAuth } from '../../../app/lib/session.server';
import { runSandboxCommandStream } from '../../../app/lib/sandbox.server';

function errorResponse(message: string, status: number, details?: unknown) {
  return Response.json({ error: message, details }, { status });
}

async function requireApiAuth(request: Request) {
  try {
    return await requireAuth(request);
  } catch (error) {
    if (error instanceof Response) {
      return null;
    }

    throw error;
  }
}

function getSandboxRecordId(request: Request) {
  const segments = new URL(request.url).pathname.split('/').filter(Boolean);
  return segments.at(-2) ?? '';
}

export default async function handler(request: Request) {
  if (request.method !== 'POST') {
    return errorResponse('Method not allowed', 405);
  }

  const session = await requireApiAuth(request);
  if (!session) {
    return errorResponse('Unauthorized', 401);
  }

  const payload = await request.json().catch(() => ({}));
  const parsed = executeCommandSchema.safeParse(payload);
  if (!parsed.success) {
    return errorResponse(
      'Invalid command payload',
      400,
      parsed.error.flatten(),
    );
  }

  const sandboxRecord = await getSandboxById(
    getSandboxRecordId(request),
    session.userId,
  );
  if (!sandboxRecord) {
    return errorResponse('Sandbox not found', 404);
  }

  try {
    const execution = await runSandboxCommandStream(
      sandboxRecord.sandboxId,
      parsed.data.command,
      {
        cwd: parsed.data.cwd,
        env: parsed.data.env,
      },
    );
    const encoder = new TextEncoder();

    const stream = new ReadableStream({
      async start(controller) {
        try {
          for await (const chunk of execution.stream) {
            controller.enqueue(
              encoder.encode(
                `${JSON.stringify({ ...chunk, timestamp: Date.now() })}\n`,
              ),
            );
          }

          const result = await execution.completed;
          controller.enqueue(
            encoder.encode(
              `${JSON.stringify({ exitCode: result.exitCode, timestamp: Date.now(), type: 'exit' })}\n`,
            ),
          );
        } catch (error) {
          controller.enqueue(
            encoder.encode(
              `${JSON.stringify({ data: error instanceof Error ? error.message : 'Command failed', timestamp: Date.now(), type: 'stderr' })}\n`,
            ),
          );
          controller.enqueue(
            encoder.encode(
              `${JSON.stringify({ exitCode: 1, timestamp: Date.now(), type: 'exit' })}\n`,
            ),
          );
        } finally {
          controller.close();
        }
      },
    });

    return new Response(stream, {
      headers: {
        'Cache-Control': 'no-cache',
        'Content-Type': 'application/x-ndjson; charset=utf-8',
      },
    });
  } catch (error) {
    return errorResponse(
      error instanceof Error ? error.message : 'Unable to execute command',
      500,
    );
  }
}
