import { type NextRequest, NextResponse } from "next/server";

import { ProjectSyncInputSchema } from "@agency/schemas";

import { syncProject } from "@/lib/runtime-client";
import {
  createApiErrorResponse,
  requireInternalApiActor,
} from "@/lib/server-auth";

export async function POST(request: NextRequest) {
  try {
    await requireInternalApiActor(request);
    const input = ProjectSyncInputSchema.parse(await request.json());
    const result = await syncProject(input);

    return NextResponse.json(result);
  } catch (error) {
    return createApiErrorResponse(error);
  }
}