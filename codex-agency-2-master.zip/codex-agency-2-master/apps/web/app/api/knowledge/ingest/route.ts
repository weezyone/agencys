import { type NextRequest, NextResponse } from "next/server";

import { KnowledgeIngestInputSchema } from "@agency/schemas";

import { ingestKnowledge } from "@/lib/runtime-client";
import {
  createApiErrorResponse,
  requireInternalApiActor,
} from "@/lib/server-auth";

export async function POST(request: NextRequest) {
  try {
    await requireInternalApiActor(request);
    const input = KnowledgeIngestInputSchema.parse(await request.json());
    const result = await ingestKnowledge(input);

    return NextResponse.json(result);
  } catch (error) {
    return createApiErrorResponse(error);
  }
}