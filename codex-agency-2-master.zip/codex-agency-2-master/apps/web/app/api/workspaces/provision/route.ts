import { type NextRequest, NextResponse } from "next/server";

import { ClientWorkspaceSchema, WorkspaceProvisionInputSchema } from "@agency/schemas";

import { getRequiredRepositories } from "@/lib/database";
import {
  createApiErrorResponse,
  requireInternalApiActor,
} from "@/lib/server-auth";

export async function POST(request: NextRequest) {
  try {
    await requireInternalApiActor(request);
    const input = WorkspaceProvisionInputSchema.parse(await request.json());
    const workspace = ClientWorkspaceSchema.parse({
      id: createId("workspace"),
      name: input.workspaceName,
      primaryContactEmail: input.primaryContactEmail,
      proposalId: input.proposalId,
      projectIds: [],
      portalAccess: "active",
      createdAt: nowIso(),
      updatedAt: nowIso(),
    });

    const repositories = await getRequiredRepositories();
    await repositories.workspaces.provision(workspace);

    return NextResponse.json({ workspace });
  } catch (error) {
    return createApiErrorResponse(error);
  }
}

function createId(prefix: string) {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
}

function nowIso() {
  return new Date().toISOString();
}