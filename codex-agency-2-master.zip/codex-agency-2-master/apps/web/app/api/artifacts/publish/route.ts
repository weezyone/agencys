import { type NextRequest, NextResponse } from "next/server";

import { ArtifactPublishInputSchema } from "@agency/schemas";

import { publishArtifacts } from "@/lib/runtime-client";
import {
  createApiErrorResponse,
  requireInternalApiActor,
} from "@/lib/server-auth";

export async function POST(request: NextRequest) {
  try {
    await requireInternalApiActor(request);
    const input = ArtifactPublishInputSchema.parse(await request.json());
    const result = await publishArtifacts(input);

    return NextResponse.json(result);
  } catch (error) {
    return createApiErrorResponse(error);
  }
}