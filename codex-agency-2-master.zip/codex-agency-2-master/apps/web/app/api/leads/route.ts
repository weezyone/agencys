import { type NextRequest, NextResponse } from "next/server";

import { LeadIntakeInputSchema, LeadSchema } from "@agency/schemas";

import { getRequiredRepositories } from "@/lib/database";
import { qualifyLead } from "@/lib/runtime-client";
import { createApiErrorResponse } from "@/lib/server-auth";

export async function POST(request: NextRequest) {
  try {
    const input = LeadIntakeInputSchema.parse(await request.json());
    const lead = LeadSchema.parse({
      ...input,
      id: createId("lead"),
      status: "new",
      createdAt: nowIso(),
      updatedAt: nowIso(),
    });

    const repositories = await getRequiredRepositories();
    await repositories.leads.create(lead);

    const qualification = await qualifyLead(lead);

    return NextResponse.json({
      lead,
      qualification,
    });
  } catch (error) {
    return createApiErrorResponse(error);
  }
}

function createId(prefix: string) {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
}

function nowIso() {
  return new Date().toISOString();
}