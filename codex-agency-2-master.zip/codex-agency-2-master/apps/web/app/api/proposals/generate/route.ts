import { type NextRequest, NextResponse } from "next/server";

import { ProposalGenerationInputSchema } from "@agency/schemas";

import { generateProposal } from "@/lib/runtime-client";
import {
  createApiErrorResponse,
  requireInternalApiActor,
} from "@/lib/server-auth";

export async function POST(request: NextRequest) {
  try {
    await requireInternalApiActor(request);
    const input = ProposalGenerationInputSchema.parse(await request.json());
    const result = await generateProposal(input);

    return NextResponse.json(result);
  } catch (error) {
    return createApiErrorResponse(error);
  }
}