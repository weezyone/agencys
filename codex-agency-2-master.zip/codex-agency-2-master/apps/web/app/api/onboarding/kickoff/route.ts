import { type NextRequest, NextResponse } from "next/server";

import { OnboardingKickoffInputSchema } from "@agency/schemas";

import { kickoffOnboarding } from "@/lib/runtime-client";
import {
  createApiErrorResponse,
  requireInternalApiActor,
} from "@/lib/server-auth";

export async function POST(request: NextRequest) {
  try {
    await requireInternalApiActor(request);
    const input = OnboardingKickoffInputSchema.parse(await request.json());
    const result = await kickoffOnboarding(input);

    return NextResponse.json(result);
  } catch (error) {
    return createApiErrorResponse(error);
  }
}