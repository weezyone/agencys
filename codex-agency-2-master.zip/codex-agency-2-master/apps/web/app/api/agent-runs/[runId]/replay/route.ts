import { type NextRequest, NextResponse } from "next/server";

import { replayAgentRun } from "@/lib/runtime-client";
import {
  createApiErrorResponse,
  requireInternalApiActor,
} from "@/lib/server-auth";

export async function POST(
  request: NextRequest,
  context: { params: Promise<{ runId: string }> },
) {
  try {
    await requireInternalApiActor(request);
    const { runId } = await context.params;
    const payload = await request.json().catch(() => ({}));
    const result = await replayAgentRun(runId, payload?.notes);

    return NextResponse.json(result);
  } catch (error) {
    return createApiErrorResponse(error);
  }
}