import { sanitizeReturnToPath } from "@/lib/access-control";

import { SignInForm } from "./sign-in-form";

export default async function SignInPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string | string[] }>;
}) {
  const params = await searchParams;
  const next = Array.isArray(params.next) ? params.next[0] : params.next;
  const callbackURL = sanitizeReturnToPath(next);

  return <SignInForm callbackURL={callbackURL} />;
}
