"use client";

import Link from "next/link";
import { useState, useTransition } from "react";

import { Button, Card, CardDescription, CardTitle } from "@agency/ui";

import { authClient } from "@/lib/auth-client";

export function SignInForm({ callbackURL }: { callbackURL: string }) {
  const [email, setEmail] = useState("owner@example.com");
  const [password, setPassword] = useState("change-me");
  const [message, setMessage] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  return (
    <main className="mx-auto flex min-h-[70vh] max-w-xl items-center px-6 py-16">
      <Card className="w-full space-y-6 rounded">
        <div className="space-y-3">
          <CardTitle className="text-3xl">Sign in to Agency OS</CardTitle>
          <CardDescription>
            Email/password auth is wired through Better Auth with organization support.
          </CardDescription>
        </div>

        <form
          className="space-y-4"
          onSubmit={(event) => {
            event.preventDefault();
            setMessage(null);

            startTransition(async () => {
              const result = await authClient.signIn.email({
                email,
                password,
                callbackURL,
              });

              setMessage(
                result.error?.message ??
                  "Sign-in request sent. If this is a fresh database, run the Better Auth migration and seed the first admin account.",
              );
            });
          }}
        >
          <label className="block space-y-2">
            <span className="text-sm text-[var(--muted-foreground)]">Email</span>
            <input
              className="w-full rounded border border-white/10 bg-black/20 px-4 py-3 outline-none"
              onChange={(event) => setEmail(event.target.value)}
              required
              type="email"
              value={email}
            />
          </label>
          <label className="block space-y-2">
            <span className="text-sm text-[var(--muted-foreground)]">Password</span>
            <input
              className="w-full rounded border border-white/10 bg-black/20 px-4 py-3 outline-none"
              onChange={(event) => setPassword(event.target.value)}
              required
              type="password"
              value={password}
            />
          </label>
          <Button className="w-full rounded" disabled={isPending} type="submit">
            {isPending ? "Signing in..." : "Sign in"}
          </Button>
        </form>

        <p className="text-sm text-[var(--muted-foreground)]">
          Need an account?{" "}
          <Link className="text-white underline decoration-white/30 underline-offset-4" href={`/sign-up?next=${encodeURIComponent(callbackURL)}`}>
            Sign up
          </Link>
        </p>

        {message ? <p className="text-sm text-[var(--muted-foreground)]">{message}</p> : null}
      </Card>
    </main>
  );
}
