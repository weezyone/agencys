import { Badge, Button, Card, CardDescription, CardTitle, SectionHeading } from "@agency/ui";

import { requireWorkspacePageActor } from "@/lib/server-auth";

export default async function ClientWorkspacePage({
  params,
}: {
  params: Promise<{ workspaceId: string }>;
}) {
  const { workspaceId } = await params;
  const actor = await requireWorkspacePageActor(workspaceId);

  return (
    <main className="mx-auto flex max-w-6xl flex-col gap-12 px-6 py-16 lg:px-10">
      <SectionHeading
        eyebrow="Active client portal"
        title={`Workspace ${workspaceId}`}
        description={`Milestones, deliverables, approvals, and feedback sit behind one per-client workspace boundary. Viewing as ${actor.role.replaceAll("_", " ")}.`}
      />

      <section className="grid gap-4 md:grid-cols-3">
        {[
          ["Milestones", "4"],
          ["Deliverables in review", "2"],
          ["Pending approvals", "1"],
        ].map(([label, value]) => (
          <Card key={label} className="space-y-2">
            <CardDescription>{label}</CardDescription>
            <CardTitle className="text-4xl">{value}</CardTitle>
          </Card>
        ))}
      </section>

      <section className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
        <Card className="space-y-5">
          <SectionHeading
            eyebrow="Milestones"
            title="Current delivery cadence"
            description="The portal exposes project health without leaking the internal ops surface."
          />
          {[
            {
              title: "Design system alignment",
              status: "approved",
              description: "Tokens, components, and figure-ground direction locked.",
            },
            {
              title: "Agency cockpit buildout",
              status: "review",
              description: "Internal operations surface is ready for walkthrough.",
            },
            {
              title: "Runtime orchestration service",
              status: "active",
              description: "Mastra workflows and adapters are wired and awaiting credentials.",
            },
          ].map((item) => (
            <div key={item.title} className="rounded-2xl border border-white/8 bg-black/20 p-4">
              <div className="flex items-center justify-between">
                <CardTitle>{item.title}</CardTitle>
                <Badge>{item.status}</Badge>
              </div>
              <CardDescription className="mt-2">{item.description}</CardDescription>
            </div>
          ))}
        </Card>

        <Card className="space-y-5">
          <SectionHeading
            eyebrow="Approvals"
            title="Client actions"
            description="Draft-first communication still ends in a clear approval queue."
          />
          <div className="rounded-2xl border border-[color:var(--accent)]/20 bg-[color:var(--accent)]/8 p-4">
            <CardTitle>Homepage release packet</CardTitle>
            <CardDescription className="mt-2">
              Review the latest design and implementation packet before publishing.
            </CardDescription>
            <div className="mt-4 flex gap-3">
              <Button>Approve</Button>
              <Button variant="secondary">Request changes</Button>
            </div>
          </div>
        </Card>
      </section>
    </main>
  );
}
