import { sanitizeReturnToPath } from "@/lib/access-control";

import { SignUpForm } from "./sign-up-form";

export default async function SignUpPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string | string[] }>;
}) {
  const params = await searchParams;
  const next = Array.isArray(params.next) ? params.next[0] : params.next;
  const callbackURL = sanitizeReturnToPath(next);

  return <SignUpForm callbackURL={callbackURL} />;
}
