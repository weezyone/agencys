"use client";

import Link from "next/link";
import { useState, useTransition } from "react";

import { Button, Card, CardDescription, CardTitle } from "@agency/ui";

import { authClient } from "@/lib/auth-client";

export function SignUpForm({ callbackURL }: { callbackURL: string }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  return (
    <main className="mx-auto flex min-h-[70vh] max-w-xl items-center px-6 py-16">
      <Card className="w-full space-y-6 rounded">
        <div className="space-y-3">
          <CardTitle className="text-3xl">Create your client account</CardTitle>
          <CardDescription>
            New accounts are created through Better Auth and start with the client role until an agency operator assigns workspace access.
          </CardDescription>
        </div>

        <form
          className="space-y-4"
          onSubmit={(event) => {
            event.preventDefault();
            setMessage(null);

            startTransition(async () => {
              const result = await authClient.signUp.email({
                name,
                email,
                password,
                callbackURL,
              });

              setMessage(
                result.error?.message ??
                  "Account created. If your workspace is already assigned, you can continue straight into the portal.",
              );
            });
          }}
        >
          <label className="block space-y-2">
            <span className="text-sm text-[var(--muted-foreground)]">Name</span>
            <input
              className="w-full rounded border border-white/10 bg-black/20 px-4 py-3 outline-none"
              onChange={(event) => setName(event.target.value)}
              required
              type="text"
              value={name}
            />
          </label>
          <label className="block space-y-2">
            <span className="text-sm text-[var(--muted-foreground)]">Email</span>
            <input
              className="w-full rounded border border-white/10 bg-black/20 px-4 py-3 outline-none"
              onChange={(event) => setEmail(event.target.value)}
              required
              type="email"
              value={email}
            />
          </label>
          <label className="block space-y-2">
            <span className="text-sm text-[var(--muted-foreground)]">Password</span>
            <input
              className="w-full rounded border border-white/10 bg-black/20 px-4 py-3 outline-none"
              minLength={8}
              onChange={(event) => setPassword(event.target.value)}
              required
              type="password"
              value={password}
            />
          </label>
          <Button className="w-full rounded" disabled={isPending} type="submit">
            {isPending ? "Creating account..." : "Create account"}
          </Button>
        </form>

        <p className="text-sm text-[var(--muted-foreground)]">
          Already have an account?{" "}
          <Link className="text-white underline decoration-white/30 underline-offset-4" href={`/sign-in?next=${encodeURIComponent(callbackURL)}`}>
            Sign in
          </Link>
        </p>

        {message ? <p className="text-sm text-[var(--muted-foreground)]">{message}</p> : null}
      </Card>
    </main>
  );
}
