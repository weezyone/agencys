"use client";

import Link from "next/link";
import { useState, useTransition } from "react";

import { Button } from "@agency/ui";

import { authClient } from "@/lib/auth-client";

export function AuthNav() {
  const { data: session, isPending } = authClient.useSession();
  const [message, setMessage] = useState<string | null>(null);
  const [isSigningOut, startTransition] = useTransition();

  if (!session?.user) {
    return (
      <>
        <Link href="/sign-up">Sign up</Link>
        <Link href="/sign-in">Sign in</Link>
      </>
    );
  }

  const label = session.user.email ?? session.user.name ?? "Signed in";

  return (
    <div className="flex items-center gap-3">
      <span className="hidden max-w-52 truncate text-xs text-[var(--muted-foreground)] lg:inline">
        {label}
      </span>
      <Button
        className="rounded"
        disabled={isPending || isSigningOut}
        onClick={() => {
          setMessage(null);

          startTransition(async () => {
            const result = await authClient.signOut();

            if (result.error) {
              setMessage(result.error.message ?? "Unable to sign out.");
              return;
            }

            window.location.assign("/sign-in");
          });
        }}
        size="sm"
        type="button"
        variant="secondary"
      >
        {isSigningOut ? "Signing out..." : "Sign out"}
      </Button>
      {message ? <span className="hidden text-xs text-[var(--muted-foreground)] xl:inline">{message}</span> : null}
    </div>
  );
}
