import type { Metadata } from "next";
import { IBM_Plex_Mono, Instrument_Serif, Space_Grotesk } from "next/font/google";
import Link from "next/link";

import { AuthNav } from "./auth-nav";
import "./globals.css";

const sans = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-space-grotesk",
});

const serif = Instrument_Serif({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-instrument-serif",
});

const mono = IBM_Plex_Mono({
  weight: ["400", "500"],
  subsets: ["latin"],
  variable: "--font-ibm-plex-mono",
});

export const metadata: Metadata = {
  title: "Mastra Agency OS",
  description: "Digital design and development agency operating system.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body className={`${sans.variable} ${serif.variable} ${mono.variable}`}>
        <div className="page-shell min-h-screen">
          <header className="sticky top-0 z-30 border-b border-white/8 bg-black/20 backdrop-blur-xl">
            <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-10">
              <Link className="text-sm font-semibold tracking-[0.24em] uppercase" href="/">
                Codex Agency
              </Link>
              <nav className="flex items-center gap-5 text-sm text-[var(--muted-foreground)]">
                <Link href="/agency">Agency OS</Link>
                <Link href="/client/demo-workspace">Client Portal</Link>
                <AuthNav />
              </nav>
            </div>
          </header>
          {children}
        </div>
      </body>
    </html>
  );
}
