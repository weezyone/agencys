import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

describe("HomePage source", () => {
  it("keeps the client portal CTA variant and custom class separate", () => {
    const source = readFileSync(new URL("./page.tsx", import.meta.url), "utf8");

    expect(source).toContain('<Button variant="secondary" className="rounded">View Client Portal</Button>');
  });
});
