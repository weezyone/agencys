import Link from "next/link";
import { ArrowRight, Sparkles, Workflow } from "lucide-react";

import { Badge, Button, Card, CardDescription, CardTitle, SectionHeading } from "@agency/ui";

import { marketingServices, stackBadges, stageRows } from "@/lib/demo-data";

export default function HomePage() {
  return (
    <main className="mx-auto flex max-w-7xl flex-col gap-20 px-6 py-16 lg:px-10 lg:py-24">
      <section className="grid gap-10 lg:grid-cols-[1.35fr_0.9fr] lg:items-end">
        <div className="space-y-8">
          <Badge className="eyebrow">Mastra Agency Operating System</Badge>
          <div className="space-y-6">
            <h1 className="max-w-4xl text-5xl font-semibold tracking-[-0.06em] text-white md:text-7xl">
              Run a design and development agency like a{" "}
              <span className="display-serif text-[color:var(--accent)]">digital crew</span>
              , not a pile of tabs.
            </h1>
            <p className="max-w-2xl text-lg leading-8 text-[var(--muted-foreground)]">
              Internal ops, proposal flow, RAG-backed research, design generation,
              GitHub/Linear delivery, and active-client portal access in one stack.
            </p>
          </div>
          <div className="flex flex-wrap gap-4">
            <Link href="/agency">
              <Button className="gap-2 rounded">
                Open Agency OS
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
            <Link href="/client/demo-workspace">
              <Button variant="secondary" className="rounded">View Client Portal</Button>
            </Link>
          </div>
        </div>

        <Card className="space-y-6 rounded">
          <div className="flex items-center justify-between ">
            <Badge>V1 delivery loop</Badge>
            <Workflow className="h-5 w-5 text-[var(--accent)]" />
          </div>
          <div className="grid gap-4">
            {[
              "Lead intake and qualification",
              "Proposal drafting and scope framing",
              "Client onboarding and workspace provisioning",
              "Delivery orchestration across design and engineering",
              "QA packaging and approval routing",
            ].map((item) => (
              <div
                key={item}
                className="rounded-2xl border border-white/10 bg-black/20 px-4 py-3 text-sm text-[var(--muted-foreground)]"
              >
                {item}
              </div>
            ))}
          </div>
        </Card>
      </section>

      <section className="space-y-8">
        <SectionHeading
          eyebrow="Service modes"
          title="A full-service agency stack with explicit operator boundaries"
          description="Design, research, engineering, and QA agents move work forward autonomously inside the system, while external communication remains draft-first."
        />
        <div className="grid gap-6 lg:grid-cols-3 ">
          {marketingServices.map((service) => (
            <Card key={service.title} className="space-y-4 rounded">
              <Sparkles className="h-5 w-5 text-[var(--accent)]" />
              <CardTitle>{service.title}</CardTitle>
              <CardDescription>{service.description}</CardDescription>
            </Card>
          ))}
        </div>
      </section>

      <section className="space-y-8">
        <SectionHeading
          eyebrow="Stage routing"
          title="Every lifecycle stage maps to a fixed team roster"
          description="This keeps Mastra orchestration deterministic and keeps each agent’s tool surface narrow."
        />
        <div className="grid gap-4 ">
          {stageRows.map((row) => (
            <Card key={row.stage} className="flex flex-col rounded gap-3 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <CardTitle className="capitalize">{row.stage.replaceAll("_", " ")}</CardTitle>
                <CardDescription>Default routing for this workflow stage.</CardDescription>
              </div>
              <div className="flex flex-wrap gap-2">
                {row.roster.map((agent) => (
                  <Badge key={agent} className="border-[color:var(--accent)]/25 text-white">
                    {agent.replaceAll("_", " ")}
                  </Badge>
                ))}
              </div>
            </Card>
          ))}
        </div>
      </section>

      <section className="space-y-6">
        <SectionHeading
          eyebrow="Stack"
          title="Built on the stack you specified"
          description="Everything in this scaffold is organized around a split deploy: Next.js on the app side and a long-running Mastra runtime for orchestration."
        />
        <div className="flex flex-wrap gap-3">
          {stackBadges.map((item) => (
            <Badge key={item}>{item}</Badge>
          ))}
        </div>
      </section>
    </main>
  );
}

