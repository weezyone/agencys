import { existsSync, readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

describe("auth flows source", () => {
  it("mounts shared auth navigation in the app shell", () => {
    const layoutSource = readFileSync(new URL("./layout.tsx", import.meta.url), "utf8");

    expect(layoutSource).toContain('import { AuthNav } from "./auth-nav";');
    expect(layoutSource).toContain("<AuthNav />");
  });

  it("includes dedicated sign-up and sign-out flows", () => {
    const signUpFormPath = new URL("./sign-up/sign-up-form.tsx", import.meta.url);
    const authNavPath = new URL("./auth-nav.tsx", import.meta.url);

    expect(existsSync(signUpFormPath)).toBe(true);
    expect(existsSync(authNavPath)).toBe(true);

    const signUpFormSource = readFileSync(signUpFormPath, "utf8");
    const authNavSource = readFileSync(authNavPath, "utf8");

    expect(signUpFormSource).toContain("authClient.signUp.email");
    expect(authNavSource).toContain("authClient.signOut(");
    expect(authNavSource).toContain('href="/sign-up"');
  });
});
