import { createPreviewSnapshot } from "@agency/db";
import { Badge, Card, CardDescription, CardTitle, SectionHeading } from "@agency/ui";

import { agentRoster, stageRows } from "@/lib/demo-data";
import { requireAgencyPageActor } from "@/lib/server-auth";

export default async function AgencyDashboardPage() {
  const actor = await requireAgencyPageActor();
  const snapshot = createPreviewSnapshot();

  return (
    <main className="mx-auto flex max-w-7xl flex-col gap-14 px-6 py-16 lg:px-10">
      <SectionHeading
        eyebrow="Internal cockpit"
        title="Agency OS"
        description={`Pipeline, workspace, and orchestration visibility for the team running the agency. Signed in as ${actor.role.replaceAll("_", " ")}${actor.email ? ` (${actor.email})` : ""}.`}
      />

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-5">
        {[
          ["Qualified leads", snapshot.leads],
          ["Draft proposals", snapshot.proposals],
          ["Active projects", snapshot.activeProjects],
          ["Pending approvals", snapshot.pendingApprovals],
          ["Open agent runs", snapshot.openAgentRuns],
        ].map(([label, value]) => (
          <Card key={label} className="space-y-2">
            <CardDescription>{label}</CardDescription>
            <CardTitle className="text-4xl">{value}</CardTitle>
          </Card>
        ))}
      </section>

      <section className="grid gap-6 lg:grid-cols-[1.1fr_1fr]">
        <Card className="space-y-6">
          <SectionHeading
            eyebrow="Lifecycle routing"
            title="Stage handoffs"
            description="Each stage keeps a fixed roster so the workflow engine stays explicit."
          />
          <div className="grid gap-4">
            {stageRows.map((row) => (
              <div key={row.stage} className="rounded-2xl border border-white/8 bg-black/20 p-4">
                <div className="flex items-center justify-between">
                  <CardTitle className="capitalize">{row.stage.replaceAll("_", " ")}</CardTitle>
                  <Badge>{row.roster.length} agents</Badge>
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  {row.roster.map((agent) => (
                    <Badge key={agent} className="text-white">
                      {agent.replaceAll("_", " ")}
                    </Badge>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card className="space-y-6">
          <SectionHeading
            eyebrow="Roster"
            title="Specialist agents"
            description="Every role carries a distinct goal and a controlled tool perimeter."
          />
          <div className="grid gap-4">
            {agentRoster.map((agent) => (
              <div key={agent.id} className="rounded-2xl border border-white/8 bg-black/20 p-4">
                <div className="flex items-center justify-between gap-3">
                  <CardTitle>{agent.label}</CardTitle>
                  <Badge>{agent.role}</Badge>
                </div>
                <CardDescription className="mt-2">{agent.description}</CardDescription>
                <p className="mt-3 text-sm text-white/85">{agent.goal}</p>
              </div>
            ))}
          </div>
        </Card>
      </section>
    </main>
  );
}
