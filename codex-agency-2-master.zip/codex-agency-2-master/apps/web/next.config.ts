import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  transpilePackages: [
    "@agency/agents",
    "@agency/db",
    "@agency/integrations",
    "@agency/schemas",
    "@agency/ui",
  ],
};

export default nextConfig;
