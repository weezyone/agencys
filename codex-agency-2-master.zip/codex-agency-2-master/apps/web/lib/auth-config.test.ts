import { afterEach, describe, expect, it, vi } from "vitest";
import type { Lead } from "@agency/schemas";

import { emailAndPasswordConfig, userAdditionalFields } from "./auth-config";

const sampleLead: Lead = {
  id: "lead_alpha",
  source: "website",
  company: "Acme Co",
  contactName: "Taylor",
  contactEmail: "taylor@example.com",
  needs: ["design system"],
  status: "new",
  tags: [],
  createdAt: "2026-03-10T00:00:00.000Z",
  updatedAt: "2026-03-10T00:00:00.000Z",
};

describe("auth-config", () => {
  afterEach(() => {
    vi.restoreAllMocks();
    vi.resetModules();
    vi.unstubAllEnvs();
    vi.unstubAllGlobals();
  });

  it("keeps public email/password sign-up enabled for client onboarding", () => {
    expect(emailAndPasswordConfig.enabled).toBe(true);
    expect(emailAndPasswordConfig.disableSignUp).toBe(false);
  });

  it("defaults new users to the least-privileged client role", () => {
    expect(userAdditionalFields.role.defaultValue).toBe("client");
    expect(userAdditionalFields.role.input).toBe(false);
  });

  it("throws a runtime_unavailable error when the runtime base URL is missing", async () => {
    vi.stubEnv("RUNTIME_BASE_URL", "");

    const { qualifyLead } = await import("./runtime-client");

    await expect(qualifyLead(sampleLead)).rejects.toMatchObject({
      code: "runtime_unavailable",
      statusCode: 503,
    });
  });

  it("throws a runtime_unavailable error when the runtime responds with a non-OK status", async () => {
    vi.stubEnv("RUNTIME_BASE_URL", "http://runtime.internal");
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue({
        ok: false,
        status: 502,
      }),
    );

    const { generateProposal } = await import("./runtime-client");

    await expect(
      generateProposal({
        leadId: "lead_alpha",
        clientWorkspaceId: "workspace_alpha",
        objectives: ["launch site"],
      }),
    ).rejects.toMatchObject({
      code: "runtime_unavailable",
      statusCode: 503,
    });
  });

  it("serializes infrastructure failures into a structured 503 response", async () => {
    const { InfrastructureError, createInfrastructureErrorResponse } = await import("./infrastructure");

    const response = createInfrastructureErrorResponse(
      new InfrastructureError({
        code: "runtime_unavailable",
        message: "Mastra runtime is unavailable.",
      }),
    );

    expect(response.status).toBe(503);
    await expect(response.json()).resolves.toEqual({
      ok: false,
      code: "runtime_unavailable",
      error: "Mastra runtime is unavailable.",
      retryable: true,
    });
  });
});
