export const trustedOrigins = [process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000"];

export const emailAndPasswordConfig = {
  enabled: true,
  disableSignUp: false,
} as const;

export const userAdditionalFields = {
  role: {
    type: "string",
    required: false,
    defaultValue: "client",
    input: false,
  },
  clientWorkspaceId: {
    type: "string",
    required: false,
    input: false,
  },
} as const;
