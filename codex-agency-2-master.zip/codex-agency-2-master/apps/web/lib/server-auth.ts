import { type NextRequest, NextResponse } from "next/server";
import { headers as nextHeaders } from "next/headers";
import { notFound, redirect } from "next/navigation";

import {
  AccessDeniedError,
  normalizeActor,
  requireAgencyConsoleAccess,
  requireInternalMutationAccess,
  requireWorkspaceAccess,
  type AgencyActor,
} from "@/lib/access-control";
import { getAuthSession } from "@/lib/auth";
import {
  createInfrastructureErrorResponse,
  isInfrastructureError,
} from "@/lib/infrastructure";

export async function getCurrentActor(): Promise<AgencyActor | null> {
  const requestHeaders = await nextHeaders();
  return getActorFromHeaders(new Headers(requestHeaders));
}

export async function requireAgencyPageActor(nextPath = "/agency"): Promise<AgencyActor> {
  try {
    return requireAgencyConsoleAccess(await getCurrentActor());
  } catch (error) {
    return handlePageAccessError(error, nextPath);
  }
}

export async function requireWorkspacePageActor(
  clientWorkspaceId: string,
): Promise<AgencyActor> {
  try {
    return requireWorkspaceAccess(
      await getCurrentActor(),
      clientWorkspaceId,
    );
  } catch (error) {
    return handlePageAccessError(error, `/client/${clientWorkspaceId}`);
  }
}

export async function requireInternalApiActor(
  request: NextRequest,
): Promise<AgencyActor> {
  return requireInternalMutationAccess(await getActorFromHeaders(request.headers));
}

export function createApiErrorResponse(error: unknown) {
  if (error instanceof AccessDeniedError) {
    if (error.kind === "sign_in") {
      return NextResponse.json({ error: "Authentication required." }, { status: 401 });
    }

    if (error.kind === "forbidden") {
      return NextResponse.json({ error: "Forbidden." }, { status: 403 });
    }

    return NextResponse.json({ error: "Not found." }, { status: 404 });
  }

  if (isInfrastructureError(error)) {
    return createInfrastructureErrorResponse(error);
  }

  throw error;
}

async function getActorFromHeaders(headers: Headers): Promise<AgencyActor | null> {
  const session = await getAuthSession(headers);
  return normalizeActor(session);
}

function handlePageAccessError(error: unknown, nextPath: string): never {
  if (error instanceof AccessDeniedError) {
    if (error.kind === "sign_in") {
      redirect(`/sign-in?next=${encodeURIComponent(nextPath)}`);
    }

    notFound();
  }

  throw error;
}