import { NextResponse } from "next/server";

export type InfrastructureErrorCode = "runtime_unavailable" | "persistence_unavailable";

export class InfrastructureError extends Error {
  readonly code: InfrastructureErrorCode;
  readonly statusCode: number;
  readonly retryable: boolean;
  readonly cause?: unknown;

  constructor(input: {
    code: InfrastructureErrorCode;
    message: string;
    statusCode?: number;
    retryable?: boolean;
    cause?: unknown;
  }) {
    super(input.message);
    this.name = "InfrastructureError";
    this.code = input.code;
    this.statusCode = input.statusCode ?? 503;
    this.retryable = input.retryable ?? true;
    this.cause = input.cause;
  }
}

export function isInfrastructureError(error: unknown): error is InfrastructureError {
  return error instanceof InfrastructureError;
}

export function createInfrastructureErrorResponse(error: InfrastructureError) {
  return NextResponse.json(
    {
      ok: false,
      code: error.code,
      error: error.message,
      retryable: error.retryable,
    },
    { status: error.statusCode },
  );
}