import { betterAuth } from "better-auth";
import { mongodbAdapter } from "better-auth/adapters/mongodb";
import { nextCookies } from "better-auth/next-js";
import { organization } from "better-auth/plugins/organization";
import { MongoClient } from "mongodb";

import {
  emailAndPasswordConfig,
  trustedOrigins,
  userAdditionalFields,
} from "@/lib/auth-config";

const mongoClient = new MongoClient(
  process.env.MONGODB_URL ?? "mongodb://127.0.0.1:27017",
);
const database = mongoClient.db(process.env.MONGODB_DB_NAME ?? "codex_agency");

export const auth = betterAuth({
  appName: "Mastra Agency OS",
  baseURL: process.env.BETTER_AUTH_URL,
  secret: process.env.BETTER_AUTH_SECRET,
  trustedOrigins,
  database: mongodbAdapter(database),
  emailAndPassword: emailAndPasswordConfig,
  user: {
    additionalFields: userAdditionalFields,
  },
  plugins: [organization(), nextCookies()],
});

export interface AuthSessionShape {
  session?: {
    id?: string | null;
  } | null;
  user?: {
    id?: string | null;
    email?: string | null;
    name?: string | null;
    role?: string | null;
    clientWorkspaceId?: string | null;
  } | null;
}

const getSession = auth.api.getSession as (input: {
  headers: Headers;
}) => Promise<AuthSessionShape | null>;

export async function getAuthSession(headers: Headers): Promise<AuthSessionShape | null> {
  return getSession({ headers });
}
