import { createAgencyRepositories } from "@agency/db";

import { InfrastructureError } from "./infrastructure";

export async function getOptionalRepositories() {
  try {
    return await createAgencyRepositories();
  } catch {
    return null;
  }
}

export async function getRequiredRepositories() {
  try {
    return await createAgencyRepositories();
  } catch (cause) {
    throw new InfrastructureError({
      code: "persistence_unavailable",
      message: "MongoDB persistence is unavailable.",
      cause,
    });
  }
}
