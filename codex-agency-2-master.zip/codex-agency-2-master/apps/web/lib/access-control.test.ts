import { afterEach, describe, expect, it, vi } from "vitest";
import type { Lead } from "@agency/schemas";

import {
  AccessDeniedError,
  canAccessAgencyConsole,
  canAccessWorkspace,
  normalizeActor,
  requireAgencyConsoleAccess,
  requireInternalMutationAccess,
  requireWorkspaceAccess,
  sanitizeReturnToPath,
} from "./access-control";

const sampleLead: Lead = {
  id: "lead_alpha",
  source: "website",
  company: "Acme Co",
  contactName: "Taylor",
  contactEmail: "taylor@example.com",
  needs: ["design system"],
  status: "new",
  tags: [],
  createdAt: "2026-03-10T00:00:00.000Z",
  updatedAt: "2026-03-10T00:00:00.000Z",
};

describe("access-control", () => {
  afterEach(() => {
    vi.restoreAllMocks();
    vi.resetModules();
  });

  it("defaults unknown roles to the least-privileged client role", () => {
    const actor = normalizeActor({
      session: { id: "session_1" },
      user: {
        id: "user_1",
        email: "owner@example.com",
        role: "not-a-real-role",
      },
    });

    expect(actor).toMatchObject({
      id: "user_1",
      role: "client",
      clientWorkspaceId: null,
      sessionId: "session_1",
    });
  });

  it("allows agency operators into the internal cockpit", () => {
    const actor = normalizeActor({
      session: { id: "session_1" },
      user: {
        id: "user_1",
        role: "agency_owner",
      },
    });
    expect(actor).not.toBeNull();

    expect(canAccessAgencyConsole(actor!)).toBe(true);
    expect(requireAgencyConsoleAccess(actor)).toEqual(actor);
  });

  it("blocks client users from the internal cockpit", () => {
    const actor = normalizeActor({
      session: { id: "session_1" },
      user: {
        id: "user_1",
        role: "client",
        clientWorkspaceId: "workspace_alpha",
      },
    });
    expect(actor).not.toBeNull();

    expect(canAccessAgencyConsole(actor!)).toBe(false);
    expect(() => requireAgencyConsoleAccess(actor)).toThrowError(AccessDeniedError);
    expect(() => requireAgencyConsoleAccess(actor)).toThrowError("not_found");
  });

  it("allows client users into only their own workspace", () => {
    const actor = normalizeActor({
      session: { id: "session_1" },
      user: {
        id: "user_1",
        role: "client",
        clientWorkspaceId: "workspace_alpha",
      },
    });
    expect(actor).not.toBeNull();

    expect(canAccessWorkspace(actor!, "workspace_alpha")).toBe(true);
    expect(canAccessWorkspace(actor!, "workspace_beta")).toBe(false);
    expect(requireWorkspaceAccess(actor, "workspace_alpha")).toEqual(actor);
    expect(() => requireWorkspaceAccess(actor, "workspace_beta")).toThrowError("not_found");
  });

  it("keeps internal mutation routes closed to client users", () => {
    const actor = normalizeActor({
      session: { id: "session_1" },
      user: {
        id: "user_1",
        role: "client",
        clientWorkspaceId: "workspace_alpha",
      },
    });
    expect(actor).not.toBeNull();

    expect(() => requireInternalMutationAccess(actor)).toThrowError(AccessDeniedError);
    expect(() => requireInternalMutationAccess(actor)).toThrowError("forbidden");
  });

  it("requires sign-in before granting any protected access", () => {
    expect(() => requireAgencyConsoleAccess(null)).toThrowError("sign_in");
    expect(() => requireWorkspaceAccess(null, "workspace_alpha")).toThrowError("sign_in");
    expect(() => requireInternalMutationAccess(null)).toThrowError("sign_in");
  });

  it("sanitizes return paths so sign-in cannot become an open redirect", () => {
    expect(sanitizeReturnToPath("/client/workspace_alpha")).toBe("/client/workspace_alpha");
    expect(sanitizeReturnToPath(undefined)).toBe("/agency");
    expect(sanitizeReturnToPath("https://evil.example")).toBe("/agency");
    expect(sanitizeReturnToPath("//evil.example")).toBe("/agency");
    expect(sanitizeReturnToPath("agency")).toBe("/agency");
  });

  it("throws a persistence_unavailable error when write repositories cannot be created", async () => {
    const dbModule = await import("@agency/db");
    vi.spyOn(dbModule, "createAgencyRepositories").mockRejectedValueOnce(new Error("mongo offline"));

    const { getRequiredRepositories } = await import("./database");

    await expect(getRequiredRepositories()).rejects.toMatchObject({
      code: "persistence_unavailable",
      statusCode: 503,
    });
  });

  it("upserts leads by logical id so repeated intake does not duplicate the record", async () => {
    const { createLeadRepository } = await import("@agency/db");
    const updateOne = vi.fn().mockResolvedValue(undefined);
    const insertOne = vi.fn().mockResolvedValue(undefined);
    const db = {
      collection: vi.fn().mockReturnValue({
        updateOne,
        insertOne,
      }),
    };

    const repository = createLeadRepository(db as never);

    await repository.create(sampleLead);

    expect(updateOne).toHaveBeenCalledWith(
      { id: sampleLead.id },
      { $set: sampleLead },
      { upsert: true },
    );
    expect(insertOne).not.toHaveBeenCalled();
  });
});