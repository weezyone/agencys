import { AgencyRoleSchema, type AgencyRole } from "@agency/schemas";

export interface SessionShape {
  session?: {
    id?: string | null;
  } | null;
  user?: {
    id?: string | null;
    email?: string | null;
    name?: string | null;
    role?: unknown;
    clientWorkspaceId?: unknown;
  } | null;
}

export interface AgencyActor {
  id: string;
  email: string | null;
  name: string | null;
  role: AgencyRole;
  clientWorkspaceId: string | null;
  sessionId: string | null;
}

export type AccessFailureKind = "sign_in" | "forbidden" | "not_found";

export class AccessDeniedError extends Error {
  constructor(public readonly kind: AccessFailureKind) {
    super(kind);
    this.name = "AccessDeniedError";
  }
}

export function normalizeActor(session: SessionShape | null | undefined): AgencyActor | null {
  const userId = toNonEmptyString(session?.user?.id);

  if (!userId) {
    return null;
  }

  return {
    id: userId,
    email: toNonEmptyString(session?.user?.email),
    name: toNonEmptyString(session?.user?.name),
    role: normalizeRole(session?.user?.role),
    clientWorkspaceId: toNonEmptyString(session?.user?.clientWorkspaceId),
    sessionId: toNonEmptyString(session?.session?.id),
  };
}

export function canAccessAgencyConsole(actor: AgencyActor): boolean {
  return actor.role !== "client";
}

export function canAccessWorkspace(
  actor: AgencyActor,
  clientWorkspaceId: string,
): boolean {
  return canAccessAgencyConsole(actor) || actor.clientWorkspaceId === clientWorkspaceId;
}

export function canAccessInternalMutations(actor: AgencyActor): boolean {
  return canAccessAgencyConsole(actor);
}

export function requireAgencyConsoleAccess(
  actor: AgencyActor | null,
): AgencyActor {
  if (!actor) {
    throw new AccessDeniedError("sign_in");
  }

  if (!canAccessAgencyConsole(actor)) {
    throw new AccessDeniedError("not_found");
  }

  return actor;
}

export function requireWorkspaceAccess(
  actor: AgencyActor | null,
  clientWorkspaceId: string,
): AgencyActor {
  if (!actor) {
    throw new AccessDeniedError("sign_in");
  }

  if (!canAccessWorkspace(actor, clientWorkspaceId)) {
    throw new AccessDeniedError("not_found");
  }

  return actor;
}

export function requireInternalMutationAccess(
  actor: AgencyActor | null,
): AgencyActor {
  if (!actor) {
    throw new AccessDeniedError("sign_in");
  }

  if (!canAccessInternalMutations(actor)) {
    throw new AccessDeniedError("forbidden");
  }

  return actor;
}

export function sanitizeReturnToPath(path: string | null | undefined): string {
  if (!path || !path.startsWith("/") || path.startsWith("//")) {
    return "/agency";
  }

  try {
    const url = new URL(path, "https://agency.local");

    if (url.origin !== "https://agency.local") {
      return "/agency";
    }

    return `${url.pathname}${url.search}${url.hash}`;
  } catch {
    return "/agency";
  }
}

function normalizeRole(value: unknown): AgencyRole {
  const result = AgencyRoleSchema.safeParse(value);
  return result.success ? result.data : "client";
}

function toNonEmptyString(value: unknown): string | null {
  return typeof value === "string" && value.length > 0 ? value : null;
}
