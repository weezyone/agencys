import { AGENT_BLUEPRINTS, STAGE_ROSTERS } from "@agency/agents";

export const marketingServices = [
  {
    title: "Proposal-to-production pods",
    description:
      "Spin up design, research, engineering, and QA pods from one accepted proposal.",
  },
  {
    title: "Draft-first client comms",
    description:
      "Agents prepare every proposal, onboarding note, and portal update without auto-sending.",
  },
  {
    title: "RAG-backed execution!",
    description:
      "Research and delivery decisions stay grounded in proposals, client docs, GitHub, Linear, and Figma.",
  },
];

export const stackBadges = [
  "Mastra",
  "Next.js App Router",
  "Tailwind CSS",
  "shadcn/ui patterns",
  "MongoDB Atlas",
  "Better Auth",
  "GitHub MCP",
  "Linear MCP",
  "Figma MCP",
  "Stitch MCP",
  "Recraft API",
];

export const stageRows = Object.entries(STAGE_ROSTERS).map(([stage, roster]) => ({
  stage,
  roster,
}));

export const agentRoster = Object.values(AGENT_BLUEPRINTS);
