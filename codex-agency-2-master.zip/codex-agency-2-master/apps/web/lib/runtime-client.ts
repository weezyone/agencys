import type {
  AgentRun,
  DraftMessage,
  KnowledgeDocument,
  Lead,
  Opportunity,
  PortalApproval,
  Project,
  Proposal,
  WorkItem,
} from "@agency/schemas";

import { InfrastructureError } from "./infrastructure";

const RUNTIME_UNAVAILABLE_MESSAGE = "Mastra runtime is unavailable.";

export async function qualifyLead(lead: Lead) {
  return callRuntime<Lead, {
    lead: Lead;
    opportunity: Opportunity;
    agentOutput: AgentOutputShape;
    run: AgentRun;
  }>("/workflows/lead-qualification", lead);
}

export async function generateProposal(input: {
  leadId: string;
  clientWorkspaceId: string;
  objectives: string[];
  budgetCeilingUsd?: number | undefined;
}) {
  return callRuntime<typeof input, {
    proposal: Proposal;
    agentOutput: AgentOutputShape;
    run: AgentRun;
  }>("/workflows/proposal-generation", input);
}

export async function kickoffOnboarding(input: {
  proposalId: string;
  clientWorkspaceId: string;
  projectName: string;
}) {
  return callRuntime<typeof input, {
    project: Project;
    kickoffMessage: DraftMessage;
    agentOutput: AgentOutputShape;
    run: AgentRun;
  }>("/workflows/client-onboarding", input);
}

export async function syncProject(input: {
  clientWorkspaceId: string;
  projectId: string;
  linearProjectId?: string | undefined;
  githubRepo?: string | undefined;
}) {
  return callRuntime<typeof input, {
    workItems: WorkItem[];
    agentOutput: AgentOutputShape;
    run: AgentRun;
  }>("/workflows/delivery-orchestration", input);
}

export async function publishArtifacts(input: {
  clientWorkspaceId: string;
  deliverableId: string;
  artifactIds: string[];
}) {
  return callRuntime<typeof input, {
    approval: PortalApproval;
    agentOutput: AgentOutputShape;
    run: AgentRun;
  }>("/workflows/qa-release", input);
}

export async function ingestKnowledge(input: {
  clientWorkspaceId?: string | undefined;
  source: string;
  title: string;
  body: string;
  citationUrl?: string | undefined;
  tags?: string[] | undefined;
}) {
  return callRuntime<typeof input, {
    documents: KnowledgeDocument[];
    agentOutput: AgentOutputShape;
    run: AgentRun;
  }>("/knowledge/ingest", input);
}

export async function replayAgentRun(runId: string, notes?: string) {
  return callRuntime<{ notes?: string }, {
    replayed: boolean;
    runId: string;
    notes: string | null;
  }>(`/agent-runs/${runId}/replay`, notes ? { notes } : {});
}

async function callRuntime<TInput, TOutput>(path: string, input: TInput) {
  const runtimeBaseUrl = process.env.RUNTIME_BASE_URL;

  if (!runtimeBaseUrl) {
    throw new InfrastructureError({
      code: "runtime_unavailable",
      message: RUNTIME_UNAVAILABLE_MESSAGE,
    });
  }

  let response: Response;

  try {
    response = await fetch(`${runtimeBaseUrl}${path}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(input),
      cache: "no-store",
    });
  } catch (cause) {
    throw new InfrastructureError({
      code: "runtime_unavailable",
      message: RUNTIME_UNAVAILABLE_MESSAGE,
      cause,
    });
  }

  if (!response.ok) {
    throw new InfrastructureError({
      code: "runtime_unavailable",
      message: RUNTIME_UNAVAILABLE_MESSAGE,
      cause: new Error(`Runtime responded with status ${response.status}.`),
    });
  }

  return (await response.json()) as TOutput;
}

type AgentOutputShape = {
  summary: string;
  status: AgentRun["status"];
  citations: Array<{
    label: string;
    source: string;
    excerpt?: string;
  }>;
  nextActions: Array<{
    id: string;
    title: string;
    owner?: string;
  }>;
  artifacts: Array<{
    id: string;
    type: string;
    title: string;
    url?: string;
    description?: string;
  }>;
  risks: Array<{
    label: string;
    severity: string;
    mitigation: string;
  }>;
};

