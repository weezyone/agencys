import { createAgencyRepositories } from "@agency/db";
import {
  AgentRunReplayInputSchema,
  ArtifactPublishInputSchema,
  KnowledgeIngestInputSchema,
  LeadSchema,
  OnboardingKickoffInputSchema,
  ProjectSyncInputSchema,
  ProposalGenerationInputSchema,
} from "@agency/schemas";
import { Hono } from "hono";
import { z } from "zod";
import type { AnyWorkflow } from "@mastra/core/workflows";

import { buildResearchBrief, ingestKnowledge, ResearchBriefInputSchema } from "./research/rag-service";
import { agencyWorkflows } from "./runtime/mastra";

export function createApp() {
  const app = new Hono();

  app.get("/health", (c) =>
    c.json({
      ok: true,
      workflows: Object.keys(agencyWorkflows),
    }),
  );

  app.post("/workflows/lead-qualification", async (c) => {
    const input = LeadSchema.parse(await c.req.json());
    const result = await runWorkflow(
      agencyWorkflows.leadQualificationWorkflow,
      input,
      input.clientWorkspaceId,
    );
    await persistRun(result.run);
    return c.json(result);
  });

  app.post("/workflows/proposal-generation", async (c) => {
    const input = ProposalGenerationInputSchema.parse(await c.req.json());
    const result = await runWorkflow(
      agencyWorkflows.proposalGenerationWorkflow,
      input,
      input.clientWorkspaceId,
    );
    await persistProposalResult(result);
    return c.json(result);
  });

  app.post("/workflows/client-onboarding", async (c) => {
    const input = OnboardingKickoffInputSchema.parse(await c.req.json());
    const result = await runWorkflow(
      agencyWorkflows.clientOnboardingWorkflow,
      input,
      input.clientWorkspaceId,
    );
    await persistOnboardingResult(result);
    return c.json(result);
  });

  app.post("/workflows/delivery-orchestration", async (c) => {
    const input = ProjectSyncInputSchema.parse(await c.req.json());
    const result = await runWorkflow(
      agencyWorkflows.deliveryOrchestrationWorkflow,
      input,
      input.clientWorkspaceId,
    );
    await persistRun(result.run);
    return c.json(result);
  });

  app.post("/workflows/qa-release", async (c) => {
    const input = ArtifactPublishInputSchema.parse(await c.req.json());
    const result = await runWorkflow(
      agencyWorkflows.qaReleaseWorkflow,
      input,
      input.clientWorkspaceId,
    );
    await persistRun(result.run);
    return c.json(result);
  });

  app.post("/knowledge/ingest", async (c) => {
    const input = KnowledgeIngestInputSchema.parse(await c.req.json());
    return c.json(await ingestKnowledge(input));
  });

  app.post("/research/brief", async (c) => {
    const input = ResearchBriefInputSchema.parse(await c.req.json());
    return c.json(await buildResearchBrief(input));
  });

  app.post("/agent-runs/:runId/replay", async (c) => {
    const payload = AgentRunReplayInputSchema.parse({
      runId: c.req.param("runId"),
      ...(await safeJson(c)),
    });

    const repositories = await createAgencyRepositories();
    const existingRun = await repositories.agentRuns.getById(payload.runId);

    return c.json({
      replayed: Boolean(existingRun),
      runId: payload.runId,
      notes: payload.notes ?? null,
    });
  });

  return app;
}

async function runWorkflow(
  workflow: AnyWorkflow,
  input: unknown,
  clientWorkspaceId?: string,
) {
  const run = await workflow.createRun(
    clientWorkspaceId ? { resourceId: clientWorkspaceId } : undefined,
  );
  const result = await run.start({ inputData: input as never });

  if (result.status !== "success") {
    throw "error" in result
      ? result.error
      : new Error(`Workflow exited with status ${result.status}.`);
  }

  return result.result;
}

async function persistProposalResult(result: {
  proposal: z.infer<typeof ProposalGenerationInputSchema> | Record<string, unknown>;
  run: { id: string };
}) {
  const repositories = await createAgencyRepositories();
  await repositories.proposals.saveDraft(result.proposal as never);
  await repositories.agentRuns.record(result.run as never);
}

async function persistOnboardingResult(result: {
  project: z.infer<typeof ProjectSyncInputSchema> | Record<string, unknown>;
  run: { id: string };
}) {
  const repositories = await createAgencyRepositories();
  await repositories.projects.save(result.project as never);
  await repositories.agentRuns.record(result.run as never);
}

async function persistRun(run: { id: string }) {
  const repositories = await createAgencyRepositories();
  await repositories.agentRuns.record(run as never);
}

async function safeJson(c: { req: { json: () => Promise<unknown> } }) {
  try {
    return (await c.req.json()) as Record<string, unknown>;
  } catch {
    return {};
  }
}