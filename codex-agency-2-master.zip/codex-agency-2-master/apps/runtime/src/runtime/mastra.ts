import { AGENT_BLUEPRINTS } from "@agency/agents";
import { openai } from "@ai-sdk/openai";
import { Agent } from "@mastra/core/agent";
import { Mastra } from "@mastra/core/mastra";

import { clientOnboardingWorkflow } from "./workflows/client-onboarding";
import { deliveryOrchestrationWorkflow } from "./workflows/delivery-orchestration";
import { leadQualificationWorkflow } from "./workflows/lead-qualification";
import { proposalGenerationWorkflow } from "./workflows/proposal-generation";
import { qaReleaseWorkflow } from "./workflows/qa-release";

const sharedModel = openai("gpt-4.1-mini");

export const agencyAgents = Object.fromEntries(
  Object.values(AGENT_BLUEPRINTS).map((blueprint) => [
    blueprint.id,
    new Agent({
      id: blueprint.id,
      name: blueprint.label,
      description: blueprint.description,
      instructions: `You are the ${blueprint.label}. Goal: ${blueprint.goal} Tools: ${blueprint.toolScopes.join(", ")}.`,
      model: sharedModel,
    }),
  ]),
);

export const agencyWorkflows = {
  leadQualificationWorkflow,
  proposalGenerationWorkflow,
  clientOnboardingWorkflow,
  deliveryOrchestrationWorkflow,
  qaReleaseWorkflow,
};

export const mastra = new Mastra({
  agents: agencyAgents,
  workflows: agencyWorkflows,
});
