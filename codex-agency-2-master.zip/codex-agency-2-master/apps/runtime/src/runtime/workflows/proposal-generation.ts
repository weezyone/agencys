import { createStep, createWorkflow } from "@mastra/core/workflows";
import {
  AgentOutputSchema,
  AgentRunSchema,
  ProposalGenerationInputSchema,
  ProposalSchema,
  type Proposal,
} from "@agency/schemas";
import { z } from "zod";

import { createAgentRunRecord, createId, createOutput, nowIso } from "../helpers";

export const ProposalGenerationResultSchema = z.object({
  proposal: ProposalSchema,
  agentOutput: AgentOutputSchema,
  run: AgentRunSchema,
});

export async function draftProposal(input: z.infer<typeof ProposalGenerationInputSchema>) {
  const proposal: Proposal = ProposalSchema.parse({
    id: createId("proposal"),
    clientWorkspaceId: input.clientWorkspaceId,
    leadId: input.leadId,
    summary: `Proposal covering ${input.objectives.join(", ")} for a full-service delivery engagement.`,
    status: "draft",
    priceUsd: input.budgetCeilingUsd ?? input.objectives.length * 9000,
    timelineWeeks: Math.max(4, input.objectives.length * 2),
    deliverables: input.objectives.map((objective) => `Agency deliverable: ${objective}`),
    createdAt: nowIso(),
    updatedAt: nowIso(),
  });

  const agentOutput = createOutput({
    summary: `Drafted a proposal for workspace ${input.clientWorkspaceId} with scope, timeline, and deliverables ready for founder review.`,
    citations: [
      {
        label: "Proposal objectives",
        source: "proposal_generation",
        excerpt: input.objectives.join(", "),
      },
    ],
    nextActions: [
      {
        id: createId("action"),
        title: "Review pricing and convert the proposal into a client-facing draft.",
        owner: "pm",
      },
    ],
    artifacts: [
      {
        id: createId("artifact"),
        type: "proposal",
        title: "Proposal draft",
        description: proposal.summary,
      },
    ],
  });

  return {
    proposal,
    agentOutput,
    run: createAgentRunRecord({
      clientWorkspaceId: input.clientWorkspaceId,
      workflow: "proposal_generation",
      stage: "proposal",
      summary: agentOutput.summary,
    }),
  };
}

const generateProposalStep = createStep({
  id: "generate_proposal",
  inputSchema: ProposalGenerationInputSchema,
  outputSchema: ProposalGenerationResultSchema,
  execute: async ({ inputData }) => draftProposal(inputData),
});

export const proposalGenerationWorkflow = createWorkflow({
  id: "proposal_generation",
  inputSchema: ProposalGenerationInputSchema,
  outputSchema: ProposalGenerationResultSchema,
  description: "Generates a scoped proposal draft from a qualified opportunity.",
})
  .then(generateProposalStep)
  .commit();
