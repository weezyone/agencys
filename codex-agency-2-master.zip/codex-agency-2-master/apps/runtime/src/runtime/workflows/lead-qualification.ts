import { createStep, createWorkflow } from "@mastra/core/workflows";
import {
  AgentOutputSchema,
  AgentRunSchema,
  LeadSchema,
  OpportunitySchema,
  type Lead,
} from "@agency/schemas";
import { z } from "zod";

import { createAgentRunRecord, createId, createOutput, nowIso } from "../helpers";

export const LeadQualificationResultSchema = z.object({
  lead: LeadSchema,
  opportunity: OpportunitySchema,
  agentOutput: AgentOutputSchema,
  run: AgentRunSchema,
});

export async function draftLeadQualification(lead: Lead) {
  const closeProbability = Math.min(85, 40 + lead.needs.length * 10 + (lead.score ?? 10));
  const opportunity = OpportunitySchema.parse({
    id: createId("opp"),
    leadId: lead.id,
    clientWorkspaceId: lead.clientWorkspaceId,
    stage: "proposal",
    valueUsd: 12000 + lead.needs.length * 6000,
    closeProbability,
    notes: `Qualified from ${lead.source} with ${lead.needs.length} active needs.`,
    createdAt: nowIso(),
    updatedAt: nowIso(),
  });

  const agentOutput = createOutput({
    summary: `Lead ${lead.company} is qualified for proposal shaping with a ${closeProbability}% close estimate.`,
    citations: [
      {
        label: "Lead intake",
        source: lead.source,
        excerpt: `${lead.company} requested ${lead.needs.join(", ")}.`,
      },
    ],
    nextActions: [
      {
        id: createId("action"),
        title: "Generate a proposal brief and discovery agenda.",
        owner: "sales",
      },
    ],
    risks: lead.needs.length > 3
      ? [
          {
            label: "Scope spread",
            severity: "medium",
            mitigation: "Split brand, design, and delivery into explicit workstreams.",
          },
        ]
      : [],
  });

  return {
    lead,
    opportunity,
    agentOutput,
    run: createAgentRunRecord({
      clientWorkspaceId: lead.clientWorkspaceId,
      workflow: "lead_qualification",
      stage: "lead_generation",
      summary: agentOutput.summary,
    }),
  };
}

const qualifyLeadStep = createStep({
  id: "qualify_lead",
  inputSchema: LeadSchema,
  outputSchema: LeadQualificationResultSchema,
  execute: async ({ inputData }) => draftLeadQualification(inputData),
});

export const leadQualificationWorkflow = createWorkflow({
  id: "lead_qualification",
  inputSchema: LeadSchema,
  outputSchema: LeadQualificationResultSchema,
  description: "Qualifies inbound or outbound leads for proposal generation.",
})
  .then(qualifyLeadStep)
  .commit();
