import { createStep, createWorkflow } from "@mastra/core/workflows";
import {
  AgentOutputSchema,
  AgentRunSchema,
  ProjectSyncInputSchema,
  WorkItemSchema,
} from "@agency/schemas";
import { z } from "zod";

import { createAgentRunRecord, createId, createOutput } from "../helpers";

export const DeliveryOrchestrationResultSchema = z.object({
  workItems: z.array(WorkItemSchema),
  agentOutput: AgentOutputSchema,
  run: AgentRunSchema,
});

export async function draftDeliveryOrchestration(
  input: z.infer<typeof ProjectSyncInputSchema>,
) {
  const workItems = [
    WorkItemSchema.parse({
      id: createId("work"),
      clientWorkspaceId: input.clientWorkspaceId,
      projectId: input.projectId,
      externalId: input.linearProjectId ? `linear:${input.linearProjectId}` : undefined,
      title: "Create project architecture brief",
      summary: "Tech lead frames system boundaries and integration risks.",
      status: "todo",
      source: input.linearProjectId ? "linear" : "internal",
      labels: ["architecture", "kickoff"],
    }),
    WorkItemSchema.parse({
      id: createId("work"),
      clientWorkspaceId: input.clientWorkspaceId,
      projectId: input.projectId,
      externalId: input.githubRepo ? `github:${input.githubRepo}` : undefined,
      title: "Prepare design handoff starter set",
      summary: "Design and frontend agents align component inventory.",
      status: "todo",
      source: input.githubRepo ? "github" : "internal",
      labels: ["design", "frontend"],
    }),
  ];

  const agentOutput = createOutput({
    summary: `Queued the first delivery work items for project ${input.projectId}.`,
    citations: [
      {
        label: "Project sync",
        source: input.projectId,
        excerpt: `Linear: ${input.linearProjectId ?? "pending"}, GitHub: ${input.githubRepo ?? "pending"}`,
      },
    ],
    nextActions: [
      {
        id: createId("action"),
        title: "Assign work items across design, frontend, and backend tracks.",
        owner: "tech_lead",
      },
    ],
    artifacts: [
      {
        id: createId("artifact"),
        type: "brief",
        title: "Delivery orchestration plan",
        description: "Initial milestone stack for the project team.",
      },
    ],
  });

  return {
    workItems,
    agentOutput,
    run: createAgentRunRecord({
      clientWorkspaceId: input.clientWorkspaceId,
      workflow: "delivery_orchestration",
      stage: "delivery",
      summary: agentOutput.summary,
    }),
  };
}

const deliveryStep = createStep({
  id: "delivery_orchestration",
  inputSchema: ProjectSyncInputSchema,
  outputSchema: DeliveryOrchestrationResultSchema,
  execute: async ({ inputData }) => draftDeliveryOrchestration(inputData),
});

export const deliveryOrchestrationWorkflow = createWorkflow({
  id: "delivery_orchestration",
  inputSchema: ProjectSyncInputSchema,
  outputSchema: DeliveryOrchestrationResultSchema,
  description: "Queues delivery work across the engineering and design team.",
})
  .then(deliveryStep)
  .commit();
