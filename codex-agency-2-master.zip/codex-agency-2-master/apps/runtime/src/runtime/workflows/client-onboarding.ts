import { createStep, createWorkflow } from "@mastra/core/workflows";
import {
  AgentOutputSchema,
  AgentRunSchema,
  DraftMessageSchema,
  OnboardingKickoffInputSchema,
  ProjectSchema,
} from "@agency/schemas";
import { z } from "zod";

import { createAgentRunRecord, createId, createOutput, nowIso } from "../helpers";

export const ClientOnboardingResultSchema = z.object({
  project: ProjectSchema,
  kickoffMessage: DraftMessageSchema,
  agentOutput: AgentOutputSchema,
  run: AgentRunSchema,
});

export async function draftClientOnboarding(
  input: z.infer<typeof OnboardingKickoffInputSchema>,
) {
  const project = ProjectSchema.parse({
    id: createId("project"),
    clientWorkspaceId: input.clientWorkspaceId,
    name: input.projectName,
    status: "planning",
    summary: "Freshly provisioned project with kickoff artifacts and starter milestones.",
    createdAt: nowIso(),
    updatedAt: nowIso(),
  });

  const kickoffMessage = DraftMessageSchema.parse({
    id: createId("draft"),
    clientWorkspaceId: input.clientWorkspaceId,
    channel: "portal",
    audience: "client",
    subject: `Kickoff plan for ${input.projectName}`,
    body: "We have provisioned your workspace, drafted the first milestones, and queued the delivery team.",
    status: "draft",
    createdAt: nowIso(),
  });

  const agentOutput = createOutput({
    summary: `Workspace ${input.clientWorkspaceId} is provisioned and ready for kickoff.`,
    citations: [
      {
        label: "Accepted proposal",
        source: input.proposalId,
        excerpt: "Client onboarding initiated from accepted proposal.",
      },
    ],
    nextActions: [
      {
        id: createId("action"),
        title: "Create Linear project and GitHub repository mirror.",
        owner: "pm",
      },
    ],
    artifacts: [
      {
        id: createId("artifact"),
        type: "brief",
        title: "Kickoff packet",
        description: "Portal kickoff summary and internal project frame.",
      },
    ],
  });

  return {
    project,
    kickoffMessage,
    agentOutput,
    run: createAgentRunRecord({
      clientWorkspaceId: input.clientWorkspaceId,
      workflow: "client_onboarding",
      stage: "onboarding",
      summary: agentOutput.summary,
    }),
  };
}

const onboardingStep = createStep({
  id: "client_onboarding",
  inputSchema: OnboardingKickoffInputSchema,
  outputSchema: ClientOnboardingResultSchema,
  execute: async ({ inputData }) => draftClientOnboarding(inputData),
});

export const clientOnboardingWorkflow = createWorkflow({
  id: "client_onboarding",
  inputSchema: OnboardingKickoffInputSchema,
  outputSchema: ClientOnboardingResultSchema,
  description: "Provisions a client workspace into a project-ready state.",
})
  .then(onboardingStep)
  .commit();
