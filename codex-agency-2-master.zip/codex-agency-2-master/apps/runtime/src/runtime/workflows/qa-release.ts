import { createStep, createWorkflow } from "@mastra/core/workflows";
import {
  AgentOutputSchema,
  AgentRunSchema,
  ArtifactPublishInputSchema,
  PortalApprovalSchema,
} from "@agency/schemas";
import { z } from "zod";

import { createAgentRunRecord, createId, createOutput, nowIso } from "../helpers";

export const QaReleaseResultSchema = z.object({
  approval: PortalApprovalSchema,
  agentOutput: AgentOutputSchema,
  run: AgentRunSchema,
});

export async function draftQaRelease(
  input: z.infer<typeof ArtifactPublishInputSchema>,
) {
  const approval = PortalApprovalSchema.parse({
    id: createId("approval"),
    clientWorkspaceId: input.clientWorkspaceId,
    deliverableId: input.deliverableId,
    status: "pending",
    requestedAt: nowIso(),
  });

  const agentOutput = createOutput({
    summary: `QA packaged ${input.artifactIds.length} artifacts and created a client approval request.`,
    citations: [
      {
        label: "Release packet",
        source: input.deliverableId,
        excerpt: `${input.artifactIds.length} artifacts prepared for review.`,
      },
    ],
    nextActions: [
      {
        id: createId("action"),
        title: "Publish the approval packet to the client portal.",
        owner: "qa",
      },
    ],
    artifacts: [
      {
        id: createId("artifact"),
        type: "approval_packet",
        title: "Client approval packet",
        description: "QA summary, artifact list, and release notes.",
      },
    ],
  });

  return {
    approval,
    agentOutput,
    run: createAgentRunRecord({
      clientWorkspaceId: input.clientWorkspaceId,
      workflow: "qa_release",
      stage: "qa_release",
      summary: agentOutput.summary,
    }),
  };
}

const qaReleaseStep = createStep({
  id: "qa_release",
  inputSchema: ArtifactPublishInputSchema,
  outputSchema: QaReleaseResultSchema,
  execute: async ({ inputData }) => draftQaRelease(inputData),
});

export const qaReleaseWorkflow = createWorkflow({
  id: "qa_release",
  inputSchema: ArtifactPublishInputSchema,
  outputSchema: QaReleaseResultSchema,
  description: "Packages release notes and client approval artifacts after QA.",
})
  .then(qaReleaseStep)
  .commit();
