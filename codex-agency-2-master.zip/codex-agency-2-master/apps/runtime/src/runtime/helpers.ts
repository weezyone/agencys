import { buildAgentOutput, getStageRoster } from "@agency/agents";
import {
  type AgentOutput,
  type AgentRun,
  type AgencyRole,
  type AgencyStage,
} from "@agency/schemas";

export function createId(prefix: string) {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
}

export function nowIso() {
  return new Date().toISOString();
}

export function createAgentRunRecord(input: {
  clientWorkspaceId?: string | undefined;
  workflow: string;
  stage: AgencyStage;
  summary: string;
  status?: AgentRun["status"] | undefined;
  toolTraces?: AgentRun["toolTraces"] | undefined;
  costUsd?: number | undefined;
}): AgentRun {
  const primaryAgentId = getStageRoster(input.stage)[0] ?? "project_manager";

  return {
    id: createId("run"),
    agentId: primaryAgentId,
    workflow: input.workflow,
    stage: input.stage,
    status: input.status ?? "completed",
    summary: input.summary,
    costUsd: input.costUsd ?? 0,
    toolTraces: input.toolTraces ?? [],
    startedAt: nowIso(),
    finishedAt: nowIso(),
    ...(input.clientWorkspaceId ? { clientWorkspaceId: input.clientWorkspaceId } : {}),
  };
}

export function createOutput(input: {
  summary: string;
  status?: AgentOutput["status"];
  citations: AgentOutput["citations"];
  nextActions: AgentOutput["nextActions"];
  artifacts?: AgentOutput["artifacts"];
  risks?: AgentOutput["risks"];
}): AgentOutput {
  return buildAgentOutput({
    summary: input.summary,
    status: input.status ?? "completed",
    citations: input.citations,
    nextActions: input.nextActions,
    artifacts: input.artifacts ?? [],
    risks: input.risks ?? [],
  });
}

export function stageOwner(stage: AgencyStage): AgencyRole {
  switch (stage) {
    case "lead_generation":
      return "sales";
    case "proposal":
      return "pm";
    case "onboarding":
      return "pm";
    case "delivery":
      return "tech_lead";
    case "qa_release":
      return "qa";
  }
}
