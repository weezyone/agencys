import { z } from "zod";

const RuntimeEnvSchema = z.object({
  PORT: z.coerce.number().default(4111),
  MONGODB_URL: z.string().optional(),
  MONGODB_DB_NAME: z.string().default("codex_agency"),
  MONGODB_VECTOR_INDEX_NAME: z.string().default("knowledge_embedding"),
  OPENAI_API_KEY: z.string().optional(),
  GITHUB_MCP_URL: z.string().optional(),
  GITHUB_MCP_TOKEN: z.string().optional(),
  LINEAR_MCP_URL: z.string().optional(),
  LINEAR_MCP_TOKEN: z.string().optional(),
  FIGMA_MCP_URL: z.string().optional(),
  FIGMA_MCP_TOKEN: z.string().optional(),
  STITCH_MCP_URL: z.string().optional(),
  STITCH_MCP_TOKEN: z.string().optional(),
  RECRAFT_API_URL: z.string().default("https://external.api.recraft.ai/v1"),
  RECRAFT_API_KEY: z.string().optional(),
});

export function getRuntimeEnv() {
  return RuntimeEnvSchema.parse(process.env);
}
