import { createAgencyRepositories } from "@agency/db";
import {
  AgentOutputSchema,
  AgentRunSchema,
  type KnowledgeDocument,
  KnowledgeDocumentSchema,
  KnowledgeIngestInputSchema,
} from "@agency/schemas";
import { z } from "zod";

import { createAgentRunRecord, createId, createOutput, nowIso } from "../runtime/helpers";

export const ResearchBriefInputSchema = z.object({
  clientWorkspaceId: z.string().optional(),
  query: z.string().min(3),
});

export const KnowledgeIngestResultSchema = z.object({
  documents: z.array(KnowledgeDocumentSchema),
  agentOutput: AgentOutputSchema,
  run: AgentRunSchema,
});

export const ResearchBriefResultSchema = z.object({
  brief: z.string(),
  documents: z.array(KnowledgeDocumentSchema),
  agentOutput: AgentOutputSchema,
  run: AgentRunSchema,
});

export async function ingestKnowledge(
  input: z.infer<typeof KnowledgeIngestInputSchema>,
) {
  const documents = await createKnowledgeChunks(input);
  const repositories = await createAgencyRepositories();
  await repositories.knowledge.ingestMany(documents);

  const agentOutput = createOutput({
    summary: `Ingested ${documents.length} knowledge chunks for ${input.source}.`,
    citations: [
      {
        label: input.title,
        source: input.source,
        excerpt: input.body.slice(0, 160),
      },
    ],
    nextActions: [
      {
        id: createId("action"),
        title: "Re-run a research brief so the new knowledge is queryable.",
        owner: "research",
      },
    ],
    artifacts: [
      {
        id: createId("artifact"),
        type: "document",
        title: input.title,
        description: `${documents.length} chunk(s) stored for retrieval.`,
      },
    ],
  });

  return {
    documents,
    agentOutput,
    run: createAgentRunRecord({
      clientWorkspaceId: input.clientWorkspaceId,
      workflow: "knowledge_ingest",
      stage: "delivery",
      summary: agentOutput.summary,
    }),
  };
}

export async function buildResearchBrief(
  input: z.infer<typeof ResearchBriefInputSchema>,
) {
  const repositories = await loadOptionalRepositories();
  const documents = repositories
    ? await repositories.knowledge.searchByWorkspace({
        limit: 6,
        ...(input.clientWorkspaceId
          ? { clientWorkspaceId: input.clientWorkspaceId }
          : {}),
      })
    : [];

  const selectedDocuments = documents.filter((document) =>
    matchesQuery(document, input.query),
  );

  const context = selectedDocuments.length ? selectedDocuments : documents;
  const brief = context.length
    ? `Research brief for "${input.query}": ${context
        .slice(0, 3)
        .map((document) => `${document.title} -> ${document.body.slice(0, 120)}`)
        .join(" | ")}`
    : `Research brief for "${input.query}": no stored context yet, rely on GitHub, Linear, and Figma ingestion next.`;

  const agentOutput = createOutput({
    summary: `Compiled a cited research brief for "${input.query}".`,
    citations: (context.length ? context : [
      {
        id: createId("doc"),
        source: "agency_playbook",
        title: "Knowledge gap",
        body: "No indexed workspace material matched the query yet.",
        chunkIndex: 0,
        tags: ["gap"],
        createdAt: nowIso(),
      },
    ]).map((document) => ({
      label: document.title,
      source: document.source,
      excerpt: document.body.slice(0, 140),
    })),
    nextActions: [
      {
        id: createId("action"),
        title: "Ingest fresh client, GitHub, or Linear context if the brief feels thin.",
        owner: "research",
      },
    ],
  });

  return {
    brief,
    documents: context,
    agentOutput,
    run: createAgentRunRecord({
      clientWorkspaceId: input.clientWorkspaceId,
      workflow: "research_brief",
      stage: "delivery",
      summary: agentOutput.summary,
    }),
  };
}

async function createKnowledgeChunks(
  input: z.infer<typeof KnowledgeIngestInputSchema>,
) {
  const chunks = chunkText(input.body);

  return chunks.map(
    (chunk, index): KnowledgeDocument =>
      KnowledgeDocumentSchema.parse({
        id: createId("doc"),
        clientWorkspaceId: input.clientWorkspaceId,
        source: input.source,
        title: input.title,
        body: chunk,
        chunkIndex: index,
        citationUrl: input.citationUrl,
        tags: input.tags,
        createdAt: nowIso(),
      }),
  );
}

function chunkText(body: string, chunkSize = 700) {
  const normalized = body.replace(/\s+/g, " ").trim();

  if (normalized.length <= chunkSize) {
    return [normalized];
  }

  const chunks: string[] = [];

  for (let index = 0; index < normalized.length; index += chunkSize) {
    chunks.push(normalized.slice(index, index + chunkSize));
  }

  return chunks;
}

function matchesQuery(document: KnowledgeDocument, query: string) {
  const haystack = `${document.title} ${document.body} ${document.tags.join(" ")}`.toLowerCase();
  const terms = query.toLowerCase().split(/\s+/).filter(Boolean);

  return terms.some((term) => haystack.includes(term));
}

async function loadOptionalRepositories() {
  try {
    return await createAgencyRepositories();
  } catch {
    return null;
  }
}