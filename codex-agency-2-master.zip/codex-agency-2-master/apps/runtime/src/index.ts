import { serve } from "@hono/node-server";

import { getRuntimeEnv } from "./config";
import { createApp } from "./server";

const env = getRuntimeEnv();
const app = createApp();

serve(
  {
    fetch: app.fetch,
    port: env.PORT,
  },
  (info) => {
    console.log(`Mastra runtime listening on http://localhost:${info.port}`);
  },
);
