import { describe, expect, it } from "vitest";

import {
  canExecuteAction,
  getStageRoster,
  resolveWorkspacePolicy,
} from "./index";

describe("agent policies", () => {
  it("keeps external communication in draft mode by default", () => {
    const policy = resolveWorkspacePolicy({
      clientWorkspaceId: "workspace_001",
    });

    expect(
      canExecuteAction(policy, {
        action: "send_external_message",
        actorRole: "sales",
      }),
    ).toBe(false);
  });

  it("routes delivery execution through the engineering team", () => {
    expect(getStageRoster("delivery")).toEqual([
      "project_manager",
      "research_agent",
      "frontend_agent",
      "backend_agent",
      "tech_lead_agent",
      "qa_agent",
    ]);
  });
});
