import {
  type AgentOutput,
  AgentOutputSchema,
  type AgencyRole,
  type AgencyStage,
} from "@agency/schemas";

export type AgentIdentifier =
  | "project_manager"
  | "design_agent"
  | "research_agent"
  | "frontend_agent"
  | "backend_agent"
  | "tech_lead_agent"
  | "qa_agent"
  | "lead_finder_agent"
  | "lead_nurture_agent"
  | "client_onboarding_agent";

export type AgencyAction =
  | "send_external_message"
  | "merge_pull_request"
  | "deploy_production"
  | "delete_artifact"
  | "publish_client_artifact"
  | "sync_linear_state"
  | "sync_github_issue";

export interface AgentBlueprint {
  id: AgentIdentifier;
  label: string;
  role: AgencyRole;
  stageFocus: AgencyStage[];
  description: string;
  toolScopes: string[];
  goal: string;
}

export interface WorkspacePolicy {
  clientWorkspaceId: string;
  allowExternalSend: boolean;
  allowProductionDeploy: boolean;
  allowDestructiveTooling: boolean;
  disabledActions: AgencyAction[];
}

export const AGENT_BLUEPRINTS: Record<AgentIdentifier, AgentBlueprint> = {
  project_manager: {
    id: "project_manager",
    label: "Project Manager",
    role: "pm",
    stageFocus: ["proposal", "onboarding", "delivery", "qa_release"],
    description: "Owns the workflow state, milestones, and delivery plan.",
    toolScopes: ["linear", "github", "portal", "documents"],
    goal: "Keep execution aligned with scope, quality, and client expectations.",
  },
  design_agent: {
    id: "design_agent",
    label: "Design Agent",
    role: "design",
    stageFocus: ["proposal", "delivery"],
    description: "Generates concepts, systems, and UI directions.",
    toolScopes: ["recraft", "figma", "stitch", "assets"],
    goal: "Produce design work that moves from concept to build-ready handoff.",
  },
  research_agent: {
    id: "research_agent",
    label: "Research Agent",
    role: "research",
    stageFocus: ["lead_generation", "proposal", "delivery"],
    description: "Builds source-backed briefs from agency and client knowledge.",
    toolScopes: ["rag", "web", "github", "linear", "figma"],
    goal: "Ground every major decision in cited context.",
  },
  frontend_agent: {
    id: "frontend_agent",
    label: "Frontend Agent",
    role: "frontend",
    stageFocus: ["delivery"],
    description: "Implements client-facing experiences and component systems.",
    toolScopes: ["github", "figma", "stitch"],
    goal: "Ship polished frontend work that matches the design language.",
  },
  backend_agent: {
    id: "backend_agent",
    label: "Backend Agent",
    role: "backend",
    stageFocus: ["delivery"],
    description: "Owns APIs, persistence, integrations, and runtime plumbing.",
    toolScopes: ["github", "linear", "database"],
    goal: "Build reliable backend changes with clear operational boundaries.",
  },
  tech_lead_agent: {
    id: "tech_lead_agent",
    label: "Tech Lead Agent",
    role: "tech_lead",
    stageFocus: ["proposal", "delivery", "qa_release"],
    description: "Reviews architecture, code quality, and release readiness.",
    toolScopes: ["github", "linear", "architecture"],
    goal: "Challenge weak assumptions before they become delivery risk.",
  },
  qa_agent: {
    id: "qa_agent",
    label: "QA Agent",
    role: "qa",
    stageFocus: ["delivery", "qa_release"],
    description: "Runs checks, validates flows, and reports regressions.",
    toolScopes: ["github", "tests", "portal"],
    goal: "Keep defects from reaching the client portal or production.",
  },
  lead_finder_agent: {
    id: "lead_finder_agent",
    label: "Lead Finder",
    role: "sales",
    stageFocus: ["lead_generation"],
    description: "Finds inbound and outbound opportunities worth qualifying.",
    toolScopes: ["crm", "web", "research"],
    goal: "Keep the top of funnel full of promising opportunities.",
  },
  lead_nurture_agent: {
    id: "lead_nurture_agent",
    label: "Lead Nurture",
    role: "sales",
    stageFocus: ["lead_generation", "proposal"],
    description: "Prepares outreach, follow-up, and discovery drafts.",
    toolScopes: ["crm", "drafts", "research"],
    goal: "Move qualified leads toward a proposal decision.",
  },
  client_onboarding_agent: {
    id: "client_onboarding_agent",
    label: "Client Onboarding",
    role: "pm",
    stageFocus: ["onboarding"],
    description: "Sets up workspaces, rituals, and starter artifacts.",
    toolScopes: ["portal", "documents", "linear", "github"],
    goal: "Turn accepted proposals into execution-ready projects fast.",
  },
};

export const STAGE_ROSTERS: Record<AgencyStage, AgentIdentifier[]> = {
  lead_generation: ["lead_finder_agent", "lead_nurture_agent", "research_agent"],
  proposal: [
    "project_manager",
    "research_agent",
    "design_agent",
    "tech_lead_agent",
  ],
  onboarding: ["project_manager", "client_onboarding_agent", "research_agent"],
  delivery: [
    "project_manager",
    "research_agent",
    "frontend_agent",
    "backend_agent",
    "tech_lead_agent",
    "qa_agent",
  ],
  qa_release: ["project_manager", "qa_agent", "tech_lead_agent"],
};

export function getStageRoster(stage: AgencyStage): AgentIdentifier[] {
  return STAGE_ROSTERS[stage];
}

export function resolveWorkspacePolicy(input: {
  clientWorkspaceId: string;
  allowExternalSend?: boolean;
  allowProductionDeploy?: boolean;
  allowDestructiveTooling?: boolean;
  disabledActions?: AgencyAction[];
}): WorkspacePolicy {
  return {
    clientWorkspaceId: input.clientWorkspaceId,
    allowExternalSend: input.allowExternalSend ?? false,
    allowProductionDeploy: input.allowProductionDeploy ?? false,
    allowDestructiveTooling: input.allowDestructiveTooling ?? false,
    disabledActions: input.disabledActions ?? [],
  };
}

export function canExecuteAction(
  policy: WorkspacePolicy,
  input: {
    action: AgencyAction;
    actorRole: AgencyRole;
  },
): boolean {
  if (policy.disabledActions.includes(input.action)) {
    return false;
  }

  if (input.action === "send_external_message") {
    return policy.allowExternalSend && input.actorRole !== "client";
  }

  if (input.action === "deploy_production") {
    return policy.allowProductionDeploy && input.actorRole !== "client";
  }

  if (input.action === "delete_artifact") {
    return policy.allowDestructiveTooling && input.actorRole !== "client";
  }

  return true;
}

export function buildWorkspaceMemoryScope(
  clientWorkspaceId: string,
  scope: "global" | "sales" | "delivery" | "portal" = "delivery",
): string {
  return `client:${clientWorkspaceId}:${scope}`;
}

export function buildAgentOutput(input: AgentOutput): AgentOutput {
  return AgentOutputSchema.parse(input);
}
