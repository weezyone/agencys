import {
  type AgentRun,
  AgentRunSchema,
  type ClientWorkspace,
  ClientWorkspaceSchema,
  type KnowledgeDocument,
  KnowledgeDocumentSchema,
  type Lead,
  LeadSchema,
  type Project,
  ProjectSchema,
  type Proposal,
  ProposalSchema,
} from "@agency/schemas";
import { Db, MongoClient, type OptionalUnlessRequiredId } from "mongodb";

const COLLECTIONS = {
  leads: "leads",
  proposals: "proposals",
  workspaces: "client_workspaces",
  projects: "projects",
  knowledge: "knowledge_documents",
  agentRuns: "agent_runs",
} as const;

let cachedClient: MongoClient | undefined;

export async function getMongoClient(connectionString = process.env.MONGODB_URL) {
  if (!connectionString) {
    throw new Error("MONGODB_URL is required.");
  }

  if (!cachedClient) {
    cachedClient = new MongoClient(connectionString);
    await cachedClient.connect();
  }

  return cachedClient;
}

export async function getAgencyDb(databaseName = process.env.MONGODB_DB_NAME) {
  if (!databaseName) {
    throw new Error("MONGODB_DB_NAME is required.");
  }

  const client = await getMongoClient();
  return client.db(databaseName);
}

export function buildWorkspaceFilter(clientWorkspaceId?: string) {
  return clientWorkspaceId ? { clientWorkspaceId } : {};
}

export function createLeadRepository(db: Db) {
  const collection = db.collection<Lead>(COLLECTIONS.leads);

  return {
    async create(lead: Lead) {
      const record = LeadSchema.parse(lead);
      await collection.updateOne(
        { id: record.id },
        { $set: record },
        { upsert: true },
      );
      return record;
    },
    async listRecent(limit = 20) {
      return collection.find().sort({ createdAt: -1 }).limit(limit).toArray();
    },
  };
}

export function createProposalRepository(db: Db) {
  const collection = db.collection<Proposal>(COLLECTIONS.proposals);

  return {
    async saveDraft(proposal: Proposal) {
      const record = ProposalSchema.parse(proposal);
      await collection.updateOne(
        { id: record.id },
        { $set: record },
        { upsert: true },
      );
      return record;
    },
    async listByWorkspace(clientWorkspaceId: string) {
      return collection.find({ clientWorkspaceId }).toArray();
    },
  };
}

export function createWorkspaceRepository(db: Db) {
  const collection = db.collection<ClientWorkspace>(COLLECTIONS.workspaces);

  return {
    async provision(workspace: ClientWorkspace) {
      const record = ClientWorkspaceSchema.parse(workspace);
      await collection.updateOne(
        { id: record.id },
        { $set: record },
        { upsert: true },
      );
      return record;
    },
    async getById(id: string) {
      return collection.findOne({ id });
    },
  };
}

export function createProjectRepository(db: Db) {
  const collection = db.collection<Project>(COLLECTIONS.projects);

  return {
    async save(project: Project) {
      const record = ProjectSchema.parse(project);
      await collection.updateOne({ id: record.id }, { $set: record }, { upsert: true });
      return record;
    },
    async listByWorkspace(clientWorkspaceId: string) {
      return collection.find({ clientWorkspaceId }).toArray();
    },
  };
}

export function createKnowledgeRepository(db: Db) {
  const collection = db.collection<KnowledgeDocument>(COLLECTIONS.knowledge);

  return {
    async ingestMany(documents: KnowledgeDocument[]) {
      const records = documents.map((document) =>
        KnowledgeDocumentSchema.parse(document),
      );

      if (!records.length) {
        return [];
      }

      await collection.insertMany(records as OptionalUnlessRequiredId<KnowledgeDocument>[]);
      return records;
    },
    async searchByWorkspace(input: {
      clientWorkspaceId?: string;
      tags?: string[];
      limit?: number;
    }) {
      const limit = input.limit ?? 8;
      const cursor = collection.find({
        ...buildWorkspaceFilter(input.clientWorkspaceId),
        ...(input.tags?.length ? { tags: { $in: input.tags } } : {}),
      });

      return cursor.sort({ createdAt: -1 }).limit(limit).toArray();
    },
  };
}

export function createAgentRunRepository(db: Db) {
  const collection = db.collection<AgentRun>(COLLECTIONS.agentRuns);

  return {
    async record(run: AgentRun) {
      const record = AgentRunSchema.parse(run);
      await collection.updateOne({ id: record.id }, { $set: record }, { upsert: true });
      return record;
    },
    async getById(id: string) {
      return collection.findOne({ id });
    },
  };
}

export async function createAgencyRepositories() {
  const db = await getAgencyDb();

  return {
    db,
    leads: createLeadRepository(db),
    proposals: createProposalRepository(db),
    workspaces: createWorkspaceRepository(db),
    projects: createProjectRepository(db),
    knowledge: createKnowledgeRepository(db),
    agentRuns: createAgentRunRepository(db),
  };
}

export function createPreviewSnapshot() {
  return {
    leads: 18,
    proposals: 5,
    activeProjects: 4,
    pendingApprovals: 3,
    openAgentRuns: 6,
  };
}

