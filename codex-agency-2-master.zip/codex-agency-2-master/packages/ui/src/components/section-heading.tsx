import * as React from "react";

import { cn } from "../lib/utils";

export function SectionHeading({
  eyebrow,
  title,
  description,
  className,
}: {
  eyebrow: string;
  title: string;
  description: string;
  className?: string;
}) {
  return (
    <div className={cn("space-y-3", className)}>
      <p className="text-xs font-medium uppercase tracking-[0.28em] text-[var(--muted-foreground)]">
        {eyebrow}
      </p>
      <h2 className="text-3xl font-semibold tracking-[-0.04em] text-white md:text-4xl">
        {title}
      </h2>
      <p className="max-w-2xl text-sm leading-7 text-[var(--muted-foreground)] md:text-base">
        {description}
      </p>
    </div>
  );
}
