import {
  type NormalizedExternalWorkItem,
  NormalizedExternalWorkItemSchema,
  type Proposal,
} from "@agency/schemas";

export interface McpBridgeConfig {
  baseUrl?: string | undefined;
  token?: string | undefined;
  namespace: string;
}

export interface RecraftConfig {
  baseUrl?: string | undefined;
  apiKey?: string | undefined;
}

export class IntegrationError extends Error {
  constructor(
    message: string,
    public readonly integration: string,
    public readonly cause?: unknown,
  ) {
    super(message);
    this.name = "IntegrationError";
  }
}

export class McpBridgeClient {
  constructor(private readonly config: McpBridgeConfig) {}

  async invokeTool<TInput, TOutput>(
    tool: string,
    input: TInput,
  ): Promise<TOutput> {
    if (!this.config.baseUrl) {
      throw new IntegrationError(
        "MCP bridge URL is not configured.",
        this.config.namespace,
      );
    }

    const response = await fetch(`${this.config.baseUrl}/tools/${tool}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(this.config.token
          ? { Authorization: `Bearer ${this.config.token}` }
          : {}),
      },
      body: JSON.stringify(input),
    });

    if (!response.ok) {
      throw new IntegrationError(
        `MCP tool ${tool} failed with ${response.status}.`,
        this.config.namespace,
      );
    }

    return (await response.json()) as TOutput;
  }
}

export class GitHubMcpAdapter {
  constructor(private readonly client: McpBridgeClient) {}

  draftPullRequestReview(input: {
    repo: string;
    branch: string;
    summary: string;
  }) {
    return this.client.invokeTool<typeof input, { reviewPlan: string }>(
      "github.reviewDraft",
      input,
    );
  }

  syncRepositoryContext(input: { repo: string; issueNumber: number }) {
    return this.client.invokeTool<
      typeof input,
      { summary: string; labels: string[] }
    >("github.syncContext", input);
  }
}

export class LinearMcpAdapter {
  constructor(private readonly client: McpBridgeClient) {}

  createProjectFromProposal(input: {
    proposal: Proposal;
    kickoffSummary: string;
  }) {
    return this.client.invokeTool<
      typeof input,
      { projectId: string; issueIds: string[] }
    >("linear.createProjectFromProposal", input);
  }

  syncIssueSummary(input: { issueId: string; summary: string }) {
    return this.client.invokeTool<typeof input, { ok: boolean }>(
      "linear.syncIssueSummary",
      input,
    );
  }
}

export class FigmaMcpAdapter {
  constructor(private readonly client: McpBridgeClient) {}

  captureDesignContext(input: { fileKey: string; nodeId: string }) {
    return this.client.invokeTool<
      typeof input,
      { screenshotUrl?: string; referenceCode?: string; assetUrls?: string[] }
    >("figma.getDesignContext", input);
  }

  getCodeConnectMap(input: { fileKey: string; nodeId: string }) {
    return this.client.invokeTool<typeof input, Record<string, string>>(
      "figma.getCodeConnectMap",
      input,
    );
  }
}

export class StitchMcpAdapter {
  constructor(private readonly client: McpBridgeClient) {}

  generateUiDraft(input: {
    prompt: string;
    clientWorkspaceId: string;
    references?: string[];
  }) {
    return this.client.invokeTool<
      typeof input,
      { title: string; code: string; previewUrl?: string }
    >("stitch.generateUiDraft", input);
  }
}

export class RecraftApiClient {
  constructor(private readonly config: RecraftConfig) {}

  async generateDesignElement(input: {
    prompt: string;
    style: string;
    aspectRatio?: string;
  }): Promise<{ id?: string; imageUrl?: string; raw: unknown }> {
    if (!this.config.baseUrl || !this.config.apiKey) {
      throw new IntegrationError(
        "Recraft API credentials are not configured.",
        "recraft",
      );
    }

    const response = await fetch(`${this.config.baseUrl}/images/generations`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${this.config.apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        prompt: input.prompt,
        style: input.style,
        aspect_ratio: input.aspectRatio ?? "1:1",
      }),
    });

    if (!response.ok) {
      throw new IntegrationError(
        `Recraft generation failed with ${response.status}.`,
        "recraft",
      );
    }

    const payload = (await response.json()) as Record<string, unknown>;

    return {
      ...(typeof payload.id === "string" ? { id: payload.id } : {}),
      ...(typeof payload.image_url === "string"
        ? { imageUrl: payload.image_url }
        : {}),
      raw: payload,
    };
  }
}

export function normalizeGithubIssue(input: {
  number: number;
  title: string;
  html_url: string;
  body?: string | null;
  state: "open" | "closed";
  labels?: Array<{ name?: string }>;
}): NormalizedExternalWorkItem {
  return NormalizedExternalWorkItemSchema.parse({
    id: `github-${input.number}`,
    externalId: `github:${input.number}`,
    title: input.title,
    summary: input.body ?? undefined,
    status: input.state === "closed" ? "done" : "in_progress",
    source: "github",
    labels: (input.labels ?? [])
      .map((label) => label.name)
      .filter((label): label is string => Boolean(label)),
    url: input.html_url,
  });
}

export function normalizeLinearIssue(input: {
  identifier: string;
  title: string;
  description?: string | null;
  url: string;
  state?: { type?: string | null } | null;
  labels?: { nodes?: Array<{ name?: string | null }> } | null;
}): NormalizedExternalWorkItem {
  return NormalizedExternalWorkItemSchema.parse({
    id: `linear-${input.identifier}`,
    externalId: `linear:${input.identifier}`,
    title: input.title,
    summary: input.description ?? undefined,
    status: mapLinearState(input.state?.type),
    source: "linear",
    labels: (input.labels?.nodes ?? [])
      .map((label) => label.name ?? undefined)
      .filter((label): label is string => Boolean(label)),
    url: input.url,
  });
}

function mapLinearState(value?: string | null): NormalizedExternalWorkItem["status"] {
  switch (value) {
    case "completed":
      return "done";
    case "canceled":
    case "blocked":
      return "blocked";
    case "started":
    case "inProgress":
      return "in_progress";
    case "backlog":
      return "backlog";
    default:
      return "todo";
  }
}

export function createAgencyIntegrationsFromEnv(env: {
  GITHUB_MCP_URL?: string;
  GITHUB_MCP_TOKEN?: string;
  LINEAR_MCP_URL?: string;
  LINEAR_MCP_TOKEN?: string;
  FIGMA_MCP_URL?: string;
  FIGMA_MCP_TOKEN?: string;
  STITCH_MCP_URL?: string;
  STITCH_MCP_TOKEN?: string;
  RECRAFT_API_URL?: string;
  RECRAFT_API_KEY?: string;
}) {
  return {
    github: new GitHubMcpAdapter(
      new McpBridgeClient({
        baseUrl: env.GITHUB_MCP_URL,
        token: env.GITHUB_MCP_TOKEN,
        namespace: "github",
      }),
    ),
    linear: new LinearMcpAdapter(
      new McpBridgeClient({
        baseUrl: env.LINEAR_MCP_URL,
        token: env.LINEAR_MCP_TOKEN,
        namespace: "linear",
      }),
    ),
    figma: new FigmaMcpAdapter(
      new McpBridgeClient({
        baseUrl: env.FIGMA_MCP_URL,
        token: env.FIGMA_MCP_TOKEN,
        namespace: "figma",
      }),
    ),
    stitch: new StitchMcpAdapter(
      new McpBridgeClient({
        baseUrl: env.STITCH_MCP_URL,
        token: env.STITCH_MCP_TOKEN,
        namespace: "stitch",
      }),
    ),
    recraft: new RecraftApiClient({
      baseUrl: env.RECRAFT_API_URL,
      apiKey: env.RECRAFT_API_KEY,
    }),
  };
}
