import { describe, expect, it } from "vitest";

import {
  normalizeGithubIssue,
  normalizeLinearIssue,
} from "./index";

describe("integration normalizers", () => {
  it("normalizes GitHub issue payloads into work items", () => {
    const item = normalizeGithubIssue({
      number: 42,
      title: "Wire dashboard card states",
      html_url: "https://github.com/example/repo/issues/42",
      body: "Need loading, empty, and error states.",
      state: "open",
      labels: [{ name: "frontend" }],
    });

    expect(item.externalId).toBe("github:42");
    expect(item.labels).toEqual(["frontend"]);
  });

  it("normalizes Linear issue payloads into work items", () => {
    const item = normalizeLinearIssue({
      identifier: "ENG-101",
      title: "Create onboarding workflow",
      description: "Provision workspace and starter artifacts",
      url: "https://linear.app/example/issue/ENG-101",
      state: {
        type: "started",
      },
      labels: {
        nodes: [{ name: "automation" }],
      },
    });

    expect(item.externalId).toBe("linear:ENG-101");
    expect(item.status).toBe("in_progress");
  });
});
