import { z } from "zod";

const TimestampSchema = z.string().min(1);

export const AgencyRoleSchema = z.enum([
  "platform_admin",
  "agency_owner",
  "sales",
  "pm",
  "design",
  "research",
  "frontend",
  "backend",
  "tech_lead",
  "qa",
  "client",
]);

export const AgencyStageSchema = z.enum([
  "lead_generation",
  "proposal",
  "onboarding",
  "delivery",
  "qa_release",
]);

export const LeadStatusSchema = z.enum([
  "new",
  "qualified",
  "proposal_ready",
  "won",
  "lost",
]);

export const OpportunityStageSchema = z.enum([
  "discovery",
  "proposal",
  "negotiation",
  "won",
  "lost",
]);

export const ProposalStatusSchema = z.enum([
  "draft",
  "ready_for_review",
  "sent",
  "accepted",
  "rejected",
]);

export const ProjectStatusSchema = z.enum([
  "planning",
  "active",
  "blocked",
  "review",
  "complete",
]);

export const WorkItemStatusSchema = z.enum([
  "backlog",
  "todo",
  "in_progress",
  "review",
  "blocked",
  "done",
]);

export const DeliverableStatusSchema = z.enum([
  "draft",
  "review",
  "approved",
  "published",
]);

export const DraftStatusSchema = z.enum(["draft", "ready", "approved", "sent"]);

export const AgentRunStatusSchema = z.enum([
  "planned",
  "in_progress",
  "needs_review",
  "blocked",
  "completed",
  "failed",
]);

export const PortalApprovalStatusSchema = z.enum([
  "pending",
  "approved",
  "changes_requested",
]);

export const ArtifactSchema = z.object({
  id: z.string(),
  type: z.enum([
    "brief",
    "proposal",
    "design_asset",
    "pr_link",
    "document",
    "approval_packet",
  ]),
  title: z.string(),
  url: z.string().url().optional(),
  description: z.string().optional(),
});

export const ActionItemSchema = z.object({
  id: z.string(),
  title: z.string(),
  owner: AgencyRoleSchema.optional(),
  dueAt: TimestampSchema.optional(),
});

export const CitationSchema = z.object({
  label: z.string(),
  source: z.string(),
  excerpt: z.string().optional(),
});

export const RiskSchema = z.object({
  label: z.string(),
  severity: z.enum(["low", "medium", "high"]),
  mitigation: z.string(),
});

export const LeadSchema = z.object({
  id: z.string(),
  clientWorkspaceId: z.string().optional(),
  source: z.enum(["website", "referral", "outbound", "partnership", "event", "manual"]),
  company: z.string(),
  contactName: z.string(),
  contactEmail: z.string().email(),
  contactPhone: z.string().optional(),
  needs: z.array(z.string()),
  notes: z.string().optional(),
  score: z.number().min(0).max(100).optional(),
  status: LeadStatusSchema,
  tags: z.array(z.string()),
  createdAt: TimestampSchema,
  updatedAt: TimestampSchema,
});

export const OpportunitySchema = z.object({
  id: z.string(),
  leadId: z.string(),
  clientWorkspaceId: z.string().optional(),
  stage: OpportunityStageSchema,
  valueUsd: z.number().nonnegative(),
  closeProbability: z.number().min(0).max(100),
  notes: z.string().optional(),
  createdAt: TimestampSchema,
  updatedAt: TimestampSchema,
});

export const ProposalSchema = z.object({
  id: z.string(),
  clientWorkspaceId: z.string(),
  leadId: z.string(),
  summary: z.string(),
  status: ProposalStatusSchema,
  priceUsd: z.number().nonnegative(),
  timelineWeeks: z.number().int().positive(),
  deliverables: z.array(z.string()).min(1),
  createdAt: TimestampSchema,
  updatedAt: TimestampSchema,
});

export const ClientWorkspaceSchema = z.object({
  id: z.string(),
  name: z.string(),
  primaryContactEmail: z.string().email(),
  proposalId: z.string().optional(),
  projectIds: z.array(z.string()),
  portalAccess: z.enum(["inactive", "active"]),
  createdAt: TimestampSchema,
  updatedAt: TimestampSchema,
});

export const ProjectSchema = z.object({
  id: z.string(),
  clientWorkspaceId: z.string(),
  linearProjectId: z.string().optional(),
  githubRepo: z.string().optional(),
  name: z.string(),
  status: ProjectStatusSchema,
  summary: z.string(),
  createdAt: TimestampSchema,
  updatedAt: TimestampSchema,
});

export const WorkItemSchema = z.object({
  id: z.string(),
  clientWorkspaceId: z.string().optional(),
  projectId: z.string().optional(),
  externalId: z.string().optional(),
  title: z.string(),
  summary: z.string().optional(),
  status: WorkItemStatusSchema,
  source: z.enum(["internal", "github", "linear"]),
  labels: z.array(z.string()),
  url: z.string().url().optional(),
});

export const DeliverableSchema = z.object({
  id: z.string(),
  clientWorkspaceId: z.string(),
  projectId: z.string(),
  title: z.string(),
  status: DeliverableStatusSchema,
  artifactIds: z.array(z.string()),
  createdAt: TimestampSchema,
  updatedAt: TimestampSchema,
});

export const DesignAssetSchema = z.object({
  id: z.string(),
  clientWorkspaceId: z.string(),
  kind: z.enum(["logo", "illustration", "icon", "ui_mock", "design_system"]),
  prompt: z.string(),
  provider: z.enum(["recraft", "figma", "stitch", "manual"]),
  url: z.string().url().optional(),
  createdAt: TimestampSchema,
});

export const KnowledgeDocumentSchema = z.object({
  id: z.string(),
  clientWorkspaceId: z.string().optional(),
  source: z.enum([
    "agency_playbook",
    "proposal",
    "client_doc",
    "meeting_note",
    "github",
    "linear",
    "figma",
    "web",
  ]),
  title: z.string(),
  body: z.string(),
  chunkIndex: z.number().int().nonnegative().default(0),
  embedding: z.array(z.number()).optional(),
  citationUrl: z.string().url().optional(),
  tags: z.array(z.string()).default([]),
  createdAt: TimestampSchema,
});

export const DraftMessageSchema = z.object({
  id: z.string(),
  clientWorkspaceId: z.string().optional(),
  channel: z.enum(["email", "portal", "note"]),
  audience: z.enum(["lead", "client", "internal"]),
  subject: z.string(),
  body: z.string(),
  status: DraftStatusSchema,
  createdAt: TimestampSchema,
});

export const ToolTraceSchema = z.object({
  tool: z.string(),
  status: z.enum(["success", "failed", "skipped"]),
  summary: z.string(),
});

export const AgentRunSchema = z.object({
  id: z.string(),
  clientWorkspaceId: z.string().optional(),
  agentId: z.string(),
  workflow: z.string(),
  stage: AgencyStageSchema,
  status: AgentRunStatusSchema,
  summary: z.string(),
  costUsd: z.number().nonnegative().default(0),
  toolTraces: z.array(ToolTraceSchema).default([]),
  startedAt: TimestampSchema,
  finishedAt: TimestampSchema.optional(),
});

export const EvaluationRunSchema = z.object({
  id: z.string(),
  workflow: z.string(),
  metric: z.string(),
  score: z.number(),
  notes: z.string().optional(),
  createdAt: TimestampSchema,
});

export const PortalApprovalSchema = z.object({
  id: z.string(),
  clientWorkspaceId: z.string(),
  deliverableId: z.string(),
  status: PortalApprovalStatusSchema,
  requestedAt: TimestampSchema,
  respondedAt: TimestampSchema.optional(),
  notes: z.string().optional(),
});

export const AgentOutputSchema = z.object({
  summary: z.string(),
  artifacts: z.array(ArtifactSchema),
  nextActions: z.array(ActionItemSchema).min(1),
  citations: z.array(CitationSchema).min(1),
  risks: z.array(RiskSchema),
  status: AgentRunStatusSchema.exclude(["failed"]),
});

export const NormalizedExternalWorkItemSchema = WorkItemSchema.extend({
  externalId: z.string(),
  source: z.enum(["github", "linear"]),
});

export const LeadIntakeInputSchema = LeadSchema.omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  status: true,
});

export const ProposalGenerationInputSchema = z.object({
  leadId: z.string(),
  clientWorkspaceId: z.string(),
  objectives: z.array(z.string()).min(1),
  budgetCeilingUsd: z.number().positive().optional(),
});

export const OnboardingKickoffInputSchema = z.object({
  proposalId: z.string(),
  clientWorkspaceId: z.string(),
  projectName: z.string(),
});

export const WorkspaceProvisionInputSchema = z.object({
  proposalId: z.string(),
  workspaceName: z.string(),
  primaryContactEmail: z.string().email(),
});

export const ProjectSyncInputSchema = z.object({
  clientWorkspaceId: z.string(),
  projectId: z.string(),
  linearProjectId: z.string().optional(),
  githubRepo: z.string().optional(),
});

export const ArtifactPublishInputSchema = z.object({
  clientWorkspaceId: z.string(),
  deliverableId: z.string(),
  artifactIds: z.array(z.string()).min(1),
});

export const KnowledgeIngestInputSchema = z.object({
  clientWorkspaceId: z.string().optional(),
  source: KnowledgeDocumentSchema.shape.source,
  title: z.string(),
  body: z.string(),
  citationUrl: z.string().url().optional(),
  tags: z.array(z.string()).default([]),
});

export const AgentRunReplayInputSchema = z.object({
  runId: z.string(),
  notes: z.string().optional(),
});

export type AgencyRole = z.infer<typeof AgencyRoleSchema>;
export type AgencyStage = z.infer<typeof AgencyStageSchema>;
export type Lead = z.infer<typeof LeadSchema>;
export type Opportunity = z.infer<typeof OpportunitySchema>;
export type Proposal = z.infer<typeof ProposalSchema>;
export type ClientWorkspace = z.infer<typeof ClientWorkspaceSchema>;
export type Project = z.infer<typeof ProjectSchema>;
export type WorkItem = z.infer<typeof WorkItemSchema>;
export type Deliverable = z.infer<typeof DeliverableSchema>;
export type DesignAsset = z.infer<typeof DesignAssetSchema>;
export type KnowledgeDocument = z.infer<typeof KnowledgeDocumentSchema>;
export type DraftMessage = z.infer<typeof DraftMessageSchema>;
export type AgentRun = z.infer<typeof AgentRunSchema>;
export type EvaluationRun = z.infer<typeof EvaluationRunSchema>;
export type PortalApproval = z.infer<typeof PortalApprovalSchema>;
export type AgentOutput = z.infer<typeof AgentOutputSchema>;
export type NormalizedExternalWorkItem = z.infer<
  typeof NormalizedExternalWorkItemSchema
>;
