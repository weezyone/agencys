import { describe, expect, it } from "vitest";

import {
  AgentOutputSchema,
  LeadSchema,
  ProposalSchema,
} from "./index";

describe("schemas", () => {
  it("accepts a workspace-scoped lead and proposal", () => {
    const lead = LeadSchema.parse({
      id: "lead_001",
      source: "website",
      company: "Canyon Signal",
      contactName: "Ash Moreno",
      contactEmail: "ash@canyonsignal.com",
      needs: ["dashboard", "branding"],
      status: "qualified",
      tags: ["saas", "urgent"],
      createdAt: "2026-03-09T00:00:00.000Z",
      updatedAt: "2026-03-09T00:00:00.000Z",
    });

    const proposal = ProposalSchema.parse({
      id: "proposal_001",
      clientWorkspaceId: "workspace_001",
      leadId: lead.id,
      summary: "Full product design and MVP build",
      status: "draft",
      priceUsd: 24000,
      timelineWeeks: 8,
      deliverables: ["Design system", "MVP build"],
      createdAt: "2026-03-09T00:00:00.000Z",
      updatedAt: "2026-03-09T00:00:00.000Z",
    });

    expect(proposal.clientWorkspaceId).toBe("workspace_001");
  });

  it("rejects an agent output without citations and next actions", () => {
    expect(() =>
      AgentOutputSchema.parse({
        summary: "Looks good.",
        artifacts: [],
        risks: [],
        status: "completed",
      }),
    ).toThrow();
  });
});
