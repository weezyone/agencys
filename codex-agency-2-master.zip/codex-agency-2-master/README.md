# Mastra Agency OS

Greenfield monorepo scaffold for a digital design/development agency built around Mastra, Next.js, Tailwind CSS, shadcn-style UI primitives, MongoDB, Better Auth, and an adapter layer for GitHub MCP, Linear MCP, Figma MCP, Stitch MCP, and the Recraft API.

## Workspace layout

- `apps/web`: Next.js App Router marketing site, internal agency cockpit, client portal, auth route, and orchestration-facing API routes.
- `apps/runtime`: long-running Mastra runtime with workflow definitions, RAG ingestion/research endpoints, and a small Hono server.
- `packages/schemas`: shared Zod/TypeScript contracts for leads, proposals, workspaces, projects, deliverables, approvals, agent output, and API inputs.
- `packages/agents`: roster definitions, stage routing, workspace policy guards, and memory-scope helpers.
- `packages/integrations`: stable adapter layer for MCP-backed systems and Recraft.
- `packages/db`: MongoDB repositories and workspace-aware persistence helpers.
- `packages/ui`: reusable Tailwind/shadcn-style UI components.

## Implemented v1 scaffold

- Public marketing homepage at `/`
- Internal agency dashboard at `/agency`
- Client workspace portal at `/client/[workspaceId]`
- Better Auth route at `/api/auth/[...all]`
- Internal orchestration routes for lead intake, proposal generation, onboarding, project sync, artifact publishing, knowledge ingestion, workspace provisioning, and agent-run replay
- Mastra workflows for `lead_qualification`, `proposal_generation`, `client_onboarding`, `delivery_orchestration`, and `qa_release`
- RAG-oriented knowledge chunking and research brief endpoints
- Strictly scoped agent roster and policy layer

## Setup

1. Copy `.env.example` to `.env` and fill in:
   - `MONGODB_URL`
   - `MONGODB_DB_NAME`
   - `BETTER_AUTH_URL`
   - `BETTER_AUTH_SECRET`
   - `RUNTIME_BASE_URL`
   - MCP/Recraft credentials as needed
2. Install dependencies:

```bash
pnpm install
```

3. Start the web app:

```bash
pnpm dev:web
```

4. Start the Mastra runtime:

```bash
pnpm dev:runtime
```

## Verification

```bash
pnpm typecheck
pnpm test
pnpm build
```

## Notes

- The web app will build without a live Mongo connection, but Better Auth still expects a real `BETTER_AUTH_URL` and `BETTER_AUTH_SECRET` in runtime environments.
- External adapters are intentionally behind stable interfaces so you can replace transport details without rewriting agent/workflow logic.
- The runtime currently provides the orchestration skeleton and draft outputs; live delivery quality depends on real model/API credentials and MCP server availability.
