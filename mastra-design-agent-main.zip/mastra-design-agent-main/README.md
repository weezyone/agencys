# Mastra Design Agent

A modernist Mastra-style design agent built in Next.js. It uses OpenRouter for chat + embeddings, MongoDB for memory and semantic retrieval, and produces deliverables for Google Stitch (computer-use runbook) and Penpot exports.

## Features

- OpenRouter-powered LLM and embedding pipeline
- MongoDB persistence for memory, artifacts, and run history
- Semantic retrieval with Atlas vector search or local cosine fallback
- Google Stitch runbook for hi-fi mockup generation via computer-use flow
- Penpot deliverables plan and optional API-based file creation
- Generated artifacts: token JSON, CSS variables, wordmark SVG, wireframe HTML, content kit
- Next.js UI to run briefs and browse stored outputs

## Setup

1. Copy the env file and fill in credentials:

```bash
cp .env.example .env.local
```

2. Add your credentials:

- `OPENROUTER_API_KEY`
- `MONGODB_URI`

Optional:
- `OPENROUTER_MODEL`
- `OPENROUTER_EMBED_MODEL`
- `MONGODB_VECTOR_INDEX` (Atlas vector search index name)
- `PENPOT_ACCESS_TOKEN` (enables Penpot file creation)
- `PENPOT_PROJECT_ID` (target project for deliverables)
- `PENPOT_API_BASE` (override Penpot API base URL)
- `PENPOT_FILE_URL_TEMPLATE` (e.g. `https://design.penpot.app/#/view/{fileId}`)

You can also provide a Penpot project ID per run in the UI.

3. Install dependencies and run:

```bash
npm install
npm run dev
```

## Validation

Minimal verification path:

1. **OpenRouter chat + embeddings**
   - Submit a brief in the UI.
   - Confirm the response returns a summary and artifacts.

2. **MongoDB persistence + semantic retrieval**
   - After a run, check that artifacts and memory entries appear in the Archive.
   - Submit a second brief and confirm prior memory influences the output.

3. **UI trigger + stored artifacts**
   - Ensure the Latest Output panel renders Stitch/Penpot plans.
   - Confirm stored artifacts and memory lists populate.

4. **Penpot API integration (optional)**
   - Set `PENPOT_ACCESS_TOKEN` + `PENPOT_PROJECT_ID`.
   - Run a brief and confirm the Penpot file ID appears in Latest Output.

## Notes

- Google Stitch and Penpot tools generate runbooks and export plans. Penpot file creation is optional and requires API credentials.
- If Atlas vector search is unavailable, the app stores embeddings and computes cosine similarity in code.
