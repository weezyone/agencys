"use client";

import { useEffect, useMemo, useState, type FormEvent } from "react";
import styles from "./page.module.css";

type Artifact = {
  _id?: string;
  taskId: string;
  type: string;
  title: string;
  content: unknown;
  links?: {
    penpotUrl?: string;
    stitchUrl?: string;
  };
  createdAt: string;
};

type MemoryEntry = {
  _id?: string;
  text: string;
  metadata?: {
    role?: string;
    projectName?: string;
    source?: string;
  };
  createdAt: string;
};

type RunRecord = {
  _id?: string;
  taskId: string;
  summary: string;
  createdAt: string;
};

type AgentResult = {
  runId: string;
  taskId: string;
  summary: string;
  artifacts: Artifact[];
  stitchPlan: {
    prompt: string;
    urlHint?: string;
  };
  penpotPlan: {
    fileName: string;
    urlHint: string;
  };
  penpotFile?: {
    fileId: string;
    projectId: string;
    name: string;
    createdAt: string;
    fileUrl?: string;
  } | null;
  penpotError?: string | null;
};

type Overview = {
  artifacts: Artifact[];
  memory: MemoryEntry[];
  runs: RunRecord[];
  error?: string;
};

const deliverableOptions = [
  "Logo concepts",
  "Design system",
  "Brand tokens",
  "Wireframes",
  "Content guidance",
  "Google Stitch mockups",
  "Penpot exports",
];

const channelOptions = ["Web", "Mobile", "Social", "Email", "Print"];
const quickStartPreset = {
  projectName: "Atlas Atelier",
  brief:
    "A quiet luxury studio for architects and collectors. Build a modernist identity with strict grid logic, typographic rigor, and two-color discipline.",
  audience: "Founders, design directors, gallery curators",
  constraints: "Two colors + one typeface. No gradients. Intentional grid breaks.",
  penpotProjectId: "",
  deliverables: deliverableOptions,
  channels: channelOptions,
};

export default function Home() {
  const [theme, setTheme] = useState<"light" | "dark">("light");
  const [form, setForm] = useState({
    projectName: "",
    brief: "",
    audience: "",
    constraints: "",
    penpotProjectId: "",
    deliverables: deliverableOptions,
    channels: channelOptions,
  });
  const [status, setStatus] = useState<
    "idle" | "loading" | "success" | "error"
  >("idle");
  const [error, setError] = useState<string>("");
  const [latestRun, setLatestRun] = useState<AgentResult | null>(null);
  const [overview, setOverview] = useState<Overview>({
    artifacts: [],
    memory: [],
    runs: [],
  });

  const statusLabel = useMemo(() => {
    if (status === "loading") return "Running";
    if (status === "success") return "Complete";
    if (status === "error") return "Error";
    return "Ready";
  }, [status]);

  const refreshOverview = async () => {
    try {
      const response = await fetch("/api/overview");
      const text = await response.text();
      const data = JSON.parse(text) as Overview;
      if (!response.ok) {
        throw new Error(data.error ?? "Failed to load overview");
      }
      setOverview(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load overview");
    }
  };

  useEffect(() => {
    void refreshOverview();
  }, []);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const stored = window.localStorage.getItem("theme");
    const prefersDark = window.matchMedia?.(
      "(prefers-color-scheme: dark)"
    ).matches;
    const nextTheme =
      stored === "light" || stored === "dark"
        ? stored
        : prefersDark
          ? "dark"
          : "light";
    setTheme(nextTheme);
    document.documentElement.dataset.theme = nextTheme;
  }, []);

  const toggleTheme = () => {
    setTheme((prev) => {
      const next = prev === "dark" ? "light" : "dark";
      document.documentElement.dataset.theme = next;
      window.localStorage.setItem("theme", next);
      return next;
    });
  };

  const toggleSelection = (key: "deliverables" | "channels", value: string) => {
    setForm((prev) => {
      const existing = prev[key];
      const next = existing.includes(value)
        ? existing.filter((item) => item !== value)
        : [...existing, value];
      return { ...prev, [key]: next };
    });
  };

  const applyQuickStart = () => {
    setForm(quickStartPreset);
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError("");

    if (!form.projectName.trim() || !form.brief.trim()) {
      setStatus("error");
      setError("Project name and brief are required.");
      return;
    }

    setStatus("loading");

    try {
      const response = await fetch("/api/agent", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          projectName: form.projectName,
          brief: form.brief,
          audience: form.audience,
          constraints: form.constraints,
          penpotProjectId: form.penpotProjectId,
          deliverables: form.deliverables,
          channels: form.channels,
        }),
      });

      const text = await response.text();
      let data: (AgentResult & { error?: string }) | null = null;
      try {
        data = JSON.parse(text) as AgentResult & { error?: string };
      } catch {
        throw new Error(text || "Agent run failed");
      }

      if (!response.ok || !data) {
        throw new Error(data?.error ?? "Agent run failed");
      }

      setLatestRun(data);
      setStatus("success");
      void refreshOverview();
    } catch (err) {
      setStatus("error");
      setError(err instanceof Error ? err.message : "Agent run failed");
    }
  };

  const formatContent = (content: unknown) => {
    if (!content) return "";
    if (typeof content === "string") return content;
    return JSON.stringify(content, null, 2);
  };

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <div>
          <h1 className={styles.headline}>Mastra Design Agent</h1>
          <p className={styles.tagline}>
            Modernist design intelligence powered by OpenRouter, MongoDB memory,
            and Penpot deliverables. Grid discipline with intentional breaks and
            a single typeface.
          </p>
          <div className={styles.rule} />
        </div>
        <div className={styles.headerActions}>
          <button
            type="button"
            className={styles.themeToggle}
            onClick={toggleTheme}
            aria-pressed={theme === "dark"}
          >
            {theme === "dark" ? "Light Mode" : "Dark Mode"}
          </button>
          <div className={styles.notice}>
            OpenRouter + MongoDB + Google Stitch + Penpot
          </div>
        </div>
      </header>

      <div className={styles.layout}>
        <section className={styles.panel}>
          <div className={styles.panelHeader}>
            <div className={styles.panelTitle}>Brief Intake</div>
            <span className={styles.badge}>{statusLabel}</span>
          </div>
          <form className={styles.form} onSubmit={handleSubmit}>
            <div className={styles.field}>
              <label className={styles.label} htmlFor="projectName">
                Project Name
              </label>
              <input
                id="projectName"
                className={styles.input}
                value={form.projectName}
                onChange={(event) =>
                  setForm((prev) => ({
                    ...prev,
                    projectName: event.target.value,
                  }))
                }
                placeholder="Atlas Atelier"
              />
            </div>
            <div className={styles.field}>
              <label className={styles.label} htmlFor="brief">
                Core Brief
              </label>
              <textarea
                id="brief"
                className={styles.textarea}
                value={form.brief}
                onChange={(event) =>
                  setForm((prev) => ({ ...prev, brief: event.target.value }))
                }
                placeholder="A quiet luxury studio for architects and collectors."
              />
            </div>
            <div className={styles.field}>
              <label className={styles.label} htmlFor="audience">
                Audience
              </label>
              <input
                id="audience"
                className={styles.input}
                value={form.audience}
                onChange={(event) =>
                  setForm((prev) => ({ ...prev, audience: event.target.value }))
                }
                placeholder="Founders, design directors, gallery curators"
              />
            </div>
            <div className={styles.field}>
              <label className={styles.label}>Deliverables</label>
              <div className={styles.checkGrid}>
                {deliverableOptions.map((option) => (
                  <label key={option} className={styles.checkbox}>
                    <input
                      type="checkbox"
                      checked={form.deliverables.includes(option)}
                      onChange={() => toggleSelection("deliverables", option)}
                    />
                    {option}
                  </label>
                ))}
              </div>
            </div>
            <div className={styles.field}>
              <label className={styles.label}>Channels</label>
              <div className={styles.checkGrid}>
                {channelOptions.map((option) => (
                  <label key={option} className={styles.checkbox}>
                    <input
                      type="checkbox"
                      checked={form.channels.includes(option)}
                      onChange={() => toggleSelection("channels", option)}
                    />
                    {option}
                  </label>
                ))}
              </div>
            </div>
            <div className={styles.field}>
              <label className={styles.label} htmlFor="constraints">
                Constraints
              </label>
              <input
                id="constraints"
                className={styles.input}
                value={form.constraints}
                onChange={(event) =>
                  setForm((prev) => ({
                    ...prev,
                    constraints: event.target.value,
                  }))
                }
                placeholder="Two colors + one typeface, avoid gradients"
              />
            </div>
            <div className={styles.field}>
              <label className={styles.label} htmlFor="penpotProjectId">
                Penpot Project ID (optional)
              </label>
              <input
                id="penpotProjectId"
                className={styles.input}
                value={form.penpotProjectId}
                onChange={(event) =>
                  setForm((prev) => ({
                    ...prev,
                    penpotProjectId: event.target.value,
                  }))
                }
                placeholder="UUID from Penpot project"
              />
            </div>
            {error ? <p className={styles.notice}>{error}</p> : null}
            <div className={styles.buttonRow}>
              <button
                className={styles.secondaryButton}
                type="button"
                onClick={applyQuickStart}
                disabled={status === "loading"}
              >
                Quick Start
              </button>
              <button
                className={styles.button}
                type="submit"
                disabled={status === "loading"}
              >
                Run Design Agent
              </button>
            </div>
          </form>
        </section>

        <section className={styles.panel}>
          <div className={styles.panelHeader}>
            <div className={styles.panelTitle}>Latest Output</div>
            <span className={styles.badge}>
              {latestRun ? "Active" : "Awaiting"}
            </span>
          </div>
          {latestRun ? (
            <div className={styles.cards}>
              <div className={styles.card}>
                <div className={styles.meta}>Summary</div>
                <div className={styles.cardTitle}>{latestRun.summary}</div>
              </div>
              <div className={styles.card}>
                <div className={styles.meta}>Google Stitch Runbook</div>
                <div className={styles.cardTitle}>{latestRun.stitchPlan.prompt}</div>
                {latestRun.stitchPlan.urlHint ? (
                  <a
                    className={styles.inlineLink}
                    href={latestRun.stitchPlan.urlHint}
                    target="_blank"
                    rel="noreferrer"
                  >
                    Open Stitch
                  </a>
                ) : null}
              </div>
              <div className={styles.card}>
                <div className={styles.meta}>Penpot Deliverables</div>
                <div className={styles.cardTitle}>{latestRun.penpotPlan.fileName}</div>
                {latestRun.penpotFile ? (
                  <div className={styles.notice}>
                    File ID: {latestRun.penpotFile.fileId}
                  </div>
                ) : null}
                {latestRun.penpotError ? (
                  <div className={styles.notice}>{latestRun.penpotError}</div>
                ) : null}
                <a
                  className={styles.inlineLink}
                  href={
                    latestRun.penpotFile?.fileUrl ?? latestRun.penpotPlan.urlHint
                  }
                  target="_blank"
                  rel="noreferrer"
                >
                  Open Penpot
                </a>
              </div>
              <div className={styles.section}>
                <div className={styles.sectionTitle}>Artifacts</div>
                <div className={styles.cards}>
                  {latestRun.artifacts.map((artifact) => (
                    <div key={artifact.title} className={styles.card}>
                      <div className={styles.meta}>{artifact.type}</div>
                      <div className={styles.cardTitle}>{artifact.title}</div>
                      <pre className={styles.pre}>
                        {formatContent(artifact.content)}
                      </pre>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <p className={styles.notice}>
              No run yet. Submit a brief to generate deliverables.
            </p>
          )}
        </section>
      </div>

      <section className={styles.section}>
        <div className={styles.sectionTitle}>Archive</div>
        <div className={styles.split}>
          <div className={styles.panel}>
            <div className={styles.panelHeader}>
              <div className={styles.panelTitle}>Stored Artifacts</div>
              <span className={styles.badge}>{overview.artifacts.length}</span>
            </div>
            <div className={styles.cards}>
              {overview.artifacts.map((artifact) => (
                <div key={artifact._id ?? artifact.title} className={styles.card}>
                  <div className={styles.meta}>{artifact.type}</div>
                  <div className={styles.cardTitle}>{artifact.title}</div>
                  <div className={styles.notice}>{artifact.createdAt}</div>
                </div>
              ))}
              {overview.artifacts.length === 0 ? (
                <p className={styles.notice}>No artifacts stored yet.</p>
              ) : null}
            </div>
          </div>
          <div className={styles.panel}>
            <div className={styles.panelHeader}>
              <div className={styles.panelTitle}>Memory Ledger</div>
              <span className={styles.badge}>{overview.memory.length}</span>
            </div>
            <div className={styles.cards}>
              {overview.memory.map((entry) => (
                <div key={entry._id ?? entry.text} className={styles.card}>
                  <div className={styles.meta}>
                    {entry.metadata?.role ?? "memory"}
                  </div>
                  <div className={styles.cardTitle}>{entry.text}</div>
                  <div className={styles.notice}>{entry.createdAt}</div>
                </div>
              ))}
              {overview.memory.length === 0 ? (
                <p className={styles.notice}>No memory entries stored yet.</p>
              ) : null}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
