import { NextResponse } from "next/server";
import { runDesignAgent, type DesignRequest } from "@/lib/agent";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const payload = (await request.json()) as Partial<DesignRequest>;

    if (!payload.projectName || !payload.brief) {
      return NextResponse.json(
        { error: "projectName and brief are required." },
        { status: 400 }
      );
    }

    const result = await runDesignAgent({
      projectName: payload.projectName,
      brief: payload.brief,
      audience: payload.audience,
      deliverables: payload.deliverables,
      channels: payload.channels,
      constraints: payload.constraints,
      penpotProjectId: payload.penpotProjectId,
    });

    return NextResponse.json(result);
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Unknown agent error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
