import { NextResponse } from "next/server";
import { listArtifacts, listMemory, listRuns } from "@/lib/storage";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const [artifacts, memory, runs] = await Promise.all([
      listArtifacts(24),
      listMemory(24),
      listRuns(12),
    ]);

    return NextResponse.json({ artifacts, memory, runs });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
