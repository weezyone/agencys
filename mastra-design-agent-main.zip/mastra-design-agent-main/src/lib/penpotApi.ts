type CreatePenpotFileInput = {
  name: string;
  projectId: string;
};

export type PenpotFileRecord = {
  fileId: string;
  projectId: string;
  name: string;
  createdAt: string;
  fileUrl?: string;
};

const DEFAULT_PENPOT_API_BASE =
  "https://design.penpot.app/api/main/methods";

export function canUsePenpotApi() {
  return Boolean(process.env.PENPOT_ACCESS_TOKEN);
}

function buildFileUrl(fileId: string) {
  const template = process.env.PENPOT_FILE_URL_TEMPLATE;
  if (!template) {
    return undefined;
  }

  return template.replace("{fileId}", fileId);
}

export async function createPenpotFile({
  name,
  projectId,
}: CreatePenpotFileInput): Promise<PenpotFileRecord> {
  const apiBase = process.env.PENPOT_API_BASE ?? DEFAULT_PENPOT_API_BASE;
  const token = process.env.PENPOT_ACCESS_TOKEN;

  if (!token) {
    throw new Error("Missing PENPOT_ACCESS_TOKEN.");
  }

  const response = await fetch(`${apiBase}/create-file`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      Authorization: `Token ${token}`,
    },
    body: JSON.stringify({ name, projectId }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Penpot create-file failed: ${response.status} ${errorText}`);
  }

  const data = (await response.json()) as { id?: string };
  const fileId = data?.id;
  if (!fileId) {
    throw new Error("Penpot create-file returned no file id.");
  }

  return {
    fileId,
    projectId,
    name,
    createdAt: new Date().toISOString(),
    fileUrl: buildFileUrl(fileId),
  };
}
