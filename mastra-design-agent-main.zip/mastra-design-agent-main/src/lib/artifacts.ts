type BrandTokensInput = {
  colors?: string[];
  typeface?: string;
  typeScale?: string[];
  spacing?: string[];
  rules?: string[];
};

type WireframesInput = {
  screens?: string[];
  sections?: string[];
  notes?: string;
};

type ContentGuidanceInput = {
  tone?: string;
  rules?: string[];
  examples?: string[];
};

export type TokenBundle = {
  tokens: Record<string, unknown>;
  cssVariables: string;
  palette: {
    ink: string;
    paper: string;
    accent: string;
    accentAlt: string;
  };
  typeface: string;
  typeScale: string[];
  spacing: string[];
};

const TYPE_SCALE_LABELS = ["xs", "sm", "md", "lg", "xl", "2xl", "3xl"];
const SPACING_LABELS = [
  "2",
  "4",
  "8",
  "12",
  "16",
  "24",
  "32",
  "40",
  "48",
  "64",
];

const FALLBACK_PALETTE = ["#111111", "#f4f1e9", "#e1522c", "#3155ff"];
const FALLBACK_TYPE_SCALE = [
  "0.75rem",
  "0.875rem",
  "1rem",
  "1.25rem",
  "1.5rem",
  "2rem",
  "3rem",
];
const FALLBACK_SPACING = [
  "4px",
  "8px",
  "12px",
  "16px",
  "24px",
  "32px",
  "40px",
  "64px",
];

function normalizeStringArray(value: unknown) {
  if (!Array.isArray(value)) {
    return [] as string[];
  }

  return value.filter((item) => typeof item === "string") as string[];
}

function extractColorValue(value: string) {
  const trimmed = value.trim();
  const hexMatch = trimmed.match(/#([0-9a-fA-F]{3,8})/);
  if (hexMatch) {
    return `#${hexMatch[1]}`;
  }

  if (/^(rgb|hsl)a?\(/i.test(trimmed)) {
    return trimmed;
  }

  return null;
}

function normalizeScale(values: string[], unit: "px" | "rem") {
  const normalized = values
    .map((value) => value.trim())
    .filter(Boolean)
    .map((value) => (/[a-z%]+$/i.test(value) ? value : `${value}${unit}`));

  return normalized;
}

function buildTokenMaps(labels: string[], values: string[]) {
  return values.reduce<Record<string, string>>((acc, value, index) => {
    const label = labels[index] ?? `step-${index + 1}`;
    acc[label] = value;
    return acc;
  }, {});
}

export function buildTokenBundle(
  projectName: string,
  brandTokens: BrandTokensInput
): TokenBundle {
  const rawColors = normalizeStringArray(brandTokens.colors);
  const parsedColors = rawColors
    .map((color) => extractColorValue(color))
    .filter((color): color is string => Boolean(color));
  const palette = [...parsedColors, ...FALLBACK_PALETTE].slice(0, 4);

  const typeface = brandTokens.typeface?.trim() || "Helvetica Neue";
  const typeScale = normalizeScale(
    normalizeStringArray(brandTokens.typeScale),
    "rem"
  );
  const spacing = normalizeScale(
    normalizeStringArray(brandTokens.spacing),
    "px"
  );

  const normalizedTypeScale =
    typeScale.length >= 4 ? typeScale : FALLBACK_TYPE_SCALE;
  const normalizedSpacing =
    spacing.length >= 4 ? spacing : FALLBACK_SPACING;

  const typeScaleMap = buildTokenMaps(TYPE_SCALE_LABELS, normalizedTypeScale);
  const spacingMap = buildTokenMaps(SPACING_LABELS, normalizedSpacing);

  const tokens = {
    meta: {
      projectName,
      generatedAt: new Date().toISOString(),
      persona: "Modernist / Vignelli discipline",
    },
    color: {
      ink: { value: palette[0] },
      paper: { value: palette[1] },
      accent: { value: palette[2] },
      accentAlt: { value: palette[3] },
    },
    typography: {
      fontFamily: { value: typeface },
      scale: typeScaleMap,
    },
    spacing: spacingMap,
    rules: normalizeStringArray(brandTokens.rules),
  } satisfies Record<string, unknown>;

  const cssVariables = `:root {
  --color-ink: ${palette[0]};
  --color-paper: ${palette[1]};
  --color-accent: ${palette[2]};
  --color-accent-alt: ${palette[3]};
  --font-primary: "${typeface}";
${Object.entries(typeScaleMap)
  .map(([label, value]) => `  --type-${label}: ${value};`)
  .join("\n")}
${Object.entries(spacingMap)
  .map(([label, value]) => `  --space-${label}: ${value};`)
  .join("\n")}
}`;

  return {
    tokens,
    cssVariables,
    palette: {
      ink: palette[0],
      paper: palette[1],
      accent: palette[2],
      accentAlt: palette[3],
    },
    typeface,
    typeScale: normalizedTypeScale,
    spacing: normalizedSpacing,
  };
}

export function buildLogoSvg(projectName: string, bundle: TokenBundle) {
  const name = projectName.trim() || "Project";
  const displayName = name.toUpperCase();
  const width = 1200;
  const height = 360;

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">
  <rect width="100%" height="100%" fill="${bundle.palette.paper}" />
  <rect x="80" y="246" width="160" height="10" fill="${bundle.palette.accent}" />
  <text x="80" y="210" font-family="${bundle.typeface}, Helvetica, sans-serif" font-size="96" letter-spacing="-2" fill="${bundle.palette.ink}">${displayName}</text>
  <text x="80" y="270" font-family="${bundle.typeface}, Helvetica, sans-serif" font-size="24" letter-spacing="6" fill="${bundle.palette.ink}">MODERNIST SYSTEM</text>
</svg>`;
}

export function buildWireframeHtml(
  projectName: string,
  wireframes: WireframesInput,
  bundle: TokenBundle
) {
  const sections = normalizeStringArray(wireframes.sections);
  const normalizedSections =
    sections.length > 0
      ? sections
      : ["Hero", "Gallery", "Manifesto", "Featured", "CTA"];

  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>${projectName} Wireframe</title>
  <style>
    :root {
      --ink: ${bundle.palette.ink};
      --paper: ${bundle.palette.paper};
      --accent: ${bundle.palette.accent};
      --space: ${bundle.spacing[3] ?? "16px"};
      --space-lg: ${bundle.spacing[5] ?? "32px"};
      --grid-gap: ${bundle.spacing[4] ?? "24px"};
      --font: "${bundle.typeface}", Helvetica, sans-serif;
    }
    * { box-sizing: border-box; }
    body { margin: 0; font-family: var(--font); color: var(--ink); background: var(--paper); }
    .frame { max-width: 1100px; margin: 0 auto; padding: var(--space-lg); }
    .grid { display: grid; grid-template-columns: repeat(12, 1fr); gap: var(--grid-gap); }
    header { display: flex; justify-content: space-between; align-items: center; padding-bottom: var(--space-lg); border-bottom: 2px solid var(--ink); }
    nav { display: flex; gap: var(--space); text-transform: uppercase; letter-spacing: 0.18em; font-size: 0.7rem; }
    section { padding: var(--space-lg) 0; border-bottom: 1px solid rgba(0,0,0,0.12); }
    h2 { margin: 0 0 var(--space); font-size: 1.6rem; letter-spacing: -0.02em; }
    .block { background: rgba(0,0,0,0.06); height: 140px; border: 1px solid rgba(0,0,0,0.18); }
    .accent { height: 6px; width: 120px; background: var(--accent); }
  </style>
</head>
<body>
  <div class="frame">
    <header>
      <div>
        <div style="font-size: 1.4rem; letter-spacing: -0.02em;">${projectName}</div>
        <div class="accent"></div>
      </div>
      <nav>
        <span>Studio</span>
        <span>Work</span>
        <span>Contact</span>
      </nav>
    </header>
    ${normalizedSections
      .map(
        (section) => `
    <section>
      <div class="grid">
        <div style="grid-column: span 4;">
          <h2>${section}</h2>
          <p style="margin: 0; opacity: 0.7;">Minimal description for ${section.toLowerCase()}.</p>
        </div>
        <div style="grid-column: span 8;">
          <div class="block"></div>
        </div>
      </div>
    </section>`
      )
      .join("\n")}
  </div>
</body>
</html>`;
}

export function buildContentKit(
  projectName: string,
  contentGuidance: ContentGuidanceInput,
  channelGuidance?: Record<string, unknown>
) {
  const examples = normalizeStringArray(contentGuidance.examples);

  return {
    tone: contentGuidance.tone ?? "Precise, calm, editorial",
    headline: examples[0] ?? `${projectName} - the quiet authority of form.`,
    subhead:
      examples[1] ??
      "An exacting studio for clients who value structure, restraint, and clarity.",
    cta: examples[2] ?? "Request the system",
    socialCaption:
      examples[3] ??
      `${projectName}: a modernist identity built on grid discipline and honest materials.`,
    emailSubject:
      examples[4] ?? `Introducing ${projectName}: a system of clarity.`,
    channelGuidance: channelGuidance ?? {},
  };
}
