export type OpenRouterMessage = {
  role: "system" | "user" | "assistant";
  content: string;
};

type ChatOptions = {
  messages: OpenRouterMessage[];
  model?: string;
  temperature?: number;
  maxTokens?: number;
};

type EmbeddingOptions = {
  input: string;
  model?: string;
};

const OPENROUTER_BASE_URL =
  process.env.OPENROUTER_BASE_URL ?? "https://openrouter.ai/api/v1";

function assertApiKey() {
  if (!process.env.OPENROUTER_API_KEY) {
    throw new Error("Missing OPENROUTER_API_KEY.");
  }
}

export async function openRouterChat({
  messages,
  model,
  temperature = 0.4,
  maxTokens = 1200,
}: ChatOptions) {
  assertApiKey();

  const response = await fetch(`${OPENROUTER_BASE_URL}/chat/completions`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
      "Content-Type": "application/json",
      "HTTP-Referer": process.env.OPENROUTER_REFERER ?? "http://localhost:3000",
      "X-Title": process.env.OPENROUTER_APP_TITLE ?? "Mastra Design Agent",
    },
    body: JSON.stringify({
      model: model ?? process.env.OPENROUTER_MODEL ?? "openai/gpt-4o-mini",
      messages,
      temperature,
      max_tokens: maxTokens,
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`OpenRouter chat failed: ${response.status} ${errorText}`);
  }

  const payload = await response.json();
  const content = payload?.choices?.[0]?.message?.content ?? "";
  return { content, raw: payload } as const;
}

export async function openRouterEmbedding({ input, model }: EmbeddingOptions) {
  assertApiKey();

  const response = await fetch(`${OPENROUTER_BASE_URL}/embeddings`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
      "Content-Type": "application/json",
      "HTTP-Referer": process.env.OPENROUTER_REFERER ?? "http://localhost:3000",
      "X-Title": process.env.OPENROUTER_APP_TITLE ?? "Mastra Design Agent",
    },
    body: JSON.stringify({
      model:
        model ??
        process.env.OPENROUTER_EMBED_MODEL ??
        "openai/text-embedding-3-small",
      input,
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(
      `OpenRouter embeddings failed: ${response.status} ${errorText}`
    );
  }

  const payload = await response.json();
  const embedding = payload?.data?.[0]?.embedding ?? [];
  if (!Array.isArray(embedding) || embedding.length === 0) {
    throw new Error("OpenRouter embeddings returned empty vector.");
  }

  return embedding as number[];
}
