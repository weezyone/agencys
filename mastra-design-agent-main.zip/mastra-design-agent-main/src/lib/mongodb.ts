import { MongoClient, type Db } from "mongodb";

const dbName = process.env.MONGODB_DB ?? "mastra_design_agent";

let clientPromise: Promise<MongoClient> | undefined;

function getMongoUri() {
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    throw new Error("Missing MONGODB_URI.");
  }
  return uri;
}

export async function getMongoClient() {
  if (!clientPromise) {
    const client = new MongoClient(getMongoUri(), {
      maxPoolSize: 10,
    });
    clientPromise = client.connect();
  }

  return clientPromise;
}

export async function getDb(): Promise<Db> {
  const client = await getMongoClient();
  return client.db(dbName);
}
