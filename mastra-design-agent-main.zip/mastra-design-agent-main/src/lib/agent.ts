import { openRouterChat, openRouterEmbedding } from "@/lib/openrouter";
import {
  type Artifact,
  insertArtifacts,
  insertMemory,
  insertRun,
  searchMemoryLocally,
  searchMemoryWithVectorIndex,
} from "@/lib/storage";
import {
  buildContentKit,
  buildLogoSvg,
  buildTokenBundle,
  buildWireframeHtml,
} from "@/lib/artifacts";
import {
  canUsePenpotApi,
  createPenpotFile,
  type PenpotFileRecord,
} from "@/lib/penpotApi";
import { createStitchRunbook } from "@/lib/tools/computerUse";
import { createPenpotPlan } from "@/lib/tools/penpot";

export type DesignRequest = {
  projectName: string;
  brief: string;
  audience?: string;
  deliverables?: string[];
  channels?: string[];
  constraints?: string;
  penpotProjectId?: string;
};

type AgentOutput = {
  summary: string;
  logo: Record<string, unknown>;
  designSystem: Record<string, unknown>;
  brandTokens: {
    colors?: string[];
    typeface?: string;
    typeScale?: string[];
    spacing?: string[];
    rules?: string[];
  } & Record<string, unknown>;
  wireframes: Record<string, unknown>;
  contentGuidance: Record<string, unknown>;
  layoutNotes?: string;
  visualKeywords?: string[];
  channelGuidance?: Record<string, unknown>;
};

export type AgentRunResult = {
  runId: string;
  taskId: string;
  summary: string;
  artifacts: Artifact[];
  stitchPlan: ReturnType<typeof createStitchRunbook>;
  penpotPlan: ReturnType<typeof createPenpotPlan>;
  penpotFile?: PenpotFileRecord | null;
  penpotError?: string | null;
  raw: unknown;
};

const DEFAULT_DELIVERABLES = [
  "Logo concepts",
  "Design system",
  "Brand tokens",
  "Wireframes",
  "Content guidance",
];

const DEFAULT_CHANNELS = ["Web", "Mobile", "Social", "Email", "Print"];

function buildSystemPrompt() {
  return `You are a Mastra.ai design agent.
Persona: modernist discipline, Massimo Vignelli-inspired. Grid-first with intentional breaks. Minimalism. Strong visual hierarchy. Do more with less.
Typography: single typeface preferred. Be precise about Helvetica vs Arial (never treat them as interchangeable).
Color discipline: prefer two colors + neutrals. Avoid decorative gradients unless justified.
Deliver crisp, structured guidance with high signal, no filler. Avoid placeholders.
Return only valid JSON matching the schema.`;
}

function buildUserPrompt(
  input: DesignRequest,
  memoryContext: string,
  deliverables: string[],
  channels: string[]
) {
  return `Project: ${input.projectName}
Brief: ${input.brief}
Audience: ${input.audience ?? "Not specified"}
Constraints: ${input.constraints ?? "None"}
Deliverables: ${deliverables.join(", ")}
Channels: ${channels.join(", ")}

Relevant memory (use sparingly, if helpful):
${memoryContext || "(none)"}

Output requirements:
- Provide colors as hex values (two primary colors + neutrals).
- Provide spacing scale in px (e.g., 4px, 8px, 16px).
- Provide type scale in rem (e.g., 0.875rem, 1rem, 1.5rem).
- Wireframes should include key sections for each screen.

JSON schema:
{
  "summary": "string",
  "logo": {
    "concepts": ["string"],
    "rationale": "string",
    "usage": "string"
  },
  "designSystem": {
    "grid": "string",
    "layout": "string",
    "components": ["string"],
    "hierarchy": "string"
  },
  "brandTokens": {
    "colors": ["string"],
    "typeface": "string",
    "typeScale": ["string"],
    "spacing": ["string"],
    "rules": ["string"]
  },
  "wireframes": {
    "screens": ["string"],
    "sections": ["string"],
    "notes": "string"
  },
  "contentGuidance": {
    "tone": "string",
    "rules": ["string"],
    "examples": ["string"]
  },
  "layoutNotes": "string",
  "visualKeywords": ["string"],
  "channelGuidance": { "channel": "string" }
}`;
}

function extractJson(text: string) {
  const trimmed = text.trim();
  const fenced = trimmed.startsWith("```")
    ? trimmed.replace(/^```[a-z]*\n?/i, "").replace(/```$/, "")
    : trimmed;
  const firstBrace = fenced.indexOf("{");
  const lastBrace = fenced.lastIndexOf("}");
  if (firstBrace === -1 || lastBrace === -1) {
    return null;
  }

  const jsonSlice = fenced.slice(firstBrace, lastBrace + 1);
  try {
    return JSON.parse(jsonSlice) as AgentOutput;
  } catch (error) {
    return null;
  }
}

function normalizeOutput(raw: AgentOutput | null, fallbackText: string): AgentOutput {
  if (!raw) {
    return {
      summary: fallbackText,
      logo: {},
      designSystem: {},
      brandTokens: {},
      wireframes: {},
      contentGuidance: {},
      layoutNotes: "",
      visualKeywords: [],
      channelGuidance: {},
    };
  }

  return {
    summary: raw.summary ?? fallbackText,
    logo: raw.logo ?? {},
    designSystem: raw.designSystem ?? {},
    brandTokens: raw.brandTokens ?? {},
    wireframes: raw.wireframes ?? {},
    contentGuidance: raw.contentGuidance ?? {},
    layoutNotes: raw.layoutNotes ?? "",
    visualKeywords: raw.visualKeywords ?? [],
    channelGuidance: raw.channelGuidance ?? {},
  };
}

export async function runDesignAgent(input: DesignRequest): Promise<AgentRunResult> {
  const taskId = globalThis.crypto?.randomUUID?.() ?? `task-${Date.now()}`;
  const deliverables =
    input.deliverables && input.deliverables.length > 0
      ? input.deliverables
      : DEFAULT_DELIVERABLES;
  const channels =
    input.channels && input.channels.length > 0
      ? input.channels
      : DEFAULT_CHANNELS;

  const queryText = `${input.projectName}. ${input.brief}`;
  const queryEmbedding = await openRouterEmbedding({ input: queryText });

  let memoryMatches = [] as { text: string; metadata?: Record<string, unknown> }[];
  if (process.env.MONGODB_VECTOR_INDEX) {
    try {
      memoryMatches = await searchMemoryWithVectorIndex(queryEmbedding, 6);
    } catch (error) {
      memoryMatches = await searchMemoryLocally(queryEmbedding, 6);
    }
  } else {
    memoryMatches = await searchMemoryLocally(queryEmbedding, 6);
  }

  const memoryContext = memoryMatches
    .map((match) => `- ${match.text}`)
    .join("\n");

  const systemPrompt = buildSystemPrompt();
  const userPrompt = buildUserPrompt(input, memoryContext, deliverables, channels);

  const { content, raw } = await openRouterChat({
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt },
    ],
  });

  const parsed = extractJson(content);
  const output = normalizeOutput(parsed, content);
  const tokenBundle = buildTokenBundle(input.projectName, output.brandTokens);
  const wireframeInput = output.wireframes as {
    screens?: string[];
    sections?: string[];
    notes?: string;
  };
  const contentInput = output.contentGuidance as {
    tone?: string;
    rules?: string[];
    examples?: string[];
  };
  const channelInput = output.channelGuidance as Record<string, unknown> | undefined;
  const logoSvg = buildLogoSvg(input.projectName, tokenBundle);
  const wireframeHtml = buildWireframeHtml(
    input.projectName,
    wireframeInput,
    tokenBundle
  );
  const contentKit = buildContentKit(
    input.projectName,
    contentInput,
    channelInput
  );

  const stitchPlan = createStitchRunbook({
    projectName: input.projectName,
    brief: input.brief,
    layoutNotes: output.layoutNotes,
    visualKeywords: output.visualKeywords,
    colorPalette: [
      tokenBundle.palette.paper,
      tokenBundle.palette.ink,
      tokenBundle.palette.accent,
    ],
    typeface: tokenBundle.typeface,
    screens: wireframeInput.screens ?? undefined,
  });

  const penpotPlan = createPenpotPlan({
    projectName: input.projectName,
    screens: wireframeInput.screens ?? undefined,
    tokens: {
      colors: [
        tokenBundle.palette.paper,
        tokenBundle.palette.ink,
        tokenBundle.palette.accent,
        tokenBundle.palette.accentAlt,
      ],
      typeface: tokenBundle.typeface,
      spacing: tokenBundle.spacing,
    },
  });
  const penpotProjectId =
    input.penpotProjectId ?? process.env.PENPOT_PROJECT_ID;
  let penpotFile: PenpotFileRecord | null = null;
  let penpotError: string | null = null;
  if (penpotProjectId && canUsePenpotApi()) {
    try {
      penpotFile = await createPenpotFile({
        name: penpotPlan.fileName,
        projectId: penpotProjectId,
      });
    } catch (error) {
      penpotError = error instanceof Error ? error.message : "Penpot error.";
    }
  }

  const createdAt = new Date().toISOString();

  const userMemoryId = await insertMemory({
    text: queryText,
    embedding: queryEmbedding,
    metadata: {
      role: "user",
      taskId,
      projectName: input.projectName,
      tags: deliverables,
      source: "brief",
    },
    createdAt,
  });

  const summaryText = `Summary: ${output.summary}\nTokens: ${tokenBundle.typeface} / ${[
    tokenBundle.palette.paper,
    tokenBundle.palette.ink,
    tokenBundle.palette.accent,
  ].join(", ")}`;
  const summaryEmbedding = await openRouterEmbedding({ input: summaryText });

  const agentMemoryId = await insertMemory({
    text: summaryText,
    embedding: summaryEmbedding,
    metadata: {
      role: "agent",
      taskId,
      projectName: input.projectName,
      tags: ["summary", "tokens"],
      source: "agent-output",
    },
    createdAt,
  });

  const artifacts = [
    {
      taskId,
      type: "logo",
      title: `${input.projectName} Logo Concepts`,
      content: output.logo,
      createdAt,
    },
    {
      taskId,
      type: "logo-svg",
      title: `${input.projectName} Wordmark SVG`,
      content: {
        usage:
          (output.logo as { usage?: string })?.usage ??
          "Minimal wordmark for primary use.",
      },
      assets: {
        svg: logoSvg,
      },
      createdAt,
    },
    {
      taskId,
      type: "design-system",
      title: `${input.projectName} Design System`,
      content: output.designSystem,
      createdAt,
    },
    {
      taskId,
      type: "brand-tokens",
      title: `${input.projectName} Brand Tokens`,
      content: output.brandTokens,
      createdAt,
    },
    {
      taskId,
      type: "brand-tokens-json",
      title: `${input.projectName} Design Tokens (JSON)`,
      content: tokenBundle.tokens,
      createdAt,
    },
    {
      taskId,
      type: "brand-tokens-css",
      title: `${input.projectName} Design Tokens (CSS Variables)`,
      content: tokenBundle.cssVariables,
      createdAt,
    },
    {
      taskId,
      type: "wireframes",
      title: `${input.projectName} Wireframes`,
      content: output.wireframes,
      createdAt,
    },
    {
      taskId,
      type: "wireframe-html",
      title: `${input.projectName} Wireframe HTML`,
      content: wireframeHtml,
      createdAt,
    },
    {
      taskId,
      type: "content-guidance",
      title: `${input.projectName} Content Guidance`,
      content: output.contentGuidance,
      createdAt,
    },
    {
      taskId,
      type: "content-kit",
      title: `${input.projectName} Content Kit`,
      content: contentKit,
      createdAt,
    },
    {
      taskId,
      type: "stitch-mockups",
      title: `${input.projectName} Google Stitch Runbook`,
      content: stitchPlan,
      createdAt,
      links: { stitchUrl: stitchPlan.urlHint },
    },
    {
      taskId,
      type: "penpot-deliverables",
      title: `${input.projectName} Penpot Deliverables Plan`,
      content: {
        plan: penpotPlan,
        file: penpotFile,
        error: penpotError,
      },
      createdAt,
      links: {
        penpotUrl: penpotFile?.fileUrl ?? penpotPlan.urlHint,
      },
    },
  ];

  const artifactIds = await insertArtifacts(artifacts);

  const runId = await insertRun({
    taskId,
    request: input,
    summary: output.summary,
    artifacts: artifactIds,
    memory: [userMemoryId, agentMemoryId],
    createdAt,
  });

  return {
    runId,
    taskId,
    summary: output.summary,
    artifacts,
    stitchPlan,
    penpotPlan,
    penpotFile,
    penpotError,
    raw,
  };
}
