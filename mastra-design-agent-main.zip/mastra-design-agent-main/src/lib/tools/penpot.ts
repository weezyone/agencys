type PenpotPlanInput = {
  projectName: string;
  screens?: string[];
  tokens?: {
    colors?: string[];
    typeface?: string;
    spacing?: string[];
  };
};

export type PenpotPlan = {
  tool: "penpot";
  fileName: string;
  steps: string[];
  exports: string[];
  shareNotes: string[];
  urlHint: string;
};

export function createPenpotPlan({
  projectName,
  screens,
  tokens,
}: PenpotPlanInput): PenpotPlan {
  const tokenNotes = [
    tokens?.typeface ? `Typeface: ${tokens.typeface}.` : "",
    tokens?.colors?.length ? `Colors: ${tokens.colors.join(", ")}.` : "",
    tokens?.spacing?.length
      ? `Spacing: ${tokens.spacing.join(", ")}.`
      : "",
  ]
    .filter(Boolean)
    .join(" ");

  return {
    tool: "penpot",
    fileName: `${projectName} - Modernist System`,
    steps: [
      "Create a new Penpot file and set a 12-column grid.",
      "Define color styles and type styles first.",
      "Build core components: header, nav, buttons, cards.",
      `Lay out frames: ${(screens ?? ["Landing", "Detail", "Content"]).join(
        ", "
      )}.`,
      "Insert Stitch mockups as references and rebuild with vector precision.",
      "Export deliverables as SVG, PNG, and PDF.",
    ],
    exports: ["SVG", "PNG", "PDF"],
    shareNotes: [
      "Provide Penpot share link with view access.",
      "Attach exported assets to project artifacts in MongoDB.",
      tokenNotes,
    ].filter(Boolean),
    urlHint: "https://penpot.app",
  };
}
