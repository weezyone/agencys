type StitchRunbookInput = {
  projectName: string;
  brief: string;
  layoutNotes?: string;
  visualKeywords?: string[];
  colorPalette?: string[];
  typeface?: string;
  screens?: string[];
};

export type StitchRunbook = {
  tool: "google-stitch";
  prompt: string;
  steps: string[];
  checkpoints: string[];
  outputExpectations: string[];
  urlHint?: string;
};

export function createStitchRunbook({
  projectName,
  brief,
  layoutNotes,
  visualKeywords,
  colorPalette,
  typeface,
  screens,
}: StitchRunbookInput): StitchRunbook {
  const prompt = [
    `Project: ${projectName}.`,
    "Modernist system with strict grid and intentional breaks.",
    `Brief: ${brief}.`,
    colorPalette?.length
      ? `Palette: ${colorPalette.join(", ")}.`
      : "Palette: two colors + neutrals.",
    typeface ? `Typeface: ${typeface}.` : "Typeface: single sans-serif.",
    visualKeywords?.length
      ? `Keywords: ${visualKeywords.join(", ")}.`
      : "Keywords: reduction, hierarchy, contrast.",
    layoutNotes ? `Layout: ${layoutNotes}.` : "Layout: modular grid.",
    screens?.length ? `Screens: ${screens.join(", ")}.` : "",
  ]
    .filter(Boolean)
    .join(" ");

  return {
    tool: "google-stitch",
    prompt,
    steps: [
      "Open Google Stitch (if available) and start a new workspace.",
      "Paste the prompt into the design brief field.",
      "Lock the grid to 12 columns with generous gutters.",
      "Generate the first pass and review hierarchy, spacing, and contrast.",
      "Regenerate only the weakest section; keep the grid stable.",
      "Export mockups as PNG and SVG for Penpot reference.",
    ],
    checkpoints: [
      "Two-color discipline intact.",
      "Single typeface, no Arial fallback unless specified.",
      "Grid rhythm consistent across screens.",
      "Whitespace used to control hierarchy.",
    ],
    outputExpectations: [
      "1 hero screen mockup",
      "1 internal page mockup",
      "1 responsive variation",
    ],
    urlHint: "https://stitch.withgoogle.com",
  };
}
