import { ObjectId } from "mongodb";
import { getDb } from "@/lib/mongodb";
import { cosineSimilarity } from "@/lib/vector";

export type MemoryMetadata = {
  role: "user" | "agent" | "system";
  taskId: string;
  projectName?: string;
  tags?: string[];
  source?: string;
};

export type MemoryEntry = {
  _id?: ObjectId;
  text: string;
  embedding: number[];
  metadata: MemoryMetadata;
  createdAt: string;
};

export type Artifact = {
  _id?: ObjectId;
  taskId: string;
  type: string;
  title: string;
  content: string | Record<string, unknown>;
  links?: {
    penpotUrl?: string;
    stitchUrl?: string;
  };
  assets?: {
    svg?: string;
    png?: string;
    pdf?: string;
  };
  createdAt: string;
};

export type RunRecord = {
  _id?: ObjectId;
  taskId: string;
  request: Record<string, unknown>;
  summary: string;
  artifacts: string[];
  memory: string[];
  createdAt: string;
};

export async function insertMemory(entry: MemoryEntry) {
  const db = await getDb();
  const result = await db.collection<MemoryEntry>("memory").insertOne(entry);
  return result.insertedId.toString();
}

export async function insertArtifacts(artifacts: Artifact[]) {
  const db = await getDb();
  if (artifacts.length === 0) {
    return [] as string[];
  }

  const result = await db.collection<Artifact>("artifacts").insertMany(artifacts);
  return Object.values(result.insertedIds).map((id) => id.toString());
}

export async function insertRun(run: RunRecord) {
  const db = await getDb();
  const result = await db.collection<RunRecord>("runs").insertOne(run);
  return result.insertedId.toString();
}

export async function listArtifacts(limit = 20) {
  const db = await getDb();
  const docs = await db
    .collection<Artifact>("artifacts")
    .find()
    .sort({ createdAt: -1 })
    .limit(limit)
    .toArray();

  return docs.map((doc) => ({ ...doc, _id: doc._id?.toString() }));
}

export async function listMemory(limit = 20) {
  const db = await getDb();
  const docs = await db
    .collection<MemoryEntry>("memory")
    .find()
    .sort({ createdAt: -1 })
    .limit(limit)
    .project({ embedding: 0 })
    .toArray();

  return docs.map((doc) => ({ ...doc, _id: doc._id?.toString() }));
}

export async function listRuns(limit = 10) {
  const db = await getDb();
  const docs = await db
    .collection<RunRecord>("runs")
    .find()
    .sort({ createdAt: -1 })
    .limit(limit)
    .toArray();

  return docs.map((doc) => ({ ...doc, _id: doc._id?.toString() }));
}

export async function searchMemoryWithVectorIndex(
  queryVector: number[],
  limit = 6
) {
  const indexName = process.env.MONGODB_VECTOR_INDEX;
  if (!indexName) {
    return [] as MemoryEntry[];
  }

  const db = await getDb();
  const results = await db
    .collection<MemoryEntry>("memory")
    .aggregate([
      {
        $vectorSearch: {
          index: indexName,
          path: "embedding",
          queryVector,
          numCandidates: 100,
          limit,
        },
      },
      {
        $project: {
          text: 1,
          metadata: 1,
          createdAt: 1,
          score: { $meta: "vectorSearchScore" },
        },
      },
    ])
    .toArray();

  return results;
}

export async function searchMemoryLocally(
  queryVector: number[],
  limit = 6
) {
  const db = await getDb();
  const candidates = await db
    .collection<MemoryEntry>("memory")
    .find()
    .sort({ createdAt: -1 })
    .limit(200)
    .toArray();

  const scored = candidates
    .map((candidate) => ({
      candidate,
      score: cosineSimilarity(queryVector, candidate.embedding),
    }))
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map(({ candidate }) => candidate);

  return scored;
}
