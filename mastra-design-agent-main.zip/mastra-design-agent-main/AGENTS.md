Title: Build Mastra Design Agent (OpenRouter + MongoDB + Penpot + Google Stitch)

  Objective

  - Implement a Mastra.ai TypeScript design agent that uses OpenRouter for LLM + embeddings, persists memory and vector search in MongoDB, and generates
    modernist design deliverables via Google Stitch (computer use) and Penpot, with a Next.js frontend.

  Context

  - Framework: Mastra.ai (TypeScript)
  - Frontend: Next.js
  - LLM/Embeddings: OpenRouter
  - Memory/Vector DB: MongoDB with semantic search
  - Design tools: Google Stitch (hi‑fi mockups via computer use), Penpot (deliverables; no Figma)
  - Reference: https://penpot.app/blog/penpot-ai-whitepaper/

  Inputs

  - Repo path and current project state (new or existing)
  - OpenRouter API key (chat + embeddings)
  - MongoDB connection string

  Constraints

  - Use OpenRouter as both LLM and embedding provider.
  - Use MongoDB for memory persistence and semantic vector search.
  - Integrate computer use skill to navigate Google Stitch and create hi‑fi mockups.
  - Use Penpot for design deliverables (not Figma).
  - Store all generated artifacts in MongoDB.
  - Design agent persona: modernist discipline (Massimo Vignelli‑inspired), grid‑driven with intentional breaks, minimalism, strong visual hierarchy, “do
    more with less,” preference for 2 colors + 1 font, typographic rigor (Helvetica vs Arial distinctions).

  Required Outputs

  - Mastra agent implementation with tools for:
      - Logos, design systems, brand tokens, wireframes, and multi‑channel content guidance
      - Computer‑use workflow for Google Stitch mockups
      - Penpot deliverables creation and export
      - MongoDB storage of all outputs and memory with semantic retrieval
  - Next.js UI to trigger design tasks and browse stored outputs/memory
  - File‑path references for all code changes

  Validation

  - Provide a minimal verification path to confirm:
      - OpenRouter chat + embeddings requests work
      - MongoDB persistence + semantic retrieval works
      - UI can trigger an agent run and display stored artifacts

  Assumptions

  - If no repo exists, scaffold a minimal Mastra + Next.js TypeScript project.
  - Use MongoDB Atlas vector search if available; otherwise store embeddings and compute cosine similarity in app code.
  - Store deliverables as Penpot links plus exported PNG/SVG/PDF where possible, along with JSON tokens.
  - Use OpenRouter REST API defaults unless the user specifies models.