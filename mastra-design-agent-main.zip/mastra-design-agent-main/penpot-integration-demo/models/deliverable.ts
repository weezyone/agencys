// models/deliverable.ts
//
// Defines a Mongoose schema for storing information about files
// created in Penpot. A Deliverable represents a design artifact stored
// in Penpot along with metadata you might need in your application.

import mongoose, { Document, Model, Schema } from 'mongoose';

// Define the interface representing a deliverable document.
export interface DeliverableDocument extends Document {
  fileId: string;
  projectId: string;
  name: string;
  createdAt: Date;
}

// Create a schema corresponding to the document interface.
const DeliverableSchema = new Schema<DeliverableDocument>({
  fileId: { type: String, required: true },
  projectId: { type: String, required: true },
  name: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
});

// Because of Next.js hot-reloading and the way Mongoose caches models,
// we must check whether the model already exists to avoid OverwriteModelError.
export const Deliverable: Model<DeliverableDocument> =
  mongoose.models.Deliverable || mongoose.model('Deliverable', DeliverableSchema);
