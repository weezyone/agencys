// mastra.ts
//
// Entry point to register Mastra agents. This module can be imported in
// your Next.js API routes or server actions to access your agents.

import { mastra as Mastra } from '@mastra/core/mastra';
import { designAgent } from './agents/designAgent';

// Register your agents here. When you add more agents, register them
// similarly.
Mastra.registerAgent(designAgent);

export const mastra = Mastra;
