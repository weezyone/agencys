// tools/penpotDeliverableTool.ts
//
// Defines a custom Mastra tool for creating deliverables in Penpot.
// The tool calls an API route in your Next.js application that
// performs the Penpot and database operations, abstracting away
// complexity from the agent. See api/createDeliverable.ts for the
// corresponding server-side implementation.

import { createTool } from '@mastra/core/tools';
import { z } from 'zod';

export const penpotDeliverableTool = createTool({
  id: 'penpot-deliverable',
  description:
    'Creates a new design deliverable in Penpot and records metadata in the database. Provide a human-readable name and the Penpot project ID.',
  // Input schema defines the required arguments. The agent must supply
  // these fields when calling the tool.
  inputSchema: z.object({
    name: z.string().min(1),
    projectId: z.string().uuid(),
  }),
  // Output schema defines what the tool returns. In this example we
  // return the deliverable record with its Penpot file ID and name.
  outputSchema: z.object({
    deliverable: z.object({
      fileId: z.string(),
      projectId: z.string(),
      name: z.string(),
      createdAt: z.string(),
    }),
  }),
  // The execute function performs the work. It receives a context
  // containing the parsed input and the runtime context. Because
  // tools run on the server, you can safely perform network requests
  // and database operations here.
  execute: async ({ context }) => {
    const { name, projectId } = context;

    // Build the URL to the Next.js API route. In a typical setup this
    // would be something like `${process.env.NEXT_PUBLIC_BASE_URL}/api/createDeliverable`.
    // To keep the example simple we assume an environment variable is set.
    const apiBase = process.env.PENPOT_INTEGRATION_BASE_URL || 'http://localhost:3000';
    const url = `${apiBase}/api/penpot/create-deliverable`;

    const resp = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, projectId }),
    });
    if (!resp.ok) {
      const text = await resp.text();
      throw new Error(`Penpot deliverable creation failed: ${text}`);
    }
    const data = await resp.json();
    return { deliverable: data.deliverable };
  },
});
