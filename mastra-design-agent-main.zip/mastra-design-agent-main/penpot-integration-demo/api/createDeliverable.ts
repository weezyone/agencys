// api/createDeliverable.ts
//
// This file demonstrates how to build a Next.js API route that
// integrates with Penpot and MongoDB. The route creates a new
// deliverable file in Penpot and persists metadata about the
// deliverable in a MongoDB collection. Adjust the import paths
// depending on your project structure (e.g. app/api/route.ts for the
// Next.js App Router).

import type { NextApiRequest, NextApiResponse } from 'next';
import mongoose from 'mongoose';

// Import the Deliverable model from our models directory.
import { Deliverable } from '../models/deliverable';

// Fetch implementation – in a real Next.js project you can rely on
// the global `fetch` API. Here we import `node-fetch` for clarity.
import fetch from 'node-fetch';

// Environment variables used to access external services. Set these
// in your `.env.local` file or deployment environment.
const {
  MONGODB_URI,
  PENPOT_API_BASE = 'https://design.penpot.app/api/main/methods',
  PENPOT_ACCESS_TOKEN,
} = process.env;

// Lazily initialise the database connection. MongoDB driver caches
// connections when used with mongoose.connect(), so repeated calls
// won't open multiple connections.
async function initDatabase() {
  if (!MONGODB_URI) {
    throw new Error('MONGODB_URI must be defined in environment variables');
  }
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(MONGODB_URI);
  }
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Ensure we have the required parameters
  const { name, projectId } = req.body as { name?: string; projectId?: string };
  if (!name || !projectId) {
    return res.status(400).json({ error: 'name and projectId are required' });
  }

  try {
    // Initialise database connection
    await initDatabase();

    // Validate required env vars for Penpot
    if (!PENPOT_ACCESS_TOKEN) {
      throw new Error('PENPOT_ACCESS_TOKEN must be defined in environment variables');
    }

    // Create a new file in Penpot via its RPC API
    const penpotResponse = await fetch(`${PENPOT_API_BASE}/create-file`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': `Token ${PENPOT_ACCESS_TOKEN}`,
      },
      body: JSON.stringify({ name, projectId }),
    });

    // Handle errors from the Penpot API
    if (!penpotResponse.ok) {
      const text = await penpotResponse.text();
      return res.status(500).json({ error: 'Failed to create file in Penpot', details: text });
    }

    // Parse the response. Penpot returns JSON data describing the file.
    const fileData = await penpotResponse.json();

    // Persist metadata in MongoDB. If you need more fields (e.g. teamId,
    // status, userId), add them to the schema and here.
    const deliverable = await Deliverable.create({
      fileId: fileData.id,
      projectId,
      name,
    });

    return res.status(201).json({ deliverable });
  } catch (err: any) {
    console.error(err);
    return res.status(500).json({ error: 'Internal server error', details: err.message });
  }
}