// agents/designAgent.ts
//
// Defines a Mastra agent responsible for design-related tasks. This agent
// understands that it should call a custom tool to create deliverables in
// Penpot. When the agent receives a task requiring a deliverable, it uses
// the penpotDeliverableTool to create a new file and log it.

import { Agent } from '@mastra/core/agent';
import { openai } from '@ai-sdk/openai';
import { penpotDeliverableTool } from '../tools/penpotDeliverableTool';

export const designAgent = new Agent({
  name: 'design-agent',
  instructions: `
    You are an AI design assistant working inside a Next.js/Mastra application.
    When the user needs a new design deliverable in Penpot, you must use the
    penpot-deliverable tool. Provide the deliverable name and the Penpot
    project ID. Do not attempt to create deliverables without the tool.
    Always acknowledge when a deliverable has been created and include its
    Penpot file ID in your response.
  `,
  model: openai('gpt-5.1'),
  tools: {
    penpotDeliverableTool,
  },
});
