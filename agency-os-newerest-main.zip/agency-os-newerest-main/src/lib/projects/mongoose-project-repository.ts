import type { ProjectRepository, ProjectCreateRecord } from "./project-repository";
import { getProjectModel } from "./project-model";
import type { Project } from "./schemas";

const toProject = (doc: {
  _id: { toString: () => string };
  tenantId: string;
  clientId: string;
  name: string;
  budget: number;
  spend?: number | null;
  depositTotal?: number | null;
  timelineStart: string;
  timelineEnd: string;
  githubRepo?: string | null;
  createdAt: Date;
}): Project => ({
  id: doc._id.toString(),
  tenantId: doc.tenantId,
  clientId: doc.clientId,
  name: doc.name,
  budget: doc.budget,
  spend: doc.spend ?? 0,
  depositTotal: doc.depositTotal ?? 0,
  timelineStart: doc.timelineStart,
  timelineEnd: doc.timelineEnd,
  githubRepo: doc.githubRepo ?? null,
  createdAt: doc.createdAt.toISOString(),
});

export const createMongooseProjectRepository = (): ProjectRepository => ({
  create: async (input: ProjectCreateRecord) => {
    const model = getProjectModel();
    const doc = await model.create({ ...input, spend: 0, depositTotal: 0 });
    return toProject(doc);
  },
  listByTenantAndClient: async (tenantId, clientId) => {
    const model = getProjectModel();
    const docs = await model
      .find({ tenantId, clientId })
      .sort({ createdAt: -1 })
      .exec();
    return docs.map(toProject);
  },
  getByTenantAndId: async (tenantId, id) => {
    const model = getProjectModel();

    if (!id.match(/^[a-f\d]{24}$/i)) {
      return null;
    }

    const doc = await model.findOne({ _id: id, tenantId }).exec();
    return doc ? toProject(doc) : null;
  },
  updateSpendByTenantAndId: async (tenantId, id, spend) => {
    const model = getProjectModel();

    if (!id.match(/^[a-f\d]{24}$/i)) {
      return null;
    }

    const doc = await model
      .findOneAndUpdate({ _id: id, tenantId }, { spend }, { new: true })
      .exec();
    return doc ? toProject(doc) : null;
  },
  updateGithubRepoByTenantAndId: async (tenantId, id, githubRepo) => {
    const model = getProjectModel();

    if (!id.match(/^[a-f\d]{24}$/i)) {
      return null;
    }

    const doc = await model
      .findOneAndUpdate({ _id: id, tenantId }, { githubRepo }, { new: true })
      .exec();
    return doc ? toProject(doc) : null;
  },
  updateDepositTotalByTenantAndId: async (tenantId, id, depositTotal) => {
    const model = getProjectModel();

    if (!id.match(/^[a-f\d]{24}$/i)) {
      return null;
    }

    const doc = await model
      .findOneAndUpdate({ _id: id, tenantId }, { depositTotal }, { new: true })
      .exec();
    return doc ? toProject(doc) : null;
  },
});
