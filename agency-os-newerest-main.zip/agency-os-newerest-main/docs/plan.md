# AgencyOS — Implementation Plan

Living task board. Update status as slices ship. Decisions live in `CONTEXT.md` and `docs/adr/`.

## Product spine (locked)

| Decision | Choice |
| --- | --- |
| Product | **AgencyOS** — hybrid human CRM/PM + AI workforce |
| Conflict rule | Paul’s addendum wins over Blitzy body / PRD |
| Horizon | PRD **Phase 1** human surface + **full** AI workforce; Phase 2/3 deferred |
| PM agent | Orchestrates only (decompose, delegate, monitor, unblock, tie-break) |
| Teammates | **Execute** (research, code, email, scaffolds) |
| Policy gates | Client-facing + money → human **admin / agent-operator** approve |
| Data | **MongoDB only** (app + memory + vectors) |
| App shape | **Mastra-in-Next** monolith |
| Auth | Auth.js; 3 roles now, expandable toward PRD roles |
| Tenancy | `tenantId` on documents; **one tenant** in practice |
| Task SoR | Mongo; Linear/Monday mirror **status + assignee**; GitHub = code/PRs |
| Agents | Seed **10** + dynamic spawn **cap 10**/project |
| Code | Agents open **branches/PRs** on client repos; **humans merge** |
| Nurture | Prospector/Nurture **in v1** |
| Money kickoff | **Stripe deposits**; e-sign deferred |
| Deploy | Node 20+ + Atlas; host unspecified |
| Quality | TDD; lint/typecheck/test/build gates per slice |

## Status legend

`todo` · `in_progress` · `blocked` · `done`

---

## Slice A — Foundation

**Status:** `done`

- [x] Next.js 15 App Router + TypeScript + Tailwind v4
- [x] shadcn/ui init (`components.json` + Button; Tailwind v4)
- [x] Mastra (`@mastra/core`) stub wired in `src/mastra` (empty agents/tools/workflows; `@mastra/rag` deferred)
- [x] MongoDB singleton + Mongoose; `tenantId` on session/data path
- [x] Auth.js v5 skeleton: `admin`, `agent-operator`, `client`
- [x] `.env.example`, README stub, `docs/architecture.md` stub
- [x] Test harness (unit) green on empty smoke

**Exit:** app boots, auth session works, Mongo connects, CI scripts exist.

Note: Ticket 01 auth shell + Slice A leftovers (Mastra stub + shadcn Button). `@mastra/rag` deferred until Slice G.

---

## Slice B — Clients / Projects / Tasks + audit

**Status:** `done`

- [x] Models: Client, Project, Task, AgentActionLog (Conversation later)
- [x] Zod contracts + Client/Project/Task APIs (RBAC)
- [x] Dashboard clients/projects + task board UI
- [x] Correlation IDs on Task mutations (`x-correlation-id` → AgentActionLog)
- [x] Unit + API handler tests for Client/Project/Task + RBAC denial + audit writes

**Exit:** operator can CRUD clients/projects/tasks; actions auditable.

Note: Tickets 02–04 shipped Client → Project → Task board with action audit.

---

## Slice C — Project Manager agent + tool bus

**Status:** `done`

- [x] `project-manager` agent: orchestrate-only instructions + list/create Task tools
- [x] Mongo tools (listTasks/createTask) with Zod schemas
- [x] Every tool call → AgentActionLog
- [x] Streaming chat route `api/agents/[name]/chat`
- [x] AgentChat UI (operator) at `/dashboard/agents/project-manager`

**Exit:** PM can read/write domain state via tools; no silent tool use.

Note: Ticket 05 — list/create Task tools + streaming chat; full CRUD/retries deferred.

---

## Slice D — GitHub link + PR workflow

**Status:** `done`

- [x] GitHub tools (mocked client): branch + open PR from Task
- [x] Project ↔ repo binding in Mongo (`githubRepo`)
- [x] Policy: agents may PR; merge left to humans / branch protection (ADR-0004; no merge API)
- [x] Integration tests with mocked GitHub client

**Exit:** teammate (or PM-assisted flow) opens a PR on a linked repo from a task.

---

## Slice E — Linear + Monday sync

**Status:** `in_progress`

- [ ] Outbound sync: AgencyOS task → Linear + Monday (create/update)
- [x] Monday outbound sync: AgencyOS task → Monday (create/update) (ticket 08)
- [x] Monday inbound webhook: status/assignee → Mongo (ticket 08)
- [ ] Inbound webhooks: status/assignee → Mongo (Linear)
- [x] Scope/description edits from Monday ignored/parked with sync log (ticket 08)
- [x] Monday sync conflict log + operator visibility (`/api/monday-sync-logs`)
- [x] Tests for Monday mapping + conflict rules (ticket 08)
- [ ] Linear half of Slice E (ticket 07)

**Exit:** status/assignee round-trip; scope remains AgencyOS-owned.

Note: Ticket 07 shipped Linear-only mirror with mocked Linear client; Monday remains open.

---

## Slice F — Seed roster + policy gates + spawn

**Status:** `done`

- [x] Seed agents: tech-lead, design, research, frontend, backend, qa, prospector, nurture, onboarding (+ PM from C) (ticket 10)
- [x] Per-agent tool scopes + safety rules (ticket 10)
- [x] Policy-gate service: client email, SOW send, invoice/deposit → approve queue (ticket 09)
- [x] Dynamic spawn tool with **cap 10**/project + justification in action log (ticket 10)
- [x] Operator UI: approve/deny gated actions (ticket 09)

**Exit:** full seed roster runnable; gated actions block until approved; spawn enforced.

---

## Slice G — Agency skills + Exa/Resend + client pipeline

**Status:** `in_progress`

- [x] Tools: `createProjectBrief`, `generateSOW`, `buildMVPScaffold` (ticket 11)
- [ ] Workflows: `agency-delivery`, `client-pipeline` (lead score branching), plus stubs for lifecycle/sprint/code-review as needed
- [x] Exa search tools (ticket 13); Resend email tools remain with policy-gate queue (ticket 09/12)
- [x] Persist brief/SOW/scaffold on Project; show on project detail (ticket 11; SOW send policy-gated)
- [x] RAG ingest/query baseline for Research (hash embedding stand-in for `text-embedding-3-small`, source attribution) (ticket 13)
- [ ] Integration tests for delivery + pipeline happy paths

**Exit:** demo path lead → qualify → nurture → onboard → brief → SOW → scaffold with logs.

---

## Slice H — Client portal + Phase 1 human surfaces

**Status:** `in_progress`

- [x] `(portal)` routes: status + artifacts (client role) (ticket 14; approvals later)
- [ ] Design review (upload/annotate path; Figma deep-link later in I)
- [x] Budget guardrails (80/100/120% alerts) on Project
- [ ] Change requests + UAT checklist (Phase 1 core)
- [ ] Expand permission map toward PRD roles (without Auth0 yet)
- [ ] Tests for portal RBAC + approval state machine

**Exit:** client can review/approve; agency sees budget burn; CR/UAT paths work without e-sign.

---

## Slice I — Figma + Slack + Stripe

**Status:** `done`

- [x] Figma integration for design review
- [x] Slack notifications for gates, sync failures, budget alerts (ticket 19)
- [x] Stripe Checkout deposits; invoice hooks as Phase 1 allows
- [x] Policy gates on money movements
- [x] Webhook verification + tests

**Exit:** Phase 1 “essential” human integrations complete atop Paul-first set.

---

## Slice J — Harden

**Status:** `done`

- [x] Unit/integration/smoke coverage for critical workflows
- [x] Retries/timeouts/circuit breakers audited on all external APIs
- [x] Observability: correlation IDs end-to-end; runbooks
- [x] `docs/architecture.md`, `docs/workflows.md`, and `docs/runbooks.md` complete
- [x] Seed script + demo script
- [x] `lint` / `typecheck` / `test` / `build` all green

**Exit:** Definition of Done from build-prompt met for the locked spine.

---

## Risks

| Risk | Mitigation |
| --- | --- |
| Phase 1 human scope + full AI org is large | Ship A→G before expanding H; keep Phase 2/3 out |
| Mongo-only multi-tenant later | `tenantId` everywhere; revisit RLS-class isolation if needed |
| Dual tracker sync conflicts | Narrow bidirectional fields; log rejects |
| Agent cost / spawn sprawl | Cap 10; action-log justification; policy gates |
| PRD e-sign gap | Stripe deposits; document manual sign process in runbook |

## Progress log

| Date | Note |
| --- | --- |
| 2026-08-11 | Plan created from grill-with-docs; decisions in CONTEXT.md + ADR-0001…0005 |
| 2026-08-11 | Ticket 01: Auth shell + tenant dashboard shipped (tests/lint/typecheck/build green) |
| 2026-08-11 | Ticket 03: Project under Client (timeline + budget) shipped; 36 tests green |
| 2026-08-11 | Ticket 04: Tasks + AgentActionLog audit; Slice B done; 43 tests green |
| 2026-08-11 | Ticket 08: Monday status/assignee mirror + sync logs; Slice E in progress |
| 2026-08-11 | Ticket 09: Policy gate queue (pending/approve/deny + demo effect); Slice F in progress |
| 2026-08-11 | Ticket 10: Seed roster teammates + spawnTeammate cap 10; Slice F done |
