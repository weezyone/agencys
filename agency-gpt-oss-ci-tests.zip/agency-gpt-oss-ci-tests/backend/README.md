# Agency GPT OSS

Lightweight TypeScript service exposing three endpoints backed by OpenAI:
- `/proposal`: turns a brief into a client-ready proposal
- `/design`: produces actionable design guidance
- `/code`: returns scaffolded code snippets and structure

## Prerequisites
- Node.js 22+
- npm

## Setup
```bash
npm install
```

Create a `.env` file with:
```bash
OPENAI_API_KEY=your_key
# optional custom base URL
# OPENAI_BASE_URL=https://api.openai.com/v1
```

## Development
Run the API locally (uses tsx for ESM TS):
```bash
npm run dev
```
The server listens on http://localhost:3000 by default.

## Testing
Run once:
```bash
npm test
```
Watch mode:
```bash
npm run test:watch
```
With coverage (thresholds enforced via `jest.config.js`):
```bash
npm test -- --coverage
```
Coverage reports are emitted to the `coverage/` directory.

## CI
GitHub Actions workflow runs tests with coverage on pushes and PRs. Artifacts include the HTML coverage report.

Workflow file: `.github/workflows/ci.yml`

## Endpoints
- POST `/proposal` with `{ "brief": string }`
- POST `/design` with `{ "productDesc": string }`
- POST `/code` with `{ "featureDesc": string }`

## Project Structure
```
src/
  agents/            # Base agent + specializations
  services/          # Thin service layer
  __tests__/         # Jest unit tests + snapshots
  server.ts          # Express app
```

## Notes
- Uses `tsx` runner for Node ESM compatibility.
- TypeScript config set to `module: nodenext` and Node types enabled.
