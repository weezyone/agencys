// src/server.ts
import express from "express";
import "dotenv/config";
import {
  generateProposal,
  generateDesignSpec,
  generateCodeScaffold,
} from "./services/agencyService.js";

const app = express();
app.use(express.json());

app.post("/proposal", async (req, res) => {
  const { brief } = req.body;
  if (!brief) return res.status(400).json({ error: "brief is required" });
  const result = await generateProposal(brief);
  res.json({ proposal: result });
});

app.post("/design", async (req, res) => {
  const { productDesc } = req.body;
  if (!productDesc) return res.status(400).json({ error: "productDesc is required" });
  const result = await generateDesignSpec(productDesc);
  res.json({ designSpec: result });
});

app.post("/code", async (req, res) => {
  const { featureDesc } = req.body;
  if (!featureDesc) return res.status(400).json({ error: "featureDesc is required" });
  const result = await generateCodeScaffold(featureDesc);
  res.json({ codeScaffold: result });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 Agency API listening on ${PORT}`));