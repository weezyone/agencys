// src/agents/baseAgent.js
import { openai, DEFAULT_MODEL } from "../openaiClient.js";

export class BaseAgent {
  constructor(opts) {
    this.systemPrompt = opts.systemPrompt;
    this.temperature = opts.temperature ?? 0.7;
  }

  async run(userMessage) {
    const chat = await openai.chat.completions.create({
      model: DEFAULT_MODEL,
      temperature: this.temperature,
      messages: [
        { role: "system", content: this.systemPrompt },
        { role: "user", content: userMessage },
      ],
    });

    return chat.choices[0].message.content?.trim() ?? "";
  }
}
