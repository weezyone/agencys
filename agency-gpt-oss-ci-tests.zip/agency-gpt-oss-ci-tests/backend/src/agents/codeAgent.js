// src/agents/codeAgent.js
import { BaseAgent } from "./baseAgent.js";

export const codeAgent = new BaseAgent({
  systemPrompt: `
You are a senior full‑stack developer.
Given a feature description, output:
1. Folder structure (markdown)
2. Boilerplate code snippets (TypeScript/React)
3. Brief explanation of each file.
Only return code blocks, no extra commentary.
`,
});
