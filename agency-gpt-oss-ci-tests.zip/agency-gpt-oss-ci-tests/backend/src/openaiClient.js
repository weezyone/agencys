// src/openaiClient.js
import { OpenAI } from "openai";
import "dotenv/config";

export const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
  baseURL: process.env.OPENAI_BASE_URL,
  // The Agent SDK internally uses the same client; we just expose it here.
});
export const DEFAULT_MODEL = "gpt-oss-120b";
