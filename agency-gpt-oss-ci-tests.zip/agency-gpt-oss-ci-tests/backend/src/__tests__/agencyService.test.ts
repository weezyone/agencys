// src/__tests__/agencyService.test.ts
import { generateProposal, generateDesignSpec, generateCodeScaffold } from "../services/agencyService";
import { openai } from "../openaiClient";

jest.mock("../openaiClient", () => ({
  openai: {
    chat: {
      completions: {
        create: jest.fn(),
      },
    },
  },
  DEFAULT_MODEL: "gpt-oss-120b",
}));

const mockResponse = (content: string) => ({
  choices: [{ message: { content } }],
});

describe("Agency Service", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("creates a proposal from a brief", async () => {
    // Arrange
    const brief = "Build a landing page for a SaaS product.";
    (openai.chat.completions.create as jest.Mock).mockResolvedValue(
      mockResponse("✅ Project Overview ...")
    );

    // Act
    const proposal = await generateProposal(brief);

    // Assert
    expect(openai.chat.completions.create).toHaveBeenCalledWith(
      expect.objectContaining({
        model: "gpt-oss-120b",
        messages: expect.arrayContaining([
          expect.objectContaining({ role: "user", content: brief }),
        ]),
      })
    );
    expect(proposal).toContain("✅ Project Overview");
  });

  it("sends the proposal agent's system prompt", async () => {
    // Arrange
    const brief = "Increase conversion for onboarding";
    (openai.chat.completions.create as jest.Mock).mockResolvedValue(
      mockResponse("OK")
    );

    // Act
    await generateProposal(brief);

    // Assert
    expect(openai.chat.completions.create).toHaveBeenCalledWith(
      expect.objectContaining({
        messages: expect.arrayContaining([
          expect.objectContaining({
            role: "system",
            content: expect.stringContaining("You are a senior consultant for a dev/design agency."),
          }),
        ]),
      })
    );
  });

  it("creates a design spec from a product description", async () => {
    // Arrange
    const productDesc = "A mobile app for personal budgeting";
    (openai.chat.completions.create as jest.Mock).mockResolvedValue(
      mockResponse("Flows: Onboarding, Budget Setup")
    );

    // Act
    const design = await generateDesignSpec(productDesc);

    // Assert
    expect(openai.chat.completions.create).toHaveBeenCalledWith(
      expect.objectContaining({
        model: "gpt-oss-120b",
        messages: expect.arrayContaining([
          expect.objectContaining({ role: "user", content: productDesc }),
          expect.objectContaining({ role: "system", content: expect.stringContaining("You are a UI/UX designer assistant.") }),
        ]),
      })
    );
    expect(design).toContain("Flows");
  });

  it("creates a code scaffold from a feature description", async () => {
    // Arrange
    const featureDesc = "Add authentication with OAuth2";
    (openai.chat.completions.create as jest.Mock).mockResolvedValue(
      mockResponse("```ts\n// auth setup\n```")
    );

    // Act
    const code = await generateCodeScaffold(featureDesc);

    // Assert
    expect(openai.chat.completions.create).toHaveBeenCalledWith(
      expect.objectContaining({
        model: "gpt-oss-120b",
        messages: expect.arrayContaining([
          expect.objectContaining({ role: "user", content: featureDesc }),
          // Be lenient on punctuation/whitespace differences
          expect.objectContaining({ role: "system", content: expect.stringContaining("You are a senior full") }),
        ]),
      })
    );
    expect(code).toContain("auth setup");
  });

  it("propagates OpenAI errors for proposals", async () => {
    // Arrange
    const brief = "Do something";
    (openai.chat.completions.create as jest.Mock).mockRejectedValue(
      new Error("Boom")
    );

    // Assert (Act inside expectation)
    await expect(generateProposal(brief)).rejects.toThrow("Boom");
  });

  it("propagates OpenAI errors for design", async () => {
    // Arrange
    const productDesc = "Budget app";
    (openai.chat.completions.create as jest.Mock).mockRejectedValue(
      new Error("Design failed")
    );

    // Assert
    await expect(generateDesignSpec(productDesc)).rejects.toThrow("Design failed");
  });

  it("propagates OpenAI errors for code", async () => {
    // Arrange
    const featureDesc = "Auth";
    (openai.chat.completions.create as jest.Mock).mockRejectedValue(
      new Error("Code failed")
    );

    // Assert
    await expect(generateCodeScaffold(featureDesc)).rejects.toThrow("Code failed");
  });

  it("proposal output matches snapshot", async () => {
    // Arrange
    (openai.chat.completions.create as jest.Mock).mockResolvedValue(
      mockResponse(
        [
          "✅ Project Overview",
          "- Build MVP landing page",
          "- Integrate analytics",
          "Timeline: 2 weeks",
          "Estimated cost: $4,800",
          "Next steps: Kickoff call",
        ].join("\n")
      )
    );

    // Act
    const result = await generateProposal("Brief text");

    // Assert
    expect(result).toMatchSnapshot();
  });

  it("design output matches snapshot", async () => {
    // Arrange
    (openai.chat.completions.create as jest.Mock).mockResolvedValue(
      mockResponse(
        [
          "Flows: Onboarding, Budget Setup, Insights",
          "Palette: #0ea5e9, #111827, #f8fafc",
          "Fonts: Inter / Roboto Mono",
        ].join("\n")
      )
    );

    // Act
    const result = await generateDesignSpec("Personal budgeting app");

    // Assert
    expect(result).toMatchSnapshot();
  });

  it("code scaffold output matches snapshot", async () => {
    // Arrange
    (openai.chat.completions.create as jest.Mock).mockResolvedValue(
      mockResponse(
        [
          "```ts",
          "// src/auth/init.ts",
          "export const initAuth = () => {/* ... */}",
          "```",
        ].join("\n")
      )
    );

    // Act
    const result = await generateCodeScaffold("Add OAuth2 auth");

    // Assert
    expect(result).toMatchSnapshot();
  });

  it("proposal payload includes temperature and matches snapshot", async () => {
    // Arrange
    (openai.chat.completions.create as jest.Mock).mockResolvedValue(
      mockResponse("ok")
    );

    // Act
    await generateProposal("Brief text");

    // Assert
    const payload = (openai.chat.completions.create as jest.Mock).mock.calls[0][0];
    expect(payload.temperature).toBeCloseTo(0.7);
    expect(payload).toMatchSnapshot();
  });

  it("design payload includes temperature and matches snapshot", async () => {
    // Arrange
    (openai.chat.completions.create as jest.Mock).mockResolvedValue(
      mockResponse("ok")
    );

    // Act
    await generateDesignSpec("Personal budgeting app");

    // Assert
    const payload = (openai.chat.completions.create as jest.Mock).mock.calls[0][0];
    expect(payload.temperature).toBeCloseTo(0.7);
    expect(payload).toMatchSnapshot();
  });

  it("code payload includes temperature and matches snapshot", async () => {
    // Arrange
    (openai.chat.completions.create as jest.Mock).mockResolvedValue(
      mockResponse("ok")
    );

    // Act
    await generateCodeScaffold("Add OAuth2 auth");

    // Assert
    const payload = (openai.chat.completions.create as jest.Mock).mock.calls[0][0];
    expect(payload.temperature).toBeCloseTo(0.7);
    expect(payload).toMatchSnapshot();
  });
});