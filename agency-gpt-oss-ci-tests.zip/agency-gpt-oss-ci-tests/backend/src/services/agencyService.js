// src/services/agencyService.ts
import { proposalAgent } from "../agents/proposalAgent.js";
import { designAgent } from "../agents/designAgent.js";
import { codeAgent } from "../agents/codeAgent.js";

export async function generateProposal(brief){
  return await proposalAgent.run(brief);
}

export async function generateDesignSpec(productDesc) {
  return await designAgent.run(productDesc);
}

export async function generateCodeScaffold(featureDesc) {
  return await codeAgent.run(featureDesc);
}
