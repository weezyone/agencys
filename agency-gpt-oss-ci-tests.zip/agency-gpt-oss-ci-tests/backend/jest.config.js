// jest.config.js
module.exports = {
    preset: "ts-jest",
    testEnvironment: "node",
    collectCoverage: true,
    coverageDirectory: "coverage",
    coverageReporters: ["text", "lcov"],
    coverageThreshold: {
      global: {
        branches: 60,
        functions: 70,
        lines: 70,
        statements: 70,
      },
    },
  };