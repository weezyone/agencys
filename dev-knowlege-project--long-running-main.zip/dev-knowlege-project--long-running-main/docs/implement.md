# Execution Runbook

Use this file as the operational contract for autonomous execution.
Complete work from start to finish without stopping for per-milestone approval unless truly blocked.

## 1. Read Order
1. `dev-knowlege.md`
2. `docs/prompt.md`
3. `docs/plans.md`
4. `docs/documentation.md`
5. `docs/architecture.md`

## 2. Non-Negotiable Rules
- Plan before broad implementation.
- Keep changes small, coherent, and reviewable.
- Keep `docs/plans.md`, `docs/documentation.md`, and `docs/architecture.md` aligned with reality.
- Run verification repeatedly, not only at the end.
- Fix red tests/lint/type errors before continuing.
- Do not rewrite unrelated code.

## 3. Execution Loop
Repeat this loop until all milestones are done:
1. Pick next incomplete milestone in `docs/plans.md`.
2. Re-state target acceptance criteria in `docs/documentation.md`.
3. Implement the smallest set of changes to satisfy criteria.
4. Run milestone verification commands.
5. If verification fails, fix immediately and rerun.
6. Mark milestone status and log decisions/changes.
7. Update architecture notes if behavior/design changed.

## 4. Decision Policy
- If missing detail is low-risk, choose a reasonable default and continue.
- If a decision affects API contracts, data shape, persistence, auth, security, or cost, log the rationale in docs before moving on.
- If blocked by missing credentials/secrets/external access, stop and request only the missing prerequisite.

## 5. Documentation Policy
- `docs/plans.md`: planning truth (scope, milestones, risk, verification matrix).
- `docs/documentation.md`: execution truth (timeline, what changed, what passed/failed, current status).
- `docs/architecture.md`: technical truth (system shape, data flows, interfaces, invariants).

Update the docs in the same commit chunk as code changes whenever possible.

## 6. Verification Policy
At minimum:
- Run the per-milestone checks from `docs/plans.md`.
- Run full validation before final handoff.
- Record command + result summary in `docs/documentation.md`.

If tests are missing in an area with logic risk, add targeted tests before marking the milestone complete.

## 7. Finalization Criteria
Stop only when all are true:
- Every milestone is marked complete.
- Verification matrix is fully green.
- Documentation and architecture are up to date.
- Remaining issues are explicitly documented as follow-ups with rationale.

## 8. Handoff Format
Provide:
- What was implemented (mapped to milestones).
- What was verified (commands + result).
- Known follow-ups or deferred scope.
- Any setup needed for humans to run/demo quickly.
