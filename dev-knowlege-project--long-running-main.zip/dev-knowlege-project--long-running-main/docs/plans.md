# Project Implementation Plan

This is the source-of-truth execution plan for the long-horizon run.

## 1. Inputs
- `dev-knowlege.md`
- `docs/prompt.md`
- `docs/implement.md`
- Existing codebase and tests
- User instructions from this thread

## 2. Scope Summary

### Phase 1 — Repository scaffold (complete)
- Project statement: Deliver and document a working long-horizon scaffold that includes a React + TypeScript frontend, a local health/WebSocket server, a deterministic JSON export script, and full project quality gates.
- Success criteria:
  - App renders scaffold landing page and can display API and WebSocket status.
  - Server responds to `/api/health` and supports `/ws` handshake.
  - Export script reads example design input and writes deterministic summary output.
  - Quality commands (`typecheck`, `test`, `lint`, `build`, `export`) pass.
  - Planning/architecture/execution docs are fully populated and aligned.
- Explicit non-goals (Phase 1):
  - Building a full collaborative design editor.
  - Introducing persistence, authentication, or production deployment infra beyond scaffold.
  - Adding complex server business logic beyond scaffold health and connection checks.

### Phase 2 — DevKnowledge Base product (in progress)
- Project statement: Implement **DevKnowledge Base** per `dev-knowlege.md` — developer knowledge storage, semantic search, RAG chat with citations, URL ingestion, analytics, accounts, and UX/visual system (triadic palette, dark slate, Inter + JetBrains Mono, Phosphor, responsive navigation).
- Success criteria (high level):
  - Persistent knowledge items with upload/ingest (files, paste, URLs) and metadata.
  - Search with vector relevance and previews within agreed latency targets.
  - Chat with retrieval-grounded answers and source links to stored items.
  - Analytics dashboard with accurate metrics and robust loading/empty/error states.
  - Documented API/data boundaries; quality gates green; feature verification logged.
- Explicit non-goals (initial Phase 2 slices):
  - Full enterprise compliance/SSO unless scoped as a milestone.
  - Offline-first sync in v1 (may be a later milestone).
- Key constraints:
  - Keep diffs focused and reviewable; milestone-by-milestone verification.
  - Strict TypeScript and lint; safe URL fetching; secrets only via environment (never committed).
  - UX aligned to brief: efficient, intelligent, organized; accessible contrast and keyboard paths for core flows.

## 3. Verification Matrix
Run these at milestone boundaries and before final handoff.

**Baseline (Phase 1 — always keep green):**
- [x] `npm run typecheck`
- [x] `npm run test`
- [x] `npm run lint`
- [x] `npm run build`
- [x] `npm run export -- --input examples/starter.design.json --output exports/starter.export.json`

**Phase 2 (add as features land; document commands in milestone notes):**
- [x] Persistence migrations apply cleanly on a fresh environment (`pnpm run db:migrate`; server also runs migrations on startup).
- [x] Auth/session smoke (manual or automated) for protected routes/APIs (`POST /api/auth/login`, `GET /api/auth/me`, `RequireAuth` on app routes).
- [ ] Search/chat smoke with fixture data (including citation presence for RAG).
- [ ] URL ingestion smoke on a curated allowlisted test URL set.

Last fully green Phase 1 milestone: `Milestone 14 - Final verification and handoff sync`  
Last Phase 1 verification time: `2026-02-27 19:36 UTC`  
Phase 2 kickoff: `2026-03-22` — PRD canon in `dev-knowlege.md`, Phase 2 milestones 15–28 drafted below.

## 4. Milestones (Minimum: 14)

### Milestone 01 - Repository and runtime baseline audit
Status: [ ] Planned [ ] In Progress [x] Complete
Scope:
- Review repository structure and key runtime boundaries.
Files/modules:
- `README.md`, `package.json`, `src/`, `server/`, `scripts/`, `docs/`
Acceptance criteria:
- Inventory of major modules and responsibilities captured.
Verification:
- Manual repo audit
Notes:
- Completed before planning finalization.

### Milestone 02 - Frontend scaffold verification
Status: [ ] Planned [ ] In Progress [x] Complete
Scope:
- Verify React app entrypoint and landing scaffold rendering behavior.
Files/modules:
- `src/main.tsx`, `src/App.tsx`, `src/index.css`
Acceptance criteria:
- App renders heading, descriptive text, and status card sections.
Verification:
- `npm run test`
Notes:
- Existing tests assert primary heading content.

### Milestone 03 - API health integration verification
Status: [ ] Planned [ ] In Progress [x] Complete
Scope:
- Verify frontend health check behavior and server endpoint contract.
Files/modules:
- `src/App.tsx`, `server/index.ts`
Acceptance criteria:
- `/api/health` returns expected JSON and UI handles response/failure.
Verification:
- `npm run dev` (manual), `npm run build`
Notes:
- Contract is `{ status: "ok", service: string }`.

### Milestone 04 - WebSocket lifecycle verification
Status: [ ] Planned [ ] In Progress [x] Complete
Scope:
- Verify client WebSocket state and server connection behavior.
Files/modules:
- `src/App.tsx`, `server/index.ts`
Acceptance criteria:
- Client transitions from connecting to open/closed and server emits ready message.
Verification:
- `npm run dev` (manual)
Notes:
- UI status chip text reflects connection state.

### Milestone 05 - Data model baseline review
Status: [ ] Planned [ ] In Progress [x] Complete
Scope:
- Validate shared model types used by export and examples.
Files/modules:
- `src/core/model/types.ts`, `examples/starter.design.json`
Acceptance criteria:
- Example layer types align with model definitions.
Verification:
- `npm run typecheck`
Notes:
- Current model intentionally minimal and extensible.

### Milestone 06 - Export pipeline contract verification
Status: [ ] Planned [ ] In Progress [x] Complete
Scope:
- Validate argument parsing, output shaping, and file writing behavior.
Files/modules:
- `scripts/export.mts`
Acceptance criteria:
- Script fails with clear usage for missing args and writes summary output for valid input.
Verification:
- `npm run export -- --input examples/starter.design.json --output exports/starter.export.json`
Notes:
- Output includes `version`, `projectName`, `artboardCount`, `layerCount`.

### Milestone 07 - Testing setup verification
Status: [ ] Planned [ ] In Progress [x] Complete
Scope:
- Confirm Vitest + Testing Library setup and base test coverage.
Files/modules:
- `vite.config.ts`, `src/test/setup.ts`, `src/App.test.tsx`
Acceptance criteria:
- Test runner executes in jsdom and baseline UI assertions pass.
Verification:
- `npm run test`
Notes:
- Coverage can be expanded in future feature milestones.

### Milestone 08 - Type safety gate verification
Status: [ ] Planned [ ] In Progress [x] Complete
Scope:
- Validate strict TypeScript project references and compile constraints.
Files/modules:
- `tsconfig*.json`, `server/tsconfig.json`
Acceptance criteria:
- No type errors across app, node config, and server projects.
Verification:
- `npm run typecheck`
Notes:
- Build uses project references for coordinated checks.

### Milestone 09 - Lint and style gate verification
Status: [ ] Planned [ ] In Progress [x] Complete
Scope:
- Confirm lint baseline and core rule set.
Files/modules:
- `eslint.config.js`, source files
Acceptance criteria:
- Lint passes with zero warnings.
Verification:
- `npm run lint`
Notes:
- Consistent type imports enforced.

### Milestone 10 - Production build verification
Status: [ ] Planned [ ] In Progress [x] Complete
Scope:
- Confirm production build pipeline outputs without errors.
Files/modules:
- `vite.config.ts`, `package.json`
Acceptance criteria:
- `npm run build` succeeds.
Verification:
- `npm run build`
Notes:
- Includes TypeScript build step prior to Vite bundling.

### Milestone 11 - Plan completion
Status: [ ] Planned [ ] In Progress [x] Complete
Scope:
- Fill planning document with coherent scope, risks, milestones, and checks.
Files/modules:
- `docs/plans.md`
Acceptance criteria:
- No placeholder markers remain; plan is actionable.
Verification:
- Manual documentation review
Notes:
- This milestone establishes execution source-of-truth.

### Milestone 12 - Execution log synchronization
Status: [ ] Planned [ ] In Progress [x] Complete
Scope:
- Record current status, verification evidence, and decisions.
Files/modules:
- `docs/documentation.md`
Acceptance criteria:
- Documentation reflects actual implementation and checks.
Verification:
- Manual documentation review
Notes:
- Includes milestone tracker and verification log.

### Milestone 13 - Architecture record synchronization
Status: [ ] Planned [ ] In Progress [x] Complete
Scope:
- Document architecture, data flow, interfaces, and technical decisions.
Files/modules:
- `docs/architecture.md`
Acceptance criteria:
- Architecture doc mirrors implemented scaffold behavior.
Verification:
- Manual documentation review
Notes:
- Capture tradeoffs for scaffold simplicity.

### Milestone 14 - Final verification and handoff sync
Status: [ ] Planned [ ] In Progress [x] Complete
Scope:
- Run full verification matrix and ensure docs + implementation alignment.
Files/modules:
- Entire repository, especially `docs/`
Acceptance criteria:
- All quality gates green and handoff artifacts complete.
Verification:
- Full verification matrix in section 3
Notes:
- Ready for future feature-specific implementation cycles.

### Phase 2 — DevKnowledge Base (milestones 15–28)

### Milestone 15 - PRD alignment and design system foundation
Status: [ ] Planned [ ] In Progress [x] Complete
Scope:
- Canon product brief in `dev-knowlege.md`; planning/prompt docs synced; CSS tokens for OKLCH palette, typography (Inter, JetBrains Mono), spacing scale (4px base), dark surfaces.
Files/modules:
- `dev-knowlege.md`, `docs/prompt.md`, `docs/plans.md`, `docs/documentation.md`, `src/index.css` (or theme module), `tailwind.config.*` if extended
Acceptance criteria:
- Brief and Phase 2 milestones reflect PRD; baseline quality gates still pass.
Verification:
- `npm run typecheck && npm run test && npm run lint && npm run build`

### Milestone 16 - Application shell and navigation
Status: [ ] Planned [ ] In Progress [x] Complete
Scope:
- Client routing; layout with sidebar (collapsible) and responsive bottom navigation on small viewports; command palette stub or full implementation; Phosphor icons integrated.
Files/modules:
- `src/` (routes, layout components), dependencies as needed
Acceptance criteria:
- Navigable shell with placeholder views for Library, Search, Chat, Ingest, Analytics; no layout break on mobile width.
Verification:
- `npm run test`, manual responsive check

### Milestone 17 - Persistence and data model
Status: [ ] Planned [ ] In Progress [x] Complete
Scope:
- Choose and integrate a database (e.g. PostgreSQL or SQLite for dev) with migrations; core entities: users, knowledge items, attachments/metadata, tags/categories as per model.
Files/modules:
- `server/`, migration tooling, `src/core/model/types.ts` (expand)
Acceptance criteria:
- Schema documented; migrations apply idempotently on fresh DB; seed script optional.
Verification:
- Migration run + smoke query; `npm run typecheck`

### Milestone 18 - Authentication and sessions
Status: [ ] Planned [ ] In Progress [x] Complete
Scope:
- Account creation/login/session (or OAuth later if deferred); protected API routes; frontend auth guards.
Files/modules:
- `server/`, `src/` auth context
Acceptance criteria:
- Unauthenticated users cannot read/write private knowledge APIs; session expiry handled gracefully.
Verification:
- Manual or automated auth tests; `npm run test` where applicable

### Milestone 19 - Knowledge ingest: files and paste
Status: [ ] Planned [ ] In Progress [x] Complete
Scope:
- Upload API with drag-drop and picker UI; paste path; metadata extraction pipeline; text extraction for supported types; metadata-only path for unsupported types per PRD.
Files/modules:
- `server/` upload handlers, storage (local disk or object storage abstraction), `src/` upload dialog
Acceptance criteria:
- Representative file types ingest with stored preview text where applicable; errors surfaced in UI.
Verification:
- Manual upload tests; unit tests for parsers where safe

### Milestone 20 - Chunked upload and large-file UX
Status: [ ] Planned [ ] In Progress [x] Complete
Scope:
- Chunked/resumable upload for files >10MB; progress indicators; server-side assembly.
Files/modules:
- Upload client/server
Acceptance criteria:
- Large file completes without timeout; progress visible; failure retry path.
Verification:
- Manual test with large fixture; optional integration test with mocked storage

### Milestone 21 - Keyword and semantic search
Status: [ ] Planned [ ] In Progress [ ] Complete
Scope:
- Embeddings pipeline for knowledge items; vector index (DB extension or dedicated store); search API returning ranked results with snippets; fallback to keyword-only when embeddings unavailable.
Files/modules:
- `server/` search service, embedding worker hooks, `src/` search UI
Acceptance criteria:
- p95 target documented; “no results” state with suggestions stub or implementation.
Verification:
- Search integration test with fixture corpus; latency spot-check

### Milestone 22 - AI chat with RAG and citations
Status: [ ] Planned [ ] In Progress [ ] Complete
Scope:
- Chat UI (messages, streaming optional); RAG retrieval from knowledge base; responses include **source citations**; graceful degradation when AI API unavailable.
Files/modules:
- `server/` chat endpoint, `src/` chat route
Acceptance criteria:
- Answers reference stored item IDs/links; error banner when AI off; no fabricated citations.
Verification:
- Scripted chat test with fixture KB; manual spot-check

### Milestone 23 - Web URL ingestion
Status: [ ] Planned [ ] In Progress [ ] Complete
Scope:
- URL submission; fetch with SSRF/rate protections; extract text/main content; store as knowledge items; optional summary.
Files/modules:
- `server/` ingest worker, `src/` ingest form
Acceptance criteria:
- Curated test URLs ingest cleanly; failures show actionable errors.
Verification:
- Allowlisted test URLs; unit tests for extractor edge cases

### Milestone 24 - Analytics dashboard
Status: [ ] Planned [ ] In Progress [ ] Complete
Scope:
- Metrics: counts, usage over time, top items or tags as feasible; charts/tables; export optional.
Files/modules:
- `server/` metrics endpoints, `src/` dashboard route
Acceptance criteria:
- Numbers match DB; loading/empty states; sortable tables where applicable.
Verification:
- Snapshot or manual verification against seeded data

### Milestone 25 - Edge cases and resilience
Status: [ ] Planned [ ] In Progress [ ] Complete
Scope:
- Unsupported file handling; search empty states; AI failure fallback; network error retry patterns across critical flows.
Files/modules:
- Cross-cutting UI and API
Acceptance criteria:
- Documented behavior matches `dev-knowlege.md` edge-case table where implemented.
Verification:
- Manual checklist; `npm run test`

### Milestone 26 - Realtime and collaboration hooks (optional stretch)
Status: [ ] Planned [ ] In Progress [ ] Complete
Scope:
- Extend WebSocket usage for live status (indexing, upload progress) or presence; keep contract documented.
Files/modules:
- `server/index.ts`, client hooks
Acceptance criteria:
- WS events versioned; no regressions to health checks.
Verification:
- Manual WS test; unit tests if applicable

### Milestone 27 - Integration and regression hardening
Status: [ ] Planned [ ] In Progress [ ] Complete
Scope:
- Broaden automated tests (API, search, chat); CI-friendly scripts; performance spot-checks.
Files/modules:
- `src/**/*.test.*`, `server/**`, CI config if added
Acceptance criteria:
- Critical paths covered; baseline gates green.
Verification:
- `npm run typecheck && npm run test && npm run lint && npm run build`

### Milestone 28 - Phase 2 verification and handoff
Status: [ ] Planned [ ] In Progress [ ] Complete
Scope:
- Full Phase 2 verification matrix; update `docs/architecture.md` and `docs/documentation.md`; demo script for product.
Files/modules:
- `docs/*`, repository-wide
Acceptance criteria:
- All Phase 2 success criteria in section 2 met or explicitly deferred with rationale; docs match shipped behavior.
Verification:
- Full matrix + recorded timestamps in `docs/documentation.md`

## 5. Risk Register

| Risk | Impact | Likelihood | Mitigation | Trigger | Status |
| --- | --- | --- | --- | --- | --- |
| AI/embedding vendor cost or rate limits | High | Medium | Cache embeddings; batch; configurable models; degrade to keyword | API throttling or budget cap | Watching |
| URL ingestion SSRF or abuse | High | Medium | Allowlists, private IP blocks, SSRF guardrails, rate limits | Malicious URL or scan attempts | Active |
| Vector search latency SLOs missed | Medium | Medium | Index tuning; async embedding; scope corpus per tenant | p95 > 2s in dev tests | Watching |
| Schema drift between client and server | Medium | Medium | Shared types or codegen; contract tests | API mismatch bugs | Watching |
| Project scope creep beyond phased milestones | Medium | High | Strict milestone gates; defer non-MVP to backlog | Unbounded feature requests | Active |
| Realtime contract drift between client/server | Medium | Medium | Keep WS event contract documented in architecture and add tests when features grow | WS state inconsistencies in UI | Watching |
| Export schema expansion introduces nondeterministic output | Medium | Medium | Preserve stable output ordering/shape and add regression tests for script outputs | Export diffs fluctuate for same input | Watching |

## 6. Architecture Snapshot
- **Phase 1 (shipped)**: Vite React frontend, Node HTTP/WS server, export script, TypeScript model module, docs framework.
- **Phase 2 (target)**: Authenticated API, relational + vector store, file/blob storage, embedding + retrieval, LLM integration for chat (env-configured), URL ingest workers, analytics aggregates, design system (`dk-*` tokens).
- Main data flows (current): browser fetches `/api/health`; browser opens `/ws`; export script reads JSON and writes summarized JSON.
- Main data flows (target): authenticated CRUD on knowledge items; async indexing → embeddings; search and chat read indexed content; URL ingest pipeline; dashboard reads metrics.
- External dependencies: React 19, Vite 7, ws, Vitest, ESLint, TypeScript; Phase 2 will add DB client, AI SDKs, and icon/fonts packages as milestones land.
- Critical invariants: health response status must be `ok`; export output version pinned to `1` until revised; summary counts derived deterministically from input; **product phase** will add invariants for citation integrity and SSRF controls (documented per milestone).

## 7. Demo Script
- Demo goal: Verify scaffold runtime and export pipeline end-to-end.
- Setup commands:
  - `npm install`
  - `npm run dev`
- Steps:
  - Open `http://localhost:5173` and confirm landing UI renders.
  - Confirm API health displays as healthy and realtime status transitions to connected.
  - In a second terminal, run `npm run export -- --input examples/starter.design.json --output exports/starter.export.json`.
- Expected outcomes:
  - UI shows scaffold title, healthy API status, and WebSocket connection status.
  - Export file is generated with deterministic project/artboard/layer summary.

## 8. Final Checklist
- [x] All milestone statuses updated
- [x] Risks reviewed and current
- [x] `docs/architecture.md` reflects shipped behavior
- [x] `docs/documentation.md` includes full execution log
- [x] All verification commands are green
