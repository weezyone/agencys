# Architecture Record

This document captures the architecture as implemented and the **target direction** for DevKnowledge Base (see `dev-knowlege.md`).

## 0. Target product (Phase 2 — in planning / partial UI tokens)

- **Product**: DevKnowledge Base — developer knowledge management with ingest (files, paste, URLs), semantic search, RAG chat with citations, analytics, and accounts (per `dev-knowlege.md`).
- **Intended major components** (not all built yet): authenticated API + persistence; object/file storage abstraction; embedding + vector retrieval; optional external LLM for chat; URL fetch worker with SSRF protections; analytics read models.
- **UX system**: OKLCH palette and typography tokens in `src/styles/tokens.css` + Tailwind `dk-*` colors; Inter + JetBrains Mono (loaded in `index.html`).

The sections below describe what exists **today** unless labeled as future work.

## 1. Context and Goals
- Problem statement (scaffold): Provide a dependable starter architecture for long-horizon autonomous coding runs with planning, implementation, and verification workflows prewired.
- Problem statement (product): Centralize developer knowledge with efficient search, organized metadata, and AI-grounded answers with citations (`dev-knowlege.md`).
- Target users: Engineers and teams curating reusable technical knowledge; autonomous coding workflows using this repo’s docs discipline.
- Primary success metrics:
  - Development environment starts quickly (`npm run dev`).
  - Health and realtime connectivity are observable in UI.
  - Core quality gates pass consistently.
  - Documentation stays synchronized with shipped behavior.
  - **Product phase**: ingest/search/chat SLAs and safety properties as defined in milestones 15–28.
- Non-goals (scaffold phase, historical):
  - Full-feature design editor functionality.
  - Production auth, persistence, and multi-service deployment (superseded by Phase 2 scope where applicable).
  - Complex collaboration protocol beyond a simple WS ready signal.
- Hard constraints:
  - Strict TypeScript and lint checks.
  - Deterministic export output (existing export script).
  - Docs-first milestone process for long-horizon execution.

## 2. System Topology
- High-level components:
  - React frontend (`src/`)
  - Node HTTP + WebSocket server (`server/`)
  - Export utility (`scripts/export.mts`)
  - Planning/architecture/run docs (`docs/`)
- Runtime boundaries (client/server/services):
  - Browser app served by Vite on port 5173.
  - Local Node server on port 8787 for `/api/health`, `/api/knowledge/items`, and `/ws`.
  - SQLite file (`data/devknowledge.db` by default) accessed only from the Node server via Drizzle + `better-sqlite3`.
  - Build-time/export tooling executes as local Node scripts.
- Deployment/runtime model:
  - Local development monorepo-like single package with concurrent app/server processes.
- Trust boundaries:
  - Browser trusts local dev server proxy for API/WS endpoints.
  - Server accepts unauthenticated local requests in scaffold mode.

## 3. Core Modules and Responsibilities

| Module | Responsibility | Inputs | Outputs | Owner Notes |
| --- | --- | --- | --- | --- |
| `src/App.tsx` | Declarative routes for shell + feature placeholders | React Router location | Page components via nested routes | Wildcard redirects to `/` |
| `src/main.tsx` | App bootstrap | — | `BrowserRouter` + `App` | Entry for client routing |
| `src/layout/AppLayout.tsx` | Collapsible sidebar (md+), mobile bottom nav, page outlet | Matched child route | `Outlet` content | Persists sidebar width preference in `localStorage` |
| `src/hooks/useServiceStatus.ts` | Health fetch + WebSocket lifecycle | `/api/health`, `/ws` | `health`, `wsLabel` | Shared by Overview |
| `src/components/CommandPalette.tsx` | Quick navigation (⌘/Ctrl+K) | User actions | `navigate()` to main routes | Search/filter stub for later |
| `src/navigation.ts` | Nav metadata and Phosphor icons | — | `mainNav` config | Single source for sidebar, bottom bar, palette |
| `src/pages/*` | Placeholder screens per milestone | — | Static copy + dashed placeholder region | Overview retains stack status cards |
| `server/index.ts` | HTTP API: health, auth (register/login/logout/me), knowledge list; WebSocket `/ws` | HTTP + cookies | JSON + `Set-Cookie` | Knowledge API requires session; rows filtered by `user_id` |
| `server/auth/session.ts` | Opaque session cookie `dk_session`, SHA-256 token at rest, expiry | Cookie header | `SessionUser` or null | 30-day sliding expiry column; expired rows deleted on read |
| `server/auth/password.ts` | bcrypt password hashing | Plain password | Verifiable hash | `bcryptjs`, cost factor 10 |
| `src/auth/AuthContext.tsx` | Client session state via `GET /api/auth/me` | — | `user`, `logout`, `refresh` | `credentials: "include"` on fetches |
| `src/auth/RequireAuth.tsx` | Redirect unauthenticated users to `/login` | — | `Outlet` or `<Navigate />` | Wraps Library, Search, Chat, Ingest, Analytics |
| `scripts/export.mts` | Convert design JSON into deterministic summary artifact | CLI args (`--input`, `--output`), design JSON file | Export summary JSON | Stable output contract supports repeatable checks |
| `server/db/schema.ts` | Drizzle schema: users, **sessions**, knowledge items, tags, junction | SQL migrations | SQLite tables | Default DB file `data/devknowledge.db` (override with `DATABASE_PATH`) |
| `server/db/client.ts` | `better-sqlite3` pool, `runMigrations` on startup | Env, migration SQL | Query API | `pnpm run db:migrate` applies same migrations without starting HTTP |
| `src/core/model/design.ts` | Legacy design-document types for export examples | — | Types | Kept for `scripts/export.mts` contract |
| `src/core/model/knowledge.ts` | DTO types for knowledge domain + API | `GET /api/knowledge/items` | Client types | `types.ts` re-exports |

## 4. Data Model and State
- Core entities:
  - `DesignDocument`
  - `Artboard`
  - `Layer`
- Canonical state shape:
  - Frontend: `{ health: HealthResponse | null, wsState: "connecting" | "open" | "closed" }`
  - Export summary: `{ version: 1, projectName, artboardCount, layerCount }`
- Invariants:
  - Health endpoint status is `"ok"` when available.
  - Export summary `version` remains `1` until explicit contract revision.
  - Layer count equals sum of valid artboard layer array lengths.
- Serialization/persistence format:
  - JSON-only for health responses and export artifacts.
- Migration/versioning strategy:
  - Export schema version field enables future non-breaking/breaking migrations.

## 5. Control Flow
- Main user flow:
  1. User starts dev environment.
  2. Browser loads scaffold app.
  3. App requests `/api/health` and opens `/ws`.
  4. UI reflects service and realtime connectivity status.
- Event/action pipeline:
  - `useEffect` triggers health fetch and WS setup on mount.
  - State updates trigger status text recalculation via `useMemo`.
- Async workflow and side effects:
  - HTTP fetch with response check + JSON parse.
  - WebSocket open/close/error callbacks update connection state.
- Error propagation and recovery:
  - Health request failures set `health` to `null`.
  - WS errors/close transition UI to closed state.

## 6. Interfaces and Contracts
- Internal interfaces:
  - `HealthResponse` type in `App.tsx`.
  - `DesignDocument` and related model types.
- External APIs/services:
  - `GET /api/health` → `{ status: "ok", service: string }`.
  - `GET /api/auth/me` → `{ user: { id, email } | null }` (cookie session).
  - `POST /api/auth/register` | `POST /api/auth/login` → user JSON + `Set-Cookie: dk_session=…`.
  - `POST /api/auth/logout` → clears session cookie.
  - `GET /api/knowledge/items` → `{ items: [...] }` (requires session; scoped to user).
  - `WS /ws` initial event message `{ type: "server:ready", message: string }`.
- Schema/contracts and validation:
  - Export script assumes optional `project` and `artboards` fields; defaults are applied when missing.
- Compatibility requirements:
  - Runs on modern Node + browser environments consistent with Vite 7 and React 19 toolchain.

## 7. Quality Attributes
- Performance targets and bottlenecks:
  - Fast local startup and lightweight runtime interactions; no significant bottlenecks in baseline scaffold.
- Reliability strategy:
  - Keep runtime logic small and verify via typecheck/test/lint/build/export gates.
- Security/privacy posture:
  - Local-only development posture; passwords hashed with bcrypt; session tokens stored as SHA-256; `httpOnly` cookies for session id.
- Observability (logs/metrics/traces):
  - Concise server startup logging and visible client status indicators.
- Accessibility/usability constraints (if relevant):
  - Semantically structured heading/text layout; baseline readability prioritized.

## 8. Testing Strategy
- Unit coverage strategy:
  - Current UI baseline test verifies key heading content.
  - Expand tests around health/WS states as behavior grows.
- Integration/end-to-end strategy:
  - Manual local run (`npm run dev`) for API and WS interaction verification.
- Determinism checks:
  - Export script output checked through fixed input/output command.
- Regression prevention strategy:
  - Enforce full quality matrix before handoff.

## 9. Key Technical Decisions

| Decision | Options Considered | Chosen Approach | Rationale | Tradeoffs |
| --- | --- | --- | --- | --- |
| Serve API and WS from lightweight local Node server | Embed mocks in frontend, separate service, Node local server | Node HTTP + `ws` server in `server/index.ts` | Clear runtime boundary and realistic local integration path | More moving parts than pure frontend mock |
| Use deterministic summary export instead of raw passthrough | Raw copy, rich transform, minimal deterministic summary | Deterministic summary JSON | Reliable CI validation and simple artifact contract | Limited output detail for now |
| Use docs-first milestone workflow | Ad-hoc coding, issue-driven coding, structured docs workflow | Structured planning + execution + architecture docs | Better traceability for long-horizon autonomous runs | More upfront documentation effort |

## 10. Risks and Open Questions
- Risk: Product scope ambiguity due placeholder brief.
  - Mitigation: Maintain documented baseline and require brief completion before major feature expansion.
- Risk: Realtime behavior under richer interactions is untested.
  - Mitigation: Add integration tests when message protocol expands.
- Open question: What concrete user workflow should replace scaffold messaging?
- Open question: Should export pipeline evolve to preserve full document fidelity or remain summary-only?

## 11. Change History

| Timestamp (TZ) | Change | Reason | Related Milestone |
| --- | --- | --- | --- |
| 2026-02-27 12:23 UTC | Replaced placeholder architecture template with implemented baseline architecture record | Align docs with current shipped scaffold | 13 |
| 2026-02-27 12:23 UTC | Added explicit contracts, data invariants, and decision tradeoffs | Improve implementation traceability for future iterations | 13-14 |
| 2026-03-22 UTC | Added Phase 2 target architecture section and DevKnowledge Base UX token note | Align architecture doc with adopted PRD and Milestone 15 | 15 |
| 2026-03-22 UTC | Documented routing shell, layout, command palette, and `useServiceStatus` | Milestone 16 shipped | 16 |
| 2026-03-22 UTC | Documented SQLite + Drizzle persistence and knowledge API | Milestone 17 shipped | 17 |
| 2026-03-22 UTC | Documented session auth, bcrypt, and protected knowledge API | Milestone 18 shipped | 18 |
