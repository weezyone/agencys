# DevKnowledge Base

Developer knowledge management product (see `dev-knowlege.md`), built from a long-horizon scaffold: planning through implementation and verification.

## Included
- React + TypeScript + Vite app with **React Router** (public `/`, `/login`, `/register`; protected library/search/chat/ingest/analytics), collapsible sidebar, mobile nav, and ⌘/Ctrl+K command palette
- Local Node server: `/api/health`, **cookie-based auth**, `/api/knowledge/items`, and `/ws`
- Vitest + Testing Library setup
- ESLint + TypeScript strict checks
- Export utility (`scripts/export.mts`) with starter input
- Long-horizon docs:
  - `docs/prompt.md`
  - `docs/plans.md`
  - `docs/implement.md`
  - `docs/documentation.md`
  - `docs/architecture.md`

## Quick Start
```bash
npm install
npm run dev
```

## Validation
```bash
npm run typecheck
npm run test
npm run lint
npm run build
npm run export -- --input examples/starter.design.json --output exports/starter.export.json
```

## Database (SQLite + Drizzle)
- Default database file: `data/devknowledge.db` (gitignored). Override with env `DATABASE_PATH`.
- The dev server runs migrations on startup. You can also run `pnpm run db:migrate`.
- Optional sample rows: `pnpm run db:seed` (idempotent dev user `dev@local.local` / password `devpassword`).
- Regenerate SQL from schema: `pnpm run db:generate` (after editing `server/db/schema.ts`).

## Auth (Milestone 18)
- Register: `POST /api/auth/register` JSON `{ "email", "password" }` (password ≥ 8 chars).
- Login: `POST /api/auth/login` — sets `httpOnly` cookie `dk_session`.
- Session: `GET /api/auth/me` returns `{ user: { id, email } | null }`.
- Logout: `POST /api/auth/logout`.
- Knowledge API `GET /api/knowledge/items` requires a valid session and returns only that user’s rows.
- UI: `/login`, `/register`; Library/Search/Chat/Ingest/Analytics require sign-in.

## Long-Horizon Workflow
1. Product brief: `dev-knowlege.md` (DevKnowledge Base PRD).
2. Start from `docs/prompt.md`.
3. Let Codex complete `docs/plans.md` before broad implementation.
4. Execute milestones using `docs/implement.md`.
5. Keep `docs/documentation.md` and `docs/architecture.md` current.
