# Repository Guidelines

## Project Structure and Module Organization
- `src/`: Main frontend (React + TypeScript).
- `server/`: Local collaboration/WebSocket server run during dev.
- `docs/`: Planning, architecture, and execution logs for long-horizon tasks.
- `scripts/`: Utility scripts (for example, export tooling).
- `examples/`: Demo inputs/outputs.
- Tests live alongside source (`*.test.ts` / `*.test.tsx`).

## Build, Test, and Development Commands
- `npm run dev`: Starts app and server via `concurrently`.
- `npm run dev:app`: Starts the Vite dev server.
- `npm run dev:server`: Starts the local server watcher.
- `npm run build`: TypeScript project build + Vite production build.
- `npm run typecheck`: Strict TS checks without emitting.
- `npm run lint`: ESLint with zero warnings allowed.
- `npm run test`: Runs Vitest once.
- `npm run test:watch`: Runs Vitest in watch mode.
- `npm run export`: Runs `scripts/export.mts` with `tsx`.

## Coding Style and Naming Conventions
- Language: TypeScript (`.ts` / `.tsx`), React 19, Vite 7.
- Indentation: 2 spaces.
- Components: PascalCase filenames.
- Hooks/utilities: `useX.ts` / `xHelpers.ts`.
- Keep docs in `docs/` synchronized with implementation.

## Testing Guidelines
- Framework: Vitest + Testing Library (`jsdom` environment).
- Keep tests close to source files.
- Always run: `npm run typecheck && npm run test && npm run lint`.

## Commit and PR Guidelines
- Conventional commits: `feat: ...`, `docs: ...`, `fix: ...`.
- Keep commits focused and scoped to one change.
- Include problem/solution summary and validation commands in PRs.
