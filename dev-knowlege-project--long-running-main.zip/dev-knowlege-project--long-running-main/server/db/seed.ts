import { randomUUID } from "node:crypto";
import bcrypt from "bcryptjs";
import { getSqlite, runMigrations } from "./client.js";

const DEV_USER_EMAIL = "dev@local.local";

function seed(): void {
  runMigrations();
  const db = getSqlite();
  const hash = bcrypt.hashSync("devpassword", 10);

  const existing = db
    .prepare(`SELECT id, password_hash FROM users WHERE email = ?`)
    .get(DEV_USER_EMAIL) as
    | { id: string; password_hash: string | null }
    | undefined;

  if (existing) {
    if (!existing.password_hash) {
      db.prepare(`UPDATE users SET password_hash = ? WHERE id = ?`).run(
        hash,
        existing.id
      );
      console.log("[db:seed] set password for existing dev user (devpassword)");
    } else {
      console.log("[db:seed] dev user already present, skipping insert");
    }
    return;
  }

  const userId = randomUUID();
  const now = Date.now();
  db.prepare(
    `INSERT INTO users (id, email, password_hash, created_at) VALUES (?, ?, ?, ?)`
  ).run(userId, DEV_USER_EMAIL, hash, now);

  db.prepare(
    `INSERT INTO knowledge_items (id, user_id, title, kind, body_text, source_url, metadata_json, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    randomUUID(),
    userId,
    "Welcome to DevKnowledge Base",
    "document",
    "Sample knowledge row in SQLite. Log in as dev@local.local / devpassword. Milestone 19+ will add real ingest.",
    null,
    JSON.stringify({ seeded: true, milestone: 17 }),
    now,
    now
  );

  console.log("[db:seed] inserted dev user and sample knowledge item");
}

seed();
