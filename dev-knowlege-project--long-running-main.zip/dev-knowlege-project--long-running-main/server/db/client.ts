import fs from "node:fs";
import path from "node:path";
import Database from "better-sqlite3";
import { drizzle } from "drizzle-orm/better-sqlite3";
import { migrate } from "drizzle-orm/better-sqlite3/migrator";
import * as schema from "./schema.js";

const defaultPath = path.join(process.cwd(), "data", "devknowledge.db");

function resolveDbPath(): string {
  return process.env.DATABASE_PATH?.trim() || defaultPath;
}

let sqlite: Database.Database | null = null;
let db: ReturnType<typeof drizzle<typeof schema>> | null = null;

export function getSqlite(): Database.Database {
  if (!sqlite) {
    const dbPath = resolveDbPath();
    fs.mkdirSync(path.dirname(dbPath), { recursive: true });
    sqlite = new Database(dbPath);
    sqlite.pragma("foreign_keys = ON");
  }
  return sqlite;
}

export function getDb() {
  if (!db) {
    db = drizzle(getSqlite(), { schema });
  }
  return db;
}

export function runMigrations(): void {
  const d = getDb();
  const folder = path.join(process.cwd(), "server/db/migrations");
  migrate(d, { migrationsFolder: folder });
}
