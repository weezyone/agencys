import { runMigrations } from "./client.js";

runMigrations();
console.log("[db:migrate] migrations applied");
