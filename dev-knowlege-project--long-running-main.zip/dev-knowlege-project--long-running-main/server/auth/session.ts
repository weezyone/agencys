import { createHash, randomBytes, randomUUID } from "node:crypto";
import type { IncomingMessage } from "node:http";
import { getSqlite } from "../db/client.js";

export const SESSION_COOKIE = "dk_session";
const SESSION_MS = 30 * 24 * 60 * 60 * 1000;

export type SessionUser = {
  id: string;
  email: string;
};

export function hashSessionToken(token: string): string {
  return createHash("sha256").update(token, "utf8").digest("hex");
}

function parseCookies(header: string | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  if (!header) return out;
  for (const part of header.split(";")) {
    const idx = part.indexOf("=");
    if (idx === -1) continue;
    const key = part.slice(0, idx).trim();
    const val = part.slice(idx + 1).trim();
    out[key] = decodeURIComponent(val);
  }
  return out;
}

export function getSessionUser(req: IncomingMessage): SessionUser | null {
  const cookies = parseCookies(req.headers.cookie);
  const token = cookies[SESSION_COOKIE];
  if (!token) return null;

  const now = Date.now();
  getSqlite()
    .prepare(`DELETE FROM sessions WHERE expires_at < ?`)
    .run(now);

  const tokenHash = hashSessionToken(token);
  const row = getSqlite()
    .prepare(
      `SELECT u.id AS id, u.email AS email
       FROM sessions s
       INNER JOIN users u ON u.id = s.user_id
       WHERE s.token_hash = ? AND s.expires_at > ?`
    )
    .get(tokenHash, now) as { id: string; email: string } | undefined;

  return row ?? null;
}

export function createSession(userId: string): { token: string } {
  const id = randomUUID();
  const token = randomBytes(32).toString("hex");
  const tokenHash = hashSessionToken(token);
  const now = Date.now();
  const expiresAt = now + SESSION_MS;

  getSqlite()
    .prepare(
      `INSERT INTO sessions (id, user_id, token_hash, expires_at, created_at)
       VALUES (?, ?, ?, ?, ?)`
    )
    .run(id, userId, tokenHash, expiresAt, now);

  return { token };
}

export function revokeSession(req: IncomingMessage): void {
  const cookies = parseCookies(req.headers.cookie);
  const token = cookies[SESSION_COOKIE];
  if (!token) return;
  const tokenHash = hashSessionToken(token);
  getSqlite().prepare(`DELETE FROM sessions WHERE token_hash = ?`).run(tokenHash);
}

export function sessionCookieHeader(token: string, clear: boolean): string {
  if (clear) {
    return `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`;
  }
  const maxAgeSec = Math.floor(SESSION_MS / 1000);
  return `${SESSION_COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAgeSec}`;
}
