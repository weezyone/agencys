/** Bytes per chunk for resumable uploads (Milestone 20). */
export const UPLOAD_CHUNK_SIZE_BYTES = 5 * 1024 * 1024;

/** Hard cap for a single file (bytes). */
export const UPLOAD_MAX_TOTAL_BYTES = 500 * 1024 * 1024;

/** Pending session files older than this are removed on new init. */
export const UPLOAD_SESSION_TTL_MS = 24 * 60 * 60 * 1000;
