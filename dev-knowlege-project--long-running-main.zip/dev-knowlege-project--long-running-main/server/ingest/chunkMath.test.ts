// @vitest-environment node
import { describe, expect, it } from "vitest";
import {
  defaultChunkSize,
  expectedChunkByteLength,
  totalChunksFor
} from "./chunkMath.js";

describe("chunkMath", () => {
  it("computes total chunks", () => {
    expect(totalChunksFor(25, 10)).toBe(3);
    expect(totalChunksFor(20, 10)).toBe(2);
    expect(totalChunksFor(1, 5)).toBe(1);
  });

  it("sizes each chunk except possibly the last", () => {
    const totalBytes = 25;
    const chunkSize = 10;
    const n = totalChunksFor(totalBytes, chunkSize);
    expect(expectedChunkByteLength(totalBytes, chunkSize, 0, n)).toBe(10);
    expect(expectedChunkByteLength(totalBytes, chunkSize, 1, n)).toBe(10);
    expect(expectedChunkByteLength(totalBytes, chunkSize, 2, n)).toBe(5);
  });

  it("default chunk size is 5 MiB", () => {
    expect(defaultChunkSize()).toBe(5 * 1024 * 1024);
  });
});
