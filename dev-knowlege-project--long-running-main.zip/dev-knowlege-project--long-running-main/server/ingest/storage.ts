import fs from "node:fs";
import path from "node:path";

function uploadsRoot(): string {
  const fromEnv = process.env.UPLOAD_DIR?.trim();
  if (fromEnv) return path.resolve(fromEnv);
  return path.join(process.cwd(), "data", "uploads");
}

export function ensureUploadsDir(): string {
  const root = uploadsRoot();
  fs.mkdirSync(root, { recursive: true });
  return root;
}

/**
 * Safe filename segment for disk storage (basename, limited charset).
 */
export function sanitizeFilename(original: string): string {
  const base = path.basename(original);
  const cleaned = base.replace(/[^\w.\-()+ ]/gu, "_").slice(0, 200);
  return cleaned.length > 0 ? cleaned : "upload.bin";
}

/**
 * Writes bytes under `data/uploads/<userId>/<itemId>/<safeName>` and returns a stable relative key.
 */
export function saveUploadedFile(
  userId: string,
  itemId: string,
  originalName: string,
  buffer: Buffer
): { relativeKey: string; storedName: string; size: number } {
  const storedName = sanitizeFilename(originalName);
  const dir = path.join(ensureUploadsDir(), userId, itemId);
  fs.mkdirSync(dir, { recursive: true });
  const fullPath = path.join(dir, storedName);
  fs.writeFileSync(fullPath, buffer);
  const relativeKey = path
    .join("uploads", userId, itemId, storedName)
    .replace(/\\/g, "/");
  return { relativeKey, storedName, size: buffer.length };
}
