import fs from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";
import {
  UPLOAD_MAX_TOTAL_BYTES,
  UPLOAD_SESSION_TTL_MS
} from "./chunkConstants.js";
import {
  defaultChunkSize,
  expectedChunkByteLength,
  totalChunksFor
} from "./chunkMath.js";
import { ensureUploadsDir } from "./storage.js";

export type UploadSessionMeta = {
  userId: string;
  fileName: string;
  totalBytes: number;
  mimeType: string;
  title: string | null;
  chunkSize: number;
  totalChunks: number;
  nextChunkIndex: number;
  receivedBytes: number;
  createdAt: number;
  expiresAt: number;
};

function sessionsRoot(): string {
  return path.join(ensureUploadsDir(), "sessions");
}

function sessionDir(uploadId: string): string {
  return path.join(sessionsRoot(), uploadId);
}

function metaPath(uploadId: string): string {
  return path.join(sessionDir(uploadId), "meta.json");
}

function partPath(uploadId: string): string {
  return path.join(sessionDir(uploadId), "part.bin");
}

function readMeta(uploadId: string): UploadSessionMeta | null {
  const p = metaPath(uploadId);
  if (!fs.existsSync(p)) return null;
  try {
    const raw = fs.readFileSync(p, "utf8");
    return JSON.parse(raw) as UploadSessionMeta;
  } catch {
    return null;
  }
}

function writeMeta(uploadId: string, meta: UploadSessionMeta): void {
  fs.mkdirSync(sessionDir(uploadId), { recursive: true });
  fs.writeFileSync(metaPath(uploadId), JSON.stringify(meta, null, 0), "utf8");
}

export function cleanupExpiredSessions(): void {
  const root = sessionsRoot();
  if (!fs.existsSync(root)) return;
  const now = Date.now();
  for (const name of fs.readdirSync(root)) {
    const dir = path.join(root, name);
    try {
      const st = fs.statSync(dir);
      if (!st.isDirectory()) continue;
      const meta = readMeta(name);
      const exp = meta?.expiresAt ?? 0;
      if (exp < now) {
        fs.rmSync(dir, { recursive: true, force: true });
      }
    } catch {
      /* ignore */
    }
  }
}

export function createUploadSession(input: {
  userId: string;
  fileName: string;
  totalBytes: number;
  mimeType: string;
  title: string | null;
}): { uploadId: string; chunkSize: number; totalChunks: number } {
  if (
    typeof input.fileName !== "string" ||
    input.fileName.trim().length === 0
  ) {
    throw new ChunkSessionError("fileName is required", 400);
  }
  if (
    !Number.isFinite(input.totalBytes) ||
    input.totalBytes <= 0 ||
    input.totalBytes > UPLOAD_MAX_TOTAL_BYTES
  ) {
    throw new ChunkSessionError("Invalid totalBytes", 400);
  }
  cleanupExpiredSessions();
  const chunkSize = defaultChunkSize();
  const totalChunks = totalChunksFor(input.totalBytes, chunkSize);
  const uploadId = randomUUID();
  fs.mkdirSync(sessionDir(uploadId), { recursive: true });
  fs.writeFileSync(partPath(uploadId), Buffer.alloc(0));
  const now = Date.now();
  const meta: UploadSessionMeta = {
    userId: input.userId,
    fileName: input.fileName.trim().slice(0, 500),
    totalBytes: input.totalBytes,
    mimeType:
      typeof input.mimeType === "string"
        ? input.mimeType.slice(0, 200)
        : "application/octet-stream",
    title:
      typeof input.title === "string" && input.title.trim().length > 0
        ? input.title.trim().slice(0, 500)
        : null,
    chunkSize,
    totalChunks,
    nextChunkIndex: 0,
    receivedBytes: 0,
    createdAt: now,
    expiresAt: now + UPLOAD_SESSION_TTL_MS
  };
  writeMeta(uploadId, meta);
  return { uploadId, chunkSize, totalChunks };
}

export class ChunkSessionError extends Error {
  constructor(
    message: string,
    readonly status: number
  ) {
    super(message);
    this.name = "ChunkSessionError";
  }
}

export function appendUploadChunk(input: {
  uploadId: string;
  userId: string;
  chunkIndex: number;
  buffer: Buffer;
}): { nextChunkIndex: number; duplicate: boolean } {
  const meta = readMeta(input.uploadId);
  if (!meta) {
    throw new ChunkSessionError("Upload session not found", 404);
  }
  if (meta.expiresAt < Date.now()) {
    removeUploadSession(input.uploadId);
    throw new ChunkSessionError("Upload session expired", 410);
  }
  if (meta.userId !== input.userId) {
    throw new ChunkSessionError("Forbidden", 403);
  }
  if (input.chunkIndex < meta.nextChunkIndex) {
    return { nextChunkIndex: meta.nextChunkIndex, duplicate: true };
  }
  if (input.chunkIndex > meta.nextChunkIndex) {
    throw new ChunkSessionError(
      `Expected chunk ${meta.nextChunkIndex}`,
      409
    );
  }
  const expectedLen = expectedChunkByteLength(
    meta.totalBytes,
    meta.chunkSize,
    input.chunkIndex,
    meta.totalChunks
  );
  if (expectedLen < 0 || input.buffer.length !== expectedLen) {
    throw new ChunkSessionError("Chunk size mismatch", 400);
  }
  fs.appendFileSync(partPath(input.uploadId), input.buffer);
  meta.nextChunkIndex += 1;
  meta.receivedBytes += input.buffer.length;
  meta.expiresAt = Date.now() + UPLOAD_SESSION_TTL_MS;
  writeMeta(input.uploadId, meta);
  return { nextChunkIndex: meta.nextChunkIndex, duplicate: false };
}

export function getUploadStatus(uploadId: string, userId: string): {
  nextChunkIndex: number;
  totalChunks: number;
  totalBytes: number;
  receivedBytes: number;
  chunkSize: number;
} | null {
  const meta = readMeta(uploadId);
  if (!meta || meta.userId !== userId) return null;
  if (meta.expiresAt < Date.now()) {
    removeUploadSession(uploadId);
    return null;
  }
  return {
    nextChunkIndex: meta.nextChunkIndex,
    totalChunks: meta.totalChunks,
    totalBytes: meta.totalBytes,
    receivedBytes: meta.receivedBytes,
    chunkSize: meta.chunkSize
  };
}

export function readCompletedUpload(
  uploadId: string,
  userId: string
): { meta: UploadSessionMeta; buffer: Buffer } {
  const meta = readMeta(uploadId);
  if (!meta) {
    throw new ChunkSessionError("Upload session not found", 404);
  }
  if (meta.userId !== userId) {
    throw new ChunkSessionError("Forbidden", 403);
  }
  if (meta.expiresAt < Date.now()) {
    removeUploadSession(uploadId);
    throw new ChunkSessionError("Upload session expired", 410);
  }
  if (meta.nextChunkIndex !== meta.totalChunks) {
    throw new ChunkSessionError("Upload incomplete", 400);
  }
  const buf = fs.readFileSync(partPath(uploadId));
  if (buf.length !== meta.totalBytes) {
    throw new ChunkSessionError("Assembled size mismatch", 500);
  }
  return { meta, buffer: buf };
}

export function removeUploadSession(uploadId: string): void {
  const dir = sessionDir(uploadId);
  if (fs.existsSync(dir)) {
    fs.rmSync(dir, { recursive: true, force: true });
  }
}
