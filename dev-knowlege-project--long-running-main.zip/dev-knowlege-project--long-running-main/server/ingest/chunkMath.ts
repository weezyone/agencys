import { UPLOAD_CHUNK_SIZE_BYTES } from "./chunkConstants.js";

export function totalChunksFor(totalBytes: number, chunkSize: number): number {
  if (totalBytes <= 0 || chunkSize <= 0) {
    throw new Error("totalBytes and chunkSize must be positive");
  }
  return Math.ceil(totalBytes / chunkSize);
}

/**
 * Expected byte length for chunk `chunkIndex` (0-based).
 */
export function expectedChunkByteLength(
  totalBytes: number,
  chunkSize: number,
  chunkIndex: number,
  totalChunks: number
): number {
  if (chunkIndex < 0 || chunkIndex >= totalChunks) {
    return -1;
  }
  if (chunkIndex < totalChunks - 1) {
    return chunkSize;
  }
  const last = totalBytes - (totalChunks - 1) * chunkSize;
  return last > 0 ? last : chunkSize;
}

export function defaultChunkSize(): number {
  return UPLOAD_CHUNK_SIZE_BYTES;
}
