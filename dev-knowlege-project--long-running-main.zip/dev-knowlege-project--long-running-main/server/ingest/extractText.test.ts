// @vitest-environment node
import { describe, expect, it } from "vitest";
import { extractFromUpload } from "./extractText.js";

describe("extractFromUpload", () => {
  it("treats images as media without searchable text", () => {
    const r = extractFromUpload("x.png", "image/png", Buffer.from([0xff, 0xd8]));
    expect(r.kind).toBe("media");
    expect(r.bodyText).toBeNull();
    expect(r.extraction).toBe("metadata_only");
  });

  it("extracts TypeScript as code_snippet", () => {
    const r = extractFromUpload(
      "foo.ts",
      "application/octet-stream",
      Buffer.from("export const n = 1;\n")
    );
    expect(r.kind).toBe("code_snippet");
    expect(r.bodyText).toContain("export");
  });

  it("extracts Markdown as document", () => {
    const r = extractFromUpload(
      "readme.md",
      "text/markdown",
      Buffer.from("# Hi")
    );
    expect(r.kind).toBe("document");
    expect(r.bodyText).toBe("# Hi");
  });

  it("uses metadata-only path for PDF", () => {
    const r = extractFromUpload("x.pdf", "application/pdf", Buffer.from("%PDF"));
    expect(r.kind).toBe("document");
    expect(r.bodyText).toBeNull();
    expect(r.extraction).toBe("metadata_only");
  });
});
