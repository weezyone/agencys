import { randomUUID } from "node:crypto";
import path from "node:path";
import { extractFromUpload } from "./extractText.js";
import { saveUploadedFile } from "./storage.js";
import { insertKnowledgeItem } from "../knowledge/repository.js";
import type { KnowledgeItemApi } from "../knowledge/repository.js";

export function completeFileIngest(input: {
  userId: string;
  fileName: string;
  mimeType: string;
  titleOverride: string | null;
  buffer: Buffer;
  /** When set, marks metadata that the file arrived via chunked upload. */
  chunked?: boolean;
}): KnowledgeItemApi {
  const extracted = extractFromUpload(
    input.fileName,
    input.mimeType,
    input.buffer
  );
  const itemId = randomUUID();
  const { relativeKey, size } = saveUploadedFile(
    input.userId,
    itemId,
    input.fileName,
    input.buffer
  );
  const base = path.basename(input.fileName);
  const stem = base.includes(".")
    ? base.slice(0, base.lastIndexOf("."))
    : base;
  const defaultTitle = stem.trim() || base || "Uploaded file";
  const titleField = input.titleOverride?.trim() ?? "";
  const title = (titleField.length > 0 ? titleField : defaultTitle).slice(
    0,
    500
  );
  const ingest: Record<string, unknown> = {
    source: "file_upload",
    originalName: input.fileName,
    mimeType: input.mimeType,
    size,
    storageKey: relativeKey,
    extraction: extracted.extraction
  };
  if (input.chunked) {
    ingest.chunked = true;
  }
  return insertKnowledgeItem({
    id: itemId,
    userId: input.userId,
    title,
    kind: extracted.kind,
    bodyText: extracted.bodyText,
    sourceUrl: null,
    metadata: { ingest }
  });
}
