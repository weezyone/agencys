import path from "node:path";

export type ExtractResult = {
  kind: "document" | "code_snippet" | "media";
  bodyText: string | null;
  extraction: "full" | "metadata_only";
};

/** Exported for paste ingest and tests — SQLite text and UI stay within this cap. */
export const MAX_KNOWLEDGE_BODY_CHARS = 500_000;

const CODE_EXT = new Set([
  ".ts",
  ".tsx",
  ".mts",
  ".cts",
  ".js",
  ".jsx",
  ".mjs",
  ".cjs",
  ".py",
  ".go",
  ".rs",
  ".java",
  ".c",
  ".cpp",
  ".h",
  ".hpp",
  ".cs",
  ".rb",
  ".php",
  ".swift",
  ".kt",
  ".sql",
  ".sh",
  ".bash",
  ".zsh",
  ".vue",
  ".svelte"
]);

const TEXT_EXT = new Set([
  ".txt",
  ".md",
  ".markdown",
  ".mdx",
  ".rst",
  ".json",
  ".jsonc",
  ".csv",
  ".tsv",
  ".xml",
  ".html",
  ".htm",
  ".css",
  ".scss",
  ".sass",
  ".less",
  ".yaml",
  ".yml",
  ".toml",
  ".ini",
  ".cfg",
  ".env",
  ".log",
  ".svg"
]);

function truncate(text: string): string {
  if (text.length <= MAX_KNOWLEDGE_BODY_CHARS) return text;
  return text.slice(0, MAX_KNOWLEDGE_BODY_CHARS);
}

function bufferHasNul(buf: Buffer, maxScan = 8192): boolean {
  const n = Math.min(buf.length, maxScan);
  for (let i = 0; i < n; i++) {
    if (buf[i] === 0) return true;
  }
  return false;
}

function isCodeExtension(ext: string): boolean {
  return CODE_EXT.has(ext);
}

/**
 * Infer searchable text and kind from an uploaded file (buffer + name/MIME).
 */
export function extractFromUpload(
  filename: string,
  mimeType: string | undefined,
  buffer: Buffer
): ExtractResult {
  const ext = path.extname(filename).toLowerCase();
  const mime = (mimeType ?? "").toLowerCase();

  if (mime.startsWith("image/")) {
    return { kind: "media", bodyText: null, extraction: "metadata_only" };
  }

  if (mime === "application/pdf") {
    return { kind: "document", bodyText: null, extraction: "metadata_only" };
  }

  const treatAsText =
    TEXT_EXT.has(ext) ||
    isCodeExtension(ext) ||
    mime.startsWith("text/") ||
    mime === "application/json" ||
    mime === "application/javascript" ||
    mime === "application/typescript" ||
    mime === "application/xml" ||
    mime === "application/xhtml+xml";

  if (treatAsText && !bufferHasNul(buffer)) {
    const text = buffer.toString("utf8");
    const kind = isCodeExtension(ext) ? "code_snippet" : "document";
    return {
      kind,
      bodyText: truncate(text),
      extraction: "full"
    };
  }

  if (!treatAsText && buffer.length > 0 && !bufferHasNul(buffer)) {
    const head = buffer.subarray(0, Math.min(buffer.length, 4096));
    const asText = head.toString("utf8");
    const printableRatio =
      asText.length > 0
        ? [...asText].filter((ch) => {
            const c = ch.codePointAt(0) ?? 0;
            return (
              c === 9 ||
              c === 10 ||
              c === 13 ||
              (c >= 32 && c !== 127)
            );
          }).length / asText.length
        : 0;
    if (printableRatio > 0.94 && buffer.length < 2_000_000) {
      const text = buffer.toString("utf8");
      return {
        kind: "document",
        bodyText: truncate(text),
        extraction: "full"
      };
    }
  }

  return { kind: "document", bodyText: null, extraction: "metadata_only" };
}
