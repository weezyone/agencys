import busboy from "busboy";
import type { IncomingMessage } from "node:http";

const MAX_FILE_BYTES = 10 * 1024 * 1024;

export type ParsedFileUpload = {
  title: string | undefined;
  fileName: string;
  mimeType: string;
  buffer: Buffer;
};

export class MultipartError extends Error {
  constructor(
    message: string,
    readonly status: number
  ) {
    super(message);
    this.name = "MultipartError";
  }
}

/**
 * Parse multipart/form-data with a single file field and optional `title` text field.
 */
export function parseKnowledgeFileUpload(
  req: IncomingMessage
): Promise<ParsedFileUpload> {
  return new Promise((resolve, reject) => {
    const bb = busboy({
      headers: req.headers,
      limits: { fileSize: MAX_FILE_BYTES, files: 1 }
    });

    let title: string | undefined;
    let fileName = "";
    let mimeType = "application/octet-stream";
    let fileBuffer: Buffer | null = null;
    let fileEnded = false;
    let sawFileField = false;

    bb.on("file", (_field, file, info) => {
      sawFileField = true;
      fileName = info.filename || "upload.bin";
      mimeType = info.mimeType || "application/octet-stream";
      const chunks: Buffer[] = [];
      file.on("data", (chunk: Buffer) => {
        chunks.push(chunk);
      });
      file.on("limit", () => {
        reject(new MultipartError("File too large", 413));
      });
      file.on("end", () => {
        fileBuffer = Buffer.concat(chunks);
        fileEnded = true;
      });
    });

    bb.on("field", (name, val) => {
      if (name === "title") {
        const t = String(val).trim();
        title = t.length > 0 ? t : undefined;
      }
    });

    bb.on("finish", () => {
      if (!sawFileField || !fileEnded || fileBuffer === null) {
        reject(new MultipartError("Expected a file field", 400));
        return;
      }
      resolve({
        title,
        fileName,
        mimeType,
        buffer: fileBuffer
      });
    });

    bb.on("error", (err: Error) => {
      reject(err);
    });

    req.pipe(bb);
  });
}
