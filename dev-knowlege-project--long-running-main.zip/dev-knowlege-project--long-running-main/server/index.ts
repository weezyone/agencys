import { randomUUID } from "node:crypto";
import { createServer } from "node:http";
import type { IncomingMessage, ServerResponse } from "node:http";
import type WebSocket from "ws";
import { WebSocketServer } from "ws";
import {
  corsHeaders,
  parseJson,
  readBody,
  readRawBody
} from "./auth/http.js";
import { hashPassword, verifyPassword } from "./auth/password.js";
import {
  createSession,
  getSessionUser,
  revokeSession,
  sessionCookieHeader
} from "./auth/session.js";
import { getSqlite, runMigrations } from "./db/client.js";
import { UPLOAD_CHUNK_SIZE_BYTES } from "./ingest/chunkConstants.js";
import {
  ChunkSessionError,
  appendUploadChunk,
  createUploadSession,
  getUploadStatus,
  readCompletedUpload,
  removeUploadSession
} from "./ingest/chunkedSession.js";
import { completeFileIngest } from "./ingest/completeFileIngest.js";
import { MAX_KNOWLEDGE_BODY_CHARS } from "./ingest/extractText.js";
import { MultipartError, parseKnowledgeFileUpload } from "./ingest/multipart.js";
import {
  insertKnowledgeItem,
  listKnowledgeItems
} from "./knowledge/repository.js";

runMigrations();

const port = Number(process.env.PORT ?? 8787);

function sendJson(
  res: ServerResponse,
  status: number,
  body: unknown,
  req: IncomingMessage,
  options?: { setCookie?: string }
) {
  /** All headers must be passed to `writeHead` — `setHeader` after `writeHead` throws in Node. */
  const headers: Record<string, string | number | string[]> = {
    ...corsHeaders(req),
    "content-type": "application/json; charset=utf-8"
  };
  if (options?.setCookie) {
    headers["Set-Cookie"] = options.setCookie;
  }
  res.writeHead(status, headers);
  res.end(JSON.stringify(body));
}

function parseLimit(searchParams: URLSearchParams): number {
  const raw = searchParams.get("limit");
  if (!raw) return 50;
  const n = Number.parseInt(raw, 10);
  if (!Number.isFinite(n) || n < 1) return 50;
  return Math.min(n, 200);
}

const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function validateEmail(email: unknown): email is string {
  return typeof email === "string" && emailRe.test(email.trim());
}

type ParsedUploadRoute =
  | { kind: "init" }
  | {
      kind: "session";
      uploadId: string;
      tail: "status" | "chunk" | "complete" | "root";
    };

function parseKnowledgeUploadRoute(pathname: string): ParsedUploadRoute | null {
  const base = "/api/knowledge/uploads/";
  if (!pathname.startsWith(base)) return null;
  const rest = pathname.slice(base.length);
  if (rest === "init") return { kind: "init" };
  const parts = rest.split("/").filter(Boolean);
  if (parts.length === 1) {
    return { kind: "session", uploadId: parts[0], tail: "root" };
  }
  if (parts.length === 2) {
    const [uploadId, sub] = parts;
    if (sub === "status" || sub === "chunk" || sub === "complete") {
      return { kind: "session", uploadId, tail: sub };
    }
  }
  return null;
}

async function handleApi(
  req: IncomingMessage,
  res: ServerResponse,
  url: URL
): Promise<boolean> {
  if (req.method === "GET" && url.pathname === "/api/health") {
    sendJson(res, 200, { status: "ok", service: "dev-knowlege-server" }, req);
    return true;
  }

  if (req.method === "GET" && url.pathname === "/api/auth/me") {
    const u = getSessionUser(req);
    sendJson(
      res,
      200,
      { user: u ? { id: u.id, email: u.email } : null },
      req
    );
    return true;
  }

  if (req.method === "POST" && url.pathname === "/api/auth/logout") {
    revokeSession(req);
    sendJson(res, 200, { ok: true }, req, {
      setCookie: sessionCookieHeader("", true)
    });
    return true;
  }

  if (req.method === "POST" && url.pathname === "/api/auth/register") {
    try {
      const raw = await readBody(req);
      const body = parseJson<{ email?: unknown; password?: unknown }>(raw);
      const email = body.email;
      const password = body.password;
      if (!validateEmail(email)) {
        sendJson(res, 400, { error: "Invalid email" }, req);
        return true;
      }
      if (typeof password !== "string" || password.length < 8) {
        sendJson(res, 400, { error: "Password must be at least 8 characters" }, req);
        return true;
      }
      const normalized = email.toLowerCase().trim();
      const taken = getSqlite()
        .prepare(`SELECT id FROM users WHERE email = ?`)
        .get(normalized) as { id: string } | undefined;
      if (taken) {
        sendJson(res, 409, { error: "Email already registered" }, req);
        return true;
      }
      const id = randomUUID();
      const now = Date.now();
      const passwordHash = await hashPassword(password);
      getSqlite()
        .prepare(
          `INSERT INTO users (id, email, password_hash, created_at) VALUES (?, ?, ?, ?)`
        )
        .run(id, normalized, passwordHash, now);
      const { token } = createSession(id);
      sendJson(
        res,
        201,
        { user: { id, email: normalized } },
        req,
        { setCookie: sessionCookieHeader(token, false) }
      );
    } catch (e) {
      console.error("[api/auth/register]", e);
      sendJson(res, 500, { error: "Registration failed" }, req);
    }
    return true;
  }

  if (req.method === "POST" && url.pathname === "/api/auth/login") {
    try {
      const raw = await readBody(req);
      const body = parseJson<{ email?: unknown; password?: unknown }>(raw);
      const email = body.email;
      const password = body.password;
      if (!validateEmail(email) || typeof password !== "string") {
        sendJson(res, 400, { error: "Invalid credentials" }, req);
        return true;
      }
      const normalized = email.toLowerCase().trim();
      const row = getSqlite()
        .prepare(
          `SELECT id, email, password_hash FROM users WHERE email = ?`
        )
        .get(normalized) as
        | { id: string; email: string; password_hash: string | null }
        | undefined;
      if (!row || !(await verifyPassword(password, row.password_hash))) {
        sendJson(res, 401, { error: "Invalid email or password" }, req);
        return true;
      }
      const { token } = createSession(row.id);
      sendJson(
        res,
        200,
        { user: { id: row.id, email: row.email } },
        req,
        { setCookie: sessionCookieHeader(token, false) }
      );
    } catch (e) {
      console.error("[api/auth/login]", e);
      sendJson(res, 500, { error: "Login failed" }, req);
    }
    return true;
  }

  if (req.method === "GET" && url.pathname === "/api/knowledge/items") {
    const sessionUser = getSessionUser(req);
    if (!sessionUser) {
      sendJson(res, 401, { error: "Unauthorized" }, req);
      return true;
    }
    try {
      const limit = parseLimit(url.searchParams);
      const items = listKnowledgeItems(sessionUser.id, limit);
      sendJson(res, 200, { items }, req);
    } catch (error) {
      console.error("[api/knowledge/items]", error);
      sendJson(res, 500, { error: "Failed to load knowledge items" }, req);
    }
    return true;
  }

  const uploadRoute = parseKnowledgeUploadRoute(url.pathname);
  if (uploadRoute) {
    const sessionUser = getSessionUser(req);
    if (!sessionUser) {
      sendJson(res, 401, { error: "Unauthorized" }, req);
      return true;
    }

    if (uploadRoute.kind === "init" && req.method === "POST") {
      try {
        const raw = await readBody(req, 64_000);
        let body: {
          fileName?: unknown;
          totalBytes?: unknown;
          mimeType?: unknown;
          title?: unknown;
        };
        try {
          body = parseJson(raw);
        } catch {
          sendJson(res, 400, { error: "Invalid JSON" }, req);
          return true;
        }
        const fileName =
          typeof body.fileName === "string" ? body.fileName : "";
        const totalBytes =
          typeof body.totalBytes === "number" ? body.totalBytes : NaN;
        const mimeType =
          typeof body.mimeType === "string"
            ? body.mimeType
            : "application/octet-stream";
        const title =
          typeof body.title === "string" && body.title.trim().length > 0
            ? body.title.trim()
            : null;
        const created = createUploadSession({
          userId: sessionUser.id,
          fileName,
          totalBytes,
          mimeType,
          title
        });
        sendJson(res, 201, created, req);
      } catch (error) {
        if (error instanceof ChunkSessionError) {
          sendJson(res, error.status, { error: error.message }, req);
          return true;
        }
        console.error("[api/knowledge/uploads/init]", error);
        sendJson(res, 500, { error: "Could not start upload" }, req);
      }
      return true;
    }

    if (uploadRoute.kind === "session") {
      const { uploadId, tail } = uploadRoute;

      if (tail === "status" && req.method === "GET") {
        const st = getUploadStatus(uploadId, sessionUser.id);
        if (!st) {
          sendJson(res, 404, { error: "Upload session not found" }, req);
          return true;
        }
        sendJson(res, 200, st, req);
        return true;
      }

      if (tail === "chunk" && req.method === "PUT") {
        const rawIdx = req.headers["x-chunk-index"];
        const chunkIndex =
          typeof rawIdx === "string" ? Number.parseInt(rawIdx, 10) : NaN;
        if (!Number.isFinite(chunkIndex) || chunkIndex < 0) {
          sendJson(res, 400, { error: "X-Chunk-Index required" }, req);
          return true;
        }
        try {
          const buffer = await readRawBody(req, UPLOAD_CHUNK_SIZE_BYTES);
          const result = appendUploadChunk({
            uploadId,
            userId: sessionUser.id,
            chunkIndex,
            buffer
          });
          sendJson(
            res,
            200,
            {
              nextChunkIndex: result.nextChunkIndex,
              duplicate: result.duplicate
            },
            req
          );
        } catch (error) {
          if (error instanceof ChunkSessionError) {
            sendJson(res, error.status, { error: error.message }, req);
            return true;
          }
          if (error instanceof Error && error.message === "Body too large") {
            sendJson(res, 413, { error: "Chunk too large" }, req);
            return true;
          }
          console.error("[api/knowledge/uploads/chunk]", error);
          sendJson(res, 500, { error: "Chunk upload failed" }, req);
        }
        return true;
      }

      if (tail === "complete" && req.method === "POST") {
        try {
          const { meta, buffer } = readCompletedUpload(
            uploadId,
            sessionUser.id
          );
          const item = completeFileIngest({
            userId: sessionUser.id,
            fileName: meta.fileName,
            mimeType: meta.mimeType,
            titleOverride: meta.title,
            buffer,
            chunked: true
          });
          removeUploadSession(uploadId);
          sendJson(res, 201, { item }, req);
        } catch (error) {
          if (error instanceof ChunkSessionError) {
            sendJson(res, error.status, { error: error.message }, req);
            return true;
          }
          console.error("[api/knowledge/uploads/complete]", error);
          sendJson(res, 500, { error: "Could not finalize upload" }, req);
        }
        return true;
      }

      if (tail === "root" && req.method === "DELETE") {
        const st = getUploadStatus(uploadId, sessionUser.id);
        if (!st) {
          sendJson(res, 404, { error: "Upload session not found" }, req);
          return true;
        }
        removeUploadSession(uploadId);
        sendJson(res, 200, { ok: true }, req);
        return true;
      }
    }
  }

  if (req.method === "POST" && url.pathname === "/api/knowledge/items/upload") {
    const sessionUser = getSessionUser(req);
    if (!sessionUser) {
      sendJson(res, 401, { error: "Unauthorized" }, req);
      return true;
    }
    try {
      const parsed = await parseKnowledgeFileUpload(req);
      const titleField =
        typeof parsed.title === "string" ? parsed.title.trim() : "";
      const item = completeFileIngest({
        userId: sessionUser.id,
        fileName: parsed.fileName,
        mimeType: parsed.mimeType,
        titleOverride: titleField.length > 0 ? titleField : null,
        buffer: parsed.buffer
      });
      sendJson(res, 201, { item }, req);
    } catch (error) {
      if (error instanceof MultipartError) {
        sendJson(res, error.status, { error: error.message }, req);
        return true;
      }
      console.error("[api/knowledge/items/upload]", error);
      sendJson(res, 500, { error: "Upload failed" }, req);
    }
    return true;
  }

  if (req.method === "POST" && url.pathname === "/api/knowledge/items") {
    const sessionUser = getSessionUser(req);
    if (!sessionUser) {
      sendJson(res, 401, { error: "Unauthorized" }, req);
      return true;
    }
    try {
      const raw = await readBody(req, 2_000_000);
      let body: {
        title?: unknown;
        bodyText?: unknown;
        kind?: unknown;
      };
      try {
        body = parseJson<{
          title?: unknown;
          bodyText?: unknown;
          kind?: unknown;
        }>(raw);
      } catch {
        sendJson(res, 400, { error: "Invalid JSON" }, req);
        return true;
      }
      const text =
        typeof body.bodyText === "string" ? body.bodyText.trim() : "";
      if (!text) {
        sendJson(res, 400, { error: "bodyText is required" }, req);
        return true;
      }
      const kindRaw = body.kind;
      const kind =
        kindRaw === "code_snippet" || kindRaw === "document"
          ? kindRaw
          : "document";
      let title = typeof body.title === "string" ? body.title.trim() : "";
      if (!title) {
        const line = text.split(/\r?\n/).find((l) => l.trim().length > 0);
        title = (line ?? text).slice(0, 120);
      }
      title = title.slice(0, 500);
      const bodyText =
        text.length > MAX_KNOWLEDGE_BODY_CHARS
          ? text.slice(0, MAX_KNOWLEDGE_BODY_CHARS)
          : text;
      const item = insertKnowledgeItem({
        userId: sessionUser.id,
        title,
        kind,
        bodyText,
        sourceUrl: null,
        metadata: { ingest: { source: "paste" } }
      });
      sendJson(res, 201, { item }, req);
    } catch (error) {
      console.error("[api/knowledge/items]", error);
      sendJson(res, 500, { error: "Failed to save item" }, req);
    }
    return true;
  }

  return false;
}

async function handleRequest(req: IncomingMessage, res: ServerResponse) {
  if (req.method === "OPTIONS") {
    res.writeHead(204, corsHeaders(req));
    res.end();
    return;
  }

  const url = new URL(req.url ?? "/", "http://127.0.0.1");

  try {
    const handled = await handleApi(req, res, url);
    if (handled) return;
  } catch (e) {
    if (e instanceof Error && e.message === "Body too large") {
      sendJson(res, 413, { error: "Payload too large" }, req);
      return;
    }
    console.error("[request]", e);
    sendJson(res, 500, { error: "Internal server error" }, req);
    return;
  }

  sendJson(res, 404, { error: "Not found" }, req);
}

const httpServer = createServer((req, res) => {
  void handleRequest(req, res);
});

const wsServer = new WebSocketServer({
  server: httpServer,
  path: "/ws"
});

wsServer.on("connection", (socket: WebSocket) => {
  socket.send(
    JSON.stringify({
      type: "server:ready",
      message: "WebSocket connected"
    })
  );
});

httpServer.listen(port, () => {
  console.log(`[dev-knowlege-server] listening on :${port}`);
});
