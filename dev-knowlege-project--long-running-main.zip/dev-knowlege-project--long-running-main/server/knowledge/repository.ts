import { randomUUID } from "node:crypto";
import { getSqlite } from "../db/client.js";

export type KnowledgeItemRow = {
  id: string;
  userId: string;
  title: string;
  kind: string;
  bodyText: string | null;
  sourceUrl: string | null;
  metadataJson: string | null;
  createdAt: number;
  updatedAt: number;
};

export type KnowledgeItemApi = {
  id: string;
  userId: string;
  title: string;
  kind: string;
  bodyText: string | null;
  sourceUrl: string | null;
  metadata: Record<string, unknown> | null;
  createdAt: number;
  updatedAt: number;
};

export function parseMetadata(
  json: string | null
): Record<string, unknown> | null {
  if (!json) return null;
  try {
    const v = JSON.parse(json) as unknown;
    if (v && typeof v === "object" && !Array.isArray(v)) {
      return v as Record<string, unknown>;
    }
    return null;
  } catch {
    return null;
  }
}

export function rowToApi(row: KnowledgeItemRow): KnowledgeItemApi {
  return {
    id: row.id,
    userId: row.userId,
    title: row.title,
    kind: row.kind,
    bodyText: row.bodyText,
    sourceUrl: row.sourceUrl,
    metadata: parseMetadata(row.metadataJson),
    createdAt: row.createdAt,
    updatedAt: row.updatedAt
  };
}

export function listKnowledgeItems(
  userId: string,
  limit: number
): KnowledgeItemApi[] {
  const stmt = getSqlite().prepare(`
    SELECT
      id,
      user_id AS userId,
      title,
      kind,
      body_text AS bodyText,
      source_url AS sourceUrl,
      metadata_json AS metadataJson,
      created_at AS createdAt,
      updated_at AS updatedAt
    FROM knowledge_items
    WHERE user_id = ?
    ORDER BY updated_at DESC
    LIMIT ?
  `);
  const rows = stmt.all(userId, limit) as KnowledgeItemRow[];
  return rows.map(rowToApi);
}

export function insertKnowledgeItem(input: {
  /** When set (e.g. file uploads), must match on-disk paths created before insert. */
  id?: string;
  userId: string;
  title: string;
  kind: string;
  bodyText: string | null;
  sourceUrl: string | null;
  metadata: Record<string, unknown> | null;
}): KnowledgeItemApi {
  const id = input.id ?? randomUUID();
  const now = Date.now();
  const metadataJson = input.metadata ? JSON.stringify(input.metadata) : null;
  getSqlite()
    .prepare(
      `INSERT INTO knowledge_items (
        id, user_id, title, kind, body_text, source_url, metadata_json, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      id,
      input.userId,
      input.title,
      input.kind,
      input.bodyText,
      input.sourceUrl,
      metadataJson,
      now,
      now
    );
  return rowToApi({
    id,
    userId: input.userId,
    title: input.title,
    kind: input.kind,
    bodyText: input.bodyText,
    sourceUrl: input.sourceUrl,
    metadataJson,
    createdAt: now,
    updatedAt: now
  });
}
