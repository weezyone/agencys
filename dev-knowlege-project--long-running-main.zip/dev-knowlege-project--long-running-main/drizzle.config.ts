import path from "node:path";
import { defineConfig } from "drizzle-kit";

const dbFile = path.join(process.cwd(), "data", "devknowledge.db");

export default defineConfig({
  schema: "./server/db/schema.ts",
  out: "./server/db/migrations",
  dialect: "sqlite",
  dbCredentials: {
    url: dbFile
  }
});
