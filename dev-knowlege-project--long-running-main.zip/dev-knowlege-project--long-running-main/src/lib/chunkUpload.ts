import type { KnowledgeItem } from "../core/model/knowledge";

/** Files larger than this use chunked upload (see Milestone 20). */
export const CHUNKED_UPLOAD_THRESHOLD_BYTES = 10 * 1024 * 1024;

export type ChunkedUploadInit = {
  uploadId: string;
  chunkSize: number;
  totalChunks: number;
};

export async function initChunkedUpload(input: {
  fileName: string;
  totalBytes: number;
  mimeType: string;
  title?: string;
}): Promise<ChunkedUploadInit> {
  const res = await fetch("/api/knowledge/uploads/init", {
    method: "POST",
    credentials: "include",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      fileName: input.fileName,
      totalBytes: input.totalBytes,
      mimeType: input.mimeType,
      title: input.title
    })
  });
  const data = (await res.json()) as ChunkedUploadInit & { error?: string };
  if (!res.ok) {
    throw new Error(data.error ?? `Init failed (${res.status})`);
  }
  return data;
}

export async function putUploadChunk(input: {
  uploadId: string;
  chunkIndex: number;
  blob: Blob;
  signal?: AbortSignal;
}): Promise<{ nextChunkIndex: number; duplicate: boolean }> {
  const res = await fetch(`/api/knowledge/uploads/${input.uploadId}/chunk`, {
    method: "PUT",
    credentials: "include",
    headers: {
      "content-type": "application/octet-stream",
      "X-Chunk-Index": String(input.chunkIndex)
    },
    body: input.blob,
    signal: input.signal
  });
  const data = (await res.json()) as {
    error?: string;
    nextChunkIndex?: number;
    duplicate?: boolean;
  };
  if (!res.ok) {
    throw new Error(data.error ?? `Chunk failed (${res.status})`);
  }
  return {
    nextChunkIndex: data.nextChunkIndex ?? 0,
    duplicate: Boolean(data.duplicate)
  };
}

export async function completeChunkedUpload(
  uploadId: string
): Promise<{ item: KnowledgeItem }> {
  const res = await fetch(`/api/knowledge/uploads/${uploadId}/complete`, {
    method: "POST",
    credentials: "include"
  });
  const data = (await res.json()) as {
    error?: string;
    item?: KnowledgeItem;
  };
  if (!res.ok) {
    throw new Error(data.error ?? `Complete failed (${res.status})`);
  }
  if (!data.item) {
    throw new Error("No item returned");
  }
  return { item: data.item };
}

export async function abortChunkedUpload(uploadId: string): Promise<void> {
  await fetch(`/api/knowledge/uploads/${uploadId}`, {
    method: "DELETE",
    credentials: "include"
  });
}

/**
 * Uploads a large file in fixed-size chunks with optional cancellation.
 */
export async function runChunkedFileUpload(
  file: File,
  options: {
    title?: string;
    signal?: AbortSignal;
    onProgress?: (percent: number) => void;
  } = {}
): Promise<KnowledgeItem> {
  const mime = file.type || "application/octet-stream";
  let uploadId: string | null = null;
  try {
    const init = await initChunkedUpload({
      fileName: file.name,
      totalBytes: file.size,
      mimeType: mime,
      title: options.title
    });
    uploadId = init.uploadId;
    const { chunkSize, totalChunks } = init;

    for (let i = 0; i < totalChunks; i++) {
      if (options.signal?.aborted) {
        throw Object.assign(new Error("Cancelled"), { name: "AbortError" });
      }
      const start = i * chunkSize;
      const end =
        i === totalChunks - 1 ? file.size : Math.min(start + chunkSize, file.size);
      const blob = file.slice(start, end);
      await putUploadChunk({
        uploadId,
        chunkIndex: i,
        blob,
        signal: options.signal
      });
      options.onProgress?.(Math.min(100, Math.round((end / file.size) * 100)));
    }
    const { item } = await completeChunkedUpload(uploadId);
    return item;
  } catch (e) {
    if (uploadId) {
      await abortChunkedUpload(uploadId).catch(() => {});
    }
    throw e;
  }
}
