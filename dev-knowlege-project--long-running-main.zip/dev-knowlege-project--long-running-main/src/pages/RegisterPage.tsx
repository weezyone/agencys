import { useState, type FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";

export function RegisterPage() {
  const { refresh } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        credentials: "include",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ email, password })
      });
      const data = (await res.json()) as { error?: string };
      if (!res.ok) {
        setError(data.error ?? "Registration failed");
        return;
      }
      await refresh();
      navigate("/library", { replace: true });
    } catch {
      setError("Network error");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="mx-auto flex max-w-md flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold text-dk-text">Create account</h1>
        <p className="mt-1 text-sm text-dk-muted">
          Password must be at least 8 characters.
        </p>
      </div>
      <form
        className="flex flex-col gap-4 rounded-xl border border-dk-border bg-dk-surface p-6"
        onSubmit={(e) => void onSubmit(e)}
      >
        <label className="flex flex-col gap-1 text-sm">
          <span className="text-dk-muted">Email</span>
          <input
            autoComplete="email"
            className="rounded-lg border border-dk-border bg-dk-bg px-3 py-2 text-dk-text outline-none focus:border-dk-accent"
            name="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </label>
        <label className="flex flex-col gap-1 text-sm">
          <span className="text-dk-muted">Password</span>
          <input
            autoComplete="new-password"
            className="rounded-lg border border-dk-border bg-dk-bg px-3 py-2 text-dk-text outline-none focus:border-dk-accent"
            name="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </label>
        {error ? (
          <p className="text-sm text-dk-warm" role="alert">
            {error}
          </p>
        ) : null}
        <button
          className="rounded-lg bg-dk-primary py-2 text-sm font-medium text-dk-onprimary transition hover:opacity-90 disabled:opacity-50"
          disabled={submitting}
          type="submit"
        >
          {submitting ? "Creating…" : "Register"}
        </button>
      </form>
      <p className="text-center text-sm text-dk-muted">
        Already have an account?{" "}
        <Link className="text-dk-accent hover:underline" to="/login">
          Sign in
        </Link>
      </p>
    </div>
  );
}
