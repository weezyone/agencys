import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import type { KnowledgeItem } from "../core/model/knowledge";
import { SectionPage } from "./SectionPage";

export function LibraryPage() {
  const [items, setItems] = useState<KnowledgeItem[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    void fetch("/api/knowledge/items?limit=50", { credentials: "include" })
      .then(async (res) => {
        if (res.status === 401) {
          throw new Error("401");
        }
        if (!res.ok) throw new Error(String(res.status));
        return res.json() as Promise<{ items: KnowledgeItem[] }>;
      })
      .then((data) => {
        if (!cancelled) setItems(data.items);
      })
      .catch((err: unknown) => {
        if (cancelled) return;
        if (err instanceof Error && err.message === "401") {
          setLoadError("Sign in to view your library.");
          return;
        }
        setLoadError("Could not load knowledge items.");
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-6">
      <SectionPage
        description="Central library for code snippets, documents, media, and bookmarks. Tagging and richer metadata will connect here."
        hidePlaceholder
        title="Library"
      />
      <div className="rounded-xl border border-dk-border bg-dk-surface p-4 text-sm">
        {loadError ? (
          <p className="text-dk-warm">{loadError}</p>
        ) : items === null ? (
          <p className="text-dk-muted">Loading…</p>
        ) : (
          <>
            <p className="font-medium text-dk-text">
              {items.length} item{items.length === 1 ? "" : "s"} in SQLite
            </p>
            {items.length > 0 ? (
              <ul className="mt-2 space-y-1 text-dk-muted">
                {items.slice(0, 8).map((it) => (
                  <li key={it.id} className="truncate text-xs">
                    <span className="font-mono text-dk-text">{it.title}</span>{" "}
                    <span className="text-dk-accent">({it.kind})</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="mt-1 text-dk-muted">
                No items yet — open{" "}
                <Link
                  className="text-dk-accent underline-offset-2 hover:underline"
                  to="/ingest"
                >
                  Ingest
                </Link>{" "}
                to paste or upload files, or run{" "}
                <code className="rounded bg-dk-bg px-1 font-mono text-dk-text">
                  pnpm run db:seed
                </code>{" "}
                for a sample row.
              </p>
            )}
          </>
        )}
      </div>
    </div>
  );
}
