import { SectionPage } from "./SectionPage";

export function AnalyticsPage() {
  return (
    <SectionPage
      description="Dashboards for growth, usage, and knowledge insights with export options."
      title="Analytics"
    />
  );
}
