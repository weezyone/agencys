import { useState, type FormEvent } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";

export function LoginPage() {
  const { refresh } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from =
    (location.state as { from?: string } | null)?.from &&
    (location.state as { from?: string }).from !== "/login"
      ? (location.state as { from: string }).from
      : "/library";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        credentials: "include",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ email, password })
      });
      const data = (await res.json()) as { error?: string };
      if (!res.ok) {
        setError(data.error ?? "Login failed");
        return;
      }
      await refresh();
      navigate(from, { replace: true });
    } catch {
      setError("Network error");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="mx-auto flex max-w-md flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold text-dk-text">Sign in</h1>
        <p className="mt-1 text-sm text-dk-muted">
          Dev account:{" "}
          <code className="font-mono text-dk-accent">dev@local.local</code> /{" "}
          <code className="font-mono text-dk-accent">devpassword</code> after{" "}
          <code className="font-mono">pnpm run db:seed</code>.
        </p>
      </div>
      <form
        className="flex flex-col gap-4 rounded-xl border border-dk-border bg-dk-surface p-6"
        onSubmit={(e) => void onSubmit(e)}
      >
        <label className="flex flex-col gap-1 text-sm">
          <span className="text-dk-muted">Email</span>
          <input
            autoComplete="email"
            className="rounded-lg border border-dk-border bg-dk-bg px-3 py-2 text-dk-text outline-none focus:border-dk-accent"
            name="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </label>
        <label className="flex flex-col gap-1 text-sm">
          <span className="text-dk-muted">Password</span>
          <input
            autoComplete="current-password"
            className="rounded-lg border border-dk-border bg-dk-bg px-3 py-2 text-dk-text outline-none focus:border-dk-accent"
            name="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </label>
        {error ? (
          <p className="text-sm text-dk-warm" role="alert">
            {error}
          </p>
        ) : null}
        <button
          className="rounded-lg bg-dk-primary py-2 text-sm font-medium text-dk-onprimary transition hover:opacity-90 disabled:opacity-50"
          disabled={submitting}
          type="submit"
        >
          {submitting ? "Signing in…" : "Sign in"}
        </button>
      </form>
      <p className="text-center text-sm text-dk-muted">
        No account?{" "}
        <Link className="text-dk-accent hover:underline" to="/register">
          Register
        </Link>
      </p>
    </div>
  );
}
