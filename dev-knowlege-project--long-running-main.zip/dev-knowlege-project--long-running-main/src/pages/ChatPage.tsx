import { SectionPage } from "./SectionPage";

export function ChatPage() {
  return (
    <SectionPage
      description="RAG chat over your knowledge base with source citations and resilient error states."
      title="Chat"
    />
  );
}
