import type { ReactNode } from "react";

type SectionPageProps = {
  title: string;
  description: string;
  /** Omit the default dashed placeholder (e.g. when more content follows in the parent). */
  hidePlaceholder?: boolean;
  children?: ReactNode;
};

export function SectionPage({
  title,
  description,
  hidePlaceholder,
  children
}: SectionPageProps) {
  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-3">
      <h1 className="text-2xl font-bold tracking-tight text-dk-text md:text-3xl">
        {title}
      </h1>
      <p className="text-base leading-relaxed text-dk-muted">{description}</p>
      {children != null ? (
        <div className="mt-4 flex flex-col gap-4">{children}</div>
      ) : hidePlaceholder ? null : (
        <div className="mt-4 rounded-xl border border-dashed border-dk-border bg-dk-bg/50 p-8 text-center text-sm text-dk-muted">
          Placeholder — functionality ships in upcoming milestones.
        </div>
      )}
    </div>
  );
}
