import { FileArrowUp } from "@phosphor-icons/react";
import {
  type DragEvent,
  type FormEvent,
  useCallback,
  useRef,
  useState
} from "react";
import { Link } from "react-router-dom";
import type { KnowledgeItem } from "../core/model/knowledge";
import {
  CHUNKED_UPLOAD_THRESHOLD_BYTES,
  runChunkedFileUpload
} from "../lib/chunkUpload";
import { SectionPage } from "./SectionPage";

export function IngestPage() {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const uploadAbortRef = useRef<AbortController | null>(null);
  const lastFileRef = useRef<File | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [optionalTitle, setOptionalTitle] = useState("");
  const [pasteText, setPasteText] = useState("");
  const [pasteKind, setPasteKind] = useState<"document" | "code_snippet">(
    "document"
  );
  const [busy, setBusy] = useState<"paste" | "file" | null>(null);
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [lastCreated, setLastCreated] = useState<KnowledgeItem | null>(null);

  async function submitPaste(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setLastCreated(null);
    const text = pasteText.trim();
    if (!text) {
      setError("Enter some text to save.");
      return;
    }
    setBusy("paste");
    try {
      const res = await fetch("/api/knowledge/items", {
        method: "POST",
        credentials: "include",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          title: optionalTitle.trim() || undefined,
          bodyText: text,
          kind: pasteKind
        })
      });
      const data = (await res.json()) as {
        error?: string;
        item?: KnowledgeItem;
      };
      if (!res.ok) {
        setError(data.error ?? "Could not save");
        return;
      }
      if (data.item) setLastCreated(data.item);
      setPasteText("");
      setOptionalTitle("");
    } catch {
      setError("Network error");
    } finally {
      setBusy(null);
    }
  }

  const uploadFile = useCallback(
    async (file: File) => {
      setError(null);
      setLastCreated(null);
      lastFileRef.current = file;
      setBusy("file");
      uploadAbortRef.current?.abort();
      const ac = new AbortController();
      uploadAbortRef.current = ac;
      const title = optionalTitle.trim() || undefined;

      try {
        if (file.size > CHUNKED_UPLOAD_THRESHOLD_BYTES) {
          setUploadProgress(0);
          const item = await runChunkedFileUpload(file, {
            title,
            signal: ac.signal,
            onProgress: (pct) => setUploadProgress(pct)
          });
          setLastCreated(item);
          setOptionalTitle("");
          setUploadProgress(100);
        } else {
          const fd = new FormData();
          fd.append("file", file);
          if (title) fd.append("title", title);
          const res = await fetch("/api/knowledge/items/upload", {
            method: "POST",
            credentials: "include",
            body: fd,
            signal: ac.signal
          });
          const data = (await res.json()) as {
            error?: string;
            item?: KnowledgeItem;
          };
          if (!res.ok) {
            setError(data.error ?? "Upload failed");
            return;
          }
          if (data.item) setLastCreated(data.item);
          setOptionalTitle("");
          setUploadProgress(100);
        }
      } catch (err: unknown) {
        if (err instanceof Error && err.name === "AbortError") {
          setError("Upload cancelled.");
        } else if (err instanceof Error) {
          setError(err.message);
        } else {
          setError("Upload failed");
        }
      } finally {
        uploadAbortRef.current = null;
        setBusy(null);
        setUploadProgress(null);
      }
    },
    [optionalTitle]
  );

  function cancelUpload() {
    uploadAbortRef.current?.abort();
  }

  function retryLastUpload() {
    const f = lastFileRef.current;
    if (f) void uploadFile(f);
  }

  function onDrop(e: DragEvent) {
    e.preventDefault();
    setDragOver(false);
    const f = e.dataTransfer.files[0];
    if (f) void uploadFile(f);
  }

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-6">
      <SectionPage
        description="Add knowledge from the clipboard or from files on disk. Text is stored in SQLite; files are saved under data/uploads with extracted text when supported. Files over 10&nbsp;MB use chunked upload with a progress bar."
        title="Ingest"
      >
        <div className="rounded-xl border border-dk-border bg-dk-surface p-4 text-sm">
          <label className="block text-xs font-medium text-dk-muted" htmlFor="ingest-title">
            Title (optional)
          </label>
          <input
            className="mt-1 w-full rounded-lg border border-dk-border bg-dk-bg px-3 py-2 font-mono text-sm text-dk-text placeholder:text-dk-muted focus:outline-none focus:ring-2 focus:ring-dk-accent/40"
            id="ingest-title"
            placeholder="Overrides auto title from first line or filename"
            type="text"
            value={optionalTitle}
            onChange={(e) => setOptionalTitle(e.target.value)}
          />
        </div>

        <div
          aria-label="File upload"
          className={`flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed px-4 py-10 text-center transition ${
            dragOver
              ? "border-dk-accent bg-dk-bg/80"
              : "border-dk-border bg-dk-surface hover:border-dk-muted"
          }`}
          onClick={() => fileInputRef.current?.click()}
          onDragEnter={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={(e) => {
            e.preventDefault();
            setDragOver(false);
          }}
          onDragOver={(e) => {
            e.preventDefault();
          }}
          onDrop={onDrop}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              fileInputRef.current?.click();
            }
          }}
        >
          <FileArrowUp aria-hidden className="h-10 w-10 text-dk-accent" />
          <p className="font-medium text-dk-text">
            Drop a file here or click to choose
          </p>
          <p className="max-w-md text-xs text-dk-muted">
            Up to 10&nbsp;MB uses a single request; larger files use 5&nbsp;MiB
            chunks (up to 500&nbsp;MB total). Text-like formats get full
            extraction; images and opaque binaries store metadata and keep the
            file on disk.
          </p>
          <input
            ref={fileInputRef}
            accept="*/*"
            className="sr-only"
            disabled={busy !== null}
            type="file"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void uploadFile(f);
              e.target.value = "";
            }}
          />
        </div>

        {uploadProgress !== null && busy === "file" ? (
          <div className="space-y-1">
            <div className="h-2 w-full overflow-hidden rounded-full bg-dk-bg">
              <div
                className="h-full bg-dk-accent transition-[width] duration-150"
                style={{ width: `${uploadProgress}%` }}
              />
            </div>
            <div className="flex flex-wrap items-center gap-2 text-xs text-dk-muted">
              <span>
                Uploading… {uploadProgress}%
                {lastFileRef.current
                  ? ` (${(lastFileRef.current.size / (1024 * 1024)).toFixed(1)} MiB)`
                  : ""}
              </span>
              <button
                className="rounded border border-dk-border px-2 py-0.5 text-dk-text hover:bg-dk-bg"
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  cancelUpload();
                }}
              >
                Cancel
              </button>
            </div>
          </div>
        ) : null}

        <form className="space-y-3" onSubmit={submitPaste}>
          <div>
            <label
              className="block text-xs font-medium text-dk-muted"
              htmlFor="ingest-paste"
            >
              Paste
            </label>
            <textarea
              className="mt-1 min-h-[160px] w-full rounded-lg border border-dk-border bg-dk-bg px-3 py-2 font-mono text-sm text-dk-text placeholder:text-dk-muted focus:outline-none focus:ring-2 focus:ring-dk-accent/40"
              disabled={busy !== null}
              id="ingest-paste"
              placeholder="Notes, code, or anything you want searchable later…"
              value={pasteText}
              onChange={(e) => setPasteText(e.target.value)}
            />
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <label className="text-xs text-dk-muted" htmlFor="ingest-kind">
              Kind
            </label>
            <select
              className="rounded-lg border border-dk-border bg-dk-bg px-2 py-1.5 text-sm text-dk-text focus:outline-none focus:ring-2 focus:ring-dk-accent/40"
              disabled={busy !== null}
              id="ingest-kind"
              value={pasteKind}
              onChange={(e) =>
                setPasteKind(e.target.value as "document" | "code_snippet")
              }
            >
              <option value="document">Document</option>
              <option value="code_snippet">Code snippet</option>
            </select>
            <button
              className="rounded-lg border border-dk-border bg-dk-bg px-4 py-2 text-sm font-medium text-dk-text transition hover:bg-dk-surface disabled:opacity-50"
              disabled={busy !== null}
              type="submit"
            >
              {busy === "paste" ? "Saving…" : "Save paste"}
            </button>
            {busy === "file" && uploadProgress === null ? (
              <span className="text-xs text-dk-muted">Uploading…</span>
            ) : null}
          </div>
        </form>

        {error ? (
          <div className="space-y-2">
            <p className="text-sm text-dk-warm" role="alert">
              {error}
            </p>
            {lastFileRef.current ? (
              <button
                className="rounded-lg border border-dk-border bg-dk-bg px-3 py-1.5 text-sm text-dk-text hover:bg-dk-surface"
                type="button"
                onClick={() => {
                  setError(null);
                  retryLastUpload();
                }}
              >
                Retry upload
              </button>
            ) : null}
          </div>
        ) : null}
        {lastCreated ? (
          <p className="text-sm text-dk-muted">
            Saved{" "}
            <span className="font-mono text-dk-text">{lastCreated.title}</span>{" "}
            ({lastCreated.kind}).{" "}
            <Link className="text-dk-accent underline-offset-2 hover:underline" to="/library">
              View library
            </Link>
          </p>
        ) : null}
      </SectionPage>
    </div>
  );
}
