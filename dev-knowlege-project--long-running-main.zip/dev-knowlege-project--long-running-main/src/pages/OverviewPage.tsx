import { useServiceStatus } from "../hooks/useServiceStatus";

export function OverviewPage() {
  const { health, wsLabel } = useServiceStatus();

  return (
    <div className="mx-auto flex max-w-4xl flex-col gap-6">
      <p className="text-xs font-semibold uppercase tracking-[0.2em] text-dk-accent">
        DevKnowledge Base
      </p>
      <h1 className="text-[2rem] font-bold leading-tight tracking-tight">
        Long-horizon coding workspace scaffold
      </h1>
      <p className="max-w-2xl text-base leading-relaxed text-dk-muted">
        Developer knowledge storage, search, and AI-assisted chat are planned
        per the product brief—this screen validates API, realtime, and design
        tokens for the next milestones.
      </p>
      <div className="grid gap-3 rounded-xl border border-dk-border bg-dk-surface p-5 shadow-sm sm:grid-cols-2">
        <div>
          <p className="text-sm font-medium text-dk-muted">API health</p>
          <p
            className={
              health?.status === "ok"
                ? "mt-1 text-base text-dk-forest"
                : "mt-1 text-base text-dk-warm"
            }
          >
            {health?.status === "ok"
              ? `${health.service}: healthy`
              : "Health endpoint unavailable"}
          </p>
        </div>
        <div>
          <p className="text-sm font-medium text-dk-muted">Realtime</p>
          <p className="mt-1 text-base text-dk-text">{wsLabel}</p>
        </div>
      </div>
      <p className="font-mono text-sm text-dk-muted">
        npm run dev · stack ready for DevKnowledge Base milestones
      </p>
    </div>
  );
}
