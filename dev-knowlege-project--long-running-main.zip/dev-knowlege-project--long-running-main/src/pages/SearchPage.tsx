import { SectionPage } from "./SectionPage";

export function SearchPage() {
  return (
    <SectionPage
      description="Vector-backed search with previews and relevance ranking. Keyword fallback when embeddings are unavailable."
      title="Search"
    />
  );
}
