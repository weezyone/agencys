import { render, screen, waitFor, within } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { MemoryRouter } from "react-router-dom";
import { AuthProvider } from "./auth/AuthContext";
import { App } from "./App";

function requestUrl(input: RequestInfo | URL): string {
  if (typeof input === "string") return input;
  if (input instanceof URL) return input.href;
  return input.url;
}

function mockFetch(health: "ok" | "offline") {
  return vi.fn().mockImplementation((input: RequestInfo | URL) => {
    const url = requestUrl(input);
    if (url.includes("/api/auth/me")) {
      return Promise.resolve({
        ok: true,
        json: async () => ({ user: null })
      });
    }
    if (url.includes("/api/health")) {
      if (health === "offline") {
        return Promise.reject(new Error("offline"));
      }
      return Promise.resolve({
        ok: true,
        json: async () => ({ status: "ok", service: "dev-knowlege-server" })
      });
    }
    return Promise.reject(new Error(`unmocked fetch: ${url}`));
  });
}

function renderApp(path = "/") {
  return render(
    <MemoryRouter initialEntries={[path]}>
      <AuthProvider>
        <App />
      </AuthProvider>
    </MemoryRouter>
  );
}

class MockWebSocket {
  static instances: MockWebSocket[] = [];
  onopen: (() => void) | null = null;
  onclose: (() => void) | null = null;
  onerror: (() => void) | null = null;

  constructor(public readonly url: string) {
    MockWebSocket.instances.push(this);
  }

  close() {
    this.onclose?.();
  }

  emitOpen() {
    this.onopen?.();
  }

  emitError() {
    this.onerror?.();
  }
}

describe("App", () => {
  afterEach(() => {
    vi.restoreAllMocks();
    MockWebSocket.instances = [];
  });

  it("renders the project heading", () => {
    vi.stubGlobal("fetch", mockFetch("offline"));
    vi.stubGlobal("WebSocket", MockWebSocket as unknown as typeof WebSocket);

    renderApp("/");

    const main =
      screen
        .getAllByTestId("shell-main")
        .find((el) =>
          within(el).queryByText("Long-horizon coding workspace scaffold")
        ) ?? screen.getAllByTestId("shell-main")[0];
    expect(main).toBeTruthy();
    expect(within(main).getByText("DevKnowledge Base")).toBeInTheDocument();
    expect(
      within(main).getByText("Long-horizon coding workspace scaffold")
    ).toBeInTheDocument();
  });

  it("shows healthy API status and open websocket status", async () => {
    vi.stubGlobal("fetch", mockFetch("ok"));
    vi.stubGlobal("WebSocket", MockWebSocket as unknown as typeof WebSocket);

    renderApp("/");

    MockWebSocket.instances[0]?.emitOpen();

    await waitFor(() => {
      const main = screen
        .getAllByTestId("shell-main")
        .find((el) =>
          within(el).queryByText("dev-knowlege-server: healthy")
        );
      expect(main).toBeTruthy();
    });

    const main =
      screen
        .getAllByTestId("shell-main")
        .find((el) =>
          within(el).queryByText("dev-knowlege-server: healthy")
        ) ?? null;
    expect(main).toBeTruthy();
    expect(
      within(main!).getByText("WebSocket connected")
    ).toBeInTheDocument();
  });
});
