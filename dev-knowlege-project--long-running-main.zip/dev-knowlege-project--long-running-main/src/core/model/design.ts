export type LayerType = "rect" | "ellipse" | "text";

export type Layer = {
  id: string;
  type: LayerType;
};

export type Artboard = {
  id: string;
  layers: Layer[];
};

export type DesignDocument = {
  project: {
    name: string;
  };
  artboards: Artboard[];
};
