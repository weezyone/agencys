/** Aligns with `knowledge_items.kind` in `server/db/schema.ts`. */
export type KnowledgeItemKind =
  | "code_snippet"
  | "document"
  | "media"
  | "bookmark"
  | "url";

/** API shape for `GET /api/knowledge/items`. */
export type KnowledgeItem = {
  id: string;
  userId: string;
  title: string;
  kind: KnowledgeItemKind | string;
  bodyText: string | null;
  sourceUrl: string | null;
  metadata: Record<string, unknown> | null;
  createdAt: number;
  updatedAt: number;
};

export type User = {
  id: string;
  email: string;
  createdAt: number;
};

export type Tag = {
  id: string;
  userId: string;
  name: string;
};
