import { useEffect, useMemo, useState } from "react";

export type HealthResponse = {
  status: "ok";
  service: string;
};

export function useServiceStatus() {
  const [health, setHealth] = useState<HealthResponse | null>(null);
  const [wsState, setWsState] = useState<"connecting" | "open" | "closed">(
    "connecting"
  );

  useEffect(() => {
    let isMounted = true;
    void fetch("/api/health")
      .then(async (response) => {
        if (!response.ok) {
          throw new Error(`Health check failed: ${response.status}`);
        }
        return (await response.json()) as HealthResponse;
      })
      .then((json) => {
        if (isMounted) {
          setHealth(json);
        }
      })
      .catch(() => {
        if (isMounted) {
          setHealth(null);
        }
      });

    return () => {
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    if (typeof WebSocket === "undefined") {
      setWsState("closed");
      return;
    }

    const socket = new WebSocket(
      `${window.location.origin.replace("http", "ws")}/ws`
    );
    socket.onopen = () => setWsState("open");
    socket.onclose = () => setWsState("closed");
    socket.onerror = () => setWsState("closed");

    return () => {
      socket.close();
    };
  }, []);

  const wsLabel = useMemo(() => {
    if (wsState === "open") return "WebSocket connected";
    if (wsState === "connecting") return "WebSocket connecting";
    return "WebSocket closed";
  }, [wsState]);

  return { health, wsState, wsLabel };
}
