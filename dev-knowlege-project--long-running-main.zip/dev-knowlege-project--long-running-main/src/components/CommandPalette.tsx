import { Command } from "@phosphor-icons/react";
import { useCallback, useEffect, useId, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { mainNav } from "../navigation";

type CommandPaletteProps = {
  onNavigate?: () => void;
};

export function CommandPalette({ onNavigate }: CommandPaletteProps) {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);
  const titleId = useId();

  const actions = useMemo(
    () =>
      mainNav.map((item) => ({
        id: item.to,
        label: item.label,
        hint: item.description,
        to: item.to
      })),
    []
  );

  const close = useCallback(() => setOpen(false), []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setOpen((v) => !v);
      }
      if (e.key === "Escape") {
        setOpen(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    if (open) {
      queueMicrotask(() => inputRef.current?.focus());
    }
  }, [open]);

  const run = (to: string) => {
    navigate(to);
    onNavigate?.();
    close();
  };

  if (!open) {
    return null;
  }

  return (
    <div
      aria-labelledby={titleId}
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-start justify-center bg-black/60 p-4 pt-[12vh]"
      role="dialog"
    >
      <button
        aria-label="Close command palette"
        className="absolute inset-0 cursor-default"
        type="button"
        onClick={close}
      />
      <div className="relative z-10 w-full max-w-lg overflow-hidden rounded-xl border border-dk-border bg-dk-surface shadow-xl">
        <div className="flex items-center gap-2 border-b border-dk-border px-3 py-2">
          <Command aria-hidden className="h-5 w-5 shrink-0 text-dk-muted" />
          <input
            ref={inputRef}
            aria-label="Search commands"
            className="w-full bg-transparent text-sm text-dk-text outline-none placeholder:text-dk-muted"
            placeholder="Jump to a page…"
            type="search"
            onChange={() => {
              /* Stub: filtering can be added in a later milestone */
            }}
          />
          <kbd className="hidden shrink-0 rounded border border-dk-border px-1.5 py-0.5 font-mono text-[10px] text-dk-muted sm:inline">
            Esc
          </kbd>
        </div>
        <p className="sr-only" id={titleId}>
          Command palette
        </p>
        <ul className="max-h-[min(60vh,420px)] overflow-y-auto p-2">
          {actions.map((a) => (
            <li key={a.id}>
              <button
                className="flex w-full flex-col items-start gap-0.5 rounded-lg px-3 py-2 text-left text-sm text-dk-text transition hover:bg-dk-bg"
                type="button"
                onClick={() => run(a.to)}
              >
                <span className="font-medium">{a.label}</span>
                <span className="text-xs text-dk-muted">{a.hint}</span>
              </button>
            </li>
          ))}
        </ul>
        <div className="border-t border-dk-border px-3 py-2 text-xs text-dk-muted">
          Tip: press{" "}
          <kbd className="rounded border border-dk-border px-1 py-0.5 font-mono">
            ⌘K
          </kbd>{" "}
          or{" "}
          <kbd className="rounded border border-dk-border px-1 py-0.5 font-mono">
            Ctrl+K
          </kbd>{" "}
          to toggle
        </div>
      </div>
    </div>
  );
}
