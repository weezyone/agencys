import { CaretDoubleLeft, CaretDoubleRight } from "@phosphor-icons/react";
import { useCallback, useEffect, useState } from "react";
import { Link, NavLink, Outlet } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import { CommandPalette } from "../components/CommandPalette";
import { mainNav } from "../navigation";

const STORAGE_KEY = "dk-sidebar-collapsed";

function readCollapsed(): boolean {
  if (typeof window === "undefined") return false;
  return window.localStorage.getItem(STORAGE_KEY) === "1";
}

export function AppLayout() {
  const { user, logout } = useAuth();
  const [collapsed, setCollapsed] = useState(readCollapsed);

  useEffect(() => {
    window.localStorage.setItem(STORAGE_KEY, collapsed ? "1" : "0");
  }, [collapsed]);

  const toggle = useCallback(() => setCollapsed((c) => !c), []);

  return (
    <div className="flex min-h-screen bg-dk-bg font-sans text-dk-text">
      <CommandPalette />

      <aside
        className={`relative hidden shrink-0 border-r border-dk-border bg-dk-surface transition-[width] duration-200 md:flex md:flex-col ${
          collapsed ? "w-[4.5rem]" : "w-56"
        }`}
      >
        <div className="flex h-14 items-center justify-between gap-2 border-b border-dk-border px-3">
          {!collapsed ? (
            <span className="truncate text-sm font-semibold text-dk-text">
              DevKnowledge Base
            </span>
          ) : (
            <span className="sr-only">DevKnowledge Base</span>
          )}
          <button
            aria-expanded={!collapsed}
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            className="rounded-md p-1.5 text-dk-muted transition hover:bg-dk-bg hover:text-dk-text"
            type="button"
            onClick={toggle}
          >
            {collapsed ? (
              <CaretDoubleRight className="h-5 w-5" />
            ) : (
              <CaretDoubleLeft className="h-5 w-5" />
            )}
          </button>
        </div>

        <nav aria-label="Main" className="flex flex-1 flex-col gap-1 p-2">
          {mainNav.map(({ to, label, end, Icon }) => (
            <NavLink
              key={to}
              className={({ isActive }) =>
                [
                  "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition",
                  collapsed ? "justify-center" : "",
                  isActive
                    ? "border border-dk-border bg-dk-bg text-dk-text"
                    : "border border-transparent text-dk-muted hover:border-dk-border hover:bg-dk-bg hover:text-dk-text"
                ].join(" ")
              }
              end={end}
              title={label}
              to={to}
            >
              <Icon className="h-5 w-5 shrink-0" />
              {!collapsed ? <span>{label}</span> : null}
            </NavLink>
          ))}
        </nav>
        <div className="mt-auto border-t border-dk-border p-2 text-xs">
          {user ? (
            <div className="flex flex-col gap-2">
              <span className="truncate text-dk-muted" title={user.email}>
                {user.email}
              </span>
              <button
                className="rounded-lg border border-dk-border px-2 py-1.5 text-left text-dk-text transition hover:bg-dk-bg"
                type="button"
                onClick={() => void logout()}
              >
                Sign out
              </button>
            </div>
          ) : (
            <div className="flex flex-col gap-2">
              <Link
                className="rounded-lg border border-dk-border px-2 py-1.5 text-center text-dk-text transition hover:bg-dk-bg"
                to="/login"
              >
                Sign in
              </Link>
              <Link
                className="rounded-lg border border-dk-border px-2 py-1.5 text-center text-dk-muted transition hover:bg-dk-bg hover:text-dk-text"
                to="/register"
              >
                Register
              </Link>
            </div>
          )}
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between gap-2 border-b border-dk-border bg-dk-bg px-4 py-3 md:hidden">
          <span className="text-sm font-semibold">DevKnowledge Base</span>
          {user ? (
            <button
              className="text-xs text-dk-accent"
              type="button"
              onClick={() => void logout()}
            >
              Sign out
            </button>
          ) : (
            <Link className="text-xs text-dk-accent" to="/login">
              Sign in
            </Link>
          )}
        </header>

        <main
          className="flex-1 px-4 py-6 pb-24 md:px-8 md:pb-8"
          data-testid="shell-main"
        >
          <Outlet />
        </main>
      </div>

      <nav
        aria-label="Primary"
        className="fixed bottom-0 left-0 right-0 z-40 border-t border-dk-border bg-dk-surface/95 backdrop-blur md:hidden"
      >
        <div className="flex gap-1 overflow-x-auto px-2 py-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {mainNav.map(({ to, label, end, Icon }) => (
            <NavLink
              key={to}
              className={({ isActive }) =>
                [
                  "flex min-w-[4.25rem] shrink-0 flex-col items-center gap-1 rounded-lg px-2 py-1.5 text-[11px] leading-tight transition",
                  isActive
                    ? "text-dk-accent"
                    : "text-dk-muted hover:text-dk-text"
                ].join(" ")
              }
              end={end}
              to={to}
            >
              <Icon className="h-6 w-6" />
              <span className="text-center">{label}</span>
            </NavLink>
          ))}
        </div>
      </nav>
    </div>
  );
}
