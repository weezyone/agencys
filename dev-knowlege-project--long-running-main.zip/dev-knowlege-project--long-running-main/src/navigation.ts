import {
  Books,
  ChartBar,
  ChatCircle,
  House,
  LinkSimple,
  MagnifyingGlass,
  type IconProps
} from "@phosphor-icons/react";
import type { ComponentType } from "react";

export type NavItem = {
  to: string;
  label: string;
  description: string;
  end?: boolean;
  Icon: ComponentType<IconProps>;
};

export const mainNav: NavItem[] = [
  {
    to: "/",
    label: "Overview",
    description: "Stack status and getting started",
    end: true,
    Icon: House
  },
  {
    to: "/library",
    label: "Library",
    description: "Upload and organize knowledge items",
    Icon: Books
  },
  {
    to: "/search",
    label: "Search",
    description: "Semantic and keyword discovery",
    Icon: MagnifyingGlass
  },
  {
    to: "/chat",
    label: "Chat",
    description: "RAG conversation with citations",
    Icon: ChatCircle
  },
  {
    to: "/ingest",
    label: "Ingest",
    description: "Capture URLs and web content",
    Icon: LinkSimple
  },
  {
    to: "/analytics",
    label: "Analytics",
    description: "Usage and knowledge insights",
    Icon: ChartBar
  }
];
