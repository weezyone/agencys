import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";

type DesignInput = {
  project?: { name?: string };
  artboards?: Array<{ layers?: unknown[] }>;
};

type ExportSummary = {
  version: 1;
  projectName: string;
  artboardCount: number;
  layerCount: number;
};

function parseArgs(argv: string[]) {
  const inputIdx = argv.indexOf("--input");
  const outputIdx = argv.indexOf("--output");

  if (inputIdx === -1 || outputIdx === -1) {
    throw new Error(
      "Usage: npm run export -- --input <path/to/input.json> --output <path/to/output.json>"
    );
  }

  return {
    input: argv[inputIdx + 1],
    output: argv[outputIdx + 1]
  };
}

async function run() {
  const { input, output } = parseArgs(process.argv.slice(2));
  const raw = await readFile(input, "utf8");
  const inputJson = JSON.parse(raw) as DesignInput;

  const artboards = inputJson.artboards ?? [];
  const layerCount = artboards.reduce((count, artboard) => {
    return count + (Array.isArray(artboard.layers) ? artboard.layers.length : 0);
  }, 0);

  const exportSummary: ExportSummary = {
    version: 1,
    projectName: inputJson.project?.name ?? "unnamed-project",
    artboardCount: artboards.length,
    layerCount
  };

  await mkdir(path.dirname(output), { recursive: true });
  await writeFile(output, `${JSON.stringify(exportSummary, null, 2)}\n`, "utf8");
}

void run().catch((error: unknown) => {
  const message =
    error instanceof Error ? error.message : "Unknown export pipeline failure";
  console.error(`[export] ${message}`);
  process.exit(1);
});
