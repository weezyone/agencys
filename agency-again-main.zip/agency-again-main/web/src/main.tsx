import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { Root } from "./root";
import { ProjectsList } from "./routes/ProjectsList";
import { ProjectDetail } from "./routes/ProjectDetail";
import "./styles.css";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Root />,
    children: [
      { index: true, element: <ProjectsList /> },
      { path: "projects/:projectId", element: <ProjectDetail /> },
    ],
  },
]);

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>,
);
