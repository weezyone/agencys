import { Link, Outlet } from "react-router-dom";

/** Top-level layout (root.tsx per the design brief). */
export function Root() {
  return (
    <div className="app">
      <header className="navbar">
        <Link to="/" className="brand">
          <span className="brand-mark">◆</span> Agency
          <span className="brand-sub">Multi-Agent Project Manager</span>
        </Link>
        <div className="navbar-tags">
          <span className="pill">Maestro</span>
          <span className="pill">Composio</span>
          <span className="pill">MongoDB</span>
        </div>
      </header>
      <main className="content">
        <Outlet />
      </main>
    </div>
  );
}
