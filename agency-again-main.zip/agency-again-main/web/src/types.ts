export type ProjectStatus = "planning" | "active" | "completed" | "blocked";
export type TaskStatus = "todo" | "in_progress" | "blocked" | "review" | "done";

export interface Project {
  id: string;
  name: string;
  clientName: string;
  brief: string;
  status: ProjectStatus;
  createdAt: string;
  updatedAt: string;
}

export interface Task {
  id: string;
  projectId: string;
  sprintId: string;
  title: string;
  description: string;
  assignedAgentId: string | null;
  status: TaskStatus;
  tags: string[];
  result: string | null;
  attempts: number;
}

export interface Sprint {
  id: string;
  name: string;
  goal: string;
  status: string;
  order: number;
  tasks: Task[];
}

export interface Board {
  project: Project;
  sprints: Sprint[];
}

export interface Agent {
  id: string;
  name: string;
  role: string;
  capabilities: string[];
  state: "idle" | "busy" | "error";
}

export interface Observation {
  id: string;
  agentId: string;
  type: string;
  content: string;
  timestamp: string;
}

export interface AgentMessage {
  id: string;
  from: string;
  to: string;
  kind: string;
  timestamp: string;
}

export interface Notification {
  via: string;
  target: string;
  text: string;
  timestamp: string;
}

export interface Feed {
  observations: Observation[];
  messages: AgentMessage[];
  notifications: Notification[];
}

export interface RunSummary {
  projectId: string;
  totalTasks: number;
  done: number;
  blocked: number;
  escalations: number;
  status: ProjectStatus;
}

export interface RerunResult {
  reset: number;
  summary: RunSummary;
}
