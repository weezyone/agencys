import { useState, type FormEvent } from "react";
import { api } from "../api";

interface NewProjectFormProps {
  onCreated: () => void;
}

const SAMPLE =
  "We need a Slack bot for alerts, a MongoDB backend for persistence, and a React dashboard so the client can track sprints and tasks.";

export function NewProjectForm({ onCreated }: NewProjectFormProps) {
  const [name, setName] = useState("");
  const [clientName, setClientName] = useState("");
  const [brief, setBrief] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.createProject({ name, clientName, brief });
      setName("");
      setClientName("");
      setBrief("");
      onCreated();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to create project");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className="card form" onSubmit={submit}>
      <h2>New client brief</h2>
      <p className="muted">
        The orchestrator (Maestro) will plan sprints & tasks, dispatch them to
        worker agents, review the output, and escalate anything that gets stuck.
      </p>
      <label>
        Project name
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Acme Portal"
          required
        />
      </label>
      <label>
        Client
        <input
          value={clientName}
          onChange={(e) => setClientName(e.target.value)}
          placeholder="Acme Corp"
          required
        />
      </label>
      <label>
        Brief
        <textarea
          value={brief}
          onChange={(e) => setBrief(e.target.value)}
          placeholder={SAMPLE}
          rows={4}
          required
        />
      </label>
      <div className="form-actions">
        <button
          type="button"
          className="ghost"
          onClick={() => {
            setName("Acme Portal");
            setClientName("Acme Corp");
            setBrief(SAMPLE);
          }}
        >
          Use sample
        </button>
        <button type="submit" disabled={busy}>
          {busy ? "Planning…" : "Plan & run project"}
        </button>
      </div>
      {error && <p className="error">{error}</p>}
    </form>
  );
}
