import type {
  Agent,
  Board,
  Feed,
  Project,
  RerunResult,
  RunSummary,
} from "./types";

async function json<T>(res: Response): Promise<T> {
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`${res.status} ${res.statusText}: ${body}`);
  }
  return res.json() as Promise<T>;
}

export const api = {
  listProjects: () => fetch("/api/projects").then(json<Project[]>),
  listAgents: () => fetch("/api/agents").then(json<Agent[]>),
  getBoard: (id: string) => fetch(`/api/projects/${id}/board`).then(json<Board>),
  getFeed: (id: string) => fetch(`/api/projects/${id}/feed`).then(json<Feed>),
  createProject: (input: { name: string; clientName: string; brief: string }) =>
    fetch("/api/projects", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(input),
    }).then(json<{ project: Project; summary: RunSummary }>),
  rerun: (id: string) =>
    fetch(`/api/projects/${id}/rerun`, { method: "POST" }).then(
      json<RerunResult>,
    ),
};
