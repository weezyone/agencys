import { useCallback, useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { api } from "../api";
import type { Board, Feed } from "../types";
import { StatusBadge } from "../components/StatusBadge";

export function ProjectDetail() {
  const { projectId } = useParams();
  const [board, setBoard] = useState<Board | null>(null);
  const [feed, setFeed] = useState<Feed | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    if (!projectId) return;
    const [b, f] = await Promise.all([
      api.getBoard(projectId),
      api.getFeed(projectId),
    ]);
    setBoard(b);
    setFeed(f);
  }, [projectId]);

  useEffect(() => {
    void load();
  }, [load]);

  async function rerun() {
    if (!projectId) return;
    setBusy(true);
    try {
      await api.rerun(projectId);
      await load();
    } finally {
      setBusy(false);
    }
  }

  if (!board) return <p className="muted">Loading project…</p>;

  return (
    <div>
      <div className="section-head">
        <div>
          <Link to="/" className="muted">
            ← All projects
          </Link>
          <h1>
            {board.project.name}{" "}
            <StatusBadge status={board.project.status} />
          </h1>
          <p className="muted">{board.project.clientName}</p>
        </div>
        <button onClick={() => void rerun()} disabled={busy}>
          {busy ? "Running…" : "Re-run"}
        </button>
      </div>

      <p className="brief">{board.project.brief}</p>

      <div className="board">
        {board.sprints.map((sprint) => (
          <div key={sprint.id} className="board-column">
            <div className="column-head">
              <h3>{sprint.name}</h3>
              <StatusBadge status={sprint.status} />
            </div>
            <p className="muted small">{sprint.goal}</p>
            {sprint.tasks.map((task) => (
              <div key={task.id} className={`task-card task-${task.status}`}>
                <div className="task-top">
                  <strong>{task.title}</strong>
                  <StatusBadge status={task.status} />
                </div>
                <p className="muted small">{task.description}</p>
                <div className="task-meta">
                  <span className="chip">{task.assignedAgentId ?? "unassigned"}</span>
                  {task.attempts > 0 && (
                    <span className="chip">{task.attempts} attempt(s)</span>
                  )}
                  {task.tags.map((tag) => (
                    <span key={tag} className="chip chip-tag">
                      {tag}
                    </span>
                  ))}
                </div>
                {task.result && <p className="task-result">{task.result}</p>}
              </div>
            ))}
          </div>
        ))}
      </div>

      <div className="grid-two">
        <section className="card">
          <h2>Activity & memory</h2>
          <ul className="feed">
            {feed?.observations.map((o) => (
              <li key={o.id} className={`feed-item feed-${o.type}`}>
                <span className="chip">{o.type}</span>
                <span>{o.content}</span>
                <span className="muted small">{o.agentId}</span>
              </li>
            ))}
          </ul>
        </section>
        <section className="card">
          <h2>Agent messages</h2>
          <ul className="feed">
            {feed?.messages.map((m) => (
              <li key={m.id} className="feed-item">
                <span className="chip">{m.kind}</span>
                <div>
                  <div className="muted small">
                    {m.from} → {m.to}
                  </div>
                  <span className="muted small">{m.timestamp}</span>
                </div>
              </li>
            ))}
            {feed && feed.messages.length === 0 && (
              <li className="muted">No agent messages yet.</li>
            )}
          </ul>
        </section>
      </div>

      <section className="card" style={{ marginTop: 16 }}>
        <h2>Composio notifications</h2>
        <ul className="feed">
          {feed?.notifications.map((n, i) => (
            <li key={i} className="feed-item">
              <span className="chip">{n.via}</span>
              <div>
                <div className="muted small">{n.target}</div>
                <span>{n.text}</span>
              </div>
            </li>
          ))}
          {feed && feed.notifications.length === 0 && (
            <li className="muted">No notifications yet.</li>
          )}
        </ul>
      </section>
    </div>
  );
}
