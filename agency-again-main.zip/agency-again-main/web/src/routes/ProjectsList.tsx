import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api";
import type { Agent, Project } from "../types";
import { StatusBadge } from "../components/StatusBadge";
import { NewProjectForm } from "../components/NewProjectForm";

export function ProjectsList() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const [p, a] = await Promise.all([api.listProjects(), api.listAgents()]);
    setProjects(p);
    setAgents(a);
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <div className="grid-two">
      <section>
        <div className="section-head">
          <h1>Projects</h1>
          <button className="ghost" onClick={() => void load()}>
            Refresh
          </button>
        </div>
        {loading && <p className="muted">Loading…</p>}
        {!loading && projects.length === 0 && (
          <p className="muted">No projects yet — create one from a brief.</p>
        )}
        <ul className="project-list">
          {projects.map((project) => (
            <li key={project.id}>
              <Link to={`/projects/${project.id}`} className="card project-row">
                <div>
                  <strong>{project.name}</strong>
                  <div className="muted">{project.clientName}</div>
                </div>
                <StatusBadge status={project.status} />
              </Link>
            </li>
          ))}
        </ul>

        <div className="agents-panel card">
          <h2>Agent team</h2>
          <ul className="agent-list">
            {agents.map((agent) => (
              <li key={agent.id}>
                <span className={`dot dot-${agent.state}`} />
                <strong>{agent.name}</strong>
                <span className="muted">{agent.role}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section>
        <NewProjectForm onCreated={() => void load()} />
      </section>
    </div>
  );
}
