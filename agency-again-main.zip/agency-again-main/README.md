# agency-again

A **Multi-Agent Project Manager**. A "Maestro"-style orchestrator agent breaks a
client brief into projects → sprints → tasks, dispatches them to worker agents,
reviews the output, and escalates anything that gets stuck to a human PM — with
**MongoDB** for persistence + observational memory and **Composio** for
real-world integrations (Slack/Gmail/Linear).

The system runs **fully offline**: the LLM/planner ("Maestro") and the
integrations ("Composio") sit behind interfaces with deterministic mock
implementations, and MongoDB is provided by an in-process ephemeral server when
no `MONGODB_URI` is configured. Real adapters can be dropped in without touching
the agents.

## Architecture

```
web (React 19 + Vite)  ──HTTP──▶  server (Express)
                                     │
                        ┌────────────┼───────────────┐
                        ▼            ▼               ▼
                  Orchestrator   Planner/Worker/   MongoDB
                  ("Maestro")     Reviewer agents  (persistence
                        │            │              + observational
                        ▼            ▼              memory)
                  LlmClient     IntegrationClient
                  (mock/real)   (Composio mock/real)
```

- `server/src/domain` — core types (Project, Sprint, Task, Agent, Observation, AgentMessage).
- `server/src/db` — MongoDB store + repositories (typed, string `_id`).
- `server/src/llm` — `LlmClient` gateway + deterministic mock planner.
- `server/src/integrations` — `IntegrationClient` (Composio) + mock.
- `server/src/agents` — `BaseAgent` and Planner/Worker/Reviewer, message bus.
- `server/src/orchestrator` — Maestro orchestrator, error classification/retry, system factory.
- `server/src/memory` — observational memory.
- `server/src/api` — Express REST API.
- `web/` — React 19 + Vite dashboard (project board, agents, activity feed).

## Prerequisites

- Node.js >= 20
- [pnpm](https://pnpm.io) (repo uses a pnpm workspace)

## Setup

```bash
pnpm install
```

This also downloads a MongoDB binary via `mongodb-memory-server` (cached), so no
external database is required for local development or tests.

## Run (development)

```bash
pnpm dev          # runs the API (:4000) and the web app (:5173) together
```

Then open http://localhost:5173.

Run individually:

```bash
pnpm --filter @agency/server dev   # API on :4000
pnpm --filter @agency/web dev      # Vite dev server on :5173 (proxies /api)
```

### Optional configuration (env)

| Variable           | Default              | Description                                  |
| ------------------ | -------------------- | -------------------------------------------- |
| `PORT`             | `4000`               | API port                                     |
| `MONGODB_URI`      | _(ephemeral server)_ | Use a real MongoDB instead of the in-memory one |
| `WORKER_COUNT`     | `3`                  | Number of worker agents                      |
| `PM_SLACK_CHANNEL` | `#project-updates`   | Channel used for escalations/alerts          |
| `LLM_PROVIDER`     | `mock`               | `mock` or `openai` (real adapter TBD)        |
| `OPENAI_API_KEY`   | —                    | Required when `LLM_PROVIDER=openai`          |
| `COMPOSIO_API_KEY` | —                    | When set, use Composio adapter (TBD)         |

## Test / lint / build

```bash
pnpm test        # all workspaces (server uses Vitest + real ephemeral MongoDB)
pnpm lint
pnpm typecheck
pnpm build
```

## API

| Method | Path                         | Description                                  |
| ------ | ---------------------------- | -------------------------------------------- |
| GET    | `/api/health`                | Health check                                 |
| GET    | `/api/agents`                | List the agent team                          |
| GET    | `/api/projects`              | List projects                                |
| POST   | `/api/projects`              | Create → plan → run a project from a brief   |
| GET    | `/api/projects/:id/board`    | Project with sprints + tasks                 |
| GET    | `/api/projects/:id/feed`     | Observations, messages, Composio notifications |
| POST   | `/api/projects/:id/rerun`    | Re-run orchestration                         |
