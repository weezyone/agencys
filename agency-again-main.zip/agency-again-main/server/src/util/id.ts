import { randomUUID } from "node:crypto";

export function randomId(prefix = ""): string {
  return `${prefix}${randomUUID()}`;
}

/** Deterministic, monotonically increasing id factory (useful for tests). */
export function sequentialIdFactory(prefix = "id_"): () => string {
  let counter = 0;
  return () => {
    counter += 1;
    return `${prefix}${counter}`;
  };
}
