import type { Task } from "../domain/types.js";

/**
 * LLM gateway abstraction ("Maestro" planning brain).
 *
 * The rest of the system depends only on this interface. The default
 * implementation is a deterministic mock so everything runs offline; a real
 * provider (e.g. OpenAI) implements the same contract by translating each
 * request `kind` into a prompt and parsing the response.
 */

export interface PlannedTask {
  title: string;
  description: string;
  tags: string[];
}

export interface PlannedSprint {
  name: string;
  goal: string;
  tasks: PlannedTask[];
}

export interface PlanResult {
  summary: string;
  sprints: PlannedSprint[];
}

export interface ExecuteResult {
  output: string;
}

export interface ReviewResult {
  approved: boolean;
  feedback: string;
}

export interface TiebreakResult {
  chosenIndex: number;
  rationale: string;
}

export type LlmRequest =
  | { kind: "plan"; clientName: string; brief: string }
  | { kind: "execute"; task: Task; memory: string[] }
  | { kind: "review"; task: Task; output: string }
  | { kind: "tiebreak"; question: string; options: string[]; context: string };

export interface LlmClient {
  readonly name: string;
  plan(clientName: string, brief: string): Promise<PlanResult>;
  execute(task: Task, memory: string[]): Promise<ExecuteResult>;
  review(task: Task, output: string): Promise<ReviewResult>;
  tiebreak(
    question: string,
    options: string[],
    context: string,
  ): Promise<TiebreakResult>;
}
