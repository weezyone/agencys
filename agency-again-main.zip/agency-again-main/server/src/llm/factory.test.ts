import { describe, expect, it } from "vitest";
import { loadConfig } from "../config.js";
import { createLlmClient } from "./factory.js";

describe("LLM factory", () => {
  it("defaults to the mock LLM client", () => {
    const client = createLlmClient(loadConfig({}));
    expect(client.name).toBe("mock-maestro");
  });

  it("requires OPENAI_API_KEY when LLM_PROVIDER=openai", () => {
    expect(() =>
      createLlmClient(loadConfig({ LLM_PROVIDER: "openai" })),
    ).toThrow(/OPENAI_API_KEY/);
  });
});
