import { describe, expect, it } from "vitest";
import { createMockLlm } from "./mockLlm.js";
import type { Task } from "../domain/types.js";

const baseTask = (overrides: Partial<Task>): Task => ({
  id: "t1",
  projectId: "p1",
  sprintId: "s1",
  title: "Do the thing",
  description: "",
  assignedAgentId: "w1",
  status: "todo",
  tags: [],
  result: null,
  attempts: 1,
  createdAt: "",
  updatedAt: "",
  ...overrides,
});

describe("mock LLM planner", () => {
  const llm = createMockLlm();

  it("produces 3 sprints and detects features from the brief", async () => {
    const plan = await llm.plan(
      "Acme",
      "We need a Slack bot, a MongoDB backend and a React dashboard.",
    );
    expect(plan.sprints).toHaveLength(3);
    const implTasks = plan.sprints[1]!.tasks.map((t) => t.title);
    expect(implTasks).toContain("Integrate Slack notifications");
    expect(implTasks).toContain("Implement MongoDB persistence");
    expect(implTasks).toContain("Build project board UI");
  });

  it("falls back to brief-derived tasks when no features match", async () => {
    const plan = await llm.plan(
      "Acme",
      "Organise the annual company offsite retreat for staff.",
    );
    expect(plan.sprints[1]!.tasks.length).toBeGreaterThan(0);
  });

  it("executes a normal task successfully", async () => {
    const res = await llm.execute(baseTask({}), []);
    expect(res.output).toContain('Completed "Do the thing"');
  });

  it("throws for force:error tasks", async () => {
    await expect(
      llm.execute(baseTask({ tags: ["force:error"] }), []),
    ).rejects.toThrow(/transient failure/);
  });

  it("is flaky then succeeds based on attempts", async () => {
    await expect(
      llm.execute(baseTask({ tags: ["flaky:2"], attempts: 1 }), []),
    ).rejects.toThrow(/flaky/);
    const ok = await llm.execute(baseTask({ tags: ["flaky:2"], attempts: 2 }), []);
    expect(ok.output).toContain("Completed");
  });

  it("rejects output containing TODO, approves otherwise", async () => {
    const bad = await llm.review(baseTask({}), "Result with TODO left");
    expect(bad.approved).toBe(false);
    const good = await llm.review(baseTask({}), "All done");
    expect(good.approved).toBe(true);
  });

  it("tiebreaks by choosing the most detailed option", async () => {
    const res = await llm.tiebreak("Which plan?", ["A", "A much longer plan"], "");
    expect(res.chosenIndex).toBe(1);
  });
});
