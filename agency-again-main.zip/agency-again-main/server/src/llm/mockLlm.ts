import type { Task } from "../domain/types.js";
import type {
  ExecuteResult,
  LlmClient,
  PlanResult,
  PlannedTask,
  ReviewResult,
  TiebreakResult,
} from "./types.js";

/**
 * Deterministic, offline LLM used for local dev and tests. It emulates a
 * Maestro-style planner with simple, explainable heuristics so the whole
 * multi-agent pipeline can run without any API keys.
 *
 * Testing hooks (encoded in task tags so behaviour is deterministic):
 *   - "force:error"   -> execute() throws a transient error every attempt
 *   - "flaky:N"       -> execute() throws for the first N attempts, then succeeds
 *   - "needs:review"  -> review() rejects the first time (output contains TODO)
 */

interface FeatureRule {
  match: RegExp;
  task: PlannedTask;
}

const FEATURE_RULES: FeatureRule[] = [
  {
    match: /slack/,
    task: {
      title: "Integrate Slack notifications",
      description: "Wire Composio Slack toolkit so agents can post alerts.",
      tags: ["integration", "slack"],
    },
  },
  {
    match: /gmail|email/,
    task: {
      title: "Integrate email notifications",
      description: "Send status emails to the client via the Gmail toolkit.",
      tags: ["integration", "email"],
    },
  },
  {
    match: /linear|jira|ticket/,
    task: {
      title: "Sync tasks to issue tracker",
      description: "Mirror tasks into Linear/Jira via Composio.",
      tags: ["integration", "tracker"],
    },
  },
  {
    match: /mongo|database|persist|memory/,
    task: {
      title: "Implement MongoDB persistence",
      description: "Model projects, sprints, tasks, agents and observations.",
      tags: ["backend", "database"],
    },
  },
  {
    match: /react|frontend|ui|dashboard|board/,
    task: {
      title: "Build project board UI",
      description: "React dashboard showing sprints, tasks and agent activity.",
      tags: ["frontend", "ui"],
    },
  },
  {
    match: /orchestrat|agent|multi-agent|maestro/,
    task: {
      title: "Implement agent orchestration engine",
      description: "Planner/worker/reviewer agents coordinated by an orchestrator.",
      tags: ["backend", "agents"],
    },
  },
];

function derivedFeatureTasks(brief: string): PlannedTask[] {
  const lower = brief.toLowerCase();
  const matched = FEATURE_RULES.filter((r) => r.match.test(lower)).map(
    (r) => r.task,
  );
  if (matched.length > 0) return matched;
  // Fall back to turning the first few sentences of the brief into tasks.
  return brief
    .split(/[.\n]/)
    .map((s) => s.trim())
    .filter((s) => s.length > 12)
    .slice(0, 3)
    .map((sentence, i) => ({
      title: `Deliver feature ${i + 1}`,
      description: sentence,
      tags: ["feature"],
    }));
}

export function createMockLlm(name = "mock-maestro"): LlmClient {
  return {
    name,

    async plan(clientName: string, brief: string): Promise<PlanResult> {
      const featureTasks = derivedFeatureTasks(brief);
      return {
        summary: `Plan for ${clientName}: ${featureTasks.length} core deliverables across 3 sprints.`,
        sprints: [
          {
            name: "Discovery & Planning",
            goal: "Understand requirements and set up foundations.",
            tasks: [
              {
                title: "Gather requirements",
                description: `Analyse the brief from ${clientName} and confirm scope.`,
                tags: ["planning"],
              },
              {
                title: "Design data model",
                description: "Define collections/schemas and key access patterns.",
                tags: ["planning", "backend"],
              },
            ],
          },
          {
            name: "Implementation",
            goal: "Build the core deliverables.",
            tasks: featureTasks,
          },
          {
            name: "Review & Launch",
            goal: "Validate quality and hand off to the client.",
            tasks: [
              {
                title: "QA and integration testing",
                description: "Verify each deliverable end to end.",
                tags: ["qa", "needs:review"],
              },
              {
                title: "Launch and notify client",
                description: `Ship and send a summary to ${clientName}.`,
                tags: ["launch"],
              },
            ],
          },
        ],
      };
    },

    async execute(task: Task): Promise<ExecuteResult> {
      if (task.tags.includes("force:critical")) {
        throw new Error("Security policy violation: forbidden operation");
      }
      if (task.tags.includes("force:error")) {
        throw new Error(`Simulated transient failure while executing "${task.title}"`);
      }
      const flaky = task.tags.find((t) => t.startsWith("flaky:"));
      if (flaky) {
        const threshold = Number(flaky.split(":")[1] ?? "1");
        // attempts is 1-based for the current attempt.
        if (task.attempts < threshold) {
          throw new Error(
            `Simulated flaky failure (attempt ${task.attempts}/${threshold})`,
          );
        }
      }
      const needsReview =
        task.tags.includes("needs:review") && !task.tags.includes("reworked");
      const marker = needsReview ? " TODO: refine before launch." : "";
      return {
        output: `Completed "${task.title}".${marker} Deliverable produced by ${name}.`,
      };
    },

    async review(_task: Task, output: string): Promise<ReviewResult> {
      const approved = !/todo/i.test(output);
      return {
        approved,
        feedback: approved
          ? "Meets acceptance criteria."
          : "Contains unfinished TODO items; please rework.",
      };
    },

    async tiebreak(
      _question: string,
      options: string[],
      _context: string,
    ): Promise<TiebreakResult> {
      // Deterministic policy: prefer the option that is most specific (longest).
      let chosenIndex = 0;
      for (let i = 1; i < options.length; i += 1) {
        if ((options[i]?.length ?? 0) > (options[chosenIndex]?.length ?? 0)) {
          chosenIndex = i;
        }
      }
      return {
        chosenIndex,
        rationale: "Selected the most detailed option as the higher-confidence plan.",
      };
    },
  };
}
