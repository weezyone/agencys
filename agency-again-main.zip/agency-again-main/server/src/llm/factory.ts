import type { AppConfig } from "../config.js";
import { createMockLlm } from "./mockLlm.js";
import type { LlmClient } from "./types.js";

/**
 * Select the LLM adapter from configuration. Defaults to the deterministic
 * mock so the system runs fully offline.
 */
export function createLlmClient(config: AppConfig): LlmClient {
  if (config.llmProvider === "openai") {
    if (!config.openaiApiKey) {
      throw new Error(
        "OPENAI_API_KEY is required when LLM_PROVIDER=openai. " +
          "Set the key or use LLM_PROVIDER=mock for offline development.",
      );
    }
    throw new Error(
      "OpenAI LLM adapter is not yet implemented. Use LLM_PROVIDER=mock for now.",
    );
  }
  return createMockLlm();
}
