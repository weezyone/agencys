/**
 * Error classification and retry policy for agent actions.
 *
 * Every LLM/tool call is wrapped so failures are classified as:
 *   - transient: retry with exponential backoff + jitter
 *   - permanent: fail fast (caller decides on fallback)
 *   - critical:  fail fast and escalate to a human
 */

export type ErrorSeverity = "transient" | "permanent" | "critical";

const TRANSIENT = /(timeout|timed out|rate.?limit|429|503|econnreset|temporarily|flaky|transient|unavailable)/i;
const CRITICAL = /(budget|security|unauthor|forbidden|401|403|permission denied)/i;

export function classifyError(error: unknown): ErrorSeverity {
  const message = error instanceof Error ? error.message : String(error);
  if (CRITICAL.test(message)) return "critical";
  if (TRANSIENT.test(message)) return "transient";
  return "permanent";
}

export interface RetryOptions {
  retries?: number;
  baseDelayMs?: number;
  maxDelayMs?: number;
  classify?: (error: unknown) => ErrorSeverity;
  sleep?: (ms: number) => Promise<void>;
  random?: () => number;
  onRetry?: (attempt: number, error: unknown, delayMs: number) => void;
}

const defaultSleep = (ms: number) =>
  new Promise<void>((resolve) => setTimeout(resolve, ms));

/**
 * Run `fn`, retrying only transient failures with exponential backoff + jitter.
 * Permanent/critical errors are re-thrown immediately so the caller can pick a
 * fallback or escalation path. `attempt` passed to `fn` is 1-based.
 */
export async function withRetry<T>(
  fn: (attempt: number) => Promise<T>,
  options: RetryOptions = {},
): Promise<T> {
  const retries = options.retries ?? 3;
  const baseDelayMs = options.baseDelayMs ?? 200;
  const maxDelayMs = options.maxDelayMs ?? 5000;
  const classify = options.classify ?? classifyError;
  const sleep = options.sleep ?? defaultSleep;
  const random = options.random ?? Math.random;

  let lastError: unknown;
  for (let attempt = 1; attempt <= retries + 1; attempt += 1) {
    try {
      return await fn(attempt);
    } catch (error) {
      lastError = error;
      const severity = classify(error);
      const isLastAttempt = attempt === retries + 1;
      if (severity !== "transient" || isLastAttempt) {
        throw error;
      }
      const backoff = Math.min(maxDelayMs, baseDelayMs * 2 ** (attempt - 1));
      const delayMs = Math.round(backoff * (0.5 + random() * 0.5));
      options.onRetry?.(attempt, error, delayMs);
      await sleep(delayMs);
    }
  }
  throw lastError;
}
