import type {
  Project,
  ProjectStatus,
  Sprint,
  Task,
} from "../domain/types.js";
import type { Repositories } from "../db/repositories.js";
import type { ErrorSeverity } from "./errors.js";
import { BaseAgent, type AgentConfig, type AgentContext } from "../agents/baseAgent.js";
import { PlannerAgent } from "../agents/plannerAgent.js";
import { ReviewerAgent } from "../agents/reviewerAgent.js";
import { WorkerAgent, type WorkerRetryConfig } from "../agents/workerAgent.js";
import { BROADCAST } from "../agents/messageBus.js";

export interface CreateProjectInput {
  name: string;
  clientName: string;
  brief: string;
}

export interface RunSummary {
  projectId: string;
  totalTasks: number;
  done: number;
  blocked: number;
  escalations: number;
  status: ProjectStatus;
}

export interface OrchestratorDeps {
  repos: Repositories;
  ids: () => string;
  planner: PlannerAgent;
  reviewer: ReviewerAgent;
  workers: WorkerAgent[];
  pmChannel?: string;
  retry?: WorkerRetryConfig;
}

/**
 * The "Maestro" orchestrator / project-manager agent. It plans the project,
 * dispatches tasks to workers, verifies results via the reviewer, and steps in
 * to retry, rework, or escalate to the human PM (via Composio) when needed.
 */
export class Orchestrator extends BaseAgent {
  private readonly repos: Repositories;
  private readonly ids: () => string;
  private readonly planner: PlannerAgent;
  private readonly reviewer: ReviewerAgent;
  private readonly workers: WorkerAgent[];
  private readonly workerById: Map<string, WorkerAgent>;
  private readonly pmChannel: string;
  private readonly retry: WorkerRetryConfig;

  constructor(config: AgentConfig, ctx: AgentContext, deps: OrchestratorDeps) {
    super(config, ctx);
    this.repos = deps.repos;
    this.ids = deps.ids;
    this.planner = deps.planner;
    this.reviewer = deps.reviewer;
    this.workers = deps.workers;
    this.workerById = new Map(deps.workers.map((w) => [w.id, w]));
    this.pmChannel = deps.pmChannel ?? "#project-updates";
    this.retry = deps.retry ?? {};
  }

  /** Create a project and expand the plan into persisted sprints + tasks. */
  async createProject(input: CreateProjectInput): Promise<Project> {
    const now = this.ctx.clock().toISOString();
    const project: Project = {
      id: this.ids(),
      name: input.name,
      clientName: input.clientName,
      brief: input.brief,
      status: "planning",
      createdAt: now,
      updatedAt: now,
    };
    await this.repos.projects.insert(project);
    await this.remember(project.id, "event", `Project "${project.name}" created for ${project.clientName}.`);

    const plan = await this.planner.plan(project);

    let workerCursor = 0;
    for (let i = 0; i < plan.sprints.length; i += 1) {
      const planned = plan.sprints[i]!;
      const sprint: Sprint = {
        id: this.ids(),
        projectId: project.id,
        name: planned.name,
        goal: planned.goal,
        status: "planned",
        order: i,
        createdAt: this.ctx.clock().toISOString(),
      };
      await this.repos.sprints.insert(sprint);

      for (const plannedTask of planned.tasks) {
        const assigned =
          this.workers.length > 0
            ? this.workers[workerCursor % this.workers.length]!.id
            : null;
        workerCursor += 1;
        const ts = this.ctx.clock().toISOString();
        const task: Task = {
          id: this.ids(),
          projectId: project.id,
          sprintId: sprint.id,
          title: plannedTask.title,
          description: plannedTask.description,
          assignedAgentId: assigned,
          status: "todo",
          tags: plannedTask.tags,
          result: null,
          attempts: 0,
          createdAt: ts,
          updatedAt: ts,
        };
        await this.repos.tasks.insert(task);
      }
    }

    return project;
  }

  /** Execute every non-done task in the project, sprint by sprint. */
  async run(projectId: string): Promise<RunSummary> {
    const project = await this.repos.projects.get(projectId);
    if (!project) throw new Error(`Project ${projectId} not found`);
    await this.setState("busy");
    await this.repos.projects.update(projectId, { status: "active" });

    let escalations = 0;
    const sprints = await this.repos.sprints.listByProject(projectId);
    for (const sprint of sprints) {
      await this.repos.sprints.update(sprint.id, { status: "active" });
      const tasks = await this.repos.tasks.listBySprint(sprint.id);
      for (const task of tasks) {
        if (task.status === "done") continue;
        const escalated = await this.executeTask(task);
        if (escalated) escalations += 1;
      }
      const remaining = await this.repos.tasks.listBySprint(sprint.id);
      if (remaining.every((t) => t.status === "done")) {
        await this.repos.sprints.update(sprint.id, { status: "completed" });
      }
    }

    const allTasks = await this.repos.tasks.listByProject(projectId);
    const done = allTasks.filter((t) => t.status === "done").length;
    const blocked = allTasks.filter((t) => t.status === "blocked").length;
    const status: ProjectStatus = blocked > 0 ? "blocked" : "completed";
    await this.repos.projects.update(projectId, { status });
    await this.setState("idle");

    if (status === "completed") {
      await this.ctx.integrations.notify(
        "slack",
        this.pmChannel,
        `✅ Project "${project.name}" for ${project.clientName} is complete: ${done}/${allTasks.length} tasks done.`,
        projectId,
      );
    }

    await this.remember(
      projectId,
      "decision",
      `Run finished: ${done} done, ${blocked} blocked, ${escalations} escalations. Status=${status}.`,
    );

    return {
      projectId,
      totalTasks: allTasks.length,
      done,
      blocked,
      escalations,
      status,
    };
  }

  /** Reset blocked tasks so a re-run can retry them. */
  async prepareForRerun(projectId: string): Promise<number> {
    const tasks = await this.repos.tasks.listByProject(projectId);
    let reset = 0;
    for (const task of tasks) {
      if (task.status !== "blocked") continue;
      await this.repos.tasks.update(task.id, {
        status: "todo",
        result: null,
        updatedAt: this.ctx.clock().toISOString(),
      });
      reset += 1;
    }
    if (reset > 0) {
      await this.remember(
        projectId,
        "event",
        `Prepared for re-run: reset ${reset} blocked task(s) to todo.`,
      );
    }
    return reset;
  }

  /** Plan and immediately execute; convenience for API + demos. */
  async planAndRun(
    input: CreateProjectInput,
  ): Promise<{ project: Project; summary: RunSummary }> {
    const project = await this.createProject(input);
    const summary = await this.run(project.id);
    return { project, summary };
  }

  private workerFor(task: Task): WorkerAgent | undefined {
    if (task.assignedAgentId) {
      const direct = this.workerById.get(task.assignedAgentId);
      if (direct) return direct;
    }
    return this.workers[0];
  }

  /** Returns true if the task ended up escalated/blocked. */
  private async executeTask(task: Task): Promise<boolean> {
    const worker = this.workerFor(task);
    if (!worker) {
      await this.escalate(task, "No worker available to execute the task.", 0, "permanent");
      return true;
    }
    await this.repos.tasks.update(task.id, {
      status: "in_progress",
      assignedAgentId: worker.id,
    });

    const outcome = await worker.executeTask(task, this.retry);
    let attempts = outcome.attempts;

    if (!outcome.ok) {
      await this.escalate(
        task,
        `Worker failed (${outcome.severity}): ${outcome.error}`,
        attempts,
        outcome.severity,
      );
      return true;
    }

    let review = await this.reviewer.review(task, outcome.output);
    let finalOutput = outcome.output;

    if (!review.approved) {
      // Fallback: ask the worker to rework once, then re-review.
      await this.repos.tasks.update(task.id, { status: "review" });
      const reworkTask: Task = {
        ...task,
        tags: [...task.tags, "reworked"],
        attempts,
      };
      const retryOutcome = await worker.executeTask(reworkTask, this.retry);
      attempts += retryOutcome.attempts;
      if (!retryOutcome.ok) {
        await this.escalate(
          task,
          `Rework failed (${retryOutcome.severity}): ${retryOutcome.error}`,
          attempts,
          retryOutcome.severity,
        );
        return true;
      }
      finalOutput = retryOutcome.output;
      review = await this.reviewer.review(reworkTask, retryOutcome.output);
      if (!review.approved) {
        await this.escalate(
          task,
          `Still not approved after rework: ${review.feedback}`,
          attempts,
          "permanent",
        );
        return true;
      }
    }

    await this.repos.tasks.update(task.id, {
      status: "done",
      result: finalOutput,
      attempts,
      updatedAt: this.ctx.clock().toISOString(),
    });
    return false;
  }

  private async escalate(
    task: Task,
    reason: string,
    attempts = task.attempts,
    severity: ErrorSeverity = "permanent",
  ): Promise<void> {
    await this.repos.tasks.update(task.id, {
      status: "blocked",
      result: reason,
      attempts,
      updatedAt: this.ctx.clock().toISOString(),
    });
    await this.remember(
      task.projectId,
      "escalation",
      `Escalated "${task.title}" to human PM (${severity}): ${reason}`,
    );
    await this.send({
      projectId: task.projectId,
      to: BROADCAST,
      kind: "task.escalated",
      payload: { taskId: task.id, reason, severity },
    });
    const alert = escalationAlert(task.title, reason, severity);
    await this.ctx.integrations.notify(
      "slack",
      this.pmChannel,
      alert,
      task.projectId,
    );
  }

  /**
   * Orchestrator as tiebreaker: pick between conflicting options. If the
   * options are indistinguishable (ambiguous), escalate to the human PM.
   */
  async resolveConflict(
    projectId: string,
    question: string,
    options: string[],
    context = "",
  ): Promise<{ escalated: boolean; chosen?: string }> {
    const distinctLengths = new Set(options.map((o) => o.length));
    if (options.length > 1 && distinctLengths.size === 1) {
      await this.remember(projectId, "escalation", `Ambiguous tie on: ${question}`);
      await this.ctx.integrations.notify(
        "slack",
        this.pmChannel,
        `🤝 Agents are tied on "${question}". Please advise.`,
        projectId,
      );
      return { escalated: true };
    }
    const result = await this.ctx.llm.tiebreak(question, options, context);
    const chosen = options[result.chosenIndex]!;
    await this.remember(
      projectId,
      "decision",
      `Tiebreak "${question}" -> "${chosen}" (${result.rationale})`,
    );
    return { escalated: false, chosen };
  }
}

function escalationAlert(
  title: string,
  reason: string,
  severity: ErrorSeverity,
): string {
  switch (severity) {
    case "critical":
      return `🛑 CRITICAL — automation halted for "${title}". ${reason}`;
    case "transient":
      return `⚠️ Retries exhausted for "${title}". ${reason}`;
    case "permanent":
      return `🚨 "${title}" needs a human. ${reason}`;
    default: {
      const _exhaustive: never = severity;
      return _exhaustive;
    }
  }
}
