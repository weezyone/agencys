import type { AgentContext } from "../agents/baseAgent.js";
import type { Repositories } from "../db/repositories.js";
import { PlannerAgent } from "../agents/plannerAgent.js";
import { ReviewerAgent } from "../agents/reviewerAgent.js";
import { WorkerAgent, type WorkerRetryConfig } from "../agents/workerAgent.js";
import { Orchestrator } from "./orchestrator.js";

export interface OrchestrationSystem {
  orchestrator: Orchestrator;
  planner: PlannerAgent;
  reviewer: ReviewerAgent;
  workers: WorkerAgent[];
}

export interface SystemOptions {
  workerCount?: number;
  pmChannel?: string;
  retry?: WorkerRetryConfig;
}

/**
 * Build and register the full multi-agent team: one planner, one reviewer,
 * N workers, and the orchestrator that coordinates them.
 */
export async function createOrchestrationSystem(
  repos: Repositories,
  ctx: AgentContext,
  ids: () => string,
  options: SystemOptions = {},
): Promise<OrchestrationSystem> {
  const workerCount = options.workerCount ?? 3;

  const planner = new PlannerAgent(
    { id: "planner", name: "Planner", role: "planner", capabilities: ["decompose"] },
    ctx,
  );
  const reviewer = new ReviewerAgent(
    { id: "reviewer", name: "Reviewer", role: "reviewer", capabilities: ["review"] },
    ctx,
  );
  const workers = Array.from({ length: workerCount }, (_, i) => {
    const n = i + 1;
    return new WorkerAgent(
      {
        id: `worker-${n}`,
        name: `Worker ${n}`,
        role: "worker",
        capabilities: ["build", "integrate"],
      },
      ctx,
    );
  });

  const orchestrator = new Orchestrator(
    {
      id: "orchestrator",
      name: "Maestro Orchestrator",
      role: "orchestrator",
      capabilities: ["plan", "coordinate", "escalate"],
    },
    ctx,
    {
      repos,
      ids,
      planner,
      reviewer,
      workers,
      ...(options.pmChannel ? { pmChannel: options.pmChannel } : {}),
      ...(options.retry ? { retry: options.retry } : {}),
    },
  );

  await Promise.all([
    planner.register(),
    reviewer.register(),
    orchestrator.register(),
    ...workers.map((w) => w.register()),
  ]);

  return { orchestrator, planner, reviewer, workers };
}
