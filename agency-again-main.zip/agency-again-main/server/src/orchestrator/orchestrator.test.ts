import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { makeTestHarness, type TestHarness } from "../__testutils__/context.js";
import { createOrchestrationSystem, type OrchestrationSystem } from "./system.js";

describe("Orchestrator end-to-end", () => {
  let h: TestHarness;
  let system: OrchestrationSystem;

  beforeEach(async () => {
    h = await makeTestHarness();
    system = await createOrchestrationSystem(h.store.repositories, h.ctx, h.ids, {
      workerCount: 2,
      retry: { retries: 2, sleep: async () => {} },
    });
  });
  afterEach(async () => {
    await h.close();
  });

  it("plans and completes a straightforward project", async () => {
    const { project, summary } = await system.orchestrator.planAndRun({
      name: "Acme Portal",
      clientName: "Acme",
      brief: "Build a MongoDB backend, a Slack bot, and a React dashboard.",
    });

    expect(summary.status).toBe("completed");
    expect(summary.totalTasks).toBeGreaterThan(0);
    expect(summary.done).toBe(summary.totalTasks);
    expect(summary.blocked).toBe(0);

    const tasks = await h.store.repositories.tasks.listByProject(project.id);
    expect(tasks.every((t) => t.status === "done")).toBe(true);
    // Each task got assigned to a worker (round-robin).
    expect(tasks.every((t) => t.assignedAgentId?.startsWith("worker-"))).toBe(true);

    // Reviewer forced a rework on the QA task (tagged needs:review) but it still
    // completed after one rework pass.
    const qa = tasks.find((t) => t.tags.includes("needs:review"));
    expect(qa?.status).toBe("done");

    // Completion notification was sent via the (mock) Composio Slack toolkit.
    const slack = h.ctx.integrations.history().filter((n) => n.via === "slack");
    expect(slack.some((n) => n.text.includes("complete"))).toBe(true);
  });

  it("escalates to the human PM when a task keeps failing", async () => {
    const project = await system.orchestrator.createProject({
      name: "Risky",
      clientName: "Beta",
      brief: "Ship the thing.",
    });

    // Inject a poison task that always fails.
    const sprints = await h.store.repositories.sprints.listByProject(project.id);
    await h.store.repositories.tasks.insert({
      id: "poison",
      projectId: project.id,
      sprintId: sprints[0]!.id,
      title: "Impossible task",
      description: "",
      assignedAgentId: "worker-1",
      status: "todo",
      tags: ["force:error"],
      result: null,
      attempts: 0,
      createdAt: h.clock().toISOString(),
      updatedAt: h.clock().toISOString(),
    });

    const summary = await system.orchestrator.run(project.id);

    expect(summary.status).toBe("blocked");
    expect(summary.blocked).toBeGreaterThanOrEqual(1);
    expect(summary.escalations).toBeGreaterThanOrEqual(1);

    const poison = await h.store.repositories.tasks.get("poison");
    expect(poison?.status).toBe("blocked");

    const slack = h.ctx.integrations.history().filter((n) => n.via === "slack");
    expect(slack.some((n) => n.text.includes("Retries exhausted"))).toBe(true);

    const obs = await h.store.repositories.observations.listByProject(project.id);
    expect(obs.some((o) => o.type === "escalation")).toBe(true);
  });

  it("acts as tiebreaker and escalates ambiguous ties", async () => {
    const project = await system.orchestrator.createProject({
      name: "Decide",
      clientName: "Gamma",
      brief: "Pick an approach.",
    });

    const clear = await system.orchestrator.resolveConflict(
      project.id,
      "Which database?",
      ["SQL", "MongoDB document store"],
    );
    expect(clear.escalated).toBe(false);
    expect(clear.chosen).toBe("MongoDB document store");

    const ambiguous = await system.orchestrator.resolveConflict(
      project.id,
      "Coin flip?",
      ["aaa", "bbb"],
    );
    expect(ambiguous.escalated).toBe(true);
  });

  it("re-runs only non-done tasks after resetting blocked ones", async () => {
    const project = await system.orchestrator.createProject({
      name: "Rerun",
      clientName: "Delta",
      brief: "Ship the thing.",
    });

    const summary = await system.orchestrator.run(project.id);
    expect(summary.status).toBe("completed");

    const tasks = await h.store.repositories.tasks.listByProject(project.id);
    const target = tasks[0]!;
    await h.store.repositories.tasks.update(target.id, {
      status: "blocked",
      result: "Needs human",
    });

    const reset = await system.orchestrator.prepareForRerun(project.id);
    expect(reset).toBe(1);

    const blocked = await h.store.repositories.tasks.get(target.id);
    expect(blocked?.status).toBe("todo");

    const rerun = await system.orchestrator.run(project.id);
    expect(rerun.status).toBe("completed");
    expect(rerun.done).toBe(tasks.length);
  });

  it("uses severity-specific escalation alerts", async () => {
    const project = await system.orchestrator.createProject({
      name: "Severity",
      clientName: "Epsilon",
      brief: "Ship the thing.",
    });

    const sprints = await h.store.repositories.sprints.listByProject(project.id);

    await h.store.repositories.tasks.insert({
      id: "critical-task",
      projectId: project.id,
      sprintId: sprints[0]!.id,
      title: "Critical op",
      description: "",
      assignedAgentId: "worker-1",
      status: "todo",
      tags: ["force:critical"],
      result: null,
      attempts: 0,
      createdAt: h.clock().toISOString(),
      updatedAt: h.clock().toISOString(),
    });

    await system.orchestrator.run(project.id);

    const slack = h.ctx.integrations
      .history(project.id)
      .filter((n) => n.via === "slack");
    expect(slack.some((n) => n.text.includes("CRITICAL"))).toBe(true);
  });
});
