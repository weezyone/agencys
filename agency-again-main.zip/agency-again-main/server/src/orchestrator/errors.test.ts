import { describe, expect, it, vi } from "vitest";
import { classifyError, withRetry } from "./errors.js";

describe("classifyError", () => {
  it("detects transient errors", () => {
    expect(classifyError(new Error("Request timeout"))).toBe("transient");
    expect(classifyError(new Error("429 rate limit exceeded"))).toBe("transient");
    expect(classifyError("service temporarily unavailable")).toBe("transient");
  });

  it("detects critical errors", () => {
    expect(classifyError(new Error("out of budget"))).toBe("critical");
    expect(classifyError(new Error("401 unauthorized"))).toBe("critical");
    expect(classifyError(new Error("security violation"))).toBe("critical");
  });

  it("defaults to permanent", () => {
    expect(classifyError(new Error("bad input"))).toBe("permanent");
  });
});

describe("withRetry", () => {
  const noSleep = () => Promise.resolve();

  it("returns immediately on success", async () => {
    const fn = vi.fn(async () => "ok");
    const result = await withRetry(fn, { sleep: noSleep });
    expect(result).toBe("ok");
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it("retries transient errors up to the limit then succeeds", async () => {
    let calls = 0;
    const fn = vi.fn(async (attempt: number) => {
      calls = attempt;
      if (attempt < 3) throw new Error("timeout");
      return "recovered";
    });
    const result = await withRetry(fn, {
      retries: 3,
      sleep: noSleep,
      random: () => 0.5,
    });
    expect(result).toBe("recovered");
    expect(calls).toBe(3);
  });

  it("does not retry permanent errors", async () => {
    const fn = vi.fn(async () => {
      throw new Error("invalid argument");
    });
    await expect(withRetry(fn, { sleep: noSleep })).rejects.toThrow(/invalid/);
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it("does not retry critical errors", async () => {
    const fn = vi.fn(async () => {
      throw new Error("security breach detected");
    });
    await expect(withRetry(fn, { sleep: noSleep })).rejects.toThrow(/security/);
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it("gives up after exhausting retries on persistent transient errors", async () => {
    const onRetry = vi.fn();
    const fn = vi.fn(async () => {
      throw new Error("timeout");
    });
    await expect(
      withRetry(fn, { retries: 2, sleep: noSleep, onRetry, random: () => 0 }),
    ).rejects.toThrow(/timeout/);
    expect(fn).toHaveBeenCalledTimes(3); // 1 initial + 2 retries
    expect(onRetry).toHaveBeenCalledTimes(2);
  });
});
