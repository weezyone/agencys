import { createStore, type Store } from "../db/store.js";
import { createMockLlm } from "../llm/mockLlm.js";
import { createMockComposio } from "../integrations/mockComposio.js";
import { createMemory } from "../memory/memory.js";
import { createMessageBus } from "../agents/messageBus.js";
import type { AgentContext } from "../agents/baseAgent.js";
import { sequentialIdFactory } from "../util/id.js";
import type { Clock, IdFactory } from "../domain/types.js";

export interface TestHarness {
  store: Store;
  ctx: AgentContext;
  ids: IdFactory;
  clock: Clock;
  close: () => Promise<void>;
}

/**
 * Wire a full agent context backed by a real (ephemeral) MongoDB and the
 * deterministic mock adapters. Ids and the clock are deterministic.
 */
export async function makeTestHarness(): Promise<TestHarness> {
  const store = await createStore();
  const ids = sequentialIdFactory();
  let tick = 0;
  const clock: Clock = () => new Date(1_700_000_000_000 + tick++ * 1000);

  const ctx: AgentContext = {
    llm: createMockLlm(),
    integrations: createMockComposio(clock),
    memory: createMemory(store.repositories.observations, ids, clock),
    bus: createMessageBus(store.repositories.messages, ids, clock),
    agents: store.repositories.agents,
    clock,
  };

  return {
    store,
    ctx,
    ids,
    clock,
    close: () => store.close(),
  };
}
