import type { Task } from "../domain/types.js";
import type { ReviewResult } from "../llm/types.js";
import { BaseAgent } from "./baseAgent.js";

/** Reviews a worker's output against acceptance criteria. */
export class ReviewerAgent extends BaseAgent {
  async review(task: Task, output: string): Promise<ReviewResult> {
    await this.setState("busy");
    try {
      const result = await this.ctx.llm.review(task, output);
      await this.remember(
        task.projectId,
        "decision",
        `Review of "${task.title}": ${result.approved ? "approved" : "rework"} - ${result.feedback}`,
      );
      return result;
    } finally {
      await this.setState("idle");
    }
  }
}
