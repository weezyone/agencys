import type { Project } from "../domain/types.js";
import type { PlanResult } from "../llm/types.js";
import { BaseAgent } from "./baseAgent.js";

/** Breaks a client brief into a structured plan of sprints and tasks. */
export class PlannerAgent extends BaseAgent {
  async plan(project: Project): Promise<PlanResult> {
    await this.setState("busy");
    try {
      const result = await this.ctx.llm.plan(project.clientName, project.brief);
      const taskCount = result.sprints.reduce(
        (sum, s) => sum + s.tasks.length,
        0,
      );
      await this.remember(
        project.id,
        "decision",
        `Planned ${result.sprints.length} sprints / ${taskCount} tasks for ${project.clientName}.`,
      );
      await this.send({
        projectId: project.id,
        to: "broadcast",
        kind: "plan.ready",
        payload: { sprints: result.sprints.length, tasks: taskCount },
      });
      return result;
    } finally {
      await this.setState("idle");
    }
  }
}
