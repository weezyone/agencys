import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { makeTestHarness, type TestHarness } from "../__testutils__/context.js";
import { WorkerAgent } from "./workerAgent.js";
import { BROADCAST } from "./messageBus.js";
import type { Task } from "../domain/types.js";

const makeTask = (overrides: Partial<Task>): Task => ({
  id: "t1",
  projectId: "p1",
  sprintId: "s1",
  title: "Sample task",
  description: "",
  assignedAgentId: "w1",
  status: "todo",
  tags: [],
  result: null,
  attempts: 0,
  createdAt: "",
  updatedAt: "",
  ...overrides,
});

describe("message bus + memory", () => {
  let h: TestHarness;
  beforeEach(async () => {
    h = await makeTestHarness();
  });
  afterEach(async () => {
    await h.close();
  });

  it("delivers direct and broadcast messages and persists them", async () => {
    const received: string[] = [];
    h.ctx.bus.on("orchestrator", (m) => received.push(`direct:${m.kind}`));
    h.ctx.bus.on(BROADCAST, (m) => received.push(`bcast:${m.kind}`));

    await h.ctx.bus.send({
      projectId: "p1",
      from: "w1",
      to: "orchestrator",
      kind: "task.completed",
    });
    await h.ctx.bus.send({
      projectId: "p1",
      from: "planner",
      to: BROADCAST,
      kind: "plan.ready",
    });

    // direct message also reaches broadcast subscribers
    expect(received).toContain("direct:task.completed");
    expect(received).toContain("bcast:task.completed");
    expect(received).toContain("bcast:plan.ready");

    const history = await h.ctx.bus.history("p1");
    expect(history).toHaveLength(2);
  });

  it("records and recalls observations in chronological order", async () => {
    await h.ctx.memory.record("p1", "a1", "decision", "first");
    await h.ctx.memory.record("p1", "a1", "event", "second");
    const recall = await h.ctx.memory.recall("p1");
    expect(recall[0]).toContain("first");
    expect(recall[1]).toContain("second");
  });
});

describe("WorkerAgent", () => {
  let h: TestHarness;
  beforeEach(async () => {
    h = await makeTestHarness();
  });
  afterEach(async () => {
    await h.close();
  });

  const buildWorker = () =>
    new WorkerAgent(
      { id: "w1", name: "Worker One", role: "worker", capabilities: ["build"] },
      h.ctx,
    );

  it("completes a normal task and emits task.completed", async () => {
    const worker = buildWorker();
    await worker.register();
    const events: string[] = [];
    h.ctx.bus.on("orchestrator", (m) => events.push(m.kind));

    const outcome = await worker.executeTask(makeTask({}), { sleep: async () => {} });
    expect(outcome.ok).toBe(true);
    if (outcome.ok) expect(outcome.output).toContain("Completed");
    expect(events).toContain("task.completed");
    expect((await h.ctx.agents.get("w1"))?.state).toBe("idle");
  });

  it("recovers from a flaky task within the retry budget", async () => {
    const worker = buildWorker();
    await worker.register();
    const outcome = await worker.executeTask(makeTask({ tags: ["flaky:2"] }), {
      retries: 3,
      sleep: async () => {},
    });
    expect(outcome.ok).toBe(true);
    if (outcome.ok) expect(outcome.attempts).toBe(2);
  });

  it("fails and flags error state when a task keeps failing", async () => {
    const worker = buildWorker();
    await worker.register();
    const failures: string[] = [];
    h.ctx.bus.on("orchestrator", (m) => {
      if (m.kind === "task.failed") failures.push(String(m.payload.severity));
    });

    const outcome = await worker.executeTask(makeTask({ tags: ["force:error"] }), {
      retries: 2,
      sleep: async () => {},
    });
    expect(outcome.ok).toBe(false);
    if (!outcome.ok) expect(outcome.severity).toBe("transient");
    expect(failures).toContain("transient");
    expect((await h.ctx.agents.get("w1"))?.state).toBe("error");
  });
});
