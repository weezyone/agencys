import type { Agent, AgentRole, Clock } from "../domain/types.js";
import type { AgentRepository } from "../db/repositories.js";
import type { LlmClient } from "../llm/types.js";
import type { IntegrationClient } from "../integrations/types.js";
import type { Memory } from "../memory/memory.js";
import type { MessageBus, MessageHandler, OutboundMessage } from "./messageBus.js";

export interface AgentContext {
  llm: LlmClient;
  integrations: IntegrationClient;
  memory: Memory;
  bus: MessageBus;
  agents: AgentRepository;
  clock: Clock;
}

export interface AgentConfig {
  id: string;
  name: string;
  role: AgentRole;
  capabilities: string[];
}

/**
 * Shared functionality for every agent: identity/heartbeat, access to the LLM
 * and Composio tools, observational memory, and inter-agent messaging. Concrete
 * agents (Planner/Worker/Reviewer/Orchestrator) extend this.
 */
export abstract class BaseAgent {
  readonly id: string;
  readonly name: string;
  readonly role: AgentRole;
  readonly capabilities: string[];
  protected readonly ctx: AgentContext;

  constructor(config: AgentConfig, ctx: AgentContext) {
    this.id = config.id;
    this.name = config.name;
    this.role = config.role;
    this.capabilities = config.capabilities;
    this.ctx = ctx;
  }

  /** Persist this agent's metadata so the orchestrator can discover it. */
  async register(): Promise<Agent> {
    const agent: Agent = {
      id: this.id,
      name: this.name,
      role: this.role,
      capabilities: this.capabilities,
      state: "idle",
      lastHeartbeat: this.ctx.clock().toISOString(),
    };
    return this.ctx.agents.upsert(agent);
  }

  async setState(state: Agent["state"]): Promise<void> {
    await this.ctx.agents.update(this.id, {
      state,
      lastHeartbeat: this.ctx.clock().toISOString(),
    });
  }

  protected async remember(
    projectId: string,
    type: Parameters<Memory["record"]>[2],
    content: string,
  ): Promise<void> {
    await this.ctx.memory.record(projectId, this.id, type, content);
  }

  protected send(
    message: Omit<OutboundMessage, "from">,
  ): ReturnType<MessageBus["send"]> {
    return this.ctx.bus.send({ ...message, from: this.id });
  }

  onMessage(handler: MessageHandler): () => void {
    return this.ctx.bus.on(this.id, handler);
  }
}
