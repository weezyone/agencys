import type { Task } from "../domain/types.js";
import { classifyError, withRetry, type ErrorSeverity } from "../orchestrator/errors.js";
import { BaseAgent } from "./baseAgent.js";

export type WorkerOutcome =
  | { ok: true; output: string; attempts: number }
  | { ok: false; severity: ErrorSeverity; error: string; attempts: number };

export interface WorkerRetryConfig {
  retries?: number;
  baseDelayMs?: number;
  sleep?: (ms: number) => Promise<void>;
}

/**
 * Executes an individual task via the LLM/tools, wrapping the call in the
 * retry/backoff policy. Returns a structured outcome so the orchestrator can
 * decide whether to accept, retry, fall back, or escalate.
 */
export class WorkerAgent extends BaseAgent {
  async executeTask(
    task: Task,
    retryConfig: WorkerRetryConfig = {},
  ): Promise<WorkerOutcome> {
    await this.setState("busy");
    let attempts = 0;
    try {
      const memory = await this.ctx.memory.recall(task.projectId, 10);
      const output = await withRetry(
        async (attempt) => {
          attempts = attempt;
          // Reflect the current attempt into the task so downstream logic
          // (e.g. flaky-task simulation) is deterministic.
          return (await this.ctx.llm.execute({ ...task, attempts }, memory)).output;
        },
        {
          retries: retryConfig.retries ?? 2,
          baseDelayMs: retryConfig.baseDelayMs ?? 50,
          ...(retryConfig.sleep ? { sleep: retryConfig.sleep } : {}),
        },
      );

      await this.remember(
        task.projectId,
        "event",
        `Completed task "${task.title}" in ${attempts} attempt(s).`,
      );
      await this.send({
        projectId: task.projectId,
        to: "orchestrator",
        kind: "task.completed",
        payload: { taskId: task.id, attempts },
      });
      return { ok: true, output, attempts };
    } catch (error) {
      const severity = classifyError(error);
      const message = error instanceof Error ? error.message : String(error);
      await this.setState("error");
      await this.remember(
        task.projectId,
        "error",
        `Failed task "${task.title}" (${severity}): ${message}`,
      );
      await this.send({
        projectId: task.projectId,
        to: "orchestrator",
        kind: "task.failed",
        payload: { taskId: task.id, severity, error: message },
      });
      return { ok: false, severity, error: message, attempts };
    } finally {
      if ((await this.ctx.agents.get(this.id))?.state !== "error") {
        await this.setState("idle");
      }
    }
  }
}
