import type { AgentMessage, Clock, IdFactory } from "../domain/types.js";
import type { MessageRepository } from "../db/repositories.js";

export const BROADCAST = "broadcast";

export interface OutboundMessage {
  projectId: string;
  from: string;
  to: string;
  kind: string;
  payload?: Record<string, unknown>;
}

export type MessageHandler = (message: AgentMessage) => void;

export interface MessageBus {
  send(message: OutboundMessage): Promise<AgentMessage>;
  on(agentId: string, handler: MessageHandler): () => void;
  history(projectId: string, limit?: number): Promise<AgentMessage[]>;
}

/**
 * Lightweight message bus modelled on the Agent Messaging Protocol envelope
 * ({from, to, timestamp, payload}). Messages are persisted for auditability and
 * dispatched in-process to subscribers addressed directly or via broadcast.
 */
export function createMessageBus(
  repo: MessageRepository,
  idFactory: IdFactory,
  clock: Clock,
): MessageBus {
  const handlers = new Map<string, Set<MessageHandler>>();

  return {
    async send(message: OutboundMessage): Promise<AgentMessage> {
      const envelope: AgentMessage = {
        id: idFactory(),
        projectId: message.projectId,
        from: message.from,
        to: message.to,
        kind: message.kind,
        payload: message.payload ?? {},
        timestamp: clock().toISOString(),
      };
      await repo.insert(envelope);

      const targets = new Set<MessageHandler>();
      for (const h of handlers.get(message.to) ?? []) targets.add(h);
      if (message.to !== BROADCAST) {
        for (const h of handlers.get(BROADCAST) ?? []) targets.add(h);
      }
      for (const handler of targets) handler(envelope);

      return envelope;
    },

    on(agentId: string, handler: MessageHandler): () => void {
      const set = handlers.get(agentId) ?? new Set<MessageHandler>();
      set.add(handler);
      handlers.set(agentId, set);
      return () => {
        set.delete(handler);
      };
    },

    history(projectId: string, limit?: number): Promise<AgentMessage[]> {
      return repo.listByProject(projectId, limit);
    },
  };
}
