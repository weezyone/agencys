import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { createStore, type Store } from "./store.js";
import type { Project, Task } from "../domain/types.js";

describe("MongoDB store + repositories", () => {
  let store: Store;

  beforeAll(async () => {
    store = await createStore();
  });

  afterAll(async () => {
    await store.close();
  });

  it("inserts and retrieves a project", async () => {
    const project: Project = {
      id: "p1",
      name: "Website Revamp",
      clientName: "Acme",
      brief: "Redesign marketing site",
      status: "planning",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await store.repositories.projects.insert(project);

    const fetched = await store.repositories.projects.get("p1");
    expect(fetched).not.toBeNull();
    expect(fetched?.name).toBe("Website Revamp");
    expect(fetched?.id).toBe("p1");
  });

  it("updates a project without clobbering the id", async () => {
    const updated = await store.repositories.projects.update("p1", {
      id: "hacked",
      status: "active",
    } as Partial<Project>);
    expect(updated?.id).toBe("p1");
    expect(updated?.status).toBe("active");
  });

  it("queries tasks by sprint and by agent", async () => {
    const base = {
      projectId: "p1",
      description: "",
      status: "todo",
      tags: [],
      result: null,
      attempts: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    } as const;

    const tasks: Task[] = [
      { ...base, id: "t1", sprintId: "s1", title: "A", assignedAgentId: "w1" },
      { ...base, id: "t2", sprintId: "s1", title: "B", assignedAgentId: "w2" },
      { ...base, id: "t3", sprintId: "s2", title: "C", assignedAgentId: "w1" },
    ];
    for (const t of tasks) await store.repositories.tasks.insert(t);

    const sprint1 = await store.repositories.tasks.listBySprint("s1");
    expect(sprint1.map((t) => t.id).sort()).toEqual(["t1", "t2"]);

    const worker1 = await store.repositories.tasks.listByAgent("w1");
    expect(worker1.map((t) => t.id).sort()).toEqual(["t1", "t3"]);
  });

  it("stores observations newest-first", async () => {
    await store.repositories.observations.insert({
      id: "o1",
      projectId: "p1",
      agentId: "orch",
      type: "decision",
      content: "first",
      timestamp: "2026-01-01T00:00:00.000Z",
    });
    await store.repositories.observations.insert({
      id: "o2",
      projectId: "p1",
      agentId: "orch",
      type: "decision",
      content: "second",
      timestamp: "2026-01-02T00:00:00.000Z",
    });
    const obs = await store.repositories.observations.listByProject("p1");
    expect(obs[0]?.content).toBe("second");
    expect(obs[1]?.content).toBe("first");
  });
});
