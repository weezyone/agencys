import type { Collection, Document } from "mongodb";
import type {
  Agent,
  AgentMessage,
  Observation,
  Project,
  Sprint,
  Task,
} from "../domain/types.js";

/**
 * Repository interfaces. Keeping these behind interfaces means the agent /
 * orchestration logic never depends on MongoDB directly and can be tested
 * against any backing store.
 */
export interface ProjectRepository {
  insert(project: Project): Promise<Project>;
  get(id: string): Promise<Project | null>;
  list(): Promise<Project[]>;
  update(id: string, patch: Partial<Project>): Promise<Project | null>;
}

export interface SprintRepository {
  insert(sprint: Sprint): Promise<Sprint>;
  listByProject(projectId: string): Promise<Sprint[]>;
  update(id: string, patch: Partial<Sprint>): Promise<Sprint | null>;
}

export interface TaskRepository {
  insert(task: Task): Promise<Task>;
  get(id: string): Promise<Task | null>;
  listByProject(projectId: string): Promise<Task[]>;
  listBySprint(sprintId: string): Promise<Task[]>;
  listByAgent(agentId: string): Promise<Task[]>;
  update(id: string, patch: Partial<Task>): Promise<Task | null>;
}

export interface AgentRepository {
  upsert(agent: Agent): Promise<Agent>;
  get(id: string): Promise<Agent | null>;
  list(): Promise<Agent[]>;
  update(id: string, patch: Partial<Agent>): Promise<Agent | null>;
}

export interface ObservationRepository {
  insert(observation: Observation): Promise<Observation>;
  listByProject(projectId: string, limit?: number): Promise<Observation[]>;
  listByAgent(agentId: string, limit?: number): Promise<Observation[]>;
}

export interface MessageRepository {
  insert(message: AgentMessage): Promise<AgentMessage>;
  listByProject(projectId: string, limit?: number): Promise<AgentMessage[]>;
}

export interface Repositories {
  projects: ProjectRepository;
  sprints: SprintRepository;
  tasks: TaskRepository;
  agents: AgentRepository;
  observations: ObservationRepository;
  messages: MessageRepository;
}

export type MongoDoc<T extends { id: string }> = Omit<T, "id"> & { _id: string };

function toDoc<T extends { id: string }>(entity: T): MongoDoc<T> {
  const { id, ...rest } = entity;
  return { _id: id, ...rest } as MongoDoc<T>;
}

function fromDoc<T extends { id: string }>(doc: Document | null): T | null {
  if (!doc) return null;
  const { _id, ...rest } = doc;
  return { id: _id, ...rest } as T;
}

function applyPatch<T extends { id: string }>(
  patch: Partial<T>,
): Partial<MongoDoc<T>> {
  // Never allow the primary key to be overwritten via patch.
  const { id: _ignored, ...rest } = patch as Partial<T> & { id?: string };
  return rest as Partial<MongoDoc<T>>;
}

export function mongoProjectRepository(
  collection: Collection<MongoDoc<Project>>,
): ProjectRepository {
  return {
    async insert(project) {
      await collection.insertOne(toDoc(project));
      return project;
    },
    async get(id) {
      return fromDoc<Project>(await collection.findOne({ _id: id }));
    },
    async list() {
      const docs = await collection.find().sort({ createdAt: -1 }).toArray();
      return docs.map((d) => fromDoc<Project>(d)!).filter(Boolean);
    },
    async update(id, patch) {
      await collection.updateOne({ _id: id }, { $set: applyPatch(patch) });
      return fromDoc<Project>(await collection.findOne({ _id: id }));
    },
  };
}

export function mongoSprintRepository(
  collection: Collection<MongoDoc<Sprint>>,
): SprintRepository {
  return {
    async insert(sprint) {
      await collection.insertOne(toDoc(sprint));
      return sprint;
    },
    async listByProject(projectId) {
      const docs = await collection
        .find({ projectId })
        .sort({ order: 1 })
        .toArray();
      return docs.map((d) => fromDoc<Sprint>(d)!);
    },
    async update(id, patch) {
      await collection.updateOne({ _id: id }, { $set: applyPatch(patch) });
      return fromDoc<Sprint>(await collection.findOne({ _id: id }));
    },
  };
}

export function mongoTaskRepository(
  collection: Collection<MongoDoc<Task>>,
): TaskRepository {
  return {
    async insert(task) {
      await collection.insertOne(toDoc(task));
      return task;
    },
    async get(id) {
      return fromDoc<Task>(await collection.findOne({ _id: id }));
    },
    async listByProject(projectId) {
      const docs = await collection
        .find({ projectId })
        .sort({ createdAt: 1 })
        .toArray();
      return docs.map((d) => fromDoc<Task>(d)!);
    },
    async listBySprint(sprintId) {
      const docs = await collection
        .find({ sprintId })
        .sort({ createdAt: 1 })
        .toArray();
      return docs.map((d) => fromDoc<Task>(d)!);
    },
    async listByAgent(agentId) {
      const docs = await collection
        .find({ assignedAgentId: agentId })
        .sort({ createdAt: 1 })
        .toArray();
      return docs.map((d) => fromDoc<Task>(d)!);
    },
    async update(id, patch) {
      await collection.updateOne({ _id: id }, { $set: applyPatch(patch) });
      return fromDoc<Task>(await collection.findOne({ _id: id }));
    },
  };
}

export function mongoAgentRepository(
  collection: Collection<MongoDoc<Agent>>,
): AgentRepository {
  return {
    async upsert(agent) {
      await collection.updateOne(
        { _id: agent.id },
        { $set: applyPatch(agent) },
        { upsert: true },
      );
      return agent;
    },
    async get(id) {
      return fromDoc<Agent>(await collection.findOne({ _id: id }));
    },
    async list() {
      const docs = await collection.find().sort({ role: 1 }).toArray();
      return docs.map((d) => fromDoc<Agent>(d)!);
    },
    async update(id, patch) {
      await collection.updateOne({ _id: id }, { $set: applyPatch(patch) });
      return fromDoc<Agent>(await collection.findOne({ _id: id }));
    },
  };
}

export function mongoObservationRepository(
  collection: Collection<MongoDoc<Observation>>,
): ObservationRepository {
  return {
    async insert(observation) {
      await collection.insertOne(toDoc(observation));
      return observation;
    },
    async listByProject(projectId, limit = 100) {
      const docs = await collection
        .find({ projectId })
        .sort({ timestamp: -1 })
        .limit(limit)
        .toArray();
      return docs.map((d) => fromDoc<Observation>(d)!);
    },
    async listByAgent(agentId, limit = 100) {
      const docs = await collection
        .find({ agentId })
        .sort({ timestamp: -1 })
        .limit(limit)
        .toArray();
      return docs.map((d) => fromDoc<Observation>(d)!);
    },
  };
}

export function mongoMessageRepository(
  collection: Collection<MongoDoc<AgentMessage>>,
): MessageRepository {
  return {
    async insert(message) {
      await collection.insertOne(toDoc(message));
      return message;
    },
    async listByProject(projectId, limit = 200) {
      const docs = await collection
        .find({ projectId })
        .sort({ timestamp: -1 })
        .limit(limit)
        .toArray();
      return docs.map((d) => fromDoc<AgentMessage>(d)!);
    },
  };
}
