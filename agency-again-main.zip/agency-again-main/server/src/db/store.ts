import { MongoClient } from "mongodb";
import {
  mongoAgentRepository,
  mongoMessageRepository,
  mongoObservationRepository,
  mongoProjectRepository,
  mongoSprintRepository,
  mongoTaskRepository,
  type MongoDoc,
  type Repositories,
} from "./repositories.js";
import type {
  Agent,
  AgentMessage,
  Observation,
  Project,
  Sprint,
  Task,
} from "../domain/types.js";

export interface Store {
  repositories: Repositories;
  close(): Promise<void>;
}

export interface StoreOptions {
  uri?: string | undefined;
  dbName?: string;
}

/**
 * Create a MongoDB-backed store.
 *
 * If `uri` is provided (e.g. process.env.MONGODB_URI) we connect to that real
 * MongoDB instance. Otherwise we spin up an ephemeral in-process MongoDB via
 * `mongodb-memory-server` so the app and tests run with zero external setup.
 */
export async function createStore(options: StoreOptions = {}): Promise<Store> {
  const dbName = options.dbName ?? "agency";
  let uri = options.uri;
  let stopMemoryServer: (() => Promise<void>) | undefined;

  if (!uri) {
    const { MongoMemoryServer } = await import("mongodb-memory-server");
    const mem = await MongoMemoryServer.create();
    uri = mem.getUri();
    stopMemoryServer = async () => {
      await mem.stop();
    };
  }

  const client = new MongoClient(uri);
  await client.connect();
  const db = client.db(dbName);

  const repositories: Repositories = {
    projects: mongoProjectRepository(
      db.collection<MongoDoc<Project>>("projects"),
    ),
    sprints: mongoSprintRepository(db.collection<MongoDoc<Sprint>>("sprints")),
    tasks: mongoTaskRepository(db.collection<MongoDoc<Task>>("tasks")),
    agents: mongoAgentRepository(db.collection<MongoDoc<Agent>>("agents")),
    observations: mongoObservationRepository(
      db.collection<MongoDoc<Observation>>("observations"),
    ),
    messages: mongoMessageRepository(
      db.collection<MongoDoc<AgentMessage>>("messages"),
    ),
  };

  // Indexes matching the most common access patterns from the design brief.
  await Promise.all([
    db.collection("sprints").createIndex({ projectId: 1, order: 1 }),
    db.collection("tasks").createIndex({ sprintId: 1 }),
    db.collection("tasks").createIndex({ assignedAgentId: 1 }),
    db.collection("tasks").createIndex({ projectId: 1 }),
    db.collection("observations").createIndex({ agentId: 1, timestamp: -1 }),
    db.collection("observations").createIndex({ projectId: 1, timestamp: -1 }),
    db.collection("messages").createIndex({ projectId: 1, timestamp: -1 }),
  ]);

  return {
    repositories,
    async close() {
      await client.close();
      if (stopMemoryServer) await stopMemoryServer();
    },
  };
}
