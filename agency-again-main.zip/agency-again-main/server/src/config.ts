export type LlmProvider = "mock" | "openai";

export interface AppConfig {
  port: number;
  mongoUri: string | undefined;
  workerCount: number;
  pmChannel: string;
  llmProvider: LlmProvider;
  openaiApiKey: string | undefined;
  composioApiKey: string | undefined;
}

export function loadConfig(env: NodeJS.ProcessEnv = process.env): AppConfig {
  const llmProvider = env.LLM_PROVIDER === "openai" ? "openai" : "mock";
  return {
    port: Number(env.PORT ?? 4000),
    mongoUri: env.MONGODB_URI,
    workerCount: Number(env.WORKER_COUNT ?? 3),
    pmChannel: env.PM_SLACK_CHANNEL ?? "#project-updates",
    llmProvider,
    openaiApiKey: env.OPENAI_API_KEY,
    composioApiKey: env.COMPOSIO_API_KEY,
  };
}
