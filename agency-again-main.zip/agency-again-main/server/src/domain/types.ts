/**
 * Core domain types for the Multi-Agent Project Manager.
 *
 * These mirror the MongoDB collections described in the design brief:
 * Projects, Sprints, Tasks, Agents, and Memory (Observations), plus the
 * AgentMessage envelope used for inter-agent communication.
 */

export type ProjectStatus = "planning" | "active" | "completed" | "blocked";
export type SprintStatus = "planned" | "active" | "completed";
export type TaskStatus = "todo" | "in_progress" | "blocked" | "review" | "done";
export type AgentRole = "orchestrator" | "planner" | "worker" | "reviewer";
export type AgentState = "idle" | "busy" | "error";

export interface Project {
  id: string;
  name: string;
  clientName: string;
  brief: string;
  status: ProjectStatus;
  createdAt: string;
  updatedAt: string;
}

export interface Sprint {
  id: string;
  projectId: string;
  name: string;
  goal: string;
  status: SprintStatus;
  order: number;
  createdAt: string;
}

export interface Task {
  id: string;
  projectId: string;
  sprintId: string;
  title: string;
  description: string;
  assignedAgentId: string | null;
  status: TaskStatus;
  tags: string[];
  result: string | null;
  attempts: number;
  createdAt: string;
  updatedAt: string;
}

export interface Agent {
  id: string;
  name: string;
  role: AgentRole;
  capabilities: string[];
  state: AgentState;
  lastHeartbeat: string;
}

/**
 * Observational memory: agents compress decisions/events into short dated
 * notes so long-running context stays cheap to store and recall.
 */
export type ObservationType = "decision" | "event" | "error" | "escalation";

export interface Observation {
  id: string;
  projectId: string;
  agentId: string;
  type: ObservationType;
  content: string;
  timestamp: string;
}

/**
 * Inter-agent message envelope. Inspired by the Agent Messaging Protocol:
 * every message carries `from`, `to`, `timestamp` and a `payload`.
 */
export interface AgentMessage {
  id: string;
  projectId: string;
  from: string;
  to: string; // agent id or "broadcast"
  kind: string;
  payload: Record<string, unknown>;
  timestamp: string;
}

export type Clock = () => Date;
export type IdFactory = () => string;
