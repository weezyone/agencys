import { loadConfig } from "./config.js";
import { createRuntime } from "./runtime.js";
import { createApiApp } from "./api/server.js";

async function main(): Promise<void> {
  const config = loadConfig();
  const runtime = await createRuntime(config);
  const app = createApiApp(runtime);

  const server = app.listen(config.port, () => {
    const mode = config.mongoUri ? "MONGODB_URI" : "in-memory MongoDB";
    console.log(
      `[agency] API listening on http://localhost:${config.port} (${mode}, ${config.workerCount} workers)`,
    );
  });

  const shutdown = async () => {
    server.close();
    await runtime.close();
    process.exit(0);
  };
  process.on("SIGINT", shutdown);
  process.on("SIGTERM", shutdown);
}

main().catch((error) => {
  console.error("[agency] failed to start", error);
  process.exit(1);
});
