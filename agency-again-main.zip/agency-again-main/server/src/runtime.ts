import { createStore, type Store } from "./db/store.js";
import { createLlmClient } from "./llm/factory.js";
import { createIntegrationClient } from "./integrations/factory.js";
import { createMemory } from "./memory/memory.js";
import { createMessageBus } from "./agents/messageBus.js";
import type { AgentContext } from "./agents/baseAgent.js";
import {
  createOrchestrationSystem,
  type OrchestrationSystem,
} from "./orchestrator/system.js";
import { randomId } from "./util/id.js";
import type { AppConfig } from "./config.js";
import type { IntegrationClient } from "./integrations/types.js";

export interface Runtime {
  store: Store;
  ctx: AgentContext;
  system: OrchestrationSystem;
  integrations: IntegrationClient;
  close(): Promise<void>;
}

/**
 * Assemble the running application: MongoDB store, adapters (deterministic
 * mocks by default so it runs offline), memory, message bus and the agent team.
 */
export async function createRuntime(config: AppConfig): Promise<Runtime> {
  const store = await createStore({ uri: config.mongoUri });
  const ids = () => randomId("");
  const clock = () => new Date();

  const integrations = createIntegrationClient(config, clock);
  const ctx: AgentContext = {
    llm: createLlmClient(config),
    integrations,
    memory: createMemory(store.repositories.observations, ids, clock),
    bus: createMessageBus(store.repositories.messages, ids, clock),
    agents: store.repositories.agents,
    clock,
  };

  const system = await createOrchestrationSystem(store.repositories, ctx, ids, {
    workerCount: config.workerCount,
    pmChannel: config.pmChannel,
    retry: { retries: 2, baseDelayMs: 25 },
  });

  return {
    store,
    ctx,
    system,
    integrations,
    close: () => store.close(),
  };
}
