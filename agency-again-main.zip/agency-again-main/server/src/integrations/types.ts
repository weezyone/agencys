/**
 * Integration gateway abstraction (Composio).
 *
 * Agents use this to reach real-world apps (Slack, Gmail, Linear, ...). The
 * default mock records notifications in memory so escalations and alerts are
 * observable in tests and the UI without any external credentials.
 */

export type NotificationChannelKind = "slack" | "email" | "log";

export interface Notification {
  via: NotificationChannelKind;
  target: string;
  text: string;
  timestamp: string;
  projectId?: string;
}

export interface IntegrationClient {
  readonly name: string;
  notify(
    via: NotificationChannelKind,
    target: string,
    text: string,
    projectId?: string,
  ): Promise<Notification>;
  /** Notifications sent so far (mock/testing/inspection). */
  history(projectId?: string): Notification[];
}
