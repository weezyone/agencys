import type { Clock } from "../domain/types.js";
import type {
  IntegrationClient,
  Notification,
  NotificationChannelKind,
} from "./types.js";

/**
 * Deterministic Composio stand-in. It emulates toolkits like
 * SLACK_SEND_MESSAGE / GMAIL_SEND_EMAIL by recording every notification so the
 * activity feed and escalation flows are fully observable offline.
 */
export function createMockComposio(
  clock: Clock = () => new Date(),
  name = "mock-composio",
): IntegrationClient {
  const sent: Notification[] = [];
  return {
    name,
    async notify(
      via: NotificationChannelKind,
      target: string,
      text: string,
      projectId?: string,
    ): Promise<Notification> {
      const notification: Notification = {
        via,
        target,
        text,
        timestamp: clock().toISOString(),
        ...(projectId ? { projectId } : {}),
      };
      sent.push(notification);
      return notification;
    },
    history(projectId?: string) {
      if (!projectId) return [...sent];
      return sent.filter((n) => n.projectId === projectId);
    },
  };
}
