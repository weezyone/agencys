import { describe, expect, it } from "vitest";
import { loadConfig } from "../config.js";
import { createIntegrationClient } from "./factory.js";

describe("integration factory", () => {
  it("defaults to the mock Composio client", () => {
    const client = createIntegrationClient(loadConfig({}));
    expect(client.name).toBe("mock-composio");
  });

  it("throws when COMPOSIO_API_KEY is set but real adapter is unavailable", () => {
    expect(() =>
      createIntegrationClient(
        loadConfig({ COMPOSIO_API_KEY: "test-key" }),
      ),
    ).toThrow(/not yet implemented/i);
  });
});
