import { describe, expect, it } from "vitest";
import { createMockComposio } from "./mockComposio.js";

describe("mock Composio integration", () => {
  it("records notifications with a fixed clock", async () => {
    const clock = () => new Date("2026-07-13T12:00:00.000Z");
    const composio = createMockComposio(clock);

    await composio.notify("slack", "#project-acme", "Heads up y'all");
    await composio.notify("email", "pm@acme.com", "Status update");

    const history = composio.history();
    expect(history).toHaveLength(2);
    expect(history[0]).toMatchObject({
      via: "slack",
      target: "#project-acme",
      text: "Heads up y'all",
      timestamp: "2026-07-13T12:00:00.000Z",
    });
    expect(history[1]?.via).toBe("email");
  });

  it("returns a defensive copy of history", async () => {
    const composio = createMockComposio();
    await composio.notify("log", "console", "hi");
    const first = composio.history();
    first.pop();
    expect(composio.history()).toHaveLength(1);
  });

  it("filters history by projectId", async () => {
    const composio = createMockComposio();
    await composio.notify("slack", "#a", "project A", "proj-a");
    await composio.notify("slack", "#b", "project B", "proj-b");
    expect(composio.history("proj-a")).toHaveLength(1);
    expect(composio.history("proj-a")[0]?.text).toBe("project A");
  });
});
