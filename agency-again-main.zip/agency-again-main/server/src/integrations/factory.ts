import type { AppConfig } from "../config.js";
import type { Clock } from "../domain/types.js";
import { createMockComposio } from "./mockComposio.js";
import type { IntegrationClient } from "./types.js";

/**
 * Select the Composio integration adapter from configuration. Without a
 * COMPOSIO_API_KEY the deterministic mock is used so escalations are
 * observable in tests and the UI without external credentials.
 */
export function createIntegrationClient(
  config: AppConfig,
  clock: Clock = () => new Date(),
): IntegrationClient {
  if (config.composioApiKey) {
    throw new Error(
      "Real Composio adapter is not yet implemented. " +
        "Unset COMPOSIO_API_KEY to use the offline mock.",
    );
  }
  return createMockComposio(clock);
}
