import { afterAll, beforeAll, describe, expect, it } from "vitest";
import request from "supertest";
import type { Express } from "express";
import { createRuntime, type Runtime } from "../runtime.js";
import { createApiApp } from "./server.js";

describe("API integration", () => {
  let runtime: Runtime;
  let app: Express;

  beforeAll(async () => {
    runtime = await createRuntime({
      port: 0,
      mongoUri: undefined,
      workerCount: 2,
      pmChannel: "#test",
      llmProvider: "mock",
      openaiApiKey: undefined,
      composioApiKey: undefined,
    });
    app = createApiApp(runtime);
  });

  afterAll(async () => {
    await runtime.close();
  });

  it("reports health", async () => {
    const res = await request(app).get("/api/health");
    expect(res.status).toBe(200);
    expect(res.body.ok).toBe(true);
  });

  it("registers the agent team", async () => {
    const res = await request(app).get("/api/agents");
    expect(res.status).toBe(200);
    const roles = res.body.map((a: { role: string }) => a.role);
    expect(roles).toContain("orchestrator");
    expect(roles).toContain("planner");
    expect(roles).toContain("reviewer");
    expect(roles.filter((r: string) => r === "worker").length).toBe(2);
  });

  it("validates the create-project payload", async () => {
    const res = await request(app).post("/api/projects").send({ name: "x" });
    expect(res.status).toBe(400);
  });

  it("creates, plans and runs a project end to end", async () => {
    const res = await request(app)
      .post("/api/projects")
      .send({
        name: "Acme Portal",
        clientName: "Acme",
        brief: "Build a MongoDB backend, Slack alerts and a React dashboard.",
      });
    expect(res.status).toBe(201);
    expect(res.body.summary.status).toBe("completed");
    const projectId = res.body.project.id as string;

    const board = await request(app).get(`/api/projects/${projectId}/board`);
    expect(board.status).toBe(200);
    expect(board.body.sprints.length).toBe(3);
    const allTasks = board.body.sprints.flatMap(
      (s: { tasks: unknown[] }) => s.tasks,
    );
    expect(allTasks.length).toBeGreaterThan(0);

    const feed = await request(app).get(`/api/projects/${projectId}/feed`);
    expect(feed.status).toBe(200);
    expect(feed.body.observations.length).toBeGreaterThan(0);
    expect(feed.body.notifications.length).toBeGreaterThan(0);
  });

  it("returns 404 for unknown projects", async () => {
    const res = await request(app).get("/api/projects/nope/board");
    expect(res.status).toBe(404);
  });

  it("re-runs a project after resetting blocked tasks", async () => {
    const created = await request(app)
      .post("/api/projects")
      .send({
        name: "Rerun Test",
        clientName: "Acme",
        brief: "Ship the thing.",
      });
    const projectId = created.body.project.id as string;

    const sprints = await request(app).get(`/api/projects/${projectId}/board`);
    const firstTask = sprints.body.sprints[0]!.tasks[0]!;
    await runtime.store.repositories.tasks.update(firstTask.id, {
      status: "blocked",
      result: "Simulated failure",
    });

    const rerun = await request(app).post(`/api/projects/${projectId}/rerun`);
    expect(rerun.status).toBe(200);
    expect(rerun.body.reset).toBe(1);
    expect(rerun.body.summary.status).toBe("completed");
  });
});
