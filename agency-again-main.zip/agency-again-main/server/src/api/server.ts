import express, { type Express, type Request, type Response } from "express";
import cors from "cors";
import { z } from "zod";
import type { Runtime } from "../runtime.js";
import type { Sprint, Task } from "../domain/types.js";

const createProjectSchema = z.object({
  name: z.string().min(1),
  clientName: z.string().min(1),
  brief: z.string().min(1),
});

interface BoardSprint extends Sprint {
  tasks: Task[];
}

/** Build the Express app around a live runtime. */
export function createApiApp(runtime: Runtime): Express {
  const app = express();
  app.use(cors());
  app.use(express.json());

  const { repositories } = runtime.store;

  app.get("/api/health", (_req: Request, res: Response) => {
    res.json({ ok: true });
  });

  app.get("/api/agents", async (_req, res) => {
    res.json(await repositories.agents.list());
  });

  app.get("/api/projects", async (_req, res) => {
    res.json(await repositories.projects.list());
  });

  app.post("/api/projects", async (req, res) => {
    const parsed = createProjectSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.flatten() });
      return;
    }
    const result = await runtime.system.orchestrator.planAndRun(parsed.data);
    res.status(201).json(result);
  });

  app.get("/api/projects/:id", async (req, res) => {
    const project = await repositories.projects.get(req.params.id);
    if (!project) {
      res.status(404).json({ error: "Project not found" });
      return;
    }
    res.json(project);
  });

  app.get("/api/projects/:id/board", async (req, res) => {
    const project = await repositories.projects.get(req.params.id);
    if (!project) {
      res.status(404).json({ error: "Project not found" });
      return;
    }
    const sprints = await repositories.sprints.listByProject(project.id);
    const board: BoardSprint[] = [];
    for (const sprint of sprints) {
      const tasks = await repositories.tasks.listBySprint(sprint.id);
      board.push({ ...sprint, tasks });
    }
    res.json({ project, sprints: board });
  });

  app.get("/api/projects/:id/feed", async (req, res) => {
    const project = await repositories.projects.get(req.params.id);
    if (!project) {
      res.status(404).json({ error: "Project not found" });
      return;
    }
    const [observations, messages] = await Promise.all([
      repositories.observations.listByProject(project.id),
      repositories.messages.listByProject(project.id),
    ]);
    res.json({
      observations,
      messages,
      notifications: runtime.integrations.history(project.id),
    });
  });

  app.post("/api/projects/:id/rerun", async (req, res) => {
    const project = await repositories.projects.get(req.params.id);
    if (!project) {
      res.status(404).json({ error: "Project not found" });
      return;
    }
    const reset = await runtime.system.orchestrator.prepareForRerun(project.id);
    const summary = await runtime.system.orchestrator.run(project.id);
    res.json({ reset, summary });
  });

  return app;
}
