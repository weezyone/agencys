import type {
  Clock,
  IdFactory,
  Observation,
  ObservationType,
} from "../domain/types.js";
import type { ObservationRepository } from "../db/repositories.js";

export interface Memory {
  record(
    projectId: string,
    agentId: string,
    type: ObservationType,
    content: string,
  ): Promise<Observation>;
  recall(projectId: string, limit?: number): Promise<string[]>;
}

/**
 * Observational memory: agents compress decisions/events into short dated notes
 * (stored as documents) so long-running context stays cheap to store and recall
 * without vector databases.
 */
export function createMemory(
  repo: ObservationRepository,
  idFactory: IdFactory,
  clock: Clock,
): Memory {
  return {
    async record(projectId, agentId, type, content) {
      const observation: Observation = {
        id: idFactory(),
        projectId,
        agentId,
        type,
        content,
        timestamp: clock().toISOString(),
      };
      return repo.insert(observation);
    },
    async recall(projectId, limit = 20) {
      const observations = await repo.listByProject(projectId, limit);
      // Return oldest-first so the LLM reads memory in chronological order.
      return observations
        .slice()
        .reverse()
        .map((o) => `[${o.timestamp}] (${o.type}) ${o.content}`);
    },
  };
}
