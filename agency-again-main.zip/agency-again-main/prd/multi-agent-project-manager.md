# Multi-Agent Project Manager — Product Requirements

## Overview

A Maestro-style orchestrator breaks client briefs into projects → sprints → tasks, dispatches work to specialist agents (Planner / Worker / Reviewer), persists state in MongoDB, and escalates stuck work to a human PM via Composio integrations (Slack, Gmail, Linear).

## Goals

1. Automate project planning and task execution with multi-agent orchestration.
2. Persist projects, tasks, agent state, and observational memory in MongoDB.
3. Notify humans via Composio when agents disagree, fail, or complete milestones.
4. Provide a React dashboard to monitor boards, agents, and activity feeds.

## Architecture

| Layer | Technology | Role |
|-------|------------|------|
| Orchestration | Maestro (Orchestrator agent) | Plan, dispatch, review, escalate, tiebreak |
| Agents | Planner / Worker / Reviewer | Specialized task execution |
| Persistence | MongoDB | Projects, sprints, tasks, agents, observations, messages |
| Integrations | Composio | Slack/Gmail/Linear notifications |
| Frontend | React 19 + Vite + React Router 7 | Project board, agent team, activity feed |

## Data Model

### Collections

- **Projects** — `{ id, name, clientName, brief, status, createdAt, updatedAt }`
- **Sprints** — `{ id, projectId, name, goal, status, order, createdAt }`
- **Tasks** — `{ id, projectId, sprintId, title, description, assignedAgentId, status, tags, result, attempts, createdAt, updatedAt }`
- **Agents** — `{ id, name, role, capabilities, state, lastHeartbeat }`
- **Observations** — `{ id, projectId, agentId, type, content, timestamp }` (observational memory)
- **AgentMessages** — `{ id, projectId, from, to, kind, payload, timestamp }` (inter-agent comms)

### Status enums

- Project: `planning | active | completed | blocked`
- Task: `todo | in_progress | blocked | review | done`
- Agent: `idle | busy | error`

## Agent Orchestration

### Patterns

- **Sequential** — sprint-by-sprint, task-by-task execution (default).
- **Review loop** — Worker executes → Reviewer approves → one rework pass if rejected → escalate if still rejected.
- **Tiebreaker** — Orchestrator resolves conflicts via LLM; ambiguous ties escalate to human PM.

### Error handling

| Severity | Behavior |
|----------|----------|
| `transient` | Retry with exponential backoff + jitter |
| `permanent` | Fail fast, escalate with "needs human input" alert |
| `critical` | Fail fast, escalate immediately with "automation halted" alert |

### Escalation

Orchestrator sends Slack notification via Composio when:
- A task fails after retries
- Review rejects after rework
- Agents produce ambiguous tie results
- Project completes (success notification)

## API

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/health` | Health check |
| GET | `/api/agents` | List agent team |
| GET | `/api/projects` | List projects |
| POST | `/api/projects` | Create → plan → run from brief |
| GET | `/api/projects/:id/board` | Sprints + tasks |
| GET | `/api/projects/:id/feed` | Observations, messages, notifications |
| POST | `/api/projects/:id/rerun` | Reset blocked tasks and re-run |

## Frontend

- **Projects list** — all projects + agent team panel + new project form
- **Project detail** — sprint board, activity/memory feed, agent messages, Composio notifications, re-run button

## Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `4000` | API port |
| `MONGODB_URI` | _(ephemeral)_ | Real MongoDB URI |
| `WORKER_COUNT` | `3` | Worker agents |
| `PM_SLACK_CHANNEL` | `#project-updates` | Escalation channel |
| `LLM_PROVIDER` | `mock` | `mock` or `openai` |
| `OPENAI_API_KEY` | — | Required when `LLM_PROVIDER=openai` |
| `COMPOSIO_API_KEY` | — | When set, use Composio adapter (falls back to mock offline) |

## Acceptance Criteria

1. POST `/api/projects` with a brief creates a project, plans 3 sprints, executes all tasks, and returns a summary.
2. Tasks tagged `force:error` escalate to human PM with Slack notification and `blocked` status.
3. Tasks tagged `needs:review` are reworked once and complete after re-review.
4. Ambiguous tiebreaks escalate; clear ties are resolved by the orchestrator.
5. Re-run resets blocked tasks to `todo` and re-executes only non-done tasks.
6. Feed returns observations, agent messages, and project-scoped notifications.
7. Dashboard shows project board, agent team, activity feed, and agent messages.
8. All server tests pass with ephemeral MongoDB (no external services required by default).

## Out of Scope (v1)

- Parallel task execution within a sprint
- Full AMP cryptographic messaging
- Real-time WebSocket updates
- Human-in-the-loop resolution API (unblock/reassign)
- Drag-and-drop kanban
