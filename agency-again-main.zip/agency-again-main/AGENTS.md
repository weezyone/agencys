# AGENTS.md

## Project overview

Multi-Agent Project Manager. pnpm workspace with two packages:

- `server` — TypeScript + Express API, MongoDB persistence, and the agent
  orchestration engine (Planner / Worker / Reviewer + Maestro Orchestrator).
  LLM and Composio integrations are behind interfaces with deterministic mocks.
- `web` — React 19 + Vite dashboard (project board, agent team, activity feed).

See `README.md` for architecture, the env-var table, and the API reference.

## Standard commands

Commands are defined in the root and package `package.json` files — use those:

- Install: `pnpm install`
- Run both services (dev): `pnpm dev` (API `:4000`, web `:5173`)
- Run one service: `pnpm --filter @agency/server dev` / `pnpm --filter @agency/web dev`
- Test / lint / typecheck / build: `pnpm test` | `pnpm lint` | `pnpm typecheck` | `pnpm build`

## Cursor Cloud specific instructions

- **No external services or API keys are required.** By default the app runs
  fully offline: MongoDB is an in-process ephemeral server (`mongodb-memory-server`)
  and the LLM/Composio layers are deterministic mocks. Set `MONGODB_URI` only if
  you want to point at a real MongoDB.
- **MongoDB binary:** `pnpm install` runs the `mongodb-memory-server` postinstall
  which downloads and caches the `mongod` binary (pinned to `7.0.24` in the root
  `package.json` `config`). This requires network access on the first install of
  a fresh VM. Tests and the dev server reuse the cached binary. If the download
  is ever blocked, set `MONGODB_URI` to a reachable MongoDB and everything works
  unchanged.
- **pnpm build scripts:** `esbuild` and `mongodb-memory-server` are allow-listed
  via `pnpm.onlyBuiltDependencies` in the root `package.json`, so `pnpm install`
  runs their postinstall scripts non-interactively (do not run
  `pnpm approve-builds`).
- **Server tests use a real (ephemeral) MongoDB**, so each test file starts a
  `mongod` (~0.5–0.8s). This is expected; no mocking of the DB.
- **Vite dev server proxies `/api` to `http://localhost:4000`** (see
  `web/vite.config.ts`), so the API must be running for the web app to load data.
  Override the target with `VITE_API_TARGET`.
- **Deterministic testing hooks:** the mock LLM changes behaviour based on task
  tags — `force:error` (always fails → escalation), `flaky:N` (fails first N
  attempts), `needs:review` (reviewer rejects until reworked). Useful for
  exercising retry/escalation paths.
