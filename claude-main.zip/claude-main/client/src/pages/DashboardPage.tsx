import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '@/api/client';
import type { Artifact, PlatformStats, WorkflowInfo, WorkflowRun } from '@/api/types';
import { StatusBadge } from '@/components/StatusBadge';
import { WorkflowCard } from '@/components/WorkflowCard';

export const DashboardPage = () => {
  const [workflows, setWorkflows] = useState<WorkflowInfo[]>([]);
  const [runs, setRuns] = useState<WorkflowRun[]>([]);
  const [artifacts, setArtifacts] = useState<Artifact[]>([]);
  const [stats, setStats] = useState<PlatformStats | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      try {
        const [workflowList, runList, artifactList, platformStats] = await Promise.all([
          api.listWorkflows(),
          api.listRuns(),
          api.listArtifacts(),
          api.stats(),
        ]);
        setWorkflows(workflowList);
        setRuns(runList.slice(-5).reverse());
        setArtifacts(artifactList.slice(-5).reverse());
        setStats(platformStats);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load dashboard');
      }
    };

    void load();
  }, []);

  if (error) {
    return <p className="error-banner">Dashboard unavailable: {error}</p>;
  }

  return (
    <div className="page-grid">
      <section className="hero card">
        <h1>Agent-powered agency operations</h1>
        <p>
          Launch research, intake, and build-planning workflows with specialized agents and
          human approval gates.
        </p>
        {stats ? (
          <div className="stats-row">
            <div><strong>{stats.agents}</strong><span>Agents</span></div>
            <div><strong>{stats.workflows}</strong><span>Workflows</span></div>
            <div><strong>{stats.runs}</strong><span>Runs</span></div>
            <div><strong>{stats.artifacts}</strong><span>Artifacts</span></div>
            <div><strong>{stats.aiClient}</strong><span>AI client</span></div>
          </div>
        ) : null}
      </section>

      <section>
        <div className="section-header">
          <h2>Workflows</h2>
          <Link to="/workflows">View all</Link>
        </div>
        <div className="card-grid">
          {workflows.map((workflow) => (
            <WorkflowCard key={workflow.id} workflow={workflow} />
          ))}
        </div>
      </section>

      <section className="split-grid">
        <div>
          <div className="section-header">
            <h2>Recent runs</h2>
            <Link to="/runs">View all</Link>
          </div>
          <ul className="list-card">
            {runs.length === 0 ? <li className="muted">No workflow runs yet.</li> : null}
            {runs.map((run) => (
              <li key={run.id}>
                <Link to={`/runs/${run.id}`}>
                  <strong>{run.workflowName}</strong>
                </Link>
                <StatusBadge status={run.status} />
              </li>
            ))}
          </ul>
        </div>
        <div>
          <div className="section-header">
            <h2>Recent artifacts</h2>
            <Link to="/artifacts">View all</Link>
          </div>
          <ul className="list-card">
            {artifacts.length === 0 ? <li className="muted">No artifacts yet.</li> : null}
            {artifacts.map((artifact) => (
              <li key={artifact.id}>
                <Link to={`/artifacts/${artifact.id}`}>
                  <strong>{artifact.title}</strong>
                </Link>
                <span className="muted">{artifact.producedBy}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </div>
  );
};
