import { type FormEvent, useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api } from '@/api/client';
import type { WorkflowInfo } from '@/api/types';
import { buildWorkflowInput, getWorkflowFields } from '@/lib/workflow-forms';

export const LaunchWorkflowPage = () => {
  const { workflowId = '' } = useParams();
  const navigate = useNavigate();
  const [workflow, setWorkflow] = useState<WorkflowInfo | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    api
      .listWorkflows()
      .then((items) => setWorkflow(items.find((item) => item.id === workflowId) ?? null))
      .catch((err) => setError(err instanceof Error ? err.message : 'Failed to load workflow'));
  }, [workflowId]);

  const onSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitting(true);
    setError(null);

    try {
      const formData = new FormData(event.currentTarget);
      const input = buildWorkflowInput(workflowId, formData);
      const run = await api.startWorkflow(workflowId, input);
      navigate(`/runs/${run.id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to start workflow');
      setSubmitting(false);
    }
  };

  if (!workflow && !error) return <p>Loading workflow…</p>;
  if (!workflow) return <p className="error-banner">{error}</p>;

  const fields = getWorkflowFields(workflowId);

  return (
    <section className="form-page card">
      <h1>Launch {workflow.name}</h1>
      <p className="muted">{workflow.description}</p>
      <form onSubmit={onSubmit} className="stack-form">
        {fields.map((field) =>
          field.type === 'textarea' ? (
            <label key={field.name}>
              {field.label}
              <textarea name={field.name} rows={4} placeholder={field.placeholder} />
            </label>
          ) : (
            <label key={field.name}>
              {field.label}
              <input name={field.name} type="text" placeholder={field.placeholder} />
            </label>
          ),
        )}
        {error ? <p className="error-banner">{error}</p> : null}
        <button className="button button-primary" type="submit" disabled={submitting}>
          {submitting ? 'Starting…' : 'Start workflow'}
        </button>
      </form>
    </section>
  );
};
