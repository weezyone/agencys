import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '@/api/client';
import type { WorkflowRun } from '@/api/types';
import { StatusBadge } from '@/components/StatusBadge';

export const RunsPage = () => {
  const [runs, setRuns] = useState<WorkflowRun[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api
      .listRuns()
      .then((items) => setRuns([...items].reverse()))
      .catch((err) => setError(err instanceof Error ? err.message : 'Failed to load runs'));
  }, []);

  if (error) return <p className="error-banner">{error}</p>;

  return (
    <section>
      <h1>Workflow runs</h1>
      <ul className="list-card">
        {runs.length === 0 ? <li className="muted">No runs yet. Launch a workflow to begin.</li> : null}
        {runs.map((run) => (
          <li key={run.id}>
            <div>
              <Link to={`/runs/${run.id}`}>
                <strong>{run.workflowName}</strong>
              </Link>
              <p className="muted">{new Date(run.createdAt).toLocaleString()}</p>
            </div>
            <StatusBadge status={run.status} />
          </li>
        ))}
      </ul>
    </section>
  );
};
