import { useEffect, useState } from 'react';
import { api } from '@/api/client';
import type { WorkflowInfo } from '@/api/types';
import { WorkflowCard } from '@/components/WorkflowCard';

export const WorkflowsPage = () => {
  const [workflows, setWorkflows] = useState<WorkflowInfo[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api
      .listWorkflows()
      .then(setWorkflows)
      .catch((err) => setError(err instanceof Error ? err.message : 'Failed to load workflows'));
  }, []);

  if (error) return <p className="error-banner">{error}</p>;

  return (
    <section>
      <h1>Workflows</h1>
      <p className="muted">Choose a workflow to launch with guided inputs.</p>
      <div className="card-grid">
        {workflows.map((workflow) => (
          <WorkflowCard key={workflow.id} workflow={workflow} />
        ))}
      </div>
    </section>
  );
};
