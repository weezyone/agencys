import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api } from '@/api/client';
import { StepTimeline } from '@/components/StepTimeline';
import { StatusBadge } from '@/components/StatusBadge';
import { usePollRun } from '@/hooks/usePollRun';

export const RunDetailPage = () => {
  const { runId = '' } = useParams();
  const { run, error, loading, refresh } = usePollRun({ api, runId });
  const [actionError, setActionError] = useState<string | null>(null);
  const [acting, setActing] = useState(false);

  const reviewStep = run?.steps.find((step) => step.status === 'needs_review');

  const handleApprove = async () => {
    if (!reviewStep) return;
    setActing(true);
    setActionError(null);
    try {
      await api.approveStep(runId, reviewStep.step.id);
      await refresh();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Approval failed');
    } finally {
      setActing(false);
    }
  };

  const handleReject = async () => {
    if (!reviewStep) return;
    const reason = window.prompt('Reason for rejection?') ?? 'Rejected by reviewer';
    setActing(true);
    setActionError(null);
    try {
      await api.rejectStep(runId, reviewStep.step.id, reason);
      await refresh();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Rejection failed');
    } finally {
      setActing(false);
    }
  };

  if (loading) return <p>Loading run…</p>;
  if (error || !run) return <p className="error-banner">{error ?? 'Run not found'}</p>;

  return (
    <section className="page-grid">
      <header className="card run-header">
        <div>
          <p className="muted">
            <Link to="/runs">Runs</Link> / {run.id}
          </p>
          <h1>{run.workflowName}</h1>
        </div>
        <StatusBadge status={run.status} />
      </header>

      {reviewStep ? (
        <section className="card review-panel">
          <h2>Approval required</h2>
          <p>
            Step <strong>{reviewStep.step.title}</strong> produced an artifact and is waiting for
            review before the workflow can continue.
          </p>
          {reviewStep.artifactId ? (
            <p>
              <Link to={`/artifacts/${reviewStep.artifactId}`}>Review artifact</Link>
            </p>
          ) : null}
          <div className="button-row">
            <button className="button button-primary" onClick={handleApprove} disabled={acting}>
              Approve
            </button>
            <button className="button button-danger" onClick={handleReject} disabled={acting}>
              Reject
            </button>
          </div>
          {actionError ? <p className="error-banner">{actionError}</p> : null}
        </section>
      ) : null}

      <section className="card">
        <h2>Steps</h2>
        <StepTimeline steps={run.steps} />
      </section>
    </section>
  );
};
