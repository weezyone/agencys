import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api } from '@/api/client';
import type { Artifact } from '@/api/types';

export const ArtifactDetailPage = () => {
  const { artifactId = '' } = useParams();
  const [artifact, setArtifact] = useState<Artifact | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api
      .getArtifact(artifactId)
      .then(setArtifact)
      .catch((err) => setError(err instanceof Error ? err.message : 'Failed to load artifact'));
  }, [artifactId]);

  if (!artifact && !error) return <p>Loading artifact…</p>;
  if (!artifact) return <p className="error-banner">{error}</p>;

  return (
    <section className="page-grid">
      <header className="card">
        <p className="muted">
          <Link to="/artifacts">Artifacts</Link> / {artifact.id}
        </p>
        <h1>{artifact.title}</h1>
        <p className="muted">
          Produced by {artifact.producedBy} on {new Date(artifact.createdAt).toLocaleString()}
        </p>
        {artifact.workflowRunId ? (
          <p>
            <Link to={`/runs/${artifact.workflowRunId}`}>View workflow run</Link>
          </p>
        ) : null}
      </header>
      <section className="card">
        <h2>Content</h2>
        <pre className="artifact-json">{JSON.stringify(artifact.content, null, 2)}</pre>
      </section>
    </section>
  );
};
