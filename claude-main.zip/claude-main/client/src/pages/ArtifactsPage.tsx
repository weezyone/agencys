import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '@/api/client';
import type { Artifact } from '@/api/types';

export const ArtifactsPage = () => {
  const [artifacts, setArtifacts] = useState<Artifact[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api
      .listArtifacts()
      .then((items) => setArtifacts([...items].reverse()))
      .catch((err) => setError(err instanceof Error ? err.message : 'Failed to load artifacts'));
  }, []);

  if (error) return <p className="error-banner">{error}</p>;

  return (
    <section>
      <h1>Artifacts</h1>
      <ul className="list-card">
        {artifacts.length === 0 ? <li className="muted">No artifacts yet.</li> : null}
        {artifacts.map((artifact) => (
          <li key={artifact.id}>
            <div>
              <Link to={`/artifacts/${artifact.id}`}>
                <strong>{artifact.title}</strong>
              </Link>
              <p className="muted">
                {artifact.producedBy} · {new Date(artifact.createdAt).toLocaleString()}
              </p>
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
};
