export type StepStatus =
  | 'pending'
  | 'in_progress'
  | 'completed'
  | 'failed'
  | 'needs_review';

export type WorkflowRunStatus =
  | 'pending'
  | 'running'
  | 'needs_review'
  | 'completed'
  | 'failed';

export interface AgentInfo {
  type: string;
  label: string;
  description: string;
}

export interface WorkflowStepInfo {
  id: string;
  title: string;
  agentType: string;
  dependsOn: string[];
  requiresApproval: boolean;
}

export interface WorkflowInfo {
  id: string;
  name: string;
  description: string;
  steps: WorkflowStepInfo[];
}

export interface AgentRunResult {
  status: 'success' | 'failed';
  summary: string;
  output: Record<string, unknown>;
  questions?: string[];
  risks?: string[];
}

export interface WorkflowRunStep {
  step: WorkflowStepInfo;
  status: StepStatus;
  artifactId?: string;
  result?: AgentRunResult;
  startedAt?: string;
  completedAt?: string;
}

export interface WorkflowRun {
  id: string;
  workflowId: string;
  workflowName: string;
  projectId: string;
  input: Record<string, unknown>;
  status: WorkflowRunStatus;
  steps: WorkflowRunStep[];
  createdAt: string;
  startedAt?: string;
  completedAt?: string;
}

export interface Artifact {
  id: string;
  workflowRunId?: string;
  projectId: string;
  producedBy: string;
  stepId?: string;
  title: string;
  content: Record<string, unknown>;
  createdAt: string;
}

export interface PlatformStats {
  agents: number;
  workflows: number;
  runs: number;
  runsByStatus: Record<string, number>;
  artifacts: number;
  aiClient: string;
}

export interface ActivityMessage {
  id: string;
  from: string;
  to?: string;
  type: string;
  payload: Record<string, unknown>;
  timestamp: string;
}
