import type {
  ActivityMessage,
  AgentInfo,
  AgentRunResult,
  Artifact,
  PlatformStats,
  WorkflowInfo,
  WorkflowRun,
} from './types';

export interface ApiClientOptions {
  baseUrl?: string;
  fetchFn?: typeof fetch;
}

interface ApiErrorBody {
  error?: string;
}

const request = async <T>(
  fetchFn: typeof fetch,
  url: string,
  init?: RequestInit,
): Promise<T> => {
  const response = await fetchFn(url, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...(init?.headers ?? {}),
    },
  });

  const body = (await response.json().catch(() => ({}))) as T & ApiErrorBody;

  if (!response.ok) {
    throw new Error(body.error ?? `Request failed (${response.status})`);
  }

  return body;
};

export const createApiClient = ({ baseUrl = '', fetchFn = fetch }: ApiClientOptions = {}) => {
  const url = (path: string) => `${baseUrl}${path}`;

  return {
    health: () => request<{ status: string }>(fetchFn, url('/api/health')),

    stats: () => request<PlatformStats>(fetchFn, url('/api/stats')),

    listAgents: async () => {
      const data = await request<{ agents: AgentInfo[] }>(fetchFn, url('/api/agents'));
      return data.agents;
    },

    runAgent: async (type: string, instruction: string, input: Record<string, unknown> = {}) => {
      const data = await request<{ result: AgentRunResult }>(
        fetchFn,
        url(`/api/agents/${type}/run`),
        {
          method: 'POST',
          body: JSON.stringify({ instruction, input }),
        },
      );
      return data.result;
    },

    listWorkflows: async () => {
      const data = await request<{ workflows: WorkflowInfo[] }>(fetchFn, url('/api/workflows'));
      return data.workflows;
    },

    startWorkflow: async (id: string, input: Record<string, unknown> = {}) => {
      const data = await request<{ run: WorkflowRun }>(
        fetchFn,
        url(`/api/workflows/${id}/run`),
        {
          method: 'POST',
          body: JSON.stringify({ input }),
        },
      );
      return data.run;
    },

    listRuns: async () => {
      const data = await request<{ runs: WorkflowRun[] }>(fetchFn, url('/api/runs'));
      return data.runs;
    },

    getRun: async (runId: string) => {
      const data = await request<{ run: WorkflowRun }>(fetchFn, url(`/api/runs/${runId}`));
      return data.run;
    },

    approveStep: async (runId: string, stepId: string) => {
      const data = await request<{ run: WorkflowRun }>(
        fetchFn,
        url(`/api/runs/${runId}/steps/${stepId}/approve`),
        { method: 'POST', body: JSON.stringify({}) },
      );
      return data.run;
    },

    rejectStep: async (runId: string, stepId: string, reason?: string) => {
      const data = await request<{ run: WorkflowRun }>(
        fetchFn,
        url(`/api/runs/${runId}/steps/${stepId}/reject`),
        { method: 'POST', body: JSON.stringify({ reason }) },
      );
      return data.run;
    },

    listArtifacts: async (filter: { runId?: string; projectId?: string } = {}) => {
      const params = new URLSearchParams();
      if (filter.runId) params.set('runId', filter.runId);
      if (filter.projectId) params.set('projectId', filter.projectId);
      const query = params.toString();
      const data = await request<{ artifacts: Artifact[] }>(
        fetchFn,
        url(`/api/artifacts${query ? `?${query}` : ''}`),
      );
      return data.artifacts;
    },

    getArtifact: async (id: string) => {
      const data = await request<{ artifact: Artifact }>(fetchFn, url(`/api/artifacts/${id}`));
      return data.artifact;
    },

    recentActivity: async () => {
      const data = await request<{ activity: ActivityMessage[] }>(fetchFn, url('/api/activity'));
      return data.activity;
    },
  };
};

export type ApiClient = ReturnType<typeof createApiClient>;

export const api = createApiClient();
