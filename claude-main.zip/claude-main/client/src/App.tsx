import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { Layout } from '@/components/Layout';
import { ArtifactDetailPage } from '@/pages/ArtifactDetailPage';
import { ArtifactsPage } from '@/pages/ArtifactsPage';
import { DashboardPage } from '@/pages/DashboardPage';
import { LaunchWorkflowPage } from '@/pages/LaunchWorkflowPage';
import { RunDetailPage } from '@/pages/RunDetailPage';
import { RunsPage } from '@/pages/RunsPage';
import { WorkflowsPage } from '@/pages/WorkflowsPage';

export const App = () => (
  <BrowserRouter>
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<DashboardPage />} />
        <Route path="workflows" element={<WorkflowsPage />} />
        <Route path="workflows/:workflowId/launch" element={<LaunchWorkflowPage />} />
        <Route path="runs" element={<RunsPage />} />
        <Route path="runs/:runId" element={<RunDetailPage />} />
        <Route path="artifacts" element={<ArtifactsPage />} />
        <Route path="artifacts/:artifactId" element={<ArtifactDetailPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  </BrowserRouter>
);
