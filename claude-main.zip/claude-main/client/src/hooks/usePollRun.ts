import { useCallback, useEffect, useState } from 'react';
import type { WorkflowRun } from '@/api/types';
import type { ApiClient } from '@/api/client';

interface UsePollRunOptions {
  api: ApiClient;
  runId: string;
  intervalMs?: number;
  enabled?: boolean;
}

export const usePollRun = ({
  api,
  runId,
  intervalMs = 2000,
  enabled = true,
}: UsePollRunOptions) => {
  const [run, setRun] = useState<WorkflowRun | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    try {
      const next = await api.getRun(runId);
      setRun(next);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load run');
    } finally {
      setLoading(false);
    }
  }, [api, runId]);

  useEffect(() => {
    if (!enabled) return;
    void refresh();
  }, [enabled, refresh]);

  useEffect(() => {
    if (!enabled || !run) return;
    if (run.status !== 'running' && run.status !== 'pending') return;

    const timer = window.setInterval(() => {
      void refresh();
    }, intervalMs);

    return () => window.clearInterval(timer);
  }, [enabled, intervalMs, refresh, run]);

  return { run, error, loading, refresh };
};
