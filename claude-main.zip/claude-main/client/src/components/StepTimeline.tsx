import { Link } from 'react-router-dom';
import type { WorkflowRunStep } from '@/api/types';
import { StatusBadge } from './StatusBadge';

interface StepTimelineProps {
  steps: WorkflowRunStep[];
}

const formatAgent = (agentType: string) =>
  agentType
    .split('_')
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(' ');

export const StepTimeline = ({ steps }: StepTimelineProps) => (
  <ol className="step-timeline">
    {steps.map((entry) => (
      <li key={entry.step.id} className={`step-item step-${entry.status}`}>
        <div className="step-header">
          <strong>{entry.step.title}</strong>
          <StatusBadge status={entry.status} />
        </div>
        <p className="muted">{formatAgent(entry.step.agentType)}</p>
        {entry.result?.summary ? <p>{entry.result.summary}</p> : null}
        {entry.artifactId ? (
          <p>
            <Link to={`/artifacts/${entry.artifactId}`}>View artifact</Link>
          </p>
        ) : null}
      </li>
    ))}
  </ol>
);
