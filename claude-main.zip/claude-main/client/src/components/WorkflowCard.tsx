import { Link } from 'react-router-dom';
import type { WorkflowInfo } from '@/api/types';

interface WorkflowCardProps {
  workflow: WorkflowInfo;
}

export const WorkflowCard = ({ workflow }: WorkflowCardProps) => (
  <article className="card workflow-card">
    <header>
      <h3>{workflow.name}</h3>
      <p>{workflow.description}</p>
    </header>
    <footer>
      <span className="muted">{workflow.steps.length} steps</span>
      <Link className="button button-primary" to={`/workflows/${workflow.id}/launch`}>
        Launch
      </Link>
    </footer>
  </article>
);
