import type { StepStatus, WorkflowRunStatus } from '@/api/types';

const STATUS_LABELS: Record<StepStatus | WorkflowRunStatus, string> = {
  pending: 'Pending',
  in_progress: 'In progress',
  completed: 'Completed',
  failed: 'Failed',
  needs_review: 'Needs review',
  running: 'Running',
};

const STATUS_CLASS: Record<StepStatus | WorkflowRunStatus, string> = {
  pending: 'status-pending',
  in_progress: 'status-running',
  running: 'status-running',
  completed: 'status-completed',
  failed: 'status-failed',
  needs_review: 'status-review',
};

interface StatusBadgeProps {
  status: StepStatus | WorkflowRunStatus;
}

export const StatusBadge = ({ status }: StatusBadgeProps) => (
  <span className={`status-badge ${STATUS_CLASS[status]}`}>{STATUS_LABELS[status]}</span>
);
