import { Link, Outlet, useLocation } from 'react-router-dom';

const NAV = [
  { to: '/', label: 'Dashboard' },
  { to: '/workflows', label: 'Workflows' },
  { to: '/runs', label: 'Runs' },
  { to: '/artifacts', label: 'Artifacts' },
];

export const Layout = () => {
  const location = useLocation();

  return (
    <div className="app-shell">
      <header className="app-header">
        <div className="brand">
          <span className="brand-mark">AA</span>
          <div>
            <strong>Agency Agent Platform</strong>
            <p className="muted">V1 multi-agent workflow operations</p>
          </div>
        </div>
        <nav className="app-nav">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={location.pathname === item.to ? 'nav-link active' : 'nav-link'}
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </header>
      <main className="app-main">
        <Outlet />
      </main>
    </div>
  );
};
