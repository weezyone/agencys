type WorkflowField = {
  name: string;
  label: string;
  type?: 'text' | 'textarea';
  placeholder?: string;
};

const WORKFLOW_FIELDS: Record<string, WorkflowField[]> = {
  lead_to_outreach: [
    { name: 'leadName', label: 'Lead name' },
    { name: 'leadCompany', label: 'Company' },
    { name: 'websiteUrl', label: 'Website URL' },
    { name: 'role', label: 'Role / title' },
    { name: 'linkedInUrl', label: 'LinkedIn URL' },
    { name: 'notes', label: 'Notes', type: 'textarea' },
  ],
  intake_to_brief: [
    { name: 'clientName', label: 'Client name' },
    { name: 'goals', label: 'Goals', type: 'textarea' },
    { name: 'constraints', label: 'Constraints', type: 'textarea' },
    { name: 'targetAudience', label: 'Target audience' },
    { name: 'intakeNotes', label: 'Intake notes', type: 'textarea' },
  ],
  brief_to_build_plan: [
    { name: 'clientName', label: 'Client name' },
    { name: 'brief', label: 'Project brief', type: 'textarea' },
    { name: 'technicalConstraints', label: 'Technical constraints', type: 'textarea' },
  ],
};

export const getWorkflowFields = (workflowId: string): WorkflowField[] =>
  WORKFLOW_FIELDS[workflowId] ?? [{ name: 'notes', label: 'Notes', type: 'textarea' }];

export const buildWorkflowInput = (
  workflowId: string,
  formData: FormData,
): Record<string, unknown> => {
  const fields = getWorkflowFields(workflowId);
  return fields.reduce<Record<string, unknown>>((acc, field) => {
    const value = String(formData.get(field.name) ?? '').trim();
    if (value) acc[field.name] = value;
    return acc;
  }, {});
};
