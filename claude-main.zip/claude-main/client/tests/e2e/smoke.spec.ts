import { test, expect } from '@playwright/test';

test.describe('Agency Agent Platform smoke', () => {
  test('dashboard loads workflows and stats', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByRole('heading', { name: /agent-powered agency/i })).toBeVisible();
    await expect(page.getByText('Lead → Outreach')).toBeVisible();
    await expect(page.getByText('Intake → Project Brief')).toBeVisible();
    await expect(page.getByText('Brief → Build Plan')).toBeVisible();
  });

  test('launch lead→outreach, approve gate, complete run', async ({ page }) => {
    await page.goto('/workflows/lead_to_outreach/launch');
    await expect(page.getByRole('heading', { name: /launch lead → outreach/i })).toBeVisible();

    await page.getByLabel('Lead name').fill('Dana Rivera');
    await page.getByLabel('Company').fill('Nimbus Co');
    await page.getByRole('button', { name: /start workflow/i }).click();

    await expect(page).toHaveURL(/\/runs\//);
    await expect(page.getByRole('heading', { name: 'Lead → Outreach' })).toBeVisible();
    await expect(page.getByText('Approval required')).toBeVisible();
    await expect(page.getByText('Needs review').first()).toBeVisible();

    await page.getByRole('button', { name: 'Approve' }).click();
    await expect(page.getByText('Completed').first()).toBeVisible({ timeout: 15_000 });
    await expect(page.getByText('Approval required')).toHaveCount(0);
  });

  test('artifact from a run is viewable', async ({ page }) => {
    await page.goto('/workflows/lead_to_outreach/launch');
    await page.getByLabel('Lead name').fill('Alex Kim');
    await page.getByRole('button', { name: /start workflow/i }).click();
    await expect(page).toHaveURL(/\/runs\//);

    await page.getByRole('link', { name: 'View artifact' }).first().click();
    await expect(page).toHaveURL(/\/artifacts\//);
    await expect(page.getByRole('heading', { level: 2, name: 'Content' })).toBeVisible();
    await expect(page.locator('.artifact-json')).toContainText('{');
  });
});
