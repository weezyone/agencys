import { describe, it, expect, vi, beforeEach } from 'vitest';
import { createApiClient } from '@/api/client';

const jsonResponse = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });

describe('createApiClient', () => {
  const fetchMock = vi.fn<typeof fetch>();

  beforeEach(() => {
    fetchMock.mockReset();
  });

  it('fetches workflows from /api/workflows', async () => {
    fetchMock.mockResolvedValueOnce(
      jsonResponse({
        workflows: [{ id: 'lead_to_outreach', name: 'Lead → Outreach', description: 'x', steps: [] }],
      }),
    );

    const api = createApiClient({ fetchFn: fetchMock, baseUrl: '' });
    const workflows = await api.listWorkflows();

    expect(fetchMock).toHaveBeenCalledWith('/api/workflows', expect.any(Object));
    expect(workflows).toHaveLength(1);
    expect(workflows[0]?.id).toBe('lead_to_outreach');
  });

  it('starts a workflow via POST /api/workflows/:id/run', async () => {
    fetchMock.mockResolvedValueOnce(
      jsonResponse({
        run: { id: 'run_1', workflowId: 'lead_to_outreach', status: 'needs_review', steps: [] },
      }),
    );

    const api = createApiClient({ fetchFn: fetchMock, baseUrl: '' });
    const run = await api.startWorkflow('lead_to_outreach', { leadName: 'Dana' });

    expect(fetchMock).toHaveBeenCalledWith(
      '/api/workflows/lead_to_outreach/run',
      expect.objectContaining({ method: 'POST' }),
    );
    expect(run.id).toBe('run_1');
  });

  it('throws on non-OK responses with server error message', async () => {
    fetchMock.mockResolvedValueOnce(
      jsonResponse({ error: 'Unknown workflow: bad' }, 404),
    );

    const api = createApiClient({ fetchFn: fetchMock, baseUrl: '' });
    await expect(api.startWorkflow('bad', {})).rejects.toThrow('Unknown workflow: bad');
  });

  it('approves a paused workflow step', async () => {
    fetchMock.mockResolvedValueOnce(
      jsonResponse({ run: { id: 'run_1', status: 'completed', steps: [] } }),
    );

    const api = createApiClient({ fetchFn: fetchMock, baseUrl: '' });
    const run = await api.approveStep('run_1', 'draft_outreach');

    expect(fetchMock).toHaveBeenCalledWith(
      '/api/runs/run_1/steps/draft_outreach/approve',
      expect.objectContaining({ method: 'POST' }),
    );
    expect(run.status).toBe('completed');
  });
});
