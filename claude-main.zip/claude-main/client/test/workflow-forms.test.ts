import { describe, it, expect } from 'vitest';
import { buildWorkflowInput, getWorkflowFields } from '@/lib/workflow-forms';

describe('workflow forms', () => {
  it('returns lead-specific fields', () => {
    const fields = getWorkflowFields('lead_to_outreach');
    expect(fields.some((field) => field.name === 'leadName')).toBe(true);
  });

  it('builds trimmed workflow input from form data', () => {
    const formData = new FormData();
    formData.set('leadName', ' Dana ');
    formData.set('leadCompany', 'Nimbus Co');
    formData.set('notes', '   ');

    const input = buildWorkflowInput('lead_to_outreach', formData);
    expect(input).toEqual({ leadName: 'Dana', leadCompany: 'Nimbus Co' });
  });
});
