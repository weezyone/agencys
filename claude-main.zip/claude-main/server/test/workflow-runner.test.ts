import { describe, it, expect, beforeEach } from 'vitest';
import { AgentFactory } from '../src/core/agent-factory.js';
import { MockAiClient } from '../src/core/ai-client.js';
import { createLogger } from '../src/core/logger.js';
import { MessageBus } from '../src/core/message-bus.js';
import { InMemoryArtifactStore } from '../src/core/artifact-store.js';
import { WorkflowRunner } from '../src/core/workflow-runner.js';
import { defaultContext } from '../src/core/agent-context.js';
import { findWorkflow } from '../src/workflows/definitions.js';
import { resetIds } from '../src/core/ids.js';

function makeRunner() {
  const bus = new MessageBus();
  const factory = new AgentFactory({
    ai: new MockAiClient(),
    logger: createLogger('test', true),
    bus,
  });
  const artifacts = new InMemoryArtifactStore(() => '2026-01-01T00:00:00.000Z');
  const runner = new WorkflowRunner({
    factory,
    artifacts,
    logger: createLogger('test', true),
    now: () => '2026-01-01T00:00:00.000Z',
  });
  return { runner, artifacts };
}

describe('WorkflowRunner', () => {
  beforeEach(() => resetIds());

  it('pauses at an approval gate and resumes to completion', async () => {
    const { runner, artifacts } = makeRunner();
    const def = findWorkflow('lead_to_outreach')!;

    let run = await runner.start(def, { leadName: 'Dana', leadCompany: 'Nimbus Co' }, defaultContext());

    // First step completes; second (approval-gated) pauses for review.
    expect(run.status).toBe('needs_review');
    expect(run.steps[0].status).toBe('completed');
    expect(run.steps[1].status).toBe('needs_review');
    // The artifact under review already exists.
    expect(run.steps[1].artifactId).toBeTruthy();
    expect(artifacts.get(run.steps[1].artifactId!)).toBeTruthy();

    run = await runner.approve(run, 'draft_outreach');
    expect(run.status).toBe('completed');
    expect(run.steps.every((s) => s.status === 'completed')).toBe(true);
    expect(run.completedAt).toBeTruthy();
  });

  it('runs a diamond of dependencies in the intake→brief workflow', async () => {
    const { runner, artifacts } = makeRunner();
    const def = findWorkflow('intake_to_brief')!;
    let run = await runner.start(
      def,
      { clientName: 'Acme', goals: ['Launch a site'] },
      defaultContext(),
    );

    // Two steps done, final compose step awaits approval.
    expect(run.steps[0].status).toBe('completed');
    expect(run.steps[1].status).toBe('completed');
    expect(run.steps[2].status).toBe('needs_review');

    // The compose step received both upstream artifacts as dependencies.
    const composeArtifact = artifacts.get(run.steps[2].artifactId!);
    expect(composeArtifact).toBeTruthy();

    run = await runner.approve(run, 'compose_brief');
    expect(run.status).toBe('completed');
    // One artifact per step.
    expect(artifacts.list({ workflowRunId: run.id }).length).toBe(3);
  });

  it('rejecting a paused step fails the run', async () => {
    const { runner } = makeRunner();
    const def = findWorkflow('lead_to_outreach')!;
    let run = await runner.start(def, { leadName: 'Dana' }, defaultContext());
    expect(run.status).toBe('needs_review');
    run = await runner.reject(run, 'draft_outreach', 'off tone');
    expect(run.status).toBe('failed');
  });

  it('respects dependency ordering (dependent runs after its prerequisite)', async () => {
    const { runner } = makeRunner();
    const def = findWorkflow('brief_to_build_plan')!;
    const run = await runner.start(def, { clientName: 'Acme' }, defaultContext());
    const [design, build] = run.steps;
    expect(design.status).toBe('completed');
    // build depends on design; it must have started only after design completed.
    expect(build.startedAt).toBeTruthy();
    expect(design.completedAt).toBeTruthy();
  });
});
