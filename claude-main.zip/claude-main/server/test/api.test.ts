import { describe, it, expect, beforeEach } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/server.js';
import { AgencyService } from '../src/services/agency-service.js';
import { MockAiClient } from '../src/core/ai-client.js';
import { createLogger } from '../src/core/logger.js';
import { resetIds } from '../src/core/ids.js';

function makeApp() {
  const service = new AgencyService({
    logger: createLogger('test', true),
    ai: new MockAiClient(),
  });
  return createApp(service);
}

describe('HTTP API', () => {
  beforeEach(() => resetIds());

  it('GET /api/health returns ok', async () => {
    const res = await request(makeApp()).get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ok');
  });

  it('GET /api/agents lists all seven agents', async () => {
    const res = await request(makeApp()).get('/api/agents');
    expect(res.status).toBe(200);
    expect(res.body.agents).toHaveLength(7);
    expect(res.body.agents[0]).toHaveProperty('label');
  });

  it('POST /api/agents/:type/run runs a single agent', async () => {
    const res = await request(makeApp())
      .post('/api/agents/research/run')
      .send({ instruction: 'Summarise Acme', input: { clientName: 'Acme' } });
    expect(res.status).toBe(200);
    expect(res.body.result.status).toBe('success');
    expect(res.body.result.output).toHaveProperty('findings');
  });

  it('POST /api/agents/:type/run rejects an unknown agent', async () => {
    const res = await request(makeApp())
      .post('/api/agents/wizard/run')
      .send({ instruction: 'cast a spell' });
    expect(res.status).toBe(400);
  });

  it('GET /api/workflows lists the three sample workflows', async () => {
    const res = await request(makeApp()).get('/api/workflows');
    expect(res.status).toBe(200);
    expect(res.body.workflows).toHaveLength(3);
  });

  it('runs a workflow to an approval gate, then approves to completion', async () => {
    const app = makeApp();
    const start = await request(app)
      .post('/api/workflows/lead_to_outreach/run')
      .send({ input: { leadName: 'Dana', leadCompany: 'Nimbus Co' } });
    expect(start.status).toBe(201);
    expect(start.body.run.status).toBe('needs_review');

    const runId = start.body.run.id;
    const pausedStep = start.body.run.steps.find((s: any) => s.status === 'needs_review');
    expect(pausedStep).toBeTruthy();

    const approve = await request(app)
      .post(`/api/runs/${runId}/steps/${pausedStep.step.id}/approve`)
      .send({});
    expect(approve.status).toBe(200);
    expect(approve.body.run.status).toBe('completed');
  });

  it('exposes artifacts produced during a run', async () => {
    const app = makeApp();
    const start = await request(app)
      .post('/api/workflows/lead_to_outreach/run')
      .send({ input: { leadName: 'Dana' } });
    const runId = start.body.run.id;

    const list = await request(app).get(`/api/artifacts?runId=${runId}`);
    expect(list.status).toBe(200);
    expect(list.body.artifacts.length).toBeGreaterThan(0);

    const first = list.body.artifacts[0];
    const one = await request(app).get(`/api/artifacts/${first.id}`);
    expect(one.status).toBe(200);
    expect(one.body.artifact.id).toBe(first.id);
  });

  it('GET /api/stats reports the mock AI client', async () => {
    const res = await request(makeApp()).get('/api/stats');
    expect(res.status).toBe(200);
    expect(res.body.aiClient).toBe('mock');
    expect(res.body.agents).toBe(7);
    expect(res.body.workflows).toBe(3);
  });

  it('unknown API route returns 404', async () => {
    const res = await request(makeApp()).get('/api/does-not-exist');
    expect(res.status).toBe(404);
  });
});
