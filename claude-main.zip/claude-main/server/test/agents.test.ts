import { describe, it, expect, beforeEach } from 'vitest';
import { AgentFactory } from '../src/core/agent-factory.js';
import { MockAiClient } from '../src/core/ai-client.js';
import { createLogger } from '../src/core/logger.js';
import { MessageBus } from '../src/core/message-bus.js';
import { ALL_AGENT_TYPES, AgentType } from '../src/core/agent-types.js';
import { defaultContext } from '../src/core/agent-context.js';
import { resetIds } from '../src/core/ids.js';

function makeFactory() {
  return new AgentFactory({
    ai: new MockAiClient(),
    logger: createLogger('test', true),
    bus: new MessageBus(),
  });
}

describe('specialized agents', () => {
  beforeEach(() => resetIds());

  it('every agent type is constructible and returns a uniform result', async () => {
    const factory = makeFactory();
    for (const type of ALL_AGENT_TYPES) {
      const agent = factory.createAgent(type, defaultContext());
      expect(agent.type).toBe(type);
      const result = await agent.assignTask({
        id: 't',
        title: 'demo',
        instruction: 'do your default task',
        input: { clientName: 'Acme', goals: ['Launch a marketing site'] },
      });
      expect(result.status).toBe('success');
      expect(typeof result.summary).toBe('string');
      expect(result.summary.length).toBeGreaterThan(0);
      expect(typeof result.output).toBe('object');
      expect(agent.status).toBe('completed');
    }
  });

  it('project manager derives milestones from provided goals', async () => {
    const factory = makeFactory();
    const agent = factory.createAgent(AgentType.ProjectManager, defaultContext());
    const result = await agent.assignTask({
      id: 't',
      title: 'goals',
      instruction: 'clarify goals',
      input: { clientName: 'Acme', goals: ['Ship a site', 'Capture leads'] },
    });
    expect(Array.isArray(result.output.milestones)).toBe(true);
    expect((result.output.milestones as unknown[]).length).toBe(2);
  });

  it('client growth produces an outreach message referencing the lead', async () => {
    const factory = makeFactory();
    const agent = factory.createAgent(AgentType.ClientGrowth, defaultContext());
    const result = await agent.assignTask({
      id: 't',
      title: 'outreach',
      instruction: 'draft outreach',
      input: { leadName: 'Dana', leadCompany: 'Nimbus Co' },
    });
    expect(String(result.output.message)).toContain('Dana');
    expect(String(result.output.message)).toContain('Nimbus Co');
  });

  it('creating multiple agents yields unique ids', () => {
    const factory = makeFactory();
    const a = factory.createAgent(AgentType.QA, defaultContext());
    const b = factory.createAgent(AgentType.QA, defaultContext());
    expect(a.id).not.toBe(b.id);
  });

  it('unknown agent type throws', () => {
    const factory = makeFactory();
    // @ts-expect-error deliberately invalid
    expect(() => factory.createAgent('nope', defaultContext())).toThrow();
  });
});
