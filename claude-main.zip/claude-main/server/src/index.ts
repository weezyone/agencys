/**
 * index.ts — process entrypoint. Boots the service and starts the HTTP server.
 */
import { createApp } from './server.js';
import { AgencyService } from './services/agency-service.js';
import { createLogger } from './core/logger.js';

const logger = createLogger('server');
const service = new AgencyService({ logger });
const app = createApp(service);

const port = Number(process.env.PORT ?? 4000);
app.listen(port, () => {
  logger.info(`Agency platform API listening on http://localhost:${port}`);
});
