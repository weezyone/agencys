/**
 * definitions.ts
 *
 * The three sample workflows from the spec. New workflows can be added here
 * without touching the runner or the agents.
 */
import { AgentType } from '../core/agent-types.js';
import type { WorkflowDefinition } from '../core/workflow-runner.js';

export const WORKFLOWS: WorkflowDefinition[] = [
  {
    id: 'lead_to_outreach',
    name: 'Lead → Outreach',
    description:
      'Research summarises a prospect, then Client Growth drafts personalised outreach. An approval gate protects the agency tone.',
    steps: [
      {
        id: 'research_prospect',
        title: 'Summarise the prospect',
        agentType: AgentType.Research,
        instruction: "Summarise the prospect's business and likely needs.",
      },
      {
        id: 'draft_outreach',
        title: 'Draft outreach',
        agentType: AgentType.ClientGrowth,
        instruction: 'Draft a personalised outreach message grounded in the research.',
        dependsOn: ['research_prospect'],
        requiresApproval: true,
      },
    ],
  },
  {
    id: 'intake_to_brief',
    name: 'Intake → Project Brief',
    description:
      'Project Manager summarises client goals, Research adds market context, and the PM composes a brief that requires approval.',
    steps: [
      {
        id: 'summarise_goals',
        title: 'Summarise client goals',
        agentType: AgentType.ProjectManager,
        instruction: 'Clarify the client goals and outline milestones.',
      },
      {
        id: 'market_context',
        title: 'Add market context',
        agentType: AgentType.Research,
        instruction: 'Add market and competitor context for the client.',
        dependsOn: ['summarise_goals'],
      },
      {
        id: 'compose_brief',
        title: 'Compose the project brief',
        agentType: AgentType.ProjectManager,
        instruction: 'Compose a concise project brief from the goals and market context.',
        dependsOn: ['summarise_goals', 'market_context'],
        requiresApproval: true,
      },
    ],
  },
  {
    id: 'brief_to_build_plan',
    name: 'Brief → Build Plan',
    description:
      'Designer proposes a visual direction, Tech Lead outlines the build plan, and QA creates a checklist — with a final approval step.',
    steps: [
      {
        id: 'visual_direction',
        title: 'Propose visual direction',
        agentType: AgentType.Designer,
        instruction: 'Propose a visual direction based on the brief.',
      },
      {
        id: 'build_plan',
        title: 'Outline the build plan',
        agentType: AgentType.TechLead,
        instruction: 'Outline the technical architecture and build plan.',
        dependsOn: ['visual_direction'],
      },
      {
        id: 'qa_checklist',
        title: 'Create the QA checklist',
        agentType: AgentType.QA,
        instruction: 'Define acceptance criteria and a QA checklist for the build.',
        dependsOn: ['build_plan'],
        requiresApproval: true,
      },
    ],
  },
];

export function findWorkflow(id: string): WorkflowDefinition | undefined {
  return WORKFLOWS.find((w) => w.id === id);
}
