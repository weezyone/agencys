/**
 * agency-service.ts
 *
 * Application service that composes the core pieces (AI client, factory,
 * artifact store, workflow runner, message bus) and owns run state. The HTTP
 * layer is a thin wrapper over this class.
 */
import { defaultContext } from '../core/agent-context.js';
import type { AgentRunResult } from '../core/agent-result.js';
import { AgentType, isAgentType, AGENT_LABELS, AGENT_DESCRIPTIONS, ALL_AGENT_TYPES } from '../core/agent-types.js';
import type { AiClient } from '../core/ai-client.js';
import { createAiClient } from '../core/ai-client.js';
import { AgentFactory } from '../core/agent-factory.js';
import type { Artifact } from '../core/artifact-store.js';
import { InMemoryArtifactStore } from '../core/artifact-store.js';
import { nextId } from '../core/ids.js';
import type { Logger } from '../core/logger.js';
import { createLogger } from '../core/logger.js';
import { MessageBus } from '../core/message-bus.js';
import type { AgentMessage } from '../core/message-bus.js';
import { WorkflowRunner } from '../core/workflow-runner.js';
import type { WorkflowRun } from '../core/workflow-runner.js';
import { WORKFLOWS, findWorkflow } from '../workflows/definitions.js';

export interface AgencyServiceOptions {
  logger?: Logger;
  ai?: AiClient;
}

export class AgencyService {
  readonly bus: MessageBus;
  private readonly logger: Logger;
  private readonly ai: AiClient;
  private readonly factory: AgentFactory;
  private readonly artifacts: InMemoryArtifactStore;
  private readonly runner: WorkflowRunner;
  private readonly runs = new Map<string, WorkflowRun>();

  constructor(opts: AgencyServiceOptions = {}) {
    this.logger = opts.logger ?? createLogger('agency');
    this.ai = opts.ai ?? createAiClient(this.logger);
    this.bus = new MessageBus();
    this.factory = new AgentFactory({ ai: this.ai, logger: this.logger, bus: this.bus });
    this.artifacts = new InMemoryArtifactStore();
    this.runner = new WorkflowRunner({
      factory: this.factory,
      artifacts: this.artifacts,
      logger: this.logger.child('runner'),
    });
  }

  // --- Agents -------------------------------------------------------------

  listAgents() {
    return ALL_AGENT_TYPES.map((type) => ({
      type,
      label: AGENT_LABELS[type],
      description: AGENT_DESCRIPTIONS[type],
    }));
  }

  /** Run a single agent ad-hoc (mirrors POST /api/agents/:type/run). */
  async runAgent(
    type: string,
    instruction: string,
    input: Record<string, unknown> = {},
  ): Promise<AgentRunResult> {
    if (!isAgentType(type)) {
      throw new HttpError(400, `Unknown agent type: ${type}`);
    }
    const agent = this.factory.createAgent(type as AgentType, defaultContext());
    return agent.assignTask({
      id: nextId('task'),
      title: instruction || `${AGENT_LABELS[type as AgentType]} ad-hoc task`,
      instruction: instruction || 'Perform your default task for the given input.',
      input,
    });
  }

  // --- Workflows ----------------------------------------------------------

  listWorkflows() {
    return WORKFLOWS.map((w) => ({
      id: w.id,
      name: w.name,
      description: w.description,
      steps: w.steps.map((s) => ({
        id: s.id,
        title: s.title,
        agentType: s.agentType,
        dependsOn: s.dependsOn ?? [],
        requiresApproval: Boolean(s.requiresApproval),
      })),
    }));
  }

  async startWorkflow(id: string, input: Record<string, unknown> = {}): Promise<WorkflowRun> {
    const def = findWorkflow(id);
    if (!def) throw new HttpError(404, `Unknown workflow: ${id}`);
    const run = await this.runner.start(def, input, defaultContext());
    this.runs.set(run.id, run);
    return run;
  }

  getRun(runId: string): WorkflowRun {
    const run = this.runs.get(runId);
    if (!run) throw new HttpError(404, `Run not found: ${runId}`);
    return run;
  }

  listRuns(): WorkflowRun[] {
    return [...this.runs.values()];
  }

  async approveStep(runId: string, stepId: string): Promise<WorkflowRun> {
    const run = this.getRun(runId);
    try {
      return await this.runner.approve(run, stepId);
    } catch (err) {
      throw new HttpError(400, err instanceof Error ? err.message : String(err));
    }
  }

  async rejectStep(runId: string, stepId: string, reason?: string): Promise<WorkflowRun> {
    const run = this.getRun(runId);
    try {
      return await this.runner.reject(run, stepId, reason);
    } catch (err) {
      throw new HttpError(400, err instanceof Error ? err.message : String(err));
    }
  }

  // --- Artifacts ----------------------------------------------------------

  listArtifacts(filter: { workflowRunId?: string; projectId?: string } = {}): Artifact[] {
    return this.artifacts.list(filter);
  }

  getArtifact(id: string): Artifact {
    const artifact = this.artifacts.get(id);
    if (!artifact) throw new HttpError(404, `Artifact not found: ${id}`);
    return artifact;
  }

  // --- Activity feed ------------------------------------------------------

  recentActivity(limit = 50): AgentMessage[] {
    return this.bus.recent(limit);
  }

  stats() {
    const runs = this.listRuns();
    return {
      agents: ALL_AGENT_TYPES.length,
      workflows: WORKFLOWS.length,
      runs: runs.length,
      runsByStatus: runs.reduce<Record<string, number>>((acc, r) => {
        acc[r.status] = (acc[r.status] ?? 0) + 1;
        return acc;
      }, {}),
      artifacts: this.artifacts.list().length,
      aiClient: this.ai.name,
    };
  }
}

/** Error carrying an HTTP status, translated by the route error handler. */
export class HttpError extends Error {
  constructor(public readonly status: number, message: string) {
    super(message);
  }
}
