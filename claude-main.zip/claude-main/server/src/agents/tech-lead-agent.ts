import { BaseAgent } from '../core/base-agent.js';
import type { AgentRunResult, AgentTask } from '../core/agent-result.js';
import { describeTask } from './helpers.js';

/** Determines technical architecture and file structure. */
export class TechLeadAgent extends BaseAgent {
  getDefaultSystemPrompt(): string {
    return [
      'You are the Tech Lead agent for a design/development agency.',
      'Choose a pragmatic architecture and outline the file/module structure',
      'and a sequenced build plan. Favour simple, maintainable choices for V1.',
    ].join(' ');
  }

  protected async executeTask(task: AgentTask): Promise<AgentRunResult> {
    const summary = await this.think(describeTask(task));

    return {
      status: 'success',
      summary,
      output: {
        stack: {
          frontend: 'React + Vite (TypeScript)',
          backend: 'Node + Express (TypeScript)',
          storage: 'In-memory for V1, migrate to SQLite/Postgres later',
        },
        fileStructure: [
          'client/src/pages/*',
          'client/src/components/*',
          'server/src/routes/*',
          'server/src/services/*',
        ],
        buildPlan: [
          'Stand up API skeleton with health check',
          'Implement core domain endpoints',
          'Wire the frontend pages to the API',
          'Add automated tests and a smoke run',
        ],
      },
      risks: ['Keep the storage abstraction thin so the DB migration is low-risk.'],
    };
  }
}
