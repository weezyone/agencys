import { BaseAgent } from '../core/base-agent.js';
import type { AgentRunResult, AgentTask } from '../core/agent-result.js';
import { describeTask, str, strList } from './helpers.js';

/** Clarifies goals, breaks work into milestones, and flags blockers. */
export class ProjectManagerAgent extends BaseAgent {
  getDefaultSystemPrompt(): string {
    return [
      'You are the Project Manager agent for a design/development agency.',
      'Clarify client goals, break work into milestones, identify blockers, and',
      'assign tasks. Be concrete and prioritise a thin end-to-end slice first.',
    ].join(' ');
  }

  protected async executeTask(task: AgentTask): Promise<AgentRunResult> {
    const client = str(task.input, 'clientName', 'the client');
    const goals = strList(task.input, 'goals');
    const summary = await this.think(describeTask(task));

    const milestones = goals.length
      ? goals.map((g, i) => ({
          name: `Milestone ${i + 1}`,
          objective: g,
          owner: 'full_stack_engineer',
        }))
      : [
          { name: 'Milestone 1', objective: 'Discovery & brief sign-off', owner: 'research' },
          { name: 'Milestone 2', objective: 'Design & build plan', owner: 'designer' },
          { name: 'Milestone 3', objective: 'Implementation & QA', owner: 'qa' },
        ];

    return {
      status: 'success',
      summary,
      output: {
        client,
        milestones,
        blockers: [
          goals.length ? null : 'Client goals are not yet explicit — confirm scope.',
        ].filter(Boolean),
        recommendedFirstStep: milestones[0]?.objective ?? 'Confirm scope with the client.',
      },
      questions: goals.length ? [] : ['What are the top 3 outcomes the client wants from this engagement?'],
      risks: ['Scope creep if milestones are not signed off before build begins.'],
    };
  }
}
