import { BaseAgent } from '../core/base-agent.js';
import type { AgentRunResult, AgentTask } from '../core/agent-result.js';
import { describeTask, str } from './helpers.js';

/** Generates brand and layout direction from business context. */
export class DesignerAgent extends BaseAgent {
  getDefaultSystemPrompt(): string {
    return [
      'You are the Designer agent for a design/development agency.',
      'Propose brand and layout direction grounded in the business context.',
      'Give concrete, buildable guidance — palette, type, and page structure.',
    ].join(' ');
  }

  protected async executeTask(task: AgentTask): Promise<AgentRunResult> {
    const client = str(task.input, 'clientName', 'the client');
    const summary = await this.think(describeTask(task));

    return {
      status: 'success',
      summary,
      output: {
        client,
        direction: 'Clean, trustworthy, and modern — confidence without clutter.',
        palette: {
          primary: '#2F6FED',
          accent: '#12B5A5',
          neutralInk: '#1B2130',
          surface: '#F5F7FB',
        },
        typography: { display: 'Fraunces', body: 'Inter' },
        pages: ['Home', 'Services', 'About', 'Contact'],
        components: ['Hero with primary CTA', 'Service cards', 'Testimonials', 'Contact form'],
      },
      questions: ['Are there existing brand assets or colours we must respect?'],
      risks: ['Direction is a starting point; validate with a moodboard before build.'],
    };
  }
}
