import { BaseAgent } from '../core/base-agent.js';
import type { AgentRunResult, AgentTask } from '../core/agent-result.js';
import { describeTask, dependencies } from './helpers.js';

/** Implements code tasks according to the technical plan. */
export class FullStackEngineerAgent extends BaseAgent {
  getDefaultSystemPrompt(): string {
    return [
      'You are the Full-Stack Engineer agent for a design/development agency.',
      'Implement the assigned task against the technical plan. Produce a clear',
      'change list and note anything that still needs wiring or review.',
    ].join(' ');
  }

  protected async executeTask(task: AgentTask): Promise<AgentRunResult> {
    const summary = await this.think(describeTask(task));
    const hasPlan = dependencies(task.input).some((d) => d.agentType === 'tech_lead');

    return {
      status: 'success',
      summary,
      output: {
        changes: [
          'Scaffolded API routes and service layer',
          'Implemented the primary page components',
          'Connected the frontend to the API client',
        ],
        filesTouched: [
          'server/src/server.ts',
          'client/src/pages/Home.tsx',
          'client/src/api/client.ts',
        ],
        followUps: hasPlan ? [] : ['No tech-lead plan was provided — assumptions were made.'],
      },
      questions: hasPlan ? [] : ['Which build plan should implementation follow?'],
      risks: ['Manual verification still required before shipping to the client.'],
    };
  }
}
