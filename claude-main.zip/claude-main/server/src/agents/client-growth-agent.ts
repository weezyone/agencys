import { BaseAgent } from '../core/base-agent.js';
import type { AgentRunResult, AgentTask } from '../core/agent-result.js';
import { describeTask, str, dependencies } from './helpers.js';

/** Handles lead research, personalised outreach, and nurturing prospects. */
export class ClientGrowthAgent extends BaseAgent {
  getDefaultSystemPrompt(): string {
    return [
      'You are the Client Growth agent for a design/development agency.',
      'Draft personalised, on-tone outreach grounded in what research found.',
      'Keep it concise, specific, and respectful — never spammy.',
    ].join(' ');
  }

  protected async executeTask(task: AgentTask): Promise<AgentRunResult> {
    const lead = str(task.input, 'leadName', 'there');
    const company = str(task.input, 'leadCompany', 'your company');
    const researchDep = dependencies(task.input).find((d) => d.agentType === 'research');
    const summary = await this.think(describeTask(task));

    const insight = researchDep
      ? 'your recent focus on growing your online presence'
      : 'the opportunity to strengthen your online presence';

    return {
      status: 'success',
      summary,
      output: {
        lead,
        company,
        channel: 'email',
        subject: `A quick idea for ${company}`,
        message:
          `Hi ${lead},\n\n` +
          `I came across ${company} and noticed ${insight}. ` +
          `We help teams like yours ship a polished, high-converting site quickly. ` +
          `Would a 15-minute call next week be useful to share a couple of concrete ideas?\n\n` +
          `Best,\nThe Agency Team`,
        followUpPlan: ['Wait 3 business days', 'Send one value-add follow-up', 'Then close the loop'],
      },
      risks: ['Tone should be approved before sending to protect the agency brand.'],
    };
  }
}
