import { BaseAgent } from '../core/base-agent.js';
import type { AgentRunResult, AgentTask } from '../core/agent-result.js';
import { describeTask } from './helpers.js';

/** Defines acceptance criteria and tests output to catch issues early. */
export class QAAgent extends BaseAgent {
  getDefaultSystemPrompt(): string {
    return [
      'You are the QA agent for a design/development agency.',
      'Define crisp acceptance criteria and a checklist that verifies the work',
      'end-to-end. Call out edge cases the build should handle.',
    ].join(' ');
  }

  protected async executeTask(task: AgentTask): Promise<AgentRunResult> {
    const summary = await this.think(describeTask(task));

    return {
      status: 'success',
      summary,
      output: {
        acceptanceCriteria: [
          'All primary pages render without console errors',
          'The API health check returns ok',
          'Core user flow works end-to-end',
        ],
        qaChecklist: [
          { item: 'Responsive layout at mobile and desktop widths', status: 'todo' },
          { item: 'Forms validate and show helpful errors', status: 'todo' },
          { item: 'Broken-link and empty-state handling', status: 'todo' },
        ],
        edgeCases: ['Slow network', 'Empty data sets', 'Invalid form input'],
      },
      risks: ['Untested edge cases can surface as client-facing defects.'],
    };
  }
}
