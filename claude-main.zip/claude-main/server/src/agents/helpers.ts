/**
 * helpers.ts
 *
 * Small utilities shared by the specialized agents for reading task input and
 * summarising upstream artifacts. Keeping these here avoids repeating the same
 * defensive input-parsing in every agent.
 */
import type { AgentTask } from '../core/agent-result.js';

/** Read a string field from task input with a fallback. */
export function str(input: Record<string, unknown>, key: string, fallback = ''): string {
  const v = input[key];
  if (typeof v === 'string' && v.trim()) return v.trim();
  return fallback;
}

/** Read a string[] field from task input. */
export function strList(input: Record<string, unknown>, key: string): string[] {
  const v = input[key];
  if (Array.isArray(v)) return v.filter((x): x is string => typeof x === 'string');
  if (typeof v === 'string' && v.trim()) {
    return v
      .split(/[,\n]/)
      .map((s) => s.trim())
      .filter(Boolean);
  }
  return [];
}

export interface DependencySummary {
  stepId: string;
  title: string;
  agentType: string;
  summary: string;
  output: Record<string, unknown>;
}

/** Upstream step outputs, passed in by the WorkflowRunner under `dependencies`. */
export function dependencies(input: Record<string, unknown>): DependencySummary[] {
  const v = input['dependencies'];
  return Array.isArray(v) ? (v as DependencySummary[]) : [];
}

/** A compact, human-readable rendering of the task focus, used to prompt the model. */
export function describeTask(task: AgentTask): string {
  const deps = dependencies(task.input);
  const depLine = deps.length
    ? ` Building on: ${deps.map((d) => d.title).join('; ')}.`
    : '';
  return `${task.instruction}${depLine}`;
}
