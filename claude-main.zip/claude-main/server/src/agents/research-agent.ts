import { BaseAgent } from '../core/base-agent.js';
import type { AgentRunResult, AgentTask } from '../core/agent-result.js';
import { describeTask, str } from './helpers.js';

/** Gathers facts about a client's business or market. */
export class ResearchAgent extends BaseAgent {
  getDefaultSystemPrompt(): string {
    return [
      'You are the Research agent for a design/development agency.',
      'Perform retrieval-style research to gather concrete facts about the',
      "client's business, market, and competitors. Cite what you would verify.",
    ].join(' ');
  }

  protected async executeTask(task: AgentTask): Promise<AgentRunResult> {
    const subject =
      str(task.input, 'businessDescription') ||
      str(task.input, 'leadCompany') ||
      str(task.input, 'clientName', 'the subject business');
    const summary = await this.think(describeTask(task));

    return {
      status: 'success',
      summary,
      output: {
        subject,
        findings: [
          `Primary offering inferred from the brief: ${subject}.`,
          'Target segment appears to be small-to-mid-market buyers.',
          'Competitive differentiation should lean on service quality and speed.',
        ],
        marketContext: {
          trend: 'Buyers increasingly expect a fast, credible online presence.',
          opportunity: 'A polished V1 site plus clear positioning can win early deals.',
        },
        sourcesToVerify: [
          'Company website / LinkedIn for positioning',
          'Two or three direct competitors for pricing and messaging',
        ],
      },
      risks: ['Findings are inferred from the brief and should be validated with the client.'],
    };
  }
}
