/**
 * agent-types.ts
 *
 * Single source of truth for the agent roster. Every specialized agent and
 * every workflow step references one of these values, so a typo can never
 * silently create a phantom agent type.
 */
export enum AgentType {
  ProjectManager = 'project_manager',
  Research = 'research',
  Designer = 'designer',
  TechLead = 'tech_lead',
  FullStackEngineer = 'full_stack_engineer',
  QA = 'qa',
  ClientGrowth = 'client_growth',
}

/** Human-readable labels for UI + logging. */
export const AGENT_LABELS: Record<AgentType, string> = {
  [AgentType.ProjectManager]: 'Project Manager',
  [AgentType.Research]: 'Research',
  [AgentType.Designer]: 'Designer',
  [AgentType.TechLead]: 'Tech Lead',
  [AgentType.FullStackEngineer]: 'Full-Stack Engineer',
  [AgentType.QA]: 'QA',
  [AgentType.ClientGrowth]: 'Client Growth',
};

/** One-line role summaries, surfaced on the Agents screen. */
export const AGENT_DESCRIPTIONS: Record<AgentType, string> = {
  [AgentType.ProjectManager]:
    'Clarifies client goals, breaks work into milestones, and flags blockers.',
  [AgentType.Research]:
    'Runs retrieval-style research to gather facts about a business or market.',
  [AgentType.Designer]:
    'Generates brand direction and layout guidance from business context.',
  [AgentType.TechLead]:
    'Determines technical architecture and the file/module structure.',
  [AgentType.FullStackEngineer]:
    'Implements code tasks according to the technical plan.',
  [AgentType.QA]:
    'Defines acceptance criteria and tests output to catch issues early.',
  [AgentType.ClientGrowth]:
    'Handles lead research, personalised outreach, and nurturing prospects.',
};

export const ALL_AGENT_TYPES: AgentType[] = Object.values(AgentType);

export function isAgentType(value: unknown): value is AgentType {
  return typeof value === 'string' && ALL_AGENT_TYPES.includes(value as AgentType);
}
