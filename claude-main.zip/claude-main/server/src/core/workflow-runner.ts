/**
 * workflow-runner.ts
 *
 * Deterministic orchestrator. It executes ordered steps, honouring
 * dependencies and approval gates, and stores each step's output as an
 * artifact. Approval gates pause the run *after* an artifact is produced so a
 * human can review the concrete output before the workflow proceeds.
 */
import type { AgentContext } from './agent-context.js';
import type { AgentRunResult } from './agent-result.js';
import type { AgentType } from './agent-types.js';
import type { AgentFactory } from './agent-factory.js';
import type { ArtifactStore } from './artifact-store.js';
import { nextId } from './ids.js';
import type { Logger } from './logger.js';

export interface WorkflowStep {
  id: string;
  title: string;
  agentType: AgentType;
  /** What the agent is asked to produce. */
  instruction: string;
  /** Step ids that must complete before this one is ready. */
  dependsOn?: string[];
  /** If true, the run pauses for human approval after this step produces its artifact. */
  requiresApproval?: boolean;
}

export interface WorkflowDefinition {
  id: string;
  name: string;
  description: string;
  steps: WorkflowStep[];
}

export type StepStatus =
  | 'pending'
  | 'in_progress'
  | 'completed'
  | 'failed'
  | 'needs_review';

export interface WorkflowRunStep {
  step: WorkflowStep;
  status: StepStatus;
  artifactId?: string;
  result?: AgentRunResult;
  startedAt?: string;
  completedAt?: string;
}

export type WorkflowRunStatus =
  | 'pending'
  | 'running'
  | 'needs_review'
  | 'completed'
  | 'failed';

export interface WorkflowRun {
  id: string;
  workflowId: string;
  workflowName: string;
  projectId: string;
  context: AgentContext;
  input: Record<string, unknown>;
  status: WorkflowRunStatus;
  steps: WorkflowRunStep[];
  createdAt: string;
  startedAt?: string;
  completedAt?: string;
}

export interface WorkflowRunnerDeps {
  factory: AgentFactory;
  artifacts: ArtifactStore;
  logger: Logger;
  now?: () => string;
}

export class WorkflowRunner {
  private readonly now: () => string;

  constructor(private readonly deps: WorkflowRunnerDeps) {
    this.now = deps.now ?? (() => new Date().toISOString());
  }

  /** Create a run from a definition and process it until completion or a pause. */
  async start(
    def: WorkflowDefinition,
    input: Record<string, unknown>,
    context: AgentContext,
  ): Promise<WorkflowRun> {
    const projectId = context.projectId ?? nextId('project');
    const run: WorkflowRun = {
      id: nextId('run'),
      workflowId: def.id,
      workflowName: def.name,
      projectId,
      context: { ...context, projectId },
      input,
      status: 'pending',
      steps: def.steps.map((step) => ({ step, status: 'pending' as StepStatus })),
      createdAt: this.now(),
    };
    this.deps.logger.info(`Starting workflow "${def.name}" as ${run.id}`);
    return this.process(run);
  }

  /** Approve a paused step and resume processing. */
  async approve(run: WorkflowRun, stepId: string): Promise<WorkflowRun> {
    const rs = run.steps.find((s) => s.step.id === stepId);
    if (!rs) throw new Error(`Step not found: ${stepId}`);
    if (rs.status !== 'needs_review') {
      throw new Error(`Step ${stepId} is not awaiting review (status: ${rs.status}).`);
    }
    rs.status = 'completed';
    this.deps.logger.info(`Approved step ${stepId} on ${run.id}`);
    return this.process(run);
  }

  /** Reject a paused step; the run fails. */
  async reject(run: WorkflowRun, stepId: string, reason = 'Rejected by reviewer'): Promise<WorkflowRun> {
    const rs = run.steps.find((s) => s.step.id === stepId);
    if (!rs) throw new Error(`Step not found: ${stepId}`);
    if (rs.status !== 'needs_review') {
      throw new Error(`Step ${stepId} is not awaiting review (status: ${rs.status}).`);
    }
    rs.status = 'failed';
    run.status = 'failed';
    run.completedAt = this.now();
    this.deps.logger.warn(`Rejected step ${stepId} on ${run.id}: ${reason}`);
    return run;
  }

  /** Core loop: run ready steps one at a time until done, failed, or paused. */
  private async process(run: WorkflowRun): Promise<WorkflowRun> {
    if (run.status === 'pending') run.status = 'running';
    if (!run.startedAt) run.startedAt = this.now();

    // A step already awaiting review means the run is paused.
    if (run.steps.some((s) => s.status === 'needs_review')) {
      run.status = 'needs_review';
      return run;
    }

    // Execute ready steps sequentially. Each iteration may pause the run.
    // eslint-disable-next-line no-constant-condition
    while (true) {
      const ready = run.steps.find(
        (s) => s.status === 'pending' && this.dependenciesSatisfied(run, s),
      );
      if (!ready) break;

      await this.runStep(run, ready);

      if (ready.status === 'failed') {
        run.status = 'failed';
        run.completedAt = this.now();
        return run;
      }
      if (ready.status === 'needs_review') {
        run.status = 'needs_review';
        return run;
      }
    }

    return this.finalise(run);
  }

  private dependenciesSatisfied(run: WorkflowRun, rs: WorkflowRunStep): boolean {
    const deps = rs.step.dependsOn ?? [];
    return deps.every(
      (depId) => run.steps.find((s) => s.step.id === depId)?.status === 'completed',
    );
  }

  private async runStep(run: WorkflowRun, rs: WorkflowRunStep): Promise<void> {
    rs.status = 'in_progress';
    rs.startedAt = this.now();

    const agent = this.deps.factory.createAgent(rs.step.agentType, run.context);
    const result = await agent.assignTask({
      id: nextId('task'),
      title: rs.step.title,
      instruction: rs.step.instruction,
      input: {
        ...run.input,
        dependencies: this.collectDependencyArtifacts(run, rs),
      },
    });

    const artifact = this.deps.artifacts.save({
      workflowRunId: run.id,
      projectId: run.projectId,
      producedBy: rs.step.agentType,
      stepId: rs.step.id,
      title: rs.step.title,
      content: { summary: result.summary, ...result.output },
    });

    rs.result = result;
    rs.artifactId = artifact.id;
    rs.completedAt = this.now();

    if (result.status === 'failed') {
      rs.status = 'failed';
      return;
    }
    // Approval gate: pause with the artifact available for review.
    rs.status = rs.step.requiresApproval ? 'needs_review' : 'completed';
  }

  private collectDependencyArtifacts(run: WorkflowRun, rs: WorkflowRunStep) {
    const deps = rs.step.dependsOn ?? [];
    return deps
      .map((depId) => run.steps.find((s) => s.step.id === depId))
      .filter((s): s is WorkflowRunStep => Boolean(s?.result))
      .map((s) => ({
        stepId: s.step.id,
        title: s.step.title,
        agentType: s.step.agentType,
        summary: s.result!.summary,
        output: s.result!.output,
      }));
  }

  private finalise(run: WorkflowRun): WorkflowRun {
    if (run.steps.every((s) => s.status === 'completed')) {
      run.status = 'completed';
      run.completedAt = this.now();
      this.deps.logger.info(`Workflow ${run.id} completed.`);
    } else if (run.steps.some((s) => s.status === 'failed')) {
      run.status = 'failed';
      run.completedAt = this.now();
    }
    // Otherwise the run is blocked on an unsatisfiable dependency; leave as-is.
    return run;
  }
}
