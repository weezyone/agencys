/**
 * ids.ts
 *
 * Process-local monotonic id generator. Deterministic ordering makes tests
 * stable and ids readable (e.g. "agent_7", "run_2").
 */
const counters = new Map<string, number>();

export function nextId(prefix: string): string {
  const n = (counters.get(prefix) ?? 0) + 1;
  counters.set(prefix, n);
  return `${prefix}_${n}`;
}

/** Test helper: reset all counters so ids are reproducible per test. */
export function resetIds(): void {
  counters.clear();
}
