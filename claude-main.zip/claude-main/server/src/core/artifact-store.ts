/**
 * artifact-store.ts
 *
 * Persists agent outputs so they can be reviewed later or consumed as inputs
 * by downstream steps. V1 is in-memory; the interface is deliberately narrow
 * so a database-backed implementation can drop in later.
 */
import { nextId } from './ids.js';
import type { AgentType } from './agent-types.js';

export interface Artifact {
  id: string;
  workflowRunId?: string;
  projectId: string;
  producedBy: AgentType;
  stepId?: string;
  title: string;
  content: Record<string, unknown>;
  createdAt: string;
}

export interface NewArtifact {
  workflowRunId?: string;
  projectId: string;
  producedBy: AgentType;
  stepId?: string;
  title: string;
  content: Record<string, unknown>;
}

export interface ArtifactStore {
  save(artifact: NewArtifact): Artifact;
  get(id: string): Artifact | undefined;
  list(filter?: { workflowRunId?: string; projectId?: string }): Artifact[];
}

export class InMemoryArtifactStore implements ArtifactStore {
  private artifacts = new Map<string, Artifact>();

  constructor(private readonly now: () => string = () => new Date().toISOString()) {}

  save(input: NewArtifact): Artifact {
    const artifact: Artifact = {
      id: nextId('artifact'),
      createdAt: this.now(),
      ...input,
    };
    this.artifacts.set(artifact.id, artifact);
    return artifact;
  }

  get(id: string): Artifact | undefined {
    return this.artifacts.get(id);
  }

  list(filter: { workflowRunId?: string; projectId?: string } = {}): Artifact[] {
    return [...this.artifacts.values()].filter((a) => {
      if (filter.workflowRunId && a.workflowRunId !== filter.workflowRunId) return false;
      if (filter.projectId && a.projectId !== filter.projectId) return false;
      return true;
    });
  }
}
