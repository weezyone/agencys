/**
 * base-agent.ts
 *
 * Abstract base for every specialized agent. Consolidates identity, context,
 * task lifecycle, logging, messaging, and AI access so concrete agents only
 * implement two methods: getDefaultSystemPrompt() and executeTask().
 */
import type { AgentContext } from './agent-context.js';
import type { AgentRunResult, AgentTask, TaskStatus } from './agent-result.js';
import type { AgentType } from './agent-types.js';
import { AGENT_LABELS } from './agent-types.js';
import type { AiClient } from './ai-client.js';
import type { Logger } from './logger.js';
import type { MessageBus } from './message-bus.js';

export interface AgentDeps {
  id: string;
  type: AgentType;
  context: AgentContext;
  ai: AiClient;
  logger: Logger;
  bus: MessageBus;
}

export abstract class BaseAgent {
  readonly id: string;
  readonly type: AgentType;
  protected readonly context: AgentContext;
  protected readonly ai: AiClient;
  protected readonly logger: Logger;
  protected readonly bus: MessageBus;

  private _status: TaskStatus = 'pending';

  constructor(deps: AgentDeps) {
    this.id = deps.id;
    this.type = deps.type;
    this.context = deps.context;
    this.ai = deps.ai;
    this.logger = deps.logger;
    this.bus = deps.bus;
  }

  get status(): TaskStatus {
    return this._status;
  }

  /** The system prompt that shapes this agent's behaviour. */
  abstract getDefaultSystemPrompt(): string;

  /** Perform the actual work and return structured data. */
  protected abstract executeTask(task: AgentTask): Promise<AgentRunResult>;

  /**
   * Public entry point. Manages the pending → in_progress →
   * completed/failed lifecycle and never throws — a thrown error becomes a
   * failed AgentRunResult so the WorkflowRunner can react uniformly.
   */
  async assignTask(task: AgentTask): Promise<AgentRunResult> {
    this._status = 'in_progress';
    this.publish('task_started', `Started: ${task.title}`);
    try {
      const result = await this.executeTask(task);
      this._status = result.status === 'failed' ? 'failed' : 'completed';
      this.publish(
        result.status === 'failed' ? 'task_failed' : 'task_completed',
        result.status === 'failed'
          ? `Failed: ${task.title}`
          : `Completed: ${task.title}`,
      );
      return result;
    } catch (err) {
      this._status = 'failed';
      const message = err instanceof Error ? err.message : String(err);
      this.logger.error(`Agent ${this.id} threw while executing "${task.title}"`, {
        error: message,
      });
      this.publish('task_failed', `Errored: ${task.title}`);
      return {
        status: 'failed',
        summary: `The ${this.label} agent could not complete the task: ${message}`,
        output: {},
        risks: ['Unhandled error during execution — see server logs.'],
      };
    }
  }

  protected get label(): string {
    return AGENT_LABELS[this.type];
  }

  /** Ask the model, using this agent's system prompt. */
  protected think(prompt: string): Promise<string> {
    return this.ai.complete({ system: this.getDefaultSystemPrompt(), prompt });
  }

  private publish(
    kind: 'task_started' | 'task_completed' | 'task_failed' | 'info',
    message: string,
  ): void {
    this.bus.publish({
      at: new Date().toISOString(),
      agentId: this.id,
      agentType: this.type,
      kind,
      message,
    });
  }
}
