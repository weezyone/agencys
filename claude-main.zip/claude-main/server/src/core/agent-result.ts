/**
 * agent-result.ts
 *
 * Uniform result + task shapes. Because every agent returns the same
 * AgentRunResult, the WorkflowRunner can handle results generically without
 * any agent-specific branching.
 */

/** Lifecycle status of a task/agent run. */
export type TaskStatus = 'pending' | 'in_progress' | 'completed' | 'failed';

/** Outcome status reported by an agent for a single run. */
export type RunStatus = 'success' | 'needs_input' | 'failed';

/** A unit of work handed to an agent. */
export interface AgentTask {
  id: string;
  title: string;
  /** Free-form instruction describing what the agent should produce. */
  instruction: string;
  /** Structured inputs (client brief, upstream artifacts, etc.). */
  input: Record<string, unknown>;
}

/** The single shape every agent returns. */
export interface AgentRunResult {
  status: RunStatus;
  /** Short human-readable narrative of what was produced. */
  summary: string;
  /** Structured, domain-specific output. */
  output: Record<string, unknown>;
  /** Open questions the agent needs answered to proceed with confidence. */
  questions?: string[];
  /** Risks or caveats the agent surfaced. */
  risks?: string[];
}
