/**
 * agent-context.ts
 *
 * Contextual data an agent can access during execution. Kept deliberately
 * small in V1 — tenant/project/lead identifiers plus an open metadata bag.
 */
export interface AgentContext {
  tenantId: string;
  projectId?: string;
  leadId?: string;
  metadata?: Record<string, unknown>;
}

export function defaultContext(overrides: Partial<AgentContext> = {}): AgentContext {
  return {
    tenantId: overrides.tenantId ?? 'tenant_demo',
    projectId: overrides.projectId,
    leadId: overrides.leadId,
    metadata: overrides.metadata ?? {},
  };
}
