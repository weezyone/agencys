/**
 * message-bus.ts
 *
 * Lightweight in-process pub/sub. Agents emit lifecycle messages here; the
 * service layer can subscribe to build a live activity feed. Deliberately
 * simple (no external broker) for V1.
 */
export interface AgentMessage {
  at: string;
  agentId: string;
  agentType: string;
  kind: 'task_started' | 'task_completed' | 'task_failed' | 'info';
  message: string;
  meta?: Record<string, unknown>;
}

type Listener = (msg: AgentMessage) => void;

export class MessageBus {
  private listeners = new Set<Listener>();
  private history: AgentMessage[] = [];
  private readonly maxHistory: number;

  constructor(maxHistory = 200) {
    this.maxHistory = maxHistory;
  }

  publish(msg: AgentMessage): void {
    this.history.push(msg);
    if (this.history.length > this.maxHistory) {
      this.history.splice(0, this.history.length - this.maxHistory);
    }
    for (const listener of this.listeners) listener(msg);
  }

  subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  recent(limit = 50): AgentMessage[] {
    return this.history.slice(-limit);
  }
}
