/**
 * ai-client.ts
 *
 * Abstraction over the model provider. Agents never talk to a provider
 * directly — they call the injected AiClient. This keeps API keys server-side
 * and lets us swap a deterministic mock (default) for the real Anthropic API
 * simply by setting ANTHROPIC_API_KEY.
 */
import type { Logger } from './logger.js';

export interface AiCompletionRequest {
  /** System prompt shaping the model's behaviour. */
  system: string;
  /** The user/task prompt. */
  prompt: string;
}

export interface AiClient {
  readonly name: string;
  complete(req: AiCompletionRequest): Promise<string>;
}

/**
 * Deterministic, dependency-free client. Produces a stable, plausible
 * narrative derived from the prompt so the whole platform runs — and is
 * testable and screenshot-able — without any network or API key.
 */
export class MockAiClient implements AiClient {
  readonly name = 'mock';

  async complete({ system, prompt }: AiCompletionRequest): Promise<string> {
    const role = firstLine(system)
      .replace(/^You are (a|an|the)\s+/i, '')
      .replace(/[.:].*$/, '')
      .trim();
    const focus = firstLine(prompt).replace(/\s+/g, ' ').trim().slice(0, 140);
    return (
      `As the ${role || 'agent'}, I analysed the request and produced a ` +
      `structured, actionable response. Focus: ${focus || 'the assigned task'}.`
    );
  }
}

/**
 * Real provider client. Uses the official Anthropic SDK (loaded lazily so the
 * package is only required when a key is actually configured). Falls back to
 * a mock-style string if the SDK or network is unavailable, so a run never
 * hard-crashes on a transient provider issue.
 */
export class AnthropicAiClient implements AiClient {
  readonly name = 'anthropic';
  private readonly apiKey: string;
  private readonly logger: Logger;
  // Lazily-constructed SDK client (typed as unknown to avoid a hard dep).
  private clientPromise: Promise<unknown> | null = null;

  constructor(apiKey: string, logger: Logger) {
    this.apiKey = apiKey;
    this.logger = logger;
  }

  private async getClient(): Promise<any> {
    if (!this.clientPromise) {
      // Typed as `string` (not a literal) so TS treats this as a dynamic
      // import of an optional dependency rather than resolving it at compile time.
      const moduleName: string = '@anthropic-ai/sdk';
      this.clientPromise = import(moduleName)
        .then((mod: any) => new mod.default({ apiKey: this.apiKey }))
        .catch((err) => {
          this.logger.error(
            'Failed to load @anthropic-ai/sdk; run `npm i @anthropic-ai/sdk` to enable the real client.',
            { error: String(err) },
          );
          throw err;
        });
    }
    return this.clientPromise;
  }

  async complete({ system, prompt }: AiCompletionRequest): Promise<string> {
    try {
      const client = await this.getClient();
      const res = await client.messages.create({
        model: 'claude-opus-4-8',
        max_tokens: 2048,
        thinking: { type: 'adaptive' },
        system,
        messages: [{ role: 'user', content: prompt }],
      });
      const text = (res.content ?? [])
        .filter((b: any) => b.type === 'text')
        .map((b: any) => b.text)
        .join('\n')
        .trim();
      return text || '(the model returned no text content)';
    } catch (err) {
      this.logger.warn('Anthropic completion failed; using fallback text.', {
        error: String(err),
      });
      return new MockAiClient().complete({ system, prompt });
    }
  }
}

/**
 * Choose a client based on the environment. With ANTHROPIC_API_KEY set, the
 * real client is used; otherwise the deterministic mock keeps everything
 * running offline.
 */
export function createAiClient(logger: Logger): AiClient {
  const key = process.env.ANTHROPIC_API_KEY;
  if (key) {
    logger.info('AI client: Anthropic (ANTHROPIC_API_KEY detected, model claude-opus-4-8).');
    return new AnthropicAiClient(key, logger);
  }
  logger.info('AI client: deterministic mock (set ANTHROPIC_API_KEY to use the real model).');
  return new MockAiClient();
}

function firstLine(text: string): string {
  return (text ?? '').split('\n')[0] ?? '';
}
