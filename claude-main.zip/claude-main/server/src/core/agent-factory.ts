/**
 * agent-factory.ts
 *
 * Maps each AgentType to its constructor and produces fully-wired instances.
 * Adding a new agent is a one-line registry change — nothing else in the
 * system needs to know the concrete class.
 */
import type { AgentContext } from './agent-context.js';
import { defaultContext } from './agent-context.js';
import { AgentType } from './agent-types.js';
import type { AiClient } from './ai-client.js';
import type { BaseAgent, AgentDeps } from './base-agent.js';
import { nextId } from './ids.js';
import type { Logger } from './logger.js';
import type { MessageBus } from './message-bus.js';

import { ProjectManagerAgent } from '../agents/project-manager-agent.js';
import { ResearchAgent } from '../agents/research-agent.js';
import { DesignerAgent } from '../agents/designer-agent.js';
import { TechLeadAgent } from '../agents/tech-lead-agent.js';
import { FullStackEngineerAgent } from '../agents/full-stack-engineer-agent.js';
import { QAAgent } from '../agents/qa-agent.js';
import { ClientGrowthAgent } from '../agents/client-growth-agent.js';

type AgentCtor = new (deps: AgentDeps) => BaseAgent;

const REGISTRY: Record<AgentType, AgentCtor> = {
  [AgentType.ProjectManager]: ProjectManagerAgent,
  [AgentType.Research]: ResearchAgent,
  [AgentType.Designer]: DesignerAgent,
  [AgentType.TechLead]: TechLeadAgent,
  [AgentType.FullStackEngineer]: FullStackEngineerAgent,
  [AgentType.QA]: QAAgent,
  [AgentType.ClientGrowth]: ClientGrowthAgent,
};

export interface AgentFactoryDeps {
  ai: AiClient;
  logger: Logger;
  bus: MessageBus;
}

export class AgentFactory {
  constructor(private readonly deps: AgentFactoryDeps) {}

  createAgent(type: AgentType, context: Partial<AgentContext> = {}): BaseAgent {
    const Ctor = REGISTRY[type];
    if (!Ctor) throw new Error(`Unknown agent type: ${type}`);
    const id = nextId('agent');
    this.deps.logger.info(`Creating agent ${id} (${type})`);
    return new Ctor({
      id,
      type,
      context: defaultContext(context),
      ai: this.deps.ai,
      logger: this.deps.logger.child(type),
      bus: this.deps.bus,
    });
  }
}
