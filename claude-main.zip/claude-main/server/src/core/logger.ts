/**
 * logger.ts
 *
 * Minimal structured logger injected into agents and services. In V1 this is
 * a thin console wrapper; a future iteration can swap in pino/winston without
 * touching call sites.
 */
export interface Logger {
  info(message: string, meta?: Record<string, unknown>): void;
  warn(message: string, meta?: Record<string, unknown>): void;
  error(message: string, meta?: Record<string, unknown>): void;
  child(scope: string): Logger;
}

export function createLogger(scope = 'app', silent = false): Logger {
  const emit = (
    level: 'info' | 'warn' | 'error',
    message: string,
    meta?: Record<string, unknown>,
  ) => {
    if (silent) return;
    const line = `[${level.toUpperCase()}] (${scope}) ${message}`;
    const args = meta && Object.keys(meta).length ? [line, meta] : [line];
    // eslint-disable-next-line no-console
    console[level](...args);
  };

  return {
    info: (m, meta) => emit('info', m, meta),
    warn: (m, meta) => emit('warn', m, meta),
    error: (m, meta) => emit('error', m, meta),
    child: (childScope: string) => createLogger(`${scope}:${childScope}`, silent),
  };
}
