/**
 * server.ts
 *
 * HTTP surface. Client code interacts with agents/workflows exclusively over
 * these routes, so API keys never reach the browser. Handlers are thin — all
 * behaviour lives in AgencyService.
 */
import express from 'express';
import type { Express, Request, Response, NextFunction, RequestHandler } from 'express';
import cors from 'cors';
import { AgencyService, HttpError } from './services/agency-service.js';

/** Wrap an async handler so rejected promises reach the error middleware. */
const wrap =
  (fn: (req: Request, res: Response) => Promise<unknown>): RequestHandler =>
  (req, res, next) => {
    fn(req, res).catch(next);
  };

export function createApp(service: AgencyService): Express {
  const app = express();
  app.use(cors());
  app.use(express.json({ limit: '1mb' }));

  const api = express.Router();

  api.get('/health', (_req, res) => {
    res.json({ status: 'ok', service: 'agency-platform', time: new Date().toISOString() });
  });

  api.get('/stats', (_req, res) => {
    res.json(service.stats());
  });

  // --- Agents ---
  api.get('/agents', (_req, res) => {
    res.json({ agents: service.listAgents() });
  });

  api.post(
    '/agents/:type/run',
    wrap(async (req, res) => {
      const { instruction = '', input = {} } = req.body ?? {};
      const result = await service.runAgent(req.params.type, instruction, input);
      res.json({ result });
    }),
  );

  // --- Workflows ---
  api.get('/workflows', (_req, res) => {
    res.json({ workflows: service.listWorkflows() });
  });

  api.post(
    '/workflows/:id/run',
    wrap(async (req, res) => {
      const { input = {} } = req.body ?? {};
      const run = await service.startWorkflow(req.params.id, input);
      res.status(201).json({ run });
    }),
  );

  // --- Runs ---
  api.get('/runs', (_req, res) => {
    res.json({ runs: service.listRuns() });
  });

  api.get(
    '/runs/:runId',
    wrap(async (req, res) => {
      res.json({ run: service.getRun(req.params.runId) });
    }),
  );

  api.post(
    '/runs/:runId/steps/:stepId/approve',
    wrap(async (req, res) => {
      const run = await service.approveStep(req.params.runId, req.params.stepId);
      res.json({ run });
    }),
  );

  api.post(
    '/runs/:runId/steps/:stepId/reject',
    wrap(async (req, res) => {
      const { reason } = req.body ?? {};
      const run = await service.rejectStep(req.params.runId, req.params.stepId, reason);
      res.json({ run });
    }),
  );

  // --- Artifacts ---
  api.get('/artifacts', (req, res) => {
    const workflowRunId = typeof req.query.runId === 'string' ? req.query.runId : undefined;
    const projectId = typeof req.query.projectId === 'string' ? req.query.projectId : undefined;
    res.json({ artifacts: service.listArtifacts({ workflowRunId, projectId }) });
  });

  api.get(
    '/artifacts/:id',
    wrap(async (req, res) => {
      res.json({ artifact: service.getArtifact(req.params.id) });
    }),
  );

  // --- Activity feed ---
  api.get('/activity', (_req, res) => {
    res.json({ activity: service.recentActivity() });
  });

  app.use('/api', api);

  // 404 for unknown API routes.
  app.use('/api', (_req, res) => {
    res.status(404).json({ error: 'Not found' });
  });

  // Error handler translates HttpError -> status; everything else -> 500.
  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    if (err instanceof HttpError) {
      res.status(err.status).json({ error: err.message });
      return;
    }
    const message = err instanceof Error ? err.message : 'Internal error';
    // eslint-disable-next-line no-console
    console.error('[server] Unhandled error:', err);
    res.status(500).json({ error: message });
  });

  return app;
}
