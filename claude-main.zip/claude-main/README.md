# Agency Agent Platform (V1)

Multi-agent agency operations prototype: specialized AI agents collaborate on lead outreach, client intake briefs, and build plans — with human approval gates and a React UI that never sees API keys.

## Architecture

```
Browser (Vite/React)  →  Express API (:4000)  →  AgentFactory + WorkflowRunner
                              ↓                        ↓
                         ArtifactStore            Mock/OpenAI AiClient
```

| Layer | Location | Role |
|---|---|---|
| Core | `server/src/core/` | `BaseAgent`, `AgentFactory`, `WorkflowRunner`, `ArtifactStore` |
| Agents | `server/src/agents/` | PM, Research, Designer, Tech Lead, Engineer, QA, Client Growth |
| Workflows | `server/src/workflows/` | Lead→Outreach, Intake→Brief, Brief→Build Plan |
| API | `server/src/server.ts` | `/api/*` — all LLM calls stay server-side |
| Client | `client/src/` | Dashboard, launchers, run review, artifact viewer |

## Quick start

```bash
# Install (from repo root)
npm install --prefix server
npm install --prefix client

# Terminal 1 — API (default mock AI, no keys required)
npm run dev:server

# Terminal 2 — UI (proxies /api → http://localhost:4000)
npm run dev:client
```

Open **http://localhost:5173**.

### Optional: real Anthropic calls

```bash
export ANTHROPIC_API_KEY=sk-ant-...
# then restart the server; also: npm i @anthropic-ai/sdk --prefix server
```

Without a key, the server uses a deterministic **mock** provider — ideal for demos and tests.

## Scripts

| Command | What it does |
|---|---|
| `npm run dev:server` / `dev:client` | Start API or UI |
| `npm test` | Server + client unit tests |
| `npm run typecheck` | TypeScript check both packages |
| `npm run test:e2e` | Playwright smoke (auto-starts API + UI) |

## Sample workflows

1. **Lead → Outreach** — Research prospect → Client Growth drafts outreach → **approval gate**
2. **Intake → Brief** — PM goals → Research context → PM composes brief → **approval**
3. **Brief → Build Plan** — Designer → Tech Lead → QA checklist → **approval**

On a run page, approve or reject the paused step to continue or fail the workflow.

## Spec

See [`spec.md`](./spec.md) for the original architecture plan.
