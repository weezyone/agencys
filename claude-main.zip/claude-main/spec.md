Building the V1 Agent‑Powered Agency Platform
Introduction

This document outlines the architecture and implementation plan for Version 1 of the AI‑powered design/development agency platform. The goal is to deliver a reliable, maintainable prototype that demonstrates how specialized agents can work together to perform research, generate strategy documents and code, and handle client outreach. The plan emphasises a simple orchestration model rather than complex distributed coordination so the system can be built quickly and extended iteratively【8†L3-L6】.

Architectural Overview

V1’s core consists of four layers: shared agent abstractions, a centralized agent factory, a lightweight workflow runner and a simple artifact store【8†L7-L11】. Each specialized agent inherits from a common BaseAgent, which provides standard lifecycle management, logging, messaging hooks and AI access. An AgentFactory instantiates agents consistently and injects shared services such as AI clients, message buses, and loggers. The WorkflowRunner executes ordered steps with dependency handling and approval gates, producing artifacts saved in the artifact store. This separation of concerns makes the system easy to understand and extend【8†L20-L23】.

File Structure and Components
Core Definitions
agent-types.ts – Defines the AgentType enum listing available agents: project manager, research, designer, tech lead, full‑stack engineer, QA and client growth【8†L32-L34】. This type ensures a single source of truth for valid agent names throughout the codebase.
agent-context.ts – Specifies what contextual data (tenant, project, lead IDs) an agent can access during execution【8†L37-L39】.
agent-result.ts – Describes a uniform AgentRunResult type with fields for status, summary, output and any questions or risks【8†L45-L49】. This consistency allows the workflow runner to handle results without agent‑specific logic.
Base Agent

The abstract BaseAgent class provides a standard interface for all agents. It stores identity and context, manages task lifecycles (pending → in progress → completed/failed), and delegates AI calls to an injected AiClient【8†L52-L58】. Specialized agents override two methods:

getDefaultSystemPrompt() – returns the system prompt shaping the model’s behaviour.
executeTask() – performs the actual work and returns structured data.

By consolidating generic behaviour in one place, new agents can be added rapidly without duplicating boilerplate【8†L62-L65】.

Agent Factory

The AgentFactory maps each AgentType to its constructor and provides a createAgent() method. When asked to create an agent, the factory:

Generates a unique ID.
Injects shared services (AI client, message bus, artifact store, logger) into the agent.
Returns an instance of the requested type.

This pattern enforces uniform initialization across all agents and simplifies adding new types【8†L68-L70】.

Workflow Runner

The WorkflowRunner orchestrates tasks in a defined order. A WorkflowStep includes an ID, human‑readable title, the agent type that will execute it, optional dependencies, and a flag indicating whether human approval is required【8†L72-L76】. The runner processes workflows as follows:

Mark the workflow as running and record startedAt.
Pick the next ready step (dependencies complete and not yet started). If the step needs approval, set status to needs_review and pause the workflow.
Use the factory to create the appropriate agent and call its assignTask() method.
Save the result in the artifact store and update the step status.
Continue until all steps are completed or a critical failure occurs.

This deterministic execution ensures that steps run in correct order and that pauses happen whenever human validation is needed【8†L79-L85】.

Artifact Store

An artifact store persists outputs from agents so that they can be reviewed later or used as inputs for subsequent steps. Each artifact has an ID, references to the workflow and project, the producing agent type, a title and the content. In V1 this can be in memory or file‑based; future iterations can migrate to a database【8†L88-L90】.

Specialized Agents

Each specialised agent extends BaseAgent and implements domain‑specific logic:

Project Manager Agent – clarifies client goals, breaks work into milestones, identifies blockers and assigns tasks【8†L92-L94】.
Research Agent – performs retrieval‑augmented research to gather facts about the client’s business or market【8†L95-L96】.
Designer Agent – generates brand and layout direction based on business context【8†L97-L98】.
Tech Lead Agent – determines appropriate technical architecture and file structures【8†L99-L100】.
Full‑Stack Engineer Agent – implements code tasks according to the technical plan【8†L101-L102】.
QA Agent – defines acceptance criteria and tests output to catch issues early【8†L103-L104】.
Client Growth Agent – handles lead research, personalised outreach and nurturing prospects【8†L105-L107】.

Each agent outputs a structured object rather than plain text, enabling the workflow runner to interpret and store results【8†L108-L110】.

Client‑Side Interface

To prevent leaking API keys in the browser, the client interacts with agents via HTTP endpoints such as /api/agents/research/run. A small Agent Client Factory in the client code returns an object with a run() method, which posts a request to the appropriate route and awaits a response. This abstraction hides the network details and keeps the API surface consistent across agents【8†L112-L114】.

Workflow Examples

Three sample workflows illustrate how these pieces come together:

Lead → Outreach – The Research Agent summarises a prospect’s business and the Client Growth Agent drafts a personalised outreach plan. An approval gate ensures the outreach message reflects the agency’s tone【8†L116-L118】.
Intake → Project Brief – The Project Manager Agent summarises client goals, the Research Agent adds market context and the Project Manager composes a brief that requires approval【8†L120-L122】.
Brief → Build Plan – The Designer Agent proposes a visual direction, the Tech Lead Agent outlines a build plan and the QA Agent creates a QA checklist, with a final approval step before implementation【8†L124-L126】.

These workflows demonstrate sequential collaboration with clear handoffs and human oversight. More sophisticated flows (parallel tasks or conditional paths) can be added later.【8†L128-L131】

Conclusion and Next Steps

V1 introduces a cohesive architecture that balances simplicity and flexibility. It defines a standard agent foundation, centralises instantiation and coordination, persists outputs and supports multiple specialized roles. This structure allows rapid iteration: new agents can be added by registering them in the factory, and new workflows can be defined without modifying core code【8†L132-L135】. Future enhancements may include parallel task execution, robust persistence (e.g., a database), distributed message queues and expanded agent capabilities.