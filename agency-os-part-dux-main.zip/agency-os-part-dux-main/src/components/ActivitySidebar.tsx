import { 
  Check, 
  Send, 
  UserPlus, 
  Plus, 
  MessageSquare,
  Clock
} from 'lucide-react';
import { motion } from 'motion/react';

interface ActivityItem {
  id: string;
  type: 'proposal_signed' | 'proposal_sent' | 'account_created' | 'note';
  title: string;
  description: string;
  timestamp: string;
  icon: any;
  iconColor: string;
}

const activities: ActivityItem[] = [
  {
    id: '1',
    type: 'proposal_signed',
    title: 'Proposal Q3 2024 Marketing Retainer',
    description: 'was signed by Jane Doe.',
    timestamp: '2d ago',
    icon: Check,
    iconColor: 'bg-teal-500/20 text-teal-400 border border-teal-500/30'
  },
  {
    id: '2',
    type: 'proposal_sent',
    title: 'You sent the proposal',
    description: 'Website Redesign Project.',
    timestamp: '5d ago',
    icon: Send,
    iconColor: 'bg-white/5 text-teal-300 border border-white/10'
  },
  {
    id: '3',
    type: 'account_created',
    title: 'Client account created by',
    description: 'Alex Johnson.',
    timestamp: '1m ago',
    icon: UserPlus,
    iconColor: 'bg-white/5 text-slate-400 border border-white/10'
  }
];

export function ActivitySidebar() {
  return (
    <div className="w-80 glass flex flex-col p-6 h-full overflow-hidden shrink-0">
      <h2 className="text-[10px] uppercase tracking-[0.3em] text-teal-400 font-bold glow-text mb-6">Activity</h2>

      {/* Note Input */}
      <div className="flex gap-2 mb-8">
        <div className="relative flex-1">
          <input 
            type="text" 
            placeholder="Add a note or log activity..."
            className="w-full bg-white/5 text-slate-100 text-sm pl-4 pr-4 py-2.5 rounded-xl border border-white/10 focus:border-teal-400/50 focus:outline-none transition-all placeholder:text-slate-600"
          />
        </div>
        <button className="bg-teal-500/20 hover:bg-teal-500/30 border border-teal-500/50 text-teal-400 w-10 h-10 shrink-0 rounded-xl flex items-center justify-center transition-colors">
          <Plus className="w-5 h-5" />
        </button>
      </div>

      {/* Timeline */}
      <div className="flex-1 space-y-8 relative overflow-y-auto custom-scrollbar pr-2">
        {/* Timeline line */}
        <div className="absolute left-[19px] top-4 bottom-4 w-px bg-white/10" />

        {activities.map((activity, idx) => (
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.1 }}
            key={activity.id} 
            className="flex gap-4 relative"
          >
            <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 z-10 glass ${activity.iconColor}`}>
              <activity.icon className="w-4 h-4" />
            </div>
            <div className="flex-1">
              <div className="flex justify-between items-start mb-1">
                <h4 className="text-xs text-slate-200 leading-tight">
                  <span className="text-white font-medium">{activity.title}</span> {activity.description}
                </h4>
                <span className="font-mono text-[10px] text-teal-400/60 uppercase tracking-widest whitespace-nowrap ml-2">
                  {activity.timestamp}
                </span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
