import { useState } from 'react';
import { 
  Search, 
  Plus, 
  Circle, 
  LayoutGrid, 
  ChevronRight,
  UserPlus
} from 'lucide-react';
import { motion } from 'motion/react';

interface Client {
  id: string;
  name: string;
  contact: string;
  status: 'active' | 'inactive' | 'pending' | 'archived';
  logoColor: string;
}

const clients: Client[] = [
  { id: '1', name: 'Innovate Inc.', contact: 'Jane Doe', status: 'active', logoColor: 'bg-green-100' },
  { id: '2', name: 'Quantum Solutions', contact: 'John Smith', status: 'active', logoColor: 'bg-blue-100' },
  { id: '3', name: 'Apex Digital', contact: 'Emily White', status: 'pending', logoColor: 'bg-teal-100' },
  { id: '4', name: 'Horizon Labs', contact: 'Michael Brown', status: 'archived', logoColor: 'bg-gray-100' },
];

export function Sidebar() {
  const [selectedClient, setSelectedClient] = useState('1');

  return (
    <div className="w-72 glass flex flex-col h-full overflow-hidden shrink-0">
      {/* Brand */}
      <div className="p-6 flex items-center gap-3">
        <div className="w-8 h-8 rounded-full bg-teal-500 flex items-center justify-center glow-teal">
          <div className="w-3 h-3 bg-white rounded-full"></div>
        </div>
        <div className="flex flex-col">
          <h1 className="text-[10px] uppercase tracking-[0.3em] text-teal-400 font-bold glow-text leading-tight">AgencyOS</h1>
          <p className="text-[10px] uppercase opacity-50">Digital Agency</p>
        </div>
      </div>

      {/* Search */}
      <div className="px-4 mb-6">
        <div className="relative group">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 group-focus-within:text-teal-400 transition-colors" />
          <input 
            type="text" 
            placeholder="Search clients..."
            className="w-full bg-white/5 text-slate-100 text-sm pl-10 pr-4 py-2.5 rounded-xl border border-white/10 focus:border-teal-400/50 focus:outline-none focus:ring-4 focus:ring-teal-400/10 transition-all font-medium placeholder:text-slate-500"
          />
        </div>
      </div>

      {/* Client List */}
      <div className="flex-1 overflow-y-auto px-2 space-y-1 custom-scrollbar">
        {clients.map((client) => (
          <button
            key={client.id}
            onClick={() => setSelectedClient(client.id)}
            className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all relative group ${
              selectedClient === client.id 
                ? 'glass border border-teal-500/30 glow-teal' 
                : 'hover:bg-white/5'
            }`}
          >
            <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 border border-white/10 shadow-inner overflow-hidden`}>
              <div className={`w-full h-full flex items-center justify-center text-xs font-bold text-slate-800 ${client.logoColor}`}>
                {client.name.substring(0, 2).toUpperCase()}
              </div>
            </div>
            <div className="flex-1 text-left">
              <h3 className={`text-sm font-semibold transition-colors ${selectedClient === client.id ? 'text-white' : 'text-slate-300 group-hover:text-white'}`}>
                {client.name}
              </h3>
              <p className="text-[10px] uppercase opacity-50 mt-0.5">{client.contact}</p>
            </div>
            <div className={`w-2 h-2 rounded-full ring-4 ring-opacity-10 shrink-0 ${
              client.status === 'active' ? 'bg-teal-400 ring-teal-400/30' :
              client.status === 'pending' ? 'bg-amber-500 ring-amber-500/30' :
              'bg-slate-500 ring-slate-500/30'
            }`} />
          </button>
        ))}
      </div>

      {/* Footer Button */}
      <div className="p-4 border-t border-white/10">
        <button className="w-full bg-teal-500/20 hover:bg-teal-500/30 border border-teal-500/50 text-teal-400 py-3 rounded-xl flex items-center justify-center gap-2 font-bold text-[10px] uppercase tracking-[0.2em] transition-all">
          <Plus className="w-4 h-4" />
          <span>New Client</span>
        </button>
      </div>
    </div>
  );
}
