import { useState } from 'react';
import { 
  MoreHorizontal, 
  Plus, 
  ExternalLink, 
  FileText, 
  Edit3, 
  ArrowRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Proposal {
  id: string;
  title: string;
  status: 'signed' | 'pending' | 'sent' | 'draft';
  value: string;
  dateCreated: string;
}

const proposals: Proposal[] = [
  { id: '1', title: 'Q3 2024 Marketing Retainer', status: 'signed', value: '$25,000', dateCreated: 'July 15, 2024' },
  { id: '2', title: 'Website Redesign Project', status: 'pending', value: '$48,000', dateCreated: 'Aug 01, 2024' },
  { id: '3', title: 'Initial SEO Audit & Strategy', status: 'sent', value: '$5,000', dateCreated: 'June 28, 2024' },
  { id: '4', title: 'Brand Identity Exploration', status: 'draft', value: '$12,000', dateCreated: 'Aug 05, 2024' },
];

const tabs = ['Proposals / SOWs', 'Overview', 'Communication', 'Projects', 'Files'];

export function MainContent() {
  const [activeTab, setActiveTab] = useState('Proposals / SOWs');

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden gap-6 relative">
      
      {/* Header Panel */}
      <div className="shrink-0 flex flex-col pt-2">
        <div className="flex items-start justify-between mb-8">
          <div className="flex items-center gap-6">
            <div className="w-20 h-20 rounded-xl glass border-teal-500/20 flex items-center justify-center overflow-hidden p-2">
              <img 
                src="https://picsum.photos/seed/innovate/200/200" 
                alt="Innovate Inc" 
                className="w-full h-full object-cover rounded-lg filter grayscale opacity-80" 
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <div className="flex items-center gap-4 mb-2">
                <h1 className="text-4xl font-light tracking-tighter italic text-white flex items-center gap-3">Innovate Inc.</h1>
                <span className="px-3 py-1 glass text-teal-400 text-[10px] font-bold uppercase tracking-widest rounded-full glow-teal border border-teal-500/30">
                  Active Client
                </span>
              </div>
              <p className="text-[10px] uppercase tracking-widest opacity-60 mt-2">
                Key Contact: <span className="text-white font-bold mx-1">Jane Doe</span> 
                <span className="mx-2 text-white/20">|</span>
                <a href="mailto:jane.doe@innovate.com" className="text-teal-400 glow-text hover:text-teal-300 transition-colors font-bold lowercase tracking-normal">jane.doe@innovate.com</a>
              </p>
            </div>
          </div>
          <div className="flex gap-3 mt-2">
            <button className="px-5 py-2.5 glass text-[10px] uppercase tracking-widest text-slate-200 font-bold hover:bg-white/5 transition-all flex items-center gap-2">
              <span>More Actions</span>
              <MoreHorizontal className="w-4 h-4" />
            </button>
            <button className="px-5 py-2.5 bg-teal-500/20 border border-teal-500/50 text-teal-400 text-[10px] uppercase tracking-widest font-bold rounded-xl hover:bg-teal-500/30 transition-all flex items-center gap-2">
              <Plus className="w-4 h-4" />
              <span>Create Proposal</span>
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-8 border-b border-white/10 relative">
          {tabs.map((tab) => (
            <button 
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`pb-4 text-[10px] uppercase tracking-widest font-bold transition-all relative ${
                activeTab === tab ? 'text-teal-400 glow-text' : 'text-slate-500 hover:text-slate-300 opacity-60'
              }`}
            >
              {tab}
              {activeTab === tab && (
                <motion.div 
                  layoutId="tabUnderline"
                  className="absolute bottom-0 left-0 right-0 h-[2px] bg-teal-400 shadow-[0_0_8px_rgba(45,212,191,0.5)]" 
                />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto glass p-8 custom-scrollbar relative">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none"></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-8">
            <span className="text-[10px] uppercase tracking-[0.3em] text-teal-400 font-bold glow-text">Proposals & Statements of Work</span>
          </div>

          <table className="w-full text-left">
            <thead className="border-b border-white/10">
              <tr className="[&>th]:pb-6 [&>th]:text-[10px] [&>th]:uppercase [&>th]:tracking-[0.2em] [&>th]:font-bold [&>th]:text-teal-400/50">
                <th className="w-[40%]">Title</th>
                <th className="w-[15%]">Status</th>
                <th className="w-[15%]">Value</th>
                <th className="w-[15%]">Date Created</th>
                <th className="text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {proposals.map((proposal, idx) => (
                <motion.tr 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  key={proposal.id} 
                  className="group hover:bg-white/5 transition-colors"
                >
                  <td className="py-6 pr-4">
                    <div className="font-light italic tracking-tight text-white group-hover:text-teal-400 transition-colors text-lg">{proposal.title}</div>
                  </td>
                  <td className="py-6 pr-4">
                    <StatusBadge status={proposal.status} />
                  </td>
                  <td className="py-6 pr-4">
                    <span className="font-mono text-teal-400 font-bold">{proposal.value}</span>
                  </td>
                  <td className="py-6 pr-4">
                    <span className="font-mono text-[10px] text-white/50 uppercase tracking-widest">{proposal.dateCreated}</span>
                  </td>
                  <td className="py-6 text-right">
                    <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      {proposal.status === 'pending' ? (
                        <div className="flex flex-col items-end gap-1">
                          <button className="text-teal-400 hover:text-teal-300 text-[10px] uppercase tracking-[0.2em] font-bold transition-colors underline underline-offset-4 glow-text">Edit Request</button>
                          <button className="text-teal-400 hover:text-teal-300 text-[10px] uppercase tracking-[0.2em] font-bold transition-colors underline underline-offset-4 glow-text">Signature</button>
                        </div>
                      ) : (
                        <button className="text-teal-400 hover:text-teal-300 text-[10px] uppercase tracking-[0.2em] font-bold transition-colors flex items-center gap-1 group/btn glow-text">
                          <span>{proposal.status === 'draft' ? 'Edit' : 'View'}</span>
                          <ArrowRight className="w-3 h-3 group-hover/btn:translate-x-0.5 transition-transform" />
                        </button>
                      )}
                    </div>
                    {/* Fallback for visible actions as per screenshot */}
                    <div className="group-hover:hidden">
                       {proposal.status === 'pending' ? (
                        <div className="flex flex-col items-end gap-0.5 opacity-50">
                          <span className="text-teal-400 text-[10px] font-bold uppercase tracking-[0.2em]">Edit</span>
                          <span className="text-teal-400 text-[10px] font-bold uppercase tracking-[0.2em]">Request</span>
                          <span className="text-teal-400 text-[10px] font-bold uppercase tracking-[0.2em]">Signature</span>
                        </div>
                      ) : (
                        <span className="text-teal-400 text-[10px] font-bold uppercase tracking-[0.2em] opacity-50">{proposal.status === 'draft' ? 'Edit' : 'View'}</span>
                      )}
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: Proposal['status'] }) {
  const styles = {
    signed: 'bg-teal-500/10 border-teal-500/30 text-teal-400',
    pending: 'bg-transparent border-teal-500/50 text-teal-300 glow-teal',
    sent: 'bg-white/5 border-white/20 text-slate-300',
    draft: 'bg-transparent border-white/10 text-white/40',
  };

  const labels = {
    signed: 'Signed',
    pending: 'Pending Signature',
    sent: 'Sent',
    draft: 'Draft',
  };

  return (
    <span className={`px-2.5 py-1.5 rounded-md text-[9px] font-bold border uppercase tracking-widest ${styles[status]}`}>
      {labels[status]}
    </span>
  );
}
