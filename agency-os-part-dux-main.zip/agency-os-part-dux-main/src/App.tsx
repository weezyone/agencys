/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Sidebar } from './components/Sidebar';
import { MainContent } from './components/MainContent';
import { ActivitySidebar } from './components/ActivitySidebar';

export default function App() {
  return (
    <div className="flex h-screen w-full p-8 gap-6 box-border font-sans">
      <Sidebar />
      <MainContent />
      <ActivitySidebar />
    </div>
  );
}
